/*
 * LX thumbbrowse module
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_thumbbrowse_H
#define LX_thumbbrowse_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxDTBDropPreview ** ILxDTBDropPreviewID;
typedef struct vt_ILxDTBGroupSortOverride ** ILxDTBGroupSortOverrideID;
#include <lxserver.h>
#include <lxvalue.h>



typedef struct vt_ILxDTBDropPreview {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        MarkNone) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        MarkGridPos) (
                LXtObjectID               self,
                const char               *path,
                unsigned int              x,
                unsigned int              y);
                LXxMETHOD(  LxResult,
        MarkEntry) (
                LXtObjectID               self,
                const char               *path);
                LXxMETHOD(  LxResult,
        MarkBetween) (
                LXtObjectID               self,
                const char               *path,
                int                       markBefore);
                LXxMETHOD(  LxResult,
        MarkAnywhere) (
                LXtObjectID               self,
                const char               *path);
} ILxDTBDropPreview;
typedef struct vt_ILxDTBGroupSortOverride {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        SetArguments) (
                LXtObjectID               self,
                const char               *args);
                LXxMETHOD(  int,
        Sort) (
                LXtObjectID               self,
                const char               *string1,
                const char               *string2);
} ILxDTBGroupSortOverride;

#define LXu_DTBDROPPREVIEW              "7ccfca70-79d5-42ed-a5bf-5dfd5bc3262b"
#define LXa_DTBDROPPREVIEW              "dtbdroppreview"
//[local]  ILxDTBDropPreview
#define LXu_DTBGROUPSORTOVERRIDE        "0da992be-74c8-4c25-a402-c69216e52dfb"
#define LXa_DTBGROUPSORTOVERRIDE        "dtbgroupsortoverride"
//[local]  ILxDTBGroupSortOverride
//[export] ILxDTBGroupSortOverride gso

 #ifdef __cplusplus
  }
 #endif
#endif

