/*
 * Copyright (c) 2008-2019 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include "lxoWriter.hpp"

/*
 * This is an array of all the Luxology channels & sub-channels used by the application.
 * The constants are defined in lxidef.h.
 */
static char const *     s_channelNames[] = 
    {
    LXsICHAN_RENDER_AMBCOLOR,
    LXsICHAN_RENDER_AMBRAD,
    LXsICHAN_RENDER_RAYTHRESH,
    LXsICHAN_RENDER_RAYSHADOW,
    LXsICHAN_RENDER_REFLDEPTH,
    LXsICHAN_RENDER_REFRDEPTH,
    LXsICHAN_RENDER_GLOBRAYS,
    LXsICHAN_RENDER_GLOBLIMIT,
    LXsICHAN_RENDER_GLOBENABLE,
    LXsICHAN_RENDER_GLOBSUPER,
    LXsICHAN_RENDER_GLOBRANGE,
    LXsICHAN_RENDER_IRRRAYS,
    LXsICHAN_RENDER_IRRVALS,
    LXsICHAN_RENDER_IRRCACHE,
    LXsICHAN_RENDER_IRRRATE,
    LXsICHAN_RENDER_IRRRATIO,
    LXsICHAN_RENDER_IRRGRADS,
    LXsICHAN_RENDER_GLOBCAUS,
    LXsICHAN_RENDER_GLOBSUBS,

    LXsICHAN_RENDER_DISPENABLE,
    LXsICHAN_RENDER_DISPRATE,
    LXsICHAN_RENDER_DISPRATIO,
    LXsICHAN_RENDER_EDGEMIN,
    LXsICHAN_RENDER_DISPSMOOTH,
    LXsICHAN_RENDER_CAUSENABLE,
    LXsICHAN_RENDER_CAUSTOTAL,
    LXsICHAN_RENDER_CAUSLOCAL,

    LXsICHAN_POLYRENDER_AA,
    LXsICHAN_POLYRENDER_AAFILTER,
    LXsICHAN_POLYRENDER_RESX,
    LXsICHAN_POLYRENDER_RESY,
    LXsICHAN_POLYRENDER_FINERATE,
    LXsICHAN_POLYRENDER_FINETHRESH,
    LXsICHAN_POLYRENDER_BUCKETX,
    LXsICHAN_POLYRENDER_BUCKETY,

    LXsICHAN_RENDEROUTPUT_BLOOM,
    LXsICHAN_RENDEROUTPUT_BLOOMRAD,
    LXsICHAN_RENDEROUTPUT_BLOOMTHR,
    LXsICHAN_RENDEROUTPUT_CLAMP,
    LXsICHAN_RENDEROUTPUT_DEPTHMAX,
    LXsICHAN_RENDEROUTPUT_FILENAME,
    LXsICHAN_RENDEROUTPUT_FORMAT,
    LXsICHAN_RENDEROUTPUT_GAMMA,
    LXsICHAN_RENDEROUTPUT_OCCLRANGE,
    LXsICHAN_RENDEROUTPUT_OCCLRAYS,
    LXsICHAN_RENDEROUTPUT_TONEAMT,
    LXsICHAN_RENDEROUTPUT_WHITE,

    LXsICHAN_SCENE_TIME,
    LXsICHAN_SCENE_SCENES,
    LXsICHAN_SCENE_SCENEE,
    LXsICHAN_SCENE_CURRENTS,
    LXsICHAN_SCENE_CURRENTE,
    LXsICHAN_SCENE_TIMESYS,
    LXsICHAN_SCENE_FPS,
    LXsICHAN_SCENE_DRAWSIZE,

    LXsICHAN_IMAGEMAP_MIN,
    LXsICHAN_IMAGEMAP_MAX,
    LXsICHAN_IMAGEMAP_ALPHA,
    LXsICHAN_IMAGEMAP_REDINV,
    LXsICHAN_IMAGEMAP_GREENINV,
    LXsICHAN_IMAGEMAP_BLUEINV,

    LXsICHAN_LOCATOR_RENDER,
    LXsICHAN_LOCATOR_VISIBLE,
    LXsICHAN_LOCATOR_DISSOLVE,

    LXsICHAN_MESH_RENDER_CURVES,
    LXsICHAN_DOMELIGHT_RADIUS,

    LXsICHAN_TRANSFORM_BLEND,
    LXsICHAN_TRANSFORM_TYPE,
    LXsICHAN_TRANSLATION_POS,

    LXsICHAN_ROTATION_ORDER,
    LXsICHAN_ROTATION_ROT,
    };

enum 
    {
    CURVE_COLOR = 0xffffffFF,       // RGBA
    };

static const float          s_curveThickness = 0.5;

/*------------------------------- Luxology LLC --------------------------- 01/12
 *
 * process command line args to specify the output LXO file, and optional output file.
 * Use the LxoWriter class to write an LXO file.
 *
 *----------------------------------------------------------------------------*/
LxResult ExportLxoCurves (char const* lxoFilename, LXtFVector* points, int nCurves, int nPointsPerCurve)
{
    LxResult    result;
    LxoWriter   writer (lxoFilename, s_channelNames, sizeof s_channelNames / sizeof s_channelNames[0]);

    if (! writer.IsLxoValid ())
        return LXe_NOACCESS;

    /*
     * List all materials used for curves & lines.  These can be in the form of explicitly defined
     * materials, which are listed by name, or simple materials defined by color only.
     *
     * These need to be added BEFORE the call to WriteFileHeader() as they are written into the header.
     */
    writer.AddMaterialTag (CURVE_COLOR);

    /*
     * Write the data required at the begining of the LXO file
     */
    if (LXe_OK != (result = writer.WriteFileHeader ("ZBrush Curves")))
        return result;

    /*
     * This is where you would create and export all of your geometry. For this
     * test application, we just create and export a view types in memory.
     *
     * Note: all positions/distances are in meters.
     */

    for (int i = 0; i < nCurves; ++i, points += nPointsPerCurve)
        if (LXe_OK != (result = writer.WriteCurve (points, nPointsPerCurve, s_curveThickness, CURVE_COLOR)))
            return result;

    /*
     * Upon exit, the destructor for the LxoWriter will close the LXO file.
     */
    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 01/12
 *
 * process command line args to specify the output LXO file.
 * Use the LxoWriter class to write an LXO file.
 *
 *----------------------------------------------------------------------------*/
int main (int argc, char const * const argv[])
{
    static char         usage[] = "Usage: %s lxoFileName";

    if (argc < 2)
        return fprintf (stderr, usage, argv[0]);

    LxResult    result;
    char const* lxoFile         = argv[1];
    const int   pointsPerCurve  = 4;
    const int   nCurves         = 3;

    LXtFVector      points[] = {   { 10.f, 10.f, -5.f }, {  0.f, 10.f,  0.f },     // Poly in Z plane
                                   {  0.f,  0.f,  0.f }, { 10.f,  0.f, -5.f },
                                   {  0.f, 10.f,  0.f }, {  0.f, 10.f, 10.f },     // Poly in X plane
                                   {  0.f,  0.f, 10.f }, {  0.f,  0.f,  0.f },
                                   {  0.f,  0.f,  0.f }, {  0.f,  0.f, 10.f },     // Poly in Y plane
                                   { 10.f,  0.f, 10.f }, { 10.f,  0.f,  0.f },
                                };

    if (LXe_OK != (result = ExportLxoCurves (lxoFile, points, nCurves, pointsPerCurve)))
        return result;

    return result;
}

