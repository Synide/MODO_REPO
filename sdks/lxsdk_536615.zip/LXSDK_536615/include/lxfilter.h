/*
 * LX cache module
 *
 * Copyright (c) 2008-2019 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_cache_H
#define LX_cache_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxEvaluationStack ** ILxEvaluationStackID;
typedef struct vt_ILxStackFilter ** ILxStackFilterID;
typedef struct vt_ILxStackFilter1 ** ILxStackFilter1ID;
typedef struct vt_ILxCacheData ** ILxCacheDataID;
typedef struct vt_ILxCacheService ** ILxCacheServiceID;
#include <lxcom.h>



typedef struct vt_ILxEvaluationStack {
        ILxUnknown       iunk;
                LXxMETHOD( const char *,
        Type) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        Branch) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        AddFilter) (
                LXtObjectID              self,
                LXtObjectID              filter);
} ILxEvaluationStack;
typedef struct vt_ILxStackFilter {
        ILxUnknown       iunk;
                LXxMETHOD( const char *,
        Type) (
                LXtObjectID                      self);

                LXxMETHOD( unsigned,
        Compare) (
                LXtObjectID                      self,
                LXtObjectID                      other);

                LXxMETHOD( LxResult,
        Convert) (
                LXtObjectID                      self,
                LXtObjectID                      other);

                LXxMETHOD( LxResult,
        Identifier) (
                LXtObjectID                      self,
                const char                     **identifier);
} ILxStackFilter;
typedef struct vt_ILxStackFilter1 {
        ILxUnknown       iunk;
                LXxMETHOD( const char *,
        Type) (
                LXtObjectID                      self);

                LXxMETHOD( unsigned,
        Compare) (
                LXtObjectID                      self,
                LXtObjectID                      other);

                LXxMETHOD( LxResult,
        Convert) (
                LXtObjectID                      self,
                LXtObjectID                      other);
} ILxStackFilter1;
typedef struct vt_ILxCacheData {
        ILxUnknown       iunk;
                LXxMETHOD( unsigned int,
        Size) (
                LXtObjectID                      self);
} ILxCacheData;
typedef struct vt_ILxCacheService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD( LxResult,
        Register) (
                LXtObjectID                      self,
                const char                      *name);
                LXxMETHOD( void,
        Release) (
                LXtObjectID                      self,
                const char                      *name);
                LXxMETHOD( LxResult,
        GetData) (
                LXtObjectID                      self,
                const char                      *name,
                unsigned int                     key,
                void                            **ppvObj);
                LXxMETHOD( LxResult,
        SetData) (
                LXtObjectID                      self,
                const char                      *name,
                unsigned int                     key,
                LXtObjectID                      data);
                LXxMETHOD( void,
        PurgeData) (
                LXtObjectID                      self,
                const char                      *name);
} ILxCacheService;

#define LXsSTACK_IMAGE           "imageStack"
#define LXsSTACK_MESH            "meshStack"
#define LXsSTACK_SHADER          "shaderStack"
#define LXsSTACK_TEXTURE         "textureStack"
#define LXsSTACK_TXTRLOC         "txtrlocStack"
#define LXsSTACK_GRADIENT        "gradientStack"
#define LXsSTACK_PARTICLE        "particleStack"
#define LXu_EVALUATIONSTACK     "47F3BF05-B64A-49D9-A2C1-08B0D36AB787"
// [local]  ILxEvaluationStack
// [python] ILxEvaluationStack:Branch   obj EvaluationStack
#define LXiSTACK_DIFFERENT       0
#define LXiSTACK_COMPATIBLE      1
#define LXiSTACK_IDENTICAL       2

#define LXsCACHE_EVALSTACK      "evalstack"

#define LXu_STACKFILTER         "D1A07939-DB83-4869-9427-A78D134DA575"
// [local]   ILxStackFilter
// [export]  ILxStackFilter filt
// [default] ILxStackFilter:Compare = LXiSTACK_DIFFERENT
#define LXu_STACKFILTER1        "B79CF5D3-C630-401B-82A5-AD866BC05B6F"
#define LXu_CACHEDATA           "7561D111-72BD-4C0C-9E2D-9268A0EC30C2"

// [local]   ILxCacheData
// [export]  ILxCacheData cache
#define LXu_CACHESERVICE         "6BB353D3-179A-477A-AC23-946DECB45A37"

 #ifdef __cplusplus
  }
 #endif
#endif

