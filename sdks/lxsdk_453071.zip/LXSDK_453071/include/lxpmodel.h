/*
 * LX pmodel module
 *
 * Copyright (c) 2008-2017 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_pmodel_H
#define LX_pmodel_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxMeshElementGroup ** ILxMeshElementGroupID;
typedef struct vt_ILxSelectionOperation ** ILxSelectionOperationID;
typedef struct vt_ILxSelectionOperation1 ** ILxSelectionOperation1ID;
typedef struct vt_ILxSelectionState ** ILxSelectionStateID;
#include <lxcom.h>
#include <lxmesh.h>
#include <lxserver.h>



typedef struct vt_ILxMeshElementGroup {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        GroupCount) (
                LXtObjectID              self,
                unsigned int            *count);
                LXxMETHOD( LxResult,
        GroupName) (
                LXtObjectID               self,
                unsigned int              index,
                const char              **name);
                LXxMETHOD( LxResult,
        GroupUserName) (
                LXtObjectID               self,
                unsigned int              index,
                const char              **username);
                LXxMETHOD( LxResult,
        TestPoint) (
                LXtObjectID              self,
                unsigned int             index,
                LXtPointID               point);
                LXxMETHOD( LxResult,
        TestEdge) (
                LXtObjectID              self,
                unsigned int             index,
                LXtEdgeID                edge);
                LXxMETHOD( LxResult,
        TestPolygon) (
                LXtObjectID              self,
                unsigned int             index,
                LXtPolygonID             polygon);
} ILxMeshElementGroup;
typedef struct vt_ILxSelectionOperation {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        SetMesh) (
                LXtObjectID              self,
                LXtObjectID              mesh);
                LXxMETHOD( LxResult,
        SetTransform) (
                LXtObjectID              self,
                LXtMatrix4               xfrm);
                LXxMETHOD( LxResult,
        TestPoint) (
                LXtObjectID              self,
                LXtPointID               point);
                LXxMETHOD( LxResult,
        TestEdge) (
                LXtObjectID              self,
                LXtEdgeID                edge);
                LXxMETHOD( LxResult,
        TestPolygon) (
                LXtObjectID              self,
                LXtPolygonID             polygon);
                LXxMETHOD( LxResult,
        Evaluate) (
                LXtObjectID              self,
                LXtID4                   type,
                LXtObjectID              state);
} ILxSelectionOperation;
typedef struct vt_ILxSelectionOperation1 {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        SetMesh) (
                LXtObjectID              self,
                LXtObjectID              mesh);

                LXxMETHOD( LxResult,
        SetTransform) (
                LXtObjectID              self,
                LXtMatrix4               xfrm);

                LXxMETHOD( LxResult,
        TestPoint) (
                LXtObjectID              self,
                LXtPointID               point);

                LXxMETHOD( LxResult,
        TestEdge) (
                LXtObjectID              self,
                LXtEdgeID                edge);

                LXxMETHOD( LxResult,
        TestPolygon) (
                LXtObjectID              self,
                LXtPolygonID             polygon);
} ILxSelectionOperation1;
typedef struct vt_ILxSelectionState {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        TestPoint) (
                LXtObjectID              self,
                LXtPointID               point);
                LXxMETHOD( LxResult,
        TestEdge) (
                LXtObjectID              self,
                LXtEdgeID                edge);
                LXxMETHOD( LxResult,
        TestPolygon) (
                LXtObjectID              self,
                LXtPolygonID             polygon);
                LXxMETHOD( LxResult,
        SetPoint) (
                LXtObjectID              self,
                LXtPointID               point,
                LxResult                 state);
                LXxMETHOD( LxResult,
        SetEdge) (
                LXtObjectID              self,
                LXtEdgeID                edge,
                LxResult                 state);
                LXxMETHOD( LxResult,
        SetPolygon) (
                LXtObjectID              self,
                LXtPolygonID             polygon,
                LxResult                 state);
} ILxSelectionState;

#define LXsITYPE_MESHOP                 "meshoperation"
#define LXsICHAN_MESHOP_ENABLE          "enable"
#define LXsICHAN_MESHOP_OBJ             "meshOpObj"
#define LXsICHAN_MESHOP_SELTYPE         "selectionType"
#define LXsICHAN_MESHOP_USEXFRM         "useWorldXfrm"
#define LXsPKG_MESHOP_CREATECMD         "meshop.create"
#define LXsMESHOP_PMODEL                "pmodel.meshop"
#define LXsITYPE_TOOLOP                 "tooloperation"
#define LXsGRAPH_TOOL                   "tool"
#define LXsTOOL_PMODEL                  "pmodel.toolop"
#define LXsICHAN_TOOL_OBJ               "toolObj"
#define LXsPKG_TOOL_CHANNEL             "tool.channel"
#define LXsPKG_TOOL_TASK                "tool.task"
#define LXsPKG_TOOL_ORDER               "tool.order"
#define LXu_MESHELEMENTGROUP            "4773EA40-C2D6-4B55-800C-59FF6E9730B7"
#define LXa_MESHELEMENTGROUP            "meshelementgroup"
// [local] ILxMeshElementGroup
// [export] ILxMeshElementGroup                 eltgrp
// [python] ILxMeshElementGroup:TestPoint       bool
// [python] ILxMeshElementGroup:TestEdge        bool
// [python] ILxMeshElementGroup:TestPolygon     bool

// [python] type LXtPointID                     id
// [python] type LXtEdgeID                      id
// [python] type LXtPolygonID                   id
#define LXsGRAPH_SELOP                  "selop"
#define LXsITYPE_SELOP                  "selectionoperation"

#define LXsICHAN_SELOP_ENABLE           "enable"
#define LXsICHAN_SELOP_OBJ              "selopobj"
#define LXsICHAN_SELOP_INVERT           "invert"
#define LXsICHAN_SELOP_BLENDMODE        "blendmode"
#define LXiSELOP_BLEND_OVERRIDE          0
#define LXiSELOP_BLEND_ADD               1
#define LXiSELOP_BLEND_SUBTRACT          2
#define LXiSELOP_BLEND_MULTIPLY          3
#define LXsPMODEL_SELECTIONTYPES        "selectionoperation"
#define LXsSELOP_TYPE_NONE              "-"
#define LXsSELOP_TYPE_VERTEX            "VERX"
#define LXsSELOP_TYPE_EDGE              "EDGE"
#define LXsSELOP_TYPE_POLYGON           "POLY"
#define LXsSELOP_PMODEL                 "pmodel.selectionop"
#define LXu_SELECTIONOPERATION          "AA86E146-36F1-44C3-B170-0107F600941D"
#define LXa_SELECTIONOPERATION          "selectionoperation2"
// [local] ILxSelectionOperation
// [export] ILxSelectionOperation               selop
// [python] ILxSelectionOperation:TestPoint     bool
// [python] ILxSelectionOperation:TestEdge      bool
// [python] ILxSelectionOperation:TestPolygon   bool
#define LXu_SELECTIONOPERATION1         "563E56B1-ACC9-4E3F-B3A8-E0AFE2AB5645"
#define LXa_SELECTIONOPERATION1         "selectionoperation"
#define LXu_SELECTIONSTATE              "D1F068A3-5DFC-4587-AD63-FE1D4D0501ED"
#define LXa_SELECTIONSTATE              "selectionstate"
// [local] ILxSelectionState
// [python] ILxSelectionState:TestPoint         bool
// [python] ILxSelectionState:TestEdge          bool
// [python] ILxSelectionState:TestPolygon       bool

 #ifdef __cplusplus
  }
 #endif
#endif

