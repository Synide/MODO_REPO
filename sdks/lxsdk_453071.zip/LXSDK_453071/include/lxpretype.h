/*
 * LX pretype module
 *
 * Copyright (c) 2008-2017 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_pretype_H
#define LX_pretype_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxPresetLoaderTarget ** ILxPresetLoaderTargetID;
typedef struct vt_ILxPresetType ** ILxPresetTypeID;
typedef struct vt_ILxPresetType1 ** ILxPresetType1ID;
typedef struct vt_ILxPresetMetrics ** ILxPresetMetricsID;
typedef struct vt_ILxPresetMetrics1 ** ILxPresetMetrics1ID;
typedef struct vt_ILxPresetBrowserSource ** ILxPresetBrowserSourceID;
typedef struct vt_ILxPresetBrowserService ** ILxPresetBrowserServiceID;
#include <lxserver.h>
#include <lxvalue.h>
#include <lxdirbrowse.h>



typedef struct vt_ILxPresetLoaderTarget {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        ServerName) (
                LXtObjectID              self,
                char                    *buf,
                unsigned                 len);
                LXxMETHOD( LxResult,
        CategoryCount) (
                LXtObjectID              self,
                int                     *count);
                LXxMETHOD( LxResult,
        CategoryByIndex) (
                LXtObjectID               self,
                int                       index,
                const char              **category);
} ILxPresetLoaderTarget;
typedef struct vt_ILxPresetType {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Recognize) (
                LXtObjectID               self,
                const char               *path,
                const char              **category);
                LXxMETHOD( LxResult,
        Apply) (
                LXtObjectID               self,
                const char               *path,
                LXtObjectID               destination);
                LXxMETHOD( LxResult,
        Do) (
                LXtObjectID               self,
                const char               *path);
                LXxMETHOD( LxResult,
        DoCommandFlags) (
                LXtObjectID               self,
                const char               *path,
                int                      *flags);
                LXxMETHOD( LxResult,
        Metrics) (
                LXtObjectID               self,
                const char               *path,
                int                       flags,
                int                       w,
                int                       h,
                LXtObjectID               prevMetrics,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        GenericThumbnailResource) (
                LXtObjectID               self,
                const char               *path,
                const char              **resourceName);
                LXxMETHOD( LxResult,
        BaseAspect) (
                LXtObjectID               self,
                float                    *aspect);
                LXxMETHOD( LxResult,
        StoreThumbnail) (
                LXtObjectID               self,
                const char               *path,
                LXtObjectID               image);
                LXxMETHOD( LxResult,
        DefaultThumbnail) (
                LXtObjectID               self,
                const char               *path);
                LXxMETHOD( LxResult,
        StoreMarkup) (
                LXtObjectID               self,
                const char               *path,
                LXtObjectID               attr);
} ILxPresetType;
typedef struct vt_ILxPresetType1 {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Recognize) (
                LXtObjectID               self,
                const char               *path,
                const LXtGUID           **guid,
                const char              **category);

                LXxMETHOD( LxResult,
        Apply) (
                LXtObjectID               self,
                const char               *path,
                LXtObjectID               destination);

                LXxMETHOD( LxResult,
        Do) (
                LXtObjectID               self,
                const char               *path);

                LXxMETHOD( LxResult,
        DoCommandFlags) (
                LXtObjectID               self,
                const char               *path,
                int                      *flags);

                LXxMETHOD( LxResult,
        Metrics) (
                LXtObjectID               self,
                const char               *path,
                int                       flags,
                int                       w,
                int                       h,
                LXtObjectID               prevMetrics,
                void                    **ppvObj);

                LXxMETHOD( LxResult,
        GenericThumbnailResource) (
                LXtObjectID               self,
                const char               *path,
                const char              **resourceName);

                LXxMETHOD( LxResult,
        BaseAspect) (
                LXtObjectID               self,
                float                    *aspect);
} ILxPresetType1;
typedef struct vt_ILxPresetMetrics {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        ThumbnailImage) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        ThumbnailIdealSize) (
                LXtObjectID               self,
                int                      *idealW,
                int                      *idealH);
                LXxMETHOD( LxResult,
        ThumbnailResource) (
                LXtObjectID               self,
                const char              **resourceName);
                LXxMETHOD( LxResult,
        Metadata) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Markup) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Flags) (
                LXtObjectID               self,
                int                      *flags);
} ILxPresetMetrics;
typedef struct vt_ILxPresetMetrics1 {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Label) (
                LXtObjectID               self,
                const char              **label);

                LXxMETHOD( LxResult,
        ThumbnailImage) (
                LXtObjectID               self,
                void                    **ppvObj);

                LXxMETHOD( LxResult,
        ThumbnailIdealSize) (
                LXtObjectID               self,
                int                      *idealW,
                int                      *idealH);

                LXxMETHOD( LxResult,
        ThumbnailResource) (
                LXtObjectID               self,
                const char              **resourceName);

                LXxMETHOD( LxResult,
        Caption) (
                LXtObjectID               self,
                const char              **caption);

                LXxMETHOD( LxResult,
        ToolTip) (
                LXtObjectID               self,
                const char              **tooltip);
} ILxPresetMetrics1;
typedef struct vt_ILxPresetBrowserSource {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ViewportHash) (
                LXtObjectID              self,
                char                    *buf,
                int                      len);
} ILxPresetBrowserSource;
typedef struct vt_ILxPresetBrowserService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD(  LxResult,
        SubtypeFromIdentifier) (
                LXtObjectID              self,
                const char              *identifier,
                int                     *subtype);
                LXxMETHOD(  LxResult,
        UpdateIdentifierState) (
                LXtObjectID              self,
                const char              *identifier,
                const char              *path);
                LXxMETHOD(  LxResult,
        ServerCount) (
                LXtObjectID              self,
                int                     *count);

                LXxMETHOD(  LxResult,
        ServerByIndex) (
                LXtObjectID               self,
                int                       index,
                void                    **ppvObj);

                LXxMETHOD(  LxResult,
        ServerLookup) (
                LXtObjectID               self,
                const char               *name,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ServerNameByIndex) (
                LXtObjectID               self,
                int                       index,
                const char              **name);

                LXxMETHOD(  LxResult,
        ServerUserNameByIndex) (
                LXtObjectID               self,
                int                       index,
                const char              **name);
                LXxMETHOD(  LxResult,
        RecognizeFile) (
                LXtObjectID               self,
                const char               *path,
                int                       flags,
                const char              **serverName,
                const char              **category);
                LXxMETHOD(  LxResult,
        RecognizeFileForce) (
                LXtObjectID               self,
                const char               *path,
                int                       flags,
                const char              **serverName,
                const char              **category);
                LXxMETHOD(  LxResult,
        Rescan) (
                LXtObjectID              self,
                const char              *path);
} ILxPresetBrowserService;

#define LXiSEL_PRST     LXxID4('P','R','S','T') /* Preset */
#define LXu_PRESET                      "CA09DCB1-4E6B-4cbb-BC5E-378CE759B9E1"
#define LXa_PRESET                      "preset"
#define LXu_PRESETLOADERTARGET          "3B15936E-11F4-4D4A-8ADC-8310C6D9508E"
// [local]  ILxPresetLoaderTarget
#define LXu_PRESETTYPE                  "ea04c0c2-61af-4f45-b1a1-bce681e8982d"
#define LXa_PRESETTYPE                  "presetType"
//[export] ILxPresetType ptyp
//[local]  ILxPresetType
//[python] ILxPresetType:Metrics        obj PresetMetrics
#define LXe_PRESET_ALREADY_APPLIED      LXxGOODCODE( LXeSYS_PRESET, 1 )
#define LXsPBS_CATEGORY                 "presettype.category"
#define LXsPBS_DOSPATTERN               "presettype.dosPattern"
#define LXsPBS_CANAPPLY                 "presettype.canApply"
#define LXsPBS_CANDO                    "presettype.canDo"
#define LXsPBS_ORDINAL                  "presettype.ordinal"
#define LXsPBS_DYNAMICTHUMBNAILS        "presettype.dynamicThumbnails"
#define LXsPBS_SYNTHETICSUPPORT         "presettype.syntheticSupport"
#define LXiPBMETRICS_THUMBNAIL_IMAGE            0x0001
#define LXiPBMETRICS_BASIC_INFO                 0x0002
#define LXiPBMETRICS_EXTRA_ATTRIBUTES           0x0004

#define LXiPBMETRICS_ALL                        (LXiPBMETRICS_THUMBNAIL_IMAGE | LXiPBMETRICS_BASIC_INFO | LXiPBMETRICS_EXTRA_ATTRIBUTES)
#define LXiPBTHUMBSIZE_FULL             LXiDCE_THUMBSIZE_FULL
#define LXu_PRESETTYPE1         "2ED1F957-16BE-4d83-82A3-BE5AF7821891"
//[export] ILxPresetType1 ptyp1
//[local]  ILxPresetType1
//[python] ILxPresetType1:Metrics       obj PresetMetrics
#define LXu_PRESETMETRICS               "3139ccf8-57ee-472c-8dc9-d51f8c0acb6b"
#define LXa_PRESETMETRICS               "presetmetrics"
//[export] ILxPresetMetrics pmet
//[local]  ILxPresetMetrics
//[python] ILxPresetMetrics:ThumbnailImage      obj Image
//[python] ILxPresetMetrics:Metadata            obj Attributes
//[python] ILxPresetMetrics:Markup              obj Attributes
#define LXsPBMETA_LABEL         "label"
#define LXsPBMETA_CAPTION       "caption"
#define LXsPBMETA_TOOLTIP       "tooltip"
#define LXu_PRESETMETRICS1              "79185753-0696-4c54-9daa-fe01253bfc07"
//[export] ILxPresetMetrics1 pmet1
//[local]  ILxPresetMetrics1
//[python] ILxPresetMetrics1:ThumbnailImage     obj Image
#define LXu_PRESETBROWSERSOURCE         "cc776670-63a8-4fa9-9618-e369b5a22f62"
#define LXa_PRESETBROWSERSOURCE         "presebrowsersource"
//[local]  ILxPresetBrowserSource
#define LXu_PRESETBROWSERSERVICE        "05C3FF8F-5C3C-4463-AF6E-439C52621DCA"
#define LXa_PRESETBROWSERSERVICE        "presetbrowserservice"
// [python] ILxPresetBrowserService:ServerByIndex       obj PresetType
// [python] ILxPresetBrowserService:ServerLookup        obj PresetType
#define LXfPRESETRECOGNIZE_CAN_APPLY            0x01
#define LXfPRESETRECOGNIZE_CAN_DO               0x02

#define LXiPRESETRECOGNIZE_ALL                  0

 #ifdef __cplusplus
  }
 #endif
#endif

