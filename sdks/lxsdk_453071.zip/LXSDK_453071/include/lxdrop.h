/*
 * LX drop module
 *
 * Copyright (c) 2008-2017 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_drop_H
#define LX_drop_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxDrop ** ILxDropID;
typedef struct vt_ILxDrop1 ** ILxDrop1ID;
typedef struct vt_ILxAddDropAction ** ILxAddDropActionID;
typedef struct vt_ILxDropPreviewDefault ** ILxDropPreviewDefaultID;
typedef struct vt_ILxDropService ** ILxDropServiceID;
#include <lxcom.h>
#include <lxserver.h>



typedef struct vt_ILxDrop {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Recognize) (
                LXtObjectID               self,
                LXtObjectID               source);
                LXxMETHOD( LxResult,
        ActionList) (
                LXtObjectID               self,
                LXtObjectID               source,
                LXtObjectID               dest,
                LXtObjectID               addDropAction);
                LXxMETHOD( LxResult,
        Preview) (
                LXtObjectID               self,
                LXtObjectID               source,
                LXtObjectID               dest,
                int                       action,
                LXtObjectID               draw);
                LXxMETHOD( LxResult,
        Drop) (
                LXtObjectID               self,
                LXtObjectID               source,
                LXtObjectID               dest,
                int                       action);
} ILxDrop;
typedef struct vt_ILxDrop1 {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Recognize) (
                LXtObjectID               self,
                LXtObjectID               source);

                LXxMETHOD( LxResult,
        ActionList) (
                LXtObjectID               self,
                LXtObjectID               source,
                LXtObjectID               dest,
                LXtObjectID               addDropAction);

                LXxMETHOD( LxResult,
        Drop) (
                LXtObjectID               self,
                LXtObjectID               source,
                LXtObjectID               dest,
                int                       action);
} ILxDrop1;
typedef struct vt_ILxAddDropAction {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        AddAction) (
                LXtObjectID              self,
                int                      action,
                const char              *message);
                LXxMETHOD(  LxResult,
        Peek) (
                LXtObjectID               self,
                void                    **ppvObj);
} ILxAddDropAction;
typedef struct vt_ILxDropPreviewDefault {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Draw) (
                LXtObjectID              self);
} ILxDropPreviewDefault;
typedef struct vt_ILxDropService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD(  LxResult,
        Destination) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Source) (
                LXtObjectID               self,
                const char              **sourceType,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Action) (
                LXtObjectID               self,
                const char              **serverName,
                int                      *actionCode);
} ILxDropService;

#define LXu_DROP                "ca3c0d04-5ebe-40a7-bb1a-d38488c7967d"
#define LXa_DROP                "drop"
//[export] ILxDrop drop
//[local]  ILxDrop
#define LXsDROP_SOURCETYPE              "drop.sourceType"
#define LXsDROPSOURCE_FILES             "files"
#define LXsDROPSOURCE_FILES_SYNTH       "filesAndSynthetics"
#define LXsDROPSOURCE_COLOR             "color"
#define LXsDROPSOURCE_ITEMS             "items"
#define LXsDROPSOURCE_CHANNELS          "channels"
#define LXsDROPSOURCE_COMMANDS          "commands"
#define LXsDROPSOURCE_FORMCONTROLS      "formcontrols"
#define LXsDROP_ACTIONNAMES     "drop.actions"
#define LXu_DROP1               "abea8de3-d821-4437-88b3-05f20276ffeb"
// [export] ILxDrop1 drop1
// [local]  ILxDrop1
#define LXu_ADDDROPACTION       "05C3FF8F-5C3C-4463-AF6E-439C52621DCA"
#define LXa_ADDDROPACTION       "adddropaction"
// [local]  ILxAddDropAction
// [python] ILxAddDropAction:Peek       obj Unknown
#define LXu_DROPPREVIEWDEFAULT  "f3823495-d23f-448f-a5dd-16a1761445a0"
#define LXa_DROPPREVIEWDEFAULT  "droppreviewdefault"
// [local]  ILxDropPreviewDefault
#define LXu_DROPSERVICE "44345a07-014c-4deb-aba8-8a3147bba212"
#define LXa_DROPSERVICE "dropservice"
// [python] ILxDropService:Destination  obj Unknown
// [python] ILxDropService:Source       obj Unknown

 #ifdef __cplusplus
  }
 #endif
#endif

