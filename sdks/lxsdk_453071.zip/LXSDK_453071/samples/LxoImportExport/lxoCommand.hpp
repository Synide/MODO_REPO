/*
 * Copyright (c) 2008-2017 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * Build command stream for modo operations/rendering
 */

#pragma once

#include <windows.h>

#include "lxoIoDefs.hpp"
#include <lxpreviewsocket.h>

enum {                                      // constants for command processing
    LXIrradianceCacheSave       = 0,
    LXIrradianceCacheLoad       = 1,

    LXThreads_UseDefault        = -1,       // let modo decide how many threads to use
    LXGeomCache_Default         = 4096,     // default geometry cache, in Mb

    LxRunModo_GUI               = 0,        // flag for LxModoRunMode to run full modo
    LxRunModo_Telnet            = 2,        // flag for LxModoRunMode to use telnet I/O
    LxRunModo_NetPipe           = 4,        // flag for LxModoRunMode to use net pipe I/O
    };

typedef enum                                // modes for running modo
    {
    LxRunModo_Headless          = 1,                                        // run headless using normal local I/O
    LxRunModo_TelnetHeadless    = LxRunModo_Telnet  | LxRunModo_Headless,   // run headless using telnet I/O
    LxRunModo_TelnetGui         = LxRunModo_Telnet  | LxRunModo_GUI,        // run GUI version using normal local I/O
    LxRunModo_NetPipeHeadless   = LxRunModo_NetPipe | LxRunModo_Headless,   // run headless using net pipe I/O
    LxRunModo_NetPipeGui        = LxRunModo_NetPipe | LxRunModo_GUI,        // run GUI version using net pipe I/O
    } LxModoRunMode;

typedef enum                                // constants for command status
    {
    LxCmdResult_Success            = 0,     // status string indicating successful command completion
    LxCmdResult_System,                     // system output, starting with '@'
    LxCmdResult_Log,                        // log output, starting with '!'
    LxCmdResult_Query,                      // query output, starting with ':'
    LxCmdResult_Prompt,                     // command prompt, starting with '>', indicates command complete
    LxCmdResult_Error,                      // status string indicating error in command
    LxCmdResult_Message,                    // arbitrary message string; *may* be error string
    LxCmdResult_Partial,                    // incomplete buffer
    LxCmdResult_Empty,                      // end of buffer
    } LxCmdResult;

enum					    // preview status messages
    {
    PREVIEWERROR_ConnectionClosed   = LXxGOODCODE (0,64),   // Connection gracefully closed
    PREVIEWERROR_Failed             = LXxFAILCODE (0,65),   // SOCKET_ERROR was returned; check WSAGetLastError() for the specific code
    PREVIEWERROR_ProtocolFailure    = LXxFAILCODE (0,66),   // Unexpected value returned from the nexus app over the preview port

    PIPE_MaxNameLen                 = 256,
    };

typedef std::string     LxoCmdList;
typedef std::string     LxoCmdLog;

/*
 * Structure for defining ranges, such as portion of a view
 */
struct LxRange {
        LXtFVector2     min, max;

        LxRange (float minX, float minY, float maxX, float maxY) { min[0] = minX; min[1] = minY; max[0] = maxX; max[1] = maxY; }
        };

/*
 * Structure for setting global rendering preferences
 */
struct LxGlobalRenderPrefs {
        int             m_geomCacheMb;      // number of megabytes to be used for geometry cache
        int             m_nThreads;         // number of threads modo can use; LXThreads_UseDefault to let modo decide
        char const*     m_pluginFile;       // path to optional plugin to be loaded
        bool            m_quitOnError;      // close modo connection error

        LxGlobalRenderPrefs ()
            {
            m_nThreads      = LXThreads_UseDefault;
            m_geomCacheMb   = LXGeomCache_Default;
            m_pluginFile    = NULL;
            m_quitOnError   = false;
            }
        };

class   LxoManager;

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This class is used for preparing commands for modo
 *
 *----------------------------------------------------------------------------*/
class LxoCommand {

    private:
        static char const   CmdMacroHeader[];
        static char const   CmdExecuteMacro[];

        LxoCmdList          m_cmdList;
        bool                m_macroHeaderPresent;
        char                m_outputFile[LXMax_FileLength];
        char                m_outputType[32];
        char                m_polyRenderID[128];

        void        SetBucketDir (const char* bucketDir);           // if NULL, disables writing of bucket files
        void        IrradianceFileIO (const char* filePath, int ioMode);
        void        IrradianceFileSave (const char* filePath)   { IrradianceFileIO (filePath, LXIrradianceCacheSave); }
        void        IrradianceSaveDisable ()                    { SetChannelValue (m_polyRenderID, ArgIrradianceSaveEnable, false); }

    public:
        static char const   CmdSetChannelValue_SSS[];
        static char const   CmdSetGeomCache_I64[];
        static char const   CmdQuitOnDisconnect_I[];
        static char const   CmdSelectRenderSub_S[];
        static char const   CmdSelectNone_SS[];
        static char const   CmdAddPlugin_S[];
        static char const   CmdItemChannel_SS[];
        static char const   CmdResolution_II[];
        static char const   CmdRenderOutAlpha[];
        static char const   CmdCalcIrradiance[];
        static char const   CmdSubitemCamera_S[];

        static char const   CmdSceneOpen_S[];               // open specific LXO scene file

        static char const   CmdBucketDir_S[];               // set directory for bucket files
        static char const   CmdSetThreadsAuto_I[];          // choose whether modo selects the number of threads to use
        static char const   CmdSetThreads_I[];              // specify the number of threads for mooo to use
        static char const   CmdRenderToFile_SSS[];          // do the actual rendering, and write image to file
        static char const   CmdExitModo[];                  // exit modo and terminate process

        static char const   ArgIrradianceSaveEnable[];
        static char const   ArgIrradianceLoadEnable[];
        static char const   ArgIrradianceSaveName[];
        static char const   ArgIrradianceLoadName[];
        static char const   ArgBucketWrite[];

        LxoCommand (const char* outputFile = "", const char* outputType = "", const char* polyRenderId = NULL);
        ~LxoCommand () {}

        /*
         * These methods are made public for specific application needs, but should not generally be needed
         */

        const char* GetOutputFile () { return m_outputFile; }
        const char* GetOutputType () { return m_outputType; }

        LxResult    ReadCommandsFromFile (char const* fileName);
        LxResult    WriteCommandsToFile (char const* fileName);
        LxResult    WriteCommandsToModo (LxoManager* mgr);
        LxResult    ExitModo (LxoManager* mgr);

        void        AddCommand (char const *cmdFormatStr);
        void        AddCommand (char const *cmdFormatStr, __int64 arg);
        void        AddCommand (char const *cmdFormatStr, int arg);
        void        AddCommand (char const *cmdFormatStr, int arg1, int arg2);
        void        AddCommand (char const *cmdFormatStr, char const *arg);
        void        AddCommand (char const *cmdFormatStr, char const *arg1, char const *arg2);
        void        AddCommand (char const *cmdFormatStr, char const *arg1, char const *arg2, char const *arg3);

        void        SetChannelValue (char const *channel, char const *subChannel, char const *valueString);
        void        SetChannelValue (char const *channel, char const *subChannel, bool value);
        void        SetChannelValue (char const *channel, char const *subChannel, int value);
        void        SetChannelValue (char const *channel, char const *subChannel, double value);

        void        DisableOutput (char const *outType)         { SetChannelValue (outType, "enable", false); }

        /*
         * These methods should be used for most modo renderings
         */

        void        Clear () { m_cmdList.clear (); }
        void        SetOutputFile (const char* outputFile, const char* outputType = NULL);
        void        SetPolyRenderId (const char* polyRenderId)  { strcpy (m_polyRenderID, polyRenderId); }
        char const* GetPolyRenderId ()                          { return m_polyRenderID; }

        void        SetGlobalPrefs (LxGlobalRenderPrefs& prefs);

        void        SetCamera (LXtCamera& camera, LxRange* range = NULL);
        void        IrradianceFileLoad (const char* filePath)   { IrradianceFileIO (filePath, LXIrradianceCacheLoad); }
        void        UpdateIrradianceFile (const char* filePath, const char* altBucketDir);
        void        RenderToFile (const char* bucketDir = NULL, bool retainCache = false);
};

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * This class is used for process rendering results
 *
 *----------------------------------------------------------------------------*/
class LxoListener
    {
    private:
        HANDLE          m_isListening;

    public:         // this is the data shared between the threaded listener and the calling application

        LxResult            m_result;
        bool                m_abortFound;
        int                 m_cmdsToWaitFor;

        LxoManager*         m_mgr;                              // manager for this modo run
        char                m_outputFile[LXMax_FileLength];

    public:
        void                Abort () { m_abortFound = true; }
        void                SetOutputFile (char const* filename) { strcpy (m_outputFile, filename); }
        LxResult            WaitForTask (bool lockForNext = false);
        LxResult            BeginListening (LxoManager* mgr);
        static LxULong      ListenerThread (void* listenerP);

        virtual LxResult    Listen ();

        LxoListener ();
        ~LxoListener ();

#if 0
    virtual LxULong         GetInterval ()              { return 10; }
    virtual LxULong         GetBucketSize()             { return 40; }
    virtual LxULong         GetChannelCount ()          { return 3; }
    virtual double          GetDisplayScale ()          { return 1.0; }
    virtual bool            GetDisplayBuckets ()        { return false; }
    virtual bool            GetDisplayIlluminance ()    { return false; }

    virtual float*          GetImage () = 0;
    virtual float*          GetAlpha () = 0;
    virtual LXtVector       GetImageSize () = 0;
    virtual LxResult        DisplayResult (LxResult resultType, LXtVector origin, LXtVector size) = 0;
    virtual void            IndicateProgress (LxResult resultType, double progress, int pass, int nPasses) = 0;
    virtual LxoRenderOutput GetRenderOutput () = 0;
#endif
    };

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * This class is used for generating preview renders from modo. Sends and
 * receives data on the preview socket, and opens and closes the socket.
 *
 *----------------------------------------------------------------------------*/
class LxoPreviewer {

    private:
        SOCKET          m_socket;
        HANDLE          m_pipeH;
        int             m_status;

        LxResult        InitSocket (SOCKADDR_IN& addr);
        LxResult        InitPipe (char const* pipe);
        LxResult        SetProtocol ();

        void            SocketPreviewer (int ipAddr, int port);
        void            PipePreviewer (char const* pipe);

    public:
        LxoPreviewer (char const* pipe, int ipAddr, int port);
        LxoPreviewer (int ipAddr, int port)     { SocketPreviewer (ipAddr, port); }
        LxoPreviewer (char const* pipe)         { PipePreviewer (pipe); }
        ~LxoPreviewer ();

        LxResult        SendData (char const *data, int len);
        LxResult        RecvData (char *data, int len);

        LxResult        SendByte (char data)    { return SendData (&data, sizeof data); }
        LxResult        SendInt  (int data)     { return SendData ((char const*)&data, sizeof data); }
        LxResult        SendFloat (float data)  { return SendData ((char const*)&data, sizeof data); }
        LxResult        RecvInt (int* data)     { return RecvData ((char*)data, sizeof *data); }

        LxResult        SendFloats (float* data, int count) { return SendData ((char const*)data, count * sizeof *data); }

        LxResult        Status ()               { return m_status; }

        LxResult        SetResolution (int x, int y);
        LxResult        SetFormat (int format);
        LxResult        SetSamples (int samples);
        LxResult        SetStereo (bool enabled, bool rightEye);
        LxResult        SetQualityDraft (int samples, float draftFraction);
        LxResult        SetQualityFinal ();
        LxResult        SetQualityExtended (int samples);
        LxResult        SetEffect (char const *effect);
        LxResult        SetMousePos (int x, int y);
        LxResult        SetCamera (LXtFVector pos, LXtFVector dir, float zoom, bool final);
        LxResult        GetFrame (int* responseP, int* widthP, int* heightP, LxByte** imgBufferP);
        LxResult        GetPreviewId (int* id);
        LxResult        GetPreviewProgress (double* fracComplete);
};


/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This class is used for rendering thru modo
 *
 *----------------------------------------------------------------------------*/
class LxoManager {

    private:
        static LxoListener*     m_listener;
        static bool             m_abortFound;
        static void             HandleAbort (int signal) { m_abortFound = true; if (m_listener) m_listener->Abort (); }

        char            m_appFile[LXMax_FileLength];
        char            m_workDir[LXMax_FileLength];            // location for temp files
        char            m_bucketDir[LXMax_FileLength];          // location of bucket files
        char            m_irrBucketDir[LXMax_FileLength];       // location of irradiance bucket files

        char            m_statusBuffer[4096];                   // input buffer may span multiple commands
        char*           m_statusBufferP;
        char            m_altBuffer[4096];                      // for when a line goes past the end of the buffer
        bool            m_dataInAltBuffer;
        LxCmdResult     m_altTokenType;                        // token type of the data that was at the end of the last buffer

        LXtStringVec    m_tempCmdFiles;
        bool            m_firstPromptFound;
        bool            m_isPersistent;
        bool            m_useNetPipe;
        bool            m_useTelnet;
        bool            m_runHeadless;
        bool            m_loggingEnabled;
        LxoCmdLog       m_cmdLog;

        HANDLE          m_modoProcessHandle;
        HANDLE          m_pipeToModo;                   // the end of the modo input pipe that we write to
        HANDLE          m_pipeFromModo;                 // the end of the modo output pipe that we read from

        SOCKET          m_modoSocket;
        LxULong         m_socketPort;
        LxULong         m_socketIpAddr;
        char            m_socketPipe[PIPE_MaxNameLen];

        LxResult        WaitForResult (const char* fileToWaitFor);
        void            TerminateModo ();
        void            DropHandle (HANDLE& handle);
        LxResult        StartModoConnection ();
        LxResult        ExtractResultToken (LxCmdResult& tokenType, char*& tokenString, bool allowPipeRead = true);
        LxResult        ReadInitialPrompts ();

    public:
        /*
         * These methods are made public for use by the LxoCommand class
         */
        LxResult        WriteToModo (char const *buffer, DWORD bytesToWrite);

        LXtStringVec&   GetTempFiles ()                     { return m_tempCmdFiles; }
        void            AddTempFile (char const* fileName)  { m_tempCmdFiles.push_back (std::string (fileName)); }

    public:
        LxoManager (bool isPersistent, char const* luxDirectory = NULL, char const* subDirectory = NULL,
                    LxoListener* listener = NULL, LxModoRunMode runMode = LxRunModo_Headless);
        ~LxoManager ();

        /*
         * Initialization methods 
         */
        void            SetModoSocket (LxULong port, LxULong ipAddr) { m_socketPort = port; m_socketIpAddr = ipAddr; }
        LxResult        SetModoPath (char const *path, char const *pathVar = NULL);

        LxResult        Run (LxoCommand& cmd, bool synchronous = true);     // run commands; always asynchronous if listener used
        LxResult        WaitForResult (int nCommands);                      // only used for asynchronous renders
        LxResult        WaitForModoToExit (bool sendExitCommand = false);   // implicitly called when LxoManager is destroyed

        /*
         * Utility methods 
         */
        char const*     GetWorkDir ()       { return m_workDir; }           // current folder for work files
        char const*     GetBucketDir ()     { return m_bucketDir; }         // current folder for bucket files
        char const*     GetIrrBucketDir ()  { return m_irrBucketDir; }      // current folder for irradiance bucket files
        LxoCmdLog&      GetCommandLog ()    { return m_cmdLog; }            // result messages from last rendering(s)
};

