/*
 * LX customview module
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_customview_H
#define LX_customview_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxCustomPane ** ILxCustomPaneID;
typedef struct vt_ILxCustomView ** ILxCustomViewID;
#include <lxserver.h>
#include <lxvalue.h>

typedef void*    LXtPaneHandleID;

typedef struct vt_ILxCustomPane {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        GetParent) (
                LXtObjectID              self,
                LXtPaneHandleID         *handle );
                LXxMETHOD( LxResult,
        GetIdentifier) (
                LXtObjectID              self,
                const char**             ident );
} ILxCustomPane;
typedef struct vt_ILxCustomView {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Init) (
                LXtObjectID              self,
                LXtObjectID              pane );
                LXxMETHOD(  LxResult,
        Cleanup) (
                LXtObjectID             self,
                LXtObjectID             pane);
                LXxMETHOD(  LxResult,
        StoreState) (
                LXtObjectID              self,
                LXtObjectID              pane );

                LXxMETHOD(  LxResult,
        RestoreState) (
                LXtObjectID              self,
                LXtObjectID              pane );
} ILxCustomView;

#define LXu_CUSTOMPANE                  "7412C685-3ED9-4622-915F-253105012BC4"
#define LXa_CUSTOMPANE                  "custompane"
//[local] ILxCustomPane

#define LXu_CUSTOMVIEW                  "b427f640-821a-48ee-b7ec-f4aafe799695"
#define LXa_CUSTOMVIEW                  "customview"
//[export] ILxCustomView customview
//[local]  ILxCustomView
//[python] type LXtPaneHandleID         id
#define LXsCUSTOMVIEW_TYPE              "CustomViewType"
#define LXsCUSTOMVIEW_EMBEDABILITY      "CustomViewEmbedability"
#define LXsCUSTOMVIEW_OPTIONS_FORM      "CustomViewOptionsForm"

 #ifdef __cplusplus
  }
 #endif
#endif

