#ifndef LX_VERSION_H
#define LX_VERSION_H

#define LXx_INT_STR(i)		#i		// turn an integer into a string
#define LXx_MACRO_STR(a)	LXx_INT_STR(a)	// extra nesting required for turning macro into string

#define LXi_VERSION_BUILD 120147
#define LXi_VERSION_BASE 10
#define LXi_VERSION_MINOR 1
#define LXi_VERSION_SP 2
#define LXi_VERSION_LIB1 1012
#define LXi_VERSION_LIB2 0
#define LXi_VERSION_LIB3 12
#define LXi_VERSION_LIB4 147
#define LXs_VERSION_LIB "1012.0.12.147"
#define LXs_VERSION_PRODUCT "10.1v2"
#define LXs_VERSION_NAME "nexus 10"
#define LXs_VERSION_DESC "nexus 10 by The Foundry"
#define LXs_VERSION_MAKER "The Foundry Group LLC"
#define LXs_VERSION_FNBUILD "10.1v2.120147"
#define LXi_VERSION_YEAR 2016
#define LXs_VERSION_YEAR "2016"
#define LXi_VERSION_MONTH 7
#define LXs_VERSION_MONTH "7"
#define LXi_VERSION_DAY 15
#define LXs_VERSION_DAY "15"
#define LXi_VERSION_LICENSEDATE_MAJOR 2016
#define LXi_VERSION_LICENSEDATE_MINOR 715
#define LXs_VERSION_TIME "06:40:48"

#endif


