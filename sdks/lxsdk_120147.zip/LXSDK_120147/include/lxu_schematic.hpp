/*
 * Plug-in SDK Header: C++ Services
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Helper classes for implementing texture servers.
 */
#ifndef LXU_SCHEMATIC_HPP
#define LXU_SCHEMATIC_HPP

#include <lx_schematic.hpp>
#include <lx_item.hpp>
#include <lxu_meta.hpp>


/*
 * -------------------------------------
 * Meta Schematic Connection
 *
 * The superclass supports basic behaviors and some customization.
 */
class CLxSchematicConnection :
                public CLxObject
{
    public:
         CLxSchematicConnection ();
        ~CLxSchematicConnection ();

        /*
         * This is called to test an item to see if it should have a connection
         * point. The client function should call set_single() or set_multiple()
         * add a connection. If neither function is called the item has no
         * connection.
         */
        virtual void	test_item (CLxUser_Item &) {}
        void		set_single ();
        void		set_multiple (bool ordered = false);

        /*
         * This is called to test if an incoming connection matches the
         * destination. By default all items can be connected.
         */
        virtual bool	allow (CLxUser_Item &from, CLxUser_Item &to) { return true; }

        /*
         * If a schematic connection is being managed manually (either because
         * there is no graph or because 'manual' was true) then get_list() is
         * called to get the list of connected items. Add them with add_item().
         */
        virtual void	get_list (CLxUser_Item &) {}
        void		add_item (CLxUser_Item &);

        /*
         * For manual connections these methods are also required to add and
         * remove the schematic connection.
         */
        virtual void	connect    (CLxUser_Item &from, CLxUser_Item &to, int toIndex) {}
        virtual void	disconnect (CLxUser_Item &from, CLxUser_Item &to) {}

        class pv_SchematicConnection	*pv;
};

/*
 * Core metaclass sets global properties.
 */
class CLxMeta_SchematicConnection_Core :
                public CLxMetaServer
{
    public:
         CLxMeta_SchematicConnection_Core (const char *srvName);
        ~CLxMeta_SchematicConnection_Core ();

        virtual CLxSchematicConnection *	 new_inst () = 0;

        void *		alloc () LXx_OVERRIDE;

        /*
         * Set the name of the graph for normal, graph-based connections. 'reverse'
         * can be true to invert the sense of the link, and 'manual' can also be
         * set for manual control of the links.
         */
        void		set_graph (const char *, bool reverse = false, bool manual = false);

        /*
         * If the connection point is to be the same on all items of a given
         * type, this can be called to set the item type and type of connection.
         */
        void		set_itemtype (const char *, bool multiple = false, bool ordered = false);

        /*
         * By default the connections on items are static so each item is tested
         * only once. This method sets the connection type to dynamic so that the
         * settings will be refreshed when changes happen. The invalidate()
         * method should be called on any event that might change the connections.
         */
        void		set_dynamic ();
        void		invalidate ();

        class pv_Meta_SchematicConnection	*pv;
};

/*
 * Template for server metaclass.
 */
template <class T>
class CLxMeta_SchematicConnection :
                public CLxMeta_SchematicConnection_Core
{
    public:
        CLxMeta_SchematicConnection (const char *srvName) : CLxMeta_SchematicConnection_Core (srvName) { }

                CLxSchematicConnection *
        new_inst ()
        {
                return new T;
        }
};


#endif // LXU_SCHEMATIC_HPP

