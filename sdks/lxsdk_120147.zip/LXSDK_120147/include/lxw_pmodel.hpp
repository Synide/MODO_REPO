/*
 * C++ wrapper for lxpmodel.h
 *
 *	Copyright (c) 2008-2015 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 *
 */
#ifndef LXW_PMODEL_HPP
#define LXW_PMODEL_HPP

#include <lxpmodel.h>
#include <lx_wrap.hpp>
#include <string>

namespace lx {
    static const LXtGUID guid_SelectionOperation = {0x563E56B1,0xACC9,0x4E3F,0xB3,0xA8,0xE0,0xAF,0xE2,0xAB,0x56,0x45};
};

class CLxImpl_SelectionOperation {
  public:
    virtual ~CLxImpl_SelectionOperation() {}
    virtual LxResult
      selop_SetMesh (ILxUnknownID mesh)
        { return LXe_NOTIMPL; }
    virtual LxResult
      selop_SetTransform (LXtMatrix4 xfrm)
        { return LXe_NOTIMPL; }
    virtual LxResult
      selop_TestPoint (LXtPointID point)
        { return LXe_NOTIMPL; }
    virtual LxResult
      selop_TestEdge (LXtEdgeID edge)
        { return LXe_NOTIMPL; }
    virtual LxResult
      selop_TestPolygon (LXtPolygonID polygon)
        { return LXe_NOTIMPL; }
};
#define LXxD_SelectionOperation_SetMesh LxResult selop_SetMesh (ILxUnknownID mesh)
#define LXxO_SelectionOperation_SetMesh LXxD_SelectionOperation_SetMesh LXx_OVERRIDE
#define LXxD_SelectionOperation_SetTransform LxResult selop_SetTransform (LXtMatrix4 xfrm)
#define LXxO_SelectionOperation_SetTransform LXxD_SelectionOperation_SetTransform LXx_OVERRIDE
#define LXxD_SelectionOperation_TestPoint LxResult selop_TestPoint (LXtPointID point)
#define LXxO_SelectionOperation_TestPoint LXxD_SelectionOperation_TestPoint LXx_OVERRIDE
#define LXxD_SelectionOperation_TestEdge LxResult selop_TestEdge (LXtEdgeID edge)
#define LXxO_SelectionOperation_TestEdge LXxD_SelectionOperation_TestEdge LXx_OVERRIDE
#define LXxD_SelectionOperation_TestPolygon LxResult selop_TestPolygon (LXtPolygonID polygon)
#define LXxO_SelectionOperation_TestPolygon LXxD_SelectionOperation_TestPolygon LXx_OVERRIDE
template <class T>
class CLxIfc_SelectionOperation : public CLxInterface
{
    static LxResult
  SetMesh (LXtObjectID wcom, LXtObjectID mesh)
  {
    LXCWxINST (CLxImpl_SelectionOperation, loc);
    try {
      return loc->selop_SetMesh ((ILxUnknownID)mesh);
    } catch (LxResult rc) { return rc; }
  }
    static LxResult
  SetTransform (LXtObjectID wcom, LXtMatrix4 xfrm)
  {
    LXCWxINST (CLxImpl_SelectionOperation, loc);
    try {
      return loc->selop_SetTransform (xfrm);
    } catch (LxResult rc) { return rc; }
  }
    static LxResult
  TestPoint (LXtObjectID wcom, LXtPointID point)
  {
    LXCWxINST (CLxImpl_SelectionOperation, loc);
    try {
      return loc->selop_TestPoint (point);
    } catch (LxResult rc) { return rc; }
  }
    static LxResult
  TestEdge (LXtObjectID wcom, LXtEdgeID edge)
  {
    LXCWxINST (CLxImpl_SelectionOperation, loc);
    try {
      return loc->selop_TestEdge (edge);
    } catch (LxResult rc) { return rc; }
  }
    static LxResult
  TestPolygon (LXtObjectID wcom, LXtPolygonID polygon)
  {
    LXCWxINST (CLxImpl_SelectionOperation, loc);
    try {
      return loc->selop_TestPolygon (polygon);
    } catch (LxResult rc) { return rc; }
  }
  ILxSelectionOperation vt;
public:
  CLxIfc_SelectionOperation ()
  {
    vt.SetMesh = SetMesh;
    vt.SetTransform = SetTransform;
    vt.TestPoint = TestPoint;
    vt.TestEdge = TestEdge;
    vt.TestPolygon = TestPolygon;
    vTable = &vt.iunk;
    iid = &lx::guid_SelectionOperation;
  }
};
class CLxLoc_SelectionOperation : public CLxLocalize<ILxSelectionOperationID>
{
public:
  void _init() {m_loc=0;}
  CLxLoc_SelectionOperation() {_init();}
  CLxLoc_SelectionOperation(ILxUnknownID obj) {_init();set(obj);}
  CLxLoc_SelectionOperation(const CLxLoc_SelectionOperation &other) {_init();set(other.m_loc);}
  const LXtGUID * guid() const {return &lx::guid_SelectionOperation;}
    LxResult
  SetMesh (ILxUnknownID mesh)
  {
    return m_loc[0]->SetMesh (m_loc,(ILxUnknownID)mesh);
  }
    LxResult
  SetTransform (LXtMatrix4 xfrm)
  {
    return m_loc[0]->SetTransform (m_loc,xfrm);
  }
    LxResult
  TestPoint (LXtPointID point)
  {
    return m_loc[0]->TestPoint (m_loc,point);
  }
    LxResult
  TestEdge (LXtEdgeID edge)
  {
    return m_loc[0]->TestEdge (m_loc,edge);
  }
    LxResult
  TestPolygon (LXtPolygonID polygon)
  {
    return m_loc[0]->TestPolygon (m_loc,polygon);
  }
};

#endif

