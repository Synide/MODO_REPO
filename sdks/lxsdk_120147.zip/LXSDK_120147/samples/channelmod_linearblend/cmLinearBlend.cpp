/*
 * Plug-in linear blend channel modifier.
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include <lx_plugin.hpp>
#include <lx_value.hpp>
#include <lxu_chanmod.hpp>


        namespace LinearBlend {

static LXtTextValueHint		 hint_blend[] = {
        0,		"%min",		// float min 0.0
        10000,		"%max",		// float max 1.0
        -1,		 NULL
};

class COperator :
                public CLxChannelModifier
{
    public:
        CLxUser_Value		 v_1, v_2, v_blend, v_output;

                void
        init_chan (
                CLxAttributeDesc	&desc)		LXx_OVERRIDE
        {
                COperator		*op = 0;

                desc.add ("inputA", LXsTYPE_FLOAT);
                desc.chanmod_chan (LXfCHMOD_INPUT, &op->v_1);

                desc.add ("inputB", LXsTYPE_FLOAT);
                desc.chanmod_chan (LXfCHMOD_INPUT, &op->v_2);

                desc.add ("blend", LXsTYPE_PERCENT);
                desc.chanmod_chan (LXfCHMOD_INPUT, &op->v_blend);
                desc.hint (hint_blend);

                desc.add ("output", LXsTYPE_FLOAT);
                desc.chanmod_chan (LXfCHMOD_OUTPUT, &op->v_output);
        }

                void
        eval ()						LXx_OVERRIDE
        {
                double		 v1, v2, blend, output;

                v_1.GetFlt     (&v1);
                v_2.GetFlt     (&v2);
                v_blend.GetFlt (&blend);

                output = v1 + LXxCLAMP (blend, 0.0, 1.0) * (v2 - v1);

                v_output.SetFlt (output);
        }
};

static CLxMetaRoot_ChannelModifier<COperator>	 meta ("cmLinearBlend");

        };	// end namespace


        void
initialize ()
{
        LinearBlend::meta.initialize ();
}

