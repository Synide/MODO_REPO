/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_LIGHT_H
#define CIO_LIGHT_H

#include "cio_element.h"
#include "cio_strings.h"

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Light.
 */

class AmbientLightElement;
class DirectionalLightElement;
class PointLightElement;
class SpotlightElement;

class LightElement_modo401;
class AreaLightElement_modo401;
class CylinderLightElement_modo401;
class DomeLightElement_modo401;
class PhotometricLightElement_modo401;
class PointLightElement_modo401;
class SpotlightElement_modo401;
class SunlightElement_modo401;

class LightLibraryElement;

class LightElement : public Element
{
        friend class AmbientLightElement;
        friend class PointLightElement;
        friend class SpotlightElement;
        friend class DirectionalLightElement;

        friend class LightElement_modo401;
        friend class AreaLightElement_modo401;
        friend class CylinderLightElement_modo401;
        friend class DomeLightElement_modo401;
        friend class PhotometricLightElement_modo401;
        friend class PointLightElement_modo401;
        friend class SpotlightElement_modo401;
        friend class SunlightElement_modo401;

    public:
                                 LightElement (
                                        LightLibraryElement	&library,
                                        const std::string	&id,
                                        const std::string	&name);
                                 LightElement (
                                        LightLibraryElement	&library);
        virtual			~LightElement ();

        bool			 IsAmbient () const;
        bool			 LinkAmbientLight (
                                        AmbientLightElement &light);

        bool			 IsDirectional () const;
        bool			 LinkDirectionalLight (
                                        DirectionalLightElement &light);

        bool			 IsPoint () const;
        bool			 LinkPointLight (
                                        PointLightElement &light);

        bool			 IsSpot () const;
        bool			 LinkSpotLight (
                                        SpotlightElement &light);

        bool			 LinkTechniqueProfile_modo401 (
                                        LightElement_modo401 &light);

    protected:
        virtual void		 LinkColor ();

        void			 AddTechniqueProfile_modo401 (
                                        LightElement_modo401 &light);

        struct pv_LightElement * LightElementPV () const;

    private:
        struct pv_LightElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Ambient Light.
 */
class AmbientLightElement : public LightElement
{
        friend class LightElement;

    public:
                                 AmbientLightElement (
                                        LightLibraryElement	&library,
                                        const std::string	&id,
                                        const std::string	&name);
                                 AmbientLightElement (
                                        LightLibraryElement	&library);
        virtual			~AmbientLightElement ();

        bool			 GetColor (ColorRGB &color);
        void			 SetColor (const ColorRGB &color);

    protected:
        virtual void		 LinkColor ();

    private:
        struct pv_AmbientLightElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Point Light.
 */
class PointLightElement : public LightElement
{
        friend class LightElement;
        friend class PointLightElement_modo401;

    public:
                                 PointLightElement (
                                        LightLibraryElement	&library,
                                        const std::string	&id,
                                        const std::string	&name);
                                 PointLightElement (
                                        LightLibraryElement	&library);
        virtual			~PointLightElement ();

        bool			 GetColor (ColorRGB &color);
        void			 SetColor (const ColorRGB &color);

        bool			 GetConstantAttenuation (double &attenuation);
        void			 SetConstantAttenuation (double attenuation);

        bool			 GetLinearAttenuation (double &attenuation);
        void			 SetLinearAttenuation (double attenuation);

        bool			 GetQuadraticAttenuation (double &attenuation);
        void			 SetQuadraticAttenuation (double attenuation);

        bool			 GetZFar (double &zfar);
        void			 SetZFar (double zfar);

    protected:
        virtual void		 LinkColor ();

    private:
        struct pv_PointLightElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Spotlight.
 */
class SpotlightElement : public LightElement
{
        friend class LightElement;
        friend class SpotlightElement_modo401;

    public:
                                 SpotlightElement (
                                        LightLibraryElement	&library,
                                        const std::string	&id,
                                        const std::string	&name);
                                 SpotlightElement (
                                        LightLibraryElement	&library);
        virtual			~SpotlightElement ();

        bool			 GetColor (ColorRGB &color);
        void			 SetColor (const ColorRGB &color);

        bool			 GetConstantAttenuation (double &attenuation);
        void			 SetConstantAttenuation (double attenuation);

        bool			 GetLinearAttenuation (double &attenuation);
        void			 SetLinearAttenuation (double attenuation);

        bool			 GetQuadraticAttenuation (double &attenuation);
        void			 SetQuadraticAttenuation (double attenuation);

        bool			 GetFalloffAngle (double &angle);
        void			 SetFalloffAngle (double angle);

        bool			 GetFalloffExponent (double &exponent);
        void			 SetFalloffExponent (double exponent);

    protected:
        virtual void		 LinkColor ();

    private:
        struct pv_SpotlightElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Directional Light.
 */
class DirectionalLightElement : public LightElement
{
        friend class LightElement;
        friend class SunlightElement_modo401;

    public:
                                 DirectionalLightElement (
                                        LightLibraryElement	&library,
                                        const std::string	&id,
                                        const std::string	&name);
                                 DirectionalLightElement (
                                        LightLibraryElement	&library);
        virtual			~DirectionalLightElement ();

        bool			 GetColor (ColorRGB &color);
        void			 SetColor (const ColorRGB &color);

    protected:
        virtual void		 LinkColor ();

    private:
        struct pv_DirectionalLightElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Light Technique Profile modo 401.
 */
class LightElement_modo401 : public Element
{
        friend class AreaLightElement_modo401;
        friend class CylinderLightElement_modo401;
        friend class DomeLightElement_modo401;
        friend class PhotometricLightElement_modo401;
        friend class PointLightElement_modo401;
        friend class SpotlightElement_modo401;
        friend class SunlightElement_modo401;

    public:
                                 LightElement_modo401 (
                                        LightElement &light);
        virtual			~LightElement_modo401 ();

        /*
         * See PARAMVALUE_MODO_LIGHT_TYPE_
         */
        bool			 GetLightType (std::string &lightType);

        /*
         * Common channelized locator parameters that can be
         * targeted for animation.
         */
 
        bool			 GetRender (std::string &render);
        void			 SetRender (const std::string &render);

        bool			 GetDisplayVisible (std::string &render);
        void			 SetDisplayVisible (const std::string &render);

        bool			 GetDisplaySize (double &size);
        void			 SetDisplaySize (double size);

        bool			 GetDissolve (double &dissolve);
 	void			 SetDissolve (double dissolve);

        /*
         * Common light settings, used for all light sub-types.
         */
        bool			 GetRadiance (double &radiance);
        void			 SetRadiance (double radiance);

        bool			 GetSamples (unsigned &samples);
        void			 SetSamples (unsigned samples);

        bool			 GetShadowType (std::string &shadowType);
        void			 SetShadowType (const std::string shadowType);

        bool			 GetShadowResolution (unsigned &resolution);
        void			 SetShadowResolution (unsigned resolution);

    private:
        struct pv_LightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Area Light Technique Profile modo 401.
 */
class AreaLightElement_modo401 : public LightElement_modo401
{
    public:
                                 AreaLightElement_modo401 (
                                        PointLightElement &light);
        virtual			~AreaLightElement_modo401 ();

        bool			 GetTargetEnable (bool &enabled);
        void			 SetTargetEnable (bool enabled);

        /*
         * URI fragment ID to linked node.
         */
        bool			 GetTargetNodeID (std::string &nodeID);
        void			 SetTargetNodeID (const std::string &nodeID);

        bool			 GetTargetRoll (double &degrees);
        void			 SetTargetRoll (double degrees);

        bool			 GetWidth (double &width);
        void			 SetWidth (double width);

        bool			 GetHeight (double &height);
        void			 SetHeight (double height);
 
        /*
         * See PARAMVALUE_MODO_AREALIGHT_SHAPE_
         */
        bool			 GetShape (std::string &shape);
        void			 SetShape (const std::string &shape);

    private:
        struct pv_AreaLightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Cylinder Light Technique Profile modo 401.
 */
class CylinderLightElement_modo401 : public LightElement_modo401
{
    public:
                                 CylinderLightElement_modo401 (
                                        PointLightElement &light);
        virtual			~CylinderLightElement_modo401 ();

        bool			 GetTargetEnable (bool &enabled);
        void			 SetTargetEnable (bool enabled);

        /*
         * URI fragment ID to linked node.
         */
        bool			 GetTargetNodeID (std::string &nodeID);
        void			 SetTargetNodeID (const std::string &nodeID);

        bool			 GetTargetRoll (double &degrees);
        void			 SetTargetRoll (double degrees);

        bool			 GetLength (double &length);
        void			 SetLength (double length);

        bool			 GetRadius (double &radius);
        void			 SetRadius (double radius);

    private:
        struct pv_CylinderLightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Dome Light Technique Profile modo 401.
 */
class DomeLightElement_modo401 : public LightElement_modo401
{
    public:
                                 DomeLightElement_modo401 (
                                        PointLightElement &light);
        virtual			~DomeLightElement_modo401 ();

        bool			 GetRadius (double &radius);
        void			 SetRadius (double radius);

    private:
        struct pv_DomeLightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Photometric Light Technique Profile modo 401.
 */
class PhotometricLightElement_modo401 : public LightElement_modo401
{
    public:
                                 PhotometricLightElement_modo401 (
                                        SpotlightElement &light);
        virtual			~PhotometricLightElement_modo401 ();

        bool			 GetTargetEnable (bool &enabled);
        void			 SetTargetEnable (bool enabled);

        /*
         * URI fragment ID to linked node.
         */
        bool			 GetTargetNodeID (std::string &nodeID);
        void			 SetTargetNodeID (const std::string &nodeID);

        bool			 GetTargetRoll (double &degrees);
        void			 SetTargetRoll (double degrees);

        bool			 GetConeAngle (double &angle);
        void			 SetConeAngle (double angle);

        bool			 GetSoftEdgeAngle (double &angle);
        void			 SetSoftEdgeAngle (double angle);

        bool			 GetWidth (double &width);
        void			 SetWidth (double width);

        bool			 GetHeight (double &height);
        void			 SetHeight (double height);

        bool			 GetOutside (bool &outside);
        void			 SetOutside (bool outside);

        bool			 GetVolumetrics (bool &volumetrics);
        void			 SetVolumetrics (bool volumetrics);

        bool			 GetVolumetricDissolve (double &dissolve);
        void			 SetVolumetricDissolve (double dissolve);

        bool			 GetVolumetricSamples (unsigned &samples);
        void			 SetVolumetricSamples (unsigned samples);

        bool			 GetVolumetricRadius (double &radius);
        void			 SetVolumetricRadius (double radius);

    private:
        struct pv_PhotometricLightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Point Light Technique Profile modo 401.
 */
class PointLightElement_modo401 : public LightElement_modo401
{
    public:
                                 PointLightElement_modo401 (
                                        PointLightElement &light);
        virtual			~PointLightElement_modo401 ();

        bool			 GetRadius (double &radius);
        void			 SetRadius (double radius);

        bool			 GetVolumetrics (bool &volumetrics);
        void			 SetVolumetrics (bool volumetrics);

        bool			 GetVolumetricDissolve (double &dissolve);
        void			 SetVolumetricDissolve (double dissolve);

        bool			 GetVolumetricSamples (unsigned &samples);
        void			 SetVolumetricSamples (unsigned samples);

        bool			 GetVolumetricRadius (double &radius);
        void			 SetVolumetricRadius (double radius);

    private:
        struct pv_PointLightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Spot Light Technique Profile modo 401.
 */
class SpotlightElement_modo401 : public LightElement_modo401
{
    public:
                                 SpotlightElement_modo401 (
                                        SpotlightElement &light);
        virtual			~SpotlightElement_modo401 ();

        bool			 GetTargetEnable (bool &enabled);
        void			 SetTargetEnable (bool enabled);

        /*
         * URI fragment ID to linked node.
         */
        bool			 GetTargetNodeID (std::string &nodeID);
        void			 SetTargetNodeID (const std::string &nodeID);

        bool			 GetTargetRoll (double &degrees);
        void			 SetTargetRoll (double degrees);

        bool			 GetConeAngle (double &angle);
        void			 SetConeAngle (double angle);

        bool			 GetSoftEdgeAngle (double &angle);
        void			 SetSoftEdgeAngle (double angle);

        bool			 GetOutside (bool &outside);
        void			 SetOutside (bool outside);

        bool			 GetRadius (double &radius);
        void			 SetRadius (double radius);

        bool			 GetVolumetrics (bool &volumetrics);
        void			 SetVolumetrics (bool volumetrics);

        bool			 GetVolumetricDissolve (double &dissolve);
        void			 SetVolumetricDissolve (double dissolve);

        bool			 GetVolumetricSamples (unsigned &samples);
        void			 SetVolumetricSamples (unsigned samples);

    private:
        struct pv_SpotlightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Sunlight Technique Profile modo 401.
 */
class SunlightElement_modo401 : public LightElement_modo401
{
    public:
                                 SunlightElement_modo401 (
                                        DirectionalLightElement &light);
        virtual			~SunlightElement_modo401 ();

        bool			 GetTargetEnable (bool &enabled);
        void			 SetTargetEnable (bool enabled);

        /*
         * URI fragment ID to linked node.
         */
        bool			 GetTargetNodeID (std::string &nodeID);
        void			 SetTargetNodeID (const std::string &nodeID);

        bool			 GetTargetRoll (double &degrees);
        void			 SetTargetRoll (double degrees);

        bool			 GetAzimuth (double &angle);
        void			 SetAzimuth (double angle);

        bool			 GetClampIntensity (bool &clamp);
        void			 SetClampIntensity (bool clamp);

        bool			 GetDay (unsigned &day);
        void			 SetDay (unsigned day);

        bool			 GetElevation (double &elevation);
        void			 SetElevation (double elevation);

        bool			 GetHaze (double &haze);
        void			 SetHaze (double haze);

        bool			 GetHeight (double &height);
        void			 SetHeight (double height);

        bool			 GetLatitude (double &latitude);
        void			 SetLatitude (double latitude);

        bool			 GetLongitude (double &longitude);
        void			 SetLongitude (double longitude);

        bool			 GetMapSize (double &mapSize);
        void			 SetMapSize (double mapSize);

        bool			 GetNorth (double &north);
        void			 SetNorth (double north);

        bool			 GetRadius (double &radius);
        void			 SetRadius (double radius);

        bool			 GetSpread (double &spread);
        void			 SetSpread (double spread);

        bool			 GetSunPosition (bool &position);
        void			 SetSunPosition (bool position);

        bool			 GetTime (double &time);
        void			 SetTime (double time);

        bool			 GetTimeZone (double &zone);
        void			 SetTimeZone (double zone);

        bool			 GetVolumetrics (bool &volumetrics);
        void			 SetVolumetrics (bool volumetrics);

        bool			 GetVolumetricDissolve (double &dissolve);
        void			 SetVolumetricDissolve (double dissolve);

        bool			 GetVolumetricSamples (unsigned &samples);
        void			 SetVolumetricSamples (unsigned samples);

    private:
        struct pv_SunlightElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Light library.
 */
 
class COLLADAElement;

class LightLibraryElement : public Element
{
        friend class LightElement;

    public:
                                 LightLibraryElement (
                                         COLLADAElement &collada);
        virtual			~LightLibraryElement ();

        bool			 HasLight () const;
        bool			 LinkLight (
                                        const std::string	&lightID,
                                        LightElement		&light);

    protected:
        void			 AddLight (LightElement &light);
};

} // namespace cio

#endif // CIO_LIGHT_H

