/*
 * Command: loaderOptions.wf_OBJ
 *
 *  Copyright (c) 2008-2015 The Foundry Group LLC
 *  
 *  Permission is hereby granted, free of charge, to any person obtaining a
 *  copy of this software and associated documentation files (the "Software"),
 *  to deal in the Software without restriction, including without limitation
 *  the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *  and/or sell copies of the Software, and to permit persons to whom the
 *  Software is furnished to do so, subject to the following conditions:
 *  
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.   Except as contained
 *  in this notice, the name(s) of the above copyright holders shall not be
 *  used in advertising or otherwise to promote the sale, use or other dealings
 *  in this Software without prior written authorization.
 *  
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *  DEALINGS IN THE SOFTWARE.
 */
#include <lxu_command.hpp>
#include <lx_io.hpp>
#include <stdio.h>
#include <string>

#include "objio.hpp"


static LXtTextValueHint	 unitsType_hints[] = {
        { 0,	"meters" },
        { 1,	"centimeters" },
        { 2,	"millimeters" },
        { 3,	"inches" },
        { 0,	NULL }
};



        namespace OBJ_Options {

class CCommand :
                public CLxBasicCommand
{
    public:
        CCommand ();

        int		basic_CmdFlags	() LXx_OVERRIDE;
        void	cmd_Execute	(unsigned int flags) LXx_OVERRIDE;
        LxResult	cmd_ArgEnable (unsigned int arg);

        private:
        unsigned int	m_argIgnoreKa;
        unsigned int	m_argAsStatic;
        unsigned int	m_argGroupsAsSeparateMeshes;
        unsigned int	m_argUnits;
};


/*
 * We need factories for all the exported objects that are not servers.
 * Since the polymorph object has to exist for the lifetime of any instance,
 * they are explicitly allocated as part of the module global data and freed
 * at shutdown.
 */
static class CFactories {
    public:
        CLxPolymorph<CLoadOptions>	 opt;

        CFactories ()
        {
                opt.AddInterface (new CLxIfc_StreamIO<CLoadOptions>);
        }
} *pF;



CCommand::CCommand ()
{
        unsigned int index = 0;
        m_argIgnoreKa = index++;
        dyna_Add ("ignoreKa", LXsTYPE_BOOLEAN);
        m_argAsStatic = index++;
        dyna_Add ("asStatic", LXsTYPE_BOOLEAN);
        m_argGroupsAsSeparateMeshes = index++;
        dyna_Add ("groupsAsSeparateMeshes", LXsTYPE_BOOLEAN);
        m_argUnits = index++;
        dyna_Add ("OBJUnits", LXsTYPE_INTEGER);
        dyna_SetHint (m_argUnits, unitsType_hints);
}

        int
CCommand::basic_CmdFlags ()
{
        return LXfCMD_UI;
}


        void
CCommand::cmd_Execute (
        unsigned int		 flags)
{
        CLxUser_IOService	 ios;
        CLoadOptions		*opt;
        ILxUnknownID		 obj;
        LxResult		 rc;

        obj = pF->opt.Spawn ();
        opt = pF->opt.Cast (obj);

        rc  = attr_GetBool (0, &opt->ignore_ka);
        rc  = attr_GetBool (1, &opt->as_static);
        rc  = attr_GetBool (2, &opt->groups_as_separate_meshes);
        rc  = attr_GetInt  (3, &opt->unitsType);
        LXxUNUSED (rc);

        ios.SetOptions (obj);
        lx::ObjRelease (obj);
}

        LxResult
CCommand::cmd_ArgEnable(unsigned int arg)
{
        /*
          In the current implementation, if 'Import as a Static Mesh' is selected, only one mesh will
          be created, meaning 'Import groups as separate meshes' has no effect.  So if one option is
          selected, disable the other.
         */
        bool enabled;
        if( m_argAsStatic == arg ) {
                attr_GetBool( m_argGroupsAsSeparateMeshes, &enabled );
                return enabled ? LXe_CMD_DISABLED : LXe_OK;
        }
        else if( m_argGroupsAsSeparateMeshes == arg ) {
                attr_GetBool( m_argAsStatic, &enabled );
                return enabled ? LXe_CMD_DISABLED : LXe_OK;
        }
        else {
                return LXe_OK;
        }
}

        CLoadOptions *
GetOptions ()
{
        CLxUser_IOService	 ios;
        ILxUnknownID		 obj;

        obj = ios.PeekOptions ();
        if (!obj)
                return 0;

        return pF->opt.Cast (obj);
}

        void
SpawnOptions (
        void		       **ppvObj)
{
        if (!pF->opt.Alloc (ppvObj))
                throw (LXe_FAILED);
}


#define OPTf_AS_STATIC				0x01
#define OPTf_GROUPS_AS_SEPARATE_MESHES		0x02
#define OPTf_UNITS_TYPE				0x04
#define OPTf_IGNORE_KA				0x08

#define OPT_VER_0_0						0			// old version (no units type)
#define OPT_VER_1_0						1			// version with added units type

#define FAIL_EX(f)	rc = f; if (LXx_FAIL (rc)) throw (rc)

        LxResult
CLoadOptions::io_Write (
        ILxUnknownID		 stream)
{
        CLxUser_BlockWrite	 blk (stream);
        unsigned		 u4;
        LxResult		 rc;

        u4 = OPT_VER_1_0;
        FAIL_EX (blk.WriteU4 (&u4, 1));

        u4 = 0;
        if (as_static)
                u4 |= OPTf_AS_STATIC;

        if (groups_as_separate_meshes)
                u4 |= OPTf_GROUPS_AS_SEPARATE_MESHES;

        if (unitsType)
                u4 |= OPTf_UNITS_TYPE;

        if (ignore_ka)
                u4 |= OPTf_IGNORE_KA;

        FAIL_EX (blk.WriteU4 (&u4, 1));	// flags

        return LXe_OK;
}

        LxResult
CLoadOptions::io_Read (
        ILxUnknownID		 stream)
{
        CLxUser_BlockRead	 blk (stream);
        unsigned		 u4[2];
        int			 count;
        LxResult		 rc;

        FAIL_EX (blk.ReadU4 (u4, 2, &count));

        // Check version
        if (u4[0] > OPT_VER_1_0)
                return LXe_NOTFOUND;

        as_static = (u4[1] & OPTf_AS_STATIC) ? true : false;

        groups_as_separate_meshes = (u4[1] & OPTf_GROUPS_AS_SEPARATE_MESHES) ? true : false;

        ignore_ka = (u4[1] & OPTf_IGNORE_KA) ? true : false;

        if (u4[0] == 1)
                unitsType = (u4[1] & OPTf_UNITS_TYPE);
        else
                unitsType = UNITS_M;

        return LXe_OK;
}


/*
 * Setup our command as a server. It has a command interface, an attributes
 * interface for arguments, and an attributesUI interface.
 */
        void
initialize ()
{
        CLxGenericPolymorph	*srv;

        srv = new CLxPolymorph<CCommand>;
        srv->AddInterface (new CLxIfc_Command     <CCommand>);
        srv->AddInterface (new CLxIfc_Attributes  <CCommand>);
        srv->AddInterface (new CLxIfc_AttributesUI<CCommand>);
        lx::AddServer ("loaderOptions.wf_OBJ", srv);

        pF = new CFactories;
}

        void
cleanup ()
{
        delete pF;
}


        };	// END namespace

