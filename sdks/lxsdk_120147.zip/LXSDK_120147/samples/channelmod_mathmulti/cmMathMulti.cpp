/*
 * Plug-in channel modifiers for various math operations.
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include <lx_plugin.hpp>
#include <lx_value.hpp>
#include <lx_listener.hpp>
#include <lxu_chanmod.hpp>

using namespace lx_err;


        namespace MathMulti {

#define SRVNAME_PACKAGE		"cmMathMulti"

#define OPi_ADD			 0
#define OPi_SUBTRACT		 1
#define OPi_MULTIPLY		 2
#define OPi_DIVIDE		 3
#define OPi_AVERAGE		 4
#define OPi_MIN			 5
#define OPi_MAX			 6

static LXtTextValueHint hint_op[] = {
        OPi_ADD,		"add",
        OPi_SUBTRACT,		"sub",
        OPi_MULTIPLY,		"mul",
        OPi_DIVIDE,		"div",
        OPi_AVERAGE,		"avg",
        OPi_MIN,		"min",
        OPi_MAX,		"max",
        -1,			 NULL
};

/*
 * ----------------------------------------------------------------
 * The operator is the core of the channel modifier. It both sets up the
 * channels for the modifier and serves as the object to hold onto value
 * interfaces.
 */
class COperator :
                public CLxChannelModifier
{
    public:
        CLxUser_Value		 v_op, v_result;
        CLxUser_ValueArray	 a_inputs;

        /*
         * Channel setup is done once when the plug-in is loaded.
         * The "operation" channel is an int choice that the system will
         * automatically recognize as something that can spread into
         * multiple entries in the "Add" popup. The "inputs" channel is
         * a multilink channel that is associated with a ValueArray so
         * we can read individual inputs.
         */
                void
        init_chan (
                CLxAttributeDesc	&desc)		LXx_OVERRIDE
        {
                COperator		*op = 0;

                desc.add ("operation", LXsTYPE_INTEGER);
                desc.chanmod_chan (0, &op->v_op);
                desc.hint (hint_op);

                desc.add ("inputs", LXsTYPE_FLOAT);
                desc.chanmod_chan (LXfCHMOD_INPUT | LXfCHMOD_MULTILINK, &op->a_inputs);

                desc.add ("result", LXsTYPE_FLOAT);
                desc.chanmod_chan (LXfCHMOD_OUTPUT, &op->v_result);
        }

        /*
         * Evaluation gets the operation and then cycles through the inputs to
         * perform the action. The output is just a float.
         */
                void
        eval ()						LXx_OVERRIDE
        {
                double			 dVal, result = 0.0;
                unsigned int		 i, n;
                int			 op;

                v_op.GetInt (&op);

                n = a_inputs.Count ();
                for (i = 0; i < n; i++)
                {
                        a_inputs.GetFloat (i, &dVal);

                        if (i == 0)
                        {
                                result = dVal;
                                continue;
                        }

                        switch (op)
                        {
                                case OPi_ADD:
                                case OPi_AVERAGE:
                                        result += dVal;
                                        break;

                                case OPi_SUBTRACT:
                                        result -= dVal;
                                        break;

                                case OPi_MULTIPLY:
                                        result *= dVal;
                                        break;

                                case OPi_DIVIDE:
                                        if (dVal != 0.0)
                                                result /= dVal;
                                        break;

                                case OPi_MIN:
                                        if (dVal < result)
                                                result = dVal;
                                        break;
                                
                                case OPi_MAX:
                                        if (dVal > result)
                                                result = dVal;
                                        break;
                        }
                }

                if (op == OPi_AVERAGE && n > 1)
                        result /= n;

                v_result.SetFlt (result);
        }
};


/*
 * ----------------------------------------------------------------
 * The item will have a synthetic name based on the operator. We need
 * a listener to watch for channel changes and item behaviors to set
 * the synth name.
 */
class CPackage :
                public CLxPackage
{
    public:
        CLxUser_MessageService		 svc_message;
        CLxUser_ValueService		 svc_value;

                void
        synth_name (
                std::string		&name)
        {
                CLxUser_ChannelRead	 read;
                std::string		 sop;
                int			 op;

                svc_message.set ();
                svc_value.set ();

                check ( read.from (m_item) );
                op = read.IValue (m_item, "operation");
                check ( svc_value.TextHintEncode (op, hint_op, sop) );
                check ( svc_message.ArgTypeOptionUserName ("mathmulti-op", sop.c_str(), name) );
        }
};


class CListener :
                public CLxImpl_SceneItemListener,
                public CLxSingletonPolymorph
{
    public:
        LXxSINGLETON_METHOD

        CLxItemType		 cit_chmod;
        unsigned		 ch_operation;

        CListener () : cit_chmod (SRVNAME_PACKAGE)
        {
                AddInterface (new CLxIfc_SceneItemListener<CListener>);
                ch_operation = ~0;
        }

        LXxO_SceneItemListener_ChannelValue
        {
                CLxUser_Item		 hit (item);

                if (!hit.IsA (cit_chmod))
                        return;

                if (ch_operation == ~0)
                        check (hit.ChannelLookup ("operation", &ch_operation));

                if (index == ch_operation)
                        hit.InvalidateName ();
        }
};

static CLxMetaRoot_ChannelModifier<COperator, CPackage>
                                        meta (SRVNAME_PACKAGE);
static CLxSingletonListener<CListener>	listen;


        };	// end namespace


        void
initialize ()
{
        MathMulti::meta.initialize ();
}


