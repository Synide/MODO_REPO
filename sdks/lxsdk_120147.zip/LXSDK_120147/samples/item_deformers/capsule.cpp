/*
 * CAPSULE.CPP		Capsule Falloff Item
 *
 *	Copyright (c) 2008-2015 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_item.hpp>
#include <lx_package.hpp>
#include <lx_plugin.hpp>
#include <lx_action.hpp>
#include <lx_visitor.hpp>
#include <lx_value.hpp>
#include <lx_vmodel.hpp>
#include <lx_draw.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxu_math.hpp>
#include <lxidef.h>
#include <string>
#include <math.h>


        namespace Falloff_Capsule {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		"falloff.capsule"	// unique within item types
#define SRVNAME_MODIFIER		"falloff.capsule"	// unique within modifiers
#define SPWNAME_INSTANCE		"falloff.capsule.inst"	// unique within spawners in this module
#define SPWNAME_FALLOFF			"falloff.capsule"	// unique within spawners in this module


/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CPackage;

class CFalloffState
{
    public:
        CLxUser_Matrix		 scratch_mat;
        CLxUser_Value		 scratch_val;
        LXtMatrix4		 w_xfrm; 
        LXtMatrix4		 inv_w_xfrm; 
        LXtVector		 x_1, x_2, x_21;
        double			 r_1, r_2, r_21, d_abs2, core;
        int			 mode;
        int			 exponent;

                template <class F>
                F
        GetWeight (
                const F			*pos);

                template <class F>
                F
        Power (
                F			base,
                int			exponent);

                template <class F>
                F
        CalcWeight1D (
                F			d);

};


class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_ViewItem3D
{
    public:
        CPackage	*src_pkg;
        CLxUser_Item	 m_item;

        LxResult	 pins_Initialize (ILxUnknownID item, ILxUnknownID super)	LXx_OVERRIDE;
        void		 pins_Cleanup (void)						LXx_OVERRIDE;

        LxResult	 vitm_Draw (
                                ILxUnknownID	 itemChanRead,
                                ILxUnknownID	 viewStrokeDraw,
                                int		 selectionFlags,
                                const LXtVector	 itemColor) LXx_OVERRIDE;

        void		 capsuleDraw (
                                CLxUser_ChannelRead	 chan,
                                CLxUser_StrokeDraw	 stroke,
                                int			 selectionFlags,
                                const LXtVector		 itemColor,
                                bool			 coreMode);
};

class CPackage :
                public CLxImpl_Package
{
    public:
        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 spawn;

        CPackage () : spawn (SPWNAME_INSTANCE) {}

        LxResult		pkg_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		pkg_TestInterface (const LXtGUID *guid) LXx_OVERRIDE;
        LxResult		pkg_Attach (void **ppvObj) LXx_OVERRIDE;
};




/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,	LXsITYPE_FALLOFF	},
        { 0 }
};

/*
 * The package has a set of standard channels with default values. These
 * are setup at the start using the AddChannel interface.
 */
#define Cs_RANGESETUP		"useSetup"
#define Cs_AXIS			"axis"
#define Cs_LENGTH		"length"
#define Cs_BIAS			"bias"
#define Cs_RADIUS1		"radius1"
#define Cs_RADIUS2		"radius2"
#define Cs_CORE			"core" // inner radius defined by percentage of radius to add
#define Cs_MODE			"decayMode" // type of falloff
#define Cs_EXP			"invPower"


enum {
        RF_DECAY_SMOOTH = 0,
        RF_DECAY_INVPOW,
        //RF_DECAY_INVLIN,
        //RF_DECAY_INVSQ,
        RF_DECAY_GAUSS
};

#define RF_DECAY_LAST RF_DECAY_GAUSS

static LXtTextValueHint hint_Mode[] = {
        RF_DECAY_SMOOTH,	"smooth",
        RF_DECAY_INVPOW,	"power",
        //RF_DECAY_INVLIN,	"linear",
        //RF_DECAY_INVSQ,		"squared",
        RF_DECAY_GAUSS,		"gaussian",
        -1,			"=capsule-decay-type",
        -1,			 0
};


        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (Cs_RANGESETUP,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 0);

        ac.NewChannel  (Cs_AXIS,	LXsTYPE_AXIS);

        ac.NewChannel  (Cs_LENGTH,	LXsTYPE_DISTANCE);
        ac.SetDefault  (1.0, 0);

        ac.NewChannel  (Cs_BIAS,	LXsTYPE_PERCENT);
        ac.SetDefault  (0.0, 0);

        ac.NewChannel  (Cs_RADIUS1,	LXsTYPE_DISTANCE);
        ac.SetDefault  (0.5, 0);

        ac.NewChannel  (Cs_RADIUS2,	LXsTYPE_DISTANCE);
        ac.SetDefault  (0.5, 0);

        ac.NewChannel  (Cs_CORE,	LXsTYPE_PERCENT);
        ac.SetDefault  (0.0, 0);

        ac.NewChannel  (Cs_MODE,	LXsTYPE_INTEGER);
        ac.SetDefault  (0.0, RF_DECAY_SMOOTH);
        ac.SetHint     (hint_Mode);

        ac.NewChannel  (Cs_EXP,	LXsTYPE_INTEGER);
        ac.SetDefault  (0.0, 2);
        return LXe_OK;
}

/*
 * TestInterface() is required so that nexus knows what interfaces instance
 * of this package support. Necessary to prevent query loops.
 */
        LxResult
CPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return spawn.TestInterfaceRC (guid);
}

/*
 * Attach is called to create a new instance of this item. The returned
 * object implements a specific item of this type in the scene.
 */
        LxResult
CPackage::pkg_Attach (
        void		       **ppvObj)
{
        CInstance		*inst = spawn.Alloc (ppvObj);

        inst->src_pkg = this;
        return LXe_OK;
}



/*
 * ----------------------------------------------------------------
 * Emitter Item Instance
 *
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
        LxResult
CInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        m_item.set (item);
        return LXe_OK;
}

        void
CInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

#define	SIN45	0.707106781186547 // sine (& cosine!) of 45deg
#define COS30	0.866025403784439
#define COS60	0.5
#define SIN30	COS60
#define SIN60	COS30
#define COS15	0.965925826289068
#define SIN15	0.258819045102521
#define LXiLPAT_DOTSXLONG                 0x2020 
#define LXiLPAT_DATSXLONG                 0x7070 

        void
CInstance::capsuleDraw (
        CLxUser_ChannelRead	 chan,
        CLxUser_StrokeDraw	 stroke,
        int			 selectionFlags,
        const LXtVector		 itemColor,
        bool			 coreMode) 
{
        LXtVector		 v, v1, v2,p1,p2;
        double			 len2, bias, r1, r2, core;
        int			 ix, iy, axis;
        float			 c[8] = {0,SIN45,1,SIN45,0,-SIN45,-1,-SIN45}; //cosines around the circle
        float			 s[8] = {1,SIN45,0,-SIN45,-1,-SIN45,0,SIN45}; //sines

        int pat = !coreMode ?  LXiLPAT_DASH : LXiLPAT_DOTS;
        float alf = 1.0;//coreMode ? 0.85 : 1.0;

        axis = chan.IValue (m_item, Cs_AXIS);
        ix = (axis+1)%3;
        iy = (axis+2)%3;
        len2 = chan.FValue (m_item, Cs_LENGTH) / 2.0;
        bias = chan.FValue (m_item, Cs_BIAS);
        r1   = chan.FValue (m_item, Cs_RADIUS1);
        r2   = chan.FValue (m_item, Cs_RADIUS2);
        core = chan.FValue (m_item, Cs_CORE);


        LXx_VCLR (v);
        v[axis] = bias*len2 + len2;
        LXx_VCPY (v1, v);
        v[axis] = bias*len2 - len2;
        LXx_VCPY (v2, v);

        if(!coreMode) {
                if(selectionFlags&LXiSELECTION_SELECTED) {
                        stroke.BeginW (LXiSTROKE_LINES, itemColor, alf, 1);
                        stroke.Vert (v1);
                        stroke.Vert (v2);

                        stroke.BeginW (LXiSTROKE_FRONT_BOXES, itemColor, alf, 1);
                        core = (r1+r2)/20;
                        LXx_VSET (v, core);
                        stroke.Vert (v);
                        LXx_VSET (v, -core);
                        stroke.Vert (v);
                }
                else {
                        stroke.BeginW (LXiSTROKE_LINES, itemColor, alf, 1);
                        stroke.Vert (v1);
                        stroke.Vert (v2);
                }
        }
        else {
                if (core<=0)
                        return;
                r1 *= core;
                r2 *= core;
        }

        stroke.BeginWD (LXiSTROKE_CIRCLES, itemColor, alf, 1, pat);

        stroke.Vert (v1);
        LXx_VCPY (v, v1);
        v[axis] += r1;
        stroke.Vert (v);

        stroke.Vert (v2);
        LXx_VCPY (v, v2);
        v[axis] += r2;
        stroke.Vert (v);

        LXx_VCPY (p1, v1);
        LXx_VCPY (p2, v2);
        stroke.BeginWD (LXiSTROKE_LINES, itemColor, alf, 1, pat);
        for(int i = 0; i<8; i++) { // draw lines parallel to axis for cylinder body
                p1[ix] = v1[ix] + c[i]*r1;
                p1[iy] = v1[iy] + s[i]*r1;		
                stroke.Vert (p1);
                p2[ix] = v2[ix] + c[i]*r2;
                p2[iy] = v2[iy] + s[i]*r2;
                stroke.Vert (p2);
        }
#ifdef ARCS_IMPLEMENTED // hey this is not implemented at all :(
        stroke.BeginWD (LXiSTROKE_ARCS, itemColor, alf, 1, pat);
        for(int i = 0; i<4; i++) { // rounded half-circle endcaps, v1 first

                stroke.Vert (v1);

                p1[ix] = v1[ix] + c[i]*r1;
                p1[iy] = v1[iy] + s[i]*r1;
                stroke.Vert (p1);
                
                p1[ix] = v1[ix] - c[i]*r1;
                p1[iy] = v1[iy] - s[i]*r1;
                stroke.Vert (p1);

                stroke.Vert (v2);

                p2[ix] = v2[ix] + c[i]*r2;
                p2[iy] = v2[iy] + s[i]*r2;
                stroke.Vert (p2);
                
                p2[ix] = v2[ix] - c[i]*r2;
                p2[iy] = v2[iy] - s[i]*r2;
                stroke.Vert (p2);
        }
#else
        for(int i = 0; i<8; i++) { // rounded quarter-circle endcaps, v1 first
                stroke.BeginWD (LXiSTROKE_LINE_STRIP, itemColor, alf, 1, pat);
                p1[ix] = v1[ix] + c[i]*r1;
                p1[iy] = v1[iy] + s[i]*r1;
                LXx_VCPY (v, p1);

                stroke.Vert (v);

                v[ix] = v1[ix] + c[i]*r1*COS15;
                v[iy] = v1[iy] + s[i]*r1*COS15;
                v[axis] = v1[axis] + r1*SIN15;
                stroke.Vert (v);

                v[ix] = v1[ix] + c[i]*r1*COS30;
                v[iy] = v1[iy] + s[i]*r1*COS30;
                v[axis] = v1[axis] + r1*SIN30;
                stroke.Vert (v);

                v[ix] = v1[ix] + c[i]*r1*SIN45;
                v[iy] = v1[iy] + s[i]*r1*SIN45;
                v[axis] = v1[axis] + r1*SIN45;
                stroke.Vert (v);

                v[ix] = v1[ix] + c[i]*r1*COS60;
                v[iy] = v1[iy] + s[i]*r1*COS60;
                v[axis] = v1[axis] + r1*SIN60;
                stroke.Vert (v);

                v[ix] = v1[ix] + c[i]*r1*SIN15;
                v[iy] = v1[iy] + s[i]*r1*SIN15;
                v[axis] = v1[axis] + r1*COS15;
                stroke.Vert (v);

                v[ix] = v1[ix];
                v[iy] = v1[iy];
                v[axis] = v1[axis] + r1;
                stroke.Vert (v);

                // end cap for v2 end
                stroke.BeginWD (LXiSTROKE_LINE_STRIP, itemColor, alf, 1, pat);
                p2[ix] = v2[ix] + c[i]*r2;
                p2[iy] = v2[iy] + s[i]*r2;
                LXx_VCPY (v, p2);
                stroke.Vert (v);

                v[ix] = v2[ix] + c[i]*r2*COS15;
                v[iy] = v2[iy] + s[i]*r2*COS15;
                v[axis] = v2[axis] - r2*SIN15;
                stroke.Vert (v);

                v[ix] = v2[ix] + c[i]*r2*COS30;
                v[iy] = v2[iy] + s[i]*r2*COS30;
                v[axis] = v2[axis] - r2*SIN30;
                stroke.Vert (v);

                v[ix] = v2[ix] + c[i]*r2*SIN45;
                v[iy] = v2[iy] + s[i]*r2*SIN45;
                v[axis] = v2[axis] - r2*SIN45;
                stroke.Vert (v);

                v[ix] = v2[ix] + c[i]*r2*COS60;
                v[iy] = v2[iy] + s[i]*r2*COS60;
                v[axis] = v2[axis] - r2*SIN60;
                stroke.Vert (v);

                v[ix] = v2[ix] + c[i]*r2*SIN15;
                v[iy] = v2[iy] + s[i]*r2*SIN15;
                v[axis] = v2[axis] - r2*COS15;
                stroke.Vert (v);

                v[ix] = v2[ix];
                v[iy] = v2[iy];
                v[axis] = v2[axis] - r2;
                stroke.Vert (v);
        }
#endif
}

        LxResult
CInstance::vitm_Draw (
        ILxUnknownID		 itemChanRead,
        ILxUnknownID		 viewStrokeDraw,
        int			 selectionFlags,
        const LXtVector		 itemColor)
{
        CLxUser_ChannelRead	 chan (itemChanRead);
        CLxUser_StrokeDraw	 stroke (viewStrokeDraw);

        capsuleDraw (chan, stroke, selectionFlags, itemColor, false);
        if(selectionFlags&LXiSELECTION_SELECTED) 
                capsuleDraw (chan, stroke, selectionFlags, itemColor, true);
        return LXe_OK;
}


/*
 * ----------------------------------------------------------------
 * Falloff
 *
Distance to line, vectors:
        endpoint x1 & x2
        test point x0

t = (x0 - x1) . (x2 - x1) / ABS (x2 - x1)

for 0 < t < 1:

d = ABS ((x0 - x1) X (x0 - x2)) / ABS (x1 - x2)

 */

        template <class F>
        F
CFalloffState::GetWeight (
        const F			*x0)
{
        F			 x01[3], xt[3];
        F			 t, r, w, x;

        //LXtVector		p, wp;
        //scratch_mat.Set4 (inv_w_xfrm);  // use inverse world matrix to transform 
        //LXx_VCPY (wp, x0);		// world position to local coordinates
        //scratch_mat.MultiplyVector (wp, p);
        //
        //LXx_VSUB3 (x01, p, x_1);//
        // capsule positions already in world coord.s
        LXx_VSUB3 (x01, x0, x_1);
        t = LXx_VDOT (x01, x_21) / d_abs2;
        t = LXxCLAMP (t, 0.0, 1.0);

        LXx_VADDS3 (xt, x_1, x_21, t);
        LXx_VSUB (xt, x0);
        r = r_1 + r_21 * t;

        //rIn = r * LXxCLAMP (core, 0.0, 1.0);
        x = LXx_VLEN (xt);

        w = r>0 ? CalcWeight1D (x/r) : 1;
        //if(x<=rIn)
        //	w = 1.0;
        //else if (x>=r)
        //	w = 0.0;
        //else {
        //	w = (x - rIn) / (r - rIn); // fraction of the way from rIn to r
        //	w = 1.0 - w;
        //}
        //return lx::Smooth (LXxCLAMP (w, 0.0, 1.0));
        return w;
}

        template <class F>
        F
CFalloffState::Power (
        F			base,
        int			exponent)
{
        F			val = 1;

        for (int i=0; i<exponent; i++)
                val *= base;
        for (int i=0; i>exponent; i--) // handle negative exponent case
                val /= base;

        return val;
}

#define LN2	0.69314718055995 // useful for FWHM calculation

        template <class F>
        F
CFalloffState::CalcWeight1D (
        F			d) 
{
        F			w=0;

        switch (mode) {
                case RF_DECAY_SMOOTH:
                        if(d<=core) // inside hard core, full weight
                                return 1.0;
                        if(d>=1) // outside radius entirely
                                return 0.0;
                        w = 1.0 - ((d - core)/(1.0 - core));
                        w = lx::Smooth (LXxCLAMP (w, 0.0, 1.0));
                        break;
                case RF_DECAY_GAUSS: // ignore core
                        // gaussian: exp(-k*x^2), FWHM=2*ln(2)/k ==> k = ln(2)/FWHM = ln(2)
                        w = exp(-LN2*d*d*2); // half max at R = FWHM/2
                        break;
                case RF_DECAY_INVPOW:
                //case RF_DECAY_INVSQ:
                default:
                        if(d<=core) // inside hard core, full weight
                                return 1.0;
                        w =  d - core;
                        w = Power (LXxABS (w), exponent);
                        w = w>0.0 ? 1.0 / (1.0 + w) : 1.0; // inside radius weight over 1 would be clamped anyway
                        break;
        }
        return w;
}


class CFalloff :
                public CLxImpl_Falloff
{
    public:
        CFalloffState	 cur_state;

        float		 fall_WeightF (const LXtFVector position)		LXx_OVERRIDE;
        LxResult	 fall_WeightRun (const float **pos, float *weight, unsigned count)
                                                                                LXx_OVERRIDE;
};

        float
CFalloff::fall_WeightF (
        const LXtFVector	 position)
{
        return cur_state.GetWeight (position);
}

        LxResult
CFalloff::fall_WeightRun (
        const float	       **pos,
        float			*weight,
        unsigned		 count)
{
        return lx::WeightRun (&cur_state, pos, weight, count);
}

/*
 * The modifier spawns the falloff from the input parameters.
 */
class CModifier :
                public CLxObjectRefModifierCore
{
    public:
        const char *	ItemType ()			LXx_OVERRIDE
        {
                return SRVNAME_ITEMTYPE;
        }

        const char *	Channel  ()			LXx_OVERRIDE
        {
                return LXsICHAN_FALLOFF_FALLOFF;
        }

                void
        Attach (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)		LXx_OVERRIDE
        {
                eval.AddChan (item, Cs_AXIS);
                eval.AddChan (item, Cs_LENGTH);
                eval.AddChan (item, Cs_BIAS);
                eval.AddChan (item, Cs_RADIUS1);
                eval.AddChan (item, Cs_RADIUS2);
                eval.AddChan (item, Cs_CORE);
                eval.AddChan (item, Cs_MODE);
                eval.AddChan (item, Cs_EXP);
                eval.AddChan (item, Cs_RANGESETUP);
                eval.AddChan (item, LXsICHAN_XFRMCORE_WORLDMATRIX, LXfECHAN_READ | LXfECHAN_SETUP);
        }

                void
        Alloc (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr,
                unsigned		 index,
                ILxUnknownID		&obj)		LXx_OVERRIDE
        {
                CLxSpawner<CFalloff>	 sp (SPWNAME_FALLOFF);
                CFalloff		*fall;
                //CLxUser_ValueService	 vS;

                fall = sp.Alloc (obj);


                CFalloffState		&c = fall->cur_state;
                CLxUser_Matrix		 xfrm;
                LXtVector		 v;
                double			 len, bias;
                int			 axis;

                axis  = attr.Int   (index++);
                len   = attr.Float (index++);
                bias  = attr.Float (index++);
                c.r_1 = attr.Float (index++);
                c.r_2 = attr.Float (index++);
                c.core = attr.Float (index++);
                c.mode   = attr.Int (index++);
                c.mode = LXxCLAMP (c.mode, RF_DECAY_SMOOTH, RF_DECAY_LAST);
                c.exponent = attr.Int (index++);
                c.exponent = LXxMAX (c.exponent, 1);
                if (attr.Bool (index++))
                        eval.SetAlternateSetup ();


                attr.ObjectRO (index++, xfrm);
                //xfrm.Get4 (c.w_xfrm);
                //vS.NewValue (c.scratch_val, LXsTYPE_MATRIX4);
                //c.scratch_mat.set (c.scratch_val); 
                //c.scratch_mat.Set4 (c.w_xfrm); // use mutable matrix for invert!!!
                //c.scratch_mat.Invert ();
                //c.scratch_mat.Get4 (c.inv_w_xfrm);

                bias *= len / 2;

                LXx_VCLR (v);
                v[axis] = len / 2.0 + bias;
                xfrm.MultiplyVector (v, c.x_1);

                v[axis] = -len / 2.0 + bias;
                xfrm.MultiplyVector (v, c.x_2);

                LXx_VSUB3 (c.x_21, c.x_2, c.x_1);
                c.d_abs2 = LXx_VDOT (c.x_21, c.x_21);
                c.r_21   = c.r_2 - c.r_1;
        }
};



/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackage>;
        srv->AddInterface (new CLxIfc_Package   <CPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc<CPackage>);
        lx::AddServer (SRVNAME_ITEMTYPE, srv);

        srv = new CLxPolymorph<CInstance>;
        srv->AddInterface (new CLxIfc_PackageInstance<CInstance>);
        srv->AddInterface (new CLxIfc_ViewItem3D     <CInstance>);
        lx::AddSpawner (SPWNAME_INSTANCE, srv);

        CLxSpawner_Falloff<CFalloff> (SPWNAME_FALLOFF);

        CLxExport_ItemModifierServer<CLxObjectRefModifier<CModifier> > (SRVNAME_MODIFIER);
}

        };	// END namespace


