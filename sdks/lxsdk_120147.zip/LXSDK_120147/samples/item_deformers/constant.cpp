/*
 * CONSTANT.CPP		Constant Falloff for Deformations
 *
 *	Copyright (c) 2008-2015 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_item.hpp>
#include <lx_package.hpp>
#include <lx_plugin.hpp>
#include <lx_filter.hpp>
#include <lx_visitor.hpp>
#include <lx_value.hpp>
#include <lx_vmodel.hpp>
#include <lx_draw.hpp>
#include <lx_locator.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxu_math.hpp>
#include <lxidef.h>
#include <string>
#include <math.h>


        namespace Falloff_Constant {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		"falloff.constant"	// unique within item types
#define SRVNAME_MODIFIER		"falloff.constant"	// unique within modifiers
#define SPWNAME_INSTANCE		"falloff.constant.inst"	// unique within spawners in this module
#define SPWNAME_FALLOFF			"falloff.constant"	// unique within spawners in this module

/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CPackage;

class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_ViewItem3D
{
    public:
        CPackage	*src_pkg;
        CLxUser_Item	 m_item;

        LxResult	 pins_Initialize (ILxUnknownID item, ILxUnknownID super)	LXx_OVERRIDE;
        void		 pins_Cleanup (void)						LXx_OVERRIDE;

        LxResult	 vitm_Draw (
                                ILxUnknownID	 itemChanRead,
                                ILxUnknownID	 viewStrokeDraw,
                                int		 selectionFlags,
                                const LXtVector	 itemColor)				LXx_OVERRIDE;

};

class CPackage :
                public CLxImpl_Package
{
    public:
        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 spawn;

        CPackage () : spawn (SPWNAME_INSTANCE) {}

        LxResult		pkg_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		pkg_TestInterface (const LXtGUID *guid) LXx_OVERRIDE;
        LxResult		pkg_Attach (void **ppvObj) LXx_OVERRIDE;
};


/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,	LXsITYPE_FALLOFF	},
        { 0 }
};

        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        return LXe_OK;
}
 
/*
 * TestInterface() is required so that nexus knows what interfaces instance
 * of this package support. Necessary to prevent query loops.
 */
        LxResult
CPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return spawn.TestInterfaceRC (guid);
}

/*
 * Attach is called to create a new instance of this item. The returned
 * object implements a specific item of this type in the scene.
 */
        LxResult
CPackage::pkg_Attach (
        void		       **ppvObj)
{
        CInstance		*inst = spawn.Alloc (ppvObj);

        inst->src_pkg = this;
        return LXe_OK;
}


/*
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
        LxResult
CInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        m_item.set (item);
        return LXe_OK;
}

        void
CInstance::pins_Cleanup (void)
{
        m_item.clear ();
}


        LxResult
CInstance::vitm_Draw (
        ILxUnknownID		 itemChanRead,
        ILxUnknownID		 viewStrokeDraw,
        int			 selectionFlags,
        const LXtVector		 itemColor)
{
        return LXe_OK;
}

class CFalloff :
                public CLxImpl_Falloff
{
    public:
                LXtMatrix4		 w_xfrm; 

                template <class F>
                F
        GetWeight (
                const F			*pos)
        {
                return 1.0;
        }


        float		 fall_WeightF (const LXtFVector position)		LXx_OVERRIDE;
        LxResult	 fall_WeightRun (const float **pos, float *weight, unsigned count)
                                                                                LXx_OVERRIDE;
};

        float
CFalloff::fall_WeightF (
        const LXtFVector	 position)
{
        return GetWeight (position);
}

        LxResult
CFalloff::fall_WeightRun (
        const float	       **pos,
        float			*weight,
        unsigned		 count)
{
        return lx::WeightRun (this, pos, weight, count);
}


/*
 * The modifier spawns the falloff from the input parameters.
 */
class CModifier :
                public CLxObjectRefModifierCore
{
    public:
        const char *	ItemType ()			LXx_OVERRIDE
        {
                return SRVNAME_ITEMTYPE;
        }

        const char *	Channel  ()			LXx_OVERRIDE
        {
                return LXsICHAN_FALLOFF_FALLOFF;
        }

                void
        Attach (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)		LXx_OVERRIDE
        {
                eval.AddChan (item, LXsICHAN_XFRMCORE_WORLDMATRIX, LXfECHAN_READ | LXfECHAN_SETUP);
        }

                void
        Alloc (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr,
                unsigned		 index,
                ILxUnknownID		&obj)		LXx_OVERRIDE
        {
                CLxSpawner<CFalloff>	 sp (SPWNAME_FALLOFF);
                CFalloff		*fall;
                CLxUser_Matrix		 xfrm;
                fall = sp.Alloc (obj);

                attr.ObjectRO (index++, xfrm);
                xfrm.Get4 (fall->w_xfrm);
        }
};


/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackage>;
        srv->AddInterface (new CLxIfc_Package   <CPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc<CPackage>);
        lx::AddServer (SRVNAME_ITEMTYPE, srv);

        srv = new CLxPolymorph<CInstance>;
        srv->AddInterface (new CLxIfc_PackageInstance<CInstance>);
        srv->AddInterface (new CLxIfc_ViewItem3D     <CInstance>);
        lx::AddSpawner (SPWNAME_INSTANCE, srv);

        CLxSpawner_Falloff<CFalloff> (SPWNAME_FALLOFF);

        CLxExport_ItemModifierServer<CLxObjectRefModifier<CModifier> > (SRVNAME_MODIFIER);
}

        };	// END namespace


