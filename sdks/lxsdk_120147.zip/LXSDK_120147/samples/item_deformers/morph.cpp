/*
 * MORPH.CPP	Morph Mesh Influence
 *
 *	Copyright (c) 2008-2015 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_deform.hpp>
#include <lx_plugin.hpp>
#include <lxu_deform.hpp>
#include <lxu_package.hpp>
#include <lxu_modifier.hpp>
#include <lxu_math.hpp>
#include <lxidef.h>
#include <string>
#include <math.h>


        namespace Influence_Morph {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		LXsITYPE_MORPHDEFORM
#define SRVNAME_MODIFIER		LXsITYPE_MORPHDEFORM


/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CPackage :
                public CLxDefaultPackage
{
    public:
        static LXtTagInfoDesc	 descInfo[];

        LxResult	 pkg_SetupChannels (ILxUnknownID addChan)	LXx_OVERRIDE;
};



/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
/*
 * The package has a set of standard channels with default values. These
 * are setup at the start using the AddChannel interface.
 */
#define Cs_MESHINF		LXsICHAN_MORPHDEFORM_MESHINF
#define Cs_ENABLE		LXsICHAN_MORPHDEFORM_ENABLE
#define Cs_MAPNAME		LXsICHAN_MORPHDEFORM_MAPNAME
#define Cs_STRENGTH		LXsICHAN_MORPHDEFORM_STRENGTH
#define Cs_USELOCAL		LXsICHAN_MORPHDEFORM_USELOCAL

LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,		LXsITYPE_LOCATOR	},
        { LXsPKG_DEFORMER_CHANNEL,	Cs_MESHINF		},
        { LXsPKG_DEFORMER_FLAGS,	"+WX"			},	// no weight, no xfrm
        { LXsPKG_DEFORMER_CREATECMD,	"morphDeform.create"	},
        { 0 }
};

        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (Cs_MESHINF,	LXsTYPE_OBJREF);
        ac.SetInternal ();

        ac.NewChannel  (Cs_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);

        ac.NewChannel  (Cs_MAPNAME,	LXsTYPE_VERTMAPNAME);

        ac.NewChannel  (Cs_STRENGTH,	LXsTYPE_PERCENT);
        ac.SetDefault  (1.0, 0);

        ac.NewChannel  (Cs_USELOCAL,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 0);

        return LXe_OK;
}


/* 
 * Mesh Influence for a morph is dead simple. The CChanState holds values of
 * the channels and handles getting them from the evaluation state. It also
 * serves as the modifier cache so we can compare previous values.
 */
class CChanState :
                public CLxObject
{
    public:
        std::string		 name;
        double			 factor;
        LXtMatrix		 xfrm;
        bool			 enabled, local;

                void
        Attach (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
        {
                eval.AddChan (item, Cs_ENABLE);
                eval.AddChan (item, Cs_MAPNAME);
                eval.AddChan (item, Cs_STRENGTH);
                eval.AddChan (item, Cs_USELOCAL);
                eval.AddChan (item, LXsICHAN_XFRMCORE_WORLDMATRIX);
        }

                void
        Read (
                CLxUser_Attributes	&attr,
                unsigned		 index)
        {
                CLxUser_Matrix		 m4;

                enabled = attr.Bool (index++);
                if (enabled) {
                        attr.String (index++, name);
                        factor = attr.Float (index++);
                        local  = attr.Bool  (index++);
                        if (local) {
                                attr.ObjectRO (index++, m4);
                                m4.Get3 (xfrm);
                        }
                }
        }

                LxResult
        Compare (
                CChanState		&that)
        {
                if (enabled != that.enabled || name.compare (that.name))
                        return LXeEVAL_DIFFERENT;

                return LXeDEFORM_NEWOFFSET;
        }
};

/*
 * The influence itself selects the morph map by name and then extracts the
 * offsets for each point.
 */
class CInfluence :
                public CLxMeshInfluence
{
    public:
        CChanState		 cur;
        LXtMeshMapID		 map_id;
        bool			 is_abs;

                CInfluence () : map_id (0) {}

                bool
        SelectMap (
                CLxUser_Mesh		&mesh,
                CLxUser_MeshMap		&map)		LXx_OVERRIDE
        {
                map.SelectByName (LXi_VMAP_MORPH, cur.name.c_str ());
                map_id = map.ID ();
                if (map_id) {
                        is_abs = false;
                        return true;
                }

                map.SelectByName (LXi_VMAP_SPOT, cur.name.c_str ());
                map_id = map.ID ();
                is_abs = true;
                return true;
        }

                void
        Offset (
                CLxUser_Point		&point,
                float			 weight,
                LXtFVector		 offset)	LXx_OVERRIDE
        {
                LXtFVector		 offF, posF;

                point.MapValue (map_id, offF);
                if (is_abs) {
                        point.Pos (posF);
                        LXx_VSUB (offF, posF);
                }

                if (cur.local) {
                        LXtFVector	 tmp;

                        lx::MatrixMultiply (tmp, cur.xfrm, offF);
                        LXx_VSCL3 (offset, tmp, cur.factor * weight);
                } else
                        LXx_VSCL3 (offset, offF, cur.factor * weight);
        }
};



/*
 * The modifier operates on all items of this type, and sets the mesh influence
 * channel to an object allocated using the input parameters for the modifier.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        unsigned	 index;

                CLxObject *
        Cache ()
        {
                return new CChanState;
        }

                LxResult
        EvalCache (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr,
                CLxObject		*cacheRaw,
                bool			 prev)
        {
                CChanState		*cache = dynamic_cast<CChanState *> (cacheRaw);
                CInfluence		*infl;
                CLxUser_ValueReference	 ref;
                ILxUnknownID		 obj;
                LxResult		 rc;

                infl = new CInfluence;
                infl->Spawn ((void **) &obj);
                attr.ObjectRW (index, ref);
                ref.SetObject (obj);
                lx::UnkRelease (obj);

                infl->cur.Read (attr, index + 1);
                if (prev)
                        rc = cache->Compare (infl->cur);
                else
                        rc = LXe_OK;

                *cache = infl->cur;
                return rc;
        }
};

class CModifier :
                public CLxItemModifierServer
{
    public:
                const char *
        ItemType ()
        {
                return SRVNAME_ITEMTYPE;
        }

                CLxItemModifierElement *
        Alloc (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
        {
                CModifierElement	*elt;
                CChanState		 tmp;

                elt = new CModifierElement;
                elt->index = eval.AddChan (item, Cs_MESHINF, LXfECHAN_WRITE);

                tmp.Attach (eval, item);

                return elt;
        }
};



/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackage>;
        srv->AddInterface (new CLxIfc_Package   <CPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc<CPackage>);
        lx::AddServer (SRVNAME_ITEMTYPE, srv);

        CLxExport_ItemModifierServer<CModifier> (SRVNAME_MODIFIER);
}

        };	// END namespace



