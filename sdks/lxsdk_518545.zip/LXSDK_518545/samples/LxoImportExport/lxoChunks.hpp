/*
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * Class to write LXO files
 */

#pragma once

#include <lxidef.h>
#include <lxio.h>
#include <lxvector.h>

#include "lxoIoDefs.hpp"

#define LXs_SOLID_MATERIAL_NAME_TEMPLATE    "_SolidColor 0x%06x"
#define LXs_REPLICATOR_NAME_TEMPLATE        "Replicate %d -> %d"
#define LXs_REPLICATOR_MESH_NAME_TEMPLATE   "ReplicatorMesh %d -> %d"
#define LXs_STATIC_MESH_NAME_TEMPLATE       "StaticMesh %d"

#define LXs_OUTPUT_NAME_FINAL               "renderOutFinal"
#define LXs_OUTPUT_NAME_ALPHA               "renderOutAlpha"
#define LXs_OUTPUT_NAME_DEPTH               "renderOutDepth"

#define LXs_MODIFIER_TRANSLATION            "Translation"
#define LXs_MODIFIER_ROTATION               "Rotation"
#define LXs_MODIFIER_SCALE                  "Scale"

#define LXs_DEFAULT_CAMERA_NAME             "DefaultCamera"
#define LXs_DEFAULT_CAMERA_TRANS            LXs_DEFAULT_CAMERA_NAME LXs_MODIFIER_TRANSLATION
#define LXs_DEFAULT_CAMERA_ROT              LXs_DEFAULT_CAMERA_NAME LXs_MODIFIER_ROTATION

enum {              // Item Data Types & values
    LXVersion_Major                 = 2,
    LXVersion_Minor                 = 1,

    LXLayerColor_Default            = 0xc8c8c8ff,
    };

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This class is used for writing data to an LXO file.
 *
 *----------------------------------------------------------------------------*/
class LxoWriteData {
friend class LxoWriter;

        FILE*                   m_outFile;		// file pointer for the LXO file
        LxULong                 m_chunkSizePos;         // file position of where to write the chunk size
        LxULong                 m_subChunkSizePos;      // file position of where to write the sub-chunk size
        LxResult                m_result;		// result of I/O operations

        LXtMap_StringIds        m_channels;
        LXtMap_StringIds        m_imageFiles;
        LXtMap_StringIds        m_tags;
        LXtMap_Materials        m_materials;

        float                   m_maxLightLumens;
        float                   m_skyLumens;
        float                   m_skyCloudiness;
        float                   m_solarDiskSize;
        LxULong                 m_itemIdSunlight;       // Reference ID of the light representing the sun

        LxULong                 WriteVideoStill (char const* filename);
        LxResult                WriteMaterialPreset (LXtMaterial& material);

        LxResult                WriteMaterial (LXtMaterial& material);
        LxResult                WriteMaterials ();
        LxResult                WriteEnvironment (LXtRenderSettings& settings);

    public:
        LxULong                 m_itemId;               // Reference ID of the last item written
        LxULong                 m_renderItemId;         // Reference ID of the render chunk - all material use this as parent
        LxULong                 m_renderItemIndex;      // index of the last child item of the render chunk
        LxULong                 m_envelopeId;           // Reference ID of the last item written
        LxULong                 m_layerId;              // Reference ID of the last layer chunk written

         LxoWriteData (char const* lxoName, char const** channelNames, int nChannelNames);
        ~LxoWriteData ();

        char const*             GetUvMapName (char const *materialName, int uvMapIndex);
        LxUShort                GetChannelIndex (const char* name);     // get channel index from channel name
        LxUShort                GetTagIndex (const char* name);         // get tag index from tag name

        LxResult		WriteShort  (LxUShort val)  { return WriteShorts (&val, 1); }
        LxResult		WriteLong   (LxULong val)   { return WriteLongs  (&val, 1); }
        LxResult		WriteInt    (int val)       { return WriteInts   (&val, 1); }
        LxResult		WriteFloat  (float val)     { return WriteFloats (&val, 1); }

        LxResult		WriteIndex  (LxULong val);
        LxResult		WriteString (char const* str);

        LxResult		WriteBytes  (LxByte const* val,   LxULong count);
        LxResult		WriteShorts (LxUShort const* val, LxULong count);
        LxResult		WriteLongs  (LxULong const* val,  LxULong count);
        LxResult		WriteIndexes(LxULong const* val,  LxULong count);
        LxResult		WriteInts   (int const* val,      LxULong count);
        LxResult		WriteFloats (float const* val,    LxULong count);

        LxResult		BeginChunk (LXtID4 id);		// Write & record chunk header position
        LxResult		EndChunk ();			// Close chunk & write chunk size
        LxResult		BeginSubChunk (LXtID4 id);	// Write & record sub-chunk header position
        LxResult		EndSubChunk ();			// Close sub-chunk & write sub-chunk size

        LxResult                WriteChannels ();
        LxResult                WriteChannels (LXtStringVec fileChannels, LxULong count);
        LxResult                WriteTags ();

        LxResult                WriteItemHeader (char const* chunkType, char const* chunkName, LxULong itemId = 0);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This macro can be used for writing data to a chunk and returning if an error occurs.
 *
 *----------------------------------------------------------------------------*/
#define WriterReturnOnError(ACTION)     if (LXe_OK != (m_result = m_writer->ACTION)) return m_result

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This macro can be used for writing a sub-chunk and returning if an error occurs.
 *
 *----------------------------------------------------------------------------*/
#define ReturnOnError(ACTION)           if (LXe_OK != (m_result = ACTION)) return m_result

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This is the base class for all chunks. All other chunk types are derived
 * from this.
 *
 *----------------------------------------------------------------------------*/
class LxoChunk {
    public:
        LxoWriteData*   m_writer;		// writer class to use to actually write the chunk
        LxResult        m_result;		// result of I/O operations

        /*
         * Record the 'writer' class instance and start the chumk
         */
        LxoChunk (LXtID4 id, LxoWriteData* writer, bool isSubChunk = false)
            {
            m_writer = writer;
            m_result = isSubChunk ? m_writer->BeginSubChunk (id) : m_writer->BeginChunk (id);
            }

        /*
         * Shorthand for call to EndChunk function in writer to fix the chunk size.
         */
        virtual LxResult    CloseChunk ()   { return m_writer->EndChunk (); }
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This is the base class for all sub-chunks.
 *
 *----------------------------------------------------------------------------*/
class LxoSubChunk : public LxoChunk {
    public:
        LxoSubChunk (LXtID4 id, LxoWriteData* writer) : LxoChunk (id, writer, true) {}

        virtual LxResult    CloseChunk ()       { return m_writer->EndSubChunk (); }
};

/*******************************************************************************
 *
 * The folowing classes define sub-chunks used in Item & Action chumks
 *
 ******************************************************************************/

/*------------------------------- Luxology LLC --------------------------- 03/09
 * External reference Sub-Chunk
 *----------------------------------------------------------------------------*/
class LxoXRefSubChunk : public LxoSubChunk {
    public:
        LxoXRefSubChunk (LxoWriteData* writer) : LxoSubChunk ('XREF', writer) {}

        LxResult    Write (LxULong index, char const* filename, char const* id);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Unique id for Sub-Chunk
 *----------------------------------------------------------------------------*/
class LxoUniqueSubChunk : public LxoSubChunk {
    public:
        LxoUniqueSubChunk (LxoWriteData* writer) : LxoSubChunk ('UNIQ', writer) {}

        LxResult    Write (char const* id) { return LXe_OK == m_writer->WriteString (id) ? CloseChunk (): m_result; }
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Unique index for Sub-Chunk
 *----------------------------------------------------------------------------*/
class LxoUniqueIndexSubChunk : public LxoSubChunk {
    public:
        LxoUniqueIndexSubChunk (LxoWriteData* writer) : LxoSubChunk ('UIDX', writer) {}

        LxResult    Write (LxULong index) { return LXe_OK == m_writer->WriteLong (index) ? CloseChunk (): m_result; }
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Layer Sub-Chunk - for name / string-value pairs
 *----------------------------------------------------------------------------*/
class LxoLayerSubChunk : public LxoSubChunk {
    public:
        LxoLayerSubChunk (LxoWriteData* writer) : LxoSubChunk ('LAYR', writer) {}

        LxResult    Write (LxULong index, LxULong flags = LXLayerFlag_Default, LxULong color = 0x00777777);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Link Sub-Chunk - for referencing other items by ID
 *----------------------------------------------------------------------------*/
class LxoLinkSubChunk : public LxoSubChunk {
    public:
        LxoLinkSubChunk (LxoWriteData* writer) : LxoSubChunk ('LINK', writer) {}

        LxResult    Write (char const* name, LxULong parentItemId, LxULong linkItemId);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Package Sub-Chunk - 
 *----------------------------------------------------------------------------*/
class LxoPackageChunk : public LxoSubChunk {
    public:
        LxoPackageChunk (LxoWriteData* writer) : LxoSubChunk ('PAKG', writer) {}

        LxResult    Write (char const* name, LxULong bytes, LxByte* data);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Scalar channel Sub-Chunk - writes a single value with name & type
 *
 * Note: this class should generally NOT be used and is only included for
 * legacy files.
 *----------------------------------------------------------------------------*/
class LxoScalarChannelSubChunk : public LxoSubChunk {
    public:
        LxoScalarChannelSubChunk (LxoWriteData* writer) : LxoSubChunk ('CHNL', writer) {}

        LxResult    Write (char const* name, float       value);
        LxResult    Write (char const* name, int         value);
        LxResult    Write (char const* name, char const* value);
        LxResult    Write (char const* name, LxByte*     value, LxUShort bytes);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * RGB Channel Sub-Chunk - writes an RGB triple into a sub-chunk
 *----------------------------------------------------------------------------*/
class LxoRgbChannelSubChunk : public LxoSubChunk {
    public:
        LxoRgbChannelSubChunk (LxoWriteData* writer) : LxoSubChunk ('CHNV', writer) {}

        LxResult    Write (char const* name, LXtFVector color);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * XYZ Channel Sub-Chunk - writes an XYZ triple into a sub-chunk
 *----------------------------------------------------------------------------*/
class LxoXyzChannelSubChunk : public LxoSubChunk {
    public:
        LxoXyzChannelSubChunk (LxoWriteData* writer) : LxoSubChunk ('CHNV', writer) {}

        LxResult    Write (char const* name, LXtFVector point);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Name/String Sub-Chunk - for name / string-value pairs
 *----------------------------------------------------------------------------*/
class LxoNameStringSubChunk : public LxoSubChunk {
    public:
        LxoNameStringSubChunk (LxoWriteData* writer) : LxoSubChunk ('CHNS', writer) {}

        LxResult    Write (char const* name, char const* value);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Gradient Sub-Chunk
 *----------------------------------------------------------------------------*/
class LxoGradientSubChunk : public LxoSubChunk {
    public:
        LxoGradientSubChunk (LxoWriteData* writer) : LxoSubChunk ('GRAD', writer) {}

        LxResult    Write (char const* name, LxULong envelopeIndex, LxULong flags, char* inType, char* outType);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * General Channel Value Sub-Chunk - for writing channel values by channel index
 *----------------------------------------------------------------------------*/
class LxoChannelValueSubChunk : public LxoSubChunk {

        LxResult    Write (LxULong index, LxULong envelopeIndex, LxUShort type);

    public:
        LxoChannelValueSubChunk (LxoWriteData* writer) : LxoSubChunk ('CHAN', writer) {}

        LxResult    Write (LxULong index,    int          value, LxULong envelopeIndex = 0);
        LxResult    Write (LxULong index,    float        value, LxULong envelopeIndex = 0);
        LxResult    Write (LxULong index,    char const*  value, LxULong envelopeIndex = 0);

        LxResult    Write (const char* name, int          value, LxULong envelopeIndex = 0)
                        {
                        return Write (m_writer->GetChannelIndex (name), value, envelopeIndex);
                        }
        LxResult    Write (const char* name, float        value, LxULong envelopeIndex = 0)
                        {
                        return Write (m_writer->GetChannelIndex (name), value, envelopeIndex);
                        }
        LxResult    Write (const char* name, char const*  value, LxULong envelopeIndex = 0)
                        {
                        return Write (m_writer->GetChannelIndex (name), value, envelopeIndex);
                        }
};

/*------------------------------- Luxology LLC --------------------------- 06/15
 * General Action Value Sub-Chunk - for writing channel values to actions.
 * Just like LxoChannelValueSubChunk, except we always write the envelope index.
 *----------------------------------------------------------------------------*/
class LxoActionValueSubChunk : public LxoSubChunk {

        LxResult    Write (LxULong index, LxULong envelopeIndex, LxUShort type);

    public:
        LxoActionValueSubChunk (LxoWriteData* writer) : LxoSubChunk ('CHAN', writer) {}

        LxResult    Write (LxULong index,    int          value, LxULong envelopeIndex = 0);
        LxResult    Write (LxULong index,    float        value, LxULong envelopeIndex = 0);
        LxResult    Write (LxULong index,    char const*  value, LxULong envelopeIndex = 0);

        LxResult    Write (const char* name, int          value, LxULong envelopeIndex = 0)
                        {
                        return Write (m_writer->GetChannelIndex (name), value, envelopeIndex);
                        }
        LxResult    Write (const char* name, float        value, LxULong envelopeIndex = 0)
                        {
                        return Write (m_writer->GetChannelIndex (name), value, envelopeIndex);
                        }
        LxResult    Write (const char* name, char const*  value, LxULong envelopeIndex = 0)
                        {
                        return Write (m_writer->GetChannelIndex (name), value, envelopeIndex);
                        }
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Item Tag Sub-Chunk
 *----------------------------------------------------------------------------*/
class LxoItemTagSubChunk : public LxoSubChunk {
    public:
        LxoItemTagSubChunk (LxoWriteData* writer) : LxoSubChunk ('ITAG', writer) {}

        LxResult    Write (LXtID4 type, char const* tag);
};

/*------------------------------- Luxology LLC --------------------------- 06/15
 * Parent Sub-Chunk
 *----------------------------------------------------------------------------*/
class LxoParentSubChunk : public LxoSubChunk {
    public:
        LxoParentSubChunk (LxoWriteData* writer) : LxoSubChunk ('PRNT', writer) {}

        LxResult    Write (LxULong parentItemId) { return m_writer->WriteLong (parentItemId); }
};

/*------------------------------- Luxology LLC --------------------------- 06/15
 * Item Sub-Chunk - to point to items within actions
 *----------------------------------------------------------------------------*/
class LxoItemSubChunk : public LxoSubChunk {
    public:
        LxoItemSubChunk (LxoWriteData* writer) : LxoSubChunk ('ITEM', writer) {}

        LxResult    Write (LxULong itemId) { return m_writer->WriteLong (itemId); }
};

/*******************************************************************************
 *
 * The folowing classes define primary data chunks
 *
 ******************************************************************************/

/*------------------------------- Luxology LLC --------------------------- 03/09
 * File Chunk - header for whole file
 *----------------------------------------------------------------------------*/
class LxoFileChunk : public LxoChunk {
    public:
        LxoFileChunk (LxoWriteData* writer) : LxoChunk ('FORM', writer) {}

        LxResult    Write () { return LXe_OK == m_writer->WriteLong ('LXOB') ? CloseChunk (): m_result; }
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Version Chunk - file version & applicationstring
 *----------------------------------------------------------------------------*/
class LxoVersionChunk : public LxoChunk {
    public:
        LxoVersionChunk (LxoWriteData* writer) : LxoChunk ('VRSN', writer) {}

        LxResult    Write (LxULong major, LxULong minor, char const* appString);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Channel Names Chunk - file version & applicationstring
 *----------------------------------------------------------------------------*/
class LxoChannelNamesChunk : public LxoChunk {
    public:
        LxoChannelNamesChunk (LxoWriteData* writer) : LxoChunk ('CHNM', writer) {}

        LxResult    Write () { return LXe_OK == m_writer->WriteChannels () ? CloseChunk (): m_result; }
        LxResult    Write (LXtStringVec fileChannels, LxULong count)
                            { return LXe_OK == m_writer->WriteChannels (fileChannels, count) ? CloseChunk (): m_result; }
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Tags Chunk - assorted named tags
 *----------------------------------------------------------------------------*/
class LxoTagsChunk : public LxoChunk {
    public:
        LxoTagsChunk (LxoWriteData* writer) : LxoChunk ('TAGS', writer) {}

        LxResult    Write () { return LXe_OK == m_writer->WriteTags () ? CloseChunk (): m_result; }
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * PolyTag Chunk - assorted named tags
 *----------------------------------------------------------------------------*/
class LxoPolyTagChunk : public LxoChunk {
    public:
        LxoPolyTagChunk (LxoWriteData* writer) : LxoChunk ('PTAG', writer) {}

        LxResult    Write (LXtID4 id, LxUShort polyId, char const* name);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Text Tag Chunk - write a text srting with an ID
 *----------------------------------------------------------------------------*/
class LxoTextTagChunk : public LxoChunk {
    public:
        LxoTextTagChunk (LxoWriteData* writer) : LxoChunk ('TTGS', writer) {}

        LxResult    Write (LXtID4 id, char const* name);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Layer Chunk - write a layer chunk to group curves
 *----------------------------------------------------------------------------*/
class LxoLayerChunk : public LxoChunk {
    public:
        LxoLayerChunk (LxoWriteData* writer) : LxoChunk ('LAYR', writer) {}

        LxResult    Write (LXtLayerChunk& layer);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * 3D Group Chunk - Information about a group of surfaces
 *----------------------------------------------------------------------------*/
class Lxo3dGroupChunk : public LxoChunk {
    public:
        Lxo3dGroupChunk (LxoWriteData* writer) : LxoChunk ('3GRP', writer) {}

        LxResult    Write (LxULong nSurfs, LxULong surfItemIndex, LxULong unused = 0);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * 3D Surface Chunk - Information about a surface
 *----------------------------------------------------------------------------*/
class Lxo3dSurfaceChunk : public LxoChunk {
    public:
        Lxo3dSurfaceChunk (LxoWriteData* writer) : LxoChunk ('3SRF', writer) {}

        LxResult    Write (LxULong nVerts, LxULong nTris, LxULong nVects, LxULong nTags, LxULong unused = 0);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Polygons Chunk - list of "polygons" that make up a curve or line string
 *----------------------------------------------------------------------------*/
class LxoPolygonsChunk : public LxoChunk {
    public:
        LxoPolygonsChunk (LxoWriteData* writer) : LxoChunk ('POLS', writer) {}

        LxResult    Write (LxULong* verts, LxUShort nSegments, LxULong nVertsPerSegment);
        LxResult    Write (LxULong nPoints);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Vertex Chunk - Write out array of vertices
 *----------------------------------------------------------------------------*/
class LxoVertexChunk : public LxoChunk {
    public:
        LxoVertexChunk (LxoWriteData* writer) : LxoChunk ('VRTS', writer) {}

        LxResult    Write (LXtFVector* verts, LxULong nVerts);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Vertex Map Chunk - Write out a vertex map
 *----------------------------------------------------------------------------*/
class LxoVertexMapChunk : public LxoChunk {
    public:
        LxoVertexMapChunk (LxoWriteData* writer) : LxoChunk ('VMAP', writer) {}

        LxResult    Write (float* verts, LxULong nVerts, LxUShort valsPerVert,
                           LXtID4 id = 'XFRM', const char *name = "Transform");
};

/*------------------------------- Luxology LLC --------------------------- 03/12
 * Discontinuous Vertex Map Chunk - Write out a vertex map
 *----------------------------------------------------------------------------*/
class LxoVertexMapDiscChunk : public LxoChunk {
    public:
        LxoVertexMapDiscChunk (LxoWriteData* writer) : LxoChunk ('VMAD', writer) {}

        LxResult    Write (float* verts, LxULong* vInds, LxULong* pInds, LxULong nVerts, LxUShort valsPerVert,
                           LXtID4 id = 'XFRM', const char *name = "Transform");
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Points Chunk - Write out array of points - Z reversed in LightWave format
 *----------------------------------------------------------------------------*/
class LxoPointsChunk : public LxoChunk {
    public:
        LxoPointsChunk (LxoWriteData* writer) : LxoChunk ('PNTS', writer) {}

        LxResult    Write (LXtFVector* points, LxULong nPoints);
        LxResult    Write (LXtFVector point);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Vector Chunk - Write out n-dimensional arrays
 *----------------------------------------------------------------------------*/
class LxoVectorChunk : public LxoChunk {
    public:
        LxoVectorChunk (LxoWriteData* writer) : LxoChunk ('VVEC', writer) {}

        LxResult    Write (LXtID4 id, char const* name, float* verts, LxULong nDims, LxULong nFloats);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Triangles Chunk - Write out triples of indices into the array of vertices
 *----------------------------------------------------------------------------*/
class LxoTrianglesChunk : public LxoChunk {
    public:
        LxoTrianglesChunk (LxoWriteData* writer) : LxoChunk ('TRIS', writer) {}

        LxResult    Write (LXtUVector* tris, LxULong nTris);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Envelope Chunk - Keys for animation
 *----------------------------------------------------------------------------*/
class LxoEnvelopeChunk : public LxoChunk {
    public:
        LxoEnvelopeChunk (LxoWriteData* writer) : LxoChunk ('ENVL', writer) {}

        LxResult            Write (LxULong type, LxULong envelopeId = 0);
        LxResult            Write (LxULong type, LxULong envelopeId, LxByte* data, LxULong bytes);

        virtual LxResult    WriteData () { return LXe_OK; }
};

/*******************************************************************************
 *
 * The folowing classes define the various types of item chunks
 *
 ******************************************************************************/

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Translation Chunk - apply translation to another chunk
 *----------------------------------------------------------------------------*/
class LxoTranslationItemChunk : public LxoChunk {
    public:
        LxoTranslationItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong linkId, LxULong linkIndex, LXtFVector translate, char const* name = NULL);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Rotation Chunk - apply rotation to another chunk, the 'order' string defines
 * the order in which the angles are applied, such as "yzx".
 *----------------------------------------------------------------------------*/
class LxoRotationItemChunk : public LxoChunk {
    public:
        LxoRotationItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong linkId, LxULong linkIndex, LXtFVector angles, char const* name = NULL, char const* order = NULL);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Scale Chunk - apply scale to another chunk
 *----------------------------------------------------------------------------*/
class LxoScaleItemChunk : public LxoChunk {
    public:
        LxoScaleItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong linkId, LxULong linkIndex, LXtFVector scale, char const* name = NULL);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Surface Chunk - information about a surface
 *----------------------------------------------------------------------------*/
class LxoSurfaceItemChunk : public LxoChunk {
    public:
        LxoSurfaceItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong layerId, LxULong parentId, LxULong parentIndex);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Mesh Item Chunk - information about the current mesh
 *----------------------------------------------------------------------------*/
class LxoMeshItemChunk : public LxoChunk {
    public:
        LxoMeshItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong layerIndex, char const* layerName, float radius);
        LxResult    Write (LxULong layerIndex, char const* layerName, LxULong replicatorIndex);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Mesh Item Chunk - information about the current mesh
 *----------------------------------------------------------------------------*/
class LxoReplicatorItemChunk : public LxoChunk {
    public:
        LxoReplicatorItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong linkItemId, char const* name = "");
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Scene Chunk - animation settings for the scene
 *----------------------------------------------------------------------------*/
class LxoSceneItemChunk : public LxoChunk {
    public:
        LxoSceneItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write ();
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Render Settings Chunk - top-level render settings
 *----------------------------------------------------------------------------*/
class LxoPolyRenderItemChunk : public LxoChunk {
    public:
        LxoPolyRenderItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXtRenderSettings& settings, LxULong cameraId, LxULong cameraIndex, bool useDefaults);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Render Output Settings Chunk - output settings
 *----------------------------------------------------------------------------*/
class LxoRenderOutputItemChunk : public LxoChunk {
    public:
        LxoRenderOutputItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXtRenderSettings& settings, char const* name, char const* effectName);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Environment Chunk - visibility of environment
 *----------------------------------------------------------------------------*/
class LxoEnvironmentItemChunk : public LxoChunk {
    public:
        LxoEnvironmentItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXtRenderSettings& settings);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Sky Environment Item Chunk - data for the sky environment
 *----------------------------------------------------------------------------*/
class LxoSkyEnvironmentItemChunk : public LxoChunk {
    public:
        LxoSkyEnvironmentItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong environmentId, LxULong environmentIndex, LxULong sunlightId, float solarDiskSize, char const* name, int skyCover, float weight);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Sky Environment Item Chunk - data for the sky environment
 *----------------------------------------------------------------------------*/
class LxoGradientEnvironmentItemChunk : public LxoChunk {
    public:
        LxoGradientEnvironmentItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    WriteBody (LxULong environmentId, LxULong environmentIndex, LXtFVector zenithColor, LXtFVector nadirColor);

        LxResult    Write (LxULong environmentId, LxULong environmentIndex, LXtFVector zenithColor, LXtFVector nadirColor);
        LxResult    Write (LxULong environmentId, LxULong environmentIndex, LXtFVector zenithColor, LXtFVector nadirColor, LXtFVector skyColor, LXtFVector groundColor, float skyExp, float groundExp);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Camera Chunk - camera info
 *----------------------------------------------------------------------------*/
class LxoCameraItemChunk : public LxoChunk {
    public:
        LxoCameraItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXtCamera& camera, char const* name);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Shader Chunk - shading attributes of an item
 *----------------------------------------------------------------------------*/
class LxoShaderItemChunk : public LxoChunk {
    public:
        LxoShaderItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (char const* name, LxULong maskId, LxULong maskIndex, LXpShadeFlags* shader = NULL);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Video Still Chunk - identifies image file on disk
 *----------------------------------------------------------------------------*/
class LxoVideostillItemChunk : public LxoChunk {
    public:
        LxoVideostillItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (char const* name);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Texture Locator Chunk - defines the mapping type for a texure
 *----------------------------------------------------------------------------*/
class LxoTextureLocatorItemChunk : public LxoChunk {
    public:
        LxoTextureLocatorItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (int tileModeU, int tileModeV, int projectMode, char const* uvMapName = NULL);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Image Map Chunk - associates texture locators & video stills with a material
 *----------------------------------------------------------------------------*/
class LxoImageMapItemChunk : public LxoChunk {
    public:
        LxoImageMapItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXtMaterialLayer& layer, LxULong maskId, LxULong maskIndex, LxULong textureLocatorId);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Constant Color Chunk - used as a layer of a material
 *----------------------------------------------------------------------------*/
class LxoConstantColorItemChunk : public LxoChunk {
    public:
        LxoConstantColorItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LxULong linkId, LxULong linkIndex, LXtFVector color, int mapType, int blendType = LXBlend_Normal, float opacity = 1.0f, LxULong alphaMapId = 0);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Mask Chunk - associates a group (typically material) with element
 *----------------------------------------------------------------------------*/
class LxoMaskItemChunk : public LxoChunk {
    public:
        LxoMaskItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (char const* name, LxULong parentId, LxULong parentIndex, char const* partType = NULL);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Material Chunk - material data
 *----------------------------------------------------------------------------*/
class LxoMaterialItemChunk : public LxoChunk {
    public:
        LxoMaterialItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXtMaterial& material, LxULong maskId, LxULong maskIndex);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Fur Material Chunk - fur material data
 *----------------------------------------------------------------------------*/
class LxoFurMaterialItemChunk : public LxoChunk {
    public:
        LxoFurMaterialItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXpFurParms& fur, char const* name, LxULong maskId, LxULong maskIndex);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 * Light Material Chunk - color & effects information for a light
 *----------------------------------------------------------------------------*/
class LxoLightMaterialItemChunk : public LxoChunk {
    public:
        LxoLightMaterialItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (char const* name, LXtLightInfo& light);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Light Chunk - light position, direction, etc.
 *----------------------------------------------------------------------------*/
class LxoLightItemChunk : public LxoChunk {
    public:
        LxoLightItemChunk (LxoWriteData* writer) : LxoChunk ('ITEM', writer) {}

        LxResult    Write (LXtLightInfo& light);
};

/*------------------------------- Luxology LLC --------------------------- 06/15
 * Action Chunk - for setup, edit & scene actions
 *----------------------------------------------------------------------------*/
class LxoActionChunk : public LxoChunk {
    public:
        LxoActionChunk (LxoWriteData* writer, char const* name, LxULong actionId) : LxoChunk ('ACTN', writer) {
                m_writer->WriteItemHeader (name, name, actionId);
        }

        LxResult    Write () { return LXe_OK == m_writer->WriteLong ('LXOB') ? CloseChunk (): m_result; }
        LxResult    Close () { return CloseChunk (); }
};


