/*
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

// Ensure that the following definition is in effect before winuser.h is included.
//#define _WIN32_WINNT 0x0502
//#undef NOSYSCOMMANDS

#include <windows.h>
#include <windowsx.h>
#include <winuser.h>
#include <wincodec.h>
#include <wingdi.h>

#include <queue>
#include <stdio.h>
#include <direct.h>
#include <lximage.h>
#include "lxoCommand.hpp"

#pragma comment(lib, "shell32")

static LXtCamera    defaultCamera = { LXCameraType_Perspective,   // projection
                                      { 25.f,  9.f, 25.f },       // position
                                      { -5.f * s_degreesToRads,   // rotation (in degrees)
                                        45.f * s_degreesToRads,
                                         5.f * s_degreesToRads},
                                      10.f,                       // focalDistance

                                      0.050f,                     // focalLength - 50 mm
                                      0.036f,                     // filmWidth - 36mm
                                      0.036f,                     // filmHeight - assume square aspect

                                      { 0.f, 0.f },               // offset
                                      4.f,                        // fstop
                                      0.f,                        // lensDistortion
                                    };

class   TestListener;

struct MouseCoord { short x, y; };

union MouseUnion {
            int             i32;
            MouseCoord      m;
            };

typedef     std::queue<int>    MouseQueue;

typedef struct
    {
    HINSTANCE           hInst;
    int                 nCmdShow;
    UINT                timerInterval;
    HWND                hwndContainer;
    HWND                hwndPreview;
    HDC                 hdcPreview;
    RECT                containerRect;
    RECT                previewRect;

    LxByte*             imageBufferP;
    int                 imageSizeX, imageSizeY;
    LXtFVector          camPos, camDir;
    float               camFocal;
    bool                sendCamera;
    bool                finalCamera;
    MouseQueue          mouseQueue;
    int                 samples;
    int                 quality;
    int                 draftQuality;
    int                 stereoMode;
    bool                floatRgb;
    char                effect[256];
    double              aspect;
    double              fracComplete;
    HDC                 hdcCompat;

    LxoCommand*         cmdP;
    LxoManager*         mgrP;
    TestListener*       listenerP;

    int                 nexusIP;
    int                 previewPort, telnetPort;
    char                previewPipe[256];

    HANDLE              threadLockSemaphore;

    } WinData;

static  WinData         s_winData;

enum
    {
    STYLE_RestoredWindow    = WS_SIZEBOX | WS_SYSMENU | WS_CLIPCHILDREN | WS_CAPTION | WS_EX_APPWINDOW | WS_MAXIMIZEBOX,
    STYLE_Container         = WS_EX_LAYERED,
    ORIGIN_X                = 400,
    ORIGIN_Y                = 400,
    SIZE_X                  = 400,
    SIZE_Y                  = 400,
    TIMER_Interval          = 16,        // close to the refresh rate @60hz

    STEREO_Off              = 0,
    STEREO_LeftEye          = 1,
    STEREO_RightEye         = 2,
    STEREO_MaxMode          = STEREO_RightEye,

    QUALITY_Default         = 0,
    QUALITY_Draft           = 1,
    QUALITY_Final           = 2,
    QUALITY_Extended        = 3,
    };

// #define DEBUG_PRINTS    1
#if DEBUG_PRINTS
FILE* fp;
#endif

/*------------------------------- Luxology LLC --------------------------- 10/09
 *
 * Fill the window with a solid color
 *
 *----------------------------------------------------------------------------*/
        static int
RenderQuality (WCHAR c)
{
        if ('d' == c || 'D' == c)
            return QUALITY_Draft;

        if ('f' == c || 'F' == c)
            return QUALITY_Final;

        if ('e' == c || 'E' == c)
            return QUALITY_Extended;

        return QUALITY_Default;
}

/*------------------------------- Luxology LLC --------------------------- 10/09
 *
 * Fill the window with a solid color
 *
 *----------------------------------------------------------------------------*/
        static void 
fillRect (int color)
{
    HBRUSH      hBrush  = CreateSolidBrush (color);
    HDC         hdc     = GetDC (s_winData.hwndPreview); 

    FillRect (hdc, &s_winData.previewRect, hBrush);

    if (hBrush)
        DeleteObject (hBrush);

    ReleaseDC (s_winData.hwndPreview, hdc);
}

/*------------------------------- Luxology LLC --------------------------- 10/09
 *
 * Fill the window from an image buffer
 *
 *----------------------------------------------------------------------------*/
        static void 
copyRect (LxByte* buffer, int sizeX, int sizeY)
{
    static HBITMAP      s_bitMap;
    static int          s_mapSizeX = -1, s_mapSizeY;

    BITMAPINFO          bmInfo;
    BITMAPINFOHEADER*   bmihP;
    void*               dibBitsP = NULL;

    bmihP                       = &bmInfo.bmiHeader;
    bmihP->biSize               = sizeof bmInfo.bmiHeader;

    bmihP->biPlanes             = 1;
    bmihP->biBitCount           = 24;
    bmihP->biCompression        = BI_RGB;       // uncompressed
    bmihP->biXPelsPerMeter      = 1024;
    bmihP->biYPelsPerMeter      = 1024;
    bmihP->biClrUsed            = 0;            // no color table entries used
    bmihP->biClrImportant       = 0;
    bmihP->biSizeImage          = 0;

    bmihP->biWidth              =  sizeX;
    bmihP->biHeight             = -sizeY;       // flip the image in Y

    if (NULL == s_bitMap || sizeX != s_mapSizeX || sizeY != s_mapSizeY)
        {
        if (s_bitMap)
            DeleteObject (s_bitMap);

        if (NULL == (s_bitMap = CreateDIBSection (s_winData.hdcPreview, &bmInfo, DIB_RGB_COLORS, &dibBitsP, NULL, 0)))
            return;

        s_mapSizeX = sizeX;
        s_mapSizeY = sizeY;
        }

    SelectObject (s_winData.hdcCompat, s_bitMap);

#if DEBUG_PRINTS
    fprintf(fp, "%d: STRETCH: %d x %d\n", GetTickCount(), s_winData.previewRect.right, s_winData.previewRect.bottom); fflush (fp);
#endif

    StretchDIBits (s_winData.hdcPreview, 0, 0, s_winData.previewRect.right, s_winData.previewRect.bottom,
                   0, 0, sizeX, sizeY, buffer, &bmInfo, DIB_RGB_COLORS, SRCCOPY);
}

/*------------------------------- Luxology LLC --------------------------- 09/09
 *
 * Example listener overriding functionality of the default listener
 *
 *----------------------------------------------------------------------------*/
class   TestListener : public LxoListener
{
        virtual LxResult    Listen () override;
};

/*------------------------------- Luxology LLC --------------------------- 09/09
 *
 * This example simply allows the base class to wait for the results, but
 * prints the results and status messages.  This can eventually be extended
 * to things like progress monitors or intermediate image display.
 *
 *----------------------------------------------------------------------------*/
    LxResult
TestListener::Listen ()
{
    fillRect (0xff0000);
    printf ("\nWaiting for Output: %s\n", m_outputFile);

    LxResult    result = __super::Listen ();        // do all normal waiting/processing of the output

    // print out any status messages
    printf ("\nresult: %d\tFile: %s\n\n%s\n", result, m_outputFile, m_mgr->GetCommandLog().c_str ());
    m_mgr->GetCommandLog().clear ();

    int     sizeX = 100, sizeY = 100;

    if (LXe_OK == result)
        {
        if (NULL == s_winData.imageBufferP || sizeX != s_winData.imageSizeX || sizeY != s_winData.imageSizeY)
            {
            if (s_winData.imageBufferP)
                free (s_winData.imageBufferP);

            if (NULL == (s_winData.imageBufferP = (LxByte*) malloc (sizeX * sizeY * 4)))
                return LXe_OUTOFMEMORY;

            s_winData.imageSizeX = sizeX;
            s_winData.imageSizeY = sizeY;
            }

        // test code: make a random gradient buffer
        static int  s_trip = 0;

        s_trip ^= 1;
        LxByte*     bufP = s_winData.imageBufferP;
        for (int x = 0; x < sizeX; ++x)
            for (int y = 0; y < sizeY; ++y)
                {
                *bufP++ = 0xff & (s_trip ? x + x : y + y);
                *bufP++ = 0xff & (s_trip ? y + y : x + y);
                *bufP++ = 0xff & (s_trip ? x + y : x + x);
                *bufP++ = 0;
                }

        copyRect (s_winData.imageBufferP, s_winData.imageSizeX, s_winData.imageSizeY);
        }
    else
        fillRect (0x0000ff);

    return result;
}

/*------------------------------- Luxology LLC --------------------------- 10/09
 *
 * render the next image in the sequence
 *
 *----------------------------------------------------------------------------*/
    static LxResult
generateNextImage ()
{
    // camera setup for next view of same file
    LXtCamera       modifiedCamera = defaultCamera;

    modifiedCamera.position[0] = 30.f;
    modifiedCamera.position[1] =  7.f;
    modifiedCamera.position[2] =  3.f;

    modifiedCamera.rotation[0] =   0.f * s_degreesToRads;
    modifiedCamera.rotation[1] =  90.f * s_degreesToRads;
    modifiedCamera.rotation[2] =  10.f * s_degreesToRads;

    s_winData.cmdP->Clear ();                                           // clear to set a new command sequence
    s_winData.cmdP->SetCamera (modifiedCamera, NULL);
    s_winData.cmdP->RenderToFile (s_winData.mgrP->GetBucketDir ());     // perform the render, using buckets

    return s_winData.mgrP->Run (*s_winData.cmdP);   // run render, synchrounously wait for result unless listener is present
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Redraw the window.  We need to lock the semaphore to ensure that the
 * thread doesn't try to change the image while we're drawing.
 *
 *----------------------------------------------------------------------------*/
    void 
UpdatePreviewLocked (HWND hWnd)
{
    WaitForSingleObject (s_winData.threadLockSemaphore, INFINITE);

    if (s_winData.imageBufferP)
        {
        copyRect (s_winData.imageBufferP, s_winData.imageSizeX, s_winData.imageSizeY);
        ValidateRect (hWnd, NULL);
        }

    ReleaseSemaphore (s_winData.threadLockSemaphore, 1, NULL);
}

/*------------------------------- Luxology LLC --------------------------- 10/09
 *
 * Windows callbacks for preview window. We can watch for mouse movements here.
 *
 *----------------------------------------------------------------------------*/
LRESULT CALLBACK HostWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    enum    {
            MOUSEDOWN_None = 0,
            MOUSEDOWN_Left,
            MOUSEDOWN_Right,
            };

    static int          mouseDown = MOUSEDOWN_None;
    static MouseUnion   lastMousePos;
    MouseUnion          mousePos;

    switch (message)
        {
        case WM_LBUTTONDOWN:    // left mouse down -- start preview under mouse
            mouseDown = MOUSEDOWN_Left;
            mousePos.m.x = GET_X_LPARAM (lParam);
            mousePos.m.y = GET_Y_LPARAM (lParam);
            s_winData.mouseQueue.push (mousePos.i32);
            break;

        case WM_LBUTTONUP:      // left mouse up -- preview under mouse
            mouseDown = MOUSEDOWN_None;
            break;

        case WM_RBUTTONDOWN:    // right mouse down -- start navigation
            lastMousePos.m.x = GET_X_LPARAM (lParam);
            lastMousePos.m.y = GET_Y_LPARAM (lParam);
            mouseDown = MOUSEDOWN_Right;
            s_winData.finalCamera = false;
            break;

        case WM_RBUTTONUP:      // right mouse up -- end navigation & set camera
            mouseDown = MOUSEDOWN_None;
            s_winData.sendCamera = s_winData.finalCamera = true;
            break;

        case WM_MOUSEMOVE:
            switch (mouseDown)
                {
                case MOUSEDOWN_Left:
                    /* If the left mouse is down while moving, add the mouse pos to a queue to be processed
                     * in the preview thread. Note that it's probably a good idea to 'thin' out the list
                     * of points, making sure that we don't queue the same point twice in a row, and
                     * don't queue too many points at once. You might even want to wrap a semaphore
                     * around the queue push & pops to make sure there aren't any problems when one thread
                     * is reading from the queue while the other is writing.
                     */
                    mousePos.m.x = GET_X_LPARAM (lParam);
                    mousePos.m.y = GET_Y_LPARAM (lParam);
                    s_winData.mouseQueue.push (mousePos.i32);
                    break;

                case MOUSEDOWN_Right:
                    /* Use the right mouse button to control camera pos, rotation & focal length.
                     * Change XY position with no modifier, ZY position with CTRL+SHIFT, rotation
                     * with SHIFT, and focal legth with CTRL.
                     *
                     * The code is here is really just a hacky way of adjusting values, and is really
                     * specific to my test scene, and is merely provided as an example to illustrate
                     * performance, although the views will often be useless.
                     */
                    static float const      angleIncrement = (float)(LXx_DEG2RAD * 0.1);

                    mousePos.m.x = GET_X_LPARAM (lParam);
                    mousePos.m.y = GET_Y_LPARAM (lParam);

                    bool    isShift = 0 != (wParam & MK_SHIFT);
                    bool    isCtrl  = 0 != (wParam & MK_CONTROL);

                    if (isShift && isCtrl)      // update ZY position
                        {
                        if (mousePos.m.x != lastMousePos.m.x)
                            s_winData.camPos[2] *= mousePos.m.x > lastMousePos.m.x ? 1.01f : 1.0f / 1.01f;

                        if (mousePos.m.y != lastMousePos.m.y)
                            s_winData.camPos[1] *= mousePos.m.y > lastMousePos.m.y ? 1.01f : 1.0f / 1.01f;
                        }
                    else if (isShift)           // update rotation
                        {
                        if (mousePos.m.x != lastMousePos.m.x)
                            s_winData.camDir[1] += mousePos.m.x > lastMousePos.m.x ? angleIncrement : -angleIncrement;

                        if (mousePos.m.y != lastMousePos.m.y)
                            {
                            s_winData.camDir[0] += mousePos.m.y > lastMousePos.m.y ? angleIncrement : -angleIncrement;
                            s_winData.camDir[2] += mousePos.m.y > lastMousePos.m.y ? angleIncrement : -angleIncrement;
                            }
                        }
                    else if (isCtrl)            // update focal length
                        {
                        if (mousePos.m.y != lastMousePos.m.y)
                            s_winData.camFocal *= (mousePos.m.y < lastMousePos.m.y ? 1.01f : 1.0f / 1.01f);
                        }
                    else                        // update XY position
                        {
                        if (mousePos.m.x != lastMousePos.m.x)
                            s_winData.camPos[0] *= mousePos.m.x > lastMousePos.m.x ? 1.01f : 1.0f / 1.01f;

                        if (mousePos.m.y != lastMousePos.m.y)
                            s_winData.camPos[1] *= mousePos.m.y > lastMousePos.m.y ? 1.01f : 1.0f / 1.01f;
                        }

                    lastMousePos.m = mousePos.m;
                    s_winData.sendCamera = true;
                    break;
                }
            break;

        case WM_SYSCOMMAND:
            {
            int     maskedValue = (int)wParam & 0xFFF0;

            if (SC_RESTORE == maskedValue)
                return ShowWindow (s_winData.hwndContainer, SW_RESTORE);

            if (SC_MAXIMIZE == maskedValue)
                return ShowWindow (s_winData.hwndContainer, SW_MAXIMIZE);

            return DefWindowProc (hWnd, message, wParam, lParam);
            }

        case WM_DESTROY:
            PostQuitMessage (0);        // queue the message to exit
            break;

        case WM_SIZE:
            if (s_winData.hwndPreview != NULL)
                {
                RECT    newRect;

                GetClientRect (hWnd, &newRect);

                if (0 != s_winData.aspect)      // enforce the aspect ratio of the previewer
                    {
                    bool    adjustWindow;

                    // preserve the aspect ratio, but fix the size with the greatest change
                    int     diffX = newRect.right  - s_winData.previewRect.right;
                    int     diffY = newRect.bottom - s_winData.previewRect.bottom;

                    if (diffX < 0)
                        diffX = -diffX;
                    if (diffY < 0)
                        diffY = -diffY;

                    if (diffX >= diffY)
                        {
                        int     newSize = (int)(0.5 + newRect.right / s_winData.aspect);
                        if (adjustWindow = (newRect.bottom != newSize))
                            newRect.bottom = newSize;
                        }
                    else
                        {
                        int     newSize = (int)(0.5 + newRect.bottom * s_winData.aspect);
                        if (adjustWindow = (newRect.right != newSize))
                            newRect.right = newSize;
                        }

                    if (adjustWindow)
                        {
                        AdjustWindowRectEx (&newRect, STYLE_RestoredWindow, FALSE, STYLE_Container);

                        newRect.right  -= newRect.left;         // subtract origin to get adjusted rect width
                        newRect.bottom -= newRect.top;

                        GetWindowRect (s_winData.hwndContainer, &s_winData.containerRect);      // get latest position

                        newRect.left    = s_winData.containerRect.left;     // don't move the window, just resize it
                        newRect.top     = s_winData.containerRect.top;

                        SetWindowPos (s_winData.hwndContainer, NULL, newRect.left, newRect.top, newRect.right, newRect.bottom, 0);

                        GetClientRect (hWnd, &newRect);
                        }
                    }

                s_winData.previewRect = newRect;

                // Resize the control to fill the window.
                SetWindowPos (s_winData.hwndPreview, NULL, s_winData.previewRect.left, s_winData.previewRect.top, s_winData.previewRect.right, s_winData.previewRect.bottom, 0);

#if DEBUG_PRINTS
                fprintf(fp, "%d: SIZE\t", GetTickCount());
#endif
                UpdatePreviewLocked (hWnd);     // Redraw with semaphore to block threads from changing the image
                }
            break;

        case WM_PAINT:
            UpdatePreviewLocked (hWnd);     // Redraw with semaphore to block threads from changing the image
            break;

        default:
            return DefWindowProc (hWnd, message, wParam, lParam);
        }

    return 0;
}

/*------------------------------- Luxology LLC --------------------------- 10/09
 *
 * Create the application window
 *
 *----------------------------------------------------------------------------*/
    static LxResult
InitPreviewWindow (WinData& wData)
{
    const TCHAR     WindowClassName[]   = TEXT ("LuxologyPreview");
    const TCHAR     WindowTitle[]       = TEXT ("Luxology Preview Window");

    // Set bounds of host window according to screen size.
    wData.containerRect.top     = ORIGIN_X;
    wData.containerRect.bottom  = SIZE_X + wData.containerRect.top;
    wData.containerRect.left    = ORIGIN_Y;
    wData.containerRect.right   = SIZE_Y + wData.containerRect.left;

    wData.timerInterval         = TIMER_Interval;

    WNDCLASSEX      wcex = {};

    wcex.cbSize         = sizeof (WNDCLASSEX); 
    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = HostWndProc;
    wcex.hInstance      = wData.hInst;
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(1 + COLOR_BTNFACE);
    wcex.lpszClassName  = WindowClassName;

    RegisterClassEx(&wcex);

    // Create the host container window.
    wData.hwndContainer = CreateWindowEx (STYLE_Container, WindowClassName, WindowTitle, STYLE_RestoredWindow,
                                          wData.containerRect.left,  wData.containerRect.top, SIZE_X, SIZE_Y,
                                          NULL, NULL, wData.hInst, NULL);
    if (NULL == wData.hwndContainer)
        return LXe_FAILED;

    // Make the window opaque.
    SetLayeredWindowAttributes (wData.hwndContainer, 0, 255, LWA_ALPHA);

    // Create the preview window.
    GetClientRect (wData.hwndContainer, &wData.previewRect);    // returns 0, 0, height, width
    wData.hwndPreview = CreateWindow (WindowClassName, TEXT("PreviewContentsWindow"), WS_CHILD | WS_VISIBLE,
                                      wData.previewRect.left, wData.previewRect.top, wData.previewRect.right, wData.previewRect.bottom,
                                      wData.hwndContainer, NULL, wData.hInst, NULL );

    if (NULL == wData.hwndPreview)
        return LXe_FAILED;

    ShowWindow (wData.hwndContainer, wData.nCmdShow);
    UpdateWindow (wData.hwndContainer);

    // Create a device context (DC) to hold the bitmap.
    // The bitmap is copied from this DC to the window's DC
    // whenever it must be drawn.

    s_winData.hdcPreview  = GetDC (s_winData.hwndPreview); 
    s_winData.hdcCompat   = CreateCompatibleDC (s_winData.hdcPreview);
    SelectObject (s_winData.hdcCompat, LoadBitmap (s_winData.hInst, MAKEINTRESOURCE(1)));

    SetICMMode (s_winData.hdcPreview, ICM_DONE_OUTSIDEDC);
    SetICMMode (s_winData.hdcCompat, ICM_DONE_OUTSIDEDC);
    RealizePalette (s_winData.hdcCompat);

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/16
 *
 * Fill demo progress bar with green strip at top of image
 *
 *----------------------------------------------------------------------------*/
    static void
FillProgressBar (void)
{
    int         w        = s_winData.imageSizeX;
    int         rowBytes = ((3 * w + 3) / 4) * 4;      // longword alligned bytes per output row

    // for demo purposes, draw a green line across the top of the window to show progress
    for (int y = 0; y < 3; ++y)
        for (int x = w * s_winData.fracComplete; x >= 0; --x)
            {
            LxByte*     pixelP = &s_winData.imageBufferP[x * 3 + y * rowBytes];
            pixelP[0] = 0;
            pixelP[1] = 255;
            pixelP[2] = 0;
            }
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * This is the actual thread function, which deals with all network
 * communication on the preview port.
 *
 * You'll notice this function uses PostMessage(WM_QUIT) instead of
 * PostQuitMessage().  This is because PostQuitMessage() sends the message to
 * this thread, which isn't what we want; we need it sent to the main window.
 * While using PostMessage(WM_QUIT) isn't really the proper way to do this,
 * it works well enough.
 *
 *----------------------------------------------------------------------------*/
    DWORD WINAPI 
PreviewNetworkThread (LPVOID unused)
{
    static int      s_previewX, s_previewY = -1;
    LxoPreviewer    preview (s_winData.previewPipe, s_winData.nexusIP, s_winData.previewPort);

    if (LXe_OK != preview.Status ())
        {
        PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);
        return preview.Status ();
        }

    if (s_winData.floatRgb && LXe_OK != preview.SetFormat (LXiIMD_FLOAT))   // set the preview format
        {
        PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);
        return LXe_FAILED;
        }

    if (s_winData.effect[0] && LXe_OK != preview.SetEffect (s_winData.effect))  // set the preview effect
        {
        PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);
        return LXe_FAILED;
        }

    if (s_winData.stereoMode && LXe_OK != preview.SetStereo (true, STEREO_RightEye == s_winData.stereoMode))
        {
        PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);
        return LXe_FAILED;
        }

    switch (s_winData.quality)                                              // set the preview quality
        {
        case QUALITY_Draft:
            if (LXe_OK != preview.SetQualityDraft (s_winData.samples, 0.01f * s_winData.draftQuality))
                {
                PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);
                return LXe_FAILED;
                }
            break;

        case QUALITY_Final:
            if (LXe_OK != preview.SetQualityFinal ())
                {
                PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);
                return LXe_FAILED;
                }
            break;

        case QUALITY_Extended:
            if (LXe_OK != preview.SetQualityExtended (s_winData.samples))
                {
                PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);
                return LXe_FAILED;
                }
            break;
        }

    /*
     * Ask for frames as quickly as we can.  The loop breaks when the connection
     * is servered, which will cause our send/recv functions to throw an exception.
     */
    while (true)
        {
        if (s_previewX != s_winData.previewRect.right || s_previewY != s_winData.previewRect.bottom)
            {
            s_previewX = s_winData.previewRect.right;
            s_previewY = s_winData.previewRect.bottom;

#if DEBUG_PRINTS
            fprintf(fp, "%d: new size: %d x %d\n", GetTickCount(), s_previewX, s_previewY); fflush (fp);
#endif
            if (LXe_OK != preview.SetResolution (s_previewX, s_previewY))   // set the preview resolution
                break;          // error out
            }

        if (s_winData.sendCamera)
            {
#if DEBUG_PRINTS
            fprintf(fp, "%d: Camera pos <%f,%f,%f>, dir <%f,%f,%f>, focal <%f> final:%d\n", GetTickCount(),
                    s_winData.camPos[0], s_winData.camPos[1], s_winData.camPos[2],
                    s_winData.camDir[0], s_winData.camDir[1], s_winData.camDir[2],
                    s_winData.camFocal, s_winData.finalCamera); fflush (fp);
#endif
            if (LXe_OK != preview.SetCamera (s_winData.camPos, s_winData.camDir, s_winData.camFocal, s_winData.finalCamera))   // set the camera
                break;          // error out

            s_winData.sendCamera = false;
            }

        while (! s_winData.mouseQueue.empty ())
            {
            MouseUnion      mousePos;

            /* As long as there are points in the queue, send them to modo to reorder the buckets.
             * We should be careful here that we don't get stuck in a loop if the other thread is
             * constantly filling the queue while we're trying to empty it. We can either throttle
             * the number of points read out or queued up.
             */
            mousePos.i32 = s_winData.mouseQueue.front ();
            s_winData.mouseQueue.pop ();

            if (mousePos.m.x >= 0 && mousePos.m.y >= 0)
                {
#if DEBUG_PRINTS
                fprintf(fp, "%d: Mouse to: <%4d,%4d>\n", GetTickCount(), mousePos.m.x, mousePos.m.y); fflush (fp);
#endif
                if (LXe_OK != preview.SetMousePos (mousePos.m.x, mousePos.m.y))   // set the mouse position
                    break;          // error out
                }
            }

        Sleep (33);         // pause for 1/60 of a sec (in millisecs)

        /*
         * Receive Loop:  Continually read data from the loop
         */
        int             response, w, h;
        LxByte*         img  = NULL;
        static bool     done = false;

        if (LXe_OK != preview.GetFrame (&response, &w, &h, &img))
            break;          // error out

        if (LXiPREVIEWMSG_PREVIEW_UNAVAILABLE & response)
            {
            if (!done && (LXiPREVIEWMSG_PREVIEW_COMPLETE & response))
                {
                int         previewId;

                done = true;
                s_winData.fracComplete = 1.0;
                OutputDebugString ("Progress: Done\n");

                if (LXe_OK == preview.GetPreviewId (&previewId) && previewId) {
                    int         rowBytes = ((3 * w + 3) / 4) * 4;      // longword alligned bytes per output row

                    // place a small square on the image to show the preview is done, color based on the preview ID
                    for (int y = 10; y < 30; ++y)
                        for (int x = 10; x < 30; ++x)
                            {
                            LxByte*     pixelP = &s_winData.imageBufferP[x * 3 + y * rowBytes];
                            pixelP[0] = (previewId & 4) ? 255 : 0;
                            pixelP[1] = (previewId & 2) ? 255 : 0;
                            pixelP[2] = (previewId & 1) ? 255 : 0;
                            }
                }

                FillProgressBar ();
                RedrawWindow (s_winData.hwndPreview, NULL, NULL, RDW_INTERNALPAINT);
                }

            continue;                                       // No image ready yet; keep trying
            }

#if DEBUG_PRINTS
        fprintf(fp, "%d: data ready: %d x %d\n", GetTickCount(), w, h); fflush (fp);
#endif

        /*
         * Send the image buffer to the main thread for drawing.  We need to lock
         *  the semaphore to make sure the main thread doesn't try to draw the image
         *  while we're replacing it.
         */
        WaitForSingleObject (s_winData.threadLockSemaphore, INFINITE);

        if (s_winData.imageBufferP != NULL)
            free (s_winData.imageBufferP);

        s_winData.imageBufferP = img;
        s_winData.imageSizeX   = w;
        s_winData.imageSizeY   = h;
        done                   = false;     // new frame, so the last preview is no longer complete

        ReleaseSemaphore (s_winData.threadLockSemaphore, 1, NULL);

        if (0 == s_winData.aspect || (int)(h * s_winData.aspect + 0.5) != w)
            {
            s_winData.aspect = w / (double)h;                       // compute aspect ratio
            PostMessage (s_winData.hwndContainer, WM_SIZE, 0, 0);   // force a resize
            continue;                                               // skip the paint
            }

        if (LXe_OK == preview.GetPreviewProgress (&s_winData.fracComplete)) {
            char msg[100];
            sprintf (msg, "Progress: %6.2f%% complete\n", 100.0 * s_winData.fracComplete);
            OutputDebugString (msg);
        }

        // queue a paint message
        FillProgressBar ();
        RedrawWindow (s_winData.hwndPreview, NULL, NULL, RDW_INTERNALPAINT);
        }

    PostMessage (s_winData.hwndContainer, WM_QUIT, 0, 0);

    return preview.Status ();       // destructor of LxoPreviewer will close the socket
}

/*------------------------------- Luxology LLC --------------------------- 10/09
 *
 * process command line args to specify the nexus application's IP and the
 * preview and telnet ports. Typical command line would be:
 *
 *      lxopreview 127.0.0.1 12357 12356
 *
 * Before starting, type the following into modo to enable the preview:
 *
 *      previewsocket.listen 12357
 *
 * Alternately, to run the above with a headless modo, launch modo_cl like this:
 *
 *      modo_cl -telnet:raw@12356 "-cmdlate:previewsocket.listen 12357"
 *
 * To use a named pipe for preview, the typical command line would be:
 *
 *      lxopreview \\.\pipe\pipeName
 *
 * and before starting, type the following into modo to enable the pipe preview:
 *
 *      previewPipe.start \\.\pipe\pipeName
 *
 *----------------------------------------------------------------------------*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    static char     usage[] = "Usage:\t%S [options] ip previewPort telnetPort\n\
\t%S [options] pipeName\n\n\
Options can be:  [-frl] [-s N] [-q D|F|E] [-%% N] [-e effect]\n\n\
\t-f   - use float buffer\n\
\t-r   - use right eye of stereo\n\
\t-l   - use left eye of stereo\n\
\t-s N - set the maximum number of antialias samples (Draft & Extended Quality Only)\n\
\t-%% N - set the draft quality percentage (0-100) \n\
\t-qD  - use Draft quality\n\
\t-qF  - use Final quality\n\
\t-qE  - use Extended quality\n\
\t-e   - use the specified output channel or effect\n\
\nIf using a pipe, the name must be in the form of '\\\\.\\pipe\\pipeName' or '\\\\serverName\\pipe\\pipeName'";

    int             argc, arg = 0;
    LPWSTR*         argvW = CommandLineToArgvW (GetCommandLineW (), &argc);
    WSADATA         wsaData;

    char            argv[128];

    while (++arg < argc)
        {
        if ('-' != argvW[arg][0])
            break;

        for (int c = 1; argvW[arg][c]; c++)
            {
            if ('f' == argvW[arg][c] || 'F' == argvW[arg][c])           // float
                s_winData.floatRgb = true;

            else if ('r' == argvW[arg][c] || 'R' == argvW[arg][c])      // stereo - right eye
                s_winData.stereoMode = STEREO_RightEye;

            else if ('l' == argvW[arg][c] || 'L' == argvW[arg][c])      // stereo - left eye
                s_winData.stereoMode = STEREO_LeftEye;

            else if ('s' == argvW[arg][c] || 'S' == argvW[arg][c])      // samples
                {
                if (argvW[arg][++c])
                    s_winData.samples = _wtoi (&argvW[arg][c]);         // parse "-sNNN"
                else
                    s_winData.samples = _wtoi (argvW[++arg]);           // parse "-s NNN"

                break;          // skip to next '-' arg delimiter
                }

            else if ('e' == argvW[arg][c] || 'E' == argvW[arg][c])      // effect
                {
                if (argvW[arg][++c])
                    sprintf (s_winData.effect, "%S", &argvW[arg][c]);   // parse "-eEffect"
                else
                    sprintf (s_winData.effect, "%S", argvW[++arg]);     // parse "-s effect"

                break;          // skip to next '-' arg delimiter
                }

            else if ('%' == argvW[arg][c])                              // draft quality
                {
                if (argvW[arg][++c])
                    s_winData.draftQuality = _wtoi (&argvW[arg][c]);    // parse "-%NNN"
                else
                    s_winData.draftQuality = _wtoi (argvW[++arg]);      // parse "-% NNN"

                break;          // skip to next '-' arg delimiter
                }

            else if ('q' == argvW[arg][c])                              // quality
                {
                if (argvW[arg][++c])
                    s_winData.quality = RenderQuality (argvW[arg][c]);      // parse "-qN"
                else
                    s_winData.quality = RenderQuality (argvW[++arg][0]);    // parse "-q N"

                break;          // skip to next '-' arg delimiter
                }
            }
        }

    /*
     * Make sure we have all args
     */
    switch (argc - arg)
        {
        case 1:
            if ('\\' != argvW[arg][1])
                return fprintf (stderr, usage, argvW[0], argvW[0]);

            sprintf (s_winData.previewPipe, "%S", argvW[arg]);
            break;

        case 3:
            /*
             * Convert the xxx.xxx.xxx.xxx IP address string from Unicode to C, then into an integer IP
             */
            sprintf (argv, "%S", argvW[arg++]);
            s_winData.nexusIP = inet_addr (argv);
            if (s_winData.nexusIP == 0)
                return fprintf (stderr, "Invalid IP \"%s\"", argv);

            /*
             * Store and verify the ports
             */
            s_winData.previewPort = _wtoi (argvW[arg++]);

            if ((s_winData.previewPort < 0) || (s_winData.previewPort >= 0xFFFF))
                return fprintf (stderr, "Preview port \"%d\" out of range", s_winData.previewPort);

            s_winData.telnetPort  = _wtoi (argvW[arg++]);

            if ((s_winData.telnetPort < 0) || (s_winData.telnetPort >= 0xFFFF))
                return fprintf (stderr, "Telnet port \"%d\" out of range", s_winData.telnetPort);

            if (s_winData.telnetPort == s_winData.previewPort)
                return fprintf (stderr, "Preview port and Telnet port must be different");

            break;

        default:
            return fprintf (stderr, usage, argvW[0], argvW[0]);
        }

#if DEBUG_PRINTS
fprintf (stderr, "VALID: float: %d  stereo: %d  samples: %d\n", s_winData.floatRgb, s_winData.stereoMode, s_winData.samples);
if (s_winData.previewPipe[0])
    fprintf (stderr, "PIPE: %s\n", s_winData.previewPipe);
else
    fprintf (stderr, "Telnet: ip: %d  pPort: %d  tPort: %d\n", s_winData.nexusIP, s_winData.previewPort, s_winData.telnetPort);
#endif

#if DEBUG_PRINTS
    fp = fopen ("c:/preview.log", "w");
#endif

    /*
     * Startup WinSock
     */
    WSAStartup (MAKEWORD (2, 2), &wsaData);
    
    /*
     * Initialize the window state
     */
    s_winData.imageSizeX    = -1;
    s_winData.imageBufferP  = NULL;
    s_winData.nCmdShow      = nCmdShow;
    s_winData.aspect        = 0.;

    /* In a normal application we would know the position and orientation of the camera. For the purposes of
     * this test example, we simply initialize these values to those of a known camera in a specific scene.
     */

#if FILE_OPENED_IS_FurMap_complex				// This camera setup was used for FurMap-complex.lxo
    LXx_V3SET (s_winData.camPos, 0.280f, 0.448f, 2.8f);
    LXx_V3SET (s_winData.camDir, (float)(-19.12 * LXx_DEG2RAD), (float)(-28.47 * LXx_DEG2RAD), (float)(-10.84 * LXx_DEG2RAD));

#elif 1 || FILE_OPENED_IS_cosmetic_local			// This camera setup was used for cosmetic-local.lxo
    LXx_V3SET (s_winData.camPos, 0.048174f, 0.636459f, -1.4416f);
    LXx_V3SET (s_winData.camDir, (float)(158 * LXx_DEG2RAD), (float)(2.25 * LXx_DEG2RAD), (float)(-170 * LXx_DEG2RAD));
#endif
    s_winData.camFocal = 0.06f;

    InitPreviewWindow (s_winData);

    s_winData.threadLockSemaphore = CreateSemaphore (NULL, 1, 1, NULL);

    /*
     * Spawn our preview networking thread, which we use to send and receive data
     */
     if (NULL == CreateThread (NULL, 0, (LPTHREAD_START_ROUTINE)PreviewNetworkThread, NULL, 0, NULL))
         return 0;

    /*
     * The thread handles all the networking stuff, including grabbing the image.
     * The main thread draws the image during WM_PAINT message.
     */
    MSG     msg;
    while (GetMessage (&msg, NULL, 0, 0))        // Main message loop - wait for user to close the dialog
        {
        TranslateMessage (&msg);
        DispatchMessage (&msg);
        }

    WSACleanup();

    return 0;
}

