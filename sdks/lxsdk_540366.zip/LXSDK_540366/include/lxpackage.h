/*
 * LX package module
 *
 * Copyright (c) 2008-2019 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_package_H
#define LX_package_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxSceneEvalListener ** ILxSceneEvalListenerID;
typedef struct vt_ILxSceneEvalListener1 ** ILxSceneEvalListener1ID;
typedef struct vt_ILxSceneItemListener1 ** ILxSceneItemListener1ID;
typedef struct vt_ILxSceneItemListener2 ** ILxSceneItemListener2ID;
typedef struct vt_ILxSceneItemListener ** ILxSceneItemListenerID;
typedef struct vt_ILxSceneLoaderTarget ** ILxSceneLoaderTargetID;
typedef struct vt_ILxScene1 ** ILxScene1ID;
typedef struct vt_ILxItem1 ** ILxItem1ID;
typedef struct vt_ILxPackage ** ILxPackageID;
typedef struct vt_ILxAddChannel ** ILxAddChannelID;
typedef struct vt_ILxAddChannel1 ** ILxAddChannel1ID;
typedef struct vt_ILxItemCollection ** ILxItemCollectionID;
typedef struct vt_ILxPackageInstance ** ILxPackageInstanceID;
typedef struct vt_ILxAssemblyAlias ** ILxAssemblyAliasID;
typedef struct vt_ILxPackage1 ** ILxPackage1ID;
typedef struct vt_ILxPackageInstance1 ** ILxPackageInstance1ID;
#include <lxcom.h>
#include <lxvalue.h>
#include <lxvertex.h>
#include <lxitem.h>


typedef struct st_LXtSceneTarget {
        int                      itemType;
        int                      flags;
} LXtSceneTarget;
typedef struct vt_ILxSceneEvalListener {
        ILxUnknown       iunk;
                LXxMETHOD( void,
        ChannelValue) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                 index);
                LXxMETHOD( void,
        ChannelPreValue) (
                LXtObjectID              self);

                LXxMETHOD( void,
        ChannelPostValue) (
                LXtObjectID              self);
} ILxSceneEvalListener;
typedef struct vt_ILxSceneEvalListener1 {
        ILxUnknown       iunk;
                LXxMETHOD( void,
        ChannelValue) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                 index);
} ILxSceneEvalListener1;
typedef struct vt_ILxSceneItemListener1 {
        ILxUnknown       iunk;
                LXxMETHOD( void,
        SceneCreate) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        SceneDestroy) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        SceneFilename) (
                LXtObjectID              self,
                LXtObjectID              scene,
                const char              *filename);

                LXxMETHOD( void,
        SceneClear) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemPreChange) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemPostDelete) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemAdd) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemRemove) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemParent) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemChild) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemAddChannel) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemLocal) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemName) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemSource) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemPackage) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ChannelValue) (
                LXtObjectID              self,
                const char               *action,
                LXtObjectID              item,
                unsigned                 index);
} ILxSceneItemListener1;
typedef struct vt_ILxSceneItemListener2 {
        ILxUnknown       iunk;
                LXxMETHOD( void,
        SceneCreate) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        SceneDestroy) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        SceneFilename) (
                LXtObjectID              self,
                LXtObjectID              scene,
                const char              *filename);

                LXxMETHOD( void,
        SceneClear) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemPreChange) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemPostDelete) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemAdd) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemRemove) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemParent) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemChild) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemAddChannel) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemLocal) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemName) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemSource) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemPackage) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ChannelValue) (
                LXtObjectID              self,
                const char               *action,
                LXtObjectID              item,
                unsigned                 index);
                LXxMETHOD( void,
        LinkAdd) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        LinkRemBefore) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        LinkRemAfter) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        LinkSet) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        ChanLinkAdd) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);

                LXxMETHOD( void,
        ChanLinkRemBefore) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);

                LXxMETHOD( void,
        ChanLinkRemAfter) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);

                LXxMETHOD( void,
        ChanLinkSet) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);
} ILxSceneItemListener2;
typedef struct vt_ILxSceneItemListener {
        ILxUnknown       iunk;
                LXxMETHOD( void,
        SceneCreate) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        SceneDestroy) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        SceneFilename) (
                LXtObjectID              self,
                LXtObjectID              scene,
                const char              *filename);

                LXxMETHOD( void,
        SceneClear) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemPreChange) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemPostDelete) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( void,
        ItemAdd) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemRemove) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemParent) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemChild) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemAddChannel) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemLocal) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemName) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemSource) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ItemPackage) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( void,
        ChannelValue) (
                LXtObjectID              self,
                const char               *action,
                LXtObjectID              item,
                unsigned                 index);

                LXxMETHOD( void,
        LinkAdd) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        LinkRemBefore) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        LinkRemAfter) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        LinkSet) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                LXtObjectID              itemTo);

                LXxMETHOD( void,
        ChanLinkAdd) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);

                LXxMETHOD( void,
        ChanLinkRemBefore) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);

                LXxMETHOD( void,
        ChanLinkRemAfter) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);

                LXxMETHOD( void,
        ChanLinkSet) (
                LXtObjectID              self,
                const char              *graph,
                LXtObjectID              itemFrom,
                unsigned                 chanFrom,
                LXtObjectID              itemTo,
                unsigned                 chanTo);
                LXxMETHOD( void,
        ItemTag) (
                LXtObjectID              self,
                LXtObjectID              item);
                LXxMETHOD( void,
        ItemRemoveChannel) (
                LXtObjectID              self,
                LXtObjectID              item);
                LXxMETHOD( void,
        ItemChannelName) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned int             index);
                LXxMETHOD( void,
        ItemChannelDefault) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned int             index);
                LXxMETHOD( void,
        ItemChannelMinMax) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned int             index);
                LXxMETHOD( void,
        ItemChannelType) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned int             index);
} ILxSceneItemListener;
typedef struct vt_ILxSceneLoaderTarget {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        SetRootType) (
                LXtObjectID              self,
                const char              *typeName);

                LXxMETHOD( LxResult,
        SetFlags) (
                LXtObjectID              self,
                unsigned                 flags);

                LXxMETHOD( LxResult,
        ClearFlags) (
                LXtObjectID              self,
                unsigned                 flags);
} ILxSceneLoaderTarget;
typedef struct vt_ILxScene1 {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Lookup) (
                LXtObjectID              self,
                const char              *id,
                void                   **ppvObj);

                LXxMETHOD( int,
        ItemCount) (
                LXtObjectID              self,
                const char              *type);

                LXxMETHOD( LxResult,
        ItemByIndex) (
                LXtObjectID              self,
                const char              *type,
                unsigned int             index,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        ItemByName) (
                LXtObjectID              self,
                const char              *type_is_ignored,
                const char              *name,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        NewItem) (
                LXtObjectID              self,
                const char              *type,
                void                   **ppvObj);
                LXxMETHOD( void,
        GetMeta) (
                LXtObjectID              self,
                void                    **xobj);

                LXxMETHOD( void,
        SetMeta) (
                LXtObjectID              self,
                LXtObjectID              xobj);
                LXxMETHOD( const char *,
        GetTag) (
                LXtObjectID              self,
                LXtID4                   type);

                LXxMETHOD( void,
        SetTag) (
                LXtObjectID              self,
                LXtID4                   type,
                const char              *tag);
                LXxMETHOD( LxResult,
        Setup) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        Edit) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        Action) (
                LXtObjectID              self,
                double                   time,
                void                   **ppvObj);

                LXxMETHOD( void,
        ListenAction) (
                LXtObjectID              self,
                LXtObjectID              xobj);
                LXxMETHOD( LxResult,
        LoadImage) (
                LXtObjectID              self,
                const char              *name,
                int                     *flags,
                LXtObjectID              monitor,
                void                   **ppvObj);

} ILxScene1;
typedef struct vt_ILxItem1 {
        ILxUnknown       iunk;
                LXxMETHOD( const char *,
        Type) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        TestType) (
                LXtObjectID              self,
                const char              *type);

                LXxMETHOD( const char *,
        Ident) (
                LXtObjectID              self);

                LXxMETHOD( const char *,
        GetTag) (
                LXtObjectID              self,
                unsigned int             tag);

                LXxMETHOD( void,
        SetTag) (
                LXtObjectID              self,
                unsigned int             type,
                const char              *tag);

                LXxMETHOD( int,
        SubItemCount) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        SubItemByIndex) (
                LXtObjectID              self,
                unsigned int             index,
                void                   **ppvObj);

                LXxMETHOD( const char *,
        Name) (
                LXtObjectID              self);

                LXxMETHOD( void,
        SetName) (
                LXtObjectID              self,
                const char              *name);

                LXxMETHOD( void,
        Root) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        Parent) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( void,
        SetParent) (
                LXtObjectID              self,
                LXtObjectID              parent,
                int                      pos);

                LXxMETHOD( int,
        ChannelCount) (
                LXtObjectID              self);

                LXxMETHOD( const char *,
        ChannelName) (
                LXtObjectID              self,
                unsigned int             index);

                LXxMETHOD( LxResult,
        ChannelIndex) (
                LXtObjectID              self,
                const char              *name,
                unsigned int            *index);

                LXxMETHOD( LxResult,
        FindXfrmChannel) (
                LXtObjectID               self,
                const char               *name,
                unsigned int             *index,
                void                    **ppvObj);
} ILxItem1;
typedef struct vt_ILxPackage {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        SetupChannels) (
                LXtObjectID              self,
                LXtObjectID              addChan);

                LXxMETHOD( LxResult,
        Attach) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        TestInterface) (
                LXtObjectID              self,
                const LXtGUID           *guid);

                LXxMETHOD( LxResult,
        PostLoad) (
                LXtObjectID              self,
                LXtObjectID              scene);

                LXxMETHOD( LxResult,
        CollectItems) (
                LXtObjectID              self,
                LXtObjectID              collection,
                unsigned                 mode);
} ILxPackage;
typedef struct vt_ILxAddChannel {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        NewChannel) (
                LXtObjectID              self,
                const char              *name,
                const char              *type);
                LXxMETHOD( LxResult,
        SetGradient) (
                LXtObjectID              self,
                const char              *inType);
                LXxMETHOD( LxResult,
        SetStorage) (
                LXtObjectID              self,
                const char              *stType);
                LXxMETHOD( LxResult,
        SetVector) (
                LXtObjectID              self,
                const char              *vecType);
                LXxMETHOD( LxResult,
        SetDefault) (
                LXtObjectID              self,
                double                   defFlt,
                int                      defInt);

                LXxMETHOD( LxResult,
        SetDefaultVec) (
                LXtObjectID              self,
                const double            *defVec);
                LXxMETHOD( LxResult,
        SetHint) (
                LXtObjectID              self,
                const LXtTextValueHint  *hint);
                LXxMETHOD( LxResult,
        SetUserHint) (
                LXtObjectID              self,
                const LXtTextValueHint  *hint);
                LXxMETHOD( LxResult,
        SetDefaultObj) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD( void,
        SetInternal) (
                LXtObjectID              self);
} ILxAddChannel;
typedef struct vt_ILxAddChannel1 {
        ILxUnknown       iunk;


                LXxMETHOD( LxResult,
        NewChannel) (
                LXtObjectID              self,
                const char              *name,
                const char              *type);

                LXxMETHOD( LxResult,
        SetGradient) (
                LXtObjectID              self,
                const char              *inType);

                LXxMETHOD( LxResult,
        SetStorage) (
                LXtObjectID              self,
                const char              *stType);

                LXxMETHOD( LxResult,
        SetVector) (
                LXtObjectID              self,
                const char              *vecType);

                LXxMETHOD( LxResult,
        SetDefault) (
                LXtObjectID              self,
                double                   defFlt,
                int                      defInt);

                LXxMETHOD( LxResult,
        SetDefaultVec) (
                LXtObjectID              self,
                const double            *defVec);

                LXxMETHOD( LxResult,
        SetHint) (
                LXtObjectID              self,
                const LXtTextValueHint  *hint);

                LXxMETHOD( LxResult,
        SetDefaultObj) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( void,
        SetInternal) (
                LXtObjectID              self);
} ILxAddChannel1;
typedef struct vt_ILxItemCollection {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Test) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( LxResult,
        Count) (
                LXtObjectID              self,
                int                      type,
                unsigned                *count);

                LXxMETHOD( LxResult,
        ByIndex) (
                LXtObjectID              self,
                int                      type,
                unsigned                 index,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        Add) (
                LXtObjectID              self,
                LXtObjectID              item);
} ILxItemCollection;
typedef struct vt_ILxPackageInstance {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Initialize) (
                LXtObjectID              self,
                LXtObjectID              item,
                LXtObjectID              super);

                LXxMETHOD( void,
        Cleanup) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        SynthName) (
                LXtObjectID              self,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( unsigned,
        DupType) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        TestParent) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( LxResult,
        Newborn) (
                LXtObjectID              self,
                LXtObjectID              original,
                unsigned                 flags);

                LXxMETHOD( LxResult,
        Loading) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        AfterLoad) (
                LXtObjectID              self);

                LXxMETHOD( void,
        Doomed) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        Add) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        Remove) (
                LXtObjectID              self);
} ILxPackageInstance;
typedef struct vt_ILxAssemblyAlias {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Test) (
                LXtObjectID              self,
                LXtObjectID              assembly,
                LXtObjectID              other);
                LXxMETHOD(  LxResult,
        Configure) (
                LXtObjectID              self,
                LXtObjectID              assembly,
                LXtObjectID              other,
                LXtObjectID              alias,
                const unsigned int       change);
                LXxMETHOD(  LxResult,
        SuperType) (
                LXtObjectID              self,
                LXtItemType             *type);
                LXxMETHOD(  LxResult,
        Flags) (
                LXtObjectID              self,
                unsigned int            *flags);
} ILxAssemblyAlias;
typedef struct vt_ILxPackage1 {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        SetupChannels) (
                LXtObjectID              self,
                LXtObjectID              addChan);

                LXxMETHOD( LxResult,
        Attach) (
                LXtObjectID              self,
                void                   **ppvObj);

                LXxMETHOD( LxResult,
        TestInterface) (
                LXtObjectID              self,
                const LXtGUID           *guid);

                LXxMETHOD( LxResult,
        PostLoad) (
                LXtObjectID              self,
                LXtObjectID              scene);
} ILxPackage1;
typedef struct vt_ILxPackageInstance1 {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Initialize) (
                LXtObjectID              self,
                LXtObjectID              item,
                LXtObjectID              super);

                LXxMETHOD( void,
        Cleanup) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        SynthName) (
                LXtObjectID              self,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( unsigned,
        DupType) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        TestParent) (
                LXtObjectID              self,
                LXtObjectID              item);

                LXxMETHOD( LxResult,
        Newborn) (
                LXtObjectID              self,
                LXtObjectID              original);

                LXxMETHOD( LxResult,
        Loading) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        AfterLoad) (
                LXtObjectID              self);

                LXxMETHOD( void,
        Doomed) (
                LXtObjectID              self);
} ILxPackageInstance1;

#define LXe_INCOMPATIBLE_SCENE  LXxFAILCODE(LXeSYS_ITEM,2)
#define LXu_SCENEEVALLISTENER   "7793643D-FA56-4198-963B-AE8FAC69F48D"
// [export] ILxSceneEvalListener sel
// [local]  ILxSceneEvalListener
#define LXu_SCENEEVALLISTENER1  "816116A8-B180-49E1-9984-0DE3531BDE55"
#define LXu_SCENEITEMLISTENER1  "BCCD05F8-E560-11D7-B3B8-000393CE9680"
#define LXu_SCENEITEMLISTENER2  "C72C641E-CDCD-431B-ADD9-D75554D656E1"
#define LXu_SCENEITEMLISTENER   "AFB67180-EC4F-4E9B-AAF1-67AA47097C29"
// [export] ILxSceneItemListener sil
// [local]  ILxSceneItemListener
#define LXu_SCENELOADERTARGET   "A914B4F9-947C-4334-9D89-64BB8DC26BF6"
// [local]  ILxSceneLoaderTarget
#define LXf_SCENETARG_SUBCINE           1
#define LXf_SCENETARG_NODEFAULTS        2
#define LXf_SCENETARG_CINECHANGED       4
#define LXf_SCENETARG_GONATIVE          8
#define LXf_LOADIMG_SEARCH_PATHS        1
#define LXf_LOADIMG_USER_REPLACE        2
#define LXu_SCENE1      "4340A8FC-F984-4E04-A4BB-83931A6335AF"
#define LXa_SCENE1      "scene"
#define LXu_ITEM1       "5B14C8B6-29EF-473A-B1B3-568DFD9AE8D7"
#define LXe_GRAPH_CYCLIC        LXxFAILCODE(LXeSYS_ITEM,1)
#define LXu_PACKAGE     "01DA3920-484A-415F-AFF7-5A274B77AC3A"
#define LXa_PACKAGE     "package2"
// [export]  ILxPackage pkg
// [local]   ILxPackage
// [python]  ILxPackage:TestInterface   bool
// [default] ILxPackage:TestInterface = LXe_FALSE
#define LXsPKG_SUPERTYPE        "super"
#define LXsPKG_ITEMLIST_HIDE      "pkg.itemListHide"
#define LXsPKG_ITEMLIST_ATTRIBUTE "pkg.attribute"
#define LXsPKG_GRAPHS           "pkg.graphs"
#define LXsPKG_CREATECMD        "pkg.createCmd"
#define LXs_PKG_NODIRECTCREATE  "-"
#define LXsPKG_CONVERTCMD       "pkg.convertCmd"
#define LXs_PKG_DIRECTCONVERTOK "-"
#define LXsPKG_IS_MASK          "isMaskItem"
#define LXsPKG_SHADER_CONTEXT           "shaderContext"
#define LXsPKG_SHADER_NODE              "shaderNode"
#define LXsPKG_CREATE_INDIRECT  "createIndirect"
#define LXsPKG_IS_COREVOLUME    "isCoreVolume"
#define LXsPKG_NONEVALREAD      "allowNonEvalRead"
#define LXu_ADDCHANNEL          "47C1E8A9-6C76-4068-BD4F-360015683CD0"

// [local]  ILxAddChannel
// [python] ILxAddChannel:SetDefaultObj         obj Unknown

#define LXsCHANVEC_SCALAR       "V"
#define LXsCHANVEC_XY            LXsVECTYPE_XY
#define LXsCHANVEC_XYZ           LXsVECTYPE_XYZ
#define LXsCHANVEC_RGB           LXsVECTYPE_RGB
#define LXsCHANVEC_RGBA          LXsVECTYPE_RGBA
#define LXsCHANVEC_UV            LXsVECTYPE_UV
#define LXsCHANVEC_UVW           LXsVECTYPE_UVW
#define LXu_ADDCHANNEL1         "6E732ACC-AAA5-4695-B5DE-8059A2800554"

// [local]  ILxAddChannel1
// [python] ILxAddChannel1:SetDefaultObj                obj Unknown
#define LXu_ITEMCOLLECTION      "8D37934E-F517-45F1-90F0-8C17F595DC7D"
// [local]  ILxItemCollection
// [python] ILxItemCollection:Test      bool
// [python] ILxItemCollection:ByIndex   obj Item
#define LXiCOLLECT_NONE         -1
#define LXiCOLLECT_IMPORT        0
#define LXiCOLLECT_DEL_SHALLOW   1
#define LXiCOLLECT_DEL_DEEP      2
#define LXiCOLLECT_INSTANCES     3

#define LXxCOLLECT_IS_DELETE(m) (m == LXiCOLLECT_DEL_SHALLOW || m == LXiCOLLECT_DEL_DEEP)
#define LXu_PACKAGEINSTANCE     "68DD1902-E5AB-4591-BF93-B83C856D1908"
#define LXa_PACKAGEINSTANCE     "packageInstance2"
// [export]  ILxPackageInstance pins
// [local]   ILxPackageInstance
// [default] ILxPackageInstance:DupType    = 0
// [default] ILxPackageInstance:TestParent = LXe_TRUE
// [python]  ILxPackageInstance:TestParent      bool

#define LXfNEWBORN_REPLACE       0x01
#define LXa_ASSEMBLYALIAS       "assemblyAlias"
#define LXu_ASSEMBLYALIAS       "1794FFAE-1E80-4211-B1E8-CE09B470B20C"
// [export] ILxAssemblyAlias    alias
#define LXf_ALIAS_ALIAS         0x001
#define LXf_ALIAS_UNALIAS       0x002
#define LXf_ALIAS_CHANNELS      0x004
#define LXf_ALIAS_LOADPRESET    0x008
#define LXf_ALIAS_NEEDSOURCE    0x001
#define LXi_CIT_GROUP            1
#define LXi_CIT_CLIP             2
#define LXi_CIT_LOCATOR          3
#define LXi_CIT_MESH             4
#define LXi_CIT_LIGHT            5
#define LXi_CIT_CAMERA           6
#define LXi_CIT_INSTANCE         7
#define LXi_CIT_T_LOC            8
#define LXi_CIT_RENDER           9
#define LXi_CIT_ENVIRON          10
#define LXi_CIT_BACKDROP         11
#define LXi_CIT_TLAYER           12
#define LXu_PACKAGE1    "6383211E-2624-492e-8C4B-D06BB43886A7"
#define LXa_PACKAGE1    "package"
#define LXu_PACKAGEINSTANCE1    "09D603F7-CCF6-4A5C-B41C-021AC6C17A94"
#define LXa_PACKAGEINSTANCE1    "packageInstance"

 #ifdef __cplusplus
  }
 #endif
#endif

