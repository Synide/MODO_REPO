/*
 * LX vmodel module
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_vmodel_H
#define LX_vmodel_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxViewItem3D ** ILxViewItem3DID;
typedef struct vt_ILxViewItem3D1 ** ILxViewItem3D1ID;
typedef struct vt_ILxToolModel ** ILxToolModelID;
typedef struct vt_ILxToolModel2 ** ILxToolModel2ID;
typedef struct vt_ILxToolModel1 ** ILxToolModel1ID;
typedef struct vt_ILxAdjustTool ** ILxAdjustToolID;
typedef struct vt_ILxNavigationListener ** ILxNavigationListenerID;
#include <lxvalue.h>
#include <lxvector.h>
#include <lxtool.h>
#include <lxhandles.h>
#include <lxdraw.h>
#include <lxvalue.h>

#define LXfTRACK_ENTER          0x00
#define LXfTRACK_MOVE           0x01
#define LXfTRACK_EXIT           0x02
#define LXfTRACK_LAZY           0x000040
#define LXfTRACK_VERX           0x000100
#define LXfTRACK_EDGE           0x000200
#define LXfTRACK_POLY           0x000400
#define LXfTRACK_LOOP1          0x000800
#define LXfTRACK_LOOP2          0x001000
#define LXfTRACK_RAYCAST        0x002000
#define LXfTRACK_BK_RAYCAST     0x004000
#define LXfTRACK_ACTIVE         0x008000
#define LXfTRACK_INACTIVE       0x010000

typedef struct vt_ILxViewItem3D {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Draw) (
                LXtObjectID              self,
                LXtObjectID              chanRead,
                LXtObjectID              strokeDraw,
                int                      selectionFlags,
                LXtVector                itemColor);

                LXxMETHOD(  LxResult,
        DrawBackground) (
                LXtObjectID              self,
                LXtObjectID              chanRead,
                LXtObjectID              strokeDraw,
                LXtVector                itemColor);

                LXxMETHOD(  LxResult,
        WorldSpace) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        HandleCount) (
                LXtObjectID              self,
                int                     *count);

                LXxMETHOD(  LxResult,
        HandleMotion) (
                LXtObjectID              self,
                int                      handleIndex,
                int                     *handleFlags,
                double                  *min,
                double                  *max,
                LXtVector                plane,
                LXtVector                offset);

                LXxMETHOD(  LxResult,
        HandleChannel) (
                LXtObjectID              self,
                int                      handleIndex,
                int                     *chanIndex);

                LXxMETHOD(  LxResult,
        HandleValueToPosition) (
                LXtObjectID              self,
                int                      handleIndex,
                double                  *chanValue,
                LXtVector                position);

                LXxMETHOD(  LxResult,
        HandlePositionToValue) (
                LXtObjectID              self,
                int                      handleIndex,
                LXtVector                position,
                double                  *chanValue);
                LXxMETHOD(  LxResult,
        Test) (
                LXtObjectID              self,
                LXtObjectID              chanRead,
                LXtObjectID              strokeDraw,
                int                      selectionFlags,
                LXtVector                itemColor);
} ILxViewItem3D;
typedef struct vt_ILxViewItem3D1 {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Draw) (
                LXtObjectID              self,
                LXtObjectID              chanRead,
                LXtObjectID              strokeDraw,
                int                      selectionFlags,
                LXtVector                itemColor);

                LXxMETHOD(  LxResult,
        DrawBackground) (
                LXtObjectID              self,
                LXtObjectID              chanRead,
                LXtObjectID              strokeDraw,
                LXtVector                itemColor);

                LXxMETHOD(  LxResult,
        WorldSpace) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        HandleCount) (
                LXtObjectID              self,
                int                     *count);

                LXxMETHOD(  LxResult,
        HandleMotion) (
                LXtObjectID              self,
                int                      handleIndex,
                int                     *handleFlags,
                double                  *min,
                double                  *max,
                LXtVector                plane,
                LXtVector                offset);

                LXxMETHOD(  LxResult,
        HandleChannel) (
                LXtObjectID              self,
                int                      handleIndex,
                int                     *chanIndex);

                LXxMETHOD(  LxResult,
        HandleValueToPosition) (
                LXtObjectID              self,
                int                      handleIndex,
                double                  *chanValue,
                LXtVector                position);

                LXxMETHOD(  LxResult,
        HandlePositionToValue) (
                LXtObjectID              self,
                int                      handleIndex,
                LXtVector                position,
                double                  *chanValue);
} ILxViewItem3D1;
typedef struct vt_ILxToolModel {
        ILxUnknown       iunk;
                LXxMETHOD( unsigned,
        Flags) (
                LXtObjectID              self);
                LXxMETHOD( void,
        Draw) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              stroke,
                int                      flags);

                LXxMETHOD( void,
        Test) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              stroke,
                int                      flags);

                LXxMETHOD( void,
        Filter) (
                LXtObjectID              self,
                LXtObjectID              vts);
                LXxMETHOD( void,
        Initialize) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust,
                unsigned int             flags);
                LXxMETHOD( LxResult,
        Down) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( void,
        Move) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( void,
        Up) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);
                LXxMETHOD( const char *,
        Haul) (
                LXtObjectID              self,
                unsigned int             index);
                LXxMETHOD( const char *,
        Help) (
                LXtObjectID              self,
                LXtObjectID              vts);
                LXxMETHOD( LxResult,
        Enable) (
                LXtObjectID              self,
                LXtObjectID              msg);
                LXxMETHOD( LxResult,
        Drop) (
                LXtObjectID              self);
                LXxMETHOD( LxResult,
        Track) (
                LXtObjectID              self,
                LXtObjectID              vts,
                unsigned int             eventType);
                LXxMETHOD( LxResult,
        TrackFlags) (
                LXtObjectID              self,
                unsigned int            *flags);
                LXxMETHOD( LxResult,
        Post) (
                LXtObjectID              self,
                LXtObjectID              vts);
                LXxMETHOD( LxResult,
        TestType) (
                LXtObjectID              self,
                LXtID4                   type);
                LXxMETHOD( const char *,
        Tooltip) (
                LXtObjectID              self,
                LXtObjectID              vts,
                int                      part);
} ILxToolModel;
typedef struct vt_ILxToolModel2 {
        ILxUnknown       iunk;
                LXxMETHOD( unsigned,
        Flags) (
                LXtObjectID              self);

                LXxMETHOD( void,
        Draw) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              stroke,
                int                      flags);

                LXxMETHOD( void,
        Test) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              stroke,
                int                      flags);

                LXxMETHOD( void,
        Filter) (
                LXtObjectID              self,
                LXtObjectID              vts);

                LXxMETHOD( void,
        Initialize) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust,
                unsigned int             flags);

                LXxMETHOD( LxResult,
        Down) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( void,
        Move) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( void,
        Up) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( const char *,
        Haul) (
                LXtObjectID              self,
                unsigned int             index);

                LXxMETHOD( const char *,
        Help) (
                LXtObjectID              self,
                LXtObjectID              vts);

                LXxMETHOD( LxResult,
        Enable) (
                LXtObjectID              self,
                LXtObjectID              msg);

                LXxMETHOD( LxResult,
        Drop) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        Track) (
                LXtObjectID              self,
                LXtObjectID              vts,
                unsigned int             eventType);

                LXxMETHOD( LxResult,
        TrackFlags) (
                LXtObjectID              self,
                unsigned int            *flags);

                LXxMETHOD( LxResult,
        Post) (
                LXtObjectID              self,
                LXtObjectID              vts);

                LXxMETHOD( LxResult,
        TestType) (
                LXtObjectID              self,
                LXtID4                   type);
} ILxToolModel2;
typedef struct vt_ILxToolModel1 {
        ILxUnknown       iunk;
                LXxMETHOD( unsigned,
        Flags) (
                LXtObjectID              self);

                LXxMETHOD( void,
        Draw) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              stroke,
                int                      flags);

                LXxMETHOD( void,
        Test) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              stroke,
                int                      flags);

                LXxMETHOD( void,
        Filter) (
                LXtObjectID              self,
                LXtObjectID              vts);

                LXxMETHOD( void,
        Initialize) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust,
                unsigned int             flags);

                LXxMETHOD( LxResult,
        Down) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( void,
        Move) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( void,
        Up) (
                LXtObjectID              self,
                LXtObjectID              vts,
                LXtObjectID              adjust);

                LXxMETHOD( const char *,
        Haul) (
                LXtObjectID              self,
                unsigned int             index);

                LXxMETHOD( const char *,
        Help) (
                LXtObjectID              self,
                LXtObjectID              vts);

                LXxMETHOD( LxResult,
        Enable) (
                LXtObjectID              self,
                LXtObjectID              msg);

                LXxMETHOD( LxResult,
        Drop) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        Track) (
                LXtObjectID              self,
                LXtObjectID              vts,
                unsigned int             eventType);

                LXxMETHOD( LxResult,
        TrackFlags) (
                LXtObjectID              self,
                unsigned int            *flags);

                LXxMETHOD( LxResult,
        Post) (
                LXtObjectID              self,
                LXtObjectID              vts);
} ILxToolModel1;
typedef struct vt_ILxAdjustTool {
        ILxUnknown       iunk;
                LXxMETHOD( void,
        Value) (
                LXtObjectID              self,
                unsigned int             index,
                LXtObjectID              val);

                LXxMETHOD( void,
        SetInt) (
                LXtObjectID              self,
                unsigned int             index,
                int                      val);

                LXxMETHOD( void,
        SetFlt) (
                LXtObjectID              self,
                unsigned int             index,
                double                   val);

                LXxMETHOD( void,
        SetString) (
                LXtObjectID              self,
                unsigned int             index,
                const char              *val);
                LXxMETHOD( void,
        Lock) (
                LXtObjectID              self);

                LXxMETHOD( void,
        Invalidate) (
                LXtObjectID              self);

                LXxMETHOD( void,
        Update) (
                LXtObjectID              self);
} ILxAdjustTool;
typedef struct vt_ILxNavigationListener {
        ILxUnknown       iunk;
                LXxMETHOD( void,
        Down) (
                LXtObjectID              self,
                LXtObjectID              view,
                LXtObjectID              item);
                LXxMETHOD( void,
        Move) (
                LXtObjectID              self,
                LXtObjectID              view,
                LXtObjectID              item,
                unsigned                 hot,
                const LXtVector          pos,
                const LXtMatrix          rot,
                double                   zoom);
                LXxMETHOD( void,
        Up) (
                LXtObjectID              self,
                LXtObjectID              view,
                LXtObjectID              item);
                LXxMETHOD( void,
        Delta) (
                LXtObjectID              self,
                LXtObjectID              view,
                LXtObjectID              item,
                unsigned                 hot,
                const LXtVector          pos,
                const LXtMatrix          rot,
                double                   zoom);
                LXxMETHOD( void,
        Wheel) (
                LXtObjectID              self,
                LXtObjectID              view,
                LXtObjectID              item);
                LXxMETHOD( void,
        HotSyncPre) (
                LXtObjectID              self,
                LXtObjectID              view,
                LXtObjectID              item);
                LXxMETHOD( void,
        HotSyncPost) (
                LXtObjectID              self,
                LXtObjectID              view,
                LXtObjectID              item);
} ILxNavigationListener;

#define LXu_VIEWITEM3D          "5E0E5E09-9D9F-447C-AEDA-2F6F266DB464"
#define LXa_VIEWITEM3D          "viewitem3dv2"
//[local]  ILxViewItem3D
//[export] ILxViewItem3D vitm
#define LXiSELECTION_UNSELECTED         0
#define LXiSELECTION_SELECTED           1
#define LXiSELECTION_ROLLOVER           2

#define LXiMOTION_1D                    1 // obsolete
#define LXiMOTION_ANGULAR               2 // obsolete
#define LXiMOTION_RADIAL                3 // obsolete

#define LXiVHANDLE_BASE_PART            400

#define LXmVHANDLE_CONSTRAINT           7 // mask off bottom 3 bits for 8 constraint types
#define LXfVHANDLE_CON_LINEAR           1
#define LXfVHANDLE_CON_PLANAR           2

#define LXmVHANDLE_DRAW_SHAPE           (15<<3) // mask off next 4 bits for 16 draw shapes
#define LXfVHANDLE_DRAW_BOX             (0)
#define LXfVHANDLE_DRAW_LINE            (1<<3)
#define LXfVHANDLE_DRAW_POINT           (2<<3)
#define LXfVHANDLE_DRAW_PLUS            (3<<3)
#define LXfVHANDLE_DRAW_X               (4<<3)
#define LXxVHANDLE_DRAW_SHAPE(f)        ((f)&LXmVHANDLE_DRAW_SHAPE)

#define LXmVHANDLE_DRAW_AXIS            (3<<16) // mask off bottom 2 bits of next word for 4 axis values
#define LXxVHANDLE_DRAW_AXIS(f)         (((f)>>16)&3)

#define LXfVHANDLE_VAL_VECTOR           (1<<8)
#define LXfVHANDLE_RESERVED             (1<<31) // PRIVATE! HANDS OFF

#define LXu_VIEWITEM3D1         "9BCE73B5-3264-48BB-B129-15FF53FD1661"
#define LXa_VIEWITEM3D1         "viewitem3d"
//[local]  ILxViewItem3D1
//[export] ILxViewItem3D1 vitm
#define LXu_TOOLMODEL   "27DB58F5-5C0C-4CF7-B064-6B07188E9813"
// [local]   ILxToolModel
// [export]  ILxToolModel tmod
// [default] ILxToolModel:Flags = LXfTMOD_DRAW_3D
// [default] ILxToolModel:Help  = 0
// [default] ILxToolModel:Haul  = 0
// [default] ILxToolModel:Tooltip = 0
#define LXfTMOD_MODELSPACE       0x00004
#define LXfTMOD_DRAW_3D          0x00010
#define LXfTMOD_DRAW_PIXEL       0x00020
#define LXfTMOD_I0_INPUT         0x00040
#define LXfTMOD_I0_ATTRHAUL      0x00080
#define LXfTMOD_I1_INPUT         0x00100
#define LXfTMOD_I1_ATTRHAUL      0x00200
#define LXfTMOD_I_CURVE          0x00400
#define LXfTMOD_I_BRUSH          0x00800
#define LXfTMOD_I_GENERAL        0x01000
#define LXfTMOD_BRUSHRESET       0x02000
#define LXfTMOD_INITAGAIN        0x04000
#define LXfTMOD_NEEDSHAUL        0x08000
#define LXfTMOD_ROLLOVERS        0x10000
#define LXfTMOD_AUTORESET        0x20000
#define LXfTMOD_HANDLERESET      0x40000
#define LXfTMOD_DRAW_INACTIVE    0x80000

#define LXfTMOD_I0_NOSELECT      0x100000
#define LXfTMOD_I1_NOSELECT      0x200000

#define LXfTMOD_AUTOACTIVATE     0x400000
#define LXfTMOD_SELECTTHROUGH    0x800000

#define LXfTMOD_NOCLONE          0x1000000
#define LXfINITIALIZE_DIRECT     0x01
#define LXfINITIALIZE_EVENT      0x02
#define LXfINITIALIZE_AGAIN      0x04
#define LXfINITIALIZE_BRUSH      0x08
#define LXu_TOOLMODEL2  "B70B1F15-137A-4716-A893-1AC416C547E9"
// [local]   ILxToolModel2
// [export]  ILxToolModel2 tmod
// [default] ILxToolModel2:Flags = LXfTMOD_DRAW_3D
// [default] ILxToolModel2:Help  = 0
// [default] ILxToolModel2:Haul  = 0
#define LXu_TOOLMODEL1  "EECE6570-AD5F-4190-AFA7-15067500454F"
// [local]   ILxToolModel1
// [export]  ILxToolModel1 tmod
// [default] ILxToolModel1:Flags = LXfTMOD_DRAW_3D
// [default] ILxToolModel1:Help  = 0
// [default] ILxToolModel1:Haul  = 0
#define LXu_ADJUSTTOOL  "26E85301-8165-4FF3-AF26-392A03C9E1E7"
// [local]  ILxAdjustTool
#define LXfNAV_HOT_POS                  0x01
#define LXfNAV_HOT_ROT                  0x02
#define LXfNAV_HOT_ZOOM                 0x04
#define LXu_NAVIGATIONLISTENER  "61724B7C-59DE-40F7-B260-8C71D8FE9710"
// [export] ILxNavigationListener nav
// [local]  ILxNavigationListener

 #ifdef __cplusplus
  }
 #endif
#endif

