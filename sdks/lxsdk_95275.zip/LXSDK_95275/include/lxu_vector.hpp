/*
 * Plug-in SDK Header: C++ Services
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Helper class for doing math with modo vectors.
 */

#ifndef LX_VECTOR_HPP
#define LX_VECTOR_HPP

#include <lxvmath.h>
#include "lxu_math.hpp"

#include <string>


class CLxMatrix4;

template <typename T>
class CLxVectorT
{
public:
        T 	v[LXdND];
        
        
        CLxVectorT()
        {
                LXx_VCLR( v );
        }
        
        CLxVectorT(T xx, T yy, T zz=(T)0.)
        {
                LXx_VSET3(v, xx, yy, zz);
        }
        
        // construct from a modo vector
        template <typename U>
        CLxVectorT(const U mV[3])
        {
                LXx_VCPY(v, mV);
        }
        
        template <typename U>
        CLxVectorT(const CLxVectorT<U> &other)
        {
                LXx_VCPY(v, other.v);
        }
        
        inline void set(T xx, T yy, T zz=(T)0.)
        {
                LXx_VSET3(v, xx, yy, zz);
        }
        
        
        template <typename U>
        inline CLxVectorT& operator= (const CLxVectorT<U> &other)
        {
                LXx_VCPY(v, other.v);
                return *this;
        }
        
        
        
        // cross product
        template <typename U>
        inline CLxVectorT 	operator^ (const CLxVectorT<U> &other) const
        {
                return CLxVectorT(	v[1] * other.v[2] - v[2] * other.v[1],
                                        v[2] * other.v[0] - v[0] * other.v[2],
                                        v[0] * other.v[1] - v[1] * other.v[0]);
        }
        
        // dot product
        template <typename U>
        inline T 	operator* (const CLxVectorT<U> &other) const
        {
                return LXx_VDOT(v, other.v);
        }
        
        
        // math operators
        
        // negate
        inline CLxVectorT	operator-() const
        {
                return CLxVectorT(-v[0], -v[1], -v[2]);
        }
        
        // addition
        template <typename U>
        inline CLxVectorT& operator+= (const CLxVectorT<U> &other )
        {
                LXx_VADD(v, other.v);
                return *this;
        }
        
        template <typename U>
        inline CLxVectorT	operator+ (const CLxVectorT<U> &other) const
        {
                return CLxVectorT(	v[0] + other.v[0],
                                        v[1] + other.v[1],
                                        v[2] + other.v[2]);
        }
        
        
        // subtract
        inline CLxVectorT& operator-= (const CLxVectorT &other )
        {
                LXx_VSUB(v, other.v);
                return *this;
        }
        
        inline CLxVectorT	operator-( const CLxVectorT &other ) const
        {
                return CLxVectorT(	v[0] - other.v[0],
                                        v[1] - other.v[1],
                                        v[2] - other.v[2]);
        }
        
        // multiply
        template <typename U>
        inline CLxVectorT<T>& operator*= (const CLxVectorT<U> &other)
        {
                LXx_VMUL(v, other.v);
                return *this;
        }
        
        inline CLxVectorT& operator*=( T s )
        {
                LXx_VSCL(v, s);
                return *this;
        }
        
        inline CLxVectorT	operator*( T s ) const
        {
                return CLxVectorT(v[0] * s, v[1] * s, v[2] * s);
        }
        
        
        CLxVectorT& operator*=( const CLxMatrix4 &mat );
        
        CLxVectorT	operator*( const CLxMatrix4 &mat ) const ;
        
        


        
        // division
        template <typename U>
        inline CLxVectorT& operator/= (const CLxVectorT<U> &other)
        {
                LXx_VDIV(v, other.v);
                return *this;
        }
        
        template <typename U>
        inline CLxVectorT operator/ (const CLxVectorT<U> &other)
        {
                CLxVectorT retV( *this );
                LXx_VDIV(retV.v, other.v);
                return retV;
        }
        
        
        inline CLxVectorT& operator/=(T s)
        {
                if( s == 0.)
                        throw LXe_INVALIDARG;
                        
                return *this *= T(1.0) / s;
        }
        
        inline CLxVectorT operator/(T s)
        {
                if( s == 0.)
                        throw LXe_INVALIDARG;
                
                return *this * (T(1.0) / s);
        }
        
        // equality operator
        // returns true if both vectors are identical
        inline bool	operator==(const CLxVectorT& other) const
        {
                return ((v[0] == other.v[0]) && (v[1] == other.v[1]) && (v[2] == other.v[2]));
        }
        
        inline bool	operator!=(const CLxVectorT& other) const
        {
                return !(*this == other);
        }
        
        
        // utility functions
        
        // returns the length of the vector squared
        inline T length2() const
        {
                return LXx_VLENSQ(v);
        }
        
        // returns the length of the vector
        inline T length() const
        {
                return LXx_VLEN(v);
        }
        
        // return the vector at a unit length
        inline CLxVectorT normal() const
        {
                CLxVectorT norm(*this);
                return norm.normalize();
        }
        
        // scales the vector to a unit length
        inline CLxVectorT& normalize()
        {
                return *this /= length();
        }
        
        // returns the triple product
        template<typename U, typename V>
        inline T 	triple (const CLxVectorT<U> &v1, const CLxVectorT<V> &v2 ) const
        {
                return
                v[0] * (v1.v[1] * v2.v[2] - v1.v[2] * v2.v[1]) +
                v[1] * (v1.v[2] * v2.v[0] - v1.v[0] * v2.v[2]) +
                v[2] * (v1.v[0] * v2.v[1] - v1.v[1] * v2.v[0]);
        }
        
        // returns the distance between the vector and the one passed
        template<typename U>
        inline T 	distance ( const CLxVectorT<U> &other ) const
        {
                return (v - *this).length();
        }
        
        // returns the linearly interpolated vector between this and the passed vector by the scalar value
        template <typename U>
        inline CLxVectorT	lerp (const CLxVectorT<U> &other, T s ) const
        {
                CLxVectorT retV;
                LXx_VLERP( retV.v, v, other.v, s );
        }
        
        // returns the angle in radians between this and the passed vector
        template<typename U>
        inline T 	angle ( const CLxVectorT<U> &other ) const
        {
                return (T)std::acos(normal().dot(v.normal()));
        }
        
        inline CLxVectorT absolute() const
        {
                return CLxVectorT( fabs(v[0]), fabs(v[1]), fabs(v[2]) );
        }
        
        inline int furthestAxis() const
        {
                return absolute().minAxis();
        }
        
        inline int closestAxis() const
        {
                return absolute().maxAxis();
        }

        inline int minAxis() const
        {
                return v[0] < v[1] ? (v[0] <v[2] ? 0 : 2) : (v[1] <v[2] ? 1 : 2);
        }
        
        inline int maxAxis() const
        {
                return v[0] < v[1] ? (v[1] <v[2] ? 2 : 1) : (v[0] <v[2] ? 2 : 0);
        }
        
        
        
        std::string toString()
        {
                std::string str;
                str += v[0];
                str += ", ";
                str += v[1];
                str += ", ";
                str += v[2];
                return str;
        }
        
        
        // accessors
        
        operator T*()
        {
                return(v);
        }
        
        
        
        inline T& 	operator() (unsigned int i)
        {
                if( i > LXdND )
                        throw LXe_OUTOFBOUNDS;
                else
                        return v[i];
        }
        
        inline T& 	operator[] (unsigned int i)
        {
                if( i > LXdND )
                        throw LXe_OUTOFBOUNDS;
                else
                        return v[i];
        }

        inline const T& 	operator[] (unsigned int i) const
        {
                if( i > LXdND )
                        throw LXe_OUTOFBOUNDS;
                else
                        return v[i];
        }
};


typedef CLxVectorT<float>	CLxFVector;
typedef CLxVectorT<double>	CLxVector;




#endif	/* LX_VECTOR_HPP */

