/*
 * Plug-in Kelvin color model.
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * A plug-in color model that enables picking colors using a
 * Kelvin color temperature component.
 */

#include "kelvincolormodel.h"

#include <lxvmath.h>
#include <lxu_message.hpp>
#include <lxu_queries.hpp>
#include <lx_file.hpp>

#include <string>
#include <float.h>

using namespace std;

#define _R		rgb[0]
#define _G		rgb[1]
#define _B		rgb[2]

const float MIN_KELVIN = 1000.0;
const float MAX_KELVIN = 9500.0;

/*
 * ---------------------------------------------------------------------------
 * CKelvinColorModel.
 */

LXtTagInfoDesc	 CKelvinColorModel::descInfo[] = {
        { LXsLOD_CLASSLIST,          LXa_COLORMODEL       },
        { LXsSRV_USERNAME,	     "Kelvin"             },
        { LXsSRV_LOGSUBSYSTEM,	     "kelvin-color-model" },
        { LXsCOLORMODEL_VALUEPRESET, "0:kelvin"	          },
        { 0 }
};

        static int
GetUserInt (const char *prefKey, int defaultValue = 0)
{
        int	value = defaultValue;
        CLxReadUserValue ruvUser;
        if (ruvUser.Query (prefKey)) {
                value = ruvUser.GetInt ();
        }

        return value;
}

CKelvinColorModel::CKelvinColorModel ()
{
}

CKelvinColorModel::~CKelvinColorModel ()
{
}

        int
CKelvinColorModel::colm_NumComponents (void)
{
        return 1; // Temperature in Kelvins
}

        LxResult
CKelvinColorModel::colm_ComponentType (
        unsigned	 componentIndex,
        const char	**type)
{
        *type = LXsTYPE_FLOAT;

        return LXe_OK;
}

        LxResult
CKelvinColorModel::colm_ComponentRange (
        unsigned	 componentIndex,
        float		*minValue,
        float		*maxValue)
{
        *minValue = static_cast<float>(MinTemp ());
        *maxValue = static_cast<float>(MaxTemp ());

        return LXe_OK;
}

        LxResult
CKelvinColorModel::colm_ToRGB (
        const float	*kelvin,
        float		*rgb)
{
        return imageSvc.Kelvin2RGB (*kelvin, rgb);
}

        LxResult
CKelvinColorModel::colm_FromRGB (
        const float	*rgb,
        float		*kelvin)
{
        return imageSvc.RGB2Kelvin (const_cast<float*>(rgb), kelvin);
}

        LxResult
CKelvinColorModel::colm_DrawSlice (
        ILxUnknownID	 image,
        unsigned	 xAxis,
        unsigned	 yAxis,
        const float	*vec)
{
        LxResult		 result = LXe_OK;
        CLxUser_ImageWrite	 writeImage;
        CLxUser_Image		 readImage;

        m_log.Setup ();

        writeImage.set (image);
        readImage.set (image);

        unsigned		 width, height;
        writeImage.Size (&width, &height);
        
        float minTemp = static_cast<float>(MinTemp ());
        float maxTemp = static_cast<float>(MaxTemp ());

        float *rgbRowBuffer = new float [width * 3];
        float kelvinRange = maxTemp - minTemp;
        for (unsigned index = 0; index < width; ++index) {
                float	kelvin = minTemp + static_cast<float>(index) / width * kelvinRange;
                LXtFVector rgbColor;
                imageSvc.Kelvin2RGB (kelvin, rgbColor);
                LXx_VCPY (&rgbRowBuffer[index * 3], rgbColor);
        }

        unsigned totalWidth = width;

        LXtImageByte		*lineBuffer;
        lineBuffer = new LXtImageByte [totalWidth * 4];

        float		 rgb[3] = {0, 0, 0};
        for (unsigned y = 0; y < height; ++y) {
                LXtImageByte	*pixel = lineBuffer;
                for (unsigned x = 0; x < width; ++x) {
                        _R = rgbRowBuffer[x * 3];
                        _G = rgbRowBuffer[x * 3 + 1];
                        _B = rgbRowBuffer[x * 3 + 2];
                        pixel[0] = static_cast<LXtImageByte>(_R * 255.0);
                        pixel[1] = static_cast<LXtImageByte>(_G * 255.0);
                        pixel[2] = static_cast<LXtImageByte>(_B * 255.0);
                        pixel[3] = 255;
                        pixel += 4;
                }

                result = writeImage.SetLine (y, LXiIMP_RGBA32, lineBuffer);
        }

        delete [] lineBuffer;

        delete [] rgbRowBuffer;

        return result;
}

        LxResult
CKelvinColorModel::colm_DrawSliceMarker (
        ILxUnknownID	 image,
        unsigned	 xAxis,
        unsigned	 yAxis,
        const float	*downVec,
        const float	*kelvin)
{
        /*
         * Use the default marker appearance.
         */
        return LXe_NOTIMPL;
}

        LxResult
CKelvinColorModel::colm_CanSliceBeReused (
        unsigned	  xAxis,
        unsigned	  yAxis,
        const float	 *oldVec,
        const float	 *newVec)
{
        return LXe_TRUE;
}

/*
 * Calculate imgX and imgY in (0..imgW, 0..imgH), from hsv color components
 * on the plane specified by xAxis, yAxis.
 */
        LxResult
CKelvinColorModel::colm_ToSlicePos (
        unsigned	 xAxis,
        unsigned	 yAxis,
        unsigned	 imgW,
        unsigned	 imgH,
        const float	*kelvin,
        unsigned	*imgX,
        unsigned	*imgY)
{
        float minTemp = static_cast<float>(MinTemp ());
        float maxTemp = static_cast<float>(MaxTemp ());
        float kelvinRange = maxTemp - minTemp;
        float x = (*kelvin - minTemp) / kelvinRange;
        float y = 0.5f;

        *imgX = static_cast<unsigned>(LXxCLAMP (x, 0, 1) * imgW);
        *imgY = static_cast<unsigned>(LXxCLAMP (y, 0, 1) * imgH);

        return LXe_OK;
}

/*
 * Calculate color model components hsv using imgX and imgY in [0, 1],
 * on the plane specified by xAxis, yAxis.
 *
 * NOTE: The other axis (the one that is neither x nor y) component value
 *       should already be set by the last bar selection or the initial
 *       color load.
 */
        LxResult
CKelvinColorModel::colm_FromSlicePos (
        unsigned	 xAxis,
        unsigned	 yAxis,
        unsigned	 imgW,
        unsigned	 imgH,
        unsigned	 imgX,
        unsigned	 imgY,
        float		*downVec,
        float		*kelvin)
{
        float minTemp = static_cast<float>(MinTemp ());
        float maxTemp = static_cast<float>(MaxTemp ());
        float kelvinRange = maxTemp - minTemp;

        *kelvin = minTemp + (static_cast<float>(imgX) / imgW) * kelvinRange;

        return LXe_OK;
}

/*
 * Return a clean vector so the color picker can drawn the horizontal
 * strip properly.  For hue, this is 0,1,1, for saturation we set the
 * value to 1 but leave the rest alone,, and for value it's always 0,0,0.
 */
        LxResult
CKelvinColorModel::colm_StripBaseVector (
        unsigned	 axis,
        int		 dynamic,
        float		*kelvin)
{
        return LXe_OK;
}

static const char* LXsUSER_VALUE_KELVIN_MIN_TEMP	= "kelvinMinTemp";
static const char* LXsUSER_VALUE_KELVIN_MAX_TEMP	= "kelvinMaxTemp";

        unsigned
CKelvinColorModel::MinTemp () const
{
        return GetUserInt (LXsUSER_VALUE_KELVIN_MIN_TEMP,
                static_cast<unsigned>(MIN_KELVIN));
}

        unsigned
CKelvinColorModel::MaxTemp () const
{
        return GetUserInt (LXsUSER_VALUE_KELVIN_MAX_TEMP,
                static_cast<unsigned>(MAX_KELVIN));
}

/*
 * ----------------------------------------------------------------
 * Server initialization.
 */

        void
initialize ()
{
        LXx_ADD_SERVER (ColorModel, CKelvinColorModel, "kelvin_color_model");
}

