/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#pragma warning(disable: 4786)

#include "colladasaver.h"

#include "../libcolladaio/cio_asset.h"
#include "../libcolladaio/cio_camera.h"
#include "../libcolladaio/cio_collada.h"
#include "../libcolladaio/cio_effect.h"
#include "../libcolladaio/cio_file.h"
#include "../libcolladaio/cio_geometry.h"
#include "../libcolladaio/cio_image.h"
#include "../libcolladaio/cio_material.h"
#include "../libcolladaio/cio_node.h"
#include "../libcolladaio/cio_shadernode.h"
#include "../libcolladaio/cio_visualscene.h"
#include "../libcolladaio/cio_scene.h"
#include "../libcolladaio/cio_animation.h"
#include "../libcolladaio/cio_math.h"
#include "../libcolladaio/cio_profiles.h"
#include "../libcolladaio/cio_schema.h"
#include "../libcolladaio/cio_format.h"

#include "colladaconfig.h"
#include "colladacontainers.h"
#include "colladaprefs.h"
#include "colladaregistrar.h"

/*
 * Bring in LXsICHAN_VIDEOSTILL_FILENAME constant.
 */
#include <lxidef.h>
#include <lxu_queries.hpp>
#include <lx_value.hpp>
#include <lx_util.hpp>
#include <lxu_prefvalue.hpp>
#include <lx_package.hpp>
#include <lx_deform.hpp>
#include <lx_action.hpp>
#include <lx_locator.hpp>
#include <lx_util.hpp>

#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>
#include <stdlib.h>
#include <algorithm>

using namespace std;
using namespace cio;
using namespace cio::math;

/*
 * Define COLLADASAVER_VERBOSE_LOGGING for heavy-duty
 * logging message info.
 */
// #define COLLADASAVER_VERBOSE_LOGGING		1

namespace {

        static const bool SAVE_ANIMATION = true;

        static const string translationChannelXname =
                string(LXsICHAN_TRANSLATION_POS) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_X);

        static const string translationChannelYname =
                string(LXsICHAN_TRANSLATION_POS) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_Y);

        static const string translationChannelZname =
                string(LXsICHAN_TRANSLATION_POS) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_Z);

        static const string rotationChannelXname =
                string(LXsICHAN_ROTATION_ROT) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_X);

        static const string rotationChannelYname =
                string(LXsICHAN_ROTATION_ROT) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_Y);

        static const string rotationChannelZname =
                string(LXsICHAN_ROTATION_ROT) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_Z);

        static const string scaleChannelXname =
                string(LXsICHAN_SCALE_SCL) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_X);

        static const string scaleChannelYname =
                string(LXsICHAN_SCALE_SCL) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_Y);

        static const string scaleChannelZname =
                string(LXsICHAN_SCALE_SCL) +
                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                string(ATTRVALUE_Z);

                static void
        BuildAxisOrder (
                int	rotationOrder,
                int	axis[3])
        {
                switch (rotationOrder) {
                        case ROTATION_ORDER_XZY:
                                axis[0] = 0;
                                axis[1] = 2;
                                axis[2] = 1;
                                break;

                        case ROTATION_ORDER_YXZ:
                                axis[0] = 1;
                                axis[1] = 0;
                                axis[2] = 2;
                                break;

                        case ROTATION_ORDER_YZX:
                                axis[0] = 1;
                                axis[1] = 2;
                                axis[2] = 0;
                                break;

                        case ROTATION_ORDER_ZXY:
                                axis[0] = 2;
                                axis[1] = 0;
                                axis[2] = 1;
                                break;

                        case ROTATION_ORDER_ZYX:
                                axis[0] = 2;
                                axis[1] = 1;
                                axis[2] = 0;
                                break;

                        case ROTATION_ORDER_XYZ:
                        default:
                                axis[0] = 0;
                                axis[1] = 1;
                                axis[2] = 2;
                                break;
                }
        }

        /*
         * Mesh map visitor. Builds an array of mesh map names, which can be
         * used to select the maps to enable iterating over their elements.
         */
        class MeshMapVisitor : public CLxImpl_AbstractVisitor
        {
            public:
                                                MeshMapVisitor (
                                                        CLxUser_MeshMap *theMeshMap)
                {
                        meshMap = theMeshMap;
                }

                void SortMapNames ()
                {
                                std::sort(mapNames.begin(), mapNames.end());
                }
                
                const StringArray & GetMapNames () const
                {
                        return mapNames;
                }

            private:
                CLxUser_MeshMap		*meshMap;
                StringArray		 mapNames;

                virtual LxResult		Evaluate ()
                {
                        const char *mapName;
                        if (LXx_OK (meshMap->Name (&mapName))) {
                                mapNames.push_back(string(mapName));
                        }
                        return LXe_OK;
                }

        };
};

/*
 *------------------------------------------------------------------------
 * Standard saver overrides
 */

LXtTagInfoDesc	 COLLADASceneSaver::descInfo[] = {
        { LXsSAV_OUTCLASS,	LXa_SCENE			},
        { LXsSAV_DOSTYPE,	VALUE_COLLADA_FILE_EXTENSION	},
        { LXsSRV_USERNAME,	VALUE_SCENE_IO_USER_NAME	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"			},
        { 0 }
};

/*
 * Return the value of an enumerated integer channel as a symbolic string.
 */
#if defined(MODO_501)
        string
GetTextHintEncodedChannelValue (
        const CLxSceneSaver	&saver,
        const string		&channelName)
#else
        string
GetTextHintEncodedChannelValue (
        CLxSceneSaver		&saver,
        const string		&channelName)
#endif
{
        string	channelValueText;
        const unsigned MAX_HINT_TEXT_LENGTH = 2048;
        char	 hintText[MAX_HINT_TEXT_LENGTH];
        saver.ChanIntEncoded (
                channelName.c_str (), hintText, MAX_HINT_TEXT_LENGTH);
        channelValueText = string(hintText);

        return channelValueText;
}

/*
 * Normalize a 2D vector.
 */
        static void
NormalizeVector2D (double &x, double &y)
{
        double magR = 1.0 / sqrt(x * x + y * y);
        x *= magR;
        y *= magR;
}

/*
 * If the given result is OK, checks if the scene saver has an error.
 */
        LxResult
COLLADASceneSaver::LogError (
        LxResult		result,
        const string		&msg)
{
        LxResult logResult(result);
        if (LXx_OK (logResult)) {
                logResult = LastErr ();
        }

        if (LXx_FAIL(logResult)) {
                log.Info (string("Error in ") + msg + string(": "), result);
        }

        return logResult;
}

#define LOG_ERR(result) LogError (result, __FUNCTION__)

        const COLLADAprefs&
COLLADASceneSaver::GetPrefs () const
{
        return prefs;
}

/*
 * Add the <asset> element to the root.
 */
        LxResult
COLLADASceneSaver::AddAsset (COLLADAElement &collada)
{
        LxResult		 result(LXe_FAILED);

        log.Info ("Adding asset element.");

        AssetElement asset(collada);

        /*
         * Add the <contributor> element to the <asset> element.
         */
        result = AddAssetContributor (asset);
        if (LXx_OK (result)) {
                /*
                 * Add the <created> element to the <asset> element.
                 */
                result = AddAssetCreatedDateTime (asset);
                if (LXx_OK (result)) {
                        /*
                         * Add the keywords.
                         */
                        asset.SetKeywords (GetKeywords ());

                        /*
                         * Add the <modified> element to the <asset> element.
                         */
                        result = AddAssetModifiedDateTime (asset);
                        if (LXx_OK (result)) {
                                /*
                                 * Add the revision.
                                 */
                                asset.SetRevision (GetRevision ());

                                /*
                                 * Add the subject.
                                 */
                                asset.SetSubject (GetSubject ());

                                /*
                                 * Add the title.
                                 */
                                asset.SetTitle (GetTitle ());

                                /*
                                 * Add the <unit> element to the <asset> element.
                                 */
                                result = AddAssetUnit (asset);
                                if (LXx_OK (result)) {
                                        /*
                                         * Add the <up_axis> element to the <asset> element.
                                         */
                                        result = AddAssetUpAxis (asset);
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

/*
 * Add the <contributor> element to the <asset> element.
 */
        LxResult
COLLADASceneSaver::AddAssetContributor (AssetElement& asset)
{
        /*
         * Define SYNCVER as zero if not set.
         */
        #ifndef SYNCVER
                #define SYNCVER		0
        #endif

        LxResult		 result(LXe_OK);

        ContributorElement	contributor(asset);

        contributor.SetAuthor (GetAuthor ());

        contributor.SetAuthoringTool (GetAuthoringTool ());

        /*
         * Build a comment string using the build-time build number and
         * the user-configured export settings.
         */
        StringArray comments;
        comments.push_back (string("Plug-in: [Build ") + IntegerToString(SYNCVER) + string("];"));

        prefs.GetExportComments (comments);
        contributor.SetComments (comments);

        contributor.SetCopyright (GetCopyright ());

        /*
         * Build the source data file text value.
         */
        string baseSceneFileName;
        if (IsSceneSaved ()) {
                baseSceneFileName = ScenePath();
        }
        else {
                baseSceneFileName = ATTRVALUE_DEFAULTSCENEFILENAME;
        }

        contributor.SetSourceData (FilePathToAbsoluteURI (baseSceneFileName));

        return LOG_ERR (result);
}

        static bool
GetDateTime (DateTime& dateTime)
{
        bool	haveTime(false);
        /*
         * Get current date/time based on the current system.
         */
        time_t currentTime = time(0);

        /*
         * Convert currentTime to UTC.
         */
        #pragma warning(disable: 4996)
        tm* timeUTC = gmtime (&currentTime);
        if (timeUTC != NULL)
        {
                /*
                 * Date
                 */
                dateTime.year = timeUTC->tm_year + 1900;
                dateTime.month = timeUTC->tm_mon + 1;
                dateTime.day = timeUTC->tm_mday;

                /*
                 * Time
                 */
                dateTime.hour = timeUTC->tm_hour;
                dateTime.minute = timeUTC->tm_min;
                dateTime.second = timeUTC->tm_sec;

                haveTime = true;
        }

        return haveTime;
}

/*
 * Add the <created> and <modified> elements to the <asset> element.
 */
        LxResult
COLLADASceneSaver::AddAssetCreatedDateTime (AssetElement& asset)
{
        LxResult		 result(LXe_OK);

        DateTime		 dateTime;
        if (GetDateTime (dateTime)) {
                /*
                 * [TODO] Write out the creation date and time of original doc.
                 */
                asset.SetCreationDateTime (dateTime);
        }

        return LOG_ERR (result);
}

/*
 * Add the <created> and <modified> elements to the <asset> element.
 */
        LxResult
COLLADASceneSaver::AddAssetModifiedDateTime (AssetElement& asset)
{
        LxResult		 result(LXe_OK);

        DateTime		 dateTime;
        if (GetDateTime (dateTime)) {
                /*
                 * [TODO] Write out the modification date and time of original doc.
                 */
                asset.SetModifiedDateTime (dateTime);
        }

        return LOG_ERR (result);
}

/*
 * Add the <unit> element to the <asset> element.
 */
        LxResult
COLLADASceneSaver::AddAssetUnit (AssetElement& asset)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding unit element.");

        int defaultUnit = prefs.GetDefaultUnit ();
        switch (prefs.GetUnitSystem ()) {
                case LXiPREFERENCE_VALUE_UNIT_SYSTEM_SI: {
                        switch (defaultUnit) {
                                case LXsPREFERENCE_VALUE_UNIT_SI_MICRONS:
                                        asset.SetUnit (
                                                UNITNAME_MICRON,
                                                METERS_PER_MICRON);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_SI_MILLIMETERS:
                                        asset.SetUnit (
                                                UNITNAME_MILLIMETER,
                                                METERS_PER_MILLIMETER);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_SI_METERS:
                                        /*
                                         * Use default of "meter" and one meter = 1.0 units.
                                         */
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_SI_KILOMETERS:
                                        asset.SetUnit (
                                                UNITNAME_KILOMETER,
                                                METERS_PER_KILOMETER);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_SI_MEGAMETERS:
                                        asset.SetUnit (
                                                UNITNAME_MEGAMETER,
                                                METERS_PER_MEGAMETER);
                                        break;
                        }
                        break;
                }

                case LXiPREFERENCE_VALUE_UNIT_SYSTEM_METRIC: {
                        switch (defaultUnit) {
                                case LXsPREFERENCE_VALUE_UNIT_METRIC_MICRONS:
                                        asset.SetUnit (
                                                UNITNAME_MICRON,
                                                METERS_PER_MICRON);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_METRIC_MILLIMETERS:
                                        asset.SetUnit (
                                                UNITNAME_MILLIMETER,
                                                METERS_PER_MILLIMETER);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_METRIC_CENTIMETERS:
                                        asset.SetUnit (
                                                UNITNAME_CENTIMETER,
                                                METERS_PER_CENTIMETER);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_METRIC_METERS:
                                        /*
                                         * Use default of "meter" and
                                         * one meter = 1.0 units.
                                         */
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_METRIC_KILOMETERS:
                                        asset.SetUnit (
                                                UNITNAME_KILOMETER,
                                                METERS_PER_KILOMETER);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_METRIC_MEGAMETERS:
                                        asset.SetUnit (
                                                UNITNAME_MEGAMETER,
                                                METERS_PER_MEGAMETER);
                                        break;
                        }
                        break;
                }

                case LXiPREFERENCE_VALUE_UNIT_SYSTEM_ENGLISH: {
                        switch (defaultUnit) {
                                case LXsPREFERENCE_VALUE_UNIT_ENGLISH_MILS:
                                        asset.SetUnit (
                                                UNITNAME_MILS,
                                                METERS_PER_MIL);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_ENGLISH_INCHES: {
                                        asset.SetUnit (
                                                UNITNAME_INCH,
                                                METERS_PER_INCH);
                                        break;
                                }
                                case LXsPREFERENCE_VALUE_UNIT_ENGLISH_FEET:
                                        asset.SetUnit (
                                                UNITNAME_FOOT,
                                                METERS_PER_FOOT);
                                        break;
                                case LXsPREFERENCE_VALUE_UNIT_ENGLISH_MILES:
                                        asset.SetUnit (
                                                UNITNAME_MILE,
                                                METERS_PER_MILE);
                                        break;
                        }
                        break;
                }

                case LXiPREFERENCE_VALUE_UNIT_SYSTEM_GAME_UNITS: {
                        float metersPerGameUnit = prefs.GetMetersPerGameUnit ();
                        asset.SetUnit (UNITNAME_GAME, metersPerGameUnit);
                        break;
                }

                case LXiPREFERENCE_VALUE_UNIT_SYSTEM_UNITLESS:
                default: {
                        /*
                         * Use default values of "meter" and "1.0".
                         */
                        break;
                }
        }

        return LOG_ERR (result);
}

/*
 * Add the <up_axis> element to the <asset> element.
 */
        LxResult
COLLADASceneSaver::AddAssetUpAxis (AssetElement& asset)
{
        LxResult		 result(LXe_OK);

        /*
         * The scene up axis is stored in the <visual_scene>/<asset> element.
         */
        switch (prefs.GetUpAxis ()) {
                case LXsPREFERENCE_VALUE_UP_AXIS_X:
                        asset.SetUpAxis (AssetElement::UP_AXIS_X);
                        break;

                case LXsPREFERENCE_VALUE_UP_AXIS_Z:
                        asset.SetUpAxis (AssetElement::UP_AXIS_Z);
                        break;

                case LXsPREFERENCE_VALUE_UP_AXIS_Y:
                default:
                        asset.SetUpAxis (AssetElement::UP_AXIS_Y);
                        break;
        }

        return LOG_ERR (result);
}

/*
 * Determine if we have at least one interesting item type.
 */
        bool
COLLADASceneSaver::FindItemTypes ()
{
        LxResult		 result(LXe_OK);
        bool			 foundOneItem(false);

        /*
         * Look up "save animation" setting from the config
         * for the COLLADAio Scene I/O prefs.
         */
        CLxReadUserValue ruv;
        if (ruv.Query ("sceneio.collada.save.animation")) {
                saveAnimation = (ruv.GetInt () != 0);
        }

        /*
         * Check if we have at least one effect/material.
         */
        haveAtLeastOneEffect = haveAtLeastOneMaterial =
                FindEffectMaterialItem ();

        /*
         * Look for at least one transformable item in all relevant item types.
         */
        foundOneItem = FindTransformableItems ();

        /*
         * Look for at least one controllable item in the item tree.
         */
        haveAtLeastOneController = FindControllableItems ();

        /*
         * Register item types and their channels using the item type
         * channel bind.
         */
        RegisterTypesAndChannels ();

        /*
         * Find items and their channel envelopes using our visitor.
         */
        if (FindItemsAndChannelEnvelopes ()) {
                foundOneItem = true;
        }

        /*
         * [TODO] Config option to set foundOneItem if an image library is present.
         */

        LOG_ERR (result);

        return foundOneItem;
}

/*
 * Check if we have at least one effect/material.
 */
        bool
COLLADASceneSaver::FindEffectMaterialItem ()
{
        bool	foundEffectMaterial(false);
        for (MaterialSet::iterator iter = materialTagSet.begin ();
             iter != materialTagSet.end(); ++iter) {
                materialTag = *iter;
                if (ScanMask (materialTag.c_str ())) {
                        while (NextLayer ()) {
                                if (!ChanInt (LXsICHAN_TEXTURELAYER_ENABLE)) {
                                        continue;
                                }

                                if (ItemIsA (LXsITYPE_ADVANCEDMATERIAL) ||
                                    ItemIsA (LXsITYPE_IMAGEMAP)) {
                                        foundEffectMaterial = true;
                                        break;
                                }
                                else {
                                        string itemType(ItemType ());
                                        log.Info (string("Other item type: ") + itemType);
                                }
                        }
                }

                if (foundEffectMaterial) {
                        break;
                }
        }

        return foundEffectMaterial;
}

/*
 * Look for at least one transform on all relevant item types.
 *
 * [TODO] This function should also be walking the layered transform graph.
 */
        bool
COLLADASceneSaver::FindTransformableItems ()
{
        LxResult		 result(LXe_OK);
        bool			 foundTransformableItem(false);

        StartScan ();

        /*
         * While iterating, we check that we recognize each item's type.
         */
        while (NextItem ()) {
                if ((ItemIsA (LXsITYPE_CAMERA) && prefs.SaveCameras ()) ||
                     ItemIsA (LXsITYPE_MESH) ||
                     (ItemIsA (LXsITYPE_GROUPLOCATOR) && prefs.SaveLocators ()) ||
                     (ItemIsA (LXsITYPE_LIGHT) && prefs.SaveLights ()) ||
                     (ItemIsA (LXsITYPE_LOCATOR) && prefs.SaveLocators ()) ||
                     ItemIsA (LXsITYPE_TEXTURELOC)) {

                        /*
                         * Item name for debugging during iteration.
                         */
                        string		 itemName = ItemName ();
                        string		 itemType = ItemType ();
                        foundTransformableItem = true;

                        if (saveAnimation) {
                                /*
                                 * Save off the selected item so it can be restored
                                 * after selecting a transform item.
                                 *
                                 * [TODO] We need to walk the layered transforms here
                                 *        as well, in case a secondary transform is
                                 *        animated but the primary transforms are not!
                                 */
                                CLxLoc_Item selectedItem;
                                if (GetItem (selectedItem)) {
                                        /*
                                         * Check for translation.
                                         */
                                        if (HasXformItem (LXiXFRM_POSITION) && XformItem (LXiXFRM_POSITION)) {
                                                CLxLoc_Envelope	envelope;
                                                if (ChanEnvelope (translationChannelXname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                                else if (ChanEnvelope (translationChannelYname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                                else if (ChanEnvelope (translationChannelZname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                        }
                                        SetItem (selectedItem);

                                        if (HasXformItem (LXiXFRM_ROTATION) && XformItem (LXiXFRM_ROTATION)) {
                                                CLxLoc_Envelope	envelope;
                                                if (ChanEnvelope (rotationChannelXname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                                else if (ChanEnvelope (rotationChannelYname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                                else if (ChanEnvelope (rotationChannelZname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                        }
                                        SetItem (selectedItem);

                                        if (HasXformItem (LXiXFRM_SCALE) && XformItem (LXiXFRM_SCALE)) {
                                                CLxLoc_Envelope	envelope;
                                                if (ChanEnvelope (scaleChannelXname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                                else if (ChanEnvelope (scaleChannelYname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                                else if (ChanEnvelope (scaleChannelZname.c_str (), envelope)) {
                                                        haveAtLeastOneAnimation = true;
                                                        haveAtLeastOneTransformAnimation = true;
                                                        break;
                                                }
                                        }
                                        SetItem (selectedItem);
                                }
                        }
                        else {
                                /*
                                 * We found our item, but since animation saving is
                                 * disabled, we don't need to scan for envelopes.
                                 */
                                break;
                        }
                }
        }

        LOG_ERR (result);

        return foundTransformableItem;
}

/*
 * ---------------------------------------------------------------------------
 * Channel registration.
 */

        void
COLLADASceneSaver::RegisterTypesAndChannels ()
{
        if (!isRegistered) {
                ItemTypeChannelRegistrar	registrar(itemTypeChannels);

                registrar.RegisterItemSubTypes ();
                registrar.RegisterChannels ();

                isRegistered = true;
        }
}

        bool
COLLADASceneSaver::FindItemsAndChannelEnvelopes ()
{
        bool	foundItem;

        itemTypeChannelVisitor.SetVisitExtent (
                VISIT_EXTENT_FIRST_WANTED_CHANNEL);
        itemTypeChannelVisitor.SetVisitTask (
                VISIT_TASK_FIND_ITEM_TYPES_AND_ACTIVE_CHANNELS);
        itemTypeChannels.VisitItemTypeChannels (&itemTypeChannelVisitor);

        haveAtLeastOneAnimation =
                haveAtLeastOneAnimation ||
                itemTypeChannelVisitor.FoundAnyChannel ();

        if (prefs.SaveCameras ()) {
                haveAtLeastOneCamera =
                        itemTypeChannelVisitor.FoundItemType (LXsITYPE_CAMERA);
                haveAtLeastOneCameraAnimation =
                        itemTypeChannelVisitor.FoundChannel (LXsITYPE_CAMERA);
        }

        if (prefs.SaveLights ()) {
                StringArray lightSubTypes;
                itemTypeChannels.GetItemSubTypes (LXsITYPE_LIGHT, lightSubTypes);
                haveAtLeastOneLightAnimation =
                        itemTypeChannelVisitor.FoundChannel (lightSubTypes);
        }

        haveAtLeastOneMesh =
                itemTypeChannelVisitor.FoundItemType (LXsITYPE_MESH);

        /*
         * Check for at least one non-empty mesh.
         */
        bool foundNonEmptyMesh = false;
        if (haveAtLeastOneMesh) {
                StartScan ();
                while (NextMesh ()) {
                        if (PointCount ()) {
                                foundNonEmptyMesh = true;
                                break;
                        }
                }
                if (!foundNonEmptyMesh) {
                        haveAtLeastOneMesh = false;
                }
        }

        haveAtLeastOneMeshAnimation = haveAtLeastOneMesh &&
                itemTypeChannelVisitor.FoundChannel (LXsITYPE_MESH);

        foundItem = itemTypeChannelVisitor.FoundAnyItemType ();

        return foundItem;
}

/*
 * Exporting layered transforms is switchable. Fall back to
 * exporting a baked matrix when this is disabled.
 */
        bool
COLLADASceneSaver::ShouldExportLayeredTransforms () const
{
        /*
         * Baking the matrices disables the transform layering.
         */
        bool exportLayeredTransforms = !prefs.BakeMatrices ();

        return exportLayeredTransforms;
}

/*
 * Add an animation library.
 */
        LxResult
COLLADASceneSaver::AddAnimationLibrary (COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        if (haveAtLeastOneAnimation) {
                log.Info ("Adding animation library.");

                AnimationLibraryElement animationLibrary(collada);

                /*
                 * Grab the transform graph, so we can look
                 * for layered transforms.
                 */
                CLxUser_Scene		 scene(SceneObject ());
                CLxUser_SceneGraph	 sceneGraph;
                scene.GetGraph (LXsGRAPH_XFRMCORE, sceneGraph);
                itemGraph.set (sceneGraph);

                StartScan ();

                /*
                 * While iterating, we check that we recognize each item's type.
                 */
                if (haveAtLeastOneTransformAnimation) {
                        while (NextItem ()) {
                                if ((ItemIsA (LXsITYPE_CAMERA) && prefs.SaveCameras ()) ||
                                    ItemIsA (LXsITYPE_MESH) ||
                                    (ItemIsA (LXsITYPE_GROUPLOCATOR) && prefs.SaveLocators ()) ||
                                    (ItemIsA (LXsITYPE_LIGHT) && prefs.SaveLights ()) ||
                                    (ItemIsA (LXsITYPE_LOCATOR) && prefs.SaveLocators ()) ||
                                    ItemIsA (LXsITYPE_TEXTURELOC)) {
                                        /*
                                         * Item name for debugging during iteration.
                                         */
                                        string		 itemName = ItemName ();
                                        /*
                                         * Save off the selected item so it can be restored
                                         * after selecting a transform item.
                                         */
                                        CLxUser_Item item;
                                        if (ReallySaving () &&
                                            GetItem (item)) {
                                                /*
                                                 * Camera, mesh, and light items are
                                                 * transformable and instanced from
                                                 * a library, so build a custom item ID.
                                                 */
                                                string libraryElementName;
                                                if (ItemIsA (LXsITYPE_CAMERA)) {
                                                        libraryElementName =
                                                                ELEMENT_CAMERA;
                                                }
                                                else if (ItemIsA (LXsITYPE_MESH)) {
                                                        libraryElementName =
                                                                ELEMENT_GEOMETRY;
                                                }
                                                else if (ItemIsA (LXsITYPE_LIGHT)) {
                                                        libraryElementName =
                                                                ELEMENT_LIGHT;
                                                }
                                                else {
                                                        libraryElementName = ELEMENT_NODE;
                                                }

                                                result = AddTransformAnimations (
                                                        animationLibrary, item,
                                                        libraryElementName);
                                        }
                                }
                        }
                }

                /*
                 * Iterate over all channels for possible animation.
                 */
                itemTypeChannelVisitor.SetVisitExtent (
                        VISIT_EXTENT_ALL_CHANNELS);
                itemTypeChannelVisitor.SetVisitTask (
                        VISIT_TASK_BUILD_ANIMATION_LIBRARY);
                itemTypeChannelVisitor.SetAnimationLibrary (&animationLibrary);

                if (prefs.SaveCameras ()) {
                        /*
                         * Add any camera animations.
                         */
                        itemTypeChannels.VisitItemTypeChannels (
                                string(LXsITYPE_CAMERA), &itemTypeChannelVisitor);
                }

                if (prefs.SaveLights ()) {
                        /*
                         * Add any light animations.
                         */
                        itemTypeChannels.VisitItemTypeChannels (
                                string(LXsITYPE_LIGHT), &itemTypeChannelVisitor);
                }

                /*
                 * Add any mesh animations.
                 */
                itemTypeChannels.VisitItemTypeChannels (
                        string(LXsITYPE_MESH), &itemTypeChannelVisitor);

                /*
                 * Add any render animations.
                 */
                itemTypeChannels.VisitItemTypeChannels (
                        string(LXsITYPE_POLYRENDER), &itemTypeChannelVisitor);

                /*
                 * Add any environment animations.
                 */
                itemTypeChannels.VisitItemTypeChannels (
                        string(LXsITYPE_ENVIRONMENT), &itemTypeChannelVisitor);
        }

        return LOG_ERR (result);
}

/*
 * Add the transform animations for the given item.
 */
        LxResult
COLLADASceneSaver::AddTransformAnimations (
        AnimationLibraryElement	&library,
        CLxUser_Item		&item,
        const string		&targetLibraryElementName)
{
        LxResult		 result(LXe_OK);

        /*
         * Exporting layered transforms is switchable. Fall back to
         * exporting the matrix transforms if baked matrices are selected.
         */
        if (ShouldExportLayeredTransforms ()) {
                result = AddLayeredTransformAnimations (
                        library, item, targetLibraryElementName);
        }
        else {
                result = AddMatrixTransformAnimations (
                        library, item, targetLibraryElementName);
        }

        return LOG_ERR (result);
}

/*
 * Add the layered transform animations for the given item.
 */
        LxResult
COLLADASceneSaver::AddLayeredTransformAnimations (
        AnimationLibraryElement	&library,
        CLxUser_Item		&item,
        const string		&targetLibraryElementName)
{
        LxResult		 result(LXe_OK);

        /*
         * This block is used when transform layering is enabled, in which
         * case both the fixed and user-added transform channels are found
         * by iterating over the item graph.
         */
        string			 itemID = ItemIdentity ();
        unsigned transformCount = itemGraph.Reverse (item);
        for (unsigned transformIndex = 0;
             transformIndex < transformCount; ++transformIndex) {
                CLxUser_Item transform;
                if (itemGraph.Reverse (item, transformIndex, transform)) {
                        SetItem (transform);

                        string transformID(ItemIdentity ());
                        const char *xformType = ItemType ();
                        if (string(xformType) == string(LXsITYPE_ROTATION)) {
                                result = AddAnimationRotateEnvelopes (
                                        library, itemID,
                                        targetLibraryElementName,
                                        transformID);
                        }
                        else if (string(xformType) == string(LXsITYPE_SCALE)) {
                                result = AddAnimationScaleEnvelopes (
                                        library, itemID,
                                        targetLibraryElementName,
                                        transformID);
                        }
                        else if (string(xformType) == string(LXsITYPE_TRANSLATION)) {
                                result = AddAnimationTranslateEnvelopes (
                                        library, itemID,
                                        targetLibraryElementName,
                                        transformID);
                        }

                        LXtItemType itemType = transform.Type ();

#if defined(COLLADASAVER_VERBOSE_LOGGING)
                        log.Info (
                                string ("Transform type: ") +
                                IntegerToString(itemType));
                        LogItemChannels (transform);
#endif

                        LXxUNUSED (itemType);
                }
        }

        /*
         * Restore the current item back above the transforms.
         */
        SetItem (item);

        return LOG_ERR (result);
}

/*
 * Add the matrix transform animations for the given item.
 */
        LxResult
COLLADASceneSaver::AddMatrixTransformAnimations (
        AnimationLibraryElement	&library,
        CLxUser_Item		&item,
        const string		&targetLibraryElementName)
{
        LxResult		 result(LXe_OK);

        /*
         * Provides a "Bake matrices" option, to form a single,
         * pre-multiplied transform from all transform layers.
         *
         * We build the matrix animation envelope in two-passes:
         *
         * In the first pass, we build a vector of keyframe times
         * across all transform types.
         *
         * In the second pass, we multiply all transforms at each time
         * into a single matrix and write it out into a matrix envelope.
         */

        /*
         * Build a vector of keyframe times across all transform types.
         */
        Element::FloatSet	 times;
        if ((GetItemKeyframeTimes (item, times) == LXe_OK) && times.size () > 0) {
                /*
                 * Multiply all transforms at each time into a single matrix and
                 * write it out into a matrix envelope.
                 */
                result = AddMatrixTransformAnimationsAtTimes (
                        library, item, targetLibraryElementName, times);
        }

        /*
         * Restore the current item back above the transforms.
         */
        SetItem (item);

        return LOG_ERR (result);
}

/*
 * Build a vector of keyframe times across all transform types.
 */
        LxResult
COLLADASceneSaver::GetItemKeyframeTimes (
        CLxUser_Item			&item,
        Element::FloatSet		&times)
{
        LxResult	result(LXe_OK);

        unsigned transformCount = itemGraph.Reverse (item);
        for (unsigned transformIndex = 0;
             transformIndex < transformCount; ++transformIndex) {
                CLxUser_Item transform;
                if (itemGraph.Reverse (item, transformIndex, transform)) {
                        SetItem (transform);

                        const char *xformType = ItemType ();
                        if (string(xformType) == string(LXsITYPE_SCALE)) {
                                result = GetScaleKeyframeTimes (times);
                        }
                        else if (string(xformType) == string(LXsITYPE_ROTATION)) {
                                result = GetRotateKeyframeTimes (times);
                        }
                        else if (string(xformType) == string(LXsITYPE_TRANSLATION)) {
                                result = GetTranslateKeyframeTimes (times);
                        }
                }
        }

        /*
         * Restore the current item back above the transforms.
         */
        SetItem (item);

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::GetScaleKeyframeTimes (
        Element::FloatSet		&times)
{
        LxResult	result(LXe_FALSE);

        if ((GetChannelKeyframeTimes (scaleChannelXname, times) == LXe_OK) &&
            (GetChannelKeyframeTimes (scaleChannelYname, times) == LXe_OK) &&
            (GetChannelKeyframeTimes (scaleChannelZname, times) == LXe_OK)) {
                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::GetRotateKeyframeTimes (
        Element::FloatSet		&times)
{
        LxResult	result(LXe_FALSE);

        if ((GetChannelKeyframeTimes (rotationChannelXname, times) == LXe_OK) &&
            (GetChannelKeyframeTimes (rotationChannelYname, times) == LXe_OK) &&
            (GetChannelKeyframeTimes (rotationChannelZname, times) == LXe_OK)) {
                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::GetTranslateKeyframeTimes (
        Element::FloatSet		&times)
{
        LxResult	result(LXe_FALSE);

        if ((GetChannelKeyframeTimes (translationChannelXname, times) == LXe_OK) &&
            (GetChannelKeyframeTimes (translationChannelYname, times) == LXe_OK) &&
            (GetChannelKeyframeTimes (translationChannelZname, times) == LXe_OK)) {
                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        static void
InsertArrayIntoSet (
        const Element::FloatArray	&valueArray,
        Element::FloatSet		&valueSet)
{
        for (Element::FloatArray::const_iterator iter = valueArray.begin ();
             iter != valueArray.end (); ++iter) {
                valueSet.insert (*iter);
        }
}

        LxResult
COLLADASceneSaver::GetChannelKeyframeTimes (
        const string		&channelName,
        Element::FloatSet	&times)
{
        LxResult	result(LXe_FALSE);

        CLxUser_Envelope	envelope;
        if (ChanEnvelope (channelName.c_str (), envelope)) {
                AnimationElement::Envelope		animationEnvelope;
                AnimationElement::Envelope_modo501	modoEnvelope;
                if (GetKeyFrames(
                        PARAM_TYPE_FLOAT,
                        envelope,
                        animationEnvelope,
                        modoEnvelope)) {
                        InsertArrayIntoSet (
                                animationEnvelope.times, times);
                        result = LXe_OK;
                }
        }

        return LOG_ERR (result);
}

/*
 * Multiply all transforms at each time into a single matrix and
 * write it out into a matrix envelope.
 */
        LxResult
COLLADASceneSaver::AddMatrixTransformAnimationsAtTimes (
        AnimationLibraryElement		&library,
        CLxUser_Item			&item,
        const string			&targetLibraryElementName,
        const Element::FloatSet		&times)
{
        LxResult	result(LXe_OK);

        AnimationElement::MatrixEnvelope matrixEnvelope;
        if (LXx_OK (BuildMatrixEnvelope (item, times, matrixEnvelope))) {
                /*
                 * Write out the array of matrices.
                 */
                TransformAnimationElement animationTransform(
                        library, ItemIdentity (), targetLibraryElementName,
                        matrixEnvelope);
        }

        return LOG_ERR (result);
}

/*
 * Build an envelope of matrices at the given times.
 */
        LxResult
COLLADASceneSaver::BuildMatrixEnvelope (
        CLxUser_Item				&item,
        const Element::FloatSet			&times,
        AnimationElement::MatrixEnvelope	&envelope)
{
        LxResult	result(LXe_OK);

        /*
         * For each keyframe time, we reverse iterate over the transform
         * graph and gather the scale, rotate, and translate components to
         * compose a matrix for that time, and then add it to our matrix
         * array to be added to the animation element.
         */
        for (Element::FloatSet::const_iterator iter = times.begin ();
             iter != times.end (); ++iter) {
                float time = *iter;
                envelope.times.push_back (time);

                /*
                 * Compose the matrix.
                 */
                Matrix4Wrap	matrix;
                Matrix4Identity (matrix.m);
                unsigned transformCount = itemGraph.Reverse (item);
                for (unsigned transformIndex = 0;
                     transformIndex < transformCount; ++transformIndex) {
                        CLxUser_Item transform;
                        if (itemGraph.Reverse (item, transformIndex, transform)) {
                                SetItem (transform);

                                const char *xformType = ItemType ();
                                Vector3	vec;
                                if (string(xformType) == string(LXsITYPE_SCALE)) {
                                        result = GetScaleKeyframeValueAtTime (
                                                time, vec);
                                        LXtMatrix4 sm;
                                        Matrix4CreateScale (sm, vec);
                                        Matrix4Compose (matrix.m, sm);
                                }
                                else if (string(xformType) == string(LXsITYPE_ROTATION)) {
                                        result = GetRotateKeyframeValueAtTime (
                                                time, vec);

                                        /*
                                         * Take rotation order
                                         * into account.
                                         */
                                        int axis[3];
                                        BuildAxisOrder (
                                                ChanInt (LXsICHAN_ROTATION_ORDER),
                                                axis);

                                        LXtMatrix4 rm;
                                        Matrix4CreateRotation (
                                                rm, vec[axis[0]], axis[0]);
                                        Matrix4Compose (matrix.m, rm);

                                        Matrix4CreateRotation (
                                                rm, vec[axis[1]], axis[1]);
                                        Matrix4Compose (matrix.m, rm);

                                        Matrix4CreateRotation (
                                                rm, vec[axis[2]], axis[2]);
                                        Matrix4Compose (matrix.m, rm);
                                }
                                else if (string(xformType) == string(LXsITYPE_TRANSLATION)) {
                                        result = GetTranslateKeyframeValueAtTime (
                                                time, vec);
                                        LXtMatrix4 tm;
                                        Matrix4CreateTranslation (
                                                tm, vec);
                                        Matrix4Compose (matrix.m, tm);
                                }
                        }
                }

                /*
                 * Add the matrix keyframe to the array.
                 */
                envelope.outputs.push_back (matrix);
        }

        /*
         * Restore the current item back above the transforms.
         */
        SetItem (item);

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::GetScaleKeyframeValueAtTime (
        double				time,
        Vector3				&value)
{
        LxResult	result(LXe_OK);

        vector<string>	channels;
        channels.push_back (scaleChannelXname);
        channels.push_back (scaleChannelYname);
        channels.push_back (scaleChannelZname);
        result = GetEnvelopeKeyframeValueAtTime (time, channels, value);

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::GetRotateKeyframeValueAtTime (
        double				time,
        Vector3				&value)
{
        LxResult	result(LXe_OK);

        vector<string>	channels;
        channels.push_back (rotationChannelXname);
        channels.push_back (rotationChannelYname);
        channels.push_back (rotationChannelZname);
        result = GetEnvelopeKeyframeValueAtTime (time, channels, value);

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::GetTranslateKeyframeValueAtTime (
        double				time,
        Vector3				&value)
{
        LxResult	result(LXe_OK);

        vector<string>	channels;
        channels.push_back (translationChannelXname);
        channels.push_back (translationChannelYname);
        channels.push_back (translationChannelZname);
        result = GetEnvelopeKeyframeValueAtTime (time, channels, value);

        return LOG_ERR (result);
}

/*
 * Fetch a value vector for the keyframe values at the given time,
 * on the given channels.
 */
        LxResult
COLLADASceneSaver::GetEnvelopeKeyframeValueAtTime (
        double			 time,
        vector<string>		 channels,
        Vector3			&value)
{
        LxResult	result(LXe_OK);

        for (unsigned axisIndex = 0; axisIndex < 3; ++axisIndex) {
                CLxUser_Envelope	envelope;
                if (ChanEnvelope (channels.at (axisIndex).c_str (), envelope)) {
                        value[axisIndex] = envelope.Value (time);
                }
        }

        return LOG_ERR (result);
}

/*
 * Add any translation envelopes.
 */
        LxResult
COLLADASceneSaver::AddAnimationTranslateEnvelopes (
        AnimationLibraryElement		&library,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformID)
{
        LxResult		 result(LXe_OK);

        CLxUser_Envelope	envelopeX;
        if (ChanEnvelope (translationChannelXname.c_str (), envelopeX)) {
                result = AddAnimationTranslateEnvelope (
                        library, envelopeX,
                        itemName, targetLibraryElementName, transformID,
                        string(ATTRVALUE_X));
        }

        CLxUser_Envelope	envelopeY;
        if (ChanEnvelope (translationChannelYname.c_str (), envelopeY)) {
                result = AddAnimationTranslateEnvelope (
                        library, envelopeY,
                        itemName, targetLibraryElementName, transformID,
                        string(ATTRVALUE_Y));
        }

        CLxUser_Envelope	envelopeZ;
        if (ChanEnvelope (translationChannelZname.c_str (), envelopeZ)) {
                result = AddAnimationTranslateEnvelope (
                        library, envelopeZ,
                        itemName, targetLibraryElementName, transformID,
                        string(ATTRVALUE_Z));
        }

        return LOG_ERR (result);
}

/*
 * Add any rotation envelopes.
 */
        LxResult
COLLADASceneSaver::AddAnimationRotateEnvelopes (
        AnimationLibraryElement		&library,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformID)
{
        LxResult		 result(LXe_OK);

        CLxUser_Envelope	envelopeX;
        if (ChanEnvelope (rotationChannelXname.c_str (), envelopeX)) {
                result = AddAnimationRotateEnvelope (
                        library, envelopeX,
                        itemName, targetLibraryElementName,
                        transformID, string(ATTRVALUE_X));
        }

        CLxUser_Envelope	envelopeY;
        if (ChanEnvelope (rotationChannelYname.c_str (), envelopeY)) {
                result = AddAnimationRotateEnvelope (
                        library, envelopeY,
                        itemName, targetLibraryElementName,
                        transformID, string(ATTRVALUE_Y));
        }

        CLxUser_Envelope	envelopeZ;
        if (ChanEnvelope (rotationChannelZname.c_str (), envelopeZ)) {
                result = AddAnimationRotateEnvelope (
                        library, envelopeZ,
                        itemName, targetLibraryElementName,
                        transformID, string(ATTRVALUE_Z));
        }

        return LOG_ERR (result);
}

/*
 * Add any scale envelopes.
 */
        LxResult
COLLADASceneSaver::AddAnimationScaleEnvelopes (
        AnimationLibraryElement		&library,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformID)
{
        LxResult		 result(LXe_OK);

        CLxUser_Envelope	envelopeX;
        if (ChanEnvelope (scaleChannelXname.c_str (), envelopeX)) {
                result = AddAnimationScaleEnvelope (
                        library, envelopeX,
                        itemName, targetLibraryElementName,
                        transformID, string(ATTRVALUE_X));
        }

        CLxUser_Envelope	envelopeY;
        if (ChanEnvelope (scaleChannelYname.c_str (), envelopeY)) {
                result = AddAnimationScaleEnvelope (
                        library, envelopeY,
                        itemName, targetLibraryElementName,
                        transformID, string(ATTRVALUE_Y));
        }

        CLxUser_Envelope	envelopeZ;
        if (ChanEnvelope (scaleChannelZname.c_str (), envelopeZ)) {
                result = AddAnimationScaleEnvelope (
                        library, envelopeZ,
                        itemName, targetLibraryElementName,
                        transformID, string(ATTRVALUE_Z));
        }

        return LOG_ERR (result);
}

/*
 * Add a translate transform element for the given envelope and axis.
 */
        LxResult
COLLADASceneSaver::AddAnimationTranslateEnvelope (
        AnimationLibraryElement		&library,
        CLxUser_Envelope		&envelope,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformID,
        const string			&axisName)
{
        LxResult		 result;

        /*
         * NOTE: This is the same call that is made by AddAnimationScaleEnvelope,
         *       but since rotation is different, for clarity we'll leave all
         *       all three transform wrappers as separate functions.
         */
        result = AddAnimationTransformEnvelope (
                library, envelope,
                itemName, targetLibraryElementName,
                transformID, axisName, axisName);

        return LOG_ERR (result);
}

/*
 * Add a rotate transform element for the given envelope and axis.
 */
        LxResult
COLLADASceneSaver::AddAnimationRotateEnvelope (
        AnimationLibraryElement		&library,
        CLxUser_Envelope		&envelope,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformID,
        const string			&axisName)
{
        LxResult		 result;

        result = AddAnimationTransformEnvelope (
                library, envelope,
                itemName, targetLibraryElementName,
                transformID, axisName, string(ATTRVALUE_ANGLE),
                RAD2DEG,
                true);		// append axis to target transform name

        return LOG_ERR (result);
}

/*
 * Add a scale transform element for the given envelope and axis.
 */
        LxResult
COLLADASceneSaver::AddAnimationScaleEnvelope (
        AnimationLibraryElement	&library,
        CLxUser_Envelope		&envelope,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformID,
        const string			&axisName)
{
        LxResult		 result;

        /*
         * NOTE: This is the same call that is made by AddAnimationTranslateEnvelope,
         *       but since rotation is different, for clarity we'll leave all
         *       all three transform wrappers as separate functions.
         */
        result = AddAnimationTransformEnvelope (
                library, envelope,
                itemName, targetLibraryElementName,
                transformID, axisName, axisName);

        return LOG_ERR (result);
}

/*
 * Add a transform animation element for the given envelope and axis.
 */
        LxResult
COLLADASceneSaver::AddAnimationTransformEnvelope (
        AnimationLibraryElement		&library,
        CLxUser_Envelope		&envelope,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformID,
        const string			&axisName,
        const string			&componentName,
        double				 valueScale,
        bool				 appendAxisToTargetTransformName)
{
        LxResult		 result(LXe_OK);

        /*
         * Build arrays of the transform channel keyframe values.
         */
        AnimationElement::Envelope			animationEnvelope;
        AnimationElement::Envelope_modo501		modoEnvelope;
        if (GetKeyFrames (
                PARAM_TYPE_FLOAT, envelope, animationEnvelope, modoEnvelope, valueScale)) {
                /*
                 * Add the transform animation.
                 */
                if (prefs.SaveModoProfile ()) {
                        TransformAnimationElement animationTransform(
                                library, itemName, targetLibraryElementName,
                                transformID, axisName, componentName,
                                appendAxisToTargetTransformName,
                                animationEnvelope, modoEnvelope,
                                prefs.SaveMayaProfile ());
                }
                else {
                        TransformAnimationElement animationTransform(
                                library, itemName, targetLibraryElementName,
                                transformID, axisName, componentName,
                                appendAxisToTargetTransformName,
                                animationEnvelope,
                                prefs.SaveMayaProfile ());
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddAnimationParam (
        AnimationLibraryElement		&library,
        CLxLoc_Item			&item,
        const string			&channel,
        const string			&paramSID,
        const string			&paramName,
        ParamType			 paramType)
{
        LxResult			 result(LXe_OK);

        CLxLoc_Envelope	envelopeLoc;

        /*
         * [TODO] Add an outer loop that iterates over each color channel.
         */
        string channelName(channel);
        if (paramType == PARAM_TYPE_COLOR) {
                const char* CHANNEL_R = ".R";
                channelName += string(CHANNEL_R);
        }

        if (ChanEnvelope (channelName.c_str (), envelopeLoc)) {
                CLxUser_Envelope envelope(
                        (ILxUnknownID)envelopeLoc.m_loc);
                AnimationElement::Envelope		animationEnvelope;
                AnimationElement::Envelope_modo501	modoEnvelope;
                if (GetKeyFrames (
                        paramType, envelope, animationEnvelope, modoEnvelope)) {
                        string		itemName(ItemName ());

                        /*
                         * Determine the target library element name.
                         *
                         * [TODO] Register these mappings to avoid switch/if/else.
                         */
                        string		targetLibraryElementName;
                        if (item.TestType (ItemType (LXsITYPE_CAMERA))) {
                                targetLibraryElementName = ELEMENT_CAMERA;
                        }
                        else if (item.TestType (ItemType (LXsITYPE_ADVANCEDMATERIAL))) {
                                targetLibraryElementName = ELEMENT_EFFECT;
                        }
                        else if (item.TestType (ItemType (LXsITYPE_LIGHT))) {
                                targetLibraryElementName = ELEMENT_LIGHT;
                        }
                        else if (item.TestType (ItemType (LXsITYPE_MESH))) {
                                targetLibraryElementName = ELEMENT_GEOMETRY;
                        }
                        else if ((item.TestType (ItemType (LXsITYPE_POLYRENDER))) ||
                                 (item.TestType (ItemType (LXsITYPE_ENVIRONMENT)))) {
                                targetLibraryElementName = ELEMENT_NODE;
                        }

                        if (prefs.SaveModoProfile ()) {
                                ParamAnimationElement animationParam(
                                        library, itemName,
                                        targetLibraryElementName,
                                        paramSID,
                                        paramName,
                                        animationEnvelope,
                                        modoEnvelope,
                                        prefs.SaveMayaProfile ());
                        }
                        else {
                                ParamAnimationElement animationParam(
                                        library, itemName,
                                        targetLibraryElementName,
                                        paramSID,
                                        paramName,
                                        animationEnvelope,
                                        prefs.SaveMayaProfile ());
                        }
                }
        }

        return LOG_ERR (result);
}

        double
COLLADASceneSaver::GetFrameRate ()
{
        LxResult		 result(LXe_OK);
        double			 frameRate = 30;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        frameRate = ChanFloat (LXsICHAN_SCENE_FPS);
                }
                SetItem (curItem);
        }

        LogError (result, "GetFrameRate");

        return frameRate;
}

        double
COLLADASceneSaver::GetStartTime ()
{
        LxResult		 result(LXe_OK);
        double			 startTime = 0;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        startTime = ChanFloat (LXsICHAN_SCENE_SCENES);
                }
                SetItem (curItem);
        }

        LogError (result, "GetStartTime");

        return startTime;
}

        double
COLLADASceneSaver::GetEndTime ()
{
        LxResult		 result(LXe_OK);
        double			 endTime = 0;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        endTime = ChanFloat (LXsICHAN_SCENE_SCENEE);
                }
                SetItem (curItem);
        }

        LogError (result, "GetEndTime");

        return endTime;
}

        double
COLLADASceneSaver::GetCurrentStartTime ()
{
        LxResult		 result(LXe_OK);
        double			 currentStartTime = 0;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        currentStartTime = ChanFloat (LXsICHAN_SCENE_CURRENTS);
                }
                SetItem (curItem);
        }

        LogError (result, "GetCurrentStartTime");

        return currentStartTime;
}

        double
COLLADASceneSaver::GetCurrentEndTime ()
{
        LxResult		 result(LXe_OK);
        double			 currentEndTime = 0;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        currentEndTime = ChanFloat (LXsICHAN_SCENE_CURRENTE);
                }
                SetItem (curItem);
        }

        LogError (result, "GetCurrentEndTime");

        return currentEndTime;
}

        double
COLLADASceneSaver::GetTime ()
{
        LxResult		 result(LXe_OK);
        double			 time = 0;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        time = ChanFloat (LXsICHAN_SCENE_TIME);
                }
                SetItem (curItem);
        }

        LogError (result, "GetTime");

        return time;
}

        double
COLLADASceneSaver::GetDefaultDrawSize ()
{
        LxResult		 result(LXe_OK);
        double			 drawSize = 1.0;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        drawSize = ChanFloat (LXsICHAN_SCENE_DRAWSIZE);
                }
                SetItem (curItem);
        }

        LogError (result, "GetDefaultDrawSize");

        return drawSize;
}

        string
COLLADASceneSaver::GetTimeSystem ()
{
        LxResult		 result(LXe_OK);
        string			 timeSystem;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        timeSystem = GetTextHintEncodedChannelValue (
                                *this, LXsICHAN_SCENE_TIMESYS);
                }
                SetItem (curItem);
        }

        LogError (result, "GetTimeSystem");

        return timeSystem;
}

        int
COLLADASceneSaver::GetUpAxis ()
{
        LxResult		 result(LXe_OK);
        int			 upAxis = LXiICVAL_SCENE_UPAXIS_Y;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        upAxis = ChanInt (LXsICHAN_SCENE_UPAXIS);
                }
                SetItem (curItem);
        }

        LogError (result, "GetUpAxis");

        return upAxis;
}


        string
COLLADASceneSaver::GetAuthor ()
{
        return GetTag (LXi_TAG_AUTHOR);
}

        string
COLLADASceneSaver::GetCopyright ()
{
        return GetTag (LXi_TAG_COPYRIGHT);
}

        string
COLLADASceneSaver::GetKeywords ()
{
        return GetTag (LXi_TAG_KEYWORDS);
}

        string
COLLADASceneSaver::GetRevision ()
{
        return GetTag (LXi_TAG_REVISION);
}

        string
COLLADASceneSaver::GetSubject ()
{
        return GetTag (LXi_TAG_SUBJECT);
}

        string
COLLADASceneSaver::GetTitle ()
{
        return GetTag (LXi_TAG_TITLE);
}

        string
COLLADASceneSaver::GetTag (LXtID4 tagID)
{
        LxResult		 result(LXe_OK);
        string			 tag;
        CLxLoc_Item		 curItem;
        if (GetItem (curItem)) {
                StartScan (LXsITYPE_SCENE);
                if (NextItem ()) {
                        const char *itemTag = ItemTag (tagID);
                        if (itemTag) {
                                tag = itemTag;
                        }
                }
                SetItem (curItem);
        }

        LogError (result, "GetTag");

        return tag;
}

        static AnimationSourceElement::InfinityBehavior
modoInfinityToTechniqueProfile_modo401 (LXtEndBehavior modoBehavior)
{
        AnimationSourceElement::InfinityBehavior	behavior;
        switch (modoBehavior) {

                case LXiENV_NONE: // stop
                        behavior = AnimationSourceElement::INFINITY_BEHAVIOR_STOP;
                        break;

                case LXiENV_LINEAR: // linear
                        behavior = AnimationSourceElement::INFINITY_BEHAVIOR_LINEAR;
                        break;

                case LXiENV_REPEAT: // repeat
                        behavior = AnimationSourceElement::INFINITY_BEHAVIOR_REPEAT;
                        break;

                case LXiENV_OSCILLATE: // oscillate
                        behavior = AnimationSourceElement::INFINITY_BEHAVIOR_OSCILLATE;
                        break;

                case LXiENV_OFFSETREPEAT: // offset repeat
                        behavior = AnimationSourceElement::INFINITY_BEHAVIOR_OFFSET_REPEAT;
                        break;

                case LXiENV_RESET: // reset
                        behavior = AnimationSourceElement::INFINITY_BEHAVIOR_RESET;
                        break;

                case LXiENV_CONSTANT:	// constant
                default:
                        behavior = AnimationSourceElement::INFINITY_BEHAVIOR_CONSTANT;
                        break;
        }

        return behavior;
}

        static AnimationSourceElement::InfinityBehavior
PreInfinityBehavior (CLxUser_Envelope &envelope)
{
        return modoInfinityToTechniqueProfile_modo401 (
                static_cast<LXtEndBehavior>(envelope.EndBehavior (LXiENVSIDE_IN)));
}

        static AnimationSourceElement::InfinityBehavior
PostInfinityBehavior (CLxUser_Envelope &envelope)
{
        return modoInfinityToTechniqueProfile_modo401 (
                static_cast<LXtEndBehavior>(envelope.EndBehavior (LXiENVSIDE_OUT)));
}

        bool
COLLADASceneSaver::GetKeyFrames (
        ParamType				 paramType,
        CLxUser_Envelope			&envelope,
        AnimationElement::Envelope		&animationEnvelope,
        AnimationElement::Envelope_modo501	&modoEnvelope,
        double					 valueScale)
{
        bool			 atLeastOneKey(false);

        /* Check for a recognized envelope interpolation type. */
        bool			 knownInterpolationType;
        unsigned		 interpolationType = envelope.Interpolation ();
        switch (interpolationType) {
            case LXiENVv_INTERP_CURVE:
            case LXiENVv_INTERP_LINEAR:
            case LXiENVv_INTERP_STEPPED:
                knownInterpolationType = true;
                break;

            default:
                knownInterpolationType = false;
                break;
        }

        if (prefs.SampleAnimation ()) {
                GetSampledKeyFrames (paramType, envelope, animationEnvelope, valueScale);
        }
        else if (knownInterpolationType) {
                CLxUser_Keyframe	 key (envelope);
                LxResult		 keyResult = key.First ();
                Element::BoolArray	 brokenValues, brokenWeights, brokenSlopes;
                bool			 atLeastOneBrokenValue(false),
                                         atLeastOneBrokenWeight(false),
                                         atLeastOneBrokenSlope(false);

                while (keyResult != LXe_NOTFOUND) {
                        double time = key.Time ();
                        animationEnvelope.times.push_back (static_cast<float>(time));

                        unsigned int 	 brokenFlags;
                        bool isBrokenValue(false);
                        bool isBrokenWeight(false);
                        bool isBrokenSlope(false);
                        if (interpolationType == LXiENVv_INTERP_CURVE) {
                                /*
                                 * These arrays are temporary, until we have at
                                 * least one broken value, weight, or slope.
                                 */
                                key.GetBroken (&brokenFlags, 0);
                                isBrokenValue = (brokenFlags & LXfKEYBREAK_VALUE) ? true : false;
                                brokenValues.push_back (isBrokenValue);

                                isBrokenWeight = (brokenFlags & LXfKEYBREAK_WEIGHT) ? true : false;
                                brokenWeights.push_back (isBrokenWeight);

                                isBrokenSlope = (brokenFlags & LXfKEYBREAK_SLOPE) ? true : false;
                                brokenSlopes.push_back (isBrokenSlope);
                        }

                        double value;
                        double inValue, outValue;
                        if (isBrokenValue) {
                                atLeastOneBrokenValue = true;

                                /*
                                 * Push back a time for each keyframe that is broken by value.
                                 */
                                modoEnvelope.brokenValueTimes.push_back (static_cast<float>(time));

                                if (paramType == PARAM_TYPE_INT) {
                                        /*
                                         * Integer keyframe values are not scaled.
                                         */
                                        int intInValue, intOutValue;
                                        keyResult = key.GetValueI (&intInValue, LXiENVSIDE_IN);
                                        keyResult = key.GetValueI (&intOutValue, LXiENVSIDE_OUT);
                                        inValue = static_cast<double>(intInValue);
                                        outValue = static_cast<double>(intOutValue);
                                }
                                else {
                                        keyResult = key.GetValueF (&inValue, LXiENVSIDE_IN);
                                        keyResult = key.GetValueF (&outValue, LXiENVSIDE_OUT);
                                }

                                /*
                                 * The common profile only permits one value per time.
                                 */
                                animationEnvelope.outputs.push_back (static_cast<float>(inValue));

                                modoEnvelope.brokenInTanValues.push_back (static_cast<float>(inValue));
                                modoEnvelope.brokenOutTanValues.push_back (static_cast<float>(outValue));
                        }
                        else {
                                if (paramType == PARAM_TYPE_INT) {
                                        /*
                                         * Integer keyframe values are not scaled.
                                         */
                                        int intValue;
                                        keyResult = key.GetValueI (&intValue, LXiENVSIDE_BOTH);
                                        value = static_cast<double>(intValue);
                                }
                                else {
                                        keyResult = key.GetValueF (&value, LXiENVSIDE_BOTH);
                                        value *= valueScale;
                                }
                                animationEnvelope.outputs.push_back (static_cast<float>(value));
                        }

                        LXtSlopeType	 slopeModeIn = LXiSLOPE_LINEAR_IN;
                        LXtSlopeType	 slopeModeOut = LXiSLOPE_LINEAR_IN;

                        if (envelope.Interpolation () == LXiENVv_INTERP_CURVE) {
                                key.GetSlopeType (&slopeModeIn, 0, LXiENVSIDE_IN);
                                key.GetSlopeType (&slopeModeOut, 0, LXiENVSIDE_OUT);
                        }

                        /*
                         * There appears to be some strange behavior with
                         * mixed slope types when using STEPPED, so for now
                         * we only allow unified slopes for stepped.
                         */
                        if ((envelope.Interpolation () == LXiENVv_INTERP_LINEAR) ||
                            ((slopeModeIn == LXiSLOPE_LINEAR_IN) &&
                             (slopeModeOut == LXiSLOPE_LINEAR_OUT))) {
                                animationEnvelope.interpolations.push_back (
                                        Element::INTERPOLATION_LINEAR);
                                brokenFlags = 0;
                        }
                        else if ((envelope.Interpolation () == LXiENVv_INTERP_STEPPED) ||
                             ((slopeModeIn == LXiSLOPE_STEPPED) &&
                              (slopeModeOut == LXiSLOPE_STEPPED))) {
                                animationEnvelope.interpolations.push_back (
                                        Element::INTERPOLATION_STEP);
                                brokenFlags = 0;
                        }
                        else if (envelope.Interpolation () == LXiENVv_INTERP_CURVE) {
                                animationEnvelope.interpolations.push_back (
                                        Element::INTERPOLATION_BEZIER);
                        }
                        else {
                                // unknown interpolation type!
                                keyResult = LXe_NOTFOUND;
                                break;
                        }

                        if (envelope.Interpolation () == LXiENVv_INTERP_CURVE) {
                                double weightIn, weightOut;
                                if (isBrokenWeight) {
                                        atLeastOneBrokenWeight = true;

                                        key.GetWeight (&weightIn, LXiENVSIDE_IN);
                                        key.GetWeight (&weightOut, LXiENVSIDE_OUT);
                                }
                                else {
                                        key.GetWeight (&weightIn, LXiENVSIDE_IN);
                                        weightOut = weightIn;
                                }
                                modoEnvelope.inWeights.push_back (static_cast<float>(weightIn));
                                modoEnvelope.outWeights.push_back (static_cast<float>(weightOut));

                                double slopeIn, slopeOut;
                                if (isBrokenSlope) {
                                        atLeastOneBrokenSlope = true;

                                        key.GetSlope (&slopeIn, LXiENVSIDE_IN);
                                        key.GetSlope (&slopeOut, LXiENVSIDE_OUT);
                                }
                                else {
                                        key.GetSlope (&slopeOut, LXiENVSIDE_OUT);
                                        slopeIn = slopeOut;
                                }
                                modoEnvelope.inSlopes.push_back (static_cast<float>(slopeIn));
                                modoEnvelope.outSlopes.push_back (static_cast<float>(slopeOut));

                                /*
                                 * Calculate the COLLADA form of the Bezier tangents. We first
                                 * normalize the slope vector, multiply by the weight and
                                 * finally translate by (time, value).
                                 */
                                double inTCX = -1;
                                double inTCY = -slopeIn;
                                NormalizeVector2D (inTCX, inTCY);

                                double outTCX = 1;
                                double outTCY = slopeOut;
                                NormalizeVector2D (outTCX, outTCY);

                                inTCX *= weightIn;
                                inTCY *= weightIn * valueScale;
                                inTCX += time;
                                if (isBrokenValue) {
                                        inTCY += inValue;
                                }
                                else {
                                        inTCY += value;
                                }
                                animationEnvelope.inTanControlX.push_back (static_cast<float>(inTCX));
                                animationEnvelope.inTanControlY.push_back (static_cast<float>(inTCY));

                                outTCX *= weightOut;
                                outTCY *= weightOut * valueScale;
                                outTCX += time;
                                if (isBrokenValue) {
                                        outTCY += outValue;
                                }
                                else {
                                        outTCY += value;
                                }
                                animationEnvelope.outTanControlX.push_back (static_cast<float>(outTCX));
                                animationEnvelope.outTanControlY.push_back (static_cast<float>(outTCY));
                        }

                        keyResult = key.Next ();
                }

                /*
                 * If at least one keyframe was broken, make the temporary
                 * broken value, weight, or slope arrays permanent.
                 */
                if (atLeastOneBrokenValue) {
                        modoEnvelope.brokenValues = brokenValues;
                }

                if (atLeastOneBrokenWeight) {
                        modoEnvelope.brokenWeights = brokenWeights;
                }

                if (atLeastOneBrokenSlope) {
                        modoEnvelope.brokenSlopes = brokenSlopes;
                }
        }
        atLeastOneKey = (animationEnvelope.outputs.size () > 0);
        if (atLeastOneKey) {
                animationEnvelope.preInfinityBehavior =
                        PreInfinityBehavior (envelope);
                animationEnvelope.postInfinityBehavior =
                        PostInfinityBehavior (envelope);
        }

        return atLeastOneKey;
}

        void
COLLADASceneSaver::GetSampledKeyFrames (
        ParamType					 paramType,
        CLxUser_Envelope				&envelope,
        AnimationElement::Envelope			&animationEnvelope,
        double						 valueScale)
{
        double frameRate = GetFrameRate ();
        if (frameRate > 0.0) {
                int startFrame = prefs.SampleStartFrame ();
                int endFrame = prefs.SampleEndFrame ();
                for (int frameIndex = startFrame;
                        frameIndex <= endFrame; ++frameIndex) {
                        /*
                                * Sample on every frame over the range.
                                */
                        double frameTime = frameIndex / frameRate;
                        animationEnvelope.times.push_back (static_cast<float>(frameTime));

                        /*
                                * Write out an integer or float keyframe value.
                                */
                        double value;
                        if (paramType == PARAM_TYPE_INT) {
                                /*
                                        * Integer keyframe values are never scaled.
                                        */
                                value = envelope.IntValue (frameTime);
                        }
                        else {
                                value = envelope.Value (frameTime) * valueScale;
                        }
                        animationEnvelope.outputs.push_back (static_cast<float>(value));

                        /*
                                * We only write out linear keyframes when
                                * sampling, with no tangent points.
                                */
                        animationEnvelope.interpolations.push_back (
                                Element::INTERPOLATION_LINEAR);
                }
        }
}

/*
 * Add a camera library.
 *
 * For each camera, we add both the common technique, with the standard
 * elements, as well as a special modo profile technique, with additional
 * camera item settings, as shown on the Properties panel.
 */
        LxResult
COLLADASceneSaver::AddCameraLibrary (COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding camera library.");

        CameraLibraryElement cameraLibrary(collada);

        StartScan (LXsITYPE_CAMERA);
        while (NextItem ()) {
                if (ItemVisibleForSave ()) {
                        CameraElement camera(cameraLibrary, ItemIdentity (), ItemName ());

                        if (ReallySaving ()) {
                                /*
                                 * Add the camera optics.
                                 */
                                result = AddCameraOptics (camera);

                                /*
                                 * Add the camera imager.
                                 */
                                result = AddCameraImager (camera);
                        }
                }
        }

        return LOG_ERR (result);
}

/*
 * Add the camera optics.
 */
        LxResult
COLLADASceneSaver::AddCameraOptics (CameraElement &camera)
{
        LxResult		 result(LXe_OK);

        OpticsElement		optics(camera);

        AddCameraOpticsTechniqueCommon (optics);

        if (prefs.SaveModoProfile ()) {
                AddCameraOpticsTechniqueProfile_modo401 (optics);
        }

        return LOG_ERR (result);
}

/*
 * Add the common technique camera optics.
 */
        LxResult
COLLADASceneSaver::AddCameraOpticsTechniqueCommon (OpticsElement &optics)
{
        LxResult		 result(LXe_OK);

        double focalLength = ChanFloat (LXsICHAN_CAMERA_FOCALLEN);
        const double MIN_FOCAL_LENGTH = 0.00001;
        if (focalLength < MIN_FOCAL_LENGTH) {
                focalLength = MIN_FOCAL_LENGTH;
        }
        double xSize = ChanFloat (LXsICHAN_CAMERA_APERTUREX);
        double ySize = ChanFloat (LXsICHAN_CAMERA_APERTUREY);

        /*
         * Look up znear and zfar from the Scene I/O prefs.
         */
        double zNear = prefs.GetZNear ();
        double zFar = prefs.GetZFar ();

        /*
         * Check the camera projection type.
         */
        string cameraProjectionType = GetTextHintEncodedChannelValue (
                *this, LXsICHAN_CAMERA_PROJTYPE);

        if (cameraProjectionType == string(LXsICVAL_CAMERA_PROJTYPE_ORTHO)) {
                OrthographicElement orthographic(optics);
                orthographic.SetMags (1.0, 1.0);

                orthographic.SetZNearFar (zNear, zFar);
        }
        else {
                /*
                 * Lump spherical together with perspective.
                 */
                PerspectiveElement perspective(optics);

                /*
                 * Calculate the horizontal and vertical field of view
                 * in degrees.
                 */
                double xfov = 2 * atan (xSize / (2.0f * focalLength)) * RAD2DEG;
                double yfov = 2 * atan (ySize / (2.0f * focalLength)) * RAD2DEG;
                perspective.SetFOVs (xfov, yfov);
        
                perspective.SetZNearFar (zNear, zFar);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddCameraOpticsTechniqueProfile_modo401 (
        OpticsElement &optics)
{
        LxResult		 result(LXe_OK);

        OpticsElement_modo401 optics_modo401(optics);

        /*
         * Targeting.
         */
        string targetID;
        if (GetTargetNodeID (targetID)) {
                optics_modo401.SetTargetNodeID (targetID);

                optics_modo401.SetTargetEnable (ChanBool (LXsICHAN_TARGET_ENABLE));
                optics_modo401.SetTargetSetFocus (ChanBool (LXsICHAN_TARGET_TARGETFOCUS));
                optics_modo401.SetTargetDistance (ChanFloat (LXsICHAN_CAMERA_TARGET));

                /*
                 * Convert internal roll angle from radians to degrees.
                 */
                optics_modo401.SetTargetRoll (
                        ChanFloat (LXsICHAN_TARGET_TARGETROLL) * RAD2DEG);
        }

        /*
         * Projection type.
         */
        string cameraProjectionType = GetTextHintEncodedChannelValue (
                *this, LXsICHAN_CAMERA_PROJTYPE);
        optics_modo401.SetProjection (cameraProjectionType);

        /*
         * Focal length.
         */
        double focalLength = ChanFloat (LXsICHAN_CAMERA_FOCALLEN);
        const double MIN_FOCAL_LENGTH = 0.00001;
        if (focalLength < MIN_FOCAL_LENGTH) {
                focalLength = MIN_FOCAL_LENGTH;
        }
        optics_modo401.SetFocalLength (focalLength);

        optics_modo401.SetLensDistortion (ChanFloat (LXsICHAN_CAMERA_DISTORT));
        optics_modo401.SetLensSqueeze (ChanFloat (LXsICHAN_CAMERA_SQUEEZE));

        /*
         * Depth of Field.
         */
        optics_modo401.SetFocusDistance (ChanFloat (LXsICHAN_CAMERA_FOCUSDIST));
        optics_modo401.SetFStop (ChanFloat (LXsICHAN_CAMERA_FSTOP));

        /*
         * Motion Blur.
         */
        optics_modo401.SetMotionBlurLength (ChanFloat (LXsICHAN_CAMERA_BLURLEN));
        optics_modo401.SetMotionBlurOffset (ChanFloat (LXsICHAN_CAMERA_BLUROFF));

        /*
         * Stereoscopic.
         */
        optics_modo401.SetInterocularDistance (ChanFloat (LXsICHAN_CAMERA_IODIST));
        optics_modo401.SetConvergenceDistance (ChanFloat (LXsICHAN_CAMERA_CONVDIST));

        return LOG_ERR (result);
}

/*
 * Add the camera imager.
 */
        LxResult
COLLADASceneSaver::AddCameraImager (CameraElement &camera)
{
        LxResult		 result(LXe_OK);

        if (prefs.SaveModoProfile ()) {
                ImagerElement imager(camera);
                ImagerElement_modo401 techniqueProfile_modo401(imager);

                /*
                 * Film Back.
                 */
                techniqueProfile_modo401.SetAperture (
                        ChanFloat (LXsICHAN_CAMERA_APERTUREX),
                        ChanFloat (LXsICHAN_CAMERA_APERTUREY));

                techniqueProfile_modo401.SetOffset (
                        ChanFloat (LXsICHAN_CAMERA_OFFSETX),
                        ChanFloat (LXsICHAN_CAMERA_OFFSETY));

                /*
                 * Film Fit Type.
                 */
                string filmFitType = GetTextHintEncodedChannelValue (
                        *this, LXsICHAN_CAMERA_FILMFIT);
                techniqueProfile_modo401.SetFilmFit (filmFitType);
        }

        return LOG_ERR (result);
}

/*
 * Add a light library.
 *
 * For each camera, we add both the common technique, with the standard
 * elements, as well as a special modo profile technique, with additional
 * camera item settings, as shown on the Properties panel.
 */
        LxResult
COLLADASceneSaver::AddLightLibrary (COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding light library.");

        LightLibraryElement lightLibrary(collada);

        /*
         * We perform two scans, one for the "POLYRENDER" item (seen as the
         * topmost "Render" item in the Shader Tree), and the second one for
         * LIGHT items, including the various light subtypes (spot, sun, etc.)
         */

        /*
         * Fetch the ambient light.
         */
        StartScan (LXsITYPE_POLYRENDER);
        while (NextItem ()) {
                if (ReallySaving ()) {
                        AmbientLightElement ambientLight(
                                lightLibrary, ItemIdentity (), ItemName ());

                        double ambientIntensity = ChanFloat (LXsICHAN_RENDER_AMBRAD);

                        LXtVector ambientColor;
                        ChanColor (LXsICHAN_RENDER_AMBCOLOR, ambientColor);

                        /*
                         * Scale the ambient color by the ambientIntensity.
                         * (Expressed in modo as W/srm2)
                         */
                        ambientColor[0] *= ambientIntensity;
                        ambientColor[1] *= ambientIntensity;
                        ambientColor[2] *= ambientIntensity;

                        ambientLight.SetColor (ambientColor);
                }
                break;
        }

        /*
         * Iterate over all light sub types.
         */
        itemTypeChannelVisitor.SetVisitExtent (
                VISIT_EXTENT_ALL_CHANNELS);
        itemTypeChannelVisitor.SetVisitTask (VISIT_TASK_BUILD_LIGHT_LIBRARY);
        itemTypeChannelVisitor.SetLightLibrary (&lightLibrary);
        itemTypeChannels.VisitItemTypeChannels (
                string(LXsITYPE_LIGHT), &itemTypeChannelVisitor);

        return LOG_ERR (result);
}

/*
 * Targets.
 */
        bool
COLLADASceneSaver::GetTargetNodeID (string &nodeID)
{
        bool foundTarget(false);

        CLxUser_Item		 targetingItem;
        if (GetItem (targetingItem)) {
                CLxUser_Scene		 scene(SceneObject ());
                CLxUser_SceneGraph	 sceneGraph;
                scene.GetGraph (LXsGRAPH_TARGETS, sceneGraph);
                CLxUser_ItemGraph	 targetGraph;
                targetGraph.set (sceneGraph);
                if (targetGraph.Forward (targetingItem) > 0) {
                        CLxUser_Item targetItem;
                        if (targetGraph.Forward (
                            targetingItem, 0, targetItem)) {
                                SetItem (targetItem);
                                nodeID = GetItemNodeID ();
                                foundTarget = !nodeID.empty ();
                                SetItem (targetingItem);
                        }
                }
        }

        return foundTarget;
}

        static void
SetGrayColorRGBA (
        Element::ColorRGBA	&color,
        double			gray,
        double			alpha = 1.0)
{
        color[0] = gray;
        color[1] = gray;
        color[2] = gray;

        color[3] = alpha;
}

        static void
ScaleColorRGBA (Element::ColorRGBA &color, double scale)
{
        color[0] *= scale;
        color[1] *= scale;
        color[2] *= scale;

        /*
         * Alpha is left untouched.
         */
}

        string
COLLADASceneSaver::NativePathToURI (const string &nativePath)
{
        /*
         * We always get an absolute image file path from
         * modo, so we need to check our AbsPath pref and
         * convert to relative as needed.
         */
        string fileNamePath(nativePath);
        bool	haveRelativePath(false);
        if (!prefs.UseAbsolutePath ()) {
                haveRelativePath = MakeFileRelative (
                        fileNamePath);
        }

        string textureURI;
        if (!haveRelativePath) {
                textureURI = FilePathToAbsoluteURI (fileNamePath);
        }
        else {
                textureURI = FilePathToRelativeURI (fileNamePath);
        }

        return textureURI;
}

/*
 * Build a list of image paths for every loaded image.
 */
        LxResult
COLLADASceneSaver::BuildImageFilePathList ()
{
        LxResult	 result(LXe_OK);

        StartScan (LXsITYPE_IMAGEMAP);
        while (NextItem ()) {
                if (ReallySaving ()) {
                        CLxUser_Item	imageMap;
                        GetItem (imageMap);
                        const char* fileName;
                        if (imageMap.test () &&
                            SetItem (imageMap) &&
                            TxtrImage() &&
                            (fileName = ChanString (LXsICHAN_VIDEOSTILL_FILENAME))) {
                                imageMapFiles.insert (NativePathToURI (fileName));
                                haveAtLeastOneImage = true;
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddEffectLibrary (
        COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding effect library.");

        EffectLibraryElement effectLibrary(collada);

        for (MaterialSet::iterator iter = materialTagSet.begin ();
             iter != materialTagSet.end(); ++iter) {
                materialTag = *iter;

                /*
                 * Build up a composite material for the common
                 * technique material.
                 */
                if (ScanMask (materialTag.c_str())) {

                        /*
                         * Add a composite material and add it as the common
                         * technique effect.
                         */
                        EffectElement effect(effectLibrary, materialTag);

                        AddEffect (effect);
                }
        }

        return LOG_ERR (result);
}

static const double DEFAULT_DIFFUSE_AMOUNT	= 0.8;
static const double DEFAULT_SPECULAR_AMOUNT	= 0.2;
static const double DEFAULT_SHININESS_AMOUNT	= 0.4;

/*
 * Common technique material, built up by compositing
 * all of the member layers as a series of masks.
 */
struct CommonMaterial
{

        double			diffuseAmount;
        Element::ColorRGBA	diffuseColor;
        string			diffuseTexture;
        string			diffuseTexcoordSet;

        double			specularAmount;
        Element::ColorRGBA	specularColor;
        string			specularTexture;
        string			specularTexcoordSet;

        double			shininess;

        double			reflectiveAmount;
        Element::ColorRGBA	reflectiveColor;
        string			reflectiveTexture;
        string			reflectiveTexcoordSet;

        double			transparentAmount;
        Element::ColorRGBA	transparentColor;
        string			transparentTexture;
        string			transparentTexcoordSet;

        double			luminousAmount;
        Element::ColorRGBA	luminousColor;
        string			luminousTexture;
        string			luminousTexcoordSet;

        CommonMaterial ()
                :
                diffuseAmount(DEFAULT_DIFFUSE_AMOUNT),
                specularAmount(DEFAULT_SPECULAR_AMOUNT),
                shininess(DEFAULT_SHININESS_AMOUNT),
                reflectiveAmount(0.0),
                transparentAmount(0.0),
                luminousAmount(0.0)
        {
                SetGrayColorRGBA (diffuseColor, 1);
                SetGrayColorRGBA (specularColor, 1);
                SetGrayColorRGBA (reflectiveColor, 1);
                SetGrayColorRGBA (transparentColor, 1);
                SetGrayColorRGBA (luminousColor, 1);
        }
};

        LxResult
COLLADASceneSaver::AddEffect (EffectElement &effect)
{
        LxResult		 result(LXe_OK);
        CommonMaterial		 commonMaterial;

        result = BuildCommonMaterial (commonMaterial);

        /*
         * First add the surfaces and samplers that will be cross referenced
         * by the phong values below.
         */
        if (!commonMaterial.luminousTexture.empty ()) {
                effect.AddSurfaceSampler (commonMaterial.luminousTexture);
        }

        if (!commonMaterial.diffuseTexture.empty ()) {
                effect.AddSurfaceSampler (commonMaterial.diffuseTexture);
        }

        if (!commonMaterial.specularTexture.empty ()) {
                effect.AddSurfaceSampler (commonMaterial.specularTexture);
        }

        if (!commonMaterial.reflectiveTexture.empty ()) {
                effect.AddSurfaceSampler (commonMaterial.reflectiveTexture);
        }

        if (!commonMaterial.transparentTexture.empty ()) {
                effect.AddSurfaceSampler (commonMaterial.transparentTexture);
        }

        LXxUNUSED (result);

        /*
         * Our saver always outputs a phong shader.
         */
        PhongElement		phong(effect);

        return AddPhong (phong, commonMaterial);
}

        LxResult
COLLADASceneSaver::BuildCommonMaterial (
        struct CommonMaterial	&commonMaterial)
{
        LxResult		 result(LXe_OK);

        /*
         * Iterate over materials from the bottom up, such
         * that higher-level materials mask the values of
         * like channels below.
         */
        while (NextLayer()) {
                string itemName(ItemName ());
                string itemType(ItemType ());

                /*
                 * Disabled layers are ignored for the composite, since
                 * they are written out as part of the modo 401 profile
                 * technique later on (if that profile is enabled).
                 */
                if (!ChanInt(LXsICHAN_TEXTURELAYER_ENABLE)) {
                        continue;
                }

                if (ItemIsA (LXsITYPE_IMAGEMAP)) {
                        /*
                         * Determine the type of image map.
                         * (diffuse, specular, reflection, etc.)
                         */
                        const char *fx = LayerEffect ();
                        CLxUser_Item	imageMap;
                        GetItem (imageMap);
                        const char* fileName;
                        if (imageMap.test () &&
                            SetItem (imageMap) &&
                            TxtrImage() &&
                            (fileName = ChanString (LXsICHAN_VIDEOSTILL_FILENAME))) {
                                string textureURI = NativePathToURI (fileName);
                                unsigned imageIndex = 1;
                                for (ImageMapFileSet::const_iterator iter =
                                        imageMapFiles.begin ();
                                        iter != imageMapFiles.end (); ++iter) {
                                        if (*iter != textureURI) {
                                                ++imageIndex;
                                        }
                                        else {
                                                break;
                                        }
                                }

                                /*
                                 * Form the image name cross reference.
                                 * [TODO] Make a standard API in "colladastrings".
                                 */
                                string imageName =
                                        string(ATTRVALUE_IMAGEPREFIX) +
                                        string(IntegerToString (
                                                static_cast<unsigned>(
                                                        imageIndex), 3));

                                /*
                                 * Check if we have a color texture.
                                 * (diffuse, specular, reflection, etc.)
                                 */
                                string mapName;
                                if (string(fx) == string(LXs_FX_DIFFCOLOR)) {
                                        commonMaterial.diffuseTexture = imageName;
                                        mapName = UVMapName (imageMap);
                                        commonMaterial.diffuseTexcoordSet = mapName;
                                }
                                else if (string(fx) == string(LXs_FX_SPECCOLOR)) {
                                        commonMaterial.specularTexture = imageName;
                                        mapName = UVMapName (imageMap);
                                        commonMaterial.specularTexcoordSet = mapName;
                                }
                                else if (string(fx) == string(LXs_FX_REFLCOLOR)) {
                                        commonMaterial.reflectiveTexture = imageName;
                                        mapName = UVMapName (imageMap);
                                        commonMaterial.reflectiveTexcoordSet = mapName;
                                }
                                else if (string(fx) == string(LXs_FX_TRANCOLOR)) {
                                        commonMaterial.transparentTexture = imageName;
                                        mapName = UVMapName (imageMap);
                                        commonMaterial.transparentTexcoordSet = mapName;
                                }
                                else if (string(fx) == string(LXs_FX_LUMICOLOR)) {
                                        commonMaterial.luminousTexture = imageName;
                                        mapName = UVMapName (imageMap);
                                        commonMaterial.luminousTexcoordSet = mapName;
                                }
                                if (!mapName.empty ()) {
                                        polyTagTexCoords.insert (make_pair (
                                                        materialTag, mapName));
                                }
                        }

                        /*
                         * Restore the image map for iteration.
                         */
                        SetItem (imageMap);
                }
                else if (ItemIsA(LXsITYPE_ADVANCEDMATERIAL)) {
                        /*
                         * Overwrite all supported advanced channels.
                         */
                        commonMaterial.diffuseAmount =
                                ChanFloat (LXsICHAN_ADVANCEDMATERIAL_DIFFAMT);
                        ChanColor (LXsICHAN_ADVANCEDMATERIAL_DIFFCOL,
                                commonMaterial.diffuseColor);

                        commonMaterial.specularAmount =
                                ChanFloat (LXsICHAN_ADVANCEDMATERIAL_SPECAMT);
                        ChanColor (LXsICHAN_ADVANCEDMATERIAL_SPECCOL,
                                commonMaterial.specularColor);

                        commonMaterial.shininess = SpecExponent ();

                        commonMaterial.reflectiveAmount =
                                ChanFloat (LXsICHAN_ADVANCEDMATERIAL_REFLAMT);
                        ChanColor (LXsICHAN_ADVANCEDMATERIAL_REFLCOL,
                                commonMaterial.reflectiveColor);

                        commonMaterial.transparentAmount =
                                ChanFloat (LXsICHAN_ADVANCEDMATERIAL_TRANAMT);
                        ChanColor (LXsICHAN_ADVANCEDMATERIAL_TRANCOL,
                                commonMaterial.transparentColor);

                        commonMaterial.luminousAmount =
                                ChanFloat (LXsICHAN_ADVANCEDMATERIAL_RADIANCE);
                        ChanColor (LXsICHAN_ADVANCEDMATERIAL_LUMICOL,
                                commonMaterial.luminousColor);
                }
                else if (ItemIsA(LXsITYPE_CONSTANT)) {
#if defined(COLLADASAVER_VERBOSE_LOGGING)
                        /*
                         * Test code to iterate over the channels of a
                         * Constant Effect item.
                         */
                        CLxUser_Item constantItem;
                        GetItem (constantItem);
                        unsigned chanCount;
                        LxResult chanResult =
                                constantItem.ChannelCount (&chanCount);
                        for (unsigned chanIndex = 0;
                             chanIndex < chanCount; ++chanIndex) {
                                const char *chanName;
                                chanResult = constantItem.ChannelName (
                                        chanIndex, &chanName);
                                unsigned chanType;
                                chanResult = constantItem.ChannelType (
                                        chanIndex, &chanType);
                                const char *storageType;
                                chanResult = constantItem.ChannelStorageType (
                                        chanIndex, &storageType);
                        }
#endif
                        /*
                         * Overwrite a targeted channel by
                         * a constant value or color.
                         */
                        const char *chanValue = LayerEffect ();
                        if (string(chanValue) == string(LXs_FX_DIFFAMOUNT)) {
                                commonMaterial.diffuseAmount =
                                        ChanFloat (LXsICHAN_CONSTANT_VALUE);
                        }
                        else if (string(chanValue) == string(LXs_FX_DIFFCOLOR)) {
                                ChanColor (LXsICHAN_CONSTANT_COLOR,
                                        commonMaterial.diffuseColor);
                        }
                        else if (string(chanValue) == string(LXs_FX_SPECAMOUNT)) {
                                commonMaterial.specularAmount =
                                        ChanFloat (LXsICHAN_CONSTANT_VALUE);
                        }
                        else if (string(chanValue) == string(LXs_FX_SPECCOLOR)) {
                                ChanColor (LXsICHAN_CONSTANT_COLOR,
                                        commonMaterial.specularColor);
                        }
                        else if (string(chanValue) == string(LXs_FX_REFLAMOUNT)) {
                                commonMaterial.reflectiveAmount =
                                        ChanFloat (LXsICHAN_CONSTANT_VALUE);
                        }
                        else if (string(chanValue) == string(LXs_FX_REFLCOLOR)) {
                                ChanColor (LXsICHAN_CONSTANT_COLOR,
                                        commonMaterial.reflectiveColor);
                        }
                        else if (string(chanValue) == string(LXs_FX_TRANAMOUNT)) {
                                commonMaterial.transparentAmount =
                                        ChanFloat (LXsICHAN_CONSTANT_VALUE);
                        }
                        else if (string(chanValue) == string(LXs_FX_TRANCOLOR)) {
                                ChanColor (LXsICHAN_CONSTANT_COLOR,
                                        commonMaterial.transparentColor);
                        }
                        else if (string(chanValue) == string(LXs_FX_LUMIAMOUNT)) {
                                commonMaterial.luminousAmount =
                                        ChanFloat (LXsICHAN_CONSTANT_VALUE);
                        }
                        else if (string(chanValue) == string(LXs_FX_LUMICOLOR)) {
                                ChanColor (LXsICHAN_CONSTANT_COLOR,
                                        commonMaterial.luminousColor);
                        }
                }
        }

        return LOG_ERR (result);
}

/*
 * Lookup the name of the UV map for the texture locator
 * associated with the given image map.
 */
        string
COLLADASceneSaver::UVMapName (
        CLxUser_Item	&imageMap)
{
        string texcoordSet = string(ATTRVALUE_TEXCOORDSET0);
        SetItem (imageMap);
        if (TxtrLocator ()) {
                const char* uvMap = ChanString (
                        LXsICHAN_TEXTURELOC_UVMAP);
                if (uvMap) {
                        texcoordSet = string(uvMap);
                }
        }

        return texcoordSet;
}

        LxResult
COLLADASceneSaver::AddPhong (
        PhongElement		&phong,
        struct CommonMaterial	&commonMaterial)
{
        LxResult	result(LXe_OK);

        /*
         * Per the "phong" element spec, its elements must appear in a fixed order:
         *
         * emission, ambient, diffuse, specular, shininess, reflective, reflectivity,
         * transparent, transparency, and index_of_refraction.
         *
         * Also, for values where either a color or a texture is possible,
         * they are mutually exclusive - only one or the other is written
         * in the common technique.
         *
         * [TODO] Use the modo 401 profile to output combinations.
         */
        if (commonMaterial.luminousAmount > 0) {
                if (commonMaterial.diffuseTexture.empty ()) {
                        ScaleColorRGBA (
                                commonMaterial.luminousColor,
                                commonMaterial.luminousAmount);
                        phong.SetEmissionColor (commonMaterial.luminousColor);
                }
                else {
                        phong.SetEmissionColorMap (
                                commonMaterial.luminousTexture,
                                commonMaterial.luminousTexcoordSet);
                }
        }

        if (commonMaterial.diffuseAmount > 0) {
                if (commonMaterial.diffuseTexture.empty ()) {
                        ScaleColorRGBA (
                                commonMaterial.diffuseColor,
                                commonMaterial.diffuseAmount);
                        phong.SetDiffuseColor (commonMaterial.diffuseColor);
                }
                else {
                        phong.SetDiffuseColorMap (
                                commonMaterial.diffuseTexture,
                                commonMaterial.diffuseTexcoordSet);
                }
        }

        if (commonMaterial.specularAmount > 0) {
                if (commonMaterial.specularTexture.empty ()) {
                        ScaleColorRGBA (
                                commonMaterial.specularColor,
                                commonMaterial.specularAmount);
                        phong.SetSpecularColor (commonMaterial.specularColor);
                }
                else {
                        phong.SetSpecularColorMap (
                                commonMaterial.specularTexture,
                                commonMaterial.specularTexcoordSet);
                }
        }

        phong.SetShininess (commonMaterial.shininess);

        /*
         * Reflective color is not scale by the reflective amount on output,
         * since it's written out as a separate common material property.
         */
        if (commonMaterial.reflectiveAmount > 0) {
                if (commonMaterial.reflectiveTexture.empty ()) {
                        phong.SetReflectiveColor (commonMaterial.reflectiveColor);
                        phong.SetReflectivity (commonMaterial.reflectiveAmount);
                }
                else {
                        phong.SetReflectiveColorMap (
                                commonMaterial.reflectiveTexture,
                                commonMaterial.reflectiveTexcoordSet);
                }
        }

        if (commonMaterial.transparentAmount > 0) {
                if (commonMaterial.transparentTexture.empty ()) {
                        /*
                         * Transparent color is not scaled by the transparent amount on output,
                         * since it's written out as a separate common material property.
                         */
                        Element::ColorRGBA color;
                        Vector4Copy (color, commonMaterial.transparentColor);
                        color[3] = 1.0;
                        phong.SetTransparentColor (color, FX_OPAQUE_RGB_ZERO);

                        double luminance =
                                (color[0] * 0.212671) +
                                (color[1] * 0.715160) +
                                (color[2] * 0.072169);
                        double transparency;
                        if (luminance) {
                                double transparencyScale = 1.0 / luminance;

                                /*
                                 * Reverse the sense of transparency to translate
                                 * from modo's internal channel value.
                                 */
                                transparency = math::Min (1.0, commonMaterial.transparentAmount);

                                transparency = math::Min (1.0, (1.0 - transparency) * transparencyScale);
                        }
                        else {
                                transparency = 1.0;
                        }

                        phong.SetTransparency (transparency);

                }
                else {
                        phong.SetTransparentColorMap (
                                commonMaterial.transparentTexture,
                                commonMaterial.transparentTexcoordSet);
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddShaderNodeLibrary (
        COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding shader node library.");

        ShaderNodeLibraryElement_modo401 shaderNodeLibrary(collada);

        /*
         * Append the native modo profile technique data in its original tree
         * order, such that the same shader tree can be reconstructed in modo
         * when importing later on.
         */
        itemTypeChannelVisitor.SetVisitExtent (
                VISIT_EXTENT_ALL_ITEMS);
        itemTypeChannelVisitor.SetVisitTask (VISIT_TASK_BUILD_SHADER_NODE_LIBRARY);
        itemTypeChannelVisitor.SetShaderNodeLibrary (&shaderNodeLibrary);

        RenderElement_modo401	render (shaderNodeLibrary);
        itemTypeChannelVisitor.SetRender (&render);

        itemTypeChannels.VisitItemTypeChannels (
                string(LXsITYPE_POLYRENDER), &itemTypeChannelVisitor);

        // [TODO] Insert all of the shader tree sub-items here.
        // LXsITYPE_ADVANCEDMATERIAL AddAdvancedMaterial
        // LXsITYPE_CONSTANT AddConstantEffect

        EnvironmentElement_modo401	environment(shaderNodeLibrary);
        itemTypeChannelVisitor.SetEnvironment (&environment);

        itemTypeChannels.VisitItemTypeChannels (
                string(LXsITYPE_ENVIRONMENT), &itemTypeChannelVisitor);

        itemTypeChannels.VisitItemTypeChannels (
                string(LXsITYPE_ENVMATERIAL), &itemTypeChannelVisitor);

        /*
         * [TODO] Iterate over the lights and add any light material
         *        or poly shader subtrees.
         */

        return LOG_ERR (result);
}

#if 0
        LxResult
COLLADASceneSaver::AddAdvancedMaterial (EffectElement &effect)
{
        LxResult		 result(LXe_OK);

        /*
         * A modo 401 profile advanced material technique.
         */
        struct AdvancedMaterial
        {
                bool		enabled;

                /*
                 * BRDF channels.
                 */
                double			diffuseAmount;
                Element::ColorRGB	diffuseColor;
                bool			conserveEnergy;

                double			specularAmount;
                Element::ColorRGB	specularColor;

                double			specularFresnel;
                double			roughness;
                double			anisotropy;
                string			uvMap;

                double			reflectionAmount;
                double			reflectionFresnel;
                Element::ColorRGB	reflectionColor;
                EffectReflectionType	reflectionType;

                bool			blurryReflection;
                unsigned		reflectionRays;
                double			clearcoatAmount;

                /*
                 * Surface Normal channels.
                 */
                double			bumpStrength;
                double			displacementDistance;
                double			smoothing;
                double			smoothingAngle;
                bool			doubleSided;

                /*
                 * Transparency channels.
                 */
                double			transparentAmount;
                Element::ColorRGB	transparentColor;
                double			absorptionDistance;
                double			refractiveIndex;
                double			dispersion;
                double			refractionRoughness;
                unsigned		refractionRays;
                double			dissolveAmount;

                /*
                 * Subsurface Scattering channels.
                 */
                double			subsurfaceAmount;
                Element::ColorRGB	subsurfaceColor;
                double			scatteringDistance;
                double			frontWeighting;
                double			subsurfaceSamples;

                /*
                 * Luminosity channels.
                 */
                double			luminousIntensity;
                Element::ColorRGB	luminousColor;

                /*
                 * Ray Tracing channels.
                 */
                Element::ColorRGB	exitColor;
        };

        AdvancedShaderNodeElement_modo401	material(effect, ItemName ());

        Element::ColorRGB	color;

        material.SetIsEnabled (ChanBool(LXsICHAN_TEXTURELAYER_ENABLE));

        material.SetDiffuseAmount (ChanFloat (LXsICHAN_ADVANCEDMATERIAL_DIFFAMT));
        ChanColor (LXsICHAN_ADVANCEDMATERIAL_DIFFCOL, color);
        material.SetDiffuseColor (color);

        material.SetSpecularAmount (ChanFloat (LXsICHAN_ADVANCEDMATERIAL_SPECAMT));
        ChanColor (LXsICHAN_ADVANCEDMATERIAL_SPECCOL, color);
        material.SetSpecularColor (color);

        material.SetRoughness (ChanFloat (LXsICHAN_ADVANCEDMATERIAL_ROUGH));

        material.SetReflectionAmount (ChanFloat (LXsICHAN_ADVANCEDMATERIAL_REFLAMT));
        ChanColor (LXsICHAN_ADVANCEDMATERIAL_REFLCOL, color);

        /*
         * Transparency channels.
         */
        material.SetTransparentAmount (ChanFloat (LXsICHAN_ADVANCEDMATERIAL_TRANAMT));
        ChanColor (LXsICHAN_ADVANCEDMATERIAL_TRANCOL, color);
        material.SetTransparentColor (color);

        /*
         * Subsurface Scattering channels.
         */

        /*
         * Luminosity channels.
         */
        material.SetLuminousIntensity (ChanFloat (LXsICHAN_ADVANCEDMATERIAL_RADIANCE));
        ChanColor (LXsICHAN_ADVANCEDMATERIAL_LUMICOL, color);
        material.SetLuminousColor (color);

        ChanColor (LXsICHAN_ADVANCEDMATERIAL_EXITCOL, color);
        material.SetExitColor (color);

        return LOG_ERR (result);
}
#endif

        bool
GetMaterialTextureEffect (
        const string			&layerEffect,
        MaterialTextureEffect		&type,
        EffectConstantStorageType	&storage)
{
        bool	recognized(false);

        if ((layerEffect == string(LXs_FX_DRIVERA)) ||
            (layerEffect == string(LXs_FX_DRIVERB)) ||
            (layerEffect == string(LXs_FX_DRIVERC)) ||
            (layerEffect == string(LXs_FX_DRIVERD)) ||
            (layerEffect == string(LXs_FX_ANISODIR)) ||
            (layerEffect == string(LXs_FX_BUMP)) ||
            (layerEffect == string(LXs_FX_COATAMOUNT)) ||
            (layerEffect == string(LXs_FX_DIFFAMOUNT)) ||
            (layerEffect == string(LXs_FX_DISPLACE)) ||
            (layerEffect == string(LXs_FX_FUR_BEND)) ||
            (layerEffect == string(LXs_FX_FUR_BUMP)) ||
            (layerEffect == string(LXs_FX_FUR_CLDENS)) ||
            (layerEffect == string(LXs_FX_FUR_CLUMPS)) ||
            (layerEffect == string(LXs_FX_FUR_CURLS)) ||
            (layerEffect == string(LXs_FX_FUR_DENSITY)) ||
            (layerEffect == string(LXs_FX_FUR_DIRECTION)) ||
            (layerEffect == string(LXs_FX_FUR_FLEX)) ||
            (layerEffect == string(LXs_FX_FUR_GROWJIT)) ||
            (layerEffect == string(LXs_FX_FUR_LENGTH)) ||
            (layerEffect == string(LXs_FX_FUR_VECTOR)) ||
            (layerEffect == string(LXs_FX_LUMIAMOUNT)) ||
            (layerEffect == string(LXs_FX_NORMAL)) ||
            (layerEffect == string(LXs_FX_REFLAMOUNT)) ||
            (layerEffect == string(LXs_FX_REFLFRESNEL)) ||
            (layerEffect == string(LXs_FX_SPECAMOUNT)) ||
            (layerEffect == string(LXs_FX_SPECFRESNEL)) ||
            (layerEffect == string(LXs_FX_STENCIL)) ||
            (layerEffect == string(LXs_FX_SUBSAMOUNT)) ||
            (layerEffect == string(LXs_FX_SP_DENSITY)) ||
            (layerEffect == string(LXs_FX_SP_NORMAL)) ||
            (layerEffect == string(LXs_FX_SP_SIZE)) ||
            (layerEffect == string(LXs_FX_TRANAMOUNT))) {

                storage = EFFECT_CONSTANT_STORAGE_PERCENT;
                recognized = true;

                if (string(layerEffect) == string(LXs_FX_DRIVERA)) {
                        type = MATERIAL_TEXTURE_EFFECT_DRIVER_A_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_DRIVERB)) {
                        type = MATERIAL_TEXTURE_EFFECT_DRIVER_B_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_DRIVERC)) {
                        type = MATERIAL_TEXTURE_EFFECT_DRIVER_C_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_DRIVERD)) {
                        type = MATERIAL_TEXTURE_EFFECT_DRIVER_D_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_ANISODIR)) {
                        type = MATERIAL_TEXTURE_EFFECT_ANISOTROPIC_DIRECTION_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_BUMP)) {
                        type = MATERIAL_TEXTURE_EFFECT_BUMP_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_COATAMOUNT)) {
                        type = MATERIAL_TEXTURE_EFFECT_CLEARCOAT_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_DIFFAMOUNT)) {
                        type = MATERIAL_TEXTURE_EFFECT_DISPLACEMENT_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_DISPLACE)) {
                        type = MATERIAL_TEXTURE_EFFECT_DIFFUSE_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_BEND)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_BEND_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_BUMP)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_BUMP_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_CLDENS)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_CLUMP_DENSITY_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_CLUMPS)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_CLUMPS_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_CURLS)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_CURLS_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_DENSITY)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_DENSITY_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_DIRECTION)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_DIRECTION_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_FLEX)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_FLEX_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_GROWJIT)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_GROWTH_JITTER_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_LENGTH)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_LENGTH_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_FUR_VECTOR)) {
                        type = MATERIAL_TEXTURE_EFFECT_FUR_VECTOR_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_LUMIAMOUNT)) {
                        type = MATERIAL_TEXTURE_EFFECT_LUMINOUS_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_NORMAL)) {
                        type = MATERIAL_TEXTURE_EFFECT_NORMAL_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_REFLAMOUNT)) {
                        type = MATERIAL_TEXTURE_EFFECT_REFLECTION_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_REFLFRESNEL)) {
                        type = MATERIAL_TEXTURE_EFFECT_REFLECTION_FRESNEL_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_ROUGH)) {
                        type = MATERIAL_TEXTURE_EFFECT_ROUGHNESS_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_SPECAMOUNT)) {
                        type = MATERIAL_TEXTURE_EFFECT_SPECULAR_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_SPECFRESNEL)) {
                        type = MATERIAL_TEXTURE_EFFECT_SPECULAR_FRESNEL_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_STENCIL)) {
                        type = MATERIAL_TEXTURE_EFFECT_STENCIL_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_SUBSAMOUNT)) {
                        type = MATERIAL_TEXTURE_EFFECT_SUBSURFACE_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_SP_DENSITY)) {
                        type = MATERIAL_TEXTURE_EFFECT_SURFACE_PARTICLE_DENSITY_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_SP_NORMAL)) {
                        type = MATERIAL_TEXTURE_EFFECT_SURFACE_PARTICLE_NORMAL_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_SP_SIZE)) {
                        type = MATERIAL_TEXTURE_EFFECT_SURFACE_PARTICLE_SIZE_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_TRANAMOUNT)) {
                        type = MATERIAL_TEXTURE_EFFECT_TRANSPARENT_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_TRANROUGH)) {
                        type = MATERIAL_TEXTURE_EFFECT_REFRACTION_ROUGHNESS_AMOUNT;
                }
                else if (string(layerEffect) == string(LXs_FX_VECDISP)) {
                        type = MATERIAL_TEXTURE_EFFECT_VECTOR_DISPLACEMENT_AMOUNT;
                }
        }
        else if ((layerEffect == string(LXs_FX_DIFFCOLOR)) ||
                 (layerEffect == string(LXs_FX_SPECCOLOR)) ||
                 (layerEffect == string(LXs_FX_REFLCOLOR)) ||
                 (layerEffect == string(LXs_FX_SUBSCOLOR)) ||
                 (layerEffect == string(LXs_FX_TRANCOLOR)) ||
                 (layerEffect == string(LXs_FX_LUMICOLOR))) {

                storage = EFFECT_CONSTANT_STORAGE_COLOR;
                recognized = true;

                if (string(layerEffect) == string(LXs_FX_DIFFCOLOR)) {
                        type = MATERIAL_TEXTURE_EFFECT_DIFFUSE_COLOR;
                }
                else if (string(layerEffect) == string(LXs_FX_LUMICOLOR)) {
                        type = MATERIAL_TEXTURE_EFFECT_LUMINOUS_COLOR;
                }
                else if (string(layerEffect) == string(LXs_FX_REFLCOLOR)) {
                        type = MATERIAL_TEXTURE_EFFECT_REFLECTION_COLOR;
                }
                else if (string(layerEffect) == string(LXs_FX_SPECCOLOR)) {
                        type = MATERIAL_TEXTURE_EFFECT_SPECULAR_COLOR;
                }
                else if (string(layerEffect) == string(LXs_FX_SUBSCOLOR)) {
                        type = MATERIAL_TEXTURE_EFFECT_SUBSURFACE_COLOR;
                }
                else if (string(layerEffect) == string(LXs_FX_TRANCOLOR)) {
                        type = MATERIAL_TEXTURE_EFFECT_TRANSPARENT_COLOR;
                }
        }

        return recognized;
}

/*
 * Add a modo 401 profile constant effect technique.
 */
#if 0
        LxResult
COLLADASceneSaver::AddConstantEffect (EffectElement &effect)
{
        LxResult		 result(LXe_OK);

        ShaderNodeElement_modo401 constant(effect, ItemName ());

        constant.SetEnabled (ChanBool (LXsICHAN_TEXTURELAYER_ENABLE));
        constant.SetInverted (ChanBool (LXsICHAN_TEXTURELAYER_INVERT));

        constant.SetBlendMode (GetTextHintEncodedChannelValue (
                *this, LXsICHAN_TEXTURELAYER_BLEND));

        constant.SetOpacity (ChanFloat (LXsICHAN_TEXTURELAYER_OPACITY));

        /*
         * Fetch the effect mask type and storage type.
         */
        EffectMaskType			type;
        EffectConstantStorageType	storageType;

        const char *layerEffect =
                ChanString (LXsICHAN_TEXTURELAYER_EFFECT);
        if (GetEffectMaskType (layerEffect, type, storageType)) {
                constant.SetEffectMaskType (type);

                if (storageType == EFFECT_CONSTANT_STORAGE_PERCENT) {
                        constant.SetAmount (ChanFloat (LXsICHAN_CONSTANT_VALUE));
                }
                else if (storageType == EFFECT_CONSTANT_STORAGE_COLOR) {
                        Element::ColorRGB		color;
                        ChanColor (LXsICHAN_CONSTANT_COLOR, color);
                        constant.SetColor (color);
                }
        }

        return LOG_ERR (result);
}
#endif

        LxResult
COLLADASceneSaver::AddImageLibrary (
        COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding image library.");

        ImageLibraryElement imageLibrary(collada);

        unsigned imageIndex = 0;
        for (ImageMapFileSet::const_iterator iter =
                imageMapFiles.begin ();
                iter != imageMapFiles.end (); ++iter) {
                /*
                 * Insert a counted image
                 * entry into the library.
                 */
                string imageName =
                        string(ATTRVALUE_IMAGEPREFIX) +
                        string(IntegerToString (
                                static_cast<unsigned>(++imageIndex), 3));
                ImageElement image(
                        imageLibrary,
                        imageName);

                image.SetURI (*iter);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddMaterialLibrary (
        COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding material library.");

        MaterialLibraryElement materialLibrary(collada);

        for (MaterialSet::iterator iter = materialTagSet.begin ();
             iter != materialTagSet.end (); ++iter) {
                materialTag = *iter;
                if (ScanMask (materialTag.c_str ())) {
                        MaterialElement material(materialLibrary, materialTag);
                }
        }

        return LOG_ERR (result);
}

/*
 * Build the set of materials for later reference.
 */
        LxResult
COLLADASceneSaver::BuildMaterialSet ()
{
        LxResult		 result(LXe_OK);

        StartScan ();
        while (NextMesh ()) {
                VisitPolygons (POLYPASS_BUILDMATERIALSET);
        }

        return LOG_ERR (result);
}

/*
 * Add a geometry library.
 *
 * For each mesh, we add both the common technique, with the standard
 * elements, as well as a special modo profile technique, with additional
 * mesh item settings, as shown on the Properties panel.
 */
        LxResult
COLLADASceneSaver::AddGeometryLibrary (COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding geometry library.");

        GeometryLibraryElement geometryLibrary(collada);

        StartScan ();
        while (NextMesh ()) {
                if (ItemVisibleForSave () && PointCount ()) {
                        /*
                         * [TODO] Look for partial UVs, (a mix of vertices
                         *        with and without UVs), and if partial UVs
                         *        are detected, split up the mesh into
                         *        separate buckets, each written out as its
                         *        own geometry item within the same node.
                         */
                        string		 itemName(ItemName ());
                        GeometryElement	 geometry(geometryLibrary, ItemIdentity (), itemName);
                        MeshElement	 mesh(geometry, itemName);

                        /*
                         * Add the standard mesh geometry elements.
                         */
                        result = AddMeshGeometry (mesh);

                        if (ReallySaving () && prefs.SaveModoProfile ()) {
                                /*
                                 * Add the modo profile technique mesh properties,
                                 * for round-tripping.
                                 */
                                result = AddMeshTechniqueProfileModo401 (mesh);
                        }
                }
        }

        return LOG_ERR (result);
}

/*
 * Add the standard mesh geometry.
 */
        LxResult
COLLADASceneSaver::AddMeshGeometry (MeshElement &mesh)
{
        LxResult		 result(LXe_OK);
        string			 itemName(ItemName ());

        /*
         * Build the points array.
         */
        pointIndex = 0;
        WritePoints();

        CLxUser_Mesh		userMesh;
        CLxUser_MeshMap		meshMap;
        bool haveMeshMap = ChanObject (LXsICHAN_MESH_MESH, userMesh);
        if (haveMeshMap) {
                userMesh.GetMaps (meshMap);
        }

        /*
         * Build the normals array.
         */
        if (saveVertexNormals) {
                normalIndex = 0;

                /*
                 * Select the first normal map, if one is available.
                 */
                if (haveMeshMap) {
                        meshMap.FilterByType (LXi_VMAP_NORMAL);
                        MeshMapVisitor normalVisitor(&meshMap);
                        meshMap.Enum (&normalVisitor);
                        if( GetPrefs().OrderVMapsAlphabetically() )
                        {
                                normalVisitor.SortMapNames ();
                        }
                        normalMapNames = normalVisitor.GetMapNames ();
                        if (!normalMapNames.empty ()) {
                                StringArray::const_iterator iter = normalMapNames.begin ();
                                string normalMapName = *iter;
                                bool mapWasSet = SetMap (LXi_VMAP_NORMAL, normalMapName.c_str ());

                                LXxUNUSED (mapWasSet);
                        }
                }

                /*
                 * If custom vertex normals are not available,
                 * fall back to the geometric normals.
                 */
                VisitPolygons (POLYPASS_NORMALS);
        }

        /*
         * Build the texture coordinates array.
         */
        if (saveUVTextureCoordinates) {
                /*
                 * We write out a texture coordinate source element for each UV map,
                 * incrementing the suffix "set" index for each additional map.
                 */
                if (haveMeshMap) {
                        meshMap.FilterByType (LXi_VMAP_TEXTUREUV);
                        MeshMapVisitor uvVisitor(&meshMap);
                        meshMap.Enum (&uvVisitor);
                        if( GetPrefs().OrderVMapsAlphabetically() )
                        {
                                uvVisitor.SortMapNames ();
                        }
                        uvMapNames = uvVisitor.GetMapNames ();

                        /*
                         * [TODO] A partial UV map is saved with placeholder zero
                         *        indices for vertices with no UV mapping. In the
                         *        modo profile technique, write out a bool array
                         *        indicating which vertices are actually in each
                         *        UV set.
                         */
                        for (StringArray::const_iterator iter = uvMapNames.begin ();
                                iter != uvMapNames.end (); ++iter) {
                                /*
                                 * Select the texture coordinate set by name.
                                 */
                                string uvMapName = *iter;
                                if (SetMap (LXi_VMAP_TEXTUREUV, uvMapName.c_str ())) {

                                        /*
                                         * Iterate over all faces, adding the
                                         * texcoords to the current set.
                                         */
                                        texcoordIndex = 0;
                                        texcoordSet = static_cast<unsigned>(texcoordMaps.size ());

                                        TexcoordMapID texcoordMap = new TexcoordMap;
                                        texcoordMaps.push_back (texcoordMap);

                                        FloatArrayID texcoordArray = new Element::FloatArray;
                                        texcoordArrays.push_back (texcoordArray);

                                        VisitPolygons (POLYPASS_UVS);

                                        /*
                                        * [TODO] Split up POLYPASS_UVS into two stages
                                        *        (first stage could be POLYPASS_UVTALLY?),
                                        *        so we can first verify that a complete
                                        *        UV set is available before committing
                                        *        to writing it out.
                                        */
                                }
                        }
                }
        }

        /*
         * Build the colors array.
         */
        if (saveColors) {
                /*
                 * We write out a color source element for each color map,
                 * incrementing the suffix "set" index for each additional map.
                 *
                 * [TODO] A partial color map is saved with placeholder zero
                 *        indices for vertices with no colors. In the modo
                 *        profile technique, write out a bool array indicating
                 *        which vertices are actually in each color set.
                 */
                if (haveMeshMap) {
                        // RGB
                        meshMap.FilterByType (LXi_VMAP_RGB);
                        MeshMapVisitor colorRGBVisitor(&meshMap);
                        meshMap.Enum (&colorRGBVisitor);
                        if( GetPrefs().OrderVMapsAlphabetically() )
                        {
                                colorRGBVisitor.SortMapNames ();
                        }
                        colorRGBMapNames = colorRGBVisitor.GetMapNames ();

                        for (StringArray::const_iterator iter = colorRGBMapNames.begin ();
                                iter != colorRGBMapNames.end (); ++iter) {
                                /*
                                 * Select the color set by name.
                                 */
                                string colorRGBMapName = *iter;
                                if (SetMap (LXi_VMAP_RGB, colorRGBMapName.c_str ())) {

                                        /*
                                         * Iterate over all faces, adding the
                                         * colors to the current set.
                                         */
                                        colorRGBIndex = 0;
                                        colorRGBSet = static_cast<unsigned>(colorRGBMaps.size ());

                                        ColorRGBMapID colorRGBMap = new ColorRGBMap;
                                        colorRGBMaps.push_back (colorRGBMap);

                                        FloatArrayID colorRGBArray = new Element::FloatArray;
                                        colorRGBArrays.push_back (colorRGBArray);

                                        VisitPolygons (POLYPASS_RGB_COLORS);
                                }
                        }

                        // RGBA
                        meshMap.FilterByType (LXi_VMAP_RGBA);
                        MeshMapVisitor colorRGBAVisitor(&meshMap);
                        meshMap.Enum (&colorRGBAVisitor);
                        if( GetPrefs().OrderVMapsAlphabetically() )
                        {
                                colorRGBAVisitor.SortMapNames ();
                        }
                        colorRGBAMapNames = colorRGBAVisitor.GetMapNames ();

                        for (StringArray::const_iterator iter = colorRGBAMapNames.begin ();
                                iter != colorRGBAMapNames.end (); ++iter) {
                                /*
                                 * Select the color set by name.
                                 */
                                string colorRGBAMapName = *iter;
                                if (SetMap (LXi_VMAP_RGBA, colorRGBAMapName.c_str ())) {

                                        /*
                                         * Iterate over all faces, adding the
                                         * colors to the current set.
                                         */
                                        colorRGBAIndex = 0;
                                        colorRGBASet = static_cast<unsigned>(colorRGBAMaps.size ());

                                        ColorRGBAMapID colorRGBAMap = new ColorRGBAMap;
                                        colorRGBAMaps.push_back (colorRGBAMap);

                                        FloatArrayID colorRGBAArray = new Element::FloatArray;
                                        colorRGBAArrays.push_back (colorRGBAArray);

                                        VisitPolygons (POLYPASS_RGBA_COLORS);
                                }
                        }
                }
        }

        /*
         * Build the weight array.
         */
        if (saveWeights) {
                /*
                 * We write out a weight source element for each weight map,
                 * incrementing the suffix "set" index for each additional map.
                 */
                if (haveMeshMap) {
                        meshMap.FilterByType (LXi_VMAP_WEIGHT);
                        MeshMapVisitor weightVisitor(&meshMap);
                        meshMap.Enum (&weightVisitor);
                        if( GetPrefs().OrderVMapsAlphabetically() )
                        {
                                weightVisitor.SortMapNames ();
                        }
                        weightMapNames = weightVisitor.GetMapNames ();

                        /*
                         * [TODO] A partial UV map is saved with placeholder zero
                         *        indices for vertices with no weights. In the
                         *        modo profile technique, write out a bool array
                         *        indicating which vertices are actually in each
                         *        weight set.
                         */
                        for (StringArray::const_iterator iter = weightMapNames.begin ();
                                iter != weightMapNames.end (); ++iter) {
                                /*
                                 * Select the weight set by name.
                                 */
                                string weightMapName = *iter;
                                if (SetMap (LXi_VMAP_WEIGHT, weightMapName.c_str ())) {

                                        /*
                                         * Iterate over all faces, adding the
                                         * weights to the current set.
                                         */
                                        weightIndex = 0;
                                        weightSet = static_cast<unsigned>(weightMaps.size ());

                                        WeightMapID weightMap = new WeightMap;
                                        weightMaps.push_back (weightMap);

                                        FloatArrayID weightArray = new Element::FloatArray;
                                        weightArrays.push_back (weightArray);

                                        VisitPolygons (POLYPASS_WEIGHTS);

                                        /*
                                        * [TODO] Split up POLYPASS_WEIGHTS into two stages
                                        *        (first stage could be POLYPASS_WEIGHTTALLY?),
                                        *        so we can first verify that a complete
                                        *        weight set is available before committing
                                        *        to writing it out.
                                        */
                                }
                        }
                }
        }

        /*
         * Create the required positions source.
         */
        SourceElement sourcePosition(mesh, ATTRVALUE_POSITIONS_SOURCE_NAME);
        if (ReallySaving ()) {
                sourcePosition.AddFloatTripleArrayPacked (
                        ATTRVALUE_X, ATTRVALUE_Y, ATTRVALUE_Z, points);
        }

        sourceNormals = NULL;
        if (ReallySaving () && saveVertexNormals) {
                /*
                 * Create the normals source.
                 */
                sourceNormals = new SourceElement(mesh, ATTRVALUE_NORMALS_SOURCE_NAME);
                sourceNormals->AddFloatTripleArrayPacked (
                        ATTRVALUE_X, ATTRVALUE_Y, ATTRVALUE_Z, normals);
        }

        sourceTexcoords.clear ();
        if (ReallySaving () && saveUVTextureCoordinates) {
                /*
                 * Create a texcoords source for each uv map set.
                 */
                StringArray::const_iterator iterUV = uvMapNames.begin ();
                for (unsigned texcoordSetIndex = 0;
                     texcoordSetIndex < texcoordMaps.size (); ++texcoordSetIndex) {
                        SourceElementID sourceTexcoord = new SourceElement(
                                mesh,
                                *iterUV);
                        sourceTexcoords.push_back (sourceTexcoord);
                        sourceTexcoord->AddFloatPairArrayPacked (
                                ATTRVALUE_S, ATTRVALUE_T,
                                *(texcoordArrays.at (texcoordSetIndex)));

                        ++iterUV;
                }
        }

        sourceColors.clear ();
        if (ReallySaving () && saveColors) {
                /*
                 * Create a colors source for each RGB color set.
                 */
                StringArray::const_iterator iterColorRGB = colorRGBMapNames.begin ();
                for (unsigned colorRGBSetIndex = 0;
                     colorRGBSetIndex < colorRGBMaps.size (); ++colorRGBSetIndex) {
                        SourceElementID sourceColor = new SourceElement(
                                mesh,
                                *iterColorRGB);
                        sourceColors.push_back (sourceColor);
                        sourceColor->AddFloatTripleArrayPacked (
                                ATTRVALUE_R, ATTRVALUE_G, ATTRVALUE_B,
                                *(colorRGBArrays.at (colorRGBSetIndex)));

                        ++iterColorRGB;
                }

                /*
                 * Create a colors source for each RGBA color set.
                 */
                StringArray::const_iterator iterColorRGBA = colorRGBAMapNames.begin ();
                for (unsigned colorRGBASetIndex = 0;
                     colorRGBASetIndex < colorRGBAMaps.size (); ++colorRGBASetIndex) {
                        SourceElementID sourceColor = new SourceElement(
                                mesh,
                                *iterColorRGBA);
                        sourceColors.push_back (sourceColor);
                        sourceColor->AddFloatQuadArrayPacked (
                                ATTRVALUE_R, ATTRVALUE_G, ATTRVALUE_B, ATTRVALUE_A,
                                *(colorRGBAArrays.at (colorRGBASetIndex)));

                        ++iterColorRGBA;
                }
        }

        sourceWeights.clear ();
        if (ReallySaving () && saveWeights) {
                /*
                 * Create a weights source for each weight set.
                 */
                StringArray::const_iterator iterWeight = weightMapNames.begin ();
                for (unsigned weightSetIndex = 0;
                     weightSetIndex < weightMaps.size (); ++weightSetIndex) {
                        SourceElementID sourceWeight = new SourceElement(
                                mesh,
                                *iterWeight);
                        sourceWeights.push_back (sourceWeight);
                        sourceWeight->AddFloatArray (
                                ATTRVALUE_WEIGHT_INPUT_SEMANTIC,
                                *(weightArrays.at (weightSetIndex)));

                        ++iterWeight;
                }
        }

        if (ReallySaving ()) {
                /*
                 * Bind the source positions to the vertices.
                 */
                VerticesElement vertices(mesh, sourcePosition.GetID ());
        }

        /*
         * Build the polygons array.
         */
        activeMesh = &mesh;
        texcoordSet = 0;

        if (PolygonCount ()) {
                VisitPolygons (POLYPASS_POLYGONS);

                /*
                 * Add the polygons using a <polylist> or <triangles> representation,
                 * according to the Triangles as Triangles preference.
                 */
                if (prefs.SaveTrianglesAsTriangles ()) {
                        AddTriangles (materialTag);
                }
                else {
                        AddPolyList (materialTag);
                }
        }

        pointMap.clear ();
        points.clear ();

        normalMap.clear ();
        normals.clear ();

        /*
         * Free the various texcoord containers.
         */
        for (TexcoordMapIDArray::iterator tcmIter = texcoordMaps.begin ();
             tcmIter != texcoordMaps.end (); ++tcmIter) {
                delete *tcmIter;
        }

        for (FloatArrayIDArray::iterator tcaIter = texcoordArrays.begin ();
             tcaIter != texcoordArrays.end (); ++tcaIter) {
                delete *tcaIter;
        }

        /*
         * Free the various color containers.
         */
        for (ColorRGBMapIDArray::iterator cmIter = colorRGBMaps.begin ();
             cmIter != colorRGBMaps.end (); ++cmIter) {
                delete *cmIter;
        }
        for (ColorRGBAMapIDArray::iterator cmIter = colorRGBAMaps.begin ();
             cmIter != colorRGBAMaps.end (); ++cmIter) {
                delete *cmIter;
        }

        for (FloatArrayIDArray::iterator caIter = colorRGBArrays.begin ();
             caIter != colorRGBArrays.end (); ++caIter) {
                delete *caIter;
        }

        for (FloatArrayIDArray::iterator caIter = colorRGBAArrays.begin ();
             caIter != colorRGBAArrays.end (); ++caIter) {
                delete *caIter;
        }

        /*
         * Free the various weight containers.
         */
        for (WeightMapIDArray::iterator wmIter = weightMaps.begin ();
             wmIter != weightMaps.end (); ++wmIter) {
                delete *wmIter;
        }

        for (FloatArrayIDArray::iterator waIter = weightArrays.begin ();
             waIter != weightArrays.end (); ++waIter) {
                delete *waIter;
        }

        texcoordMaps.clear ();
        texcoordArrays.clear ();

        colorRGBMaps.clear ();
        colorRGBAMaps.clear ();
        colorRGBArrays.clear ();
        colorRGBAArrays.clear ();

        weightMaps.clear ();
        weightArrays.clear ();

        normalMapNames.clear ();
        uvMapNames.clear ();
        colorRGBMapNames.clear ();
        colorRGBAMapNames.clear ();
        weightMapNames.clear ();

        polyCounts.clear ();
        polyIndices.clear ();

        delete sourceNormals;

        /*
         * Free the source arrays for the texcoords.
         */
        for (SourceElementIDArray::iterator sidaIter = sourceTexcoords.begin ();
                sidaIter != sourceTexcoords.end (); ++sidaIter) {
                delete *sidaIter;
        }
        sourceTexcoords.clear ();

        /*
         * Free the source arrays for the colors.
         */
        for (SourceElementIDArray::iterator sidaIter = sourceColors.begin ();
                sidaIter != sourceColors.end (); ++sidaIter) {
                delete *sidaIter;
        }
        sourceColors.clear ();

        /*
         * Free the source arrays for the weights.
         */
        for (SourceElementIDArray::iterator sidaIter = sourceWeights.begin ();
                sidaIter != sourceWeights.end (); ++sidaIter) {
                delete *sidaIter;
        }
        sourceWeights.clear ();

        return LOG_ERR (result);
}

/*
 * Add the modo profile technique mesh properties, for round-tripping.
 */
        LxResult
COLLADASceneSaver::AddMeshTechniqueProfileModo401 (MeshElement &mesh)
{
        LxResult		 result(LXe_OK);

        MeshElement_modo401 meshProfile(mesh);

        meshProfile.SetRender (GetTextHintEncodedChannelValue (
                *this, LXsICHAN_LOCATOR_RENDER));

        meshProfile.SetDissolve (ChanFloat (LXsICHAN_LOCATOR_DISSOLVE));

        meshProfile.SetRenderCurves (ChanInt (LXsICHAN_MESH_RENDER_CURVES) != 0);
        meshProfile.SetCurveRadius (ChanFloat (LXsICHAN_MESH_CURVE_RADIUS));

        return LOG_ERR (result);
}

/*
 * Visit the polygons for the selected mesh, processing according to
 * the inPolyPass mode.
 */
        LxResult
COLLADASceneSaver::VisitPolygons (PolyPass inPolyPass)
{
        LxResult		 result(LXe_OK);

        polyPass = inPolyPass;

        materialTag = "";
        polyCounts.clear ();
        polyIndices.clear ();

        /*
         * For the polygon pass, unify enumeration by the polygon material tags.
         */
        WritePolys (0, polyPass == POLYPASS_POLYGONS);

        return LOG_ERR (result);
}

/*
 * Access and cache the normal for the polygon vertex at the given index.
 *
 * For now, an arbitrary normal is cached for vertices without normals,
 * but the modo profile should flag vertices with or without normals.
 */
        void
COLLADASceneSaver::AddVertexNormal (unsigned polyVertexIndex)
{
        NormalMap::iterator	mapIter;
        double			nvec[3];
        Normal			normal;

        LXtPointID vertexID = PolyVertex (polyVertexIndex);
#if defined(MODO_401_SP5)
        /*
         * [TODO] Test PolyNormal once fix is integrated into modo 401 SP5.
         */
        if (!PolyNormal (nvec, vertexID)) {
#else
        bool haveNormal;
        if (!normalMapNames.empty ()) {
                float fvec[3];
                haveNormal = PolyMapValue (fvec, vertexID);
                nvec[0] = fvec[0]; nvec[1] = fvec[1]; nvec[2] = fvec[2];
        }
        else {
                haveNormal = PolyNormal (nvec, vertexID);
        }
        if (!haveNormal) {
#endif
                /*
                 * [TODO] Add modo profile flags for vertices with or without normals.
                 */
                nvec[0] = 1.0;
                nvec[1] = nvec[2] = 0.0;
        }

        normal.vec[0] = nvec[0];
        normal.vec[1] = nvec[1];
        normal.vec[2] = nvec[2];

        /*
         * Only push back unique normals.
         */
        mapIter = normalMap.find (normal);
        if (mapIter == normalMap.end ())
        {
                normalMap[normal] = normalIndex++;

                normals.push_back (static_cast<float>(nvec[0]));
                normals.push_back (static_cast<float>(nvec[1]));
                normals.push_back (static_cast<float>(nvec[2]));
        }
}

        unsigned
COLLADASceneSaver::FindVertexNormal (unsigned polyVertexIndex)
{
        double			nvec[3];
        unsigned		index(0);

        LXtPointID vertexID = PolyVertex (polyVertexIndex);
#if defined(MODO_401_SP5)
        /*
         * [TODO] Test PolyNormal once fix is integrated into modo 401 SP5.
         */
        if (PolyNormal (nvec, vertexID)) {
#else
        bool haveNormal;
        if (!normalMapNames.empty ()) {
                float fvec[3];
                haveNormal = PolyMapValue (fvec, vertexID);
                nvec[0] = fvec[0]; nvec[1] = fvec[1]; nvec[2] = fvec[2];
        }
        else {
                haveNormal = PolyNormal (nvec, vertexID);
        }

        if (haveNormal) {
#endif
                Normal		normal;
                normal.vec[0] = nvec[0];
                normal.vec[1] = nvec[1];
                normal.vec[2] = nvec[2];

                NormalMap::iterator mapIter = normalMap.find (normal);
                if (mapIter != normalMap.end ())
                {
                        index = mapIter->second;
                }
        }

        return index;
}

        void
COLLADASceneSaver::AddVertexTexture (unsigned polyVertexIndex)
{
        TexcoordMap::iterator	mapIter;
        float			nvec[2];
        Texcoord		texcoord;

        LXtPointID vertex = PolyVertex (polyVertexIndex);
        if (!PolyMapValue (nvec, vertex))
        {
                /*
                 * [TODO] For now, we handle case of missing texcoords
                 *        for the entire mesh by writing (0, 0). We
                 *        should indicate which vertices have valid
                 *        UV indices in the modo profile technique.
                 */
                nvec[0] = nvec[1] = 0.0f;
        }

        texcoord.vec[0] = nvec[0];
        texcoord.vec[1] = nvec[1];

        /*
         * Only push back unique texcoords.
         */
        TexcoordMapID	texcoordMap = texcoordMaps.at (texcoordSet);
        mapIter = texcoordMap->find (texcoord);
        if (mapIter == texcoordMap->end ())
        {
                (*texcoordMap)[texcoord] = texcoordIndex++;

                FloatArrayID	texcoords = texcoordArrays.at (texcoordSet);
                texcoords->push_back (nvec[0]);
                texcoords->push_back (nvec[1]);
        }
}

        unsigned
COLLADASceneSaver::FindVertexTexture (unsigned polyVertexIndex)
{
        float			nvec[2];
        unsigned		index(0);

        LXtPointID vertexID = PolyVertex (polyVertexIndex);
        if (PolyMapValue (nvec, vertexID))
        {
                Texcoord	texcoord;
                texcoord.vec[0] = nvec[0];
                texcoord.vec[1] = nvec[1];

                TexcoordMapID	texcoordMap = texcoordMaps.at (texcoordSet);
                TexcoordMap::iterator mapIter = texcoordMap->find (texcoord);
                if (mapIter != texcoordMap->end ())
                {
                        index = mapIter->second;
                }
        }

        return index;
}

        void
COLLADASceneSaver::AddVertexColor (unsigned polyVertexIndex, bool useAlpha)
{
        float			nvec[4];

        LXtPointID vertex = PolyVertex (polyVertexIndex);
        if (!PolyMapValue (nvec, vertex))
        {
                /*
                 * [TODO] For now, we handle case of missing colors
                 *        for the entire mesh by writing (0, 0, 0). We
                 *        should indicate which vertices have valid
                 *        UV indices in the modo profile technique.
                 */
                nvec[0] = nvec[1] = nvec[2] = 0.0f;
                if (useAlpha) {
                        nvec[3] = 1.0f;
                }
        }

        if (useAlpha) {
                ColorRGBA	color;

                color.vec[0] = nvec[0];
                color.vec[1] = nvec[1];
                color.vec[2] = nvec[2];
                color.vec[3] = nvec[3];

                /*
                 * Only push back unique colors.
                 */
                ColorRGBAMapID	colorMap = colorRGBAMaps.at (colorRGBASet);
                ColorRGBAMap::iterator	mapIter;
                mapIter = colorMap->find (color);
                if (mapIter == colorMap->end ())
                {
                        (*colorMap)[color] = colorRGBAIndex++;

                        FloatArrayID	colors =
                                colorRGBAArrays.at (colorRGBASet);
                        colors->push_back (nvec[0]);
                        colors->push_back (nvec[1]);
                        colors->push_back (nvec[2]);
                        colors->push_back (nvec[3]);
                }
        }
        else {
                ColorRGB	color;
                color.vec[0] = nvec[0];
                color.vec[1] = nvec[1];
                color.vec[2] = nvec[2];

                /*
                 * Only push back unique colors.
                 */
                ColorRGBMapID	colorMap = colorRGBMaps.at (colorRGBSet);
                ColorRGBMap::iterator	mapIter;
                mapIter = colorMap->find (color);
                if (mapIter == colorMap->end ())
                {
                        (*colorMap)[color] = colorRGBIndex++;

                        FloatArrayID	colors =
                                colorRGBArrays.at (colorRGBSet);
                        colors->push_back (nvec[0]);
                        colors->push_back (nvec[1]);
                        colors->push_back (nvec[2]);
                }
        }
}

        unsigned
COLLADASceneSaver::FindVertexRGBColor (unsigned polyVertexIndex)
{
        float			nvec[3];
        unsigned		index(0);

        LXtPointID vertexID = PolyVertex (polyVertexIndex);
        if (PolyMapValue (nvec, vertexID))
        {
                ColorRGB	color;
                color.vec[0] = nvec[0];
                color.vec[1] = nvec[1];
                color.vec[2] = nvec[2];

                ColorRGBMapID	colorMap = colorRGBMaps.at (colorRGBSet);
                ColorRGBMap::iterator mapIter = colorMap->find (color);
                if (mapIter != colorMap->end ())
                {
                        index = mapIter->second;
                }
        }

        return index;
}

        unsigned
COLLADASceneSaver::FindVertexRGBAColor (unsigned polyVertexIndex)
{
        float			nvec[4];
        unsigned		index(0);

        LXtPointID vertexID = PolyVertex (polyVertexIndex);
        if (PolyMapValue (nvec, vertexID))
        {
                ColorRGBA	color;
                color.vec[0] = nvec[0];
                color.vec[1] = nvec[1];
                color.vec[2] = nvec[2];
                color.vec[3] = nvec[3];

                ColorRGBAMapID	colorMap = colorRGBAMaps.at (colorRGBASet);
                ColorRGBAMap::iterator mapIter = colorMap->find (color);
                if (mapIter != colorMap->end ())
                {
                        index = mapIter->second;
                }
        }

        return index;
}

        void
COLLADASceneSaver::AddVertexWeight (unsigned polyVertexIndex)
{
        WeightMap::iterator	mapIter;
        float			weight;

        LXtPointID vertex = PolyVertex (polyVertexIndex);
        if (!PolyMapValue (&weight, vertex))
        {
                /*
                 * [TODO] For now, we handle case of missing weights
                 *        for the entire mesh by writing zero. We
                 *        should indicate which vertices have valid
                 *        weight indices in the modo profile technique.
                 */
                weight = 0.0f;
        }


        /*
         * Only push back unique weights.
         */
        WeightMapID	weightMap = weightMaps.at (weightSet);
        mapIter = weightMap->find (weight);
        if (mapIter == weightMap->end ())
        {
                (*weightMap)[weight] = weightIndex++;

                FloatArrayID	weights = weightArrays.at (weightSet);
                weights->push_back (weight);
        }
}

        unsigned
COLLADASceneSaver::FindVertexWeight (unsigned polyVertexIndex)
{
        float			weight;
        unsigned		index(0);

        LXtPointID vertexID = PolyVertex (polyVertexIndex);
        if (PolyMapValue (&weight, vertexID))
        {
                WeightMapID	weightMap = weightMaps.at (weightSet);
                WeightMap::iterator mapIter = weightMap->find (weight);
                if (mapIter != weightMap->end ())
                {
                        index = mapIter->second;
                }
        }

        return index;
}

        bool
COLLADASceneSaver::AllTriangles () const
{
        bool	allTriangles(true);
        for (vector<unsigned>::const_iterator iter = polyCounts.begin ();
             iter != polyCounts.end (); ++iter) {
                if (*iter != 3) {
                        allTriangles = false;
                        break;
                }
        }

        return allTriangles;
}

        void
COLLADASceneSaver::AddTriangles (
        const string	&materialName)
{
        if (ReallySaving ()) {
                if (AllTriangles ()) {
                        TrianglesElement triangles(
                                *activeMesh, static_cast<unsigned>(polyCounts.size ()));

                        /*
                         * Bind the polylist to its material.
                         */
                        triangles.SetMaterialName (materialName);

                        /*
                         * Add the inputs. Normals and texture coordinates are optional.
                         */
                        triangles.AddVertexInput ();

                        if (saveVertexNormals) {
                                triangles.AddNormalInput (sourceNormals->GetID ());
                        }

                        if (saveUVTextureCoordinates) {
                                vector<string> sourceTexcoordsIDs;
                                vector<unsigned> texcoordSetIndices;
                                for (unsigned texcoordSetIndex = 0;
                                     texcoordSetIndex < texcoordMaps.size ();
                                     ++texcoordSetIndex) {
                                        sourceTexcoordsIDs.push_back (
                                                sourceTexcoords.at (texcoordSetIndex)->GetID ());
                                        texcoordSetIndices.push_back (texcoordSetIndex);
                                }
                                triangles.AddTexcoordInputs (sourceTexcoordsIDs, texcoordSetIndices);
                        }

                        if (saveColors) {
                                vector<string> sourceColorIDs;
                                vector<unsigned> colorSetIndices;

                                // RGB
                                unsigned colorRGBSetIndex;
                                for (colorRGBSetIndex = 0;
                                     colorRGBSetIndex < colorRGBMaps.size ();
                                     ++colorRGBSetIndex) {
                                        sourceColorIDs.push_back (
                                                sourceColors.at (colorRGBSetIndex)->GetID ());
                                        colorSetIndices.push_back (colorRGBSetIndex);
                                }

                                // RGBA
                                for (unsigned colorRGBASetIndex = colorRGBSetIndex;
                                     colorRGBASetIndex < colorRGBAMaps.size ();
                                     ++colorRGBASetIndex) {
                                        sourceColorIDs.push_back (
                                                sourceColors.at (colorRGBASetIndex)->GetID ());
                                        colorSetIndices.push_back (colorRGBASetIndex);
                                }

                                triangles.AddColorInputs (sourceColorIDs, colorSetIndices);
                        }

                        if (saveWeights) {
                                vector<string> sourceWeightIDs;
                                vector<unsigned> weightSetIndices;
                                for (unsigned weightSetIndex = 0;
                                     weightSetIndex < weightMaps.size ();
                                     ++weightSetIndex) {
                                        sourceWeightIDs.push_back (
                                                sourceWeights.at (weightSetIndex)->GetID ());
                                        weightSetIndices.push_back (weightSetIndex);
                                }
                                triangles.AddWeightInputs (sourceWeightIDs, weightSetIndices);
                        }

                        /*
                         * Add the triangle input indices.
                         */
                        triangles.AddInputIndices (polyIndices);
                }
                else {
                        AddPolyList (materialName);
                }
        }
}

        void
COLLADASceneSaver::AddPolyList (
        const string	&materialName)
{
        if (ReallySaving ()) {
                PolylistElement polylist(
                        *activeMesh, static_cast<unsigned>(polyCounts.size ()));

                /*
                 * Bind the polylist to its material.
                 */
                polylist.SetMaterialName (materialName);

                /*
                 * Add the inputs. Normals and texture coordinates are optional.
                 */
                polylist.AddVertexInput ();

                if (saveVertexNormals) {
                        polylist.AddNormalInput (sourceNormals->GetID ());
                }

                if (saveUVTextureCoordinates) {
                        vector<string> sourceTexcoordsIDs;
                        vector<unsigned> texcoordSetIndices;
                        for (unsigned texcoordSetIndex = 0;
                             texcoordSetIndex < texcoordMaps.size ();
                             ++texcoordSetIndex) {
                                sourceTexcoordsIDs.push_back (
                                        sourceTexcoords.at (texcoordSetIndex)->GetID ());
                                texcoordSetIndices.push_back (texcoordSetIndex);
                        }
                        polylist.AddTexcoordInputs (sourceTexcoordsIDs, texcoordSetIndices);
                }

                if (saveColors) {
                        vector<string> sourceColorIDs;
                        vector<unsigned> colorSetIndices;

                        // RGB
                        unsigned colorRGBSetIndex;
                        for (colorRGBSetIndex = 0;
                             colorRGBSetIndex < colorRGBMaps.size ();
                             ++colorRGBSetIndex) {
                                sourceColorIDs.push_back (
                                        sourceColors.at (colorRGBSetIndex)->GetID ());
                                colorSetIndices.push_back (colorRGBSetIndex);
                        }

                        // RGBA
                        for (unsigned colorRGBASetIndex = colorRGBSetIndex;
                             colorRGBASetIndex < (colorRGBSetIndex + colorRGBAMaps.size ());
                             ++colorRGBASetIndex) {
                                sourceColorIDs.push_back (
                                        sourceColors.at (colorRGBASetIndex)->GetID ());
                                colorSetIndices.push_back (colorRGBASetIndex);
                        }

                        polylist.AddColorInputs (sourceColorIDs, colorSetIndices);
                }

                if (saveWeights) {
                        vector<string> sourceWeightIDs;
                        vector<unsigned> weightSetIndices;
                        for (unsigned weightSetIndex = 0;
                             weightSetIndex < weightMaps.size ();
                             ++weightSetIndex) {
                                sourceWeightIDs.push_back (
                                        sourceWeights.at (weightSetIndex)->GetID ());
                                weightSetIndices.push_back (weightSetIndex);
                        }
                        polylist.AddWeightInputs (sourceWeightIDs, weightSetIndices);
                }

                /*
                 * Add the vertex counts and the polygon input indices.
                 */
                polylist.AddVertexCounts (polyCounts);
                polylist.AddInputIndices (polyIndices);
        }
}

        void
COLLADASceneSaver::AddPolygon ()
{
        string polyMaterialTag(PolyTag (LXi_PTAG_MATR));
        if ((!polyMaterialTag.empty ()) &&
            (polyMaterialTag != materialTag)) {
                /*
                 * Test if we are transitioning onto another set
                 * of polygons associated with a different material.
                 */
                if (polyCounts.size () > 0 && !materialTag.empty ()) {
                        /*
                         * Add the polygons using a <polylist> or <triangles>
                         * representation, according to the Triangles as
                         * Triangles preference.
                         */
                        if (prefs.SaveTrianglesAsTriangles ()) {
                                AddTriangles (materialTag);
                        }
                        else {
                                AddPolyList (materialTag);
                        }
                }
                materialTag = polyMaterialTag;
                polyCounts.clear ();
                polyIndices.clear ();
        }

        unsigned polyVertexCount = PolyNumVerts ();
        polyCounts.push_back (polyVertexCount);
        if (polyVertexCount) {
                for (unsigned polyVertexIndex = 0;
                     polyVertexIndex < polyVertexCount; ++polyVertexIndex)
                {
                        LXtPointID pointID = PolyVertex (polyVertexIndex);
                        unsigned vertexIndex = pointMap[pointID];
                        polyIndices.push_back (vertexIndex);

                        if (saveVertexNormals) {
                                if (!normalMapNames.empty ()) {
                                        string normalMapName = *(normalMapNames.begin ());
                                        bool mapWasSet = SetMap (LXi_VMAP_NORMAL, normalMapName.c_str ());

                                        LXxUNUSED (mapWasSet);
                                }
                                unsigned normalIndex =
                                        FindVertexNormal (polyVertexIndex);
                                polyIndices.push_back (normalIndex);
                        }

                        if (saveUVTextureCoordinates) {
                                texcoordSet = 0;
                                for (StringArray::const_iterator iter = uvMapNames.begin ();
                                     iter != uvMapNames.end (); ++iter) {
                                        /*
                                         * Select the texture coordinate set by name.
                                         */
                                        string uvMapName = *iter;
                                        if (SetMap (LXi_VMAP_TEXTUREUV, uvMapName.c_str ())) {
                                                unsigned texcoordIndex =
                                                        FindVertexTexture (polyVertexIndex);
                                                polyIndices.push_back (texcoordIndex);
                                        }
                                        ++texcoordSet;
                                }
                        }

                        if (saveColors) {
                                // RGB
                                colorRGBSet = 0;
                                for (StringArray::const_iterator iter = colorRGBMapNames.begin ();
                                     iter != colorRGBMapNames.end (); ++iter) {
                                        /*
                                         * Select the color set by name.
                                         */
                                        string colorRGBMapName = *iter;
                                        if (SetMap (LXi_VMAP_RGB, colorRGBMapName.c_str ())) {
                                                unsigned colorIndex =
                                                        FindVertexRGBColor (polyVertexIndex);
                                                polyIndices.push_back (colorIndex);
                                        }
                                        ++colorRGBSet;
                                }

                                // RGBA
                                colorRGBASet = 0;
                                for (StringArray::const_iterator iter = colorRGBAMapNames.begin ();
                                     iter != colorRGBAMapNames.end (); ++iter) {
                                        /*
                                         * Select the color set by name.
                                         */
                                        string colorRGBAMapName = *iter;
                                        if (SetMap (LXi_VMAP_RGBA, colorRGBAMapName.c_str ())) {
                                                unsigned colorIndex =
                                                        FindVertexRGBAColor (polyVertexIndex);
                                                polyIndices.push_back (colorIndex);
                                        }
                                        ++colorRGBASet;
                                }
                        }

                        if (saveWeights) {
                                weightSet = 0;
                                for (StringArray::const_iterator iter = weightMapNames.begin ();
                                     iter != weightMapNames.end (); ++iter) {
                                        /*
                                         * Select the weight set by name.
                                         */
                                        string weightMapName = *iter;
                                        if (SetMap (LXi_VMAP_WEIGHT, weightMapName.c_str ())) {
                                                unsigned weightIndex =
                                                        FindVertexWeight (polyVertexIndex);
                                                polyIndices.push_back (weightIndex);
                                        }
                                        ++weightSet;
                                }
                        }
                }
        }
}

/*
 * Constructor.
 */
COLLADASceneSaver::COLLADASceneSaver()
        :
        io(IO_MODE_SAVE, prefs.FormattedArrays ()),
        isRegistered(false),
        saveAnimation(SAVE_ANIMATION),
        haveAtLeastOneAnimation(false),
        haveAtLeastOneCamera(false),
        haveAtLeastOneCameraAnimation(false),
        haveAtLeastOneLightAnimation(false),
        haveAtLeastOneEffect(false),
        haveAtLeastOneImage(false),
        haveAtLeastOneMaterial(false),
        haveAtLeastOneMesh(false),
        haveAtLeastOneMeshAnimation(false),
        pointIndex(0),
        normalIndex(0),
        texcoordIndex(0),
        texcoordSet(0),
        polyCount(0),
        polyPass(POLYPASS_BUILDMATERIALSET),
        activeMesh(NULL),
        sourceNormals(NULL),
        instance_geometry(NULL),
        bind_material(NULL),
        haveAtLeastOneController(false),
        haveAtLeastOneItem(false),
        haveAtLeastOneTransformAnimation(false)
{
        itemTypeChannelVisitor.SetSceneSaver (this);
}

/*
 * Add the controllers library element.
 */
        LxResult
COLLADASceneSaver::AddControllerLibrary (COLLADAElement &collada)
{
        LxResult		result(LXe_OK);

        log.Info ("Adding controllers library.");

        ControllerLibraryElement	controllerLibrary(collada);

        // Search for mesh items with a deformer.
        StartScan ();
        while (NextMesh ()) {
                CLxUser_Item	 meshItem;
                if (ItemVisibleForSave () && PointCount () &&
                    ItemIsA (LXsITYPE_MESH) && GetItem (meshItem)) {
                        CLxUser_GroupDeformer	 groupDeformer;
                        unsigned		 groupDeformerMeshIndex;

                        if (FindGroupDeformer (meshItem, groupDeformer, groupDeformerMeshIndex)) {
                                if (groupDeformer.test ()) {
                                        string			itemName(ItemName ());
                                        ControllerElement	controller(controllerLibrary, ItemIdentity (), itemName);
                                        SkinElement		skin(controller, itemName);

                                        result = AddSkinController (
                                                skin, meshItem,
                                                groupDeformer,
                                                groupDeformerMeshIndex);
                                }
                        }
                }
        }

        return result;
}

/*
 * ---------------------------------------------------------------------------
 * Visitor for the deformer and weight pairs associated with each point of a mesh.
 */
class DeformerWeightToVertexVisitor : public CLxImpl_AbstractVisitor
{
   public:
        CLxUser_Item			 rootLocator;
        IndexNodeIDMap			 indexNodeMap;
        NodeIDIndexMap			 nodeIndexMap;
        vector<unsigned>		 boneCounts;
        vector<unsigned>		 jointWeightIndices;
        Matrix4Array			 invBindMatrices;
        vector<float>			 weights;

        unsigned			 pointIndex;

        typedef CLxUser_GroupDeformer::DeformerWeightArray DeformerWeightArray;
        DeformerWeightArray		 deformerWeightList;

                                         DeformerWeightToVertexVisitor (
                                                CLxUser_Item		&meshItem,
                                                CLxUser_GroupDeformer	*groupDeformerID,
                                                unsigned		 groupDeformerMeshIndex,
                                                set<string>		*jointNodeIDs);

                                        ~DeformerWeightToVertexVisitor ();

        void				 CalcLocatorMatrix (
                                                CLxUser_Item		&locatorItem,
                                                Matrix4			&matrix);

        bool				 CalcInverseBindMatrix (
                                                CLxUser_Item		&locatorItem,
                                                Matrix4			&invBindMatrix);

        void				 FindLocators ();

        LxResult			 Enumerate ();

        virtual LxResult		 Evaluate () LXx_OVERRIDE;

    private:
        bool				 FindRootLocator (
                                                CLxUser_Item		&root);

        LxResult			 EvaluateLocatorPass ();

        LxResult			 EvaluateJointWeightPass ();

        int				 ItemChanInt (
                                                CLxUser_Item		&item,
                                                const char		*channel);

        double				 ItemChanFloat (
                                                CLxUser_Item		&item,
                                                const char		*channel);

        void				 ItemChanXform (
                                                CLxUser_Item		&item,
                                                const char		*channel,
                                                LXtVector		 vec);

        CLxUser_SceneService		 sceneSvc;
        CLxUser_Scene			 scene;
        set<string>			*nodeIDs;
        CLxLoc_ChannelRead		 setupChannels;
        CLxUser_SceneGraph		 sceneGraph;
        CLxUser_ItemGraph		 itemGraph;
        bool				 isLocatorPass;
        CLxUser_GroupDeformer		*groupDeformer;
        unsigned			 meshIndex;
        CLxUser_Point			 meshPoint;
};

DeformerWeightToVertexVisitor::DeformerWeightToVertexVisitor (
        CLxUser_Item		&meshItem,
        CLxUser_GroupDeformer	*groupDeformerID,
        unsigned		 groupDeformerMeshIndex,
        set<string>		*jointNodeIDs)
        :
        pointIndex(0),
        isLocatorPass(false),
        groupDeformer(groupDeformerID),
        meshIndex(groupDeformerMeshIndex)
{
        CLxUser_Mesh mesh;
        scene.from (meshItem);

        // Link to the set of node IDs and clear it out for the next visitation.
        nodeIDs = jointNodeIDs;
        nodeIDs->clear ();

        CLxUser_ChannelRead	 chans;
        if (scene.GetChannels (chans, LXs_ACTIONLAYER_EDIT)) {	// get channels for base mesh
                /* Get the mesh from the mesh item. */
                chans.Object (meshItem, LXsICHAN_MESH_MESH, mesh);
                if (mesh.test ()) {
                        meshPoint.fromMesh (mesh);
                }
        }

        scene.GetSetupChannels (setupChannels);

        scene.GetGraph (LXsGRAPH_XFRMCORE, sceneGraph);
        itemGraph.set (sceneGraph);
}

DeformerWeightToVertexVisitor::~DeformerWeightToVertexVisitor ()
{
}

        void
DeformerWeightToVertexVisitor::CalcLocatorMatrix (
        CLxUser_Item		&locatorItem,
        Matrix4			&matrix)
{
        Matrix4Identity (matrix);

        /*
         * For the matrix case, we need to reverse iterate
         * over the transform graph.
         */
        unsigned transformCount = itemGraph.Reverse (locatorItem);
        for (unsigned transformIndex = 0;
                transformIndex < transformCount; ++transformIndex) {
                CLxUser_Item transform;
                if (itemGraph.Reverse (locatorItem, transformIndex, transform)) {
                        const char *xformType;
                        sceneSvc.ItemTypeName (transform.Type (), &xformType);
                        if (string(xformType) == string(LXsITYPE_SCALE)) {
                                LXtVector	scale;
                                ItemChanXform (transform, LXsICHAN_SCALE_SCL, scale);
                                LXtMatrix4 sm;
                                Matrix4CreateScale (sm, scale);
                                Matrix4Compose (matrix, sm);
                        }
                        else if (string(xformType) == string(LXsITYPE_ROTATION)) {
                                LXtVector rotate;
                                ItemChanXform (transform, LXsICHAN_ROTATION_ROT, rotate);

                                /*
                                 * Take rotation order into account.
                                 */
                                int axis[3];
                                BuildAxisOrder (
                                        ItemChanInt (transform, LXsICHAN_ROTATION_ORDER),
                                        axis);

                                LXtMatrix4 rm;
                                Matrix4CreateRotation (
                                        rm, rotate[axis[0]], axis[0]);
                                Matrix4Compose (matrix, rm);

                                Matrix4CreateRotation (
                                        rm, rotate[axis[1]], axis[1]);
                                Matrix4Compose (matrix, rm);

                                Matrix4CreateRotation (
                                        rm, rotate[axis[2]], axis[2]);
                                Matrix4Compose (matrix, rm);
                        }
                        else if (string(xformType) == string(LXsITYPE_TRANSLATION)) {
                                LXtVector	translate;
                                ItemChanXform (transform, LXsICHAN_TRANSLATION_POS, translate);
                                LXtMatrix4 tm;
                                Matrix4CreateTranslation (
                                        tm, translate);
                                Matrix4Compose (matrix, tm);
                        }
                        else if (string(xformType) == string(LXsITYPE_TRANSFORM)) {
                                LXtVector	translate = {0, 0, 0};

                                /*
                                 * Walk the local graph and find the translate item for
                                 * which this transform is the inverse.
                                 */
                                CLxUser_SceneGraph	 sceneGraph;
                                scene.GetGraph (LXsGRAPH_XFRMLOCAL, sceneGraph);
                                CLxUser_ItemGraph localGraph;
                                localGraph.set (sceneGraph);
                                CLxUser_Item localTransform;
                                if (localGraph.Reverse (transform, 0, localTransform)) {
                                        /*
                                         * Fetch the translation vector and negate it.
                                         */
                                        const char *localXformType;
                                        sceneSvc.ItemTypeName (localTransform.Type (), &localXformType);
                                        if (string(localXformType) == string(LXsITYPE_TRANSLATION)) {
                                                ItemChanXform (
                                                        localTransform,
                                                        LXsICHAN_TRANSLATION_POS,
                                                        translate);
                                                translate[0] = -translate[0];
                                                translate[1] = -translate[1];
                                                translate[2] = -translate[2];

                                                /*
                                                 * And bake it in...
                                                 */
                                                LXtMatrix4 tm;
                                                Matrix4CreateTranslation (
                                                        tm, translate);
                                                Matrix4Compose (matrix, tm);
                                        }
                                }
                        }
                }
        }
}

        bool
DeformerWeightToVertexVisitor::CalcInverseBindMatrix (
        CLxUser_Item		&locatorItem,
        Matrix4			&invBindMatrix)
{
        bool		 haveInverseBindMatrix = false;
        Matrix4		 itemMatrix;

#if 0
        // Simplified test to invert the world transform matrix.
        CLxLoc_Locator	locator;
        if (locator.set (locatorItem)) {
                if (LXx_OK (locator.WorldTransform4 (setupChannels, itemMatrix))) {
                        if (Matrix4Invert (itemMatrix)) {
                                haveInverseBindMatrix = true;
                        }
                }
        }
#else
        CalcLocatorMatrix (locatorItem, itemMatrix);
        if (Matrix4Invert (itemMatrix)) {
                string		locatorID = locatorItem.GetIdentity ();
                string		rootLocatorID = rootLocator.GetIdentity ();

                // Check if we're already at the root locator item.
                haveInverseBindMatrix = (locatorID == rootLocatorID);

                // Walk up the tree, inverting and concatenating each of the
                // locator matrices until we're at the root locator item.
                CLxUser_Item	parentItem;
                while (!haveInverseBindMatrix) {
                        if (locatorItem.GetParent (parentItem)) {
                                Matrix4		parentMatrix;
                                CalcLocatorMatrix (parentItem, parentMatrix);
                                if (Matrix4Invert (parentMatrix)) {
                                        Matrix4Compose (parentMatrix, itemMatrix);
                                        Matrix4Copy (itemMatrix, parentMatrix);
                                }
                                else {
                                        // Result is undefined if the
                                        // matrix is not invertible.
                                        break;
                                }

                                if (parentItem.GetIdentity () == rootLocatorID) {
                                        haveInverseBindMatrix = true;
                                }
                                else {
                                        locatorItem.set (parentItem);
                                }
                        }
                        else {
                                break;
                        }
                }
        }
#endif
        Matrix4Copy (invBindMatrix, itemMatrix);

        return haveInverseBindMatrix;
}

        void
DeformerWeightToVertexVisitor::FindLocators ()
{
        isLocatorPass = true;
        Enumerate ();
        FindRootLocator (rootLocator);
        isLocatorPass = false;
}

        LxResult
DeformerWeightToVertexVisitor::Enumerate ()
{
        /* First iterate over all of the points. */
        LxResult	result = meshPoint.Enum (this);

        /* If this is the second pass (the first pass gathered the locators),
           create the matching array of inverse bind matrices. */
        if (LXx_OK (result) && !isLocatorPass) {
                /*
                 * Calculate the inverse bind matrix for each of
                 * the joints referenced by the group deformer.
                 */
                for (set<string>::const_iterator iter = nodeIDs->begin ();
                        iter != nodeIDs->end (); ++iter) {
                        CLxUser_Item	nodeItem;
                        string		nodeID = *iter;
                        if (scene.GetItem (nodeID.c_str (), nodeItem)) {
                                Matrix4Wrap	invBindMatrix;
                                if (CalcInverseBindMatrix (
                                        nodeItem, invBindMatrix.m)) {
                                        invBindMatrices.push_back (invBindMatrix);
                                        result = LXe_OK;
                                }
                                else {
                                        // Results are undefined if any of the
                                        // matrices are not invertible.
                                        result = LXe_FAILED;
                                        break;
                                }
                        }
                }
        }

        return result;
}

        LxResult
DeformerWeightToVertexVisitor::Evaluate ()
{
        LxResult	result = LXe_FAILED;

        if (meshPoint.test ()) {
                /* Get the list of deformers and weights for this point. */
                groupDeformer->PointEffectList (meshIndex, meshPoint.ID (), deformerWeightList);

                if (isLocatorPass) {
                        result = EvaluateLocatorPass ();
                }
                else {
                        result = EvaluateJointWeightPass ();
                }

                ++pointIndex;
        }

        LXxUNUSED (result);

        return LXe_OK;
}

        bool
DeformerWeightToVertexVisitor::FindRootLocator (
        CLxUser_Item		&root)
{
        bool			foundRoot = false;
        CLxUser_SceneService	svc;
        LXtItemType		locatorType = svc.ItemType (LXsITYPE_LOCATOR);
        unsigned		locatorCount;

        /*
         * Iterate over the scene items, starting from the root item, comparing
         * against the IDs of the items in the deformer, until we find the first
         * locator within the deformer that is closest to the root item of the scene.
         */
        locatorCount = scene.NItems (locatorType);
        for (unsigned locatorIndex = 0; locatorIndex < locatorCount; ++locatorIndex) {
                CLxUser_Item		testItem;
                scene.GetItem (locatorType, locatorIndex, testItem);
                const char	*ident;
                testItem.Ident (&ident);

                for (set<string>::const_iterator iter = nodeIDs->begin ();
                        iter != nodeIDs->end (); ++iter) {
                        string		nodeID = *iter;
                        if (nodeID == string(ident)) {
                                root.set (testItem);
                                foundRoot = true;
                                break;
                        }
                }
                if (foundRoot) {
                        break;
                }
        }

        return foundRoot;
}

        LxResult
DeformerWeightToVertexVisitor::EvaluateLocatorPass ()
{
        LxResult	result = LXe_FAILED;

        for (DeformerWeightArray::const_iterator iter = deformerWeightList.begin ();
                iter != deformerWeightList.end (); ++iter) {
                /* Get the indexed vertex influence within the group. */
                CLxLoc_Item	indexedDeformer;
                unsigned deformerIndex = iter->deformer;
                if (groupDeformer->GetDeformer (deformerIndex, indexedDeformer)) {
                        /* Get the locator referenced by the vertex influence. */
                        CLxUser_DeformerService	 deformerSvc;
                        CLxUser_Item		 locator;
                        bool			 isLocator;
                        if (deformerSvc.GetDeformerDeformationItem (
                                indexedDeformer, locator, isLocator)) {
                                if (isLocator) {
                                        // Insert the locator ID into
                                        // the set of unique IDs.
                                        nodeIDs->insert (locator.GetIdentity ());
                                }
                        }
                }
        }

        result = LXe_OK;

        return result;
}

        LxResult
DeformerWeightToVertexVisitor::EvaluateJointWeightPass ()
{
        LxResult	result = LXe_FAILED;

        result = LXe_OK;

        /* Store the number of bones for this point. */
        boneCounts.push_back (static_cast<unsigned>(deformerWeightList.size ()));

        /* Iterate over each pair. */
        for (DeformerWeightArray::const_iterator iter = deformerWeightList.begin ();
                iter != deformerWeightList.end (); ++iter) {
                /* Get the indexed vertex influence within the group. */
                CLxLoc_Item	indexedDeformer;
                unsigned deformerIndex = iter->deformer;
                if (groupDeformer->GetDeformer (deformerIndex, indexedDeformer)) {
                        /* Get the locator referenced by the vertex influence. */
                        CLxUser_DeformerService	 deformerSvc;
                        CLxUser_Item		 locator;
                        bool			 isLocator;
                        if (deformerSvc.GetDeformerDeformationItem (
                                indexedDeformer, locator, isLocator)) {
                                if (isLocator) {
                                        /* Get the node ID for the locator. */
                                        string locatorID = locator.GetIdentity ();

                                        /* Retrieve the index of the locator ID. */
                                        NodeIDIndexMap::const_iterator locatorIter =
                                                nodeIndexMap.find (locatorID);
                                        if (locatorIter != nodeIndexMap.end ()) {
                                                /* Push the locator (bone) index. */
                                                jointWeightIndices.push_back (
                                                        locatorIter->second);
                                        }

                                        /*
                                         * For now, we don't collapse duplicate
                                         * weights, to retain the same ordering
                                         * and indices across saves.
                                         *
                                         * [TODO] Control this with a COLLADA
                                         *        scene saver pref named
                                         *        "Merge Duplicate Skin Weights".
                                         */
                                        jointWeightIndices.push_back (
                                                static_cast<unsigned>(weights.size ()));
                                        weights.push_back (iter->weight);
                                }
                        }
                }
        }
        return result;
}

        int
DeformerWeightToVertexVisitor::ItemChanInt (
        CLxUser_Item		&item,
        const char		*channel)
{
        unsigned		 index;
        int			 value = 0;

        if (LXx_OK (item.ChannelLookup (channel, &index))) {
                setupChannels.Integer (item, index, &value);
        }

        return value;
}

        double
DeformerWeightToVertexVisitor::ItemChanFloat (
        CLxUser_Item		&item,
        const char		*channel)
{
        unsigned		 index;
        double			 value = 0.0;

        if (LXx_OK (item.ChannelLookup (channel, &index))) {
                setupChannels.Double (item, index, &value);
        }

        return value;
}

        void
DeformerWeightToVertexVisitor::ItemChanXform (
        CLxUser_Item		&item,
        const char		*channel,
        LXtVector		 vec)
{
        LxResult		 resultX, resultY, resultZ;
        unsigned		 indexX, indexY, indexZ;

        const char* CHANNEL_X = ".X";
        const char* CHANNEL_Y = ".Y";
        const char* CHANNEL_Z = ".Z";

        resultX = item.ChannelLookup (
                string(string(channel) + string(CHANNEL_X)).c_str (), &indexX);
        resultY = item.ChannelLookup (
                string(string(channel) + string(CHANNEL_Y)).c_str (), &indexY);
        resultZ = item.ChannelLookup (
                string(string(channel) + string(CHANNEL_Z)).c_str (), &indexZ);

        if (LXx_FAIL (resultX) || LXx_FAIL (resultY) || LXx_FAIL (resultZ)) {
                vec[0] = 0.0; vec[1] = 0.0; vec[2] = 0.0;
        }
        else {
                setupChannels.Double (item, indexX, &(vec[0]));
                setupChannels.Double (item, indexY, &(vec[1]));
                setupChannels.Double (item, indexZ, &(vec[2]));
        }
}

/*
 * Add a skin controller for the given mesh item and group deformer.
 */
        LxResult
COLLADASceneSaver::AddSkinController (
        SkinElement		&skin,
        CLxUser_Item		&meshItem,
        CLxUser_GroupDeformer	&groupDeformer,
        unsigned		 groupDeformerMeshIndex)
{
        LxResult		 result(LXe_OK);
        Matrix4			 meshNodeMatrix;

        // Get the item graph for transforms.
        CLxUser_Scene		 scene(SceneObject ());
        CLxUser_SceneGraph	 sceneGraph;
        scene.GetGraph (LXsGRAPH_XFRMCORE, sceneGraph);
        itemGraph.set (sceneGraph);

        // Setup a link to the mesh geometry that is being controlled.
        skin.SetSourceMeshURI (URI_Ref (GeometryID (ItemID (ItemIdentity ()))));

        // Populate the skin element, starting with the bind shape matrix.
        Matrix4Identity (meshNodeMatrix);	// [TODO] Get the local node matrix.
        skin.AddBindShapeMatrix (meshNodeMatrix);

        // Set up a visitor to iterate over the group deformer.
        DeformerWeightToVertexVisitor	visitor(
                meshItem, &groupDeformer, groupDeformerMeshIndex, &jointNodeIDs);

        /*
         * Gather the locators controlled by the group deformer, and
         * then determine which locator is the root locator.
         */
        visitor.FindLocators ();

        /*
         * Generate a map for quick access to the indices of nodes by their IDs.
         */
        unsigned		 index = 0;
        for (set<string>::const_iterator iter = jointNodeIDs.begin (); iter != jointNodeIDs.end (); ++iter) {
                visitor.nodeIndexMap[*iter] = index++;
        }

        /*
         * Visit the deformer/weight pairs for each point, and use the
         * locator array to generate the array of inverse bind matrices.
         */
        visitor.Enumerate ();

        // Add the joint source.
        SourceElement sourceJoints(skin, ATTRVALUE_JOINTS_SOURCE_NAME);
        StringArray	jointNameArray;
        for (set<string>::const_iterator jointIter = jointNodeIDs.begin ();
             jointIter != jointNodeIDs.end (); ++jointIter) {
                jointNameArray.push_back (NodeID (ItemID(*jointIter)));
        }
        sourceJoints.AddNameArray (PARAM_JOINT_NAME, jointNameArray);

        // Add the inverse bind matrices source.
        SourceElement sourceMatrices(skin, ATTRVALUE_MATRICES_SOURCE_NAME);
        sourceMatrices.AddMatrixArray (ATTRVALUE_FLOAT4X4, visitor.invBindMatrices);

        // Add the weights source.
        SourceElement sourceWeights(skin, ATTRVALUE_WEIGHTS_SOURCE_NAME);
        Element::FloatArray	weightArray;
        for (std::vector<float>::const_iterator weightIter = visitor.weights.begin ();
             weightIter != visitor.weights.end (); ++weightIter) {
                weightArray.push_back (*weightIter);
        }
        sourceWeights.AddFloatArray (ATTRVALUE_FLOAT, weightArray);

        // Add the joints binding element.
        JointsElement joints(skin);

        // Add the vertex weights input and indices table.
        VertexWeightsElement vertexWeights(skin, visitor.boneCounts, visitor.jointWeightIndices);

        /*
         * Release the item graph, since it's a class member variable
         * and we don't need it to hang around after this.
         */
        itemGraph.clear ();

        return result;
}

/*
 * Add the visual scene library element.
 */
        LxResult
COLLADASceneSaver::AddVisualSceneLibrary (COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding scene library.");

        VisualSceneLibraryElement visualSceneLibrary(collada);

        VisualSceneElement visualScene(
                visualSceneLibrary, ATTRVALUE_DEFAULTSCENEID);

#if defined(VISUAL_SCENE_ASSET)
        AddVisualSceneAsset (visualScene);
#endif

        CLxUser_Scene		 scene(SceneObject ());
        CLxUser_SceneGraph	 sceneGraph;
        scene.GetGraph (LXsGRAPH_XFRMCORE, sceneGraph);
        itemGraph.set (sceneGraph);

        if (prefs.SaveLights ()) {
                /*
                 * First, add the virtual ambient light node.
                 *
                 * (modo doesn't treat an ambient light as a separate item type.)
                 */
                AddAmbientLightItemNode (visualScene);
        }

        /*
         * Add the item nodes to the visual scene element, using a recursive
         * traversal that outputs a hierarchical transform tree.
         *
         * We use the default of "any" for the StartScan type name, and
         * selectively write out the items we know about.
         */
        StartScan ();
        while (NextItem ()) {
                CLxLoc_Item item;
                if (GetItem (item)) {
#if defined(COLLADASAVER_VERBOSE_LOGGING)
                        /*
                         * Enable this as needed, when we're ready
                         * to scan for more item types.
                         */
                        const char *itemType = ItemType ();
                        log.Info (string("Item #") + IntegerToString(curItem++) + string(", type: ") + string(itemType));
#endif
                        /*
                         * Check if the item has a parent.
                         */
                        LXtObjectID	parent = NULL;
                        if (item.Parent (reinterpret_cast<void**>(&parent)) == LXe_OK) {
                                /*
                                 * Skip non-root nodes.
                                 */
                                lx::ObjRelease (parent);
                                continue;
                        }

                        if ((ItemIsA (LXsITYPE_CAMERA) && prefs.SaveCameras ()) ||
                            ItemIsA (LXsITYPE_MESH) ||
                            ItemIsA (LXsITYPE_MESHINST) ||
                            (ItemIsA (LXsITYPE_GROUPLOCATOR) && prefs.SaveLocators ()) ||
                            (ItemIsA (LXsITYPE_LIGHT) && prefs.SaveLights ()) ||
                            (ItemIsA (LXsITYPE_LOCATOR) && prefs.SaveLocators ()) ||
                            ItemIsA (LXsITYPE_TEXTURELOC)) {
                                AddVisualSceneItem (visualScene);

                                /*
                                 * Restore the current item.
                                 */
                                SetItem (item);
                        }
                }
        }

        /*
         * Release the item graph, since it's a class member variable
         * and we don't need it to hang around after this.
         */
        itemGraph.clear ();

        if (ReallySaving ()) {
                if (prefs.SaveModoProfile ()) {
                        AddVisualScene_modo401 (visualScene);
                }

                if (prefs.SaveMax3DProfile ()) {
                        AddVisualScene_Max3D (visualScene);
                }

                if (prefs.SaveMayaProfile ()) {
                        AddVisualScene_Maya (visualScene);
                }

                if (prefs.SaveOkinoProfile ()) {
                        AddVisualScene_Okino (visualScene);
                }

                if (prefs.SaveXSIProfile ()) {
                        AddVisualScene_XSI (visualScene);
                }

                /*
                 * [TODO] Okino scene bounds.
                 */
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddVisualSceneAsset (
        VisualSceneElement	&visualScene)
{
        LxResult		 result(LXe_OK);

        AssetElement asset(visualScene);

        /*
         * Add the <created> element to the <asset> element.
         */
        result = AddAssetCreatedDateTime (asset);

        /*
         * Add the <modified> element to the <asset> element.
         */
        result = AddAssetModifiedDateTime (asset);

        /*
         * Add the scene up axis.
         */
        if (LXx_OK (result)) {
                int upAxis = GetUpAxis ();
                if (upAxis == LXiICVAL_SCENE_UPAXIS_X) {
                        asset.SetUpAxis (AssetElement::UP_AXIS_X);
                }
                else if (upAxis == LXiICVAL_SCENE_UPAXIS_Y) {
                        asset.SetUpAxis (AssetElement::UP_AXIS_Y);
                }
                else if (upAxis == LXiICVAL_SCENE_UPAXIS_Z) {
                        asset.SetUpAxis (AssetElement::UP_AXIS_Z);
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddVisualSceneItem (
        VisualSceneElement	&visualScene)
{
        LxResult		 result(LXe_OK);
#if 0
        AddItemNode (visualScene);
#else
        result = AddItemNode (visualScene.GetElement ());
#endif
        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddVisualScene_modo401 (
        VisualSceneElement	&visualScene)
{
        LxResult		 result(LXe_OK);

        VisualSceneElement_modo401	modoScene(visualScene);

        double	frameRate (GetFrameRate ());
        double	startTime(GetStartTime ());
        double	endTime(GetEndTime ());

        double	currentStartTime(GetCurrentStartTime ());
        double	currentEndTime(GetCurrentEndTime ());
        double	time(GetTime ());

        modoScene.SetFPS (frameRate);
        modoScene.SetStartEndTime (startTime, endTime);
        modoScene.SetCurrentStartEndTime (currentStartTime, currentEndTime);

        double drawSize(GetDefaultDrawSize ());

        /*
         * Set the time system.
         */
        string timeSystem = GetTimeSystem ();
        if (timeSystem == string(LXsICVAL_SCENE_TIMESYSTEM_SECONDS)) {
                modoScene.SetTimeSystem (TIME_SYSTEM_SECONDS);
        }
        else if (timeSystem == string(LXsICVAL_SCENE_TIMESYSTEM_FRAMES)) {
                modoScene.SetTimeSystem (TIME_SYSTEM_FRAMES);
        }
        else if (timeSystem == string(LXsICVAL_SCENE_TIMESYSTEM_SMPTE)) {
                modoScene.SetTimeSystem (TIME_SYSTEM_SMPTE);
        }
        else if (timeSystem == string(LXsICVAL_SCENE_TIMESYSTEM_FILMCODE)) {
                modoScene.SetTimeSystem (TIME_SYSTEM_FILMCODE);
        }

        LXxUNUSED (time);
        LXxUNUSED (drawSize);

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddVisualScene_Maya (
        VisualSceneElement	&visualScene)
{
        LxResult	result(LXe_OK);

        VisualSceneElement_Maya	mayaScene(visualScene);

        mayaScene.SetStartEndTime (GetStartTime (), GetEndTime ());

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddVisualScene_Max3D (
        VisualSceneElement	&visualScene)
{
        LxResult	result(LXe_OK);

        VisualSceneElement_3dsMax	maxScene(visualScene);

        maxScene.SetFrameRate (GetFrameRate ());

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddVisualScene_Okino (
        VisualSceneElement	&visualScene)
{
        LxResult	result(LXe_OK);

        VisualSceneElement_Okino	okinoScene(visualScene);

        /*
         * [TODO] Iterate over scene to discover its bounds.
         */

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddVisualScene_XSI (
        VisualSceneElement	&visualScene)
{
        LxResult	result(LXe_OK);

        VisualSceneElement_XSI	xsiScene(visualScene);

        xsiScene.SetFrameRate (GetFrameRate ());

        xsiScene.SetStartEndTime (GetStartTime (), GetEndTime ());

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddItemNode (
        VisualSceneElement	&visualScene)
{
        LxResult	result(LXe_OK);

        NodeElement	node(visualScene, GetItemNodeID (), ItemName ());

        return LOG_ERR (result);
}

        LxResult
COLLADASceneSaver::AddItemNode (
        NodeElement		&parentNode)
{
        LxResult	result(LXe_OK);

        NodeElement	node(parentNode, GetItemNodeID (), ItemName ());

        return LOG_ERR (result);
}

/*
 * Build an item node ID by appending the node suffix to the
 * type-specific item ID formed from the item name.
 */
        string
COLLADASceneSaver::GetItemNodeID () const
{
        /*
         * [TODO] Look these up using the param bind
         *        and the element type.
         */
        string	 itemID (ItemIdentity ());
        string	 nodeID(NodeID (ItemID (itemID)));
        if (ItemIsA (LXsITYPE_CAMERA)) {
                nodeID = CameraID (nodeID);
        }
        else if (ItemIsA (LXsITYPE_MESH)) {
                nodeID = GeometryID (nodeID);
        }
        else if (ItemIsA (LXsITYPE_LIGHT)) {
                nodeID = LightID (nodeID);
        }

        return nodeID;
}

/*
 * Add the virtual ambient light node.
 *
 * (modo doesn't treat an ambient light as a separate item type.)
 */
        LxResult
COLLADASceneSaver::AddAmbientLightItemNode (
        VisualSceneElement	&visualScene)
{
        LxResult		 result(LXe_OK);

        /*
         * Fetch the ambient light name.
         */
        StartScan (LXsITYPE_POLYRENDER);
        while (NextItem ()) {
                break;
        }

        /*
         * Add the render node to the visual scene.
         */
        NodeElement	renderNode(visualScene, ItemID (ItemIdentity ()), ItemName ());

        /*
         * Instance the ambient light.
         */
        InstanceLightElement	instanceLight (renderNode);

        return LOG_ERR (result);
}

#if defined(MODO_501)
        bool
COLLADASceneSaver::ItemVisibleForSave () const
#else
        bool
COLLADASceneSaver::ItemVisibleForSave ()
#endif
{
        bool		 saveItem(prefs.SaveHiddenItems ());

        /*
         * Only check visibility if the "Save Hidden Items"
         * preference option is turned off.
         */
        if (!saveItem) {
                saveItem = ItemVisible ();
        }

        return saveItem;
}

#if defined(MODO_501)
        bool
COLLADASceneSaver::ItemVisible () const
#else
        bool
COLLADASceneSaver::ItemVisible ()
#endif
{
#if defined(MODO_501)
        bool itemVisible = CLxSceneSaver::ItemVisible ();
#else
        bool	itemVisible = true;
        if (ItemIsA (LXsITYPE_LOCATOR)) {
                string locatorRender = GetTextHintEncodedChannelValue (
                        *this, LXsICHAN_LOCATOR_VISIBLE);
                itemVisible = (locatorRender != string(LXsICVAL_LOCATOR_STATE_OFF));
        }
        if (itemVisible) {
                /*
                 * Walk back up the item tree, to
                 * verify that none of the parent
                 * items have their visibility turned
                 * off.
                 */
                CLxUser_Item	lastItem;
                if (GetItem (lastItem)) {
                        CLxUser_Item	testItem;
                        GetItem (testItem);
                        CLxUser_Item	parentItem;
                        while (testItem.GetParent (parentItem)) {
                                SetItem (parentItem);
                                if (ItemIsA (LXsITYPE_LOCATOR)) {
                                        string locatorRender = GetTextHintEncodedChannelValue (
                                                *this, LXsICHAN_LOCATOR_VISIBLE);
                                        if (locatorRender == string(LXsICVAL_LOCATOR_STATE_OFF)) {
                                                itemVisible = false;
                                                break;
                                        }
                                }

                                testItem = parentItem;
                        }

                        SetItem (lastItem);
                }
        }
#endif
        return itemVisible;
}

typedef std::string				DeformationItemKey;
typedef std::map<DeformationItemKey, unsigned>	DeformationItemMap;

        bool
COLLADASceneSaver::FindGroupDeformer (
        CLxUser_Item		&meshItem,
        CLxUser_GroupDeformer	&groupDeformer,
        unsigned		&groupDeformerMeshIndex)
{
        bool			 found = false;
        CLxUser_DeformerService	 deformerSvc;
        CLxUser_Item		 deformer;
        
        const char		*ident1;
        meshItem.Ident (&ident1);

        CLxUser_Scene		 scene(SceneObject ());
        unsigned itemCount = scene.NItems (LXiTYPE_ANY);
        for (unsigned itemIndex = 0; itemIndex < itemCount; ++itemIndex) {
                CLxUser_Item		 testItem;
                CLxUser_Item		 otherMesh;
                const char		*ident2;

                if (scene.GetItem (LXiTYPE_ANY, itemIndex, testItem)) {
                        if (!deformerSvc.IsDeformer (testItem)) {
                                continue;
                        }

                        unsigned	meshCount = 0;
                        if (deformerSvc.MeshCount (testItem, &meshCount) != LXe_TRUE) {
                                continue;
                        }

                        for (unsigned meshIndex = 0; meshIndex < meshCount; ++meshIndex) {
                                if (deformerSvc.GetMesh (testItem, meshIndex, otherMesh)) {
                                        otherMesh.Ident (&ident2);
                                        if ((ident1 == ident2) &&
                                            deformer.set (testItem)) {
                                                groupDeformerMeshIndex = meshIndex;
                                                break;
                                        }
                                }
                        }

                        if (deformer.test ()) {
                                break;
                        }
                }
        }

        if (deformer.test ()) {
                // Get the group deformer object.
                CLxUser_ChannelRead	 chans;
                scene.GetChannels (chans, 0.0);

                if (deformerSvc.GetGroupDeformer (deformer, chans, groupDeformer)) {
                        unsigned	count = groupDeformer.DeformerCount ();
                        for (unsigned index = 0; index < count; ++index) {
                                CLxLoc_Item	indexedDeformer;
                                if (groupDeformer.GetDeformer (index, indexedDeformer)) {
                                        const char *deformerName;
                                        const char *deformerID;
                                        indexedDeformer.Name (&deformerName);
                                        indexedDeformer.Ident (&deformerID);

                                        bool	isLocator;
                                        CLxLoc_Item	locator;
                                        if (deformerSvc.GetDeformerDeformationItem (
                                            indexedDeformer, locator, isLocator)) {
                                                const char *locatorName;
                                                const char *locatorID;
                                                locator.Name (&locatorName);
                                                locator.Ident (&locatorID);

                                                /* Found at least one fully-wired deformer. */
                                                found = true;
                                                break;
                                        }
                                }
                        }
                }
        }

        return found;
}

/*
 * Find at least one controllable item.
 */
        bool
COLLADASceneSaver::FindControllableItems ()
{
        CLxUser_DeformerService	 deformerSvc;
        CLxUser_GroupDeformer	 groupDeformer;
        bool			 foundControllable = false;

        StartScan ();
        while (NextItem ()) {
                CLxUser_Item	 meshItem;
                if (ItemIsA (LXsITYPE_MESH) && GetItem (meshItem)) {
                        const char *meshName;
                        const char *meshID;
                        meshItem.Name (&meshName);
                        meshItem.Ident (&meshID);

                        CLxUser_GroupDeformer	 groupDeformer;
                        unsigned		 groupDeformerMeshIndex;

                        if (FindGroupDeformer (meshItem, groupDeformer, groupDeformerMeshIndex)) {
                                if (groupDeformer.test ()) {
                                        foundControllable = true;
                                        break;
                                }
                        }
                }
        }

        return foundControllable;
}

/*
 * Add an item node.
 */
        LxResult
COLLADASceneSaver::AddItemNode (ElementXML *parentNode)
{
        LxResult		 result(LXe_OK);
        string			 itemName(ItemName ());
        bool			 saveItem(ItemVisibleForSave ());

        /*
         * Skip saving a mesh instance if its source mesh is invisible.
         */
        if (saveItem && ItemIsA (LXsITYPE_MESHINST) &&
            !prefs.SaveHiddenItems ()) {
                /*
                 * Find the mesh that is referenced by the instance.
                 */
                CLxUser_SceneService	 service;
                CLxUser_Item		 meshInstItem;
                CLxUser_Item		 srcMeshItem;
                ILxItem1ID		 iMesh;
                if (GetItem (meshInstItem)) {
                        if (LXx_OK (service.GetMeshInstSourceItem (
                                (ILxUnknownID)meshInstItem, (void**)&iMesh))) {
                                SetItem ((ILxUnknownID)iMesh);
                                if (!ItemVisibleForSave ()) {
                                        saveItem = false;
                                }
                        }

                        /*
                         * Restore the current item back
                         * to the mesh instance item.
                         */
                        SetItem (meshInstItem);
                }
        }

        if (saveItem) {
                ElementXML *node;
                if (ReallySaving ()) {
                        node = io.AddElement (parentNode, ELEMENT_NODE);

                        io.SetID (node, GetItemNodeID ());
                        io.SetName (node, itemName);

                        CLxUser_Item	item;
                        GetItem (item);
                        if (jointNodeIDs.find (item.GetIdentity ()) != jointNodeIDs.end ()) {
                                // Add a scoped ID for the skeleton reference.
                                io.SetSID (node, GetItemNodeID ());

                                // Mark it as a joint (for the group deformer).
                                io.SetType (node, ATTRVALUE_JOINT);
                        }
                        else {
                                io.SetType (node, ATTRVALUE_NODE);
                        }
                }

                CLxUser_Item selectedItem;
                if (GetItem (selectedItem)) {
        #if defined(COLLADASAVER_VERBOSE_LOGGING)
                        LogItemChannels (selectedItem);
        #endif
                        if (ReallySaving ()) {
                                result = AddItemNodeTransforms (selectedItem, node);
                        }

                        SetItem (selectedItem);
                }

                /*
                 * Add the node type-specific instance reference.
                 */

                if (ItemIsA (LXsITYPE_CAMERA)) {
                        if (ReallySaving ()) {
                                /*
                                 * Instance the corresponding camera from the camera library.
                                 */
                                ElementXML *instance_camera = io.AddElement (node, ELEMENT_INSTANCE_CAMERA);
                                io.SetAttribute (instance_camera, ATTRIBUTE_URL,
                                        URI_Ref (CameraID (ItemID (ItemIdentity ()))));
                        }
                }
                else if ((ItemIsA (LXsITYPE_MESH) || ItemIsA (LXsITYPE_MESHINST)) &&
                        PointCount ()) {

                        /*
                         * Get ready to look at the mesh maps.
                         */
                        CLxUser_Mesh		 userMesh;
                        CLxUser_MeshMap		 meshMap;
                        bool			 haveMeshMap = false;
                        bool			 hasController(false);

                        if (ReallySaving ()) {
                                string meshItemID (ItemID (ItemIdentity ()));

                                if (ItemIsA (LXsITYPE_MESHINST)) {
                                        /*
                                         * Find the mesh that is referenced by the instance.
                                         */
                                        CLxUser_SceneService	 service;
                                        CLxUser_Item		 meshInstItem;
                                        CLxUser_Item		 srcMeshItem;
                                        ILxItem1ID		 iMesh;
                                        if (GetItem (meshInstItem)) {
                                                if (LXx_OK (service.GetMeshInstSourceItem (
                                                        (ILxUnknownID)meshInstItem, (void**)&iMesh))) {
                                                        SetItem ((ILxUnknownID)iMesh);
                                                        meshItemID = ItemID (ItemIdentity ());

                                                        /*
                                                         * Grab the mesh vertex maps.
                                                         */
                                                        haveMeshMap = ChanObject (
                                                                LXsICHAN_MESH_MESH, userMesh);
                                                        if (haveMeshMap) {
                                                                userMesh.GetMaps (meshMap);
                                                        }
                                                }

                                                /*
                                                 * Restore the current item back
                                                 * to the mesh instance item.
                                                 */
                                                SetItem (meshInstItem);
                                        }
                                }
                                else {
                                        /*
                                         * Grab the mesh vertex maps.
                                         */
                                        haveMeshMap = ChanObject (LXsICHAN_MESH_MESH, userMesh);
                                        if (haveMeshMap) {
                                                userMesh.GetMaps (meshMap);
                                        }
                                }
                                if (haveMeshMap) {
                                        meshMap.FilterByType (LXi_VMAP_TEXTUREUV);
                                        MeshMapVisitor uvVisitor(&meshMap);
                                        meshMap.Enum (&uvVisitor);
                                        if( GetPrefs().OrderVMapsAlphabetically() )
                                        {
                                                uvVisitor.SortMapNames ();
                                        }
                                        uvMapNames = uvVisitor.GetMapNames ();
                                }

                                /*
                                 * Test if the geometry item has a controller.
                                 */
                                CLxUser_Item		 nodeItem;
                                CLxUser_GroupDeformer	 groupDeformer;
                                unsigned		 groupDeformerMeshIndex;

                                GetItem (nodeItem);
                                if (FindGroupDeformer (nodeItem, groupDeformer, groupDeformerMeshIndex)) {
                                        if (groupDeformer.test ()) {
                                                DeformerWeightToVertexVisitor	visitor(
                                                        nodeItem, &groupDeformer,
                                                        groupDeformerMeshIndex,
                                                        &jointNodeIDs);

                                                visitor.FindLocators ();

                                                hasController = true;
                                        }
                                }

                                if (hasController) {
                                        /*
                                         * Instance the corresponding controller from the controller library.
                                         */
                                        instance_controller = io.AddElement (node, ELEMENT_INSTANCE_CONTROLLER);
                                        io.SetAttribute (
                                                instance_controller, ATTRIBUTE_URL,
                                                URI_Ref (ControllerID (meshItemID)));

                                        /*
                                         * Add skeleton elements to specify where to search for
                                         * the nodes that are referenced by the controller.
                                         */
                                        for (set<string>::const_iterator iter = jointNodeIDs.begin ();
                                                iter != jointNodeIDs.end (); ++iter) {
                                                CLxUser_Item	nodeItem;
                                                string		nodeID = *iter;

                                                ElementXML *skeleton = io.AddElement (
                                                        instance_controller, ELEMENT_SKELETON);
                                                io.SetElementValue (
                                                        skeleton,
                                                        URI_Ref (NodeID (ItemID (nodeID))));
                                        }
                                }
                                else {
                                        /*
                                         * Instance the corresponding geometry from the geometry library.
                                         */
                                        instance_geometry = io.AddElement (node, ELEMENT_INSTANCE_GEOMETRY);
                                        io.SetAttribute (
                                                instance_geometry, ATTRIBUTE_URL,
                                                URI_Ref (GeometryID (meshItemID)));
                                }
                        }

                        /*
                         * The first material will create a bind_material, so that we
                         * don't end up with an empty material instance for meshes
                         * with no assigned material.
                         */
                        bind_material = NULL;
                        material_technique_common = NULL;
                        VisitPolygons (POLYPASS_INSTANCEMATERIAL);
                        if (ReallySaving () && !meshMaterialTagSet.empty ()) {
                                /*
                                 * [TODO] Set an activeNode and stop
                                 *        using the io member variable.
                                 */
                                if (hasController) {
                                        bind_material = io.AddElement (
                                                instance_controller, ELEMENT_BIND_MATERIAL);
                                }
                                else {
                                        bind_material = io.AddElement (
                                                instance_geometry, ELEMENT_BIND_MATERIAL);
                                }
                                material_technique_common = io.AddElement (
                                        bind_material, ELEMENT_TECHNIQUE_COMMON);
                                for (MaterialSet::const_iterator iter = meshMaterialTagSet.begin ();
                                        iter != meshMaterialTagSet.end (); ++iter) {
                                        string polyMaterialTag = *iter;
                                        ElementXML *instance_material = io.AddElement (
                                                material_technique_common, ELEMENT_INSTANCE_MATERIAL);
                                        io.SetAttribute (
                                                instance_material,
                                                ATTRIBUTE_SYMBOL,
                                                MaterialSymbolicID (ItemID (polyMaterialTag)));
                                        io.SetAttribute (
                                                instance_material,
                                                ATTRIBUTE_TARGET,
                                                URI_Ref (MaterialID (ItemID (polyMaterialTag))));
                                        if (saveUVTextureCoordinates) {
                                                /*
                                                 * Look up the names of the UV maps
                                                 * associated with the textures of
                                                 * the common material for the effect.
                                                 */
                                                unsigned inputSet = 0;
                                                for (PolyTagTexCoord::const_iterator iter =
                                                     polyTagTexCoords.begin ();
                                                     iter != polyTagTexCoords.end ();
                                                     ++iter) {
                                                        if (iter->first == polyMaterialTag) {
                                                                ElementXML *bind_vertex =
                                                                        io.AddElement (
                                                                                instance_material,
                                                                                ELEMENT_BIND_VERTEX_INPUT);
                                                                io.SetAttribute (
                                                                        bind_vertex,
                                                                        ATTRIBUTE_SEMANTIC,
                                                                        EscapeNCName (iter->second));
                                                                io.SetAttribute (
                                                                        bind_vertex,
                                                                        ATTRIBUTE_INPUT_SEMANTIC,
                                                                        ATTRVALUE_TEXCOORD);

                                                                /*
                                                                 * [TODO] Detect when multiple UV-mapped
                                                                 *        materials share identical indices
                                                                 *        into their corresponding UV maps,
                                                                 *        and use input set indices to
                                                                 *        distinguish between logical
                                                                 *        UV map sets after the duplicate
                                                                 *        indices are collapsed into the
                                                                 *        same input offset.
                                                                 */

                                                                /*
                                                                 * Iterate over the list of the UV maps for the selected
                                                                 * mesh, and find the index of the UV map that matches the
                                                                 * name in iter->second (from the polyTagTexCoords list).
                                                                 */
                                                                inputSet = 0;
                                                                for (StringArray::const_iterator uvIter = uvMapNames.begin ();
                                                                        uvIter != uvMapNames.end (); ++uvIter) {
                                                                        /*
                                                                         * Select the texture coordinate set by name.
                                                                         */
                                                                        string uvMapName = *uvIter;
                                                                        if (iter->second == uvMapName) {
                                                                                io.SetAttribute (
                                                                                        bind_vertex,
                                                                                        ATTRIBUTE_INPUT_SET,
                                                                                        inputSet);
                                                                                break;
                                                                        }
                                                                        else {
                                                                                ++inputSet;
                                                                        }
                                                                }
                                                        }
                                                }
                                        }
                                }
                        }
                        meshMaterialTagSet.clear ();
                }
                else if (ItemIsA (LXsITYPE_LIGHT) && ReallySaving ()) {
                        /*
                         * Instance the corresponding light from the light library.
                         */
                        ElementXML *instance_light = io.AddElement (node, ELEMENT_INSTANCE_LIGHT);
                        io.SetAttribute (
                                instance_light, ATTRIBUTE_URL,
                                URI_Ref (LightID (ItemID (ItemIdentity ()))));
                }

                /*
                 * Add any sub-nodes.
                 */
                unsigned subItemCount;
                result = selectedItem.SubCount (&subItemCount);
                if (LXx_OK (result) && subItemCount) {
                        for (unsigned subItemIndex = 0;
                             subItemIndex < subItemCount; ++subItemIndex) {
                                LXtObjectID              subItemID;
                                result = selectedItem.SubByIndex (
                                        subItemIndex, (void **)&subItemID);
                                if (LXx_FAIL (result)) {
                                        continue;
                                }

                                /*
                                 * Recurse on the sub-items.
                                 */
                                if (SetItem (static_cast<ILxUnknownID>(subItemID))) {
        #if defined(COLLADASAVER_VERBOSE_LOGGING)
                                        log.Info (string("Sub-item type: ") + string(ItemType ()));
        #endif
                                        if ((ItemIsA (LXsITYPE_CAMERA) && prefs.SaveCameras ()) ||
                                            ItemIsA (LXsITYPE_MESH) ||
                                            ItemIsA (LXsITYPE_MESHINST) ||
                                            (ItemIsA (LXsITYPE_GROUPLOCATOR) && prefs.SaveLocators ()) ||
                                            (ItemIsA (LXsITYPE_LIGHT) && prefs.SaveLights ()) ||
                                            (ItemIsA (LXsITYPE_LOCATOR) && prefs.SaveLocators ()) ||
                                            ItemIsA (LXsITYPE_TEXTURELOC)) {
        #if defined(COLLADASAVER_VERBOSE_LOGGING)
                                                log.Info (
                                                        string("Recursing into SubItemIndex: ") +
                                                        IntegerToString(subItemIndex));
        #endif
                                                AddItemNode (node);
                                        }
                                }
                                SetItem (selectedItem);
                                lx::ObjRelease (subItemID);
                        }
                }

                /*
                 * If saving the modo profile, add our extra technique to the node,
                 * to map any pivots to their inverses.
                 */
                if (ReallySaving () &&
                    ShouldExportLayeredTransforms () &&
                    prefs.SaveModoProfile ()) {
                        ElementXML    *techniqueElem = NULL;
                        unsigned transformCount = itemGraph.Reverse (selectedItem);
                        for (unsigned transformIndex = 0;
                             transformIndex < transformCount; ++transformIndex) {
                                CLxUser_Item transform;
                                if (itemGraph.Reverse (selectedItem, transformIndex, transform)) {
                                        SetItem (transform);
                                        string	 transformID(ItemIdentity ());
                                        CLxUser_Scene		 scene(SceneObject ());
                                        CLxUser_SceneGraph	 sceneGraph;
                                        scene.GetGraph (LXsGRAPH_XFRMLOCAL, sceneGraph);
                                        CLxUser_ItemGraph localGraph;
                                        localGraph.set (sceneGraph);

                                        /*
                                         * Item-level type (scale, translate, rotate, transform).
                                         */
                                        const char *xformType = ItemType ();

                                        /*
                                         * Sub-type (core, pivot, pivot comp, etc.) 
                                         */
                                        string transformType = GetTextHintEncodedChannelValue (
                                                *this, LXsICHAN_TRANSFORM_TYPE);

                                        /*
                                         * Check for pivot and pivot compensation transforms.
                                         */
                                        if (string(xformType) == string(LXsITYPE_TRANSLATION)) {
                                                if (transformType == string(LXsICVAL_TRANSFORM_TYPE_PIVOT)) {
                                                        CLxUser_Item localTransform;
                                                        if (localGraph.Forward (transform, 0, localTransform)) {
                                                                if (!techniqueElem) {
                                                                        techniqueElem = AddExtraTechnique (node);
                                                                }

                                                                /*
                                                                 * Add a param element
                                                                 * for the pivot and
                                                                 * its inverse.
                                                                 */
                                                                SetItem (localTransform);
                                                                string	 localItemName (ItemIdentity ());
                                                                string	 localNodeID(ItemID (localItemName));
                                                                ElementXML *paramElem =
                                                                        io.AddElement (techniqueElem, ELEMENT_PARAM);
                                                                io.SetSID (paramElem, ItemID (transformID));
                                                                io.SetAttribute (
                                                                        paramElem,
                                                                        ATTRIBUTE_TYPE,
                                                                        ATTRVALUE_NAME);
                                                                io.SetAttribute (
                                                                        paramElem,
                                                                        ATTRIBUTE_SEMANTIC,
                                                                        LXsICVAL_TRANSFORM_TYPE_PIVOT);

                                                                /*
                                                                 * Link back to the source.
                                                                 */
                                                                io.SetElementValue (paramElem, localNodeID);
                                                        }
                                                }
                                                else if (transformType == string(LXsICVAL_TRANSFORM_TYPE_PIVOT_C)) {
                                                        if (!techniqueElem) {
                                                                techniqueElem = AddExtraTechnique (node);
                                                        }
                                                        ElementXML *paramElem =
                                                                io.AddElement (techniqueElem, ELEMENT_PARAM);
                                                        io.SetSID (paramElem, ItemID (transformID));
                                                        io.SetAttribute (
                                                                paramElem,
                                                                ATTRIBUTE_TYPE,
                                                                ATTRVALUE_NAME);
                                                        io.SetAttribute (
                                                                paramElem,
                                                                ATTRIBUTE_SEMANTIC,
                                                                LXsICVAL_TRANSFORM_TYPE_PIVOT_C);
                                                }
                                        }
                                        else if (string(xformType) == string(LXsITYPE_ROTATION)) {
                                                if (transformType == string(LXsICVAL_TRANSFORM_TYPE_PIVOT)) {
                                                }
                                                else if (transformType == string(LXsICVAL_TRANSFORM_TYPE_PIVOT_C)) {
                                                }
                                        }
                                        else if (string(xformType) == string(LXsITYPE_TRANSFORM)) {
                                                /*
                                                 * We walk the local graph to obtain
                                                 * the ID of the source pivot for which 
                                                 * this transform is the inverse.
                                                 *
                                                 * This also verifies that this transform
                                                 * is an inverse pivot, since our only
                                                 * example has its transform sub-type set
                                                 * to "none".
                                                 */
                                                CLxUser_Item localTransform;
                                                if (localGraph.Reverse (transform, 0, localTransform)) {
                                                        if (!techniqueElem) {
                                                                techniqueElem = AddExtraTechnique (node);
                                                        }

                                                        /*
                                                         * Add a param element for
                                                         * the pivot inverse and
                                                         * its source.
                                                         */
                                                        SetItem (localTransform);
                                                        string	 localItemID (ItemIdentity ());
                                                        string	 localNodeID(ItemID (localItemID));
                                                        ElementXML *paramElem =
                                                                io.AddElement (techniqueElem, ELEMENT_PARAM);
                                                        io.SetSID (paramElem, ItemID (transformID));
                                                        io.SetAttribute (
                                                                paramElem,
                                                                ATTRIBUTE_TYPE,
                                                                ATTRVALUE_NAME);
                                                        io.SetAttribute (
                                                                paramElem,
                                                                ATTRIBUTE_SEMANTIC,
                                                                LXsICVAL_TRANSFORM_TYPE_INVERSE);

                                                        /*
                                                         * Link back to the source.
                                                         */
                                                        io.SetElementValue (paramElem, localNodeID);
                                                }
                                        }
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

/*
 * Helper function to add an extra technique profile element.
 */
        ElementXML*
COLLADASceneSaver::AddExtraTechnique (
        ElementXML		*node)
{
        ElementXML *extraElem = io.AddElement (node, ELEMENT_EXTRA);
        ElementXML *techniqueElem = io.AddElement (extraElem, ELEMENT_TECHNIQUE);
        io.SetAttribute (techniqueElem, ATTRIBUTE_PROFILE, PROFILE_MODO401);

        return techniqueElem;
}

        LxResult
COLLADASceneSaver::AddItemNodeTransforms (
        CLxUser_Item		&selectedItem,
        ElementXML		*node)
{
        LxResult		 result(LXe_OK);

        /*
         * This block is used when transform layering is enabled, in which
         * case both the fixed and user-added transform channels are found
         * by iterating over the item graph.
         */
        if (ShouldExportLayeredTransforms ()) {
                unsigned transformCount = itemGraph.Reverse (selectedItem);
                for (unsigned transformIndex = 0;
                     transformIndex < transformCount; ++transformIndex) {
                        CLxUser_Item transform;
                        if (itemGraph.Reverse (selectedItem, transformIndex, transform)) {
                                SetItem (transform);

                                /*
                                 * Item-level type (scale, translate, rotate, transform).
                                 */
                                const char *xformType = ItemType ();
        #if defined(COLLADASAVER_VERBOSE_LOGGING)
                                log.Info (string("Transform item type: ") + string(xformType));
        #endif

                                /*
                                 * Sub-type (core, pivot, pivot comp, etc.) 
                                 */
                                string transformType = GetTextHintEncodedChannelValue (
                                        *this, LXsICHAN_TRANSFORM_TYPE);
        #if defined(COLLADASAVER_VERBOSE_LOGGING)
                                log.Info (string("Transform sub-type: ") + transformType);
        #endif

                                if (string(xformType) == string(LXsITYPE_SCALE)) {
                                        result = AddItemNodeScaleChannels (
                                                node, transform);
                                }
                                else if (string(xformType) == string(LXsITYPE_ROTATION)) {
                                        result = AddItemNodeRotationChannels (
                                                node, transform);
                                }
                                else if (string(xformType) == string(LXsITYPE_TRANSLATION)) {
                                        result = AddItemNodeTranslationChannels (
                                                node, transform);
                                }
                                else if (string(xformType) == string(LXsITYPE_TRANSFORM)) {
                                        result = AddItemNodeInverseChannel (node, transform);
                                }

                                /*
                                 * More diagnostic goodies.
                                 */
                                LXtItemType itemType = transform.Type ();
        #if defined(COLLADASAVER_VERBOSE_LOGGING)
                                log.Info (
                                        string ("Transform type: ") +
                                        IntegerToString(itemType));
                                LogItemChannels (transform);
        #endif

                                LXxUNUSED (itemType);
                        }
                }
        }
        else {
                /*
                 * Exporting layered transforms is switchable. We fall back to
                 * exporting a single baked matrix if the layered transform
                 * option is disabled, starting with the identity matrix for
                 * each node.
                 */
                Matrix4		m;
                Matrix4Identity (m);

                /*
                 * For the matrix case, we need to reverse iterate
                 * over the transform graph.
                 */
                unsigned transformCount = itemGraph.Reverse (selectedItem);
                for (unsigned transformIndex = 0;
                     transformIndex < transformCount; ++transformIndex) {
                        CLxUser_Item transform;
                        if (itemGraph.Reverse (selectedItem, transformIndex, transform)) {
                                SetItem (transform);

                                const char *xformType = ItemType ();
                                if (string(xformType) == string(LXsITYPE_SCALE)) {
                                        log.Info ("Transform is a scale.");
                                        LXtVector	scale;
                                        ChanXform (LXsICHAN_SCALE_SCL, scale);
                                        LXtMatrix4 sm;
                                        Matrix4CreateScale (sm, scale);
                                        Matrix4Compose (m, sm);
                                }
                                else if (string(xformType) == string(LXsITYPE_ROTATION)) {
                                        log.Info ("Transform is a rotation.");
                                        LXtVector rotate;
                                        ChanXform (LXsICHAN_ROTATION_ROT, rotate);

                                        /*
                                         * Take rotation order
                                         * into account.
                                         */
                                        int axis[3];
                                        BuildAxisOrder (
                                                ChanInt (LXsICHAN_ROTATION_ORDER),
                                                axis);

                                        LXtMatrix4 rm;
                                        Matrix4CreateRotation (
                                                rm, rotate[axis[0]], axis[0]);
                                        Matrix4Compose (m, rm);

                                        Matrix4CreateRotation (
                                                rm, rotate[axis[1]], axis[1]);
                                        Matrix4Compose (m, rm);

                                        Matrix4CreateRotation (
                                                rm, rotate[axis[2]], axis[2]);
                                        Matrix4Compose (m, rm);
                                }
                                else if (string(xformType) == string(LXsITYPE_TRANSLATION)) {
                                        log.Info ("Transform is a translation.");
                                        LXtVector	translate;
                                        ChanXform (LXsICHAN_TRANSLATION_POS, translate);
                                        LXtMatrix4 tm;
                                        Matrix4CreateTranslation (
                                                tm, translate);
                                        Matrix4Compose (m, tm);
                                }
                                else if (string(xformType) == string(LXsITYPE_TRANSFORM)) {
                                        LXtVector	translate = {0, 0, 0};

                                        /*
                                         * Walk the local graph and find the translate item for
                                         * which this transform is the inverse.
                                         */
                                        CLxUser_Scene		 scene(SceneObject ());
                                        CLxUser_SceneGraph	 sceneGraph;
                                        scene.GetGraph (LXsGRAPH_XFRMLOCAL, sceneGraph);
                                        CLxUser_ItemGraph localGraph;
                                        localGraph.set (sceneGraph);
                                        CLxUser_Item localTransform;
                                        if (localGraph.Reverse (transform, 0, localTransform)) {
                                                /*
                                                 * Fetch the translation vector and negate it.
                                                 */
                                                SetItem (localTransform);
                                                if (ItemType () == string(LXsITYPE_TRANSLATION)) {
                                                        ChanXform (LXsICHAN_TRANSLATION_POS, translate);
                                                        translate[0] = -translate[0];
                                                        translate[1] = -translate[1];
                                                        translate[2] = -translate[2];

                                                        /*
                                                         * And bake it in...
                                                         */
                                                        LXtMatrix4 tm;
                                                        Matrix4CreateTranslation (
                                                                tm, translate);
                                                        Matrix4Compose (m, tm);
                                                }
                                        }
                                }

                                /*
                                 * More diagnostic goodies.
                                 */
                                LXtItemType itemType = transform.Type ();
        #if defined(COLLADASAVER_VERBOSE_LOGGING)
                                log.Info (
                                        string ("Transform type: ") +
                                        IntegerToString(itemType));
                                LogItemChannels (transform);
        #endif

                                LXxUNUSED (itemType);
                        }
                }

                /*
                 * Write out a single baked matrix.
                 */
                ElementXML *matrixElem =
                        io.AddElement (node, ELEMENT_MATRIX);
                io.SetSID (matrixElem, ATTRVALUE_MATRIX_SID);
                io.SetElementValue (matrixElem, m);
        }


        return LOG_ERR (result);
}

/*
 * Add item node translation channels.
 */
        LxResult
COLLADASceneSaver::AddItemNodeTranslationChannels (
        ElementXML		*node,
        CLxUser_Item		&transformItem)
{
        LxResult		 result(LXe_OK);
        string			 transformID(ItemIdentity ());

        LXtVector	translate;
        ChanXform (LXsICHAN_TRANSLATION_POS, translate);

        ElementXML *translateElem = io.InsertFirstElement (node, ELEMENT_TRANSLATE);
        io.SetSID (translateElem, ItemID (transformID));
        io.SetElementValue (translateElem, translate);

        return LOG_ERR (result);
}

/*
 * Adds a rotation XML element from the given transformID, euler rotation order (order) and euler rotation values (rotate).
 * The output xml should look something like this.
 *
 * <rotate sid="[transformID]X">1 0 0 <<[rotate[0]]>></rotate>
 * <rotate sid="[transformID]Y">0 1 0 <<[rotate[1]]>></rotate>
 * <rotate sid="[transformID]Z">0 0 1 <<[rotate[2]]>></rotate>
 *
 * The order of the elements will depend on the rotation order.
 * The rotation order for the above example is XYZ.
 *
 */
void
COLLADASceneSaver::AddRotationElement (
        ElementXML		*node,
        const string &	transformID,
        int		order,
        const LXtVector	& rotate)
{
        ElementXML *rotateXelem;
        ElementXML *rotateYelem;
        ElementXML *rotateZelem;
        switch (order) {
                case ROTATION_ORDER_XZY:
                        rotateXelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateZelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateYelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        break;

                case ROTATION_ORDER_YXZ:
                        rotateYelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateXelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateZelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        break;

                case ROTATION_ORDER_YZX:
                        rotateYelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateZelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateXelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        break;

                case ROTATION_ORDER_ZXY:
                        rotateZelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateXelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateYelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        break;

                case ROTATION_ORDER_ZYX:
                        rotateZelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateYelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateXelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        break;

                case ROTATION_ORDER_XYZ:
                default: {
                        rotateXelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateYelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        rotateZelem = io.InsertFirstElement (
                                node, ELEMENT_ROTATE);
                        break;
                }
        }

        io.SetSID (rotateXelem, ItemID (transformID) + string(ATTRVALUE_X));
        io.SetElementValue (rotateXelem,
                string(VALUE_ROTATE_X_AXIS) + DoubleToString (rotate[0]));

        io.SetSID (rotateYelem, ItemID (transformID) + string(ATTRVALUE_Y));
        io.SetElementValue (rotateYelem,
                string(VALUE_ROTATE_Y_AXIS) + DoubleToString (rotate[1]));

        io.SetSID (rotateZelem, ItemID (transformID) + string(ATTRVALUE_Z));
        io.SetElementValue (rotateZelem,
                string(VALUE_ROTATE_Z_AXIS) + DoubleToString (rotate[2]));
}

/*
 * Add item node rotation channels.
 */
        LxResult
COLLADASceneSaver::AddItemNodeRotationChannels (
        ElementXML		*node,
        CLxUser_Item		&transformItem)
{
        string			 transformID(ItemIdentity ());

        LXtVector rotate;
        ChanXform (LXsICHAN_ROTATION_ROT, rotate);
        rotate[0] *= RAD2DEG;
        rotate[1] *= RAD2DEG;
        rotate[2] *= RAD2DEG;

        int order = ChanInt (LXsICHAN_ROTATION_ORDER);

        AddRotationElement(node, transformID, order, rotate);

        return LOG_ERR (LXe_OK);
}

/*
 * Add item node scale channels.
 */
        LxResult
COLLADASceneSaver::AddItemNodeScaleChannels (
        ElementXML		*node,
        CLxUser_Item		&transformItem)
{
        LxResult		 result(LXe_OK);
        string			 transformID(ItemIdentity ());

        LXtVector	scale;
        ChanXform (LXsICHAN_SCALE_SCL, scale);

        ElementXML *scaleElem = io.InsertFirstElement (node, ELEMENT_SCALE);
        io.SetAttribute (scaleElem, ATTRIBUTE_SID, ItemID (transformID));
        io.SetElementValue (scaleElem, scale);

        return LOG_ERR (result);
}

/*
 * Add item node inverse channel.
 */
        LxResult
COLLADASceneSaver::AddItemNodeInverseChannel (
        ElementXML		*node,
        CLxUser_Item		&transformItem)
{
        LxResult		 result(LXe_OK);
        string			 transformID(ItemIdentity ());

        /*
         * Walk the local graph and find the translate item for
         * which this transform is the inverse.
         */
        CLxUser_Scene		 scene(SceneObject ());
        CLxUser_SceneGraph	 sceneGraph;
        scene.GetGraph (LXsGRAPH_XFRMLOCAL, sceneGraph);
        CLxUser_ItemGraph localGraph;
        localGraph.set (sceneGraph);
        CLxUser_Item localTransform;
        if (localGraph.Reverse (transformItem, 0, localTransform)) {
                /*
                 * Fetch the translation vector and negate it.
                 */
                SetItem (localTransform);
                if (ItemType () == string(LXsITYPE_TRANSLATION)) {
                        LXtVector	translate = {0, 0, 0};
                        ChanXform (LXsICHAN_TRANSLATION_POS, translate);
                        translate[0] = -translate[0];
                        translate[1] = -translate[1];
                        translate[2] = -translate[2];

                        ElementXML *translateElem = io.InsertFirstElement (node, ELEMENT_TRANSLATE);
                        io.SetSID (translateElem, ItemID (transformID));
                        io.SetElementValue (translateElem, translate);

                        return LOG_ERR (result);
                }
                /*
                 * Fetch the rotation angles, convert them to radians and negate them.
                */
                else if(ItemType () == string(LXsITYPE_ROTATION))
                {
                        LXtVector	rotate;
                        ChanXform (LXsICHAN_ROTATION_ROT, rotate);
                        rotate[0] *= -RAD2DEG;
                        rotate[1] *= -RAD2DEG;
                        rotate[2] *= -RAD2DEG;

                        int order = ChanInt (LXsICHAN_ROTATION_ORDER);

                        AddRotationElement(node, transformID, order, rotate);

                        return LOG_ERR (result);
                }
        }

        /*
         * If an upstream rotation or translation cannot be found
         * then assume translation and store zero values.
        */
        LXtVector	translate = {0, 0, 0};
        ElementXML *translateElem = io.InsertFirstElement (node, ELEMENT_TRANSLATE);
        io.SetSID (translateElem, ItemID (transformID));
        io.SetElementValue (translateElem, translate);

        return LOG_ERR (result);
}

        void
COLLADASceneSaver::LogItemChannels (CLxUser_Item &item)
{
        /*
         * Test code to iterate over available channels.
         */
        unsigned channelCount = item.NChannels ();
        for (unsigned channelIndex = 0;
             channelIndex < channelCount; ++channelIndex) {
                const char *channelName;
                item.ChannelName (channelIndex, &channelName);
                if (channelName) {
                        log.Info (
                                string("Channel name: ") +
                                string(channelName));
                }
                unsigned channelType;
                if (LXx_OK (item.ChannelType (
                        channelIndex, &channelType))) {
                        log.Info (
                                string("Channel type: ") +
                                IntegerToString(channelType));
                        const char *storageType;
                        if (LXx_OK(item.ChannelStorageType (
                                channelIndex, &storageType))) {
                                log.Info (
                                        string("Storage type: ") +
                                        string(storageType));
                        }
                }
        }
}

/*
 * Add the scene element, to instantiate the scene from the visual scene library.
 */
        LxResult
COLLADASceneSaver::AddScene (COLLADAElement &collada)
{
        LxResult		 result(LXe_OK);

        log.Info ("Adding scene element.");

        SceneElement scene(collada, ATTRVALUE_DEFAULTSCENEID);

        return LOG_ERR (result);
}

        void
COLLADASceneSaver::ClearContainers ()
{
        saveAnimation = SAVE_ANIMATION;
        haveAtLeastOneAnimation = false;
        haveAtLeastOneCamera = false;
        haveAtLeastOneCameraAnimation = false;
        haveAtLeastOneLightAnimation = false;
        haveAtLeastOneEffect = false;
        haveAtLeastOneImage = false;
        haveAtLeastOneMaterial = false;
        haveAtLeastOneMesh = false;
        haveAtLeastOneMeshAnimation = false;
        pointIndex = 0;
        normalIndex = 0;
        texcoordIndex = 0;
        texcoordSet = 0;
        polyCount = 0;
        polyPass = POLYPASS_BUILDMATERIALSET;
        activeMesh = NULL;
        sourceNormals = NULL;
        instance_geometry = NULL;
        bind_material = NULL;
        haveAtLeastOneController = false;
        haveAtLeastOneItem = false;
        haveAtLeastOneTransformAnimation = false;

        materialTagSet.clear ();
        imageMapFiles.clear ();
}

        void
COLLADASceneSaver::ss_Verify()
{
        // Warn about static meshes.
        StartScan (LXsITYPE_TRISURF);
        if( NextItem() ) {
                Message("common", 2020);
                MessageArg(1, "COLLADA export does not support static meshes.");
        }
}

/*
 *
 */
        LxResult
COLLADASceneSaver::ss_Save ()
{
        LxResult		 result(LXe_OK);

        typedef enum en_COLLADA_SAVE_EXCEPTION
        {
                COLLADA_SAVE_ASSET_FAILED,
                COLLADA_SAVE_ANIMATION_LIBRARY_FAILED
        } COLLADA_SAVE_EXCEPTION;

        try {
                /*
                 * Setup the message logging system.
                 */
                log.Setup ();

                saveVertexNormals = prefs.SaveVertexNormals ();
                saveUVTextureCoordinates = prefs.SaveUVTextureCoordinates ();
                saveColors = prefs.SaveVertexColors ();
                saveWeights = prefs.SaveWeights ();

                /*
                 * Build the set of materials for
                 * later reference.
                 */
                result = BuildMaterialSet ();

                /*
                 * Determine if we have at least one interesting item type.
                 */
                haveAtLeastOneItem = FindItemTypes ();

                /*
                 * ss_Save is called twice.
                 *
                 * The first pass tallies up the number of s,
                 * and the second pass then writes out the file.
                 *
                 * We check the return value of ReallySaving to determine if
                 * this call is the tally pass.
                 */
                IO_MODE	ioMode = ReallySaving () ?
                        IO_MODE_SAVE : IO_MODE_TALLY;
                File			file(ioMode);
                COLLADAElement	collada(ioMode,
                                                prefs.FormattedArrays ());
                if (file.OpenDocument (file_name, collada)) {
                        if (ReallySaving ()) {
                                /*
                                 * Add the <asset> element to the root COLLADA element.
                                 */
                                if (LXx_FAIL (AddAsset (collada))) {
                                        throw COLLADA_SAVE_ASSET_FAILED;
                                }
                        }

                        if (haveAtLeastOneItem) {
                                /*
                                 * If there's at least one animation,
                                 * add an animation library.
                                 */
                                if (haveAtLeastOneAnimation &&
                                    LXx_FAIL (AddAnimationLibrary (collada))) {
                                        throw COLLADA_SAVE_ANIMATION_LIBRARY_FAILED;
                                }

                                /*
                                 * If the item list has at least one camera,
                                 * add a camera library.
                                 */
                                if (haveAtLeastOneCamera && prefs.SaveCameras ()) {
                                        result = AddCameraLibrary (collada);
                                }

                                /*
                                 * The effect and image libraries rely
                                 * upon a pre-built list of loaded images.
                                 */
                                BuildImageFilePathList ();

                                if (ReallySaving ()) {
                                        /*
                                         * If the item list has at least one image,
                                         * add an image library.
                                         */
                                        if (haveAtLeastOneImage) {
                                                AddImageLibrary (collada);
                                        }

                                        /*
                                         * If the item list has at least one material,
                                         * add a material library.
                                         */
                                        if (haveAtLeastOneMaterial) {
                                                AddMaterialLibrary (collada);
                                        }
                                }

                                if (ReallySaving ()) {
                                        /*
                                         * If the item list has at least one effect,
                                         * add an effect library.
                                         */
                                        if (haveAtLeastOneEffect) {
                                                AddEffectLibrary (collada);
                                        }
                                }

                                /*
                                 * If there's at least one mesh,
                                 * add a geometry library.
                                 */
                                if (haveAtLeastOneMesh) {
                                        result = AddGeometryLibrary (collada);
                                }

                                if (prefs.SaveLights ()) {
                                        /*
                                         * We always have an ambient light, so
                                         * we can always add a light library,
                                         * as long as the light item type is
                                         * enabled by the "Save Lights" pref.
                                         */
                                        result = AddLightLibrary (collada);
                                }

                                if (ReallySaving ()) {
                                        /*
                                         * If saving the modo profile is
                                         * enabled, add a shader node library.
                                         */
                                        if (prefs.SaveModoProfile ()) {
                                                AddShaderNodeLibrary (collada);
                                        }

                                        if (haveAtLeastOneController) {
                                                result = AddControllerLibrary (collada);
                                        }

                                        /*
                                         * Add the visual scene library element.
                                         */
                                        result = AddVisualSceneLibrary (collada);

                                        /*
                                         * Add the scene element.
                                         */
                                        result = AddScene (collada);
                                }
                        }

                        /*
                         * Write the document.
                         */
                        if (ReallySaving () && !file.SaveDocument (file_name)) {
                                result = LXe_FAILED;
                                log.Info ("SaveDocument failed.");
                        }
                }
        }
        catch (COLLADA_SAVE_EXCEPTION saveException) {
                string	errorMsg("Unknown.");

                switch (saveException) {
                        case COLLADA_SAVE_ASSET_FAILED:
                                errorMsg = string("Save Asset failed.");
                                break;

                        case COLLADA_SAVE_ANIMATION_LIBRARY_FAILED:
                                errorMsg = string("Save Animation Library failed.");
                                break;
                }
                log.Error (errorMsg);

                /*
                 * Force a failure result code, in case no one set it.
                 */
                if (LXx_OK (result)) {
                        result = LXe_FAILED;
                }
        }
        catch (LxResult rc) {
                string errMsg("Saver failed with error: ");
                log.Error (errMsg, rc);
        }
        catch (...) {
                /*
                 * Make sure error doesn't take down the host.
                 */
                log.Error (
                        "Saver failed with unknown error.");

                /*
                 * Force a failure result code, in case no one set it.
                 */
                if (LXx_OK (result)) {
                        result = LXe_FAILED;
                }
        }

        if (LXx_OK (result)) {
                log.Info ("Scene saved successfully.");
        }

        ClearContainers ();

        return LOG_ERR (result);
}

/*
 * A point visitor.
 */
        void
COLLADASceneSaver::ss_Point ()
{
        pointMap[PntID ()] = pointIndex++;

        double	position[3];
        PntPosition (position);

        points.push_back (static_cast<float>(position[0]));
        points.push_back (static_cast<float>(position[1]));
        points.push_back (static_cast<float>(position[2]));
}

/*
 * A polygon visitor.
 */
        void
COLLADASceneSaver::ss_Polygon ()
{
        unsigned vertIndex, vertCount;

        switch (polyPass) {
                case POLYPASS_NORMALS:
                        vertCount = PolyNumVerts ();
                        for (vertIndex = 0; vertIndex < vertCount; ++vertIndex) {
                                /*
                                 * Add vertex normals to the normals and normalMap.
                                 */
                                AddVertexNormal (vertIndex);
                        }
                        break;

                case POLYPASS_UVS:
                        vertCount = PolyNumVerts ();
                        for (vertIndex = 0; vertIndex < vertCount; ++vertIndex) {
                                /*
                                 * Save selected texcoord set to active texcoordArray.
                                 */
                                AddVertexTexture (vertIndex);
                        }
                        break;

                /*
                 * [TODO] Split up POLYPASS_RGB_COLORS into two stages (first
                 *        stage could be POLYPASS_COLORTALLY?), so we can
                 *        first verify that a complete color set is available
                 *        before committing to writing it out.
                 */
                case POLYPASS_RGB_COLORS:
                case POLYPASS_RGBA_COLORS:
                        vertCount = PolyNumVerts ();
                        for (vertIndex = 0; vertIndex < vertCount; ++vertIndex) {
                                /*
                                 * Save selected color set to active colorArray.
                                 */
                                AddVertexColor (vertIndex,
                                        (polyPass == POLYPASS_RGBA_COLORS));
                        }
                        break;

                case POLYPASS_WEIGHTS:
                        vertCount = PolyNumVerts ();
                        for (vertIndex = 0; vertIndex < vertCount; ++vertIndex) {
                                /*
                                 * Save selected weight set to active weightArray.
                                 */
                                AddVertexWeight (vertIndex);
                        }
                        break;

                case POLYPASS_POLYGONS:
                        /*
                         * Add the polygon to the polygons array.
                         */
                        AddPolygon ();
                        break;

                case POLYPASS_BUILDMATERIALSET: {
                        string polyMaterialTag(PolyTag (LXi_PTAG_MATR));
                        if ((!polyMaterialTag.empty ()) &&
                            (polyMaterialTag != materialTag)) {
                                materialTag = polyMaterialTag;

                                materialTagSet.insert (polyMaterialTag);
                        }
                        break;
                }

                /*
                 * Clients should add the instance_geometry and clear out
                 * the bind_material element prior to visiting.
                 *
                 * [TODO] This is error-prone, so we need a more reliable way
                 *        to be self-aware of the first iteration, such as
                 *        a "FirstPolygon" bool test API.
                 */
                case POLYPASS_INSTANCEMATERIAL: {
                        /*
                         * [TODO] PolyTag is returning a tag for a "Default"
                         *        material even when all of the materials
                         *        have been deleted from the Shader Tree.
                         *        Add code to detect this condition, so we
                         *        don't add a binding to a ghost material.
                         */
                        string polyMaterialTag(PolyTag (LXi_PTAG_MATR));
                        if ((!polyMaterialTag.empty ()) &&
                            (polyMaterialTag != materialTag)) {
                                materialTag = polyMaterialTag;
                                meshMaterialTagSet.insert (polyMaterialTag);
                        }
                        break;
                }
        }
}

        void
COLLADASceneSaver::ff_Cleanup    ()
{
        ClearContainers ();

        CLxLineFormat::ff_Cleanup ();
}

