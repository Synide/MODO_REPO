/*
 * CLUSTER.CPP		Locator Item Influence
 *
 *	Copyright (c) 2008-2015 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_item.hpp>
#include <lx_group.hpp>
#include <lx_package.hpp>
#include <lx_schematic.hpp>
#include <lx_listener.hpp>
#include <lx_plugin.hpp>
#include <lx_action.hpp>
#include <lx_visitor.hpp>
#include <lx_value.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxidef.h>
#include <string>
#include <vector>
#include <map>
#include <math.h>

        namespace Influence_Items {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		LXsITYPE_ITEMINFLUENCE
#define SRVNAME_MODIFIER		LXsITYPE_ITEMINFLUENCE
#define SRVNAME_CONNECTION		LXsITYPE_ITEMINFLUENCE
#define SPNNAME_INSTANCE		"itemInfl.inst"
#define SPWNAME_INFLUENCE		"locItemInfl.infl"

#define INTERPi_LOCAL		 0
#define INTERPi_LINEAR		 1

static LXtTextValueHint hint_Interp[] = {
        INTERPi_LOCAL,		LXsICVAL_ITEMINFLUENCE_INTERPOLATION_LOCAL,
        INTERPi_LINEAR,		LXsICVAL_ITEMINFLUENCE_INTERPOLATION_LINEAR,
        -1,			"=weight-interpolation-type",
        -1,			 0
};

static CLxItemType		 cit_iteminf (LXsITYPE_ITEMINFLUENCE);
static CLxItemType		 cit_locator (LXsITYPE_LOCATOR);


/*
 * ----------------------------------------------------------------
 * Source List
 *
 * This is a list of the locator items in the group which are used
 * to compose the influence.
 */
class CSourceElt {
    public:
        const char		*id;
        LXtVector		 pos;
};

typedef std::vector<CSourceElt>::iterator	 SourceList_Itr;

class CSourceList :
                public std::vector<CSourceElt>,
                public CLxImpl_AbstractVisitor
{
    public:
        CLxUser_Scene		 m_scene;

        CLxUser_GroupEnumerator	 gr_enum;
        CLxUser_Item		 cur_item;

        /*
         * Build the list of target items from an item influence. We want to find all
         * the forward-linked items, and traverse any that are groups.
         */
                void
        Build (
                ILxUnknownID		 item)
        {
                CLxUser_Item		 source (item), target;
                CLxUser_GroupItem	 grp;
                CLxUser_ItemGraph	 graph;
                unsigned		 i, n;

                clear ();
                m_scene.from (source);
                graph.from (m_scene, LXsGRAPH_DEFORMERS);

                n = graph.Forward (source);
                for (i = 0; i < n; i++) {
                        graph.Forward (source, i, target);
                        if (AddItem (target))
                                continue;

                        if (grp.set (target) && grp.GetEnumerator (gr_enum))
                                gr_enum.Enum (this, LXfGRPTYPE_ITEM);
                }

                gr_enum.clear ();
        }

                bool
        AddItem (
                CLxUser_Item		&item)
        {
                CSourceElt		 elt;

                if (!item.IsA (cit_locator))
                        return false;

                item.Ident (&elt.id);
                push_back (elt);
                return true;
        }

                LxResult
        Evaluate ()
        {
                CLxUser_Item		 item;

                gr_enum.GetItem (item);
                AddItem (item);
                return LXe_OK;
        }

        /*
         * Compare this list to another one. If the elements aren't exactly the same
         * we return false. (How come "vector" doesn't have this method?)
         */
                bool
        Compare (
                CSourceList		&that)
        {
                SourceList_Itr		 sli1, sli2;

                sli1 = begin ();
                sli2 = that.begin ();

                while (sli1 != end () && sli2 != that.end ()) {
                        if (sli1->id != sli2->id)
                                return false;

                        sli1++;
                        sli2++;
                }

                return (sli1 == end () && sli2 == that.end ());
        }

        /*
         * Enumeration walks the item list, and may be called from a couple places.
         */
                LxResult
        Enumerate (
                ILxUnknownID		 visitor)
        {
                CLxUser_Visitor		 vis (visitor);
                SourceList_Itr		 sli;
                LxResult		 rc;

                rc = LXe_OK;
                for (sli = begin (); sli != end (); sli++) {
                        if (!m_scene.GetItem (sli->id, cur_item))
                                rc = LXe_FAILED;
                        else
                                rc = vis.Evaluate ();

                        if (rc != LXe_OK)
                                break;
                }

                cur_item.clear ();
                return rc;
        }

                LxResult
        GetItem (
                void		       **ppvObj)
        {
                if (!cur_item.test ())
                        return LXe_NOACCESS;

                ppvObj[0] = lx::UnkAddRef (cur_item);
                return LXe_OK;
        }
};


/*
 * ----------------------------------------------------------------
 * Item Instance
 *
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_ItemInfluence
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CInstance>;
                srv->AddInterface (new CLxIfc_PackageInstance<CInstance>);
                srv->AddInterface (new CLxIfc_ItemInfluence  <CInstance>);
                lx::AddSpawner (SPNNAME_INSTANCE, srv);
        }

        CSourceList	*enum_list;
        CLxUser_Item	 m_item;

        CInstance () : enum_list (0) {}

                LxResult
        pins_Initialize (
                ILxUnknownID		 item,
                ILxUnknownID		 super)
                                                        LXx_OVERRIDE
        {
                m_item.set (item);
                return LXe_OK;
        }

                void
        pins_Cleanup (void)
                                                        LXx_OVERRIDE
        {
                m_item.clear ();
        }

        /*
         * The item influence interface on the item itself is used by the system
         * to find out what items this deformer wants to affect. It duplicates the
         * functionality of the deformer itself using a temp source list.
         */
                LxResult
        iinf_HasItems ()
                                                        LXx_OVERRIDE
        {
                CSourceList		 tmp;

                tmp.Build (m_item);
                return (tmp.empty () ? LXe_FALSE : LXe_TRUE);
        }

                LxResult
        iinf_Enumerate (
                ILxUnknownID		 visitor)
                                                        LXx_OVERRIDE
        {
                CSourceList		 tmp;
                LxResult		 rc;

                enum_list = &tmp;
                tmp.Build (m_item);
                rc = tmp.Enumerate (visitor);
                enum_list = 0;
                return rc;
        }

                LxResult
        iinf_GetItem (
                void		       **ppvObj)
                                                        LXx_OVERRIDE
        {
                if (!enum_list)
                        return LXe_NOACCESS;

                return enum_list->GetItem (ppvObj);
        }
};


/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
class CPackage :
                public CLxImpl_Package
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CPackage>;
                srv->AddInterface (new CLxIfc_Package   <CPackage>);
                srv->AddInterface (new CLxIfc_StaticDesc<CPackage>);
                thisModule.AddServer (SRVNAME_ITEMTYPE, srv);
        }

        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 spawn;

        CPackage () : spawn (SPNNAME_INSTANCE) {}

        /*
         * The package has a set of standard channels with default values. These
         * are setup at the start using the AddChannel interface.
         */
                LxResult
        pkg_SetupChannels (
                ILxUnknownID		 addChan)
                                                        LXx_OVERRIDE
        {
                CLxUser_AddChannel	 ac (addChan);

                ac.NewChannel  (LXsICHAN_ITEMINFLUENCE_ITEMINF,		LXsTYPE_OBJREF);
                ac.SetInternal ();

                ac.NewChannel  (LXsICHAN_ITEMINFLUENCE_ENABLE,		LXsTYPE_BOOLEAN);
                ac.SetDefault  (0.0, 1);

                ac.NewChannel  (LXsICHAN_ITEMINFLUENCE_INTERPOLATION,	LXsTYPE_INTEGER);
                ac.SetDefault  (0.0, INTERPi_LOCAL);
                ac.SetHint     (hint_Interp);

                ac.NewChannel  (LXsICHAN_ITEMINFLUENCE_POSENABLE,	LXsTYPE_BOOLEAN);
                ac.SetDefault  (0.0, 1);

                ac.NewChannel  (LXsICHAN_ITEMINFLUENCE_ROTENABLE,	LXsTYPE_BOOLEAN);
                ac.SetDefault  (0.0, 1);

                ac.NewChannel  (LXsICHAN_ITEMINFLUENCE_SCLENABLE,	LXsTYPE_BOOLEAN);
                ac.SetDefault  (0.0, 1);

                ac.NewChannel  (LXsICHAN_ITEMINFLUENCE_SAMPLEWEIGHT,	LXsTYPE_BOOLEAN);
                ac.SetDefault  (0.0, 1);

                return LXe_OK;
        }

        /*
         * TestInterface() is required so that nexus knows what interfaces instance
         * of this package support. Necessary to prevent query loops.
         */
                LxResult
        pkg_TestInterface (
                const LXtGUID		*guid)
                                                        LXx_OVERRIDE
        {
                return spawn.TestInterfaceRC (guid);
        }

        /*
         * Attach is called to create a new instance of this item. The returned
         * object implements a specific item of this type in the scene.
         */
                LxResult
        pkg_Attach (
                void		       **ppvObj)
                                                        LXx_OVERRIDE
        {
                spawn.Alloc (ppvObj);
                return LXe_OK;
        }
};

LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,		"."				},
        { LXsPKG_DEFORMER_CHANNEL,	LXsICHAN_ITEMINFLUENCE_ITEMINF	},
        { LXsPKG_DEFORMER_FLAGS,	"+OWX"				},	// no offset, no weight, no xfrm
        { 0 }
};



/* 
 * ----------------------------------------------------------------
 * Item Influence 
 */
class CInfluence :
                public CLxImpl_Deformer,
                public CLxImpl_ItemInfluence
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CInfluence>;
                srv->AddInterface (new CLxIfc_Deformer     <CInfluence>);
                srv->AddInterface (new CLxIfc_ItemInfluence<CInfluence>);
                lx::AddSpawner (SPWNAME_INFLUENCE, srv);
        }

        CLxUser_DeformerService	 d_S;

        CLxUser_Item	 m_item;
        bool		 is_enabled, is_linear;
        CSourceList	 src_list;
        unsigned	 xfrm_flags;

                unsigned
        dinf_Flags ()
                                                        LXx_OVERRIDE
        {
                return LXfDEFORMER_NO_OFFSET | LXfDEFORMER_NO_WEIGHT
                               |  (is_linear ? LXfDEFORMER_USE_LINEAR : 0);
        }

                LxResult
        iinf_HasItems ()
                                                        LXx_OVERRIDE
        {
                if (!is_enabled)
                        return LXe_FALSE;

                return (src_list.empty () ? LXe_FALSE : LXe_TRUE);
        }

                LxResult
        iinf_AllowTransform (
                unsigned		 index,
                unsigned		*flags)
                                                        LXx_OVERRIDE
        {
                flags[0] = xfrm_flags;
                return LXe_OK;
        }

                LxResult
        iinf_Enumerate (
                ILxUnknownID		 visitor)
                                                        LXx_OVERRIDE
        {
                return src_list.Enumerate (visitor);
        }

                LxResult
        iinf_GetItem (
                void		       **ppvObj)
                                                        LXx_OVERRIDE
        {
                return src_list.GetItem (ppvObj);
        }

                unsigned
        dinf_PartitionCount ()
                                                        LXx_OVERRIDE
        {
                return 1;
        }

                LxResult
        dinf_EnumeratePartition (
                ILxUnknownID		 visitor,
                unsigned		 part)
                                                        LXx_OVERRIDE
        {
                if (!is_enabled)
                        return LXe_OK;
                else if (part)
                        return LXe_OK;
                else
                        return src_list.Enumerate (visitor);
        }

                LXtDeformElt
        dinf_Element (
                unsigned		*segment)
                                                        LXx_OVERRIDE
        {
                segment[0] = 0;
                return d_S.ItemToDeformElt (src_list.cur_item);
        }
};



/*
 * ----------------------------------------------------------------
 * Schematic Connection Point
 *
 */
template <class T>
class CGraphEvent :
                public CLxImpl_SceneItemListener,
                public CLxSingletonPolymorph
{
    public:
        LXxSINGLETON_METHOD

        CLxUser_ListenerService	 listen_S;
        T			*target;

        CGraphEvent ()
        {
                AddInterface (new CLxIfc_SceneItemListener<CGraphEvent<T> >);

                listen_S.AddListener (*this);
        }

        ~CGraphEvent ()
        {
                listen_S.RemoveListener (*this);
        }

                void
        GraphChange (
                const char		*graph,
                ILxUnknownID		 item1,
                ILxUnknownID		 item2)
        {
                if (!strcmp (graph, LXsGRAPH_DEFORMERS))
                        target->Invalidate ();
        }

                void
        sil_LinkAdd (
                const char		*graph,
                ILxUnknownID		 itemFrom,
                ILxUnknownID		 itemTo)
                                                        LXx_OVERRIDE
        {
                GraphChange (graph, itemFrom, itemTo);
        }

                void
        sil_LinkRemAfter (
                const char		*graph,
                ILxUnknownID		 itemFrom,
                ILxUnknownID		 itemTo)
                                                        LXx_OVERRIDE
        {
                GraphChange (graph, itemFrom, itemTo);
        }

                void
        sil_LinkSet (
                const char		*graph,
                ILxUnknownID		 itemFrom,
                ILxUnknownID		 itemTo)
                                                        LXx_OVERRIDE
        {
                GraphChange (graph, itemFrom, itemTo);
        }
};


class CConnection :
                public CLxImpl_SchematicConnection
{
    public:
        static LXtTagInfoDesc	 descInfo[];

                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CConnection>;
                srv->AddInterface (new CLxIfc_SchematicConnection<CConnection>);
                srv->AddInterface (new CLxIfc_StaticDesc         <CConnection>);
                lx::AddServer (SRVNAME_CONNECTION, srv);
        }

        ILxUnknownID		 cur_item;
        CSourceList		 cur_list;
        CGraphEvent<CConnection> graph_event;

        CConnection ()
        {
                graph_event.target = this;
                cur_item = 0;
        }

                void
        Invalidate ()
        {
                cur_item = 0;
        }

                void
        Validate (
                ILxUnknownID		 inf)
        {
                if (cur_item == inf)
                        return;

                cur_item = inf;
                cur_list.Build (inf);
        }

                int
        schm_BaseFlags ()				LXx_OVERRIDE
        {
                return LXfSCON_USESERVER | LXfSCON_REVERSE;
        }

                LxResult
        schm_ItemFlags (
                ILxUnknownID		 item,
                unsigned		*flags)
                                                        LXx_OVERRIDE
        {
                CLxUser_Item		 it (item);

                if (!it.IsA (cit_iteminf))
                        return LXe_NOTFOUND;

                flags[0] = LXfSCON_MULTIPLE | LXfSCON_USESERVER | LXfSCON_REVERSE;
                return LXe_OK;
        }

                LxResult
        schm_AllowConnect (
                ILxUnknownID		 from,
                ILxUnknownID		 to)
                                                        LXx_OVERRIDE
        {
                CLxUser_Item		 it (from);

                return (it.IsA (cit_locator) ? LXe_TRUE : LXe_FALSE);
        }

                LxResult
        schm_GraphName (
                const char	       **name)
                                                        LXx_OVERRIDE
        {
                name[0] = LXsGRAPH_DEFORMERS;
                return LXe_OK;
        }

                LxResult
        schm_Count (
                ILxUnknownID		 item,
                unsigned		*count)
                                                        LXx_OVERRIDE
        {
                Validate (item);
                count[0] = cur_list.size ();
                return LXe_OK;
        }

                LxResult
        schm_ByIndex (
                ILxUnknownID		 item,
                unsigned		 index,
                void		       **ppvObj)
                                                        LXx_OVERRIDE
        {
                Validate (item);
                return cur_list.m_scene.ItemLookup (cur_list[index].id, ppvObj);
        }

                LxResult
        schm_Connect (
                ILxUnknownID		 from,
                ILxUnknownID		 to,
                int			 toIndex)
                                                        LXx_OVERRIDE
        {
                CLxUser_Item		 item (from);
                CLxUser_ItemGraph	 graph;

                graph.from (item, LXsGRAPH_DEFORMERS);
                graph.AddLink (to, from);
                return LXe_OK;
        }

                LxResult
        schm_Disconnect (
                ILxUnknownID		 from,
                ILxUnknownID		 to)
                                                        LXx_OVERRIDE
        {
                CLxUser_Item		 item (from);
                CLxUser_ItemGraph	 graph;

                graph.from (item, LXsGRAPH_DEFORMERS);
                graph.DeleteLink (to, from);
                return LXe_OK;
        }
};

LXtTagInfoDesc	 CConnection::descInfo[] = {
        { LXsSRV_USERNAME,	 "@SchemaGraphs@itemInfluence@"	},
        { 0 }
};


/*
 * ----------------------------------------------------------------
 * The modifier operates on all items of this type, and sets the mesh influence
 * channel to an object allocated using the input parameters for the modifier.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        CLxSpawner<CInfluence>	 spawn;
        CSourceList		 src_list;
        unsigned		 idx_enab;

        CModifierElement () : spawn (SPWNAME_INFLUENCE) {}

                void
        Attach (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
        {
                eval.AddChan (item, LXsICHAN_ITEMINFLUENCE_ITEMINF, LXfECHAN_WRITE);	// 0
                eval.AddChan (item, LXsICHAN_ITEMINFLUENCE_ENABLE);			// 1
                eval.AddChan (item, LXsICHAN_ITEMINFLUENCE_POSENABLE);			// 2
                eval.AddChan (item, LXsICHAN_ITEMINFLUENCE_ROTENABLE);			// 3
                eval.AddChan (item, LXsICHAN_ITEMINFLUENCE_SCLENABLE);			// 4
                eval.AddChan (item, LXsICHAN_ITEMINFLUENCE_SAMPLEWEIGHT);		// 5
                eval.AddChan (item, LXsICHAN_ITEMINFLUENCE_INTERPOLATION);		// 6

                src_list.Build (item);
        }

                bool
        Test (
                ILxUnknownID		 item)		LXx_OVERRIDE
        {
                CSourceList		 tmp;

                tmp.Build (item);
                return src_list.Compare (tmp);
        }

                void
        Eval (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr)		LXx_OVERRIDE
        {
                CInfluence		*infl;
                CLxUser_ValueReference	 ref;
                ILxUnknownID		 obj;

                infl = spawn.Alloc (obj);
                infl->is_enabled =  attr.Bool (1);
                infl->src_list   =  src_list;
                infl->is_linear  = (attr.Int (6) == INTERPi_LINEAR);

                infl->xfrm_flags =
                          (attr.Bool (2) ? LXfITEMINF_POSITION     : 0)
                        | (attr.Bool (3) ? LXfITEMINF_ROTATION     : 0)
                        | (attr.Bool (4) ? LXfITEMINF_SCALE        : 0)
                        | (attr.Bool (5) ? LXfITEMINF_PROBEWEIGHTS : 0);

                attr.ObjectRW (0, ref);
                ref.TakeObject (obj);
        }
};


class CModifier :
                public CLxItemModifierServer
{
    public:
                static void
        initialize ()
        {
                CLxExport_ItemModifierServer<CModifier> (SRVNAME_MODIFIER);
        }

                const char *
        ItemType ()
                                                        LXx_OVERRIDE
        {
                return SRVNAME_ITEMTYPE;
        }

                const char *
        GraphNames ()
                                                        LXx_OVERRIDE
        {
                return LXsGRAPH_GROUPS " " LXsGRAPH_ITEMGROUPS " " LXsGRAPH_DEFORMERS;
        }

                CLxItemModifierElement *
        Alloc (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
                                                        LXx_OVERRIDE
        {
                CModifierElement	*elt;

                elt = new CModifierElement;
                elt->Attach (eval, item);
                return elt;
        }
};



/*
 * Export package server to define a new item type.
 */
        void
initialize ()
{
        CPackage	:: initialize ();
        CModifier	:: initialize ();
        CInstance	:: initialize ();
        CInfluence	:: initialize ();
        CConnection	:: initialize ();
}

        };	// END namespace


