#ifndef LX_VERSION_H
#define LX_VERSION_H

#define LXx_INT_STR(i)		#i		// turn an integer into a string
#define LXx_MACRO_STR(a)	LXx_INT_STR(a)	// extra nesting required for turning macro into string

#define LXi_VERSION_BUILD 85499
#define LXi_VERSION_BASE 9
#define LXi_VERSION_LIB1 900
#define LXi_VERSION_LIB2 0
#define LXi_VERSION_LIB3 8
#define LXi_VERSION_LIB4 5499
#define LXs_VERSION_LIB "901.0.8.5499"
#define LXs_VERSION_NAME "nexus 9"
#define LXs_VERSION_DESC "nexus 9 by The Foundry"
#define LXs_VERSION_MAKER "The Foundry Group LLC"
#define LXs_VERSION_FNBUILD "9.01v85499"
#define LXi_VERSION_YEAR 2015
#define LXs_VERSION_YEAR "2015"
#define LXi_VERSION_MONTH 5
#define LXs_VERSION_MONTH "5"
#define LXi_VERSION_DAY 26
#define LXs_VERSION_DAY "26"
#define LXs_VERSION_TIME "11:50:13"

#endif


