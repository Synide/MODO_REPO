/*
 * LX inmap module
 *
 * Copyright (c) 2008-2017 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_inmap_H
#define LX_inmap_H
 #ifdef __cplusplus
  extern "C" {
 #endif

typedef void * LXtInputMapID;
// [python] type LXtInputMapID       id
typedef void * LXtInputMapGroupID;
typedef struct vt_ILxInputMapService ** ILxInputMapServiceID;
typedef struct vt_ILxInputMapClientTest ** ILxInputMapClientTestID;
typedef struct vt_ILxInputContextClientTest ** ILxInputContextClientTestID;
typedef struct vt_ILxRegionHandler ** ILxRegionHandlerID;
typedef struct vt_ILxInputDevices ** ILxInputDevicesID;
typedef struct vt_ILxInputDeviceInstance ** ILxInputDeviceInstanceID;
#include <lxserver.h>
#include <lxvalue.h>
#include <lxcommand.h>

typedef void *                  LXtInputStateID;
typedef void *                  LXtInputContextID;
#define LXiIMCONTEXTTYPE_INVALID                -1              // Invalid

#define LXiIMCONTEXTTYPE_CONTEXTLESS             0              // Identifies the global context
#define LXiIMCONTEXTTYPE_SELECTION               1              // Selection-oriented contexts (item vs. component mode)
#define LXiIMCONTEXTTYPE_LAYOUT                  2              // Layout-specific contexts (see frame.qq for more information)

#define LXiIMCONTEXTTYPE_SPECIAL                 3              // Special context that is not shown in the Input Editor
typedef unsigned short                  LXtDualKey;                     // Should be in awin.qq, but it doesn't have an SDK yet.
typedef LXtDualKey *                    LXtDualKeyCombo;

typedef struct vt_ILxInputMapService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD(  LxResult,
        Define) (
                LXtObjectID              self,
                LXtInputContextID        context,
                const char              *name,
                LXtInputMapID           *im);
                LXxMETHOD(  LxResult,
        DefineGroup) (
                LXtObjectID              self,
                const char              *group);
                LXxMETHOD(  LxResult,
        DefineStandardEvent) (
                LXtObjectID              self,
                int                      event,
                int                      flags);
                LXxMETHOD(  LxResult,
        DefineCustomEvent) (
                LXtObjectID              self,
                int                      event,
                const char              *name,
                int                      flags);
                LXxMETHOD(  LxResult,
        DefineClientTests) (
                LXtObjectID              self,
                LXtObjectID              tester);
                LXxMETHOD(  LxResult,
        DefineRegion) (
                LXtObjectID              self,
                int                      event,
                const char              *name);
                LXxMETHOD(  LxResult,
        Count) (
                LXtObjectID              self,
                LXtInputContextID        context,
                int                     *count);

                LXxMETHOD(  LxResult,
        ByIndex) (
                LXtObjectID              self,
                LXtInputContextID        context,
                int                      index,
                LXtInputMapID           *im);
                LXxMETHOD(  LxResult,
        Lookup) (
                LXtObjectID              self,
                LXtInputContextID        context,
                const char              *name,
                LXtInputMapID           *im);
                LXxMETHOD(  LxResult,
        GroupCount) (
                LXtObjectID              self,
                LXtInputMapGroupID       group,
                int                     *count);

                LXxMETHOD(  LxResult,
        GroupByIndex) (
                LXtObjectID              self,
                LXtInputMapGroupID       group,
                int                      index,
                LXtInputMapGroupID      *subgroup);

                LXxMETHOD(  LxResult,
        GroupIMCount) (
                LXtObjectID              self,
                LXtInputMapGroupID       group,
                int                     *count);

                LXxMETHOD(  LxResult,
        GroupIMByIndex) (
                LXtObjectID              self,
                LXtInputMapGroupID       group,
                int                      index,
                LXtInputMapID           *im);
                LXxMETHOD(  LxResult,
        GroupGetName) (
                LXtObjectID              self,
                LXtInputMapGroupID       group,
                const char              *name);
                LXxMETHOD(  LxResult,
        GroupGetUserName) (
                LXtObjectID              self,
                LXtInputMapGroupID       group,
                const char              *username);
                LXxMETHOD(  LxResult,
        Name) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char             **name);
                LXxMETHOD(  LxResult,
        Group) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char             **groupPath,
                LXtInputMapGroupID      *group);
                LXxMETHOD(  LxResult,
        Data) (
                LXtObjectID              self,
                LXtInputMapID            im,
                void                   **data);
                LXxMETHOD(  LxResult,
        EventCount) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                     *count);
                LXxMETHOD(  LxResult,
        EventName) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                      index,
                const char             **name);
                LXxMETHOD(  LxResult,
        EventType) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                      index,
                int                     *type);
                LXxMETHOD(  LxResult,
        EventFlags) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                      index,
                int                     *flags);
                LXxMETHOD(  LxResult,
        CanEventsCoexist) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                      event1,
                int                      event2);
                LXxMETHOD(  LxResult,
        StandardEventName) (
                LXtObjectID              self,
                int                      event,
                const char             **name);
                LXxMETHOD(  LxResult,
        StandardEventFlags) (
                LXtObjectID              self,
                int                      event,
                int                     *flags);
                LXxMETHOD(  LxResult,
        RegionCount) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                     *count);
                LXxMETHOD(  LxResult,
        RegionName) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                      i,
                const char             **name);

                LXxMETHOD(  LxResult,
        RegionType) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                      i,
                int                     *type);
                LXxMETHOD(  LxResult,
        FindEvent) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *name,
                int                      type,
                int                     *index);
                LXxMETHOD(  LxResult,
        FindRegion) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *name,
                int                      type,
                int                     *index);
                LXxMETHOD(  LxResult,
        UserName) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char             **username);

                LXxMETHOD(  LxResult,
        Desc) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char             **desc);

                LXxMETHOD(  LxResult,
        HelpURL) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char             **helpURL);
                LXxMETHOD(  LxResult,
        EventUserName) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *stateName,
                const char              *name,
                int                      index,
                const char             **username);

                LXxMETHOD(  LxResult,
        EventDesc) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *stateName,
                const char              *name,
                int                      index,
                const char             **desc);

                LXxMETHOD(  LxResult,
        EventHelpURL) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *stateName,
                const char              *name,
                int                      index,
                const char             **helpURL);
                LXxMETHOD(  LxResult,
        RegionUserName) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *stateName,
                const char              *name,
                int                      index,
                const char             **username);

                LXxMETHOD(  LxResult,
        RegionDesc) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *stateName,
                const char              *name,
                int                      index,
                const char             **desc);

                LXxMETHOD(  LxResult,
        RegionHelpURL) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *stateName,
                const char              *name,
                int                      index,
                const char             **helpURL);
                LXxMETHOD(  LxResult,
        GroupUserName) (
                LXtObjectID              self,
                const char              *path,
                int                      depth,
                const char             **username);
                LXxMETHOD(  LxResult,
        StateUserName) (
                LXtObjectID               self,
                const char               *state,
                const char              **name );
                LXxMETHOD(  LxResult,
        StateCatUserName) (
                LXtObjectID               self,
                const char               *cat,
                const char              **name );
                LXxMETHOD(  LxResult,
        StateLookup) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *name,
                int                      add,
                LXtInputStateID         *state );
                LXxMETHOD(  LxResult,
        StateCount) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                     *count );
                LXxMETHOD(  LxResult,
        StateByIndex) (
                LXtObjectID              self,
                LXtInputMapID            im,
                int                      i,
                LXtInputStateID         *state );
                LXxMETHOD(  LxResult,
        StateName) (
                LXtObjectID               self,
                LXtInputStateID           state,
                const char              **name );
                LXxMETHOD(  LxResult,
        StateInputMap) (
                LXtObjectID               self,
                LXtInputStateID           state,
                LXtInputMapID            *im );
                LXxMETHOD(  LxResult,
        TestState) (
                LXtObjectID              self,
                LXtInputMapID            im,
                const char              *state,
                int                     *priority);
                LXxMETHOD(  LxResult,
        StateUIListCatCount) (
                LXtObjectID              self,
                int                     *count);

                LXxMETHOD(  LxResult,
        StateUIListCatName) (
                LXtObjectID               self,
                int                       index,
                const char              **name);
                LXxMETHOD(  LxResult,
        StateUIListCount) (
                LXtObjectID              self,
                const char              *cat,
                int                     *count);

                LXxMETHOD(  LxResult,
        StateUIListName) (
                LXtObjectID               self,
                const char               *cat,
                int                       index,
                const char              **name);
                LXxMETHOD(  LxResult,
        StateUIFallbacksCount) (
                LXtObjectID                self,
                const char                *stateName,
                int                       *count);

                LXxMETHOD(  LxResult,
        StateUIFallbacksName) (
                LXtObjectID                self,
                const char                *stateName,
                int                        index,
                const char               **name);
                LXxMETHOD(  LxResult,
        StateUITestEvent) (
                LXtObjectID                self,
                LXtInputMapID              im,
                const char                *stateName,
                int                        eventID);

                LXxMETHOD(  LxResult,
        StateUITestRegion) (
                LXtObjectID                self,
                LXtInputMapID              im,
                const char                *stateName,
                int                        regionID);
                LXxMETHOD(  LxResult,
        RefreshStates) (
                LXtObjectID              self,
                int                      flags);
                LXxMETHOD(  LxResult,
        DefineContext) (
                LXtObjectID              self,
                const char              *name,
                int                      type,
                LXtObjectID              clientTest,
                LXtInputContextID       *context);
                LXxMETHOD(  LxResult,
        ContextCount) (
                LXtObjectID              self,
                int                     *count);

                LXxMETHOD(  LxResult,
        ContextByIndex) (
                LXtObjectID               self,
                int                       index,
                LXtInputContextID        *context);
                LXxMETHOD(  LxResult,
        ContextLookup) (
                LXtObjectID              self,
                const char              *name,
                LXtInputContextID       *context );
                LXxMETHOD(  LxResult,
        TestContext) (
                LXtObjectID              self,
                LXtInputContextID        context,
                int                     *priority);
                LXxMETHOD(  LxResult,
        ContextName) (
                LXtObjectID               self,
                LXtInputContextID         context,
                const char              **name);
                LXxMETHOD(  LxResult,
        ContextType) (
                LXtObjectID               self,
                LXtInputContextID         context,
                int                      *type);
                LXxMETHOD(  LxResult,
        ContextUserName) (
                LXtObjectID               self,
                LXtInputContextID         context,
                const char              **name);

                LXxMETHOD(  LxResult,
        ContextDesc) (
                LXtObjectID               self,
                LXtInputContextID         context,
                const char              **desc);

                LXxMETHOD(  LxResult,
        ContextHelpURL) (
                LXtObjectID               self,
                LXtInputContextID         context,
                const char              **helpURL);
                LXxMETHOD(  LxResult,
        Context) (
                LXtObjectID               self,
                LXtInputMapID             im,
                LXtInputContextID        *context);
                LXxMETHOD(  LxResult,
        RefreshContexts) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        EventMappingCount) (
                LXtObjectID              self,
                LXtInputStateID          state,
                const char              *eventName,
                int                      eventIndex,
                int                      eventType,
                int                     *count);
                LXxMETHOD(  LxResult,
        EventMappingByIndex) (
                LXtObjectID              self,
                LXtInputStateID          state,
                const char              *eventName,
                int                      eventIndex,
                int                      eventType,
                int                      index,
                LXtDualKeyCombo         *combo);
                LXxMETHOD(  LxResult,
        RegionMappingCount) (
                LXtObjectID              self,
                LXtInputStateID          state,
                const char              *regionName,
                int                      regionIndex,
                int                      regionType,
                int                     *count);
                LXxMETHOD(  LxResult,
        RegionMappingByIndex) (
                LXtObjectID              self,
                LXtInputStateID          state,
                const char              *regionName,
                int                      regionIndex,
                int                      regionType,
                int                      index,
                LXtDualKeyCombo         *combo,
                const char             **command);
                LXxMETHOD(  LxResult,
        RegionMappingFind) (
                LXtObjectID              self,
                LXtInputStateID          state,
                const char              *regionName,
                int                      regionIndex,
                int                      regionType,
                const LXtDualKeyCombo    combo,
                int                     *index);
                LXxMETHOD(  LxResult,
        ComboMapsTo) (
                LXtObjectID              self,
                LXtInputStateID          state,
                LXtDualKeyCombo          combo,
                int                      eventFlags,
                int                      index,
                int                     *type);
                LXxMETHOD(  LxResult,
        ComboToString) (
                LXtObjectID              self,
                LXtDualKeyCombo          combo,
                char                    *buffer,
                int                      bufLen);
                LXxMETHOD(  LxResult,
        ComboEncode) (
                LXtObjectID              self,
                LXtDualKeyCombo          combo,
                char                    *buffer,
                int                      bufLen);
                LXxMETHOD(  LxResult,
        ComboDecode) (
                LXtObjectID              self,
                const char              *string,
                LXtDualKeyCombo         *combo,
                int                      mode);
                LXxMETHOD(  LxResult,
        ComboCompare) (
                LXtObjectID              self,
                LXtDualKeyCombo          combo1,
                LXtDualKeyCombo          combo2 );
                LXxMETHOD(  LxResult,
        ComboEncodePart) (
                LXtObjectID              self,
                LXtDualKey               part,
                char                    *buffer,
                int                      bufLen);
                LXxMETHOD(  LxResult,
        ComboDecodePart) (
                LXtObjectID              self,
                const char              *string,
                LXtDualKey              *part );
                LXxMETHOD(  LxResult,
        GetMouseMap) (
                LXtObjectID              self,
                LXtInputMapID            im,
                void                   **ppvObj);
                LXxMETHOD(  LxResult,
        AttachRegions) (
                LXtObjectID               self,
                LXtInputMapID             im,
                void                     *pane,
                int                       mouserPriority,
                LXtObjectID               handler,
                void                    **mouser);
                LXxMETHOD(  LxResult,
        UpdateDeviceList) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        UpdateDeviceInstance) (
                LXtObjectID              self,
                const char              *name);
} ILxInputMapService;
typedef struct vt_ILxInputMapClientTest {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        TestState) (
                LXtObjectID              self,
                const char              *stateName,
                int                     *priority);
                LXxMETHOD(  LxResult,
        StateUICount) (
                LXtObjectID              self,
                int                     *count);

                LXxMETHOD(  LxResult,
        StateUIName) (
                LXtObjectID               self,
                int                       index,
                const char              **name);

                LXxMETHOD(  LxResult,
        StateUIUserName) (
                LXtObjectID               self,
                const char               *name,
                const char              **username);
                LXxMETHOD(  LxResult,
        StateUIFallbacksCount) (
                LXtObjectID                self,
                const char                *stateName,
                int                       *count);
                LXxMETHOD(  LxResult,
        StateUIFallbacksName) (
                LXtObjectID                self,
                const char                *stateName,
                int                        index,
                const char               **name);
                LXxMETHOD(  LxResult,
        StateUITestEvent) (
                LXtObjectID                self,
                LXtInputMapID              im,
                const char                *stateName,
                int                        eventID);

                LXxMETHOD(  LxResult,
        StateUITestRegion) (
                LXtObjectID                self,
                LXtInputMapID              im,
                const char                *stateName,
                int                        regionID);
                LXxMETHOD(  LxResult,
        TestCoexistence) (
                LXtObjectID              self,
                int                      event1,
                int                      event2);
} ILxInputMapClientTest;
typedef struct vt_ILxInputContextClientTest {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Test) (
                LXtObjectID              self,
                LXtInputContextID        context,
                int                     *priority);
} ILxInputContextClientTest;
typedef struct vt_ILxRegionHandler {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Test) (
                LXtObjectID              self,
                int                      x,
                int                      y,
                int                      region);
                LXxMETHOD(  LxResult,
        Pick) (
                LXtObjectID              self,
                int                      x,
                int                      y,
                int                      region);
                LXxMETHOD(  LxResult,
        ToolTip) (
                LXtObjectID               self,
                int                       x,
                int                       y,
                int                       region,
                const char              **toolTip);
} ILxRegionHandler;
typedef struct vt_ILxInputDevices {
        ILxUnknown       iunk;
                LXxMETHOD(  int,
        DeviceCount) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        DeviceNameByIndex) (
                LXtObjectID               self,
                int                       index,
                const char               *name);
                LXxMETHOD(  LxResult,
        DeviceInstanceByIndex) (
                LXtObjectID               self,
                int                       index,
                void                    **ppvObj);
} ILxInputDevices;
typedef struct vt_ILxInputDeviceInstance {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Name) (
                LXtObjectID               self,
                const char               *name);
                LXxMETHOD(  LxResult,
        IsConnected) (
                LXtObjectID               self);
                LXxMETHOD(  int,
        ButtonCount) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        ButtonName) (
                LXtObjectID               self,
                int                       index,
                char                     *buf,
                int                       len);

                LXxMETHOD(  LxResult,
        ButtonUserName) (
                LXtObjectID               self,
                int                       index,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        ButtonIsDown) (
                LXtObjectID               self,
                int                       index);
                LXxMETHOD(  int,
        AnalogCount) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        AnalogName) (
                LXtObjectID               self,
                int                       index,
                char                     *buf,
                int                       len);

                LXxMETHOD(  LxResult,
        AnalogUserName) (
                LXtObjectID               self,
                int                       index,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        AnalogMetrics) (
                LXtObjectID               self,
                int                       index,
                int                      *isAbsolute,
                int                      *isDirectional);
                LXxMETHOD(  LxResult,
        AnalogValue) (
                LXtObjectID               self,
                int                       index,
                double                   *value);
} ILxInputDeviceInstance;

#define LXe_INPUTMAP_UNMAPPED                   LXxFAILCODE(LXeSYS_INPUTMAP,1)
#define LXe_INPUTMAP_UNKNOWN_EVENT              LXxFAILCODE(LXeSYS_INPUTMAP,2)  // Input map does not support this event
#define LXe_INPUTMAP_UNKNOWN_REGION             LXxFAILCODE(LXeSYS_INPUTMAP,3)  // Input map does not support this region
#define LXe_INPUTMAP_BAD_COMBO                  LXxFAILCODE(LXeSYS_INPUTMAP,4)  // Combo needs LMB, RMB or MMB set
#define LXe_INPUTMAP_COMBO_GLOBALLY_MAPPED      LXxFAILCODE(LXeSYS_INPUTMAP,5)  // Combo is already mapped globally
#define LXe_INPUTMAP_EVENT_GLOBALLY_MAPPED      LXxFAILCODE(LXeSYS_INPUTMAP,6)  // Event is already mapped globally

#define LXe_INPUTMAP_EVENT_FOUND                LXxGOODCODE(LXeSYS_INPUTMAP,7)  // Successful; event found
#define LXe_INPUTMAP_REGION_FOUND               LXxGOODCODE(LXeSYS_INPUTMAP,8)  // Successful; region found
#define LXu_INPUTMAPSERVICE     "DEDDBC50-F747-43a4-838D-D706ED688416"
#define LXa_INPUTMAPSERVICE     "inputmapservice"
#define LXsINMAP_DEFINE         "inputmap.define"
#define LXsINMAP_GLOBALMAP      ".global"
#define LXmINEVENT_STANDARD              0xF0000000
#define LXmINEVENT_TYPE                  0xF0000000
#define LXiINEVENT_TYPE_NAV              0x80000000
#define LXiINEVENT_TYPE_SEL              0x90000000
#define LXiINEVENT_TYPE_SEL3D            0xA0000000
#define LXiINEVENT_TYPE_DRAG             0xB0000000

/* Standard types */
#define LXiINEVENT_NAV_PAN               0x80000001             // Drag
#define LXiINEVENT_NAV_ZOOM              0x80000002             // Drag
#define LXiINEVENT_NAV_BOX_ZOOM          0x80000003             // Drag
#define LXiINEVENT_NAV_ROTATE            0x80000004             // Drag
#define LXiINEVENT_NAV_FREEWHEEL         0x80000005             // Drag
#define LXiINEVENT_NAV_ROLL              0x80000006             // Drag
#define LXiINEVENT_NAV_PAN_XZ            0x80000007             // Drag
#define LXiINEVENT_NAV_PAN_Y             0x80000008             // Drag
#define LXiINEVENT_NAV_ROTATE_FPS        0x80000009             // Drag

#define LXiINEVENT_SEL_PICK              0x90000010             // Click
#define LXiINEVENT_SEL_ADD               0x90000011             // Click
#define LXiINEVENT_SEL_SUBTRACT          0x90000012             // Click
#define LXiINEVENT_SEL_TOGGLE            0x90000013             // Click
#define LXiINEVENT_SEL_RANGE             0x90000014             // Click

#define LXiINEVENT_SEL_LASSO             0x90000015             // Drag
#define LXiINEVENT_SEL_LASSO_ADD         0x90000016             // Drag
#define LXiINEVENT_SEL_LASSO_SUB         0x90000017             // Drag
#define LXiINEVENT_SEL_LASSO_TOG         0x90000018             // Drag

#define LXiINEVENT_SEL3D_PICK            0xA0000020             // Click and Drag
#define LXiINEVENT_SEL3D_ADD             0xA0000021             // Click and Drag
#define LXiINEVENT_SEL3D_SUBTRACT        0xA0000022             // Click and Drag
#define LXiINEVENT_SEL3D_TOGGLE          0xA0000023             // Click and Drag
#define LXiINEVENT_SEL3D_OPTION          0xA000002C             // Click and Drag

#define LXiINEVENT_SEL3D_AREA            0xA0000024             // Drag
#define LXiINEVENT_SEL3D_AREA_ADD        0xA0000025             // Drag
#define LXiINEVENT_SEL3D_AREA_SUB        0xA0000026             // Drag
#define LXiINEVENT_SEL3D_AREA_TOG        0xA0000027             // Drag

#define LXiINEVENT_SEL3D_THRU            0xA0000028             // Drag
#define LXiINEVENT_SEL3D_THRU_ADD        0xA0000029             // Drag
#define LXiINEVENT_SEL3D_THRU_SUB        0xA000002A             // Drag
#define LXiINEVENT_SEL3D_THRU_TOG        0xA000002B             // Drag
#define LXiINEVENT_DRAG_DROP_BEGIN       0xB0000030             // Drag.  Special in that this event is never actually mapped to anything
#define LXsINEVENT_NAV_PAN              "navPan"
#define LXsINEVENT_NAV_ZOOM             "navZoom"
#define LXsINEVENT_NAV_BOX_ZOOM         "navBoxZoom"
#define LXsINEVENT_NAV_ROTATE           "navRotate"
#define LXsINEVENT_NAV_FREEWHEEL        "navFreewheel"
#define LXsINEVENT_NAV_ROLL             "navRoll"
#define LXsINEVENT_NAV_PAN_XZ           "navPanXZ"
#define LXsINEVENT_NAV_PAN_Y            "navPanY"
#define LXsINEVENT_NAV_ROTATE_FPS       "navRotateFPS"

#define LXsINEVENT_SEL_PICK             "selPick"
#define LXsINEVENT_SEL_ADD              "selAdd"
#define LXsINEVENT_SEL_SUBTRACT         "selSubtract"
#define LXsINEVENT_SEL_TOGGLE           "selToggle"
#define LXsINEVENT_SEL_RANGE            "selRange"

#define LXsINEVENT_SEL_LASSO            "selLasso"
#define LXsINEVENT_SEL_LASSO_ADD        "selLassoAdd"
#define LXsINEVENT_SEL_LASSO_SUB        "selLassoSubtract"
#define LXsINEVENT_SEL_LASSO_TOG        "selLassoToggle"

#define LXsINEVENT_SEL3D_PICK           "sel3DPick"
#define LXsINEVENT_SEL3D_ADD            "sel3DAdd"
#define LXsINEVENT_SEL3D_SUBTRACT       "sel3DSubtract"
#define LXsINEVENT_SEL3D_TOGGLE         "sel3DToggle"
#define LXsINEVENT_SEL3D_OPTION         "sel3DOption"

#define LXsINEVENT_SEL3D_AREA           "sel3DArea"
#define LXsINEVENT_SEL3D_AREA_ADD       "sel3DAreaAdd"
#define LXsINEVENT_SEL3D_AREA_SUB       "sel3DAreaSubtract"
#define LXsINEVENT_SEL3D_AREA_TOG       "sel3DAreaToggle"

#define LXsINEVENT_SEL3D_THRU           "sel3DThru"
#define LXsINEVENT_SEL3D_THRU_ADD       "sel3DThruAdd"
#define LXsINEVENT_SEL3D_THRU_SUB       "sel3DThruSubtract"
#define LXsINEVENT_SEL3D_THRU_TOG       "sel3DThruToggle"

#define LXsINEVENT_DRAG_DROP_BEGIN      "dragDropBegin"
#define LXfINPUTEVENT_TRACK                     0x1000
#define LXfINPUTEVENT_TRACKLESS                 0x2000

#define LXfINPUTEVENT_INDEPENDANT_CLICKDRAG     0x4000

#define LXfINPUTEVENT_CONSTANT_MOVES            0x8000

#define LXmINPUTEVENT_FLAGS                     0xF000
#define LXxINPUTEVENT_FLAGS(flags)              (flags & LXmINPUTEVENT_FLAGS)
#define LXfINPUTEVENT_CLICK                     0x0001
#define LXfINPUTEVENT_DRAG                      0x0002

#define LXfINPUTEVENT_BOTH                      (LXfINPUTEVENT_CLICK | LXfINPUTEVENT_DRAG)

#define LXfINPUTEVENT_DELTADRAG                 0x0004

#define LXmINPUTEVENT_TYPE                      0x000F
#define LXxINPUTEVENT_TYPE(flags)               (flags & LXmINPUTEVENT_TYPE)

#define LXxINPUTEVENT_BOTH(flags)               (LXxINPUTEVENT_TYPE(flags) == LXfINPUTEVENT_BOTH)
#define LXxINPUTEVENT_ISDRAG(flags)             (LXxINPUTEVENT_TYPE(flags) != LXfINPUTEVENT_CLICK)
#define LXu_INPUTMAPCLIENTTEST  "7653F32B-8FDA-40ce-8EDE-0D5523BC7609"
#define LXa_INPUTMAPCLIENTTEST  "inputmapclienttest"
#define LXiINMAPINDEX_NOREGION          -3
#define LXiINMAPINDEX_NOOP              -2
#define LXiINMAPINDEX_ANYWHERE          -1

#define LXiINMAPINDEX_NOEVENT           -1

#define LXiINMAPINDEX_NOMAPPING         -1

#define LXiINMAPTYPE_NULL                0

#define LXsINMAPREGION_ANYWHERE         ".anywhere"
#define LXsINMAPREGION_NOOP             ".noop"
#define LXsINMAPSTATE_GLOBAL             "(stateless)"
#define LXfINPUTSTATE_UPDATE_CURRENT    0x0001
#define LXfINPUTSTATE_UPDATE_LIST       0x0002
#define LXu_INPUTCONTEXTCLIENTTEST      "FB08280B-5F3E-4852-B31F-8A87A6E7427F"
#define LXa_INPUTCONTEXTCLIENTTEST      "inputmapcontextclienttest"
#define LXsINMAPCONTEXT_GLOBAL           "(contextless)"
#define LXi_IMCOMBOTEST_EVENTS                  1
#define LXi_IMCOMBOTEST_REGIONS                 2
#define LXi_IMCOMBOTEST_MODIFIERS               3
#define LXu_REGIONHANDLER       "05811721-08E9-49e0-ADFE-92C6D4A3E5E6"
#define LXa_REGIONHANDLER       "inputmapregionhandler"
#define LXu_INPUTDEVICES        "0a70601b-750d-4325-b38a-86f319933e17"
#define LXa_INPUTDEVICES        "inputdevices"
//[export]  ILxInputDevices indev
//[local]   ILxInputDevices
//[python]  ILxInputDevices:DeviceInstanceByIndex       obj InputDeviceInstance
//[default] ILxInputDevices:DeviceCount = 0
#define LXsINPUTDEVICES_POLLRATE                "inputdevices.pollrate"
#define LXu_INPUTDEVICEINSTANCE "fd2edfc9-c3db-4409-a478-fce1511b9ff0"
#define LXa_INPUTDEVICEINSTANCE "inputdeviceinstance"
//[export]  ILxInputDeviceInstance indevinst
//[local]   ILxInputDeviceInstance
//[default] ILxInputDeviceInstance:ButtonCount = 0
//[default] ILxInputDeviceInstance:AnalogCount = 0
//[python]  ILxInputDeviceInstance:ButtonIsDown                         bool

 #ifdef __cplusplus
  }
 #endif
#endif

