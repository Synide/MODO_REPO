/*
 * olaSafeArea.cpp	Plug-in locator-based graphic overlay
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include <lx_item.hpp>
#include <lx_deform.hpp>
#include <lx_package.hpp>
#include <lx_plugin.hpp>
#include <lx_filter.hpp>
#include <lx_action.hpp>
#include <lx_vmodel.hpp>
#include <lx_draw.hpp>
#include <lx_handles.hpp>
#include <lx_visitor.hpp>
#include <lx_value.hpp>
#include <lx_mesh.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxu_math.hpp>
#include <lxidef.h>
#include <string>
#include <math.h>

        namespace Overlay_SafeArea {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		"safeAreaOverlay"
#define SRVNAME_MODIFIER		"safeAreaOverlay"
#define SPWNAME_INSTANCE		"safeAreaOlay.inst"	

/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CPackage;
class CInstance;
typedef struct {
        float		apertureX, apertureY;
        float		focalLength;
        float		focusDist;
        float		fStop;
        float		eyeSep;
        float		convergenceDist;
} CameraInfo;



class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_ViewItem3D
{
    public: 
        CPackage		*src_pkg;
        LXtItemType		 camType;
        CLxUser_Item		 m_item;
        CLxUser_Item		 m_cam;
        LXtVector		 camPos;
        LXtMatrix4		 camXfrm;

        int		 readCameraChannels (CLxUser_ChannelRead chan, CameraInfo *ci);

        LxResult	 pins_Initialize (ILxUnknownID item, ILxUnknownID super)	LXx_OVERRIDE;
        void		 pins_Cleanup (void)						LXx_OVERRIDE;

         // ViewItem3D interface.
        LxResult	 vitm_Draw (
                                ILxUnknownID	 itemChanRead,
                                ILxUnknownID	 viewStrokeDraw,
                                int		 selectionFlags,
                                LXtVector	 itemColor) LXx_OVERRIDE;

# if 0
        LxResult	 vitm_HandleCount (
                                int		*count) LXx_OVERRIDE;

        LxResult	 vitm_HandleMotion (
                                int		 handleIndex,
                                int		*motionType,
                                double		*min,
                                double		*max,
                                LXtVector	 plane,
                                LXtVector	 offset) LXx_OVERRIDE;

        LxResult	 vitm_HandleChannel (
                                int		 handleIndex,
                                int		*chanIndex) LXx_OVERRIDE;

        LxResult	 vitm_HandleValueToPosition (
                                int		 handleIndex,
                                double		 chanValue,
                                LXtVector	 position) LXx_OVERRIDE;

        LxResult	 vitm_HandlePositionToValue (
                                int		 handleIndex,
                                LXtVector	 position,
                                double		*chanValue) LXx_OVERRIDE;

#endif
};

class CPackage :
                public CLxImpl_Package
{
    public:
        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 inst_spawn;

        CPackage () : inst_spawn (SPWNAME_INSTANCE) {}

        LxResult		pkg_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		pkg_TestInterface (const LXtGUID *guid) LXx_OVERRIDE;
        LxResult		pkg_Attach (void **ppvObj) LXx_OVERRIDE;
};



/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
/*
 * The package has a set of standard channels with default values. These
 * are setup at the start using the AddChannel interface.
 */
#define Cs_ACTSAFE_ENABLE	"actionOn"
#define Cs_ACTSAFE_HBORDER	"actHBorder"
#define Cs_ACTSAFE_VBORDER	"actVBorder"

#define Cs_TITSAFE_ENABLE	"titleOn"
#define Cs_TITSAFE_HBORDER	"titHBorder"
#define Cs_TITSAFE_VBORDER	"titVBorder"

#define Cs_COLOR		"color"
#define Cs_STYLE		"style"
#define Cs_ALPHA		"overlayAlpha"
#define Cs_THIRDS		"thirds"

LXtTagInfoDesc	 CPackage::descInfo[] = {
//	{ LXsPKG_SUPERTYPE,		LXsITYPE_LOCATOR	},
        { 0 }
};


        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (Cs_ACTSAFE_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);
        ac.NewChannel  (Cs_ACTSAFE_HBORDER,	LXsTYPE_PERCENT); // BORDER WIDTH AS PERCENT
        ac.SetDefault  (0.1, 0);
        ac.NewChannel  (Cs_ACTSAFE_VBORDER,	LXsTYPE_PERCENT); // BORDER height AS PERCENT
        ac.SetDefault  (0.1, 0);

        ac.NewChannel  (Cs_TITSAFE_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);
        ac.NewChannel  (Cs_TITSAFE_HBORDER,	LXsTYPE_PERCENT); 
        ac.SetDefault  (0.2, 0);
        ac.NewChannel  (Cs_TITSAFE_VBORDER,	LXsTYPE_PERCENT);
        ac.SetDefault  (0.2, 0);

        ac.NewChannel  (Cs_ALPHA,	LXsTYPE_PERCENT); // radial boost to rotation
        ac.SetDefault  (0.50, 0);

        ac.NewChannel  (Cs_THIRDS,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 0);

        return LXe_OK;
}

/*
 * TestInterface() is required so that nexus knows what interfaces instance
 * of this package support. Necessary to prevent query loops.
 */
        LxResult
CPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return inst_spawn.TestInterfaceRC (guid);
}

/*
 * Attach is called to create a new instance of this item. The returned
 * object implements a specific item of this type in the scene.
 */
        LxResult
CPackage::pkg_Attach (
        void		       **ppvObj)
{
        CInstance		*inst = inst_spawn.Alloc (ppvObj);

        inst->src_pkg = this;
        return LXe_OK;
}


/*
 * ----------------------------------------------------------------
 * Item Instance
 *
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
        LxResult
CInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{

        m_item.set (item);

        CLxUser_SceneService	 svcScene;
        CLxUser_Scene		 scene;
        m_item.GetContext (scene);
        camType = svcScene.ItemType (LXsITYPE_CAMERA);
/*	if (scene.GetItem (camType, 0, m_cam)) {
                CLxUser_ChannelRead	 rchan;
                CLxUser_Scene		 scene;
                CLxUser_Matrix		 xfrm;

                unsigned		 index;
                if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_XFRMCORE_WORLDMATRIX, &index))) {
                        m_item.GetContext (scene);
                        scene.GetChannels (rchan, 0.0);
                        if (!rchan.Object (m_cam, index, xfrm)) {
                                xfrm.Get4 (camXfrm);
                                xfrm.GetOffset (camPos);
                        }
                }	
        } */


        return LXe_OK;
}


        int
CInstance::readCameraChannels ( 
        CLxUser_ChannelRead	 chan,
        CameraInfo		*camInfo) 
{
        unsigned	index, n=0;
        if (!m_cam.test())
                return 0;

        if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_CAMERA_APERTUREX, &index))) {
                camInfo->apertureX = chan.FValue (m_cam, index);
                n++;
        }
        if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_CAMERA_APERTUREY, &index))) {
                camInfo->apertureY = chan.FValue (m_cam, index);
                n++;
        }
        if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_CAMERA_FOCALLEN, &index))) {
                camInfo->focalLength = chan.FValue (m_cam, index);
                n++;
        }
        if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_CAMERA_FOCUSDIST, &index))) {
                camInfo->focusDist = chan.FValue (m_cam, index);
                n++;
        }
        if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_CAMERA_FSTOP, &index))) {
                camInfo->fStop = chan.FValue (m_cam, index);
                n++;
        }
        if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_CAMERA_IODIST, &index))) {
                camInfo->eyeSep = chan.FValue (m_cam, index);
                n++;
        }
        if (LXx_OK(m_cam.ChannelLookup (LXsICHAN_CAMERA_CONVDIST, &index))) {
                camInfo->convergenceDist = chan.FValue (m_cam, index);
                n++;
        }
        return n;
}

        void
CInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

        LxResult
CInstance::vitm_Draw (
        ILxUnknownID	 itemChanRead,
        ILxUnknownID	 viewStrokeDraw,
        int		 selectionFlags,
        LXtVector	 itemColor)
{
        CLxUser_View		 viewMap (viewStrokeDraw);

        if (viewMap.Type () != LXiVIEWv_CAMERA)
                return LXe_OK;

        CLxUser_ChannelRead	 chan (itemChanRead);
        CLxLoc_StrokeDraw	 strokeDraw (viewStrokeDraw);
        LXtVector		 nrm, pos, quad[4], tRGB,aRGB;
        double			 dx, dy, zoomX=0, zoomY=0, alpha;
        CameraInfo		 ci = {0,0,0,0,0,0,0};
        bool			 titOn, actOn, gridOn;
        float			 actXBord=0, actYBord=0;
        float			 titXBord=0, titYBord=0;

        actOn = 0 != chan.IValue (m_item, Cs_ACTSAFE_ENABLE);
        if (actOn) {
                actXBord = chan.FValue (m_item, Cs_ACTSAFE_HBORDER);
                actYBord = chan.FValue (m_item, Cs_ACTSAFE_VBORDER);
        }
        titOn = 0 != chan.IValue (m_item, Cs_TITSAFE_ENABLE);
        if (titOn) {
                titXBord = chan.FValue (m_item, Cs_TITSAFE_HBORDER);
                titYBord = chan.FValue (m_item, Cs_TITSAFE_VBORDER);
        }
        alpha = chan.FValue (m_item, Cs_ALPHA);

        gridOn = 0 != chan.IValue (m_item, Cs_THIRDS);

        LXx_VSET3 (aRGB, 0.8, 0.7, 0.2);
        LXx_VSET3 (tRGB, 0.4, 0.6, 0.3);
        //if(selectionFlags&LXiSELECTION_SELECTED) {
        //}

        LXx_VCLR (pos);
        LXx_VCLR (nrm);
        
        if (m_item.IsA (camType))
                m_cam = m_item;
        else if (m_item.GetParent (m_cam)) {
                if (!m_cam.IsA (camType))
                        return LXe_OK; 
        }

        if (!m_cam.test())
                return LXe_OK; 

        readCameraChannels (chan, &ci);
        pos[2] = ci.focusDist;
        pos[2] = LXxMAX (pos[2], ci.focalLength);
                
        // F.o.V. half angle: tan(a) =  half-sensor / foc. len = (apX/2) / flen
        // tan(a) also = (w/2) / foc. dist ==> w/2 = fdist * tan(a)
        zoomX = 0.5 / ci.focalLength; //foc. dist over foc. len
        zoomY = zoomX * ci.apertureY;
        zoomX *= ci.apertureX;

        if (actOn) {
                strokeDraw.BeginWD (LXiSTROKE_LINE_STRIP, aRGB, alpha, 1, LXiLPAT_DASH);
                dx = (1.0 - actXBord) * pos[2] * zoomX; // w/2
                dy = (1.0 - actYBord) * pos[2] * zoomY; // h/2

                LXx_VSET3 (quad[0], dx, dy, -pos[2]);
                LXx_VSET3 (quad[1], dx, -dy, -pos[2]);
                LXx_VSET3 (quad[2], -dx, -dy, -pos[2]);
                LXx_VSET3 (quad[3], -dx, dy, -pos[2]);
                strokeDraw.Vertex (quad[0], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[1], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[2], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[3], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[0], LXiSTROKE_ABSOLUTE);
        }
        if (titOn) {
                strokeDraw.BeginWD (LXiSTROKE_LINE_STRIP, tRGB, alpha, 1, LXiLPAT_DASHLONG);
                dx = (1.0 - titXBord) * pos[2] * zoomX; // w/2
                dy = (1.0 - titYBord) * pos[2] * zoomY; // h/2

                LXx_VSET3 (quad[0], dx, dy, -pos[2]);
                LXx_VSET3 (quad[1], dx, -dy, -pos[2]);
                LXx_VSET3 (quad[2], -dx, -dy, -pos[2]);
                LXx_VSET3 (quad[3], -dx, dy, -pos[2]);

                strokeDraw.Vertex (quad[0], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[1], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[2], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[3], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[0], LXiSTROKE_ABSOLUTE);
        }
        if (gridOn) {
                float		 w,h,third = 1.0/3;
                strokeDraw.BeginWD (LXiSTROKE_LINES, itemColor, alpha, 1, LXiLPAT_DOTS);
                w = pos[2] * zoomX;
                h = pos[2] * zoomY;
                dx = third * w;
                dy = third * h;

                LXx_VSET3 (quad[0], -w, dy, -pos[2]);
                LXx_VSET3 (quad[1],  w, dy, -pos[2]);
                strokeDraw.Vertex (quad[0], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[1], LXiSTROKE_ABSOLUTE);
                LXx_VSET3 (quad[0], -w, -dy, -pos[2]);
                LXx_VSET3 (quad[1],  w, -dy, -pos[2]);
                strokeDraw.Vertex (quad[0], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[1], LXiSTROKE_ABSOLUTE);

                LXx_VSET3 (quad[2], -dx, -h, -pos[2]);
                LXx_VSET3 (quad[3], -dx,  h, -pos[2]);
                strokeDraw.Vertex (quad[2], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[3], LXiSTROKE_ABSOLUTE);
                LXx_VSET3 (quad[2],  dx, -h, -pos[2]);
                LXx_VSET3 (quad[3],  dx,  h, -pos[2]);
                strokeDraw.Vertex (quad[2], LXiSTROKE_ABSOLUTE);
                strokeDraw.Vertex (quad[3], LXiSTROKE_ABSOLUTE);
        }

        return LXe_OK;
}



/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackage>;
        srv->AddInterface (new CLxIfc_Package   <CPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc<CPackage>);
        lx::AddServer (SRVNAME_ITEMTYPE, srv);

        srv = new CLxPolymorph<CInstance>;
        srv->AddInterface (new CLxIfc_PackageInstance<CInstance>);
        srv->AddInterface (new CLxIfc_ViewItem3D     <CInstance>);
        lx::AddSpawner (SPWNAME_INSTANCE, srv);
}

        void
cleanup ()
{
}


        };	// END namespace


