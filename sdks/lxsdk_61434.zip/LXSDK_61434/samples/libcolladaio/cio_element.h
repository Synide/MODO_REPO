/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */
#ifndef CIO_ELEMENT_H
#define CIO_ELEMENT_H

#include "cio_strings.h"
#include "cio_math.h"

#include <string>
#include <vector>
#include <set>

#include "../libtinyxml/tinyxml.h"

/*
 * Disable symbol length warning for STL.
 */
#pragma warning(disable: 4786)

namespace cio {

typedef enum en_CIO_EXCEPTION
{
        CIO_CORRUPT_ELEMENT_VALUE
} CIO_EXCEPTION;

/*
 * Local types for TinyXML elements and handles.
 */
#define ElementXML			 TiXmlElement
#define HandleXML			 TiXmlHandle

typedef ElementXML			*ElementXMLID;
typedef std::vector<ElementXMLID>	 ElementXMLList;

/*
 * Either a tree is loaded and Elements are linked to their nodes,
 * or a tree of elements and nodes is created and then saved. IO_MODE
 * selects which of these two modes is used in the internal class constructors.
 */
typedef enum en_IO_MODE
{
        IO_MODE_LOAD,
        IO_MODE_SAVE,
        IO_MODE_TALLY
} IO_MODE;

/*
 * ---------------------------------------------------------------------------
 * Generic COLLADA I/O operations.
 */
class Element
{
        friend class COLLADAElement;
        friend class AssetElement;
        friend class ExtraElement;
        friend class TechniqueCommonElement;
        friend class TransformAnimationElement;
        friend class ParamAnimationElement;

    public:
                                 Element (
                                        class pv_Element	*parentpv);

/*
 * [TODO] Restore protected access once all uses of COLLADASceneSaver::io are removed.
 */
//    protected:
                                 Element (
                                        IO_MODE			 io_Mode,
                                        bool			 formattedArrays);

    public:
        virtual			~Element ();

        /*
         * -------------------------------------------------------------------
         * Getting, Setting, and Adding Elements.
         */

                                /*
                                 * Indirect accessor for safely walking node
                                 * trees without NULL checks.
                                 */
        HandleXML		 GetElementHandle () const;
        HandleXML		 GetElementHandle (ElementXML *element) const;

                                /*
                                 * Direct accessor for the underlying XML node
                                 * element.
                                 *
                                 * Use GetElementHandle to safely walk node
                                 * hierarchies without NULL checks.
                                 */
        ElementXML *		 GetElement () const;

                                 /*
                                  * Returns the name of the element, as in:
                                  *
                                  * <foo name="hello">bar</foo>
                                  *
                                  * for which GetElementName returns "foo".
                                  *
                                  * NOTE: Not to be confused with
                                  *       GetElementValue or GetName.
                                  *
                                  * Call GetElementValue to get the value of
                                  * the element, which is "bar" in the above
                                  * example.
                                  *
                                  * Call GetName to get the value of the
                                  * name attribute, which is "hello" in the
                                  * above example.
                                  */
        const std::string	 GetElementName () const;

                                /*
                                 * SetElement is the key function by which the
                                 * underlying XML implementation is bound to
                                 * the transient Element class and its sub-
                                 * classes. Since the "real" data is actually
                                 * in the XML DB, the Element class instance
                                 * hierarchy uses reference lifetime management
                                 * and is transient in nature, serving only as
                                 * a wrapper to abstract away the details for
                                 * accessors and modifiers.
                                 */
        void			 SetElement (ElementXML *element);

        ElementXML *		 AddElement (
                                        const std::string	&elementName,
                                        unsigned		 index = 0);

        ElementXML *		 AddElement (
                                        const char		*elementName,
                                        unsigned		 index = 0);

        ElementXML *		 AddElement (
                                        ElementXML		*element,
                                        const std::string	&elementName,
                                        unsigned		 index = 0);

                                 /*
                                  * Inserts in front of previously
                                  * added elements.
                                  */
        ElementXML *		 InsertFirstElement (
                                        const std::string	&elementName);

        ElementXML *		 InsertFirstElement (
                                        const char		*elementName);

        ElementXML *		 InsertFirstElement (
                                        ElementXML		*element,
                                        const std::string	&elementName);

        bool			 HasChildElement (
                                        const std::string	&elementName) const;

        bool			 LinkFirstChildElement (
                                        const std::string	&elementName,
                                        Element			&child) const;

        bool			 LinkFirstChildElement (
                                        const std::string	&elementName,
                                        const std::string	&ID,
                                        Element			&child) const;

        unsigned		 GetChildCount () const;

        bool			 HasGrandchildElement (
                                        const std::string	&childElementName,
                                        const std::string	&grandchildElementName) const;

        bool			 LinkGrandchildElement (
                                        const std::string	&childElementName,
                                        const std::string	&grandchildElementName,
                                        Element			&child) const;

        bool			 HasTechniqueProfile (
                                        const std::string	&profile) const;

        bool			 HasExtraTechniqueProfile (
                                        const std::string	&profile) const;

        bool			 LinkTechniqueProfile (
                                        const std::string	&profile,
                                        Element			&technique) const;

        bool			 LinkExtraTechniqueProfile (
                                        const std::string	&profile,
                                        Element			&technique) const;

        bool			 LinkNextSiblingElement (
                                        const std::string	&elementName,
                                        Element			&link) const;

        /*
         * -------------------------------------------------------------------
         * Attribute values.
         */

        std::string		 GetID () const;
        std::string		 GetID (ElementXML *element) const;
        void			 SetID (const std::string	&ID);
        void			 SetID (ElementXML		*element,
                                        const std::string	&ID);

        std::string		 GetSID () const;
        std::string		 GetSID (ElementXML *element) const;
        void			 SetSID (const std::string	&SID);
        void			 SetSID (ElementXML		*element,
                                        const std::string	&SID);

        std::string		 GetName () const;
        std::string		 GetName (ElementXML *element) const;
        void			 SetName (const std::string	&name);
        void			 SetName (
                                        ElementXML		*element,
                                        const std::string	&name);

        std::string		 GetType () const;
        void			 SetType (const std::string	&type);
        void			 SetType (
                                        ElementXML		*element,
                                        const std::string	&type);

        std::string		 GetURL () const;
        void			 SetURL (const std::string	&url);
        void			 SetURL (
                                        ElementXML		*element,
                                        const std::string	&url);

        bool			 HasAttribute (const std::string &attributeName) const;
        bool			 HasAttribute (
                                        ElementXML		*element,
                                        const std::string	&attributeName) const;

        std::string		 GetAttribute (const std::string &attributeName) const;
        std::string		 GetAttribute (
                                        ElementXML		*element,
                                        const std::string	&attributeName) const;
        void			 SetAttribute (
                                        const char		*attributeName,
                                        const std::string	&value);

        unsigned		 GetAttributeUnsigned (
                                        const std::string	&attributeName) const;
        unsigned		 GetAttributeUnsigned (
                                        ElementXML		*element,
                                        const std::string	&attributeName) const;
        void			 SetAttribute (
                                        const char		*attributeName,
                                        unsigned		value);

        void			 SetAttribute (
                                        const char		*attributeName,
                                        int			 value);

        void			 SetAttribute (
                                        const char		*attributeName,
                                        double			value);

        void			 SetAttribute (
                                        ElementXML		*element,
                                        const char		*attributeName,
                                        const std::string	&value);

        void			 SetAttribute (
                                        ElementXML		*element,
                                        const char		*attributeName,
                                        const char		*value);

        void			 SetAttribute (
                                        ElementXML		*element,
                                        const char		*attributeName,
                                        unsigned		value);

#if defined(_WIN64) || defined(_MACOS) || defined(_LINUX)
        void			 SetAttribute (
                                        ElementXML		*element,
                                        const char		*attributeName,
                                        size_t			 value);
#endif

        void			 SetAttribute (
                                        ElementXML		*element,
                                        const char		*attributeName,
                                        int			 value);

        void			 SetAttribute (
                                        ElementXML		*element,
                                        const char		*attributeName,
                                        double			value);

        /*
         * Element values.
         */
        std::string		 GetElementValue () const;
        void			 SetElementValue (
                                        const std::string	&value);

        std::string		 GetElementValue (
                                        ElementXML		*element) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const std::string	&value);

        void			 SetElementValue (
                                        ElementXML		*element,
                                        const char		*value);

        bool			 GetElementValueBool (
                                        ElementXML		*element) const;

        void			 SetElementValue (
                                        ElementXML		*element,
                                        bool			 value);

        typedef std::vector<bool> BoolArray;

        void			 GetElementValue (
                                        ElementXML		*element,
                                        BoolArray		&values) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const BoolArray		&values);

        unsigned		 GetElementValueUnsigned (
                                        ElementXML		*element) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        unsigned		 value);

        typedef std::vector<unsigned> UnsignedArray;

        void			 GetElementValue (
                                        ElementXML		*element,
                                        UnsignedArray		&values) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const UnsignedArray	&values);

        float			 GetElementValueFloat (
                                        ElementXML		*element) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        float			 value);

        double			 GetElementValueDouble (
                                        ElementXML		*element) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        double			 value);

        typedef double           DoubleVector3[3];
        typedef DoubleVector3	 ColorRGB;

        void			 SetElementValue (
                                        ElementXML		*element,
                                        const DoubleVector3	&value);

        typedef double           DoubleVector4[4];
        typedef DoubleVector4	 ColorRGBA;

        void			 SetElementValue (
                                        ElementXML		*element,
                                        const DoubleVector4	&value);

        typedef std::vector<float> FloatArray;
        typedef std::set<float>    FloatSet;

        void			 GetElementValue (
                                        ElementXML		*element,
                                        FloatArray		&values) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const FloatArray	&values,
                                        unsigned		 stride = 1);

        typedef std::vector<double> DoubleArray;
        typedef std::set<double>    DoubleSet;

        void			 GetElementValue (
                                        ElementXML		*element,
                                        DoubleArray		&values) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const DoubleArray	&values,
                                        unsigned		 stride = 1);

        void			 GetElementValue (
                                        ElementXML		*element,
                                        FloatArray		&valuesA,
                                        FloatArray		&valuesB) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const FloatArray	&valuesA,
                                        const FloatArray	&valuesB);

        void			 GetElementValue (
                                        ElementXML		*element,
                                        FloatArray		&valuesA,
                                        FloatArray		&valuesB,
                                        FloatArray		&valuesC) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const FloatArray	&valuesA,
                                        const FloatArray	&valuesB,
                                        const FloatArray	&valuesC);

        typedef enum en_Interpolation {
                INTERPOLATION_LINEAR,
                INTERPOLATION_BEZIER,
                INTERPOLATION_BSPLINE,
                INTERPOLATION_HERMITE,
                INTERPOLATION_STEP
        } Interpolation;

        typedef std::vector<Interpolation> InterpArray;

        void			 GetElementValue (
                                        ElementXML		*element,
                                        InterpArray		&values) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const InterpArray	&values);

        void			 GetElementValue (
                                        ElementXML		*element,
                                        StringArray		&values) const;
        void			 SetElementValue (
                                        ElementXML		*element,
                                        const StringArray	&values);

        /*
         * Matrix and matrix array.
         */
        bool			 GetElementValue (
                                        ElementXML			*element,
                                        math::Matrix4			&matrix) const;
        void			 SetElementValue (
                                        ElementXML			*element,
                                        const math::Matrix4		&matrix);
        bool			 GetElementValue (
                                        ElementXML			*element,
                                        math::Matrix4Array		&matrixArray) const;
        void			 SetElementValue (
                                        ElementXML			*element,
                                        const math::Matrix4Array	&matrixArray);

        /*
         * Get/Set element value, with element create.
         */
        bool			 GetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        std::string		&value) const;
        void			 SetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        const std::string	&value);

        bool			 GetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        StringArray		&value) const;
        void			 SetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        const StringArray	&value);

        bool			 GetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        bool			&value) const;
        void			 SetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        bool			 value);

        bool			 GetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        unsigned		&value) const;
        void			 SetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        unsigned		 value);

        bool			 GetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        double			&value) const;
        void			 SetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        double			 value);

        bool			 GetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        ColorRGB		&value) const;
        void			 SetElementValue (
                                        ElementXML		**subElement,
                                        const std::string	&elementName,
                                        const ColorRGB		&value);

        bool			 GetParamValue (
                                        ElementXML		*paramParentElement,
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        bool			&value);
        void			 SetParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        bool			 value);

        bool			 GetParamValue (
                                        ElementXML		*paramParentElement,
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        unsigned		&value);
        void			 SetParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        unsigned		 value);

        bool			 GetParamValue (
                                        ElementXML		*paramParentElement,
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        double			&value);
        void			 SetParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        double			 value);

        bool			 GetParamValue (
                                        ElementXML		*paramParentElement,
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        std::string		&value);
        void			 SetParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        const std::string	&value,
                                        bool			 suppressNameType = false);

        void			 SetBoundParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&parentElementName,
                                        const std::string	&paramSID,
                                        bool			 value,
                                        bool			 suppressNameType = false);

        void			 SetBoundParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&parentElementName,
                                        const std::string	&paramSID,
                                        double			 value,
                                        bool			 suppressNameType = false);

        void			 SetBoundParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&parentElementName,
                                        const std::string	&paramSID,
                                        unsigned		 value,
                                        bool			 suppressNameType = false);

        void			 SetBoundParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&parentElementName,
                                        const std::string	&paramSID,
                                        const std::string	&value,
                                        bool			 suppressNameType = false);

        void			 SetBoundParamValue (
                                        ElementXML		**paramElement,
                                        const std::string	&parentElementName,
                                        const std::string	&paramSID,
                                        const Element::ColorRGB	&value,
                                        bool			 suppressNameType = false);

        void			 ClearElementValue ();
        void			 ClearElementValue (ElementXML *element);

    protected:
        class ElementParamBind * GetElementParamBind () const;
        IO_MODE			 GetIOMode () const;

        class pv_Element *	 PV () const;

    private:
        class pv_Element	*pv;
};


} // namespace cio

#endif // CIO_ELEMENT_H

