/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_element.h"
#include "cio_bind.h"
#include "cio_registrar.h"
#include "cio_format.h"
#include "cio_schema.h"
#include "cio_strings.h"
#include "cio_animation.h"
#include "cio_asset.h"
#include "cio_camera.h"
#include "cio_effect.h"
#include "cio_image.h"
#include "cio_geometry.h"
#include "cio_light.h"
#include "cio_material.h"
#include "cio_node.h"
#include "cio_profiles.h"
#include "cio_shadernode.h"
#include "cio_visualscene.h"
#include "cio_scene.h"

#include <string>

/*
 * Bring in std::transform
 */
#include <algorithm>

using namespace std;

namespace cio {

#define COLLADAdocument		TiXmlDocument
#define HandleXML		TiXmlHandle

namespace {

const char* CARRIAGE_RETURN		= "\n";	

        bool
IsBlank (
        char			 c)
{
        return (c == ' ' || c == '\t' || c == '\n');
}

        void
PullWhite (
        const string		&text,
        string::const_iterator	&iter)
{
        while ((iter != text.end ()) && IsBlank (*iter))
                iter++;
}

        string
PullNonWhite (
        const string		&text,
        string::const_iterator	&iter)
{
        string nonWhite;
        while ((iter != text.end ()) && !IsBlank (*iter)) {
                nonWhite += (*iter++);
        }

        return nonWhite;
}

        bool
PullName (
        const string		&text,
        string::const_iterator	&iter,
        string			&name)
{
        bool	pulled(false);
        PullWhite (text, iter);
        string arrayItem = PullNonWhite (text, iter);
        if (!arrayItem.empty ()) {
                name = arrayItem;
                pulled = true;
        }

        return pulled;
}

        bool
PullNum (
        const string		&text,
        string::const_iterator	&iter,
        float			&value)
{
        bool	pulled(false);
        PullWhite (text, iter);
        string arrayItem = PullNonWhite (text, iter);
        if (!arrayItem.empty ()) {
                value = static_cast<float>(atof (arrayItem.c_str ()));
                pulled = true;
        }

        return pulled;
}

        bool
PullNum (
        const string		&text,
        string::const_iterator &iter,
        double			&value)
{
        bool	pulled(false);
        PullWhite (text, iter);
        string arrayItem = PullNonWhite (text, iter);
        if (!arrayItem.empty ()) {
                value = atof (arrayItem.c_str ());
                pulled = true;
        }

        return pulled;
}

        static bool
IsDigit (
        char			 c)
{
        return (c >= '0' && c <= '9');
}

/*
 * Special version of white-space stripper for number parsing,
 * that throws an exception for non-white, non-numeric input.
 */
        void
PullNonDigit (
        const string		&text,
        string::const_iterator	&iter)
{
        while ((iter != text.end ()) && IsBlank (*iter))
                iter++;

        if (iter != text.end () && !IsDigit (*iter)) {
                throw CIO_CORRUPT_ELEMENT_VALUE;
        }
}

        string
PullDigits (
        const string		&text,
        string::const_iterator	&iter)
{
        string digits;
        while ((iter != text.end ()) && IsDigit (*iter)) {
                digits += (*iter++);
        }

        return digits;
}

        bool
PullNum (
        const string		&text,
        string::const_iterator	&iter,
        unsigned		&value)
{
        bool	pulled(false);
        PullNonDigit (text, iter);
        string arrayItem = PullDigits (text, iter);
        if (!arrayItem.empty ()) {
                value = atoi (arrayItem.c_str ());
                pulled = true;
        }

        return pulled;
}

        bool
IsTrue (
        const string		&text)
{
        string value(text);

        /*
         * Convert to lowercase for comparison against "true".
         */
        std::transform (
                value.begin (),
                value.end (),
                value.begin (),
                (int(*)(int))tolower);

        return (value == string("true"));
}

} // namespace

/*
 * ---------------------------------------------------------------------------
 * Generic COLLADA I/O operations.
 */

class pv_Element
{
        friend class Element;

    protected:
        pv_Element (
                IO_MODE			 io_Mode,
                ElementParamBind	*bind,
                int			 lastErr,
                bool			 areArraysFormatted,
                unsigned		 lastIndent)
                :
                ioMode(io_Mode),
                element(NULL),
                bindOwner(false),
                elementParamBind(bind),
                error(lastErr),
                formattedArrays(areArraysFormatted),
                indent(lastIndent)
        {
        }

        pv_Element (
                IO_MODE		 io_Mode,
                int			 lastErr,
                bool			 areArraysFormatted,
                unsigned		 lastIndent)
                :
                ioMode(io_Mode),
                element(NULL),
                bindOwner(true),
                elementParamBind(new ElementParamBind()),
                error(lastErr),
                formattedArrays(areArraysFormatted),
                indent(lastIndent)
        {
                ElementParamRegistrar	registrar(*elementParamBind);
        }

        virtual ~pv_Element ()
        {
                if (bindOwner) {
                        delete elementParamBind;
                }
        }

        IO_MODE		GetIOMode () const
        {
                return ioMode;
        }

        ElementXML *	GetElement () const
        {
                return element;
        }

        void			SetElement (ElementXML *anElement)
        {
                element = anElement;
        }

        ElementParamBind * GetElementParamBind () const
        {
                return elementParamBind;
        }

        string			FormatArrayPrefix ()
        {
                string arrayText;
                if (FormattedArrays ()) {
                        arrayText += string(CARRIAGE_RETURN) + IndentArraySpaces ();
                }

                return arrayText;
        }

        void			FormatArrayEntry (
                                        string		&arrayText,
                                        bool		 notOnLastItem)
        {
                if (notOnLastItem) {
                        if (FormattedArrays ()) {
                                arrayText += string(CARRIAGE_RETURN) + IndentArraySpaces ();
                        }
                        else {
                                arrayText += string(ATTRVALUE_SPACE);
                        }
                }
                else if (FormattedArrays ()) {
                        arrayText += string(CARRIAGE_RETURN) + IndentSpaces ();
                }
        }

        int			LastError () const
        {
                return error;
        }

        bool			FormattedArrays () const
        {
                return formattedArrays;
        }

        unsigned		Indent () const
        {
                return indent;
        }

    private:

        static string		BuildSpaces (unsigned indentLevel)
        {
                const unsigned SPACES_PER_INDENT = 4;

                string spaces;
                for (unsigned spaceIndex = 0;
                     spaceIndex < indentLevel * SPACES_PER_INDENT;
                     ++spaceIndex) {
                        spaces += " ";
                }

                return spaces;
        }

        string			IndentSpaces () const
        {
                return BuildSpaces (NextIndent ());
        }

        string			IndentArraySpaces () const
        {
                return BuildSpaces (NextIndent () + 1);
        }

 	unsigned		NextIndent () const
        {
                return indent + 1;
        }

        IO_MODE			 ioMode;
        ElementXML		*element;

        /*
         * State used in IO_MODE_SAVE mode.
         */
        bool			 bindOwner;
        ElementParamBind	*elementParamBind;
        int			 error;
        bool			 formattedArrays;
        unsigned		 indent;
};

Element::Element (pv_Element *parentpv)
        :
        pv(new pv_Element (
                parentpv->GetIOMode (),
                parentpv->GetElementParamBind (),
                parentpv->LastError (),
                parentpv->FormattedArrays (),
                parentpv->Indent () + 1))
{
}

Element::Element (
        IO_MODE		 io_Mode,
        bool		 formattedArrays)
        :
        pv(new pv_Element (io_Mode, 0, formattedArrays, 0))
{
}

Element::~Element ()
{
        delete pv;
}

/*
 * Indirect accessor for safely walking node trees without NULL checks.
 */
        HandleXML
Element::GetElementHandle () const
{
        return HandleXML(GetElement ());
}

        HandleXML
Element::GetElementHandle (ElementXML *element) const
{
        return HandleXML(element);
}

/*
 * Direct accessor for the underlying XML node element.
 *
 * Use GetElementHandle to safely walk node hierarchies without NULL checks.
 */
        ElementXML *
Element::GetElement () const
{
        return pv->GetElement ();
}

 /*
  * Returns the name of the element, as in:
  *
  * <foo name="hello">bar</foo>
  *
  * for which GetElementName returns "foo".
  *
  * NOTE: Not to be confused with
  *       GetElementValue or GetName.
  *
  * Call GetElementValue to get the value of
  * the element, which is "bar" in the above
  * example.
  *
  * Call GetName to get the value of the
  * name attribute, which is "hello" in the
  * above example.
  */
        const string
Element::GetElementName () const
{
        string	name;
        if (pv->GetElement ()) {
                name = pv->GetElement ()->ValueStr ();
        }

        return name;
}

/*
 * SetElement is the key function by which the underlying XML implementation
 * is bound to the transient Element class and its subclasses. Since the
 * "real" data is actually in the XML DB, the Element class instance
 * hierarchy uses reference lifetime management and is transient in nature,
 * serving only as a wrapper to abstract away the details for accessors and
 * modifiers.
 */
        void
Element::SetElement (ElementXML *element)
{
        pv->SetElement (element);
}

        ElementXML *
Element::AddElement (
        const string		&elementName,
        unsigned		 index)
{
        return AddElement (pv->GetElement (), elementName.c_str (), index);
}

/*
 *
 */
        ElementXML*
Element::AddElement (
        const char		*elementName,
        unsigned		 index)
{
        return AddElement (pv->GetElement (), elementName, index);
}

/*
 *
 */
        ElementXML*
Element::AddElement (
        ElementXML		*element,
        const string		&elementName,
        unsigned		 index)
{
        ElementXML		*newElement;

        newElement = new ElementXML (elementName);
        element->LinkEndChild (newElement);

        return newElement;
}

        ElementXML *
Element::InsertFirstElement (
        const string		&elementName)
{
        return InsertFirstElement (pv->GetElement (), elementName.c_str ());
}

/*
 *
 */
        ElementXML*
Element::InsertFirstElement (
        const char		*elementName)
{
        return InsertFirstElement (pv->GetElement (), elementName);
}

/*
 *
 */
        ElementXML*
Element::InsertFirstElement (
        ElementXML		*element,
        const string		&elementName)
{
        ElementXML		*newElement;

        newElement = new ElementXML (elementName);
        element->LinkFirstChild (newElement);

        return newElement;
}

        bool
Element::HasChildElement (
        const string		&elementName) const
{
        return (GetElementHandle ().FirstChildElement (
                elementName).Element () != NULL);
}

        bool
Element::LinkFirstChildElement (
        const string		&elementName,
        Element			&child) const
{
        bool	linked(false);
        ElementXML *childElem = GetElementHandle ().FirstChildElement (
                elementName).Element ();
        if (childElem) {
                child.SetElement (childElem);
                linked = true;
        }

        return linked;
}

        bool
Element::LinkFirstChildElement (
        const string		&elementName,
        const string		&ID,
        Element			&child) const
{
        /*
         * Iterate over the this element's child elements, looking for
         * an element with a matching ID.
         */
        bool	linked(false);
        ElementXML *childElem = GetElementHandle ().FirstChildElement (
                elementName).Element ();
        while (childElem) {
                if (GetID (childElem) == ID) {
                        child.SetElement (childElem);
                        linked = true;
                        break;
                }
                childElem = childElem->NextSiblingElement (elementName);
        }

        return linked;
}

/*
 * Calculates a shallow count of an element's sibling child elements.
 */
        unsigned
Element::GetChildCount () const
{
        unsigned count(0);

        /*
         * Find the first child and then count its siblings.
         */
        for (ElementXML *anElement = GetElement ()->FirstChildElement ();
             anElement;
             anElement = anElement->NextSiblingElement ()) {
                ++count;
        }

        return count;
}

        bool
Element::HasGrandchildElement (
        const string		&childElementName,
        const string		&grandchildElementName) const
{
        bool	found(false);
        ElementXML *childElement =
                GetElementHandle ().FirstChildElement (
                        childElementName).Element ();
        if (childElement) {
                found = (childElement->FirstChildElement (grandchildElementName) != NULL);
        }

        return found;
}

        bool
Element::LinkGrandchildElement (
        const string		&childElementName,
        const string		&grandchildElementName,
        Element			&child) const
{
        bool	linked(false);
        ElementXML *childElement =
                GetElementHandle ().FirstChildElement (
                        childElementName).Element ();
        if (childElement) {
                ElementXML *grandchildElement =
                        childElement->FirstChildElement (grandchildElementName);
                if (grandchildElement) {
                        child.SetElement (grandchildElement);
                        linked = true;
                }
        }

        return linked;
}

        bool
Element::HasTechniqueProfile (
        const string		&profile) const
{
        bool found(false);

        ElementXML *techniqueElement =
                GetElementHandle ().FirstChildElement (
                        ELEMENT_TECHNIQUE).Element ();
        while (techniqueElement && !found) {
                found = (GetAttribute (techniqueElement, ATTRIBUTE_PROFILE) == profile);
                if (!found) {
                        techniqueElement =
                                techniqueElement->NextSiblingElement (
                                        ELEMENT_TECHNIQUE);
                }
        }

        return found;
}

        bool
Element::HasExtraTechniqueProfile (
        const string		&profileName) const
{
        /*
         * The technique element that matches our profile is nested within
         * an extra element. We iterate over the extra elements to find the
         * named profile.
         */
        bool	found(false);
        ElementXML *extraElem = GetElementHandle ().FirstChildElement (
                ELEMENT_EXTRA).Element ();
        do {
                if (extraElem) {
                        ElementXML *techniqueElem =
                                extraElem->FirstChildElement (ELEMENT_TECHNIQUE);
                        do {
                                if (techniqueElem) {
                                        found = GetAttribute (
                                                techniqueElem, ATTRIBUTE_PROFILE) ==
                                                profileName;
                                        techniqueElem = techniqueElem->NextSiblingElement (
                                                ELEMENT_TECHNIQUE);
                                }
                        } while (techniqueElem && !found);
                        if (!found) {
                                extraElem = extraElem->NextSiblingElement (ELEMENT_EXTRA);
                        }
                }
        } while (extraElem && !found);

        return found;
}

        bool
Element::LinkTechniqueProfile (
        const string		&profile,
        Element			&technique) const
{
        bool linked(false);

        ElementXML *techniqueElement =
                GetElementHandle ().FirstChildElement (
                        ELEMENT_TECHNIQUE).Element ();
        while (techniqueElement && !linked) {
                linked = (GetAttribute (techniqueElement, ATTRIBUTE_PROFILE) == profile);
                if (linked) {
                        technique.SetElement (techniqueElement);
                }
                else {
                        techniqueElement =
                                techniqueElement->NextSiblingElement (
                                        ELEMENT_TECHNIQUE);
                }
        }

        return linked;
}

        bool
Element::LinkExtraTechniqueProfile (
        const string	&profileName,
        Element		&technique) const
{
        /*
         * The technique element that matches our profile is nested within
         * an extra element. We iterate over the extra elements to find the
         * named profile.
         */
        bool	linked(false);
        ElementXML *extraElem = GetElementHandle ().FirstChildElement (
                ELEMENT_EXTRA).Element ();
        do {
                if (extraElem) {
                        ElementXML *techniqueElem =
                                extraElem->FirstChildElement (ELEMENT_TECHNIQUE);
                        do {
                                if (techniqueElem) {
                                        linked = GetAttribute (
                                                techniqueElem, ATTRIBUTE_PROFILE) ==
                                                profileName;
                                        if (linked) {
                                                technique.SetElement (techniqueElem);
                                        }
                                        else {
                                                techniqueElem = techniqueElem->NextSiblingElement (ELEMENT_EXTRA);
                                        }
                                }
                        } while (techniqueElem && !linked);
                        if (!linked) {
                                extraElem = extraElem->NextSiblingElement (ELEMENT_EXTRA);
                        }
                }
        } while (extraElem && !linked);

        return linked;
}

        bool
Element::LinkNextSiblingElement (
        const string	&elementName,
        Element		&link) const
{
        bool foundNext(false);

        if (link.GetElement ()) {
                ElementXML *nextElem =
                        link.GetElement ()->NextSiblingElement (elementName);
                if (nextElem) {
                        link.SetElement (nextElem);
                        foundNext = true;
                }
        }

        return foundNext;
}

        string
Element::GetID () const
{
        return GetID (GetElement ());
}

        string
Element::GetID (ElementXML *element) const
{
        return GetAttribute (element, ATTRIBUTE_ID);
}

        void
Element::SetID (const string &ID)
{
        SetAttribute (ATTRIBUTE_ID, EscapeNCName (ID));
}

        void
Element::SetID (
        ElementXML		*element,
        const string		&ID)
{
        SetAttribute (element, ATTRIBUTE_ID, EscapeNCName (ID));
}

        string
Element::GetSID () const
{
        return GetAttribute (ATTRIBUTE_SID);
}

        string
Element::GetSID (ElementXML *element) const
{
        return GetAttribute (element, ATTRIBUTE_SID);
}

        void
Element::SetSID (const string &SID)
{
        SetAttribute (ATTRIBUTE_SID, EscapeNCName (SID));
}

        void
Element::SetSID (
        ElementXML		*element,
        const string		&SID)
{
        SetAttribute (element, ATTRIBUTE_SID, EscapeNCName (SID));
}

        string
Element::GetName () const
{
        return GetAttribute (ATTRIBUTE_NAME);
}

        string
Element::GetName (ElementXML *element) const
{
        return GetAttribute (element, ATTRIBUTE_NAME);
}

        void
Element::SetName (const string &name)
{
        SetAttribute (ATTRIBUTE_NAME, EscapeNCName (name));
}

        void
Element::SetName (
        ElementXML		*element,
        const string		&name)
{
        SetAttribute (element, ATTRIBUTE_NAME, EscapeNCName (name));
}

        string
Element::GetType () const
{
        return GetAttribute (ATTRIBUTE_TYPE);
}

        void
Element::SetType (const string &type)
{
        SetAttribute (ATTRIBUTE_TYPE, type);
}

        void
Element::SetType (
        ElementXML		*element,
        const string		&type)
{
        SetAttribute (element, ATTRIBUTE_TYPE, type);
}

        string
Element::GetURL () const
{
        return GetAttribute (ATTRIBUTE_URL);
}

        void
Element::SetURL (const string	&url)
{
        SetAttribute (ATTRIBUTE_URL, url);
}

        void
Element::SetURL (
        ElementXML		*element,
        const string		&url)
{
        SetAttribute (element, ATTRIBUTE_URL, url);
}

/*
 * @return If an attribute of the given name is present.
 */
        bool
Element::HasAttribute (const std::string &attributeName) const
{
        return pv->GetElement ()->Attribute (attributeName.c_str ()) != NULL;
}

/*
 * @return If an attribute of the given name is present.
 */
        bool
Element::HasAttribute (
        ElementXML		*element,
        const std::string	&attributeName) const
{
        return element->Attribute (attributeName.c_str ()) != NULL;
}

/*
 * @return The value of the attribute of the given name.
 *         Returns a default empty string if the attribute is not present.
 */
        string
Element::GetAttribute (const string &attributeName) const
{
        const char *attrValue = pv->GetElement ()->Attribute (attributeName.c_str ());
        if (attrValue) {
                return string(attrValue);
        }
        else {
                return string();
        }
}

        string
Element::GetAttribute (
        ElementXML		*element,
        const std::string	&attributeName) const
{
        const char *attrValue = element->Attribute (attributeName.c_str ());
        if (attrValue) {
                return string(attrValue);
        }
        else {
                return string();
        }
}

        void
Element::SetAttribute (
        const char		*attributeName,
        const string		&value)
{
        SetAttribute (GetElement (), attributeName, value);
}

        unsigned
Element::GetAttributeUnsigned (const std::string &attributeName) const
{
        return GetAttributeUnsigned (GetElement (), attributeName);
}

/*
 * @return The unsigned value of the attribute of the given name.
 *         Returns a default of zero if the attribute is not present.
 *         One may optionally call Element::HasAttribute to detect if
 *         the attribute is present.
 */
        unsigned
Element::GetAttributeUnsigned (
        ElementXML		*element,
        const std::string	&attributeName) const
{
        unsigned value = 0;

        string valueText = GetAttribute (element, attributeName);
        if (!valueText.empty ()) {
                value = atoi (valueText.c_str ());
        }

        return value;
}

        void
Element::SetAttribute (
        const char		*attributeName,
        unsigned		value)
{
        SetAttribute (pv->GetElement (), attributeName, value);
}

        void
Element::SetAttribute (
        const char		*attributeName,
        int			 value)
{
        SetAttribute (pv->GetElement (), attributeName, value);
}

        void
Element::SetAttribute (
        const char		*attributeName,
        double			value)
{
        SetAttribute (pv->GetElement (), attributeName, value);
}

        void
Element::SetAttribute (
        ElementXML		*element,
        const char		*attributeName,
        const char		*value)
{
        element->SetAttribute (attributeName, value);
}

        void
Element::SetAttribute (
        ElementXML		*element,
        const char		*attributeName,
        const string		&value)
{
        element->SetAttribute (attributeName, value.c_str ());
}

        void
Element::SetAttribute (
        ElementXML		*element,
        const char		*attributeName,
        unsigned		 value)
{
        SetAttribute (element, attributeName, IntegerToString (value));
}

#if defined(_WIN64) || defined(_MACOS) || defined(_LINUX)
        void
Element::SetAttribute (
        ElementXML		*element,
        const char		*attributeName,
        size_t			 value)
{
        SetAttribute (
                element,
                attributeName,
                IntegerToString (static_cast<unsigned>(value)));
}
#endif

        void
Element::SetAttribute (
        ElementXML		*element,
        const char		*attributeName,
        int			value)
{
        SetAttribute (element, attributeName, IntegerToString (value));
}

        void
Element::SetAttribute (
        ElementXML		*element,
        const char		*attributeName,
        double			value)
{
        SetAttribute (element, attributeName, DoubleToString (value));
}

        string
Element::GetElementValue () const
{
        return GetElementValue (GetElement ());
}

        void
Element::SetElementValue (
        const std::string	&value)
{
        SetElementValue (pv->GetElement(), value);
}

        string
Element::GetElementValue (
        ElementXML		*element) const
{
        string textStr;
        if (element) {
                const char *text = element->GetText ();
                if (text) {
                        textStr = string(text);
                }
        }

        return textStr;
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const std::string	&value)
{
        TiXmlText* elementText = new TiXmlText(value);
        element->LinkEndChild (elementText);
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const char		*value)
{
        TiXmlText* elementText = new TiXmlText(value);
        element->Clear();
        element->LinkEndChild (elementText);
}

        bool
Element::GetElementValueBool (
        ElementXML		*element) const
{
        return IsTrue (GetElementValue (element));
}

        void
Element::SetElementValue (
        ElementXML		*element,
        bool			 value)
{
        SetElementValue (element, BoolToString (value));
}

        void
Element::GetElementValue (
        ElementXML		*element,
        BoolArray		&values) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the boolean values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                string value;
                if (PullName (arrayText, iter, value)) {
                        values.push_back (IsTrue (value));
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const BoolArray		&values)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (BoolArray::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += BoolToString(*iter);

                pv->FormatArrayEntry (arrayText, iter + 1 != values.end());
        }

        SetElementValue (element, arrayText);
}

        unsigned
Element::GetElementValueUnsigned (
        ElementXML		*element) const
{
        unsigned value(0);
        string textStr;
        if (element) {
                const char *text = element->GetText ();
                if (text) {
                        value = atoi(text);
                }
        }

        return value;
}

        void
Element::SetElementValue (
        ElementXML		*element,
        unsigned		 value)
{
        SetElementValue (element, IntegerToString (value));
}

        void
Element::GetElementValue (
        ElementXML		*element,
        UnsignedArray		&values) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the float values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                unsigned value;
                if (PullNum (arrayText, iter, value)) {
                        values.push_back (value);
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const UnsignedArray	&values)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (UnsignedArray::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += IntegerToString(*iter);

                pv->FormatArrayEntry (arrayText, iter + 1 != values.end());
        }

        SetElementValue (element, arrayText);
}

        float
Element::GetElementValueFloat (
        ElementXML		*element) const
{
        float value(0.0f);
        string textStr;
        if (element) {
                const char *text = element->GetText ();
                if (text) {
                        value = static_cast<float>(atof(text));
                }
        }

        return value;
}

        void
Element::SetElementValue (
        ElementXML		*element,
        float			 value)
{
        SetElementValue (element, FloatToString (value));
}

        double
Element::GetElementValueDouble (
        ElementXML		*element) const
{
        double value(0.0);
        string textStr;
        if (element) {
                const char *text = element->GetText ();
                if (text) {
                        value = atof(text);
                }
        }

        return value;
}

        void
Element::SetElementValue (
        ElementXML		*element,
        double			 value)
{
        SetElementValue (element, DoubleToString (value));
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const DoubleVector3	&value)
{
        string vectorText;

        vectorText =
                DoubleToString (value[0]) +
                string(ATTRVALUE_SPACE) +
                DoubleToString (value[1]) +
                string(ATTRVALUE_SPACE) +
                DoubleToString (value[2]);

        SetElementValue (element, vectorText);
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const DoubleVector4	&value)
{
        string vectorText;

        vectorText =
                DoubleToString (value[0]) +
                string(ATTRVALUE_SPACE) +
                DoubleToString (value[1]) +
                string(ATTRVALUE_SPACE) +
                DoubleToString (value[2]) +
                string(ATTRVALUE_SPACE) +
                DoubleToString (value[3]);

        SetElementValue (element, vectorText);
}

        void
Element::GetElementValue (
        ElementXML		*element,
        FloatArray		&values) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the float values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                float value;
                if (PullNum (arrayText, iter, value)) {
                        values.push_back (value);
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const FloatArray	&values,
        unsigned		 stride)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (FloatArray::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                for (unsigned strideIndex = 0; strideIndex < stride; ++strideIndex) {
                        arrayText += DoubleToString(*iter);
                        if ((iter + 1 != values.end()) &&
                            (strideIndex < stride - 1)) {
                                arrayText += string(ATTRVALUE_SPACE);
                                ++iter;
                        }
                }
                bool notLastItem = (iter + 1 != values.end());
                pv->FormatArrayEntry (arrayText, notLastItem);
        }

        SetElementValue (element, arrayText);
}

        void
Element::GetElementValue (
        ElementXML		*element,
        DoubleArray		&values) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the float values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                double value;
                if (PullNum (arrayText, iter, value)) {
                        values.push_back (value);
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const DoubleArray	&values,
        unsigned		 stride)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (DoubleArray::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                for (unsigned strideIndex = 0; strideIndex < stride; ++strideIndex) {
                        arrayText += DoubleToString(*iter);
                        if ((iter + 1 != values.end()) &&
                            (strideIndex < stride - 1)) {
                                arrayText += string(ATTRVALUE_SPACE);
                                ++iter;
                        }
                }
                bool notLastItem = (iter + 1 != values.end());
                pv->FormatArrayEntry (arrayText, notLastItem);
        }

        SetElementValue (element, arrayText);
}

        void
Element::GetElementValue (
        ElementXML		*element,
        FloatArray		&valuesA,
        FloatArray		&valuesB) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the float values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                float value;
                if (PullNum (arrayText, iter, value)) {
                        valuesA.push_back (value);
                }
                if (iter != arrayText.end ()) {
                        if (PullNum (arrayText, iter, value)) {
                                valuesB.push_back (value);
                        }
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const FloatArray	&valuesA,
        const FloatArray	&valuesB)
{
        string arrayText(pv->FormatArrayPrefix ());
        FloatArray::const_iterator iterA;
        FloatArray::const_iterator iterB;
        for (iterA = valuesA.begin (), iterB = valuesB.begin ();
             iterA != valuesA.end () && iterB != valuesB.end ();
             ++iterA, ++iterB) {
                arrayText += FloatToString(*iterA);
                arrayText += string(ATTRVALUE_SPACE);
                arrayText += FloatToString(*iterB);

                pv->FormatArrayEntry (arrayText, iterA + 1 != valuesA.end());
        }

        SetElementValue (element, arrayText);
}

        void
Element::GetElementValue (
        ElementXML		*element,
        FloatArray		&valuesA,
        FloatArray		&valuesB,
        FloatArray		&valuesC) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the float values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                float value;
                if (PullNum (arrayText, iter, value)) {
                        valuesA.push_back (value);
                        if (iter != arrayText.end ()) {
                                if (PullNum (arrayText, iter, value)) {
                                        valuesB.push_back (value);
                                        if (iter != arrayText.end ()) {
                                                if (PullNum (arrayText, iter, value)) {
                                                        valuesC.push_back (value);
                                                }
                                        }
                                }
                        }
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const FloatArray	&valuesA,
        const FloatArray	&valuesB,
        const FloatArray	&valuesC)
{
        string arrayText(pv->FormatArrayPrefix ());
        FloatArray::const_iterator iterA;
        FloatArray::const_iterator iterB;
        FloatArray::const_iterator iterC;
        for (iterA = valuesA.begin (), iterB = valuesB.begin (), iterC = valuesC.begin ();
             iterA != valuesA.end () && iterB != valuesB.end () && iterC != valuesC.end ();
             ++iterA, ++iterB, ++iterC) {
                arrayText += FloatToString(*iterA);
                arrayText += string(ATTRVALUE_SPACE);
                arrayText += FloatToString(*iterB);
                arrayText += string(ATTRVALUE_SPACE);
                arrayText += FloatToString(*iterC);

                pv->FormatArrayEntry (arrayText, iterA + 1 != valuesA.end());
        }

        SetElementValue (element, arrayText);
}

        void
Element::GetElementValue (
        ElementXML		*element,
        InterpArray		&values) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the interpolation values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                string value;
                if (PullName (arrayText, iter, value)) {
                        if (value == string(VALUE_LINEAR)) {
                                values.push_back (INTERPOLATION_LINEAR);
                        }
                        else if (value == string(VALUE_BEZIER)) {
                                values.push_back (INTERPOLATION_BEZIER);
                        }
                        else if (value == string(VALUE_STEP)) {
                                values.push_back (INTERPOLATION_STEP);
                        }
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const InterpArray	&values)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (InterpArray::const_iterator iter = values.begin ();
                iter != values.end (); ++iter) {
                if (*iter == INTERPOLATION_LINEAR) {
                        arrayText += string (VALUE_LINEAR);
                }
                else if (*iter == INTERPOLATION_BEZIER) {
                        arrayText += string (VALUE_BEZIER);
                }
                else if (*iter == INTERPOLATION_STEP) {
                        arrayText += string (VALUE_STEP);
                }

                pv->FormatArrayEntry (arrayText, iter + 1 != values.end());
        }

        SetElementValue (element, arrayText);
}

        void
Element::GetElementValue (
        ElementXML		*element,
        StringArray		&values) const
{
        string	arrayText = GetElementValue (element);

        /*
         * Pull the string values from the text.
         */
        string::const_iterator iter = arrayText.begin ();
        while (iter != arrayText.end ()) {
                string value;
                if (PullName (arrayText, iter, value)) {
                        values.push_back (value);
                }
        }
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const StringArray	&values)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (StringArray::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += *iter;

                pv->FormatArrayEntry (arrayText, iter + 1 != values.end());
        }

        SetElementValue (element, arrayText);
}

/*
 * ---------------------------------------------------------------------------
 * Matrix and matrix array.
 */

        bool
Element::GetElementValue (
        ElementXML		*element,
        math::Matrix4		&matrix) const
{
        bool	linked(false);
        Element::DoubleArray	values;
        GetElementValue (element, values);

        /*
         * A matrix element must have exactly 16 values.
         */
        if (values.size () == 16) {
                for (unsigned row = 0; row < 4; ++row) {
                        for (unsigned col = 0; col < 4; ++col) {
                                matrix[col][row] = values.at (row * 4 + col);
                        }
                }
                linked = true;
        }

        return linked;
}

        void
Element::SetElementValue (
        ElementXML		*element,
        const math::Matrix4	&matrix)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (unsigned rowIndex = 0; rowIndex < 4; ++rowIndex) {
                for (unsigned colIndex = 0; colIndex < 4; ++colIndex) {
                        /*
                         * Matrix is written in row-major order for readability.
                         */
                        arrayText += DoubleToString(matrix[colIndex][rowIndex]);

                        /*
                         * No space after the last item of each row.
                         */
                        if (colIndex < 3) {
                                arrayText += string(ATTRVALUE_SPACE);
                        }
                }
                bool notLastItem = (rowIndex < 3);
                pv->FormatArrayEntry (arrayText, notLastItem);
        }

        SetElementValue (element, arrayText);
}

        bool
Element::GetElementValue (
        ElementXML		*element,
        math::Matrix4Array	&matrixArray) const
{
        bool	linked(false);
        Element::DoubleArray	values;
        GetElementValue (element, values);

        /*
         * A matrix element must have exactly 16 values.
         */
        unsigned matrixCount = static_cast<unsigned>(values.size () / 16);
        if (values.size () == matrixCount * 16) {
                for (unsigned matrixIndex = 0;
                     matrixIndex < matrixCount; ++matrixIndex) {
                        math::Matrix4Wrap	matrix;
                        unsigned matrixBase = matrixIndex * 16;
                        for (unsigned row = 0; row < 4; ++row) {
                                for (unsigned col = 0; col < 4; ++col) {
                                        matrix.m[col][row] =
                                                values.at (matrixBase + (row * 4 + col));
                                }
                        }
                        matrixArray.push_back (matrix);
                }

                linked = true;
        }

        return linked;
}

        void
Element::SetElementValue (
        ElementXML			*element,
        const math::Matrix4Array	&matrixArray)
{
        string arrayText(pv->FormatArrayPrefix ());
        for (math::Matrix4Array::const_iterator iter = matrixArray.begin ();
             iter != matrixArray.end (); ++iter) {
                for (unsigned rowIndex = 0; rowIndex < 4; ++rowIndex) {
                        for (unsigned colIndex = 0; colIndex < 4; ++colIndex) {
                                /*
                                 * Matrix is written in row-major order for readability.
                                 */
                                arrayText += DoubleToString(iter->m[colIndex][rowIndex]);

                                /*
                                 * No space after the last item of each row.
                                 */
                                if (colIndex < 3) {
                                        arrayText += string(ATTRVALUE_SPACE);
                                }
                        }
                        bool notLastItem = (rowIndex < 3) ||
                                (iter + 1 != matrixArray.end ());
                        pv->FormatArrayEntry (arrayText, notLastItem);
                }
        }

        SetElementValue (element, arrayText);
}

/*
 * ---------------------------------------------------------------------------
 * Get/Set element value, with element create.
 */

        bool
Element::GetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        string			&value) const
{
        bool	found(false);

        if (!*subElement) {
                *subElement = GetElement ()->FirstChildElement (elementName);
                found = (*subElement != NULL);
        }

        if (*subElement) {
                value = GetElementValue (*subElement);
        }

        return found;
}

        void
Element::SetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        const string		&value)
{
        if (*subElement) {
                ClearElementValue (*subElement);
        }
        else {
                *subElement = AddElement (elementName);
        }

        SetElementValue (*subElement, value);
}

        bool
Element::GetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        StringArray		&value) const
{
        bool	found(false);

        if (!*subElement) {
                *subElement = GetElement ()->FirstChildElement (elementName);
                found = (*subElement != NULL);
        }

        if (*subElement) {
                GetElementValue (*subElement, value);
        }

        return found;
}

        void
Element::SetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        const StringArray	&value)
{
        if (*subElement) {
                ClearElementValue (*subElement);
        }
        else {
                *subElement = AddElement (elementName);
        }

        SetElementValue (*subElement, value);
}

        bool
Element::GetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        bool			&value) const
{
        bool	found(false);

        if (!*subElement) {
                *subElement = GetElement ()->FirstChildElement (elementName);
                found = (*subElement != NULL);
        }

        if (*subElement) {
                value = GetElementValueBool (*subElement);
        }

        return found;
}

        void
Element::SetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        bool			 value)
{
        SetElementValue (subElement, elementName, BoolToString(value));
}

        bool
Element::GetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        unsigned		&value) const
{
        bool	found(false);

        if (!*subElement) {
                *subElement = GetElement ()->FirstChildElement (elementName);
                found = (*subElement != NULL);
        }

        if (*subElement) {
                value = GetElementValueUnsigned (*subElement);
        }

        return found;
}

        void
Element::SetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        unsigned		 value)
{
        SetElementValue (subElement, elementName, IntegerToString(value));
}

        bool
Element::GetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        double			&value) const
{
        bool	found(false);

        if (!*subElement) {
                *subElement = GetElement ()->FirstChildElement (elementName);
                found = (*subElement != NULL);
        }

        if (*subElement) {
                value = GetElementValueDouble (*subElement);
        }

        return found;
}

        void
Element::SetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        double			 value)
{
        SetElementValue (subElement, elementName, DoubleToString(value));
}

        bool
Element::GetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        ColorRGB		&value) const
{
        bool	found(false);

        if (!*subElement) {
                *subElement = GetElement ()->FirstChildElement (elementName);
        }

        if (*subElement) {
                DoubleArray	values;
                GetElementValue (*subElement, values);
                if (values.size () == 3) {
                        value[0] = values.at (0);
                        value[1] = values.at (1);
                        value[2] = values.at (2);
                        found = true;
                }
        }

        return found;
}

        void
Element::SetElementValue (
        ElementXML		**subElement,
        const string		&elementName,
        const ColorRGB		&value)
{
        string color =
                DoubleToString(value[0]) + string(" ") +
                DoubleToString(value[1]) + string(" ") +
                DoubleToString(value[2]);
        SetElementValue (subElement, elementName, color);
}

        bool
Element::GetParamValue (
        ElementXML		*paramParentElement,
        ElementXML		**paramElement,
        const string		&paramSID,
        bool			&value)
{
        bool	linked(false);

        if (!(*paramElement)) {
                ElementXML *testElem =
                        GetElement ()->FirstChildElement (ELEMENT_PARAM);
                do {
                        if (testElem &&
                            GetSID (testElem) == paramSID) {
                                *paramElement = testElem;
                                linked = true;
                        }

                        if (!linked) {
                                testElem = testElem->NextSiblingElement (ELEMENT_PARAM);
                        }
                } while (testElem && !linked);
        }

        if (*paramElement) {
                /*
                 * Fetch the "true" or "false" string value.
                 */
                value = IsTrue (GetElementValue (*paramElement));

                linked = true;
        }

        return linked;
}

        void
Element::SetParamValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        const string		&paramName,
        bool			 value)
{
        if (*paramElement) {
                ClearElementValue (*paramElement);
        }
        else {
                *paramElement = AddElement (ELEMENT_PARAM);
        }

        SetElementValue (*paramElement, value);

        SetSID (*paramElement, paramSID);
        SetName (*paramElement, paramName);
        SetType (*paramElement, ATTRVALUE_BOOL);
}

        bool
Element::GetParamValue (
        ElementXML		*paramParentElement,
        ElementXML		**paramElement,
        const std::string	&paramSID,
        unsigned		&value)
{
        bool	linked(false);

        if (!(*paramElement)) {
                ElementXML *testElem =
                        GetElement ()->FirstChildElement (ELEMENT_PARAM);
                do {
                        if (testElem &&
                            GetSID (testElem) == paramSID) {
                                *paramElement = testElem;
                                linked = true;
                        }

                        if (!linked) {
                                testElem = testElem->NextSiblingElement (ELEMENT_PARAM);
                        }
                } while (testElem && !linked);
        }

        if (*paramElement) {
                value = GetElementValueUnsigned (*paramElement);
                linked = true;
        }

        return linked;
}

        void
Element::SetParamValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        const string		&paramName,
        unsigned		 value)
{
        if (*paramElement) {
                ClearElementValue (*paramElement);
        }
        else {
                *paramElement = AddElement (ELEMENT_PARAM);
        }

        SetElementValue (*paramElement, value);

        SetSID (*paramElement, paramSID);
        SetName (*paramElement, paramName);
        SetType (*paramElement, ATTRVALUE_INT);
}

        bool
Element::GetParamValue (
        ElementXML		*paramParentElement,
        ElementXML		**paramElement,
        const std::string	&paramSID,
        double			&value)
{
        bool	linked(false);

        if (!(*paramElement)) {
                ElementXML *testElem =
                        GetElement ()->FirstChildElement (ELEMENT_PARAM);
                do {
                        if (testElem &&
                            GetSID (testElem) == paramSID) {
                                *paramElement = testElem;
                                linked = true;
                        }

                        if (!linked) {
                                testElem = testElem->NextSiblingElement (ELEMENT_PARAM);
                        }
                } while (testElem && !linked);
        }

        if (*paramElement) {
                value = GetElementValueDouble (*paramElement);
                linked = true;
        }

        return linked;
}

        void
Element::SetParamValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        const string		&paramName,
        double			 value)
{
        if (*paramElement) {
                ClearElementValue (*paramElement);
        }
        else {
                *paramElement = AddElement (ELEMENT_PARAM);
        }

        SetElementValue (*paramElement, value);

        SetSID (*paramElement, paramSID);
        SetName (*paramElement, paramName);
        SetType (*paramElement, ATTRVALUE_FLOAT);
}

        bool
Element::GetParamValue (
        ElementXML		*paramParentElement,
        ElementXML		**paramElement,
        const string		&paramSID,
        string			&value)
{
        bool	linked(false);

        if (!(*paramElement)) {
                ElementXML *testElem =
                        GetElement ()->FirstChildElement (ELEMENT_PARAM);
                do {
                        if (testElem &&
                            GetSID (testElem) == paramSID) {
                                *paramElement = testElem;
                                linked = true;
                        }

                        if (!linked) {
                                testElem = testElem->NextSiblingElement (ELEMENT_PARAM);
                        }
                } while (testElem && !linked);
        }

        if (*paramElement) {
                value = GetElementValue (*paramElement);
                linked = true;
        }

        return linked;
}

        void
Element::SetParamValue (
        ElementXML		**paramElement,
        const std::string	&paramSID,
        const string		&paramName,
        const string		&value,
        bool			 suppressNameType)
{
        if (*paramElement) {
                ClearElementValue (*paramElement);
        }
        else {
                *paramElement = AddElement (ELEMENT_PARAM);
        }

        SetElementValue (*paramElement, value);

        SetSID (*paramElement, paramSID);
        if (!suppressNameType) {
                SetName (*paramElement, paramName);
                SetType (*paramElement, ATTRVALUE_NAME);
        }
}

        void
Element::SetBoundParamValue (
        ElementXML		**paramElement,
        const string		&parentElementName,
        const string		&paramSID,
        bool			 value,
        bool			 suppressNameType)
{
        ElementParam param;
        if (pv->GetElementParamBind()->FindElementParam (
                parentElementName, paramSID, param)) {
                SetElementValue (paramElement, param.GetElementName (), value);
                SetSID (*paramElement, paramSID);
                if (!suppressNameType) {
                        SetName (*paramElement, param.GetParamName ());
                        SetType (*paramElement, ATTRVALUE_BOOL);
                }
        }
}

        void
Element::SetBoundParamValue (
        ElementXML		**paramElement,
        const string		&parentElementName,
        const string		&paramSID,
        double			 value,
        bool			 suppressNameType)
{
        ElementParam param;
        if (pv->GetElementParamBind()->FindElementParam (
                parentElementName, paramSID, param)) {
                SetElementValue (paramElement, param.GetElementName (), value);
                SetSID (*paramElement, paramSID);
                if (!suppressNameType) {
                        SetName (*paramElement, param.GetParamName ());
                        SetType (*paramElement, ATTRVALUE_FLOAT);
                }
        }
}

        void
Element::SetBoundParamValue (
        ElementXML		**paramElement,
        const std::string	&parentElementName,
        const std::string	&paramSID,
        unsigned		 value,
        bool			 suppressNameType)
{
        ElementParam param;
        if (pv->GetElementParamBind()->FindElementParam (
                parentElementName, paramSID, param)) {
                SetElementValue (paramElement, param.GetElementName (), value);
                SetSID (*paramElement, paramSID);
                if (!suppressNameType) {
                        SetName (*paramElement, param.GetParamName ());
                        SetType (*paramElement, ATTRVALUE_INT);
                }
        }
}

        void
Element::SetBoundParamValue (
        ElementXML		**paramElement,
        const std::string	&parentElementName,
        const std::string	&paramSID,
        const std::string	&value,
        bool			 suppressNameType)
{
        ElementParam param;
        if (pv->GetElementParamBind()->FindElementParam (
                parentElementName, paramSID, param)) {
                SetElementValue (paramElement, param.GetElementName (), value);
                SetSID (*paramElement, paramSID);
                if (!suppressNameType) {
                        SetName (*paramElement, param.GetParamName ());
                        SetType (*paramElement, ATTRVALUE_NAME);
                }
        }
}

        void
Element::SetBoundParamValue (
        ElementXML		**paramElement,
        const std::string	&parentElementName,
        const std::string	&paramSID,
        const Element::ColorRGB	&value,
        bool			 suppressNameType)
{
        ElementParam param;
        if (pv->GetElementParamBind()->FindElementParam (
                parentElementName, paramSID, param)) {
                SetElementValue (paramElement, param.GetElementName (), value);
                SetSID (*paramElement, paramSID);
                if (!suppressNameType) {
                        SetName (*paramElement, param.GetParamName ());
                        SetType (*paramElement, ATTRVALUE_COLOR);
                }
        }
}

        void
Element::ClearElementValue ()
{
        pv->GetElement ()->Clear ();
}

        void
Element::ClearElementValue (ElementXML *element)
{
        element->Clear ();
}

        ElementParamBind *
Element::GetElementParamBind () const
{
        return pv->GetElementParamBind ();
}

        IO_MODE
Element::GetIOMode () const
{
        return pv->GetIOMode ();
}

        pv_Element *
Element::PV () const
{
        return pv;
}

} // namespace cio

