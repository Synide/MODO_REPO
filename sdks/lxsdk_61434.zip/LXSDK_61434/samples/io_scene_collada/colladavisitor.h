/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef COLLADAVISITOR_H
#define COLLADAVISITOR_H

#include <string>

#include "colladabind.h"
#include "../libcolladaio/cio_animation.h"
#include "../libcolladaio/cio_node.h"
#include "../libcolladaio/cio_light.h"
#include "../libcolladaio/cio_shadernode.h"

class COLLADASceneSaver;

class MCItemTypeChannelVisitor : public ItemTypeChannelVisitor
{
        friend class ItemTypeChannelBind;

    public:
                                 MCItemTypeChannelVisitor ();
        virtual			~MCItemTypeChannelVisitor ();

        void			 SetSceneSaver (
                                        COLLADASceneSaver		*sceneSaver);

        void			 SetAnimationLibrary (
                                        cio::AnimationLibraryElement	*library);

        void			 SetLightLibrary (
                                        cio::LightLibraryElement	*library);

        void			 SetShaderNodeLibrary (
                                        cio::ShaderNodeLibraryElement_modo401 *library);

        void			 SetRender (
                                        cio::RenderElement_modo401	*render);

        void			 SetEnvironment (
                                        cio::EnvironmentElement_modo401	*environment);

        /*
         * [TODO] AddLight.
         */

    protected:
        virtual void		 StartItemScan (
                                        const std::string	&itemTypeName);

        virtual bool		 NextItem ();

        virtual bool		 WantItem () const;

        virtual bool		 WantChannel (
                                        const std::string	&itemTypeName,
                                        const std::string	&channel,
                                        cio::ParamType		 paramType);

        /*
         * Process an item of a given type.
         */
        virtual void		 ProcessItem (
                                        const std::string	&itemTypeName);

        /*
         * Process an item channel. Optional override.
         */
        virtual void		 ProcessItemTypeChannel (
                                        const ItemTypeChannel	&itemTypeChannel);

    private:
        /*
         * Common technique lights.
         */
        void			 AddPointLightCommon (
                                        cio::PointLightElement		&light);

        void			 AddSpotLightCommon (
                                        cio::SpotlightElement		&light);

        void			 AddSunLightCommon (
                                        cio::DirectionalLightElement	&light);

        /*
         * modo profile technique lights.
         */
        void			 AddAreaLightProfile (
                                        cio::PointLightElement		&light);

        void			 AddCylinderLightProfile (
                                        cio::PointLightElement		&light);

        void			 AddDomeLightProfile (
                                        cio::PointLightElement		&light);

        void			 AddPhotometricLightProfile (
                                        cio::SpotlightElement		&light);

        void			 AddPointLightProfile (
                                        cio::PointLightElement		&light);

        void			 AddSpotLightProfile (
                                        cio::SpotlightElement		&light);

        void			 AddSunLightProfile (
                                        cio::DirectionalLightElement	&light);

        void			 AddLightCommon_modo401 (
                                        cio::LightElement_modo401	&light);

        /*
         * modo profile technique render shader tree
         * (includes environment and lights).
         */
        void			 SetRenderChannels ();

        void			 SetEnvironmentChannels ();

        void			 SetEnvironmentMaterialChannels ();

        struct pv_MCItemTypeChannelVisitor	*pv;
};

#endif // COLLADAVISITOR_H


