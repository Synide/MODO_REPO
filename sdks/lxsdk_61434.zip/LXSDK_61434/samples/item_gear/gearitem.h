/*
 * Plug-in gear item type.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * A plug-in item type that creates a procedural gear, that can be varied
 * in various ways (number of teeth, spacing, number of spokes, etc.).
 */
#ifndef GEARITEM_H
#define GEARITEM_H

#include <lxlog.h>
#include <lxu_log.hpp>
#include <lxu_geometry.hpp>

#include <lx_surface.hpp>
#include <lx_vmodel.hpp>
#include <lx_action.hpp>
#include <lx_channelui.hpp>
#include <lx_item.hpp>
#include <lx_package.hpp>
#include <lx_tableau.hpp>
#include <lx_vertex.hpp>
#include <lx_value.hpp>

#include <lx_listener.hpp>

#include <vector>
#include <map>

class CGearItemLog : public CLxLuxologyLogMessage
{
    public:
        CGearItemLog () : CLxLuxologyLogMessage ("gear-item") { }

        const char *	 GetFormat  () { return "Gear Item Object"; }
};

/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CGearItemPackage;
class CGearItemElement;

typedef CGearItemElement *GearItemElementID;

/*
 * A multi-map of tableaus and their associated elements.
 */
typedef std::multimap<ILxUnknownID, GearItemElementID> TableauElementMap;

// #define CORE_IMPLEMENTED	1

typedef enum
{
        GEARPART_TEETH,
        GEARPART_RIM,
        GEARPART_SPOKES,
        GEARPART_SHAFT,
#if defined(CORE_IMPLEMENTED)
        GEARPART_CORE,
#endif
        GEARPART_COUNT
} GearPart;

typedef enum
{
        LAYER_UPPER,
        LAYER_LOWER,
        LAYER_MIDDLE,
        LAYER_COUNT
} Layer;

typedef enum
{
        FACE_UPPER,
        FACE_LOWER,
        FACE_LEADING,
        FACE_TRAILING
} Face;

typedef enum
{
        RIM_FACING_OUTWARDS,
        RIM_FACING_INWARDS
} RimFacing;

enum
{
        TEETH_FACING_OUTSIDE,
        TEETH_FACING_INSIDE
        //, TEETH_FACING_CROWN [TODO]
};

/*
 * ---------------------------------------------------------------------------
 * GearGeometry.
 *
 * Used for 3D viewport wireframe drawing and to sample during rendering.
 */
 struct GearGeometry
{
        // per gear
        unsigned		 teeth;
        unsigned		 coveredToothCount;
        double			 contactRatio;
        double			 bevelRadiusOffset;
        double			 scaledOuterRadius;
        double			 upperBeveledScaledOuterRadius;
        double			 lowerBeveledScaledOuterRadius;
        double			 beveledInnerToothRadius;
        double			 innerWallRadius;
        double			 toothTiltAngle;
        double			 outerSpokeRad;
        double			 innerSpokeRad;
        double			 scaledThickness;
        double			 rimThickness;
        double			 axialShaftRimThickness;
        double			 inner_spoke_thickness;
        double			 outer_spoke_thickness;

        // per tooth
        double			 apex_angle_0;
        double			 apex_angle_12;
        double			 inner_angle;
        double			 contact_angle_E;
        double			 contact_angle_N;
        double			 contact_angle_2;
        double			 contact_angle_4;
        double			 contact_angle_8;
        double			 contact_angle_10;
};

/*
 * ---------------------------------------------------------------------------
 * A gear part for rendering.
 */
class CGearPart : public GearGeometry
{
    public:
        /*
         * Tableau Surface implementation.
         */
        LxResult	Bound (LXtTableauBox bbox);
        unsigned	FeatureCount (LXtID4 type);
        LxResult	FeatureByIndex (
                                LXtID4		 type,
                                unsigned int	 index,
                                const char	**name);
        LxResult	SetVertex (ILxUnknownID vdesc);
        LxResult	Sample (
                                const LXtTableauBox	 bbox,
                                float			 scale,
                                ILxUnknownID		 trisoup);

        /*
         * Part configuration.
         */
        void		SetPart (unsigned part);

        /*
         * Part. See the GearPart enum.
         */
        unsigned		 m_part;
        bool			 hasUVs;
        CLxUser_TableauVertex	 vrt_desc;

        /*
         * Indices for vertex feature subscripts.
         */
        enum
        {
                FEATURE_POSITION,
                FEATURE_OBJECT_POSITION,
                FEATURE_NORMAL,
                FEATURE_VELOCITY,
                BASE_FEATURE_COUNT
        };

        enum
        {
                FEATURE_UV	= BASE_FEATURE_COUNT,
                FEATURE_DPDU,
                TOTAL_FEATURE_COUNT
        };

        int			 f_pos[TOTAL_FEATURE_COUNT];
        unsigned		 max_f_pos;
        unsigned		 max_f_type;

        LxResult	InitializePart (
                                CLxUser_Item		&m_item,
                                CLxUser_ChannelRead	&chanRead);

        LxResult	InitializePart (
                                double		coverage,
                                double		toothSpacing,
                                double		contactAngle,
                                double		thickness,
                                unsigned	teeth,
                                double		shaft,
                                unsigned	spokes,
                                bool		hasRim,
                                double		rimInsetRatio,
                                double		wallInsetRatio,
                                double		axialShaftInsetRatio,
                                double		radialShaftInsetRatio,
                                double		innerSpokeInsetRatio,
                                double		outerSpokeInsetRatio,
                                double		spokeSweepRatio,
                                double		spokeSwirlAngle,
                                unsigned	teethFacing,
                                double		bevelAngle,
                                double		helicalAngle,
                                bool		doubleHelical,
                                double		toothFaceRatio,
                                double		toothTiltAngle,
                                double		toothGrowth,
                                unsigned	resolution,
                                double		maxRadius);

        /*
         * Construction channels.
         */
        double			 m_coverage;
        double			 tooth_spacing;
        double			 contact_angle;
        double			 m_thickness;
        unsigned		 m_teeth;
        double			 m_shaft;
        unsigned		 m_spokes;

        /*
         * Trim channels.
         */
        bool			 has_rim;
        double			 rim_inset_ratio;
        double			 wall_inset_ratio;
        double			 axial_shaft_inset_ratio;
        double			 radial_shaft_inset_ratio;
        double			 inner_spoke_inset_ratio;
        double			 outer_spoke_inset_ratio;
        double			 spoke_sweep_ratio;
        double			 spoke_swirl_angle;

        /*
         * Specialized channels.
         */
        unsigned		 teeth_facing;
        double			 bevel_angle;
        double			 helical_angle;
        bool			 double_helical;
        double			 tooth_face_ratio;
        double			 tooth_tilt_angle;
        double			 tooth_growth;

        unsigned		 m_resolution;

        /*
         * Maximum radius for UV space scaling.
         * (Calculated from various channel values.)
         */
        double			 max_radius;

    private:
        double		 MaxRadius ();

        LxResult	 SampleGearPartTeeth (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID);

        LxResult	 SampleGearPartRim (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID);

        LxResult	 SampleGearPartSpokes (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID);

        LxResult	 SampleGearPartShaft (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID);

#if defined(CORE_IMPLEMENTED)
        LxResult	 SampleGearPartCore (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID);
#endif

        LxResult	 PushVertexFeatures (
                                CLxUser_TriangleSoup	&soup,
                                std::vector<Point>	&points,
                                std::vector<Point>	&normals,
                                std::vector<Point>	&velocities,
                                std::vector<UV>		&uvs,
                                std::vector<Point>	&dPdus,
                                std::vector<Point>	&dPdvs);

        void		 PushBeveledHelicalToothRenderPoints (
                                unsigned		 upperCopies,
                                unsigned		 middleCopies,
                                unsigned		 lowerCopies,
                                double			 upperAngle,
                                double			 lowerAngle,
                                double			 upperRadius,
                                double			 lowerRadius,
                                double			 thickness,
                                std::vector<Point>	&points,
                                std::vector<UV>		&uvs);

        void		 PushWallBeveledHelicalRenderPoints (
                                unsigned		 copies,
                                double			 upperAngle,
                                double			 lowerAngle,
                                double			 upperRadius,
                                double			 lowerRadius,
                                double			 thickness,
                                Layer			 layer,
                                std::vector<Point>	&points,
                                std::vector<UV>		&uvs);

        void		 PushSpokeEndCapRenderPoints (
                                double			 contactAngle2,
                                double			 apexAngle0,
                                double			 contactAngle10,
                                double			 outerRadius,
                                double			 innerRadius,
                                double			 outerThickness,
                                double			 innerThickness,
                                std::vector<Point>	&points,
                                std::vector<UV>		&uvs);

        void		 PushSpokeSpanRenderPoints (
                                double			 angle,
                                double			 outerRadius,
                                double			 innerRadius,
                                unsigned		 segments,
                                double			 outerThickness,
                                double			 innerThickness,
                                Layer			 layer,
                                Face			 face,
                                std::vector<Point>	&points,
                                std::vector<UV>		&uvs);

        typedef enum
        {
                RIM_MAPPING_CYLINDRICAL,
                RIM_MAPPING_CONCENTRIC
        } RimMapping;

        LxResult	 BrewRimSoup (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID,
                                double			 radius,
                                double			 thickness,
                                RimFacing		 facing,
                                RimMapping		 rimMapping = RIM_MAPPING_CYLINDRICAL);

        void		 PushRimRenderPoints (
                                CLxUser_TriangleSoup	&soup,
                                double			 angle,
                                double			 radius,
                                double			 thickness,
                                RimFacing		 facing,
                                std::vector<Point>	&points,
                                std::vector<UV>		&uvs,
                                RimMapping		 rimMapping);

        typedef enum
        {
                RING_MAPPING_INSET,
                RING_MAPPING_UNIT
        } RingMapping;

        LxResult	 BrewRingSoup (
                                CLxUser_TriangleSoup	&soup,
                                unsigned 		&segmentID,
                                double			 outerRadius,
                                double			 innerRadius,
                                double			 outerThickness,
                                double			 innerThickness,
                                RingMapping		 ringMapping = RING_MAPPING_INSET);

        void		 PushRingRenderPoints (
                                double			 angle,
                                double			 outerRadius,
                                double			 innerRadius,
                                double			 outerThickness,
                                double			 innerThickness,
                                Layer			 layer,
                                std::vector<Point>	&points,
                                std::vector<UV>		&uvs,
                                RingMapping		 ringMapping);
};

class CGearItemElement :
        public CLxImpl_TableauSurface,
        public CLxImpl_TableauInstance,
        public CGearPart
{
        CGearItemLog		 gear_log;

    public:
        /*
         * Gear elements remove themselves from the tableau element
         * multi-map when they are destroyed.
         */
        ILxUnknownID		 element;
        ILxUnknownID		 tableau;	// map key
        TableauElementMap	*tableauElementMap;

                         CGearItemElement();
        virtual		~CGearItemElement();

        /*
         * Transforms.
         */
        LXtVector		 m_offset0;
        LXtVector		 m_offset1;
        LXtMatrix		 m_xfrm0;
        LXtMatrix		 m_xfrm1;

        /*
         * TableauSurface interface.
         */
        LxResult	 tsrf_Bound (LXtTableauBox bbox) LXx_OVERRIDE;
        unsigned	 tsrf_FeatureCount (LXtID4 type) LXx_OVERRIDE;
        LxResult	 tsrf_FeatureByIndex (
                                LXtID4		 type,
                                unsigned int	 index,
                                const char	**name) LXx_OVERRIDE;
        LxResult	 tsrf_SetVertex (ILxUnknownID vdesc) LXx_OVERRIDE;
        LxResult	 tsrf_Sample (
                                const LXtTableauBox	 bbox,
                                float			 scale,
                                ILxUnknownID		 trisoup) LXx_OVERRIDE;

        /*
         * TableauInstance interface.
         */
        LxResult	 tins_GetTransform (
                                unsigned	 endPoint,
                                LXtVector	 offset,
                                LXtMatrix	 xfrm) LXx_OVERRIDE;
};

class CGearItemBin :
        public CLxImpl_SurfaceBin,
        public CLxImpl_StringTag,
        public CLxImpl_TableauSurface,
        public CGearPart
{
    public:
        /*
         * SurfaceBin interface.
         */
        LxResult	 surfbin_GetBBox (LXtBBox *bbox) LXx_OVERRIDE;
        LxResult	 surfbin_FrontBBox (
                                const LXtVector	 pos,
                                const LXtVector	 dir,
                                LXtBBox		*bbox) LXx_OVERRIDE;

        /*
         * StringTag interface.
         */
        LxResult	 stag_Get (LXtID4 type, const char **tag) LXx_OVERRIDE;

        /*
         * TableauSurface interface.
         */
        LxResult	 tsrf_Bound (LXtTableauBox bbox) LXx_OVERRIDE;
        unsigned	 tsrf_FeatureCount (LXtID4 type) LXx_OVERRIDE;
        LxResult	 tsrf_FeatureByIndex (
                                LXtID4		 type,
                                unsigned int	 index,
                                const char	**name) LXx_OVERRIDE;
        LxResult	 tsrf_SetVertex (ILxUnknownID vdesc) LXx_OVERRIDE;
        LxResult	 tsrf_Sample (
                                const LXtTableauBox	 bbox,
                                float			 scale,
                                ILxUnknownID		 trisoup) LXx_OVERRIDE;
};

class CGearItemSurface :
        public CLxImpl_Surface,
        public CGearPart
{
        /*
         * The parts of the gear (side and endcaps)
         */
        CGearItemPackage	*src_pkg;

    public:
        LxResult	 surf_GetBBox (LXtBBox *bbox) LXx_OVERRIDE;
        LxResult	 surf_FrontBBox (
                                const LXtVector	 pos,
                                const LXtVector	 dir,
                                LXtBBox		*bbox) LXx_OVERRIDE;
        LxResult	 surf_RayCast (const LXtRayInfo *ray, LXtRayHit *hit) LXx_OVERRIDE;
        LxResult	 surf_BinCount (unsigned int *count) LXx_OVERRIDE;
        LxResult	 surf_BinByIndex (unsigned int index, void **ppvObj) LXx_OVERRIDE;
        LxResult	 surf_TagCount ( LXtID4 type, unsigned int *count) LXx_OVERRIDE;
        LxResult	 surf_TagByIndex (
                                LXtID4		 type,
                                unsigned int	 index,
                                const char	**stag) LXx_OVERRIDE;

        LxResult	 Initialize (
                                CGearItemPackage	*pkg,
                                CLxUser_Item		&m_item,
                                CLxUser_ChannelRead	&chanRead);

        LxResult	 Initialize (
                                CGearItemPackage	*pkg,
                                double			 coverage,
                                double			 toothSpacing,
                                double			 contactAngle,
                                double			 thickness,
                                unsigned		 teeth,
                                double			 shaft,
                                unsigned		 spokes,
                                bool			 hasRim,
                                double			 rimInsetRatio,
                                double			 wallInsetRatio,
                                double			 axialShaftInsetRatio,
                                double			 radialShaftInsetRatio,
                                double			 innerSpokeInsetRatio,
                                double			 outerSpokeInsetRatio,
                                double			 spokeSweepRatio,
                                double			 spokeSwirlAngle,
                                unsigned		 teethFacing,
                                double			 bevelAngle,
                                double			 helicalAngle,
                                bool			 doubleHelical,
                                double			 toothFaceRatio,
                                double			 toothTiltAngle,
                                double			 toothGrowth,
                                unsigned		 resolution,
                                double			 radius);
};

class CGearItemInstance :
        public CLxImpl_PackageInstance,
        public CLxImpl_TableauSource,
        public CLxImpl_ViewItem3D,
        public CLxImpl_SurfaceItem
{
        CGearItemLog	 	 gear_log;

        TableauElementMap	 tableauElementMap;

    public:
        CGearItemPackage	*src_pkg;
        CLxUser_Item		 m_item;

        /*
         * PackageInstance interface.
         */
        LxResult	 pins_Initialize (
                                ILxUnknownID	 item,
                                ILxUnknownID	 super) LXx_OVERRIDE;
        void		 pins_Cleanup (void) LXx_OVERRIDE;
        LxResult	 pins_SynthName (char *buf, unsigned len) LXx_OVERRIDE;
        unsigned	 pins_DupType (void) LXx_OVERRIDE;
        LxResult	 pins_TestParent (ILxUnknownID item) LXx_OVERRIDE;
        LxResult	 pins_Newborn (ILxUnknownID original) LXx_OVERRIDE;
        LxResult	 pins_Loading (void) LXx_OVERRIDE;
        LxResult	 pins_AfterLoad (void) LXx_OVERRIDE;
        void		 pins_Doomed (void) LXx_OVERRIDE;

        /*
         * TableauSource interface.
         */
        LxResult	 tsrc_Elements (ILxUnknownID tableau) LXx_OVERRIDE;
        LxResult	 tsrc_Instance (
                                ILxUnknownID	 tableau,
                                ILxUnknownID	 instance) LXx_OVERRIDE;
        LxResult	 tsrc_PreviewUpdate (int chanIndex, int *update) LXx_OVERRIDE;

        /*
         * ViewItem3D interface.
         */
        LxResult	 vitm_Draw (
                                ILxUnknownID	 itemChanRead,
                                ILxUnknownID	 viewStrokeDraw,
                                int		 selectionFlags,
                                LXtVector	 itemColor) LXx_OVERRIDE;

        LxResult	 vitm_HandleCount (
                                int		*count) LXx_OVERRIDE;

        LxResult	 vitm_HandleMotion (
                                int		 handleIndex,
                                int		*motionType,
                                double		*min,
                                double		*max,
                                LXtVector	 plane,
                                LXtVector	 offset) LXx_OVERRIDE;

        LxResult	 vitm_HandleChannel (
                                int		 handleIndex,
                                int		*chanIndex) LXx_OVERRIDE;

        LxResult	 vitm_HandleValueToPosition (
                                int		 handleIndex,
                                double		 chanValue,
                                LXtVector	 position) LXx_OVERRIDE;

        LxResult	 vitm_HandlePositionToValue (
                                int		 handleIndex,
                                LXtVector	 position,
                                double		*chanValue) LXx_OVERRIDE;

        /*
         * SurfaceItem interface.
         */
        LxResult	 isurf_GetSurface (
                                ILxUnknownID	 chanRead,
                                unsigned	 morph,
                                void		**ppvObj) LXx_OVERRIDE;

        LxResult	 isurf_Prepare (
                                ILxUnknownID	 eval,
                                unsigned	*index) LXx_OVERRIDE;

        LxResult	 isurf_Evaluate (
                                ILxUnknownID	 attr,
                                unsigned	 index,
                                void		**ppvObj) LXx_OVERRIDE;
};

class CGearItemPackage :
        public CLxImpl_Package,
        public CLxImpl_ChannelUI
{
    public:
        static LXtTagInfoDesc		 descInfo[];
        CLxPolymorph<CGearItemInstance>	 gear_factory;
        CLxPolymorph<CGearItemElement>	 elt_factory;
        CLxPolymorph<CGearItemSurface>	 surf_factory;
        CLxPolymorph<CGearItemBin>	 bin_factory;

        CGearItemPackage ();

        /*
         * Package interface.
         */
        LxResult		pkg_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		pkg_TestInterface (const LXtGUID *guid) LXx_OVERRIDE;
        LxResult		pkg_Attach (void **ppvObj) LXx_OVERRIDE;

        /* 
         * Channel UI interface.
         */
        LxResult		cui_Enabled (
                                        const char	*channelName,
                                        ILxUnknownID	 msg,
                                        ILxUnknownID	 item,
                                        ILxUnknownID	 read) LXx_OVERRIDE;

        LxResult		cui_DependencyCount (
                                        const char	*channelName,
                                        unsigned	*count) LXx_OVERRIDE;

        LxResult		cui_DependencyByIndex (
                                        const char	*channelName,
                                        unsigned	 index,
                                        LXtItemType	*depItemType,
                                        const char	**depChannelName) LXx_OVERRIDE;

        LXtItemType		MyType ();

    private:
        LXtItemType		my_type;
};

/*
 * The next set of classes are used for tableau updates to the gear item.
 */

/*
 * The static TableauListenerMap simply maintains a mapping from tableaus
 * to tableau listener objects.
 */

static class CGearTableauListenerMap
{
        public:
                CGearTableauListenerMap ();
                bool TestTableau (ILxUnknownID		 tableauObj);
                void AddTableau (ILxUnknownID		 tableauObj);
                void RemoveTableau (ILxUnknownID	 tableauObj);
        private:
                std::map<ILxUnknownID, ILxUnknownID>	tableauListenerMap;
} *listenerMap;

/*
 * The tableau listener is where the real meat is, since it responds to the
 * tableau events.
 */

class CGearTableauListener :
                public CLxImpl_TableauListener
{
        public:	
                CGearTableauListener ()
                {
                        NULL;
                }

                void tli_ChannelChange (
                                        ILxUnknownID	tableauObj,
                                        ILxUnknownID	itemObj,
                                        int		chan) LXx_OVERRIDE;
                void tli_FlushElements (ILxUnknownID	tableauObj)
                {
                        NULL;
                }
                void tli_TableauDestroy(ILxUnknownID	tableauObj)
                {
                        listenerMap->RemoveTableau (tableauObj);
                }
        private:
                LXtItemType			gearType;
};

/*
 * CFactories is really just a factory for the tableau listeners.
 */

static class CFactories 
{
        public:
                CLxPolymorph<CGearTableauListener>	 	tli;

                CFactories () 
                {
                        tli.AddInterface (new CLxIfc_TableauListener<CGearTableauListener>);
                }
} *pF;

CGearTableauListenerMap::CGearTableauListenerMap () 
        :
        tableauListenerMap()
{
        NULL;
}

        bool 
CGearTableauListenerMap::TestTableau (
        ILxUnknownID		tableauObj)
{
        return (tableauListenerMap.count (tableauObj) > 0);
}

        void 
CGearTableauListenerMap::AddTableau (
        ILxUnknownID		tableauObj) 
{
        CLxUser_ListenerPort	port (tableauObj);
        ILxUnknownID		tbxListener;
        LxResult		result;

        tbxListener = pF->tli.Spawn ();
        result = port.AddListener (tbxListener);

        if (LXx_OK (result)) {
                tableauListenerMap[tableauObj] = tbxListener;
        }
}

        void
CGearTableauListenerMap::RemoveTableau (
        ILxUnknownID			tableauObj) 
{
        ILxUnknownID			tbxListener;
        std::map<ILxUnknownID, ILxUnknownID>::iterator 
                                        it;

        it = tableauListenerMap.find (tableauObj);
        if (it != tableauListenerMap.end ()) {
                tbxListener = it->second;
                lx::UnkRelease(tbxListener);
        }

        tableauListenerMap.erase (tableauObj);
}

#define SRVs_GEOMETRY_ITEM	"gear.item"
#define SRVs_ITEMTYPE		"val." SRVs_GEOMETRY_ITEM

#endif // GEARITEM_H

