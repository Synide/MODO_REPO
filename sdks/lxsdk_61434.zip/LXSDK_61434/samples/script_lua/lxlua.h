/*
 * Plug-in Lua script interpreter.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef lxlua 
#define lxlua

#include <lxaction.h>
#include <lxcommand.h>
#include <lxlog.h>
#include <lx_log.hpp>

/* Stack structure. */
#define MAX_STACK	32

typedef struct st_IntrInstance {
        ILxScriptID	 script;		// Script being executed.
        ILxMonitorID	 monitor;		// Progress monitor used by lxmon??? functions.
        int		 askedForMonitor;	// True if we asked for the monitor.
        LxResult	 rc;			// Result code from the most recently executed/queried command.
        int		 tracing;		// 1 if tracing is active, 0 if inactive.
        int		 execFlags;		// Flags provided by the caller of Run() and used for command execution.

        CLxUser_LogEntry log;			// For logging data

        int		 queryAnglesAsDegrees;	// True if queried angles should be returned in degrees instead of radians.
} IntrInstance;

/* Lua Functions */
extern "C"  int   l_lxout(lua_State *L);
extern "C"  int   l_lx(lua_State *L);
extern "C"  int   l_lxq(lua_State *L);
extern "C"  int   l_lxqt(lua_State *L);
extern "C"  int   l_lxeval(lua_State *L);
extern "C"  int   l_lxok(lua_State *L);
extern "C"  int   l_lxres(lua_State *L);
extern "C"  int   l_lxtrace(lua_State *L);
extern "C"  int   l_lxoption(lua_State *L);
extern "C"  int   l_lxsetOption(lua_State *L);
extern "C"  int   l_lxmonInit(lua_State *L);
extern "C"  int   l_lxmonStep(lua_State *L);

#endif

