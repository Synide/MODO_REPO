/*
 * MODO SDK SAMPLE
 *
 * Image Saver server
 * ==================
 *
 *	Copyright (c) 2008-2018 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 *
 * This implements a Saver server that saves images.
 *
 * For purposes of the sample this doesn't export an entire image. We'll just
 * write the size of the image and be done with it.
 *
 * CLASSES USED:
 *
 *		CLxSaverT<>
 *		CLxMeta_Saver
 *
 * TESTING:
 *
 * Right click on an image and save it. Pick this format. The file written
 * should contain the width and height of the image.
 */
#include <lxu_io.hpp>
#include <lxu_format.hpp>
#include <lx_image.hpp>

using namespace lx_err;


#define SRVNAME_SAVER		"csam.saver.basic"


                namespace SaverBasic {

/*
 * ----------------------------------------------------------------
 * Our saver derives from the template saver class, specialized for images.
 * Because a new instance of this class is allocated for every save, we
 * can rely on the destructor to manage some cleanup.
 */
class CSaver :
                public CLxSaverT<CLxUser_Image>
{
    public:
        CLxLineFormat		line_out;

        /*
         * save() is called with the object given in the template, the filename
         * to save to, and a monitor that can be used to track progress.
         */
                void
        save (
                CLxUser_Image		&image,
                const char		*filename,
                CLxUser_Monitor		&mon)			LXx_OVERRIDE
        {
                unsigned w, h;

                line_out.ff_Open (filename);

                image.Size (&w, &h);
                line_out.lf_Output (w);
                line_out.lf_Break ();
                line_out.lf_Output (h);

                check (!line_out.ff_HasError ());
        }
};


/*
 * ----------------------------------------------------------------
 * Metaclass
 *
 * Constructor sets the server name.
 */
static CLxMeta_Saver<CSaver>	 save_meta (SRVNAME_SAVER);


/*
 * ----------------------------------------------------------------
 * Root metaclass
 *
 *	(root)
 *	  |
 *	  +---	saver
 *
 * The saver metaclass needs a class (what type of object to save) and a
 * file extension.
 */
static class CRoot : public CLxMetaRoot
{
        bool pre_init ()					LXx_OVERRIDE
        {
                save_meta.set_class (LXu_IMAGE);
                save_meta.set_file_extension ("YYY");

                add (&save_meta);
                return false;
        }
} root_meta;

                }; // END namespace


