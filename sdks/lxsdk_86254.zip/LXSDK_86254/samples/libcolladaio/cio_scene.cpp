/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_scene.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_strings.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Scene.
 */

struct pv_SceneElement
{
        pv_SceneElement ()
                :
                extra(NULL),
                technique(NULL)
        {
        }

        ElementXML		*extra;
        ElementXML		*technique;
};

SceneElement::SceneElement (
        COLLADAElement		&collada,
        const std::string	&name)
        :
        Element(collada.PV ()),
        pv(new pv_SceneElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddScene (*this);

                ElementXML *instance_visual_scene =
                        AddElement (ELEMENT_INSTANCE_VISUAL_SCENE);
                SetAttribute (instance_visual_scene,
                        ATTRIBUTE_URL, URI_Ref (name));
        }
}

SceneElement::SceneElement (
        COLLADAElement	&collada)
        :
        Element(collada.PV ()),
        pv(new pv_SceneElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkScene (*this);
        }
}

SceneElement::~SceneElement ()
{
        delete pv;
}

        bool
SceneElement::GetVisualSceneID (string& visualSceneID) const
{
        bool ok = false;
        ElementXML *visualSceneURIelem =
                GetElementHandle ().FirstChildElement (
                        ELEMENT_INSTANCE_VISUAL_SCENE).Element ();

        if (visualSceneURIelem != NULL) {
                const char *text = visualSceneURIelem->Attribute (ATTRIBUTE_URL);
                if (text) {
                        visualSceneID = StripURI_Ref (string(text));
                        ok = true;
                }
        }
        return ok;
}

        bool
SceneElement::HasTechniqueProfile (
        const string		&profileName) const
{
        /*
         * The technique element that matches our profile is nested within
         * an extra element. We iterate over the extra elements to find the
         * named profile.
         */
        bool	found(false);
        ElementXML *extraElem = GetElementHandle ().FirstChildElement (
                ELEMENT_EXTRA).Element ();
        do {
                if (extraElem) {
                        ElementXML *techniqueElem =
                                GetElementHandle ().FirstChildElement (
                                        ELEMENT_TECHNIQUE).Element ();
                        do {
                                if (techniqueElem) {
                                        found = GetAttribute (
                                                techniqueElem, ATTRIBUTE_PROFILE) ==
                                                profileName;
                                        techniqueElem = techniqueElem->NextSiblingElement (
                                                ELEMENT_TECHNIQUE);
                                }
                        } while (techniqueElem && !found);
                        if (!found) {
                                extraElem = extraElem->NextSiblingElement (ELEMENT_EXTRA);
                        }
                }
        } while (extraElem && !found);

        return found;
}

        bool
SceneElement::LinkTechniqueProfile (
        const string		&profileName,
        Element			&technique)
{
        /*
         * The technique element that matches our profile is nested within
         * an extra element. We iterate over the extra elements to find the
         * named profile.
         */
        bool	linked(false);
        ElementXML *extraElem = GetElementHandle ().FirstChildElement (
                ELEMENT_EXTRA).Element ();
        do {
                if (extraElem) {
                        ElementXML *techniqueElem = GetElementHandle ().FirstChildElement (
                                ELEMENT_TECHNIQUE).Element ();
                        do {
                                if (techniqueElem) {
                                        linked = GetAttribute (
                                                techniqueElem, ATTRIBUTE_PROFILE) ==
                                                profileName;
                                        if (linked) {
                                                technique.SetElement (techniqueElem);
                                        }
                                }
                        } while (techniqueElem && !linked);
                        if (!linked) {
                                extraElem = extraElem->NextSiblingElement (ELEMENT_EXTRA);
                        }
                }
        } while (extraElem && !linked);

        return linked;
}

} // namespace cio

