#ifndef LX_VERSION_H
#define LX_VERSION_H

#define LXi_VERSION_BUILD 86254
#define LXi_VERSION_BASE 8
#define LXi_VERSION_LIB1 800
#define LXi_VERSION_LIB2 0
#define LXi_VERSION_LIB3 8
#define LXi_VERSION_LIB4 6254
#define LXs_VERSION_LIB "801.0.8.6254"
#define LXs_VERSION_NAME "nexus 8"
#define LXs_VERSION_DESC "nexus 8 by The Foundry"
#define LXi_VERSION_YEAR 2015
#define LXs_VERSION_YEAR "2015"

#endif


