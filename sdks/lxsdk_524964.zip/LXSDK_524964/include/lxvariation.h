/*
 * LX variation module
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_variation_H
#define LX_variation_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxVariation ** ILxVariationID;
typedef struct vt_ILxVariationService ** ILxVariationServiceID;




typedef struct vt_ILxVariation {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        TestItem) (
                LXtObjectID              self,
                LXtObjectID              item,
                LXtObjectID              chanRead);
                LXxMETHOD( LxResult,
        Initialize) (
                LXtObjectID              self,
                double                  *x,
                double                  *y,
                LXtObjectID              item,
                LXtObjectID              chanRead);
                LXxMETHOD( LxResult,
        RangeX) (
                LXtObjectID              self,
                double                  *min,
                double                  *max);
                LXxMETHOD( LxResult,
        RangeY) (
                LXtObjectID              self,
                double                  *min,
                double                  *max);
                LXxMETHOD( LxResult,
        Thumb) (
                LXtObjectID              self,
                double                   x,
                double                   y,
                unsigned int             size,
                LXtObjectID              chanRead,
                void                   **ppvObj);
                LXxMETHOD( LxResult,
        Do) (
                LXtObjectID              self,
                double                   x,
                double                   y);
} ILxVariation;
typedef struct vt_ILxVariationService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD( void,
        InvalidateItem) (
                LXtObjectID              self,
                LXtObjectID              item);
} ILxVariationService;

#define LXu_VARIATION                   "9EEA0765-4008-426C-A550-88F6EB08B2E4"
#define LXa_VARIATION                   "variation"
// [export] ILxVariation                 var
// [local]  ILxVariation
// [python] ILxVariation:TestItem        bool
#define LXu_VARIATIONSERVICE            "2BD9441B-C671-4F3C-9B02-45E9D750E80B"
#define LXa_VARIATIONSERVICE            "variationservice"

 #ifdef __cplusplus
  }
 #endif
#endif

