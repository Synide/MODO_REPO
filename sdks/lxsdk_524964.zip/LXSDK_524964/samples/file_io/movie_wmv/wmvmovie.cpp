/*
 * Plug-in Windows Media Format WMV saver for movies.
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 *
 * CAPABILITIES
 * ------------
 * This plug-in saves Windows Media Format WMV movies in
 * 24-bits per pixel RGB.
 *
 * BUILD TARGETING
 * ---------------
 * This plug-in builds for the x86 and x64 targets on Windows, and
 * uses the Windows Media Format SDK, which is not available on Mac OS X.
 * (Mac OS X uses QuickTime.)
 *
 * BUILD PREREQUISITES
 * -------------------
 * Building this plug-in requires the use of the "wmvmovie.vcproj" with
 * VS2008, and also requires either the Windows Platform SDK 6.0A or later,
 * or the Windows Media Format 11 SDK.
 *
 * This plug-in also requires the modo 401 or later File I/O SDK.
 */

#include <lx_image.hpp>
#include <lxu_log.hpp>
#include <lxlog.h>
#include <lxu_queries.hpp>

#include <stdlib.h>

#include "wmsdkidl.h"
#include "wmsysprf.h"

/*
 * Suppress warnings for deprecated functions.
 */
#ifdef _MSC_VER
        #define _CRT_SECURE_NO_WARNINGS 1
        #define _CRT_SECURE_NO_DEPRECATE 1
        #pragma warning(disable: 4996)
#endif

/*
 * Message logging for io-status Event Log.
 */
class WMVLogMessage : public CLxLuxologyLogMessage
{
    public:
        virtual const char* GetFormat ()
        {
                return "WMV";
        }
};

class CWMVMovie : public CLxImpl_Movie
{
        WMVLogMessage		 log;
        CLxUser_ImageService	 imageSvc;
        WMT_VERSION		 profileVersion;
        IWMProfileManager	*profileManagerWM;
        IWMProfileManager2	*profileManagerWM2;
        IWMProfile		*profileWM;
        WCHAR			*profileName;
        IWMWriter		*writeWM;
        WMVIDEOINFOHEADER	 videoInfo;
        WM_MEDIA_TYPE		 mediaType;
        IWMInputMediaProps	*videoProps;
        DWORD			 videoInput;
        unsigned		 srcImageWidth;
        unsigned		 srcImageHeight;
        unsigned		 dstImageWidth;
        unsigned		 dstImageHeight;
        DWORD			 sampleIndex;
        DWORD			 currentVideoSample;
        QWORD			 videoTime;
        DWORD			 frameRate;	// Frames Per Second Rate (FPS)

        /*
         * [TODO] For now, we only output 24-bit RGB.
         */
        enum {
                RGB_PIXEL_BIT_DEPTH	= 24,
                RGBA_PIXEL_BIT_DEPTH	= 32
        };

        LxResult		 LoadSystemProfile (
                                        DWORD		 profileIndex, 
                                        IWMProfile	**loadProfileWM);
        LxResult		 EnumSystemProfiles ();

        void			 GetOptions (int &profileIndex);
        LxResult		 SetMediaType ();
        LxResult		 WriteSample (CLxUser_Image &image);

    public:
                                 CWMVMovie ();
        virtual			 ~CWMVMovie ();

        LxResult		 mov_BeginMovie (
                                        const char	*fileName,
                                        int		 width,
                                        int		 height,
                                        int		 flags);

        LxResult		 mov_SetFramerate (int fps);
        LxResult		 mov_AddImage (ILxUnknownID img);
        LxResult		 mov_EndMovie (void);

        static LXtTagInfoDesc	 descInfo[];
};

#ifndef SAFE_RELEASE
    #define SAFE_RELEASE( x )           \
        if ( NULL != x )                \
        {                               \
            x->Release( );              \
            x = NULL;                   \
        }
#endif // SAFE_RELEASE

/*
 * Constructor.
 */
CWMVMovie::CWMVMovie ()
        :
        profileManagerWM(NULL),
        profileManagerWM2(NULL),
        profileWM(NULL),
        profileName(NULL),
        writeWM(NULL),
        videoProps(NULL)
{
        /*
         * Create the profile manager.
         */
        HRESULT hr = WMCreateProfileManager (&profileManagerWM);
        if (SUCCEEDED (hr)) {
                hr = profileManagerWM->QueryInterface (
                        IID_IWMProfileManager2, (void **)&profileManagerWM2);
                if (SUCCEEDED (hr)) {

                        /*
                         * Fetch the currently set profile version.
                         */
                        hr = profileManagerWM2->GetSystemProfileVersion (
                                &profileVersion);
                        if (SUCCEEDED (hr)) {
                                char logBuf[256];
                                sprintf (logBuf, "Initial system Profile: %05x", profileVersion);
                                log.Info (logBuf);
                        }

                        /*
                         * Get the OS version info.
                         */
                        OSVERSIONINFO	 verInfo = { 0 };
                        verInfo.dwOSVersionInfoSize = sizeof(verInfo);
                        GetVersionEx (&verInfo);

                        /*
                         * Set the system profile version to 9.0 on XP 64,
                         * and to 8.0 on everything else.
                         */
                        if (verInfo.dwMajorVersion == 5 &&
                            (sizeof(void *) == 8)) {
                                profileVersion = WMT_VER_9_0;
                        }
                        else {
                                profileVersion = WMT_VER_8_0;
                        }
                        hr = profileManagerWM2->SetSystemProfileVersion(
                                profileVersion);
                        if (SUCCEEDED (hr)) {
                                char logBuf[256];
                                sprintf (logBuf, "Using system Profile: %05x",
                                        profileVersion);
                                log.Info (logBuf);
                        }
                }
        }
}

CWMVMovie::~CWMVMovie ()
{
        /*
         * Release both profile manager interfaces.
         */
        SAFE_RELEASE (profileManagerWM2);
        SAFE_RELEASE (profileManagerWM);
}

/*
 * Load a system profile by the index.
 *
 * For now, this function is only used for debugging purposes.
 *
 * [TODO] This will be used later on once modo supports dynamically
 *        adding named profiles to the Movie preferences panel.
 */
        LxResult
CWMVMovie::LoadSystemProfile (
        DWORD		 profileIndex, 
        IWMProfile	**loadProfileWM)
{
        LxResult		 result = LXe_FAILED;
        HRESULT			 hr = S_OK;

        if (loadProfileWM == NULL) {
                return result;
        }

        /*
         * Index starts from 0 but the user sees it as starting from 1
         */
        profileIndex--;

        /*
         * Load the system profile by index.
         */
        hr = profileManagerWM->LoadSystemProfile (
                profileIndex, loadProfileWM);
        if (SUCCEEDED (hr)) {
                result = LXe_OK;
        }

        return result;
}

/*
 * Enumerate all system profiles, and display their indices and names.
 *
 * For now, this function is only used for debugging purposes to obtain the
 * official list of factory system profiles.
 *
 * [TODO] Once modo supports dynamically adding named profiles to a popup menu
 *        in the the Movie preferences panel, we can use this function to
 *        populate that list.
 */
        LxResult
CWMVMovie::EnumSystemProfiles ()
{
        LxResult		 result = LXe_FAILED;
        HRESULT			 hr = S_OK;
        DWORD			 profileIndex = 0;
        DWORD			 profileCount = 0;
        IWMProfile		*iterProfileWM = NULL;
        WCHAR			*iterProfileName = NULL;
        DWORD			 nameLength = 0;

        do
        {
                hr = profileManagerWM->GetSystemProfileCount (&profileCount);
                if (FAILED (hr))
                {
                        break;
                }

                char logBufC[256];
                sprintf (logBufC, "%d available profiles.", profileCount);
                log.Info (logBufC);

                /*
                 * Iterate over all of the system profiles.
                 */
                for (profileIndex = 0; profileIndex < profileCount; profileIndex++)
                {
                        hr = profileManagerWM->LoadSystemProfile (
                                profileIndex, &iterProfileWM);
                        if (FAILED (hr))
                        {
                                break;
                        }

                        /*
                         * Get the length of the name string.
                         */
                        hr = iterProfileWM->GetName (NULL, &nameLength);
                        if (FAILED (hr))
                        {
                                break;
                        }

                        iterProfileName = new WCHAR[ nameLength ];
                        if (iterProfileName == NULL)
                        {
                                hr = E_OUTOFMEMORY;
                                break;
                        }

                        hr = iterProfileWM->GetName (iterProfileName, &nameLength);
                        if (FAILED (hr))
                        {
                                break;
                        }

                        IWMProfile2 *iterProfileWM2;
                        hr = iterProfileWM->QueryInterface (
                                IID_IWMProfile2, (LPVOID*)&iterProfileWM2);
                        if (SUCCEEDED (hr) &&
                            iterProfileWM2 != NULL) {
                                GUID profileID;
                                hr = iterProfileWM2->GetProfileID (&profileID);
                                if (SUCCEEDED (hr)) {
                                        char logBuf[256];
                                        sprintf (logBuf,
                                                "Profile: %d, %ws: ",
                                                profileIndex + 1,
                                                iterProfileName);
                                        log.Info (logBuf);

                                        /*
                                         * Display the system profile index,
                                         * name, and ID.
                                         */
                                        char logBufID[256];
                                        sprintf (logBufID,
                                                "ID: {%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}",
                                                profileID.Data1,
                                                profileID.Data2,
                                                profileID.Data3,
                                                profileID.Data4[0],
                                                profileID.Data4[1],
                                                profileID.Data4[2],
                                                profileID.Data4[3],
                                                profileID.Data4[4],
                                                profileID.Data4[5],
                                                profileID.Data4[6],
                                                profileID.Data4[7]);
                                        log.Info (logBufID);
                                }
                        }

                        delete [] iterProfileName;
                        SAFE_RELEASE (iterProfileWM);
                }
        }
        while (false);

        if (SUCCEEDED (hr)) {
                result = LXe_OK;
        }

        /*
         * Release all resources
         */
        delete [] profileName;
        SAFE_RELEASE (iterProfileWM);

        return result;
}

/*
 * Write the next sample to the open WMV movie file.
 */
        LxResult
CWMVMovie::WriteSample (CLxUser_Image &image)
{
        LxResult		 result = LXe_FAILED;
        HRESULT			 hr = S_OK;
        INSSBuffer		*sample = NULL;

        hr = writeWM->AllocateSample (
                videoInfo.bmiHeader.biSizeImage, &sample);

        CLxUser_Image	 resizedImage;
        if (SUCCEEDED (hr)) {
                if (imageSvc.New (
                        resizedImage,
                        dstImageWidth,
                        dstImageHeight,
                        LXiIMP_RGB24)) {
                        if (LXx_OK (imageSvc.Resample (
                                resizedImage, image,
                                LXiPROCESS_MEDIUM))) {
                                /*
                                 * Verify the buffer is prepared as specified.
                                 */
                                BYTE            *activeBuffer = NULL;
                                DWORD            bufferSize = 0;
                                hr = sample->GetBufferAndLength (
                                        &activeBuffer, &bufferSize);
                                if (SUCCEEDED (hr)) {

                                        const LXtImageByte	*srcLine;
                                        LXtImageByte		*lineBuffer;
                                        LXtImageByte		*dstLine;
                                        unsigned int		 rowBytes;
                                        unsigned int		 width, height;

                                        resizedImage.Size (&width, &height);

                                        rowBytes = (width * 3 + 3) & ~3;
                                        lineBuffer = new LXtImageByte [rowBytes];

                                        for (unsigned y = 0; y < height; ++y) {
                                                /*
                                                 * Fetch a scanline in upside-down order.
                                                 */
                                                srcLine = reinterpret_cast<const LXtImageByte*>(
                                                        resizedImage.GetLine (
                                                                height - y - 1,
                                                                LXiIMP_RGB24,
                                                                lineBuffer));
                                                dstLine = activeBuffer + rowBytes * y;

                                                /*
                                                 * Copy the source image into the active sample buffer,
                                                 * transposing from RGB to BGR as we go.
                                                 */
                                                for (unsigned x = 0; x < width; ++x) {
                                                        dstLine[x * 3 + 0] =
                                                                srcLine[x * 3 + 2];
                                                        dstLine[x * 3 + 1] =
                                                                srcLine[x * 3 + 1];
                                                        dstLine[x * 3 + 2] =
                                                                srcLine[x * 3 + 0];
                                                }
                                        }

                                        delete [] lineBuffer;

                                        hr = writeWM->WriteSample (
                                                videoInput,
                                                10000 * videoTime,
                                                0, sample);
                                        videoTime = (++sampleIndex * 1000) / frameRate;

                                        /*
                                         * If we got this far, we're doing OK.
                                         */
                                        result = LXe_OK;
                                }

                        }
                }
                if (sample) {
                        sample->Release ();
                        sample = NULL;
                }
        }

        return result;
}

/*
 * Fetch the user value from the Image I/O prefs.
 *
 * At this time, only a WMV Profile Index is supported.
 *
 * ImageIO.WMV.profile.index should be defined with a range of 0..6.
 */
        void
CWMVMovie::GetOptions (int &profileIndex)
{
        CLxReadUserValue ruv;
        if (ruv.Query ("ImageIO.WMV.profile.index")) {
                profileIndex = ruv.GetInt ();
                if (profileIndex > 7) {
                        profileIndex = 7;
                }
                else if (profileIndex < 0) {
                        profileIndex = 0;
                }
        }
        else {
                static const int DEFAULT_PROFILE_INDEX = 5;
                profileIndex = DEFAULT_PROFILE_INDEX;
        }
}

/*
 * Set the Windows Media Format type info.
 */
        LxResult
CWMVMovie::SetMediaType ()
{
        LxResult		result = LXe_FAILED;

        /*
         * Specify the source and target bounds.
         */
        videoInfo.rcSource.left		= 0;
        videoInfo.rcSource.top		= 0;
        videoInfo.rcSource.right	= dstImageWidth;
        videoInfo.rcSource.bottom	= dstImageHeight;
        videoInfo.rcTarget		= videoInfo.rcSource;

        /*
         * Configure the bitmap info header.
         */
        videoInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        videoInfo.bmiHeader.biWidth = dstImageWidth;
        videoInfo.bmiHeader.biHeight = dstImageHeight;
        videoInfo.bmiHeader.biPlanes = 1;
        videoInfo.bmiHeader.biBitCount = 24;
        videoInfo.bmiHeader.biCompression = BI_RGB;

        /*
         * Calculate the number of bytes per frame.
         *
         * [TODO] For non-aligned sizes, this needs padding per bmpio.
         */
        unsigned pixelCount = dstImageWidth * dstImageHeight;
        unsigned bitsPerFrame = pixelCount * RGB_PIXEL_BIT_DEPTH;
        videoInfo.bmiHeader.biSizeImage = bitsPerFrame / 8;

        /*
         * Housekeeping for a few misc fields.
         */
        videoInfo.bmiHeader.biXPelsPerMeter = 3779;
        videoInfo.bmiHeader.biYPelsPerMeter = 3779;
        videoInfo.bmiHeader.biClrUsed = 0;
        videoInfo.bmiHeader.biClrImportant = 0;

        mediaType.majortype = WMMEDIATYPE_Video;

        /*
         * [TODO] Use WMMEDIASUBTYPE_RGB32 for alpha support, if available.
         */
        mediaType.subtype = WMMEDIASUBTYPE_RGB24;

        mediaType.bFixedSizeSamples = false;
        mediaType.bTemporalCompression = false;
        mediaType.lSampleSize = 0;
        mediaType.formattype = WMFORMAT_VideoInfo;
        mediaType.pUnk = NULL;
        mediaType.cbFormat = sizeof(WMVIDEOINFOHEADER);
        mediaType.pbFormat = reinterpret_cast<BYTE*>(&videoInfo);

        DWORD	inputCount=0;
        videoInput = 0;
        videoProps = NULL;
        HRESULT hr = writeWM->GetInputCount (&inputCount);
        for (DWORD inputIndex = 0; inputIndex < inputCount; ++inputIndex)
        {
                IWMInputMediaProps	*testInputProps = NULL;
                GUID			 guidInputType;

                if (FAILED (writeWM->GetInputProps (inputIndex, &testInputProps)))
                {
                        log.Info ("Unable to GetInput Properties");
                        continue;
                }
                if (FAILED (testInputProps->GetType (&guidInputType)))
                {
                        log.Info ("Unable to Get Input Property Type");
                        continue;
                }
                if (guidInputType == WMMEDIATYPE_Video)
                {
                        videoProps = testInputProps;
                        videoInput = inputIndex;
                        /*
                         * Found a matching input type for video.
                         */
                        log.Info ("Found Video Input Type.");
                        result = LXe_OK;
                        break;
                }
                else
                {
                        testInputProps->Release();
                        testInputProps = NULL;
                }
        }

        if ((result == LXe_OK )&& (videoProps != NULL)) {
                hr = videoProps->SetMediaType (&mediaType);
                if (FAILED (hr)) {
                        log.Info ("Unable to Set Media Type");
                        result = LXe_FAILED;
                }
                else {
                        hr = writeWM->SetInputProps (videoInput, videoProps);
                        if (FAILED (hr)) {
                                log.Info ("Unable to Set Input Properties for Media Writer");
                                result = LXe_FAILED;
                        }
                        else {
                                hr = writeWM->BeginWriting();
                                if (FAILED (hr)) {
                                        char buffer[256];
                                        sprintf (buffer, "Error=%d\n", hr);
                                        log.Info ("Unable to Initialize Writing:");
                                        log.Info (buffer);
                                        result = LXe_FAILED;
                                }
                        }
                }
        }
        return result;
}

/*
 * Begin writing a movie with the given name and dimensions.
 */
        LxResult
CWMVMovie::mov_BeginMovie (
        const char              *fileName,
        int                      width,
        int                      height,
        int                      flags)
{
        LxResult		result = LXe_FAILED;

        log.Setup ();
        log.Info ("Saving movie: ");
        log.Info (fileName);

        /*
         * Test enumeration over system profiles.
         */
        EnumSystemProfiles ();

        /*
         * Display the source dimensions.
         */
        char buffer[256];

        srcImageWidth = width;
        sprintf (buffer, "Width=%d\n", srcImageWidth);
        log.Info (buffer);

        srcImageHeight = height;
        sprintf (buffer, "Height=%d\n", srcImageHeight);
        log.Info (buffer);

        /*
         * Look up selected profile from Preferences.
         */
        int profileIndex;
        GetOptions (profileIndex);
        HRESULT hr;
#if 0
        hr = profileManagerWM->LoadSystemProfile (
                12, &profileWM);
#else
        static const GUID WMProfile_V90_256Video = {
                0x0de9657d,
                0x5e00,
                0x4ad4,
                0x98,0x3c,0xc7,0xbc,0xb2,0x51,0xed,0xeb};
        static const GUID WMProfile_V90_384Video = {
                0xdf599bfc,
                0x9f14,
                0x458b,
                0x8f,0x59,0x9b,0x31,0xcd,0x37,0xd3,0x83};
        static const GUID WMProfile_V90_768Video = {
                0xb849b50d,
                0xb846,
                0x4e0f,
                0x85,0x7a,0x70,0x15,0x98,0x43,0x6a,0x04};
        static const GUID WMProfile_V90_700NTSCVideo = {
                0x2cafa504,
                0xbd0c,
                0x41cb,
                0xb0,0xef,0xbe,0x95,0x22,0x63,0x72,0xd8};
        static const GUID WMProfile_V90_1400NTSCVideo = {
                0x26120627,
                0x782c,
                0x41a8,
                0xbe,0x71,0x2a,0xdf,0x4d,0xe6,0x27,0x6d};
        static const GUID WMProfile_V90_384PALVideo = {
                0x888fc5fd,
                0x761e,
                0x44a2,
                0xb1,0x50,0x15,0x2f,0xd4,0xbc,0x4d,0x26};
        static const GUID WMProfile_V90_700PALVideo = {
                0xbb61c755,
                0xdc2d,
                0x4431,
                0xbb,0x83,0xdc,0x46,0x33,0x87,0x8f,0x2a};

        switch (profileIndex) {
                case 0: {
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V80_256Video :
                                        WMProfile_V90_256Video);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }

                case 1: {
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V80_384Video :
                                        WMProfile_V90_384Video);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }

                case 2: {
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V80_768Video :
                                        WMProfile_V90_768Video);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }

                case 3: {
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V80_700NTSCVideo :
                                        WMProfile_V90_700NTSCVideo);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }

                case 4: {
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V80_1400NTSCVideo :
                                        WMProfile_V90_1400NTSCVideo);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }

                case 5: {
                        /*
                         * Windows Media 7 only available on Vista.
                         * On XP64, fall back to V80 1400 NTSC Video.
                         */
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V70_2000Video :
                                        WMProfile_V90_1400NTSCVideo);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }

                case 6: {
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V80_384PALVideo :
                                        WMProfile_V90_384PALVideo);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }

                case 7: {
                        const GUID& guidProfileID =
                                ((profileVersion == WMT_VER_8_0) ?
                                        WMProfile_V80_700PALVideo :
                                        WMProfile_V90_700PALVideo);
                        hr = profileManagerWM->LoadProfileByID (
                                guidProfileID, &profileWM);
                        break;
                }
        }
#endif
        if (FAILED (hr)) {
                log.Info ("Unable to load Windows Media profile by ID.");
        }
        else {
                /*
                 * Log the selected profile.
                 */
                IWMProfile2 *profileWM2;
                hr = profileWM->QueryInterface (
                        IID_IWMProfile2, (LPVOID*)&profileWM2);
                if (SUCCEEDED (hr) &&
                    profileWM2 != NULL) {
                        GUID profileID;
                        hr = profileWM2->GetProfileID (&profileID);
                        if (SUCCEEDED (hr)) {
                                log.Info ("Selected Profile ID: ");
                                char logBuf[256];
                                sprintf (logBuf,
                                        "{%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}",
                                        profileID.Data1,
                                        profileID.Data2,
                                        profileID.Data3,
                                        profileID.Data4[0],
                                        profileID.Data4[1],
                                        profileID.Data4[2],
                                        profileID.Data4[3],
                                        profileID.Data4[4],
                                        profileID.Data4[5],
                                        profileID.Data4[6],
                                        profileID.Data4[7]);
                                log.Info (logBuf);
                        }
                }
                HRESULT hr = WMCreateWriter (NULL, &writeWM);
                if (FAILED (hr)) {
                        log.Info ("Unable to create Windows Media writer.");
                }
                else {
                        hr = writeWM->SetProfile (profileWM);
                        if (FAILED (hr)) {
                        }
                        else {
                                WCHAR		wideFileName[1024];

                                hr = MultiByteToWideChar (
                                        CP_ACP, 0,
                                        fileName, -1,
                                        wideFileName,
                                        sizeof(wideFileName));
                                if (FAILED (hr)) {
                                        log.Info ("Invalid file name.");
                                }
                                else {
                                        hr = writeWM->SetOutputFilename (wideFileName);
                                        if (SUCCEEDED (hr)) {
                                                if (srcImageWidth <= 360) {
                                                        dstImageWidth = 360;
                                                        dstImageHeight = 240;
                                                }
                                                else {
                                                        dstImageWidth = 720;
                                                        dstImageHeight = 480;
                                                }
                                                result = SetMediaType ();

                                                sampleIndex = 0;
                                                videoTime = 0;
                                        }
                                }
                        }
                }
        }
        return result;
}	

/*
 * Set the number of frames per second.
 */
        LxResult
CWMVMovie::mov_SetFramerate (
        int			 fps)
{
        /*
         * Log the frame rate.
         */
        char buffer[256];
        sprintf (buffer, "FPS=%d\n", fps);
        log.Info (buffer);

        /*
         * Calculate bit rate per second.
         */
        frameRate = fps;
        unsigned pixelCount = dstImageWidth * dstImageHeight;
        unsigned bitsPerFrame = pixelCount * RGB_PIXEL_BIT_DEPTH;
        videoInfo.dwBitRate = (bitsPerFrame * frameRate);
        videoInfo.dwBitErrorRate = 0;

        /*
         * Set the average time per frame in 100ns units.
         */
        videoInfo.AvgTimePerFrame = static_cast<LONGLONG>(10000) * 1000 / frameRate;

        return LXe_OK;
}	

/*
 * Add another image frame to the movie.
 */
        LxResult
CWMVMovie::mov_AddImage (
        ILxUnknownID		 img)
{
        LxResult		 result;
        CLxUser_Image		 image (img);

        result = WriteSample (image);
        if (LXx_FAIL (result))
                return result;

        /*
         * Log the frame index.
         */
        char buffer[256];
        sprintf (buffer, "Frame number=%d\n", sampleIndex);
        log.Info (buffer);

        return LXe_OK;
}

/*
 * Finish up writing the movie and close the output file.
 */
        LxResult
CWMVMovie::mov_EndMovie (void)
{
        if (writeWM) {
                writeWM->EndWriting ();	
                writeWM->Release ();
                writeWM = NULL;

                log.Info ("Movie saved successfully.");
        }

        if (videoProps) {
                videoProps->Release ();
                videoProps = NULL;
        }
        return LXe_OK;
}

LXtTagInfoDesc	 CWMVMovie::descInfo[] = {
        { LXsLOD_CLASSLIST,	LXa_MOVIE	},
        { LXsLOD_DOSPATTERN,	"*.wmv"		},
        { LXsSAV_DOSTYPE,	"wmv"		},
        { LXsSRV_USERNAME,	"WMV Movie"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"	},
        { 0 }
};

/*
 * ----------------------------------------------------------------
 * Exporting Servers
 */
        void
initialize ()
{
        LXx_ADD_SERVER (Movie, CWMVMovie, "winmovie");
}


