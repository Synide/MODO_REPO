/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_file.h"

#include "cio_collada.h"
#include "cio_format.h"
#include "cio_schema.h"

#include <string>

using namespace std;

namespace cio {

#define COLLADAdocument		TiXmlDocument

/*
 * ---------------------------------------------------------------------------
 * File opening and saving.
 */

class pv_File
{
    public:
        COLLADAdocument		*document;
        IO_MODE			 ioMode;

                                 pv_File (IO_MODE mode);
        virtual			~pv_File ();

        bool			 LoadDocument (const string fileName);
};

pv_File::pv_File (
        IO_MODE	 mode)
        :
        document(NULL),
        ioMode(mode)
{
        if (ioMode == IO_MODE_SAVE) {
                document = new COLLADAdocument ();
        }
}

pv_File::~pv_File ()
{
        delete document;
}

/*
 * Internally, TinyXML deletes any leftover data before loading.
 */
        bool
pv_File::LoadDocument (const string fileName)
{
        bool	loaded(false);
        if (ioMode == IO_MODE_LOAD) {
                document = new COLLADAdocument (fileName.c_str ());
                loaded = document->LoadFile ();
        }
        return loaded;
}

File::File (IO_MODE mode)
        :
        pv(new pv_File (mode))
{
}

File::~File ()
{
        delete pv;
}

/*
 *
 */
        bool
File::OpenDocument (
        const std::string	&fileName,
        COLLADAElement		&collada)
{
        bool	opened(false);

        if (pv->ioMode == IO_MODE_SAVE) {
                ElementXML		*root;

                /*
                 * Start with an XML declaration.
                 */
                TiXmlDeclaration* declaration =
                        new TiXmlDeclaration (ATTRVALUE_XMLVERSION, ATTRVALUE_XMLENCODING, "");
                pv->document->LinkEndChild (declaration);

                /*
                 * Create the COLLADA root element and set its attributes.
                 */
                root = new TiXmlElement (ELEMENT_COLLADA);
                pv->document->LinkEndChild (root);

                root->SetAttribute(ATTRIBUTE_XMLNS, ATTRVALUE_COLLADASCHEMAURL);
                root->SetAttribute(ATTRIBUTE_VERSION, ATTRVALUE_COLLADAVERSION);

                if (root) {
                        collada.SetElement (root);
                }

                opened = (root != NULL);
        }
        else if (pv->ioMode == IO_MODE_TALLY) {
                opened = true;
        }

        return opened;
}

/*
 * Load the text stream into an XML document.
 */
        bool
File::LoadDocument (
        const string		&fileName,
        COLLADAElement	&collada)
{
        bool		loaded(false);
        ElementXML	*root;

        loaded = pv->LoadDocument (fileName);

        TiXmlHandle hDoc(pv->document);
        root = hDoc.FirstChildElement (ELEMENT_COLLADA).Element ();

        loaded = (root != NULL);
        if (loaded) {
                collada.SetElement (root);
        }

        return loaded;
}

/*
 *
 */
        bool
File::SaveDocument (
        const char		*fileName)
{
        return pv->document->SaveFile (fileName);
}

} // namespace cio

