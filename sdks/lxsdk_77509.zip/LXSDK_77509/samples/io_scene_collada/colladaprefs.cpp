/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "colladaconfig.h"
#include "colladaprefs.h"

#include "../libcolladaio/cio_strings.h"

#include <lxu_prefvalue.hpp>
#include <lxu_queries.hpp>
#include <lxvalue.h>
#include <lx_value.hpp>

const unsigned MAX_USER_VALUE_LEN = 256;

using namespace std;
using namespace cio;

/*
 * Preference config keys.
 */
static const char* LXsUSER_VALUE_COLLADA_ASSET_KEYWORDS		= "sceneio.collada.asset.keywords";
static const char* LXsUSER_VALUE_COLLADA_ASSET_REVISION		= "sceneio.collada.asset.revision";
static const char* LXsUSER_VALUE_COLLADA_ASSET_SUBJECT		= "sceneio.collada.asset.subject";
static const char* LXsUSER_VALUE_COLLADA_ASSET_TITLE		= "sceneio.collada.asset.title";

static const char* LXsUSER_VALUE_COLLADA_ORDER_VMAPS_ALPHABETICALLY = "sceneio.collada.order.vmaps.alphabetically";
static const char* LXsUSER_VALUE_COLLADA_BAKE_MATRICES		= "sceneio.collada.bake.matrices";
static const char* LXsUSER_VALUE_COLLADA_SAVE_NORMALS		= "sceneio.collada.save.normals";
static const char* LXsUSER_VALUE_COLLADA_SAVE_TEXCOORDS		= "sceneio.collada.save.texcoords";
static const char* LXsUSER_VALUE_COLLADA_SAVE_COLORS		= "sceneio.collada.save.colors";
static const char* LXsUSER_VALUE_COLLADA_SAVE_WEIGHTS		= "sceneio.collada.save.weights";

static const char* LXsUSER_VALUE_COLLADA_SAVE_HIDDEN_ITEMS	= "sceneio.collada.save.hidden.items";
static const char* LXsUSER_VALUE_COLLADA_SAVE_CAMERAS		= "sceneio.collada.save.cameras";
static const char* LXsUSER_VALUE_COLLADA_SAVE_LIGHTS		= "sceneio.collada.save.lights";
static const char* LXsUSER_VALUE_COLLADA_SAVE_LOCATORS		= "sceneio.collada.save.locators";
static const char* LXsUSER_VALUE_COLLADA_SAVE_TRIANGLES_AS_TRIANGLES = "sceneio.collada.save.triangles.as.triangles";
static const char* LXsUSER_VALUE_COLLADA_SAVE_ANIMATION		= "sceneio.collada.save.animation";
static const char* LXsUSER_VALUE_COLLADA_SAMPLE_ANIMATION	= "sceneio.collada.sample.animation";
static const char* LXsUSER_VALUE_COLLADA_SAMPLE_ANIMATION_START	= "sceneio.collada.sample.animation.start";
static const char* LXsUSER_VALUE_COLLADA_SAMPLE_ANIMATION_END	= "sceneio.collada.sample.animation.end";

static const char* LXsUSER_VALUE_COLLADA_Z_NEAR			= "sceneio.collada.z.near";
static const char* LXsUSER_VALUE_COLLADA_Z_FAR			= "sceneio.collada.z.far";

static const char* LXsUSER_VALUE_COLLADA_SAVE_MODO_PROFILE	= "sceneio.collada.save.modo.profile";
static const char* LXsUSER_VALUE_COLLADA_SAVE_MAYA_PROFILE	= "sceneio.collada.save.maya.profile";
static const char* LXsUSER_VALUE_COLLADA_SAVE_MAX3D_PROFILE	= "sceneio.collada.save.max3d.profile";
static const char* LXsUSER_VALUE_COLLADA_SAVE_OKINO_PROFILE	= "sceneio.collada.save.okino.profile";
static const char* LXsUSER_VALUE_COLLADA_SAVE_XSI_PROFILE	= "sceneio.collada.save.xsi.profile";

static const char* LXsUSER_VALUE_COLLADA_FORMATTED_ARRAYS	= "sceneio.collada.formatted.arrays";

static const char* LXsUSER_VALUE_COLLADA_IMPORT_UNITS		= "sceneio.collada.import.units";
static const char* LXsUSER_VALUE_COLLADA_IMPORT_UP_AXIS		= "sceneio.collada.import.up.axis";

/*
 * Export comment building blocks.
 */
static const char* EXPORT_VALUE_YES			= "Yes";
static const char* EXPORT_VALUE_NO			= "No";
static const char* EXPORT_VALUE_DELIM_PREFIX		= ": ";
static const char* EXPORT_VALUE_DELIM_SUFFIX		= ";";

static const char* EXPORT_USE_ABSOLUTE_PATH		= "Use Absolute Path";
static const char* EXPORT_MERGE_REFERENCE_ITEMS		= "Merge Reference Items";

static const char* EXPORT_SAVE_HIDDEN_ITEMS		= "Save Hidden Items";
static const char* EXPORT_SAVE_CAMERAS			= "Save Cameras";
static const char* EXPORT_SAVE_LIGHTS			= "Save Lights";
static const char* EXPORT_SAVE_LOCATORS			= "Save Locators";
static const char* EXPORT_SAVE_TRIANGLES_AS_TRIANGLES	= "Save Triangles as Triangles";

static const char* EXPORT_ORDER_VMAPS_ALPHABETICALLY	= "Order Vertex Maps Alphabetically";
static const char* EXPORT_BAKE_MATRICES			= "Bake Matrices";
static const char* EXPORT_SAVE_NORMALS			= "Save Vertex Normals";
static const char* EXPORT_SAVE_TEXCOORDS		= "Save UV Texture Coordinates";
static const char* EXPORT_SAVE_COLORS			= "Save Vertex Colors";
static const char* EXPORT_SAVE_WEIGHTS			= "Save Vertex Weights";

static const char* EXPORT_SAVE_ANIMATION		= "Save Animation";
static const char* EXPORT_SAMPLE_ANIMATION		= "Sample Animation";
static const char* EXPORT_SAMPLE_ANIMATION_START	= "Sample Animation Start";
static const char* EXPORT_SAMPLE_ANIMATION_END		= "Sample Animation End";

static const char* EXPORT_SAVE_MODO_PROFILE		= "Save modo Profile";
static const char* EXPORT_SAVE_MAYA_PROFILE		= "Save Maya Profile";
static const char* EXPORT_SAVE_MAX3D_PROFILE		= "Save 3ds Max Profile";

static const char* EXPORT_FORMATTED_ARRAYS		= "Formatted Arrays";

COLLADAprefs::COLLADAprefs ()
{
}

COLLADAprefs::~COLLADAprefs ()
{
}

        static string
GetPreferenceString (const char *prefKey)
{
        string	value;
        char	textChars[MAX_USER_VALUE_LEN];
        CLxReadPreferenceValue ruvPref;
        if (ruvPref.Query (prefKey)) {
                const char *valueChars = ruvPref.GetString (
                        textChars, MAX_USER_VALUE_LEN);
                value = string(valueChars);
        }

        return value;
}

        static int
GetPreferenceInt (const char *prefKey, int defaultValue = 0)
{
        int	value = defaultValue;
        CLxReadPreferenceValue ruvPref;
        if (ruvPref.Query (prefKey)) {
                value = ruvPref.GetInt ();
        }

        return value;
}

        static double
GetPreferenceFloat (const char *prefKey, double defaultValue = 0.0f)
{
        double	value = defaultValue;
        CLxReadPreferenceValue ruvPref;
        if (ruvPref.Query (prefKey)) {
                value = ruvPref.GetFloat ();
        }

        return value;
}

        static string
GetPreferenceIntHint (const char *prefKey)
{
        int	value = 0;
        string	hint;
        CLxReadPreferenceValue ruvPref;
        if (ruvPref.Query (prefKey)) {
                value = ruvPref.GetInt ();
                const LXtTextValueHint *hints;
                const unsigned MAX_HINT_TEXT_LENGTH = 2048;
                char	 hintText[MAX_HINT_TEXT_LENGTH];
                if (LXx_OK (ruvPref.IntHint (&hints))) {
                        CLxUser_ValueService	valueSvc;
                        if (LXx_OK (valueSvc.TextHintEncode (
                                value, hints, hintText, MAX_HINT_TEXT_LENGTH))) {
                                hint = string(hintText);
                        }
                }
        }

        return hint;
}

        static string
GetUserString (const char *prefKey)
{
        string	value;
        CLxReadUserValue ruvUser;
        if (ruvUser.Query (prefKey))
                ruvUser.GetString (value);

        return value;
}

        static int
GetUserInt (const char *prefKey, int defaultValue = 0)
{
        int	value = defaultValue;
        CLxReadUserValue ruvUser;
        if (ruvUser.Query (prefKey)) {
                value = ruvUser.GetInt ();
        }

        return value;
}

        static double
GetUserFloat (const char *prefKey, double defaultValue = 0.0)
{
        double	value = defaultValue;
        CLxReadUserValue ruvUser;
        if (ruvUser.Query (prefKey)) {
                value = ruvUser.GetFloat ();
        }

        return value;
}

/*
 * Export.
 */

        static string
YesNoComment (const string &commentName, bool enabled)
{
        return commentName + string(EXPORT_VALUE_DELIM_PREFIX) + (enabled ?
                string(EXPORT_VALUE_YES) : string(EXPORT_VALUE_NO)) +
                string(EXPORT_VALUE_DELIM_SUFFIX);
}

        static string
IntegerComment (const string &commentName, unsigned value)
{
        return commentName + string(EXPORT_VALUE_DELIM_PREFIX) +
                IntegerToString (value) + string(EXPORT_VALUE_DELIM_SUFFIX);
}

        void
COLLADAprefs::GetExportComments (StringArray &comments) const
{
        comments.push_back (YesNoComment (EXPORT_USE_ABSOLUTE_PATH, UseAbsolutePath ()));
        comments.push_back (YesNoComment (EXPORT_MERGE_REFERENCE_ITEMS, MergeReferenceItems ()));

        comments.push_back (YesNoComment (EXPORT_SAVE_HIDDEN_ITEMS, SaveHiddenItems ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_CAMERAS, SaveCameras ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_LIGHTS, SaveLights ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_LOCATORS, SaveLocators ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_TRIANGLES_AS_TRIANGLES, SaveTrianglesAsTriangles ()));

        comments.push_back (YesNoComment (EXPORT_ORDER_VMAPS_ALPHABETICALLY, OrderVMapsAlphabetically ()));
        comments.push_back (YesNoComment (EXPORT_BAKE_MATRICES, BakeMatrices ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_NORMALS, SaveVertexNormals ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_TEXCOORDS, SaveUVTextureCoordinates ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_COLORS, SaveVertexColors ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_WEIGHTS, SaveWeights ()));

        comments.push_back (YesNoComment (EXPORT_SAVE_ANIMATION, SaveAnimation ()));

        comments.push_back (YesNoComment (EXPORT_SAMPLE_ANIMATION, SampleAnimation ()));
        comments.push_back (IntegerComment (EXPORT_SAMPLE_ANIMATION_START, SampleStartFrame ()));
        comments.push_back (IntegerComment (EXPORT_SAMPLE_ANIMATION_END, SampleEndFrame ()));

        comments.push_back (YesNoComment (EXPORT_SAVE_MODO_PROFILE, SaveModoProfile ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_MAYA_PROFILE, SaveMayaProfile ()));
        comments.push_back (YesNoComment (EXPORT_SAVE_MAX3D_PROFILE, SaveMax3DProfile ()));
        comments.push_back (YesNoComment (EXPORT_FORMATTED_ARRAYS, FormattedArrays ()));
}

        bool
COLLADAprefs::UseAbsolutePath () const
{
        return (GetPreferenceInt (LXsPREFERENCE_VALUE_EXPORT_ABSOLUTE_PATH) ? true : false);
}

        bool
COLLADAprefs::MergeReferenceItems () const
{
        return (GetPreferenceInt (LXsPREFERENCE_VALUE_EXPORT_MERGE_REFS) ? true : false);
}

        int
COLLADAprefs::GetUnitSystem () const
{
        return GetPreferenceInt (
                LXsPREFERENCE_VALUE_ACCURACY_UNIT_SYSTEM,
                LXiPREFERENCE_VALUE_UNIT_SYSTEM_METRIC);
}

        int
COLLADAprefs::GetDefaultUnit () const
{
        return GetPreferenceInt (
                LXsPREFERENCE_VALUE_ACCURACY_DEFAULT_UNIT,
                LXsPREFERENCE_VALUE_UNIT_SI_METERS);
}

        float
COLLADAprefs::GetMetersPerGameUnit () const
{
        return static_cast<float>(GetPreferenceFloat (
                LXsPREFERENCE_VALUE_METERS_PER_GAME_UNIT, 1.0));
}

        int
COLLADAprefs::GetUpAxis () const
{
        return GetPreferenceInt (
                LXsPREFERENCE_VALUE_ACCURACY_UP_AXIS,
                LXsPREFERENCE_VALUE_UP_AXIS_Y);
}

        bool
COLLADAprefs::SaveHiddenItems () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_HIDDEN_ITEMS) ? true : false);
}

        bool
COLLADAprefs::SaveCameras () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_CAMERAS) ? true : false);
}

        bool
COLLADAprefs::SaveLights () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_LIGHTS) ? true : false);
}

        bool
COLLADAprefs::SaveLocators () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_LOCATORS) ? true : false);
}

        bool
COLLADAprefs::SaveTrianglesAsTriangles () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_TRIANGLES_AS_TRIANGLES) ? true : false);
}

        bool
COLLADAprefs::OrderVMapsAlphabetically () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_ORDER_VMAPS_ALPHABETICALLY) ? true : false);
}

        bool
COLLADAprefs::BakeMatrices () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_BAKE_MATRICES) ? true : false);
}

        bool
COLLADAprefs::SaveVertexNormals () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_NORMALS) ? true : false);
}

        bool
COLLADAprefs::SaveUVTextureCoordinates () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_TEXCOORDS) ? true : false);
}

        bool
COLLADAprefs::SaveVertexColors () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_COLORS) ? true : false);
}

                bool
COLLADAprefs::SaveWeights () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_WEIGHTS) ? true : false);
}

        bool
COLLADAprefs::SaveAnimation () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_ANIMATION) ? true : false);
}

        bool
COLLADAprefs::SampleAnimation () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAMPLE_ANIMATION) ? true : false);
}

        int
COLLADAprefs::SampleStartFrame () const
{
        return GetUserInt (LXsUSER_VALUE_COLLADA_SAMPLE_ANIMATION_START, 0);
}

        int
COLLADAprefs::SampleEndFrame () const
{
        return GetUserInt (LXsUSER_VALUE_COLLADA_SAMPLE_ANIMATION_END, 120);
}

        double
COLLADAprefs::GetZNear () const
{
        static const float ZNEAR_DEFAULT	= 0.01f;
        static const float ZNEAR_MIN		= 0.001f;
        static const float ZNEAR_MAX		= 1.0f;

        double zNear = GetUserFloat (LXsUSER_VALUE_COLLADA_Z_NEAR, ZNEAR_DEFAULT);
        if (zNear > ZNEAR_MAX) {
                zNear = ZNEAR_MAX;
        }
        else if (zNear < ZNEAR_MIN) {
                zNear = ZNEAR_MIN;
        }

        return zNear;
}

        double
COLLADAprefs::GetZFar () const
{
        static const float ZFAR_DEFAULT		= 10000.0f;
        static const float ZFAR_MIN		= 1.0f;
        static const float ZFAR_MAX		= 65535.0f;

        double zFar = GetUserFloat (LXsUSER_VALUE_COLLADA_Z_FAR, ZFAR_DEFAULT);
        if (zFar > ZFAR_MAX) {
                zFar = ZFAR_MAX;
        }
        else if (zFar < ZFAR_MIN) {
                zFar = ZFAR_MIN;
        }

        return zFar;
}

        bool
COLLADAprefs::SaveModoProfile () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_MODO_PROFILE) ? true : false);
}

        bool
COLLADAprefs::SaveMayaProfile () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_MAYA_PROFILE) ? true : false);
}

        bool
COLLADAprefs::SaveMax3DProfile () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_MAX3D_PROFILE) ? true : false);
}

        bool
COLLADAprefs::SaveOkinoProfile () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_OKINO_PROFILE) ? true : false);
}

        bool
COLLADAprefs::SaveXSIProfile () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_SAVE_XSI_PROFILE) ? true : false);
}

        bool
COLLADAprefs::FormattedArrays () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_FORMATTED_ARRAYS) ? true : false);
}

/*
 * Import.
 */

        bool
COLLADAprefs::ImportUnits () const

{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_IMPORT_UNITS) ? true : false);
}

        bool
COLLADAprefs::ImportUpAxis () const
{
        return (GetUserInt (LXsUSER_VALUE_COLLADA_IMPORT_UP_AXIS) ? true : false);
}

/*
 * Animation.
 */

        double
COLLADAprefs::GetFPS () const
{
        double	fps;

        string hint = GetPreferenceIntHint (LXsPREFERENCE_VALUE_ANIMATION_FPS);
        if (hint == string(LXsPREFERENCE_VALUE_ANIMATION_FPS_FILM_24)) {
                fps = LXiPVAL_ANIMATION_FPS_FILM_24;
        }
        else if (hint == string(LXsPREFERENCE_VALUE_ANIMATION_FPS_PAL_25)) {
                fps = LXiPVAL_ANIMATION_FPS_PAL_25;
        }
        else if (hint == string(LXsPREFERENCE_VALUE_ANIMATION_FPS_NTSC_29)) {
                fps = LXiPVAL_ANIMATION_FPS_NTSC_29;
        }
        else if (hint == string(LXsPREFERENCE_VALUE_ANIMATION_FPS_NTSC_30)) {
                fps = LXiPVAL_ANIMATION_FPS_NTSC_30;
        }
        else {
                fps = GetPreferenceFloat (
                        LXsPREFERENCE_VALUE_ANIMATION_FPS_CUSTOM_RATE,
                        LXiPVAL_ANIMATION_FPS_FILM_24);
        }

        return fps;
}

        double
COLLADAprefs::GetTimeRangeStart () const
{
        return GetPreferenceFloat (
                LXsPREFERENCE_VALUE_ANIMATION_TIME_RANGE_START,
                0.0);
}

        double
COLLADAprefs::GetTimeRangeEnd () const
{
        return GetPreferenceFloat (
                LXsPREFERENCE_VALUE_ANIMATION_TIME_RANGE_END,
                60.0);
}

