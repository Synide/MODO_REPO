/*
 * Custom log messages.
 */
class OBJLogMessage : public CLxLuxologyLogMessage
{
    public:
        virtual const char *	GetFormat ()
        {
                return "Wavefront Object";
        }

    private:
        std::string		authoringTool;
};
