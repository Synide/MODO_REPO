/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_light.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_strings.h"
#include "cio_profiles.h"
#include "cio_bind.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Light.
 */

struct pv_LightElement
{
        pv_LightElement ()
                :
                extra(NULL),
                technique(NULL)
        {
        }

        ElementXML *		 AddTechniqueProfile_modo401 ();

        bool			 GetLightColor (
                                        ElementXML		*colorElement,
                                        Element::ColorRGB	&color);

        Element			*light;
        ElementXML		*extra;
        ElementXML		*technique;

        /*
         * Color element is shared by all common light subtypes.
         */
        Element			*lightSubType;
        ElementXML		*colorElem;
};

        ElementXML *
pv_LightElement::AddTechniqueProfile_modo401 ()
{
        if (technique) {
                light->ClearElementValue (technique);
        }
        else {
                extra = light->AddElement (ELEMENT_EXTRA);
                technique = light->AddElement (extra, ELEMENT_TECHNIQUE);
        }

        light->SetAttribute (technique, ATTRIBUTE_PROFILE, PROFILE_MODO401);

        return technique;
}

        bool
pv_LightElement::GetLightColor (
        ElementXML			*colorElement,
        Element::ColorRGB		&color)
{
        bool		hasColor(false);

        if (colorElement) {
                Element::FloatArray	values;
                lightSubType->GetElementValue (colorElement, values);
                if (values.size () <= 3) {
                        for (unsigned channel = 0; channel < values.size (); ++channel) {
                                color[channel] = values[channel];
                        }
                        hasColor = true;
                }
        }

        return hasColor;
}

LightElement::LightElement (
         LightLibraryElement	&library,
         const std::string	&id,
         const std::string	&name)
        :
        Element(library.PV ()),
        pv(new pv_LightElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddLight (*this);

                pv->light = this;

                SetID (LightID (ItemID (id)));
                SetName (name);
        }
}

LightElement::LightElement (
         LightLibraryElement &library)
        :
        Element(library.PV ()),
        pv(new pv_LightElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                pv->light = this;
        }
}

LightElement::~LightElement ()
{
        delete pv;
}

        bool
LightElement::IsAmbient () const
{
        return HasGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_AMBIENT);
}

        bool
LightElement::LinkAmbientLight (
        AmbientLightElement &light)
{
        bool	linked(false);

        /*
         * Copy this light's linkage onto the directional light.
         */
        light.SetElement (pv->light->GetElement ());
        light.LightElementPV ()->light = pv->light;
        light.LightElementPV ()->technique = pv->technique;

        /*
         * Link to the light sub-type and its color.
         */
        light.LightElementPV ()->lightSubType = &light;

        /*
         * Now we're ready to link deeper into the light sub-type.
         */
        linked = LinkGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_AMBIENT, light);
        if (linked) {
                light.LightElementPV ()->colorElem =
                        light.GetElementHandle ().FirstChildElement (
                                ELEMENT_COLOR).Element ();
                light.LinkColor ();
        }

        return linked;
}

        bool
LightElement::IsDirectional () const
{
        return HasGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_DIRECTIONAL);
}

        bool
LightElement::LinkDirectionalLight (
        DirectionalLightElement &light)
{
        bool	linked(false);

        /*
         * Copy this light's linkage onto the directional light.
         */
        light.SetElement (pv->light->GetElement ());
        light.LightElementPV ()->light = pv->light;
        light.LightElementPV ()->technique = pv->technique;

        /*
         * Link to the light sub-type and its color.
         */
        light.LightElementPV ()->lightSubType = &light;

        /*
         * Now we're ready to link deeper into the light sub-type.
         */
        linked = LinkGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_DIRECTIONAL, light);
        if (linked) {
                light.LightElementPV ()->colorElem =
                        light.GetElementHandle ().FirstChildElement (
                                ELEMENT_COLOR).Element ();
                light.LinkColor ();
        }

        return linked;
}

        bool
LightElement::IsPoint () const
{
        return HasGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_POINT);
}

        bool
LightElement::LinkPointLight (
        PointLightElement &light)
{
        bool	linked(false);

        /*
         * Copy this light's linkage onto the directional light.
         */
        light.SetElement (pv->light->GetElement ());
        light.LightElementPV ()->light = pv->light;
        light.LightElementPV ()->technique = pv->technique;

        /*
         * Link to the light sub-type and its color.
         */
        light.LightElementPV ()->lightSubType = &light;

        /*
         * Now we're ready to link deeper into the light sub-type.
         */
        linked = LinkGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_POINT, light);
        if (linked) {
                light.LightElementPV ()->colorElem =
                        light.GetElementHandle ().FirstChildElement (
                                ELEMENT_COLOR).Element ();
                light.LinkColor ();

                /*
                 * [TODO] Link to additional spot light-specific elements.
                 */
        }

        return linked;
}

        bool
LightElement::IsSpot () const
{
        return HasGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_SPOT);
}

        bool
LightElement::LinkSpotLight (
        SpotlightElement &light)
{
        bool	linked(false);

        /*
         * Copy this light's linkage onto the directional light.
         */
        light.SetElement (pv->light->GetElement ());
        light.LightElementPV ()->light = pv->light;
        light.LightElementPV ()->technique = pv->technique;

        /*
         * Link to the light sub-type and its color.
         */
        light.LightElementPV ()->lightSubType = &light;

        /*
         * Now we're ready to link deeper into the light sub-type.
         */
        linked = LinkGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_SPOT, light);
        if (linked) {
                light.LightElementPV ()->colorElem =
                        light.GetElementHandle ().FirstChildElement (
                                ELEMENT_COLOR).Element ();
                light.LinkColor ();

                /*
                 * [TODO] Link to additional spot light-specific elements.
                 */
        }

        return linked;
}

        void
LightElement::LinkColor ()
{
}

        bool
LightElement::LinkTechniqueProfile_modo401 (
        LightElement_modo401 &light)
{
        return LinkExtraTechniqueProfile (PROFILE_MODO401, light);
}

        void
LightElement::AddTechniqueProfile_modo401 (
        LightElement_modo401 &light)
{
        light.SetElement (pv->AddTechniqueProfile_modo401 ());
}

        struct pv_LightElement *
LightElement::LightElementPV () const
{
        return pv;
}

/*
 * ---------------------------------------------------------------------------
 * Ambient Light.
 */

#if 0
/*
 * [TODO]
 * Local class with which an ambient element can be constructed using the
 * higher-level Element APIs.
 */
struct AmbientElement : public Element
{
        AmbientElement (TechniqueCommonElement &technique)
                :
                Element (technique.PV ())
        {
        }

        virtual		~AmbientElement ()
        {
        }


};
#endif

struct pv_AmbientLightElement
{
        pv_AmbientLightElement ()
                :
                techniqueCommon(NULL),
                ambient(NULL),
                color(NULL)
        {
        }

        virtual ~pv_AmbientLightElement ()
        {
        }

        ElementXML	*techniqueCommon;
        ElementXML	*ambient;
        ElementXML	*color;
};

AmbientLightElement::AmbientLightElement (
        LightLibraryElement	&library,
        const std::string	&id,
        const std::string	&name)
        :
        LightElement (library, id, name),
        pv(new pv_AmbientLightElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
                pv->ambient = AddElement (pv->techniqueCommon, ELEMENT_AMBIENT);
        }
}

AmbientLightElement::AmbientLightElement (
        LightLibraryElement	&library)
        :
        LightElement (library),
        pv(new pv_AmbientLightElement())
{
}

AmbientLightElement::~AmbientLightElement ()
{
        delete pv;
}

        bool
AmbientLightElement::GetColor (ColorRGB &color)
{
        return false;

// [TODO] Use local AmbientElement class.
//	return GetElementValue (GetElement (), &pv->color,
//		string(ELEMENT_COLOR), color);
}

        void
AmbientLightElement::SetColor (const ColorRGB &color)
{
        if (pv->color) {
                ClearElementValue (pv->color);
        }
        else {
                pv->color = AddElement (pv->ambient, ELEMENT_COLOR);
                SetSID (pv->color, PARAM_AMBIENT_LIGHT_COLOR);
        }

        SetElementValue (pv->color, color);
}

        void
AmbientLightElement::LinkColor ()
{
        pv->color = LightElementPV ()->colorElem;
}

/*
 * ---------------------------------------------------------------------------
 * Point Light.
 */

struct pv_PointLightElement
{
        pv_PointLightElement ()
                :
                techniqueCommon(NULL),
                point(NULL),
                color(NULL),
                constantAttenuation(NULL),
                linearAttenuation(NULL),
                quadraticAttenuation(NULL),
                zFar(NULL)
        {
        }

        virtual ~pv_PointLightElement ()
        {
        }

        ElementXML	*techniqueCommon;
        ElementXML	*point;
        ElementXML	*color;
        ElementXML	*constantAttenuation;
        ElementXML	*linearAttenuation;
        ElementXML	*quadraticAttenuation;
        ElementXML	*zFar;
};

PointLightElement::PointLightElement (
        LightLibraryElement	&library,
        const std::string	&id,
        const std::string	&name)
        :
        LightElement (library, id, name),
        pv(new pv_PointLightElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
                pv->point = AddElement (pv->techniqueCommon, ELEMENT_POINT);
        }
}

PointLightElement::PointLightElement (
        LightLibraryElement	&library)
        :
        LightElement (library),
        pv(new pv_PointLightElement())
{
}

PointLightElement::~PointLightElement ()
{
        delete pv;
}

        bool
PointLightElement::GetColor (ColorRGB &color)
{
        return LightElement::pv->GetLightColor (pv->color, color);
}

        void
PointLightElement::SetColor (const ColorRGB &color)
{
        if (pv->color) {
                ClearElementValue (pv->color);
        }
        else {
                pv->color = AddElement (pv->point, ELEMENT_COLOR);
                SetSID (pv->color, PARAM_POINT_LIGHT_COLOR);
        }

        SetElementValue (pv->color, color);
}

        void
PointLightElement::SetConstantAttenuation (double attenuation)
{
        if (pv->constantAttenuation) {
                ClearElementValue (pv->constantAttenuation);
        }
        else {
                pv->constantAttenuation = AddElement (
                        pv->point, ELEMENT_CONSTANT_ATTENUATION);
                SetSID (pv->constantAttenuation, PARAM_CONSTANT_ATTENUATION);
        }

        SetElementValue (pv->constantAttenuation, attenuation);
}

        void
PointLightElement::SetLinearAttenuation (double attenuation)
{
        if (pv->linearAttenuation) {
                ClearElementValue (pv->linearAttenuation);
        }
        else {
                pv->linearAttenuation = AddElement (
                        pv->point, ELEMENT_LINEAR_ATTENUATION);
                SetSID (pv->linearAttenuation, PARAM_LINEAR_ATTENUATION);
        }

        SetElementValue (pv->linearAttenuation, attenuation);
}

        void
PointLightElement::SetQuadraticAttenuation (double attenuation)
{
        if (pv->quadraticAttenuation) {
                ClearElementValue (pv->quadraticAttenuation);
        }
        else {
                pv->quadraticAttenuation = AddElement (
                        pv->point, ELEMENT_QUADRATIC_ATTENUATION);
                SetSID (pv->quadraticAttenuation, PARAM_QUADRATIC_ATTENUATION);
        }

        SetElementValue (pv->quadraticAttenuation, attenuation);
}

        void
PointLightElement::SetZFar (double zFar)
{
        if (pv->zFar) {
                ClearElementValue (pv->zFar);
        }
        else {
                pv->zFar = AddElement (
                        pv->point, ELEMENT_ZFAR);
                SetSID (pv->zFar, PARAM_ZFAR);
        }

        SetElementValue (pv->zFar, zFar);
}

        void
PointLightElement::LinkColor ()
{
        pv->color = LightElementPV ()->colorElem;
}

/*
 * ---------------------------------------------------------------------------
 * Spot Light.
 */

struct pv_SpotlightElement
{
        pv_SpotlightElement ()
                :
                techniqueCommon(NULL),
                spot(NULL),
                color(NULL),
                constantAttenuation(NULL),
                linearAttenuation(NULL),
                quadraticAttenuation(NULL),
                falloffAngle(NULL),
                falloffExponent(NULL)
        {
        }

        virtual ~pv_SpotlightElement ()
        {
        }

        ElementXML	*techniqueCommon;
        ElementXML	*spot;
        ElementXML	*color;
        ElementXML	*constantAttenuation;
        ElementXML	*linearAttenuation;
        ElementXML	*quadraticAttenuation;
        ElementXML	*falloffAngle;
        ElementXML	*falloffExponent;
};

SpotlightElement::SpotlightElement (
        LightLibraryElement	&library,
        const std::string	&id,
        const std::string	&name)
        :
        LightElement (library, id, name),
        pv(new pv_SpotlightElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
                pv->spot = AddElement (pv->techniqueCommon, ELEMENT_SPOT);
        }
}

SpotlightElement::SpotlightElement (
        LightLibraryElement	&library)
        :
        LightElement (library),
        pv(new pv_SpotlightElement())
{
}

SpotlightElement::~SpotlightElement ()
{
        delete pv;
}

        bool
SpotlightElement::GetColor (ColorRGB &color)
{
        return LightElement::pv->GetLightColor (pv->color, color);
}

        void
SpotlightElement::SetColor (const ColorRGB &color)
{
        if (pv->color) {
                ClearElementValue (pv->color);
        }
        else {
                pv->color = AddElement (pv->spot, ELEMENT_COLOR);
                SetSID (pv->color, PARAM_SPOT_LIGHT_COLOR);
        }

        SetElementValue (pv->color, color);
}

        void
SpotlightElement::SetConstantAttenuation (double attenuation)
{
        if (pv->constantAttenuation) {
                ClearElementValue (pv->constantAttenuation);
        }
        else {
                pv->constantAttenuation = AddElement (
                        pv->spot, ELEMENT_CONSTANT_ATTENUATION);
                SetSID (pv->constantAttenuation, PARAM_CONSTANT_ATTENUATION);
        }

        SetElementValue (pv->constantAttenuation, attenuation);
}

        void
SpotlightElement::SetLinearAttenuation (double attenuation)
{
        if (pv->linearAttenuation) {
                ClearElementValue (pv->linearAttenuation);
        }
        else {
                pv->linearAttenuation = AddElement (
                        pv->spot, ELEMENT_LINEAR_ATTENUATION);
                SetSID (pv->linearAttenuation, PARAM_LINEAR_ATTENUATION);
        }

        SetElementValue (pv->linearAttenuation, attenuation);
}

        void
SpotlightElement::SetQuadraticAttenuation (double attenuation)
{
        if (pv->quadraticAttenuation) {
                ClearElementValue (pv->quadraticAttenuation);
        }
        else {
                pv->quadraticAttenuation = AddElement (
                        pv->spot, ELEMENT_QUADRATIC_ATTENUATION);
                SetSID (pv->quadraticAttenuation, PARAM_QUADRATIC_ATTENUATION);
        }

        SetElementValue (pv->quadraticAttenuation, attenuation);
}

        void
SpotlightElement::SetFalloffAngle (double angle)
{
        if (pv->falloffAngle) {
                ClearElementValue (pv->falloffAngle);
        }
        else {
                pv->falloffAngle = AddElement (
                        pv->spot, ELEMENT_FALLOFF_ANGLE);
                SetSID (pv->falloffAngle, PARAM_FALLOFF_ANGLE);
        }

        SetElementValue (pv->falloffAngle, angle);
}

        void
SpotlightElement::SetFalloffExponent (double exponent)
{
        if (pv->falloffExponent) {
                ClearElementValue (pv->falloffExponent);
        }
        else {
                pv->falloffExponent = AddElement (
                        pv->spot, ELEMENT_FALLOFF_EXPONENT);
                SetSID (pv->falloffExponent, PARAM_FALLOFF_EXPONENT);
        }

        SetElementValue (pv->falloffExponent, exponent);
}

        void
SpotlightElement::LinkColor ()
{
        pv->color = LightElementPV ()->colorElem;
}

/*
 * ---------------------------------------------------------------------------
 * Directional Light.
 */

struct pv_DirectionalLightElement
{
        pv_DirectionalLightElement ()
                :
                techniqueCommon(NULL),
                directional(NULL),
                color(NULL)
        {
        }

        virtual ~pv_DirectionalLightElement ()
        {
        }

        ElementXML	*techniqueCommon;
        ElementXML	*directional;
        ElementXML	*color;
};

DirectionalLightElement::DirectionalLightElement (
        LightLibraryElement	&library,
        const std::string	&id,
        const std::string	&name)
        :
        LightElement (library, id, name),
        pv(new pv_DirectionalLightElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
                pv->directional = AddElement (pv->techniqueCommon, ELEMENT_DIRECTIONAL);
        }
}

DirectionalLightElement::DirectionalLightElement (
        LightLibraryElement	&library)
        :
        LightElement (library),
        pv(new pv_DirectionalLightElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
        }
}

DirectionalLightElement::~DirectionalLightElement ()
{
        delete pv;
}

        bool
DirectionalLightElement::GetColor (ColorRGB &color)
{
        return LightElement::pv->GetLightColor (pv->color, color);
}

        void
DirectionalLightElement::SetColor (const ColorRGB &color)
{
        if (pv->color) {
                ClearElementValue (pv->color);
        }
        else {
                pv->color = AddElement (pv->directional, ELEMENT_COLOR);
                SetSID (pv->color, PARAM_DIRECTIONAL_LIGHT_COLOR);
        }

        SetElementValue (pv->color, color);
}

        void
DirectionalLightElement::LinkColor ()
{
        pv->color = LightElementPV ()->colorElem;
}

/*
 * ---------------------------------------------------------------------------
 * Light Technique Profile modo 401.
 */

struct pv_LightElement_modo401 : public BoundElementParamValue
{
        pv_LightElement_modo401 ()
                :
                paramLightType(NULL),

                paramRender(NULL),
                paramDisplayVisible(NULL),
                paramDisplaySize(NULL),
                paramDissolve(NULL),

                paramRadiance(NULL),
                paramSamples(NULL),
                paramShadowType(NULL),
                paramShadowResolution(NULL),
                paramSimpleShading(NULL)
        {
        }

        ElementXML		*paramLightType;

        ElementXML		*paramRender;
        ElementXML		*paramDisplayVisible;
        ElementXML		*paramDisplaySize;
        ElementXML		*paramDissolve;

        ElementXML		*paramRadiance;
        ElementXML		*paramSamples;
        ElementXML		*paramShadowType;
        ElementXML		*paramShadowResolution;
        ElementXML		*paramSimpleShading;
};

LightElement_modo401::LightElement_modo401 (
        LightElement &light)
        :
        Element(light.PV ()),
        pv(new pv_LightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                light.AddTechniqueProfile_modo401 (*this);
        }
}

LightElement_modo401::~LightElement_modo401 ()
{
        delete pv;
}

/*
 * See PARAMVALUE_MODO_LIGHT_TYPE_
 */
        bool
LightElement_modo401::GetLightType (string &lightType)
{
        return GetParamValue (GetElement (), &pv->paramLightType,
                PARAM_MODO_LIGHT_TYPE, lightType);
}

/*
 * Common channelized locator parameters that can be
 * targeted for animation.
 */
 
        bool
LightElement_modo401::GetRender (string &render)
{
        return GetParamValue (GetElement (), &pv->paramRender,
                PARAM_MODO_LOCATOR_RENDER, render);
}

        void
LightElement_modo401::SetRender (const string &render)
{
        pv->SetValue (&pv->paramRender,
                PARAM_MODO_LOCATOR_RENDER, render);
}

        bool
LightElement_modo401::GetDisplayVisible (string &render)
{
        return GetParamValue (GetElement (), &pv->paramDisplayVisible,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE, render);
}

        void
LightElement_modo401::SetDisplayVisible (const string &render)
{
        pv->SetValue (&pv->paramDisplayVisible,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE, render);
}

        bool
LightElement_modo401::GetDisplaySize (double &size)
{
        return GetParamValue (GetElement (), &pv->paramDisplaySize,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE, size);
}

        void
LightElement_modo401::SetDisplaySize (double size)
{
        pv->SetValue (&pv->paramDisplaySize,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE, size);
}

        bool
LightElement_modo401::GetDissolve (double &dissolve)
{
        return GetParamValue (GetElement (), &pv->paramDissolve,
                PARAM_MODO_LOCATOR_DISSOLVE, dissolve);
}

 	void
LightElement_modo401::SetDissolve (double dissolve)
{
        pv->SetValue (&pv->paramDissolve,
                PARAM_MODO_LOCATOR_DISSOLVE, dissolve);
}

/*
 * Common light settings, used for all light sub-types.
 */

        bool
LightElement_modo401::GetRadiance (double &radiance)
{
        return GetParamValue (GetElement (), &pv->paramRadiance,
                PARAM_MODO_LIGHT_RADIANCE, radiance);
}

        void
LightElement_modo401::SetRadiance (double radiance)
{
        pv->SetValue (&pv->paramRadiance,
                PARAM_MODO_LIGHT_RADIANCE, radiance);
}

        bool
LightElement_modo401::GetSamples (unsigned &samples)
{
        return GetParamValue (GetElement (), &pv->paramSamples,
                PARAM_MODO_LIGHT_SAMPLES, samples);
}

        void
LightElement_modo401::SetSamples (unsigned samples)
{
        pv->SetValue (&pv->paramSamples,
                PARAM_MODO_LIGHT_SAMPLES, samples);
}

        bool
LightElement_modo401::GetShadowType (std::string &shadowType)
{
        return GetParamValue (GetElement (), &pv->paramShadowType,
                PARAM_MODO_LIGHT_SHADOW_TYPE, shadowType);
}

        void
LightElement_modo401::SetShadowType (std::string shadowType)
{
        pv->SetValue (&pv->paramShadowType,
                PARAM_MODO_LIGHT_SHADOW_TYPE, shadowType);
}

        bool
LightElement_modo401::GetShadowResolution (unsigned &resolution)
{
        return GetParamValue (GetElement (), &pv->paramShadowResolution,
                PARAM_MODO_LIGHT_SHADOW_RESOLUTION, resolution);
}

        void
LightElement_modo401::SetShadowResolution (unsigned resolution)
{
        pv->SetValue (&pv->paramShadowResolution,
                PARAM_MODO_LIGHT_SHADOW_RESOLUTION, resolution);
}

        bool
LightElement_modo401::GetSimpleShading (bool &simple)
{
        return GetParamValue (GetElement (), &pv->paramSimpleShading,
                PARAM_MODO_LIGHT_SIMPLE_SHADING, simple);
}

        void
LightElement_modo401::SetSimpleShading (bool simple)
{
        pv->SetValue (&pv->paramSimpleShading,
                PARAM_MODO_LIGHT_SIMPLE_SHADING, simple);
}

/*
 * ---------------------------------------------------------------------------
 * Area Light Technique Profile modo 401.
 */

struct pv_AreaLightElement_modo401 : public BoundElementParamValue
{
        pv_AreaLightElement_modo401 ()
                :
                paramTargetEnable(NULL),
                paramTargetNodeID(NULL),
                paramTargetRoll(NULL),

                paramWidth(NULL),
                paramHeight(NULL),
                paramShape(NULL)
        {
        }

        ElementXML		*paramTargetEnable;
        ElementXML		*paramTargetNodeID;
        ElementXML		*paramTargetRoll;

        ElementXML		*paramWidth;
        ElementXML		*paramHeight;

        ElementXML		*paramShape;
};

AreaLightElement_modo401::AreaLightElement_modo401 (
        PointLightElement &light)
        :
        LightElement_modo401(light),
        pv(new pv_AreaLightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                LightElement_modo401::pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_AREA_LIGHT);
                pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_AREA_LIGHT);
                SetBoundParamValue (
                        &LightElement_modo401::pv->paramLightType,
                        VIRTUAL_ELEMENT_AREA_LIGHT,
                        PARAM_MODO_LIGHT_TYPE,
                        string(PARAMVALUE_MODO_LIGHT_TYPE_AREA_LIGHT));
        }
}

AreaLightElement_modo401::~AreaLightElement_modo401 ()
{
        delete pv;
}

        bool
AreaLightElement_modo401::GetTargetEnable (bool &enabled)
{
        return GetParamValue (GetElement (), &pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

        void
AreaLightElement_modo401::SetTargetEnable (bool enabled)
{
        pv->SetValue (&pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

/*
 * URI fragment ID to linked node.
 */
        bool
AreaLightElement_modo401::GetTargetNodeID (string &nodeID)
{
        return GetParamValue (GetElement (), &pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        void
AreaLightElement_modo401::SetTargetNodeID (const string &nodeID)
{
        pv->SetValue (&pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        bool
AreaLightElement_modo401::GetTargetRoll (double &degrees)
{
        return GetParamValue (GetElement (), &pv->paramTargetRoll,
                PARAM_MODO_TARGET_ROLL, degrees);
}

        void
AreaLightElement_modo401::SetTargetRoll (double degrees)
{
        pv->SetValue (&pv->paramTargetRoll, PARAM_MODO_TARGET_ROLL, degrees);
}

        void
AreaLightElement_modo401::SetWidth (double width)
{
        SetBoundParamValue (
                &pv->paramWidth,
                VIRTUAL_ELEMENT_AREA_LIGHT,
                PARAM_MODO_AREALIGHT_WIDTH, width);
}

        void
AreaLightElement_modo401::SetHeight (double height)
{
        SetBoundParamValue (
                &pv->paramHeight,
                VIRTUAL_ELEMENT_AREA_LIGHT,
                PARAM_MODO_AREALIGHT_HEIGHT, height);
}

 	void
AreaLightElement_modo401::SetShape (const string &shape)
{
        SetBoundParamValue (
                &pv->paramShape,
                VIRTUAL_ELEMENT_AREA_LIGHT,
                PARAM_MODO_AREALIGHT_SHAPE, shape);
}

/*
 * ---------------------------------------------------------------------------
 * Cylinder Light Technique Profile modo 401.
 */

struct pv_CylinderLightElement_modo401 : public BoundElementParamValue
{
        pv_CylinderLightElement_modo401 ()
                :
                paramTargetEnable(NULL),
                paramTargetNodeID(NULL),
                paramTargetRoll(NULL),

                paramLength(NULL),
                paramRadius(NULL)
        {
        }

        ElementXML		*paramTargetEnable;
        ElementXML		*paramTargetNodeID;
        ElementXML		*paramTargetRoll;

        ElementXML		*paramLength;
        ElementXML		*paramRadius;
};

CylinderLightElement_modo401::CylinderLightElement_modo401 (
        PointLightElement &light)
        :
        LightElement_modo401(light),
        pv(new pv_CylinderLightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                LightElement_modo401::pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_CYLINDER_LIGHT);
                pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_CYLINDER_LIGHT);
                SetBoundParamValue (&LightElement_modo401::pv->paramLightType,
                        VIRTUAL_ELEMENT_CYLINDER_LIGHT,
                        PARAM_MODO_LIGHT_TYPE,
                        string(PARAMVALUE_MODO_LIGHT_TYPE_CYLINDER_LIGHT));
        }
}

CylinderLightElement_modo401::~CylinderLightElement_modo401 ()
{
        delete pv;
}

        bool
CylinderLightElement_modo401::GetTargetEnable (bool &enabled)
{
        return GetParamValue (GetElement (), &pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

        void
CylinderLightElement_modo401::SetTargetEnable (bool enabled)
{
        pv->SetValue (&pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

/*
 * URI fragment ID to linked node.
 */
        bool
CylinderLightElement_modo401::GetTargetNodeID (string &nodeID)
{
        return GetParamValue (GetElement (), &pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        void
CylinderLightElement_modo401::SetTargetNodeID (const string &nodeID)
{
        pv->SetValue (&pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        bool
CylinderLightElement_modo401::GetTargetRoll (double &degrees)
{
        return GetParamValue (GetElement (), &pv->paramTargetRoll,
                PARAM_MODO_TARGET_ROLL, degrees);
}

        void
CylinderLightElement_modo401::SetTargetRoll (double degrees)
{
        pv->SetValue (&pv->paramTargetRoll, PARAM_MODO_TARGET_ROLL, degrees);
}

        void
CylinderLightElement_modo401::SetLength (double length)
{
        SetBoundParamValue (
                &pv->paramLength,
                VIRTUAL_ELEMENT_CYLINDER_LIGHT,
                PARAM_MODO_CYLINDERLIGHT_LENGTH, length);
}
        void
CylinderLightElement_modo401::SetRadius (double radius)
{
        SetBoundParamValue (
                &pv->paramRadius,
                VIRTUAL_ELEMENT_CYLINDER_LIGHT,
                PARAM_MODO_CYLINDERLIGHT_RADIUS, radius);
}

/*
 * ---------------------------------------------------------------------------
 * Dome Light Technique Profile modo 401.
 */

struct pv_DomeLightElement_modo401 : public BoundElementParamValue
{
        pv_DomeLightElement_modo401 ()
                :
                paramRadius(NULL)
        {
        }

        ElementXML		*paramRadius;
};

DomeLightElement_modo401::DomeLightElement_modo401 (
        PointLightElement &light)
        :
        LightElement_modo401(light),
        pv(new pv_DomeLightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                LightElement_modo401::pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_DOME_LIGHT);
                pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_DOME_LIGHT);
                SetBoundParamValue (&LightElement_modo401::pv->paramLightType,
                        VIRTUAL_ELEMENT_DOME_LIGHT,
                        PARAM_MODO_LIGHT_TYPE,
                        string(PARAMVALUE_MODO_LIGHT_TYPE_DOME_LIGHT));
        }
}

DomeLightElement_modo401::~DomeLightElement_modo401 ()
{
}

        void
DomeLightElement_modo401::SetRadius (double radius)
{
        SetBoundParamValue (
                &pv->paramRadius,
                VIRTUAL_ELEMENT_DOME_LIGHT,
                PARAM_MODO_DOMELIGHT_RADIUS, radius);
}

/*
 * ---------------------------------------------------------------------------
 * Photometric Light Technique Profile modo 401.
 */

struct pv_PhotometricLightElement_modo401 : public BoundElementParamValue
{
        pv_PhotometricLightElement_modo401 ()
                :
                paramTargetEnable(NULL),
                paramTargetNodeID(NULL),
                paramTargetRoll(NULL),

                paramConeAngle(NULL),
                paramSoftEdgeAngle(NULL),
                paramWidth(NULL),
                paramHeight(NULL),
                paramOutside(NULL),
                paramVolumetrics(NULL),
                paramVolumetricDissolve(NULL),
                paramVolumetricSamples(NULL),
                paramVolumetricRadius(NULL)
        {
        }

        ElementXML		*paramTargetEnable;
        ElementXML		*paramTargetNodeID;
        ElementXML		*paramTargetRoll;

        ElementXML		*paramConeAngle;
        ElementXML		*paramSoftEdgeAngle;
        ElementXML		*paramWidth;
        ElementXML		*paramHeight;
        ElementXML		*paramOutside;
        ElementXML		*paramVolumetrics;
        ElementXML		*paramVolumetricDissolve;
        ElementXML		*paramVolumetricSamples;
        ElementXML		*paramVolumetricRadius;
};

PhotometricLightElement_modo401::PhotometricLightElement_modo401 (
        SpotlightElement &light)
        :
        LightElement_modo401(light),
        pv(new pv_PhotometricLightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                LightElement_modo401::pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT);
                pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT);
                SetBoundParamValue (&LightElement_modo401::pv->paramLightType,
                        VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                        PARAM_MODO_LIGHT_TYPE,
                        string(PARAMVALUE_MODO_LIGHT_TYPE_PHOTO_LIGHT));
        }
}

PhotometricLightElement_modo401::~PhotometricLightElement_modo401 ()
{
        delete pv;
}

        bool
PhotometricLightElement_modo401::GetTargetEnable (bool &enabled)
{
        return GetParamValue (GetElement (), &pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

        void
PhotometricLightElement_modo401::SetTargetEnable (bool enabled)
{
        pv->SetValue (&pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

/*
 * URI fragment ID to linked node.
 */
        bool
PhotometricLightElement_modo401::GetTargetNodeID (string &nodeID)
{
        return GetParamValue (GetElement (), &pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        void
PhotometricLightElement_modo401::SetTargetNodeID (const string &nodeID)
{
        pv->SetValue (&pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        bool
PhotometricLightElement_modo401::GetTargetRoll (double &degrees)
{
        return GetParamValue (GetElement (), &pv->paramTargetRoll,
                PARAM_MODO_TARGET_ROLL, degrees);
}

        void
PhotometricLightElement_modo401::SetTargetRoll (double degrees)
{
        pv->SetValue (&pv->paramTargetRoll, PARAM_MODO_TARGET_ROLL, degrees);
}

        void
PhotometricLightElement_modo401::SetConeAngle (double angle)
{
        SetBoundParamValue (&pv->paramConeAngle,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_CONE_ANGLE, angle);
}

        void
PhotometricLightElement_modo401::SetSoftEdgeAngle (double angle)
{
        SetBoundParamValue (&pv->paramSoftEdgeAngle,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_SOFT_EDGE_ANGLE,
                angle);
}

        void
PhotometricLightElement_modo401::SetWidth (double width)
{
        SetBoundParamValue (&pv->paramWidth,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_WIDTH, width);
}

        void
PhotometricLightElement_modo401::SetHeight (double height)
{
        SetBoundParamValue (&pv->paramHeight,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_HEIGHT, height);
}

        void
PhotometricLightElement_modo401::SetOutside (bool outside)
{
        SetBoundParamValue (&pv->paramOutside,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_OUTSIDE, outside);
}

        void
PhotometricLightElement_modo401::SetVolumetrics (bool volumetrics)
{
        SetBoundParamValue (&pv->paramVolumetrics,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_VOLUMETRICS, volumetrics);
}

        void
PhotometricLightElement_modo401::SetVolumetricDissolve (double dissolve)
{
        SetBoundParamValue (&pv->paramVolumetricDissolve,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_V_DISSOLVE, dissolve);
}

        void
PhotometricLightElement_modo401::SetVolumetricSamples (unsigned samples)
{
        SetBoundParamValue (&pv->paramVolumetricSamples,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_V_SAMPLES, samples);
}

        void
PhotometricLightElement_modo401::SetVolumetricRadius (double radius)
{
        SetBoundParamValue (&pv->paramVolumetricRadius,
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_V_RAD, radius);
}

/*
 * ---------------------------------------------------------------------------
 * Point Light Technique Profile modo 401.
 */

struct pv_PointLightElement_modo401 : public BoundElementParamValue
{
        pv_PointLightElement_modo401 ()
                :
                paramRadius(NULL),
                paramVolumetrics(NULL),
                paramVolumetricDissolve(NULL),
                paramVolumetricSamples(NULL),
                paramVolumetricRadius(NULL)
        {
        }

        ElementXML		*paramRadius;
        ElementXML		*paramVolumetrics;
        ElementXML		*paramVolumetricDissolve;
        ElementXML		*paramVolumetricSamples;
        ElementXML		*paramVolumetricRadius;
};

PointLightElement_modo401::PointLightElement_modo401 (
        PointLightElement &light)
        :
        LightElement_modo401(light),
        pv(new pv_PointLightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                LightElement_modo401::pv->SetBoundElement (
                        this, ELEMENT_POINT);
                pv->SetBoundElement (
                        this, ELEMENT_POINT);
                SetBoundParamValue (&LightElement_modo401::pv->paramLightType,
                        ELEMENT_POINT,
                        PARAM_MODO_LIGHT_TYPE,
                        string(PARAMVALUE_MODO_LIGHT_TYPE_POINT_LIGHT));
        }
}

PointLightElement_modo401::~PointLightElement_modo401 ()
{
        delete pv;
}

        void
PointLightElement_modo401::SetRadius (double radius)
{
        SetBoundParamValue (&pv->paramRadius,
                ELEMENT_POINT, PARAM_MODO_POINTLIGHT_RADIUS, radius);
}

        void
PointLightElement_modo401::SetVolumetrics (bool volumetrics)
{
        SetBoundParamValue (&pv->paramVolumetrics,
                ELEMENT_POINT, PARAM_MODO_POINTLIGHT_VOLUMETRICS, volumetrics);
}

        void
PointLightElement_modo401::SetVolumetricDissolve (double dissolve)
{
        SetBoundParamValue (&pv->paramVolumetricDissolve,
                ELEMENT_POINT, PARAM_MODO_POINTLIGHT_V_DISSOLVE, dissolve);
}

        void
PointLightElement_modo401::SetVolumetricSamples (unsigned samples)
{
        SetBoundParamValue (&pv->paramVolumetricSamples,
                ELEMENT_POINT, PARAM_MODO_POINTLIGHT_V_SAMPLES, samples);
}

        void
PointLightElement_modo401::SetVolumetricRadius (double radius)
{
        SetBoundParamValue (&pv->paramVolumetricRadius,
                ELEMENT_POINT, PARAM_MODO_POINTLIGHT_V_RAD, radius);
}

/*
 * ---------------------------------------------------------------------------
 * Spot Light Technique Profile modo 401.
 */

struct pv_SpotlightElement_modo401 : public BoundElementParamValue
{
        pv_SpotlightElement_modo401 ()
                :
                paramTargetEnable(NULL),
                paramTargetNodeID(NULL),
                paramTargetRoll(NULL),

                paramConeAngle(NULL),
                paramSoftEdgeAngle(NULL),
                paramOutside(NULL),
                paramRadius(NULL),
                paramVolumetrics(NULL),
                paramVolumetricDissolve(NULL),
                paramVolumetricSamples(NULL)
        {
        }

        ElementXML		*paramTargetEnable;
        ElementXML		*paramTargetNodeID;
        ElementXML		*paramTargetRoll;

        ElementXML		*paramConeAngle;
        ElementXML		*paramSoftEdgeAngle;
        ElementXML		*paramOutside;
        ElementXML		*paramRadius;
        ElementXML		*paramVolumetrics;
        ElementXML		*paramVolumetricDissolve;
        ElementXML		*paramVolumetricSamples;
};

SpotlightElement_modo401::SpotlightElement_modo401 (
        SpotlightElement &light)
        :
        LightElement_modo401(light),
        pv(new pv_SpotlightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                LightElement_modo401::pv->SetBoundElement (
                        this, ELEMENT_SPOT);
                pv->SetBoundElement (
                        this, ELEMENT_SPOT);
                SetBoundParamValue (&LightElement_modo401::pv->paramLightType,
                        ELEMENT_SPOT,
                        PARAM_MODO_LIGHT_TYPE,
                        string(PARAMVALUE_MODO_LIGHT_TYPE_SPOT_LIGHT));
        }
}

SpotlightElement_modo401::~SpotlightElement_modo401 ()
{
        delete pv;
}

        bool
SpotlightElement_modo401::GetTargetEnable (bool &enabled)
{
        return GetParamValue (GetElement (), &pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

        void
SpotlightElement_modo401::SetTargetEnable (bool enabled)
{
        pv->SetValue (&pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

/*
 * URI fragment ID to linked node.
 */
        bool
SpotlightElement_modo401::GetTargetNodeID (string &nodeID)
{
        return GetParamValue (GetElement (), &pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        void
SpotlightElement_modo401::SetTargetNodeID (const string &nodeID)
{
        pv->SetValue (&pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        bool
SpotlightElement_modo401::GetTargetRoll (double &degrees)
{
        return GetParamValue (GetElement (), &pv->paramTargetRoll,
                PARAM_MODO_TARGET_ROLL, degrees);
}

        void
SpotlightElement_modo401::SetTargetRoll (double degrees)
{
        pv->SetValue (&pv->paramTargetRoll, PARAM_MODO_TARGET_ROLL, degrees);
}

        void
SpotlightElement_modo401::SetConeAngle (double angle)
{
        SetBoundParamValue (
                &pv->paramConeAngle,
                ELEMENT_SPOT,
                PARAM_MODO_SPOTLIGHT_CONE_ANGLE, angle);
}

        void
SpotlightElement_modo401::SetSoftEdgeAngle (double angle)
{
        SetBoundParamValue (
                &pv->paramSoftEdgeAngle,
                ELEMENT_SPOT,
                PARAM_MODO_SPOTLIGHT_SOFT_EDGE_ANGLE, angle);
}

        void
SpotlightElement_modo401::SetOutside (bool outside)
{
        SetBoundParamValue (
                &pv->paramOutside,
                ELEMENT_SPOT,
                PARAM_MODO_SPOTLIGHT_OUTSIDE, outside);
}

        void
SpotlightElement_modo401::SetRadius (double radius)
{
        SetBoundParamValue (
                &pv->paramRadius,
                ELEMENT_SPOT,
                PARAM_MODO_SPOTLIGHT_RADIUS, radius);
}

        void
SpotlightElement_modo401::SetVolumetrics (bool volumetrics)
{
        SetBoundParamValue (
                &pv->paramVolumetrics,
                ELEMENT_SPOT,
                PARAM_MODO_SPOTLIGHT_VOLUMETRICS, volumetrics);
}

        void
SpotlightElement_modo401::SetVolumetricDissolve (double dissolve)
{
        SetBoundParamValue (
                &pv->paramVolumetricDissolve,
                ELEMENT_SPOT,
                PARAM_MODO_SPOTLIGHT_V_DISSOLVE, dissolve);
}

        void
SpotlightElement_modo401::SetVolumetricSamples (unsigned samples)
{
        SetBoundParamValue (
                &pv->paramVolumetricSamples,
                ELEMENT_SPOT,
                PARAM_MODO_SPOTLIGHT_V_SAMPLES, samples);
}

/*
 * ---------------------------------------------------------------------------
 * Sun Light Technique Profile modo 401.
 */

struct pv_SunlightElement_modo401 : public BoundElementParamValue
{
        pv_SunlightElement_modo401 ()
                :
                paramTargetEnable(NULL),
                paramTargetNodeID(NULL),
                paramTargetRoll(NULL),

                paramAzimuth(NULL),
                paramClampIntensity(NULL),
                paramDay(NULL),
                paramElevation(NULL),
                paramHaze(NULL),
                paramHeight(NULL),
                paramLatitude(NULL),
                paramLongitude(NULL),
                paramMapSize(NULL),
                paramNorth(NULL),
                paramRadius(NULL),
                paramSpread(NULL),
                paramSunPosition(NULL),
                paramTime(NULL),
                paramTimeZone(NULL),
                paramVolumetrics(NULL),
                paramVolumetricDissolve(NULL),
                paramVolumetricSamples(NULL)
        {
        }

        ElementXML		*paramTargetEnable;
        ElementXML		*paramTargetNodeID;
        ElementXML		*paramTargetRoll;

        ElementXML		*paramAzimuth;
        ElementXML		*paramClampIntensity;
        ElementXML		*paramDay;
        ElementXML		*paramElevation;
        ElementXML		*paramHaze;
        ElementXML		*paramHeight;
        ElementXML		*paramLatitude;
        ElementXML		*paramLongitude;
        ElementXML		*paramMapSize;
        ElementXML		*paramNorth;
        ElementXML		*paramRadius;
        ElementXML		*paramSpread;
        ElementXML		*paramSunPosition;
        ElementXML		*paramTime;
        ElementXML		*paramTimeZone;
        ElementXML		*paramVolumetrics;
        ElementXML		*paramVolumetricDissolve;
        ElementXML		*paramVolumetricSamples;
};

SunlightElement_modo401::SunlightElement_modo401 (
        DirectionalLightElement &light)
        :
        LightElement_modo401(light),
        pv(new pv_SunlightElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                LightElement_modo401::pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_SUN_LIGHT);
                pv->SetBoundElement (
                        this, VIRTUAL_ELEMENT_SUN_LIGHT);
                SetBoundParamValue (&LightElement_modo401::pv->paramLightType,
                        VIRTUAL_ELEMENT_SUN_LIGHT,
                        PARAM_MODO_LIGHT_TYPE,
                        string(PARAMVALUE_MODO_LIGHT_TYPE_SUN_LIGHT));
        }
}

SunlightElement_modo401::~SunlightElement_modo401 ()
{
        delete pv;
}

        bool
SunlightElement_modo401::GetTargetEnable (bool &enabled)
{
        return GetParamValue (GetElement (), &pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

        void
SunlightElement_modo401::SetTargetEnable (bool enabled)
{
        pv->SetValue (&pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

/*
 * URI fragment ID to linked node.
 */
        bool
SunlightElement_modo401::GetTargetNodeID (string &nodeID)
{
        return GetParamValue (GetElement (), &pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        void
SunlightElement_modo401::SetTargetNodeID (const string &nodeID)
{
        pv->SetValue (&pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        bool
SunlightElement_modo401::GetTargetRoll (double &degrees)
{
        return GetParamValue (GetElement (), &pv->paramTargetRoll,
                PARAM_MODO_TARGET_ROLL, degrees);
}

        void
SunlightElement_modo401::SetTargetRoll (double degrees)
{
        pv->SetValue (&pv->paramTargetRoll, PARAM_MODO_TARGET_ROLL, degrees);
}

        void
SunlightElement_modo401::SetAzimuth (double angle)
{
        SetBoundParamValue (&pv->paramAzimuth,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_AZIMUTH, angle);
}

        void
SunlightElement_modo401::SetClampIntensity (bool clamp)
{
        SetBoundParamValue (&pv->paramClampIntensity,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_CLAMP_INTENSITY, clamp);
}

        void
SunlightElement_modo401::SetDay (unsigned day)
{
        SetBoundParamValue (&pv->paramDay,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_DAY, day);
}

        void
SunlightElement_modo401::SetElevation (double elevation)
{
        SetBoundParamValue (&pv->paramElevation,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_ELEVATION, elevation);
}

        void
SunlightElement_modo401::SetHaze (double haze)
{
        SetBoundParamValue (&pv->paramHaze,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_HAZE, haze);
}

        void
SunlightElement_modo401::SetHeight (double height)
{
        SetBoundParamValue (&pv->paramHeight,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_HEIGHT, height);
}

        void
SunlightElement_modo401::SetLatitude (double latitude)
{
        SetBoundParamValue (&pv->paramLatitude,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_LATITUDE, latitude);
}

        void
SunlightElement_modo401::SetLongitude (double longitude)
{
        SetBoundParamValue (&pv->paramLongitude,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_LONGITUDE, longitude);
}

        void
SunlightElement_modo401::SetMapSize (double mapSize)
{
        SetBoundParamValue (&pv->paramMapSize,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_MAP_SIZE, mapSize);
}

        void
SunlightElement_modo401::SetNorth (double north)
{
        SetBoundParamValue (&pv->paramNorth,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_NORTH, north);
}

        void
SunlightElement_modo401::SetRadius (double radius)
{
        SetBoundParamValue (&pv->paramRadius,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_RADIUS, radius);
}

        void
SunlightElement_modo401::SetSpread (double spread)
{
        SetBoundParamValue (&pv->paramSpread,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_SPREAD, spread);
}

        void
SunlightElement_modo401::SetSunPosition (bool position)
{
        SetBoundParamValue (&pv->paramSunPosition,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_POSITION, position);
}

        void
SunlightElement_modo401::SetTime (double time)
{
        SetBoundParamValue (&pv->paramTime,
                VIRTUAL_ELEMENT_SUN_LIGHT,
                PARAM_MODO_SUNLIGHT_TIME, time);
}

        void
SunlightElement_modo401::SetTimeZone (double zone)
{
        SetBoundParamValue (&pv->paramTimeZone,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_TIME_ZONE, zone);
}

        void
SunlightElement_modo401::SetVolumetrics (bool volumetrics)
{
        SetBoundParamValue (&pv->paramVolumetrics,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_VOLUMETRICS, volumetrics);
}

        void
SunlightElement_modo401::SetVolumetricDissolve (double dissolve)
{
        SetBoundParamValue (&pv->paramVolumetricDissolve,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_V_DISSOLVE, dissolve);
}

        void
SunlightElement_modo401::SetVolumetricSamples (unsigned samples)
{
        SetBoundParamValue (&pv->paramVolumetricSamples,
                VIRTUAL_ELEMENT_SUN_LIGHT, PARAM_MODO_SUNLIGHT_V_SAMPLES, samples);
}

/*
 * ---------------------------------------------------------------------------
 * Light Library.
 */

LightLibraryElement::LightLibraryElement (COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddLightLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkLightLibrary (*this);
        }
}

LightLibraryElement::~LightLibraryElement ()
{
}

        bool
LightLibraryElement::HasLight () const
{
        return HasChildElement (ELEMENT_LIGHT);
}

        bool
LightLibraryElement::LinkLight (
        const string		&lightID,
        LightElement		&light)
{
        return LinkFirstChildElement (ELEMENT_LIGHT, lightID, light);
}

        void
LightLibraryElement::AddLight (LightElement &light)
{
        light.SetElement (AddElement (ELEMENT_LIGHT));
}

} // namespace cio

