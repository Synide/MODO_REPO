/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_SHADERNODE_H
#define CIO_SHADERNODE_H

#include "cio_element.h"

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Technique and Extra.
 */

class ExtraElement;

class ShaderElement_modo401 : public Element
{
    public:
                                 ShaderElement_modo401 (
                                        ExtraElement *extra);
        virtual			~ShaderElement_modo401 ();
};

class ExtraElement : public Element
{
        friend class ShaderElement_modo401;

    public:
                                 ExtraElement (Element *element);
        virtual			~ExtraElement ();

        void			 AddTechnique (ShaderElement_modo401 *technique);
};

/*
 * ---------------------------------------------------------------------------
 * Shader Node.
 */

/*
 * Poly shader layers can be parented to Renders, Environments,
 * or Lights, with corresponding texture effect options.
 */
typedef enum en_ShaderLayerType
{
        /*
         * Advanced Materials can only be parented to Renders.
         */
        SHADER_LAYER_ADVANCED_MATERIAL,

        SHADER_LAYER_POLY_CELLULAR,
        SHADER_LAYER_POLY_CHECKER,
        SHADER_LAYER_POLY_CONSTANT,
        SHADER_LAYER_POLY_DOTS,

        /*
         * Environment Materials can only be parented to Environments.
         */
        SHADER_LAYER_ENVIRONMENT_MATERIAL,

        /*
         * Fur Materials can only be parented to Renders.
         */
        SHADER_LAYER_FUR_MATERIAL,

        SHADER_LAYER_POLY_GRADIENT,
        SHADER_LAYER_POLY_GRID,
        SHADER_LAYER_POLY_GROUP,
        SHADER_LAYER_POLY_IMAGE_MAP,

        /*
         * Light Materials can only be parented to Lights.
         */
        SHADER_LAYER_LIGHT_MATERIAL,

        SHADER_LAYER_POLY_NOISE,
        SHADER_LAYER_POLY_PROCESS,

        /*
         * Render Outputs can only be parented to Renders.
         */
        SHADER_LAYER_RENDER_OUTPUT,

        SHADER_LAYER_POLY_RIPPLES,

        /*
         * Shaders can only be parented to Renders.
         */
        SHADER_LAYER_SHADER,

        /*
         * Surface Generators can only be parented to Renders.
         */
        SHADER_LAYER_SURFACE_GENERATOR,

        SHADER_LAYER_POLY_WEAVE,

        /*
         * Weight Map Textures can only be parented to Renders.
         */
        SHADER_LAYER_WEIGHT_MAP_TEXTURE,

        SHADER_LAYER_POLY_WOOD
} ShaderLayerType;

class RenderElement_modo401;
class EnvironmentElement_modo401;
class LightShaderNodeElement_modo401;

class ShaderNodeElement_modo401 : public Element
{
    public:
                                 ShaderNodeElement_modo401 (
                                        RenderElement_modo401	&render,
                                        const std::string	&name,
                                        ShaderLayerType		 layerType);

                                 ShaderNodeElement_modo401 (
                                        EnvironmentElement_modo401	&environment,
                                        const std::string		&itemName,
                                        ShaderLayerType			 layerType);

                                 ShaderNodeElement_modo401 (
                                        LightShaderNodeElement_modo401	&light,
                                        const std::string		&itemName,
                                        ShaderLayerType			 layerType);

                                 ShaderNodeElement_modo401 (
                                        ShaderNodeElement_modo401	&node,
                                        const std::string		&itemName,
                                        ShaderLayerType			 layerType);

        virtual			~ShaderNodeElement_modo401 ();

        const std::string	 GetName () const;

        ShaderLayerType		 GetShaderLayerType () const;

        void			 SetEnabled (bool enabled);
        void			 SetInverted (bool inverted);

        /*
         * See PARAMVALUE_MODO_SHADER_LAYER_BLEND_
         */
        void			 SetBlendMode (const std::string &mode);
        void			 SetOpacity (double percent);

    protected:
        void			 AddExtra (ExtraElement *extra);

        void			 AddShaderNode (
                                        ShaderNodeElement_modo401 *node);

    private:
        struct pv_ShaderNodeElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Shader Node Advanced Material Technique Profile modo 401.
 */

typedef enum en_MaterialTextureEffect
{
        /*
         * The "all channels" option is only supported
         * for (advanced) material items.
         */
        MATERIAL_TEXTURE_EFFECT_ALL,

        /*
         * Drivers, group, and layer masks are
         * common to all texture effect types.
         */
        MATERIAL_TEXTURE_EFFECT_DRIVER_A_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_DRIVER_B_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_DRIVER_C_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_DRIVER_D_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_GROUP_MASK,
        MATERIAL_TEXTURE_EFFECT_LAYER_MASK,

        MATERIAL_TEXTURE_EFFECT_ANISOTROPIC_DIRECTION_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_BUMP_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_CLEARCOAT_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_DIFFUSE_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_DIFFUSE_COLOR,
        MATERIAL_TEXTURE_EFFECT_DISPLACEMENT_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_BEND_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_BUMP_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_CLUMPS_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_CLUMP_DENSITY_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_CURLS_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_DENSITY_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_DIRECTION_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_FLEX_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_GROWTH_JITTER_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_LENGTH_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_FUR_VECTOR_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_LUMINOUS_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_LUMINOUS_COLOR,
        MATERIAL_TEXTURE_EFFECT_NORMAL_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_REFLECTION_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_REFLECTION_COLOR,
        MATERIAL_TEXTURE_EFFECT_REFLECTION_FRESNEL_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_ROUGHNESS_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_SPECULAR_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_SPECULAR_COLOR,
        MATERIAL_TEXTURE_EFFECT_SPECULAR_FRESNEL_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_STENCIL_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_SUBSURFACE_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_SUBSURFACE_COLOR,
        MATERIAL_TEXTURE_EFFECT_SURFACE_PARTICLE_DENSITY_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_SURFACE_PARTICLE_NORMAL_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_SURFACE_PARTICLE_SIZE_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_TRANSPARENT_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_TRANSPARENT_COLOR,
        MATERIAL_TEXTURE_EFFECT_REFRACTION_ROUGHNESS_AMOUNT,
        MATERIAL_TEXTURE_EFFECT_VECTOR_DISPLACEMENT_AMOUNT
} MaterialTextureEffect;

typedef enum en_EffectReflectionType
{
        EFFECT_REFLECTION_FULLSCENE,
        EFFECT_REFLECTION_ENVIRONMENT_ONLY
} EffectReflectionType;

class AdvancedShaderNodeElement_modo401
        :
        public ShaderNodeElement_modo401
{
    public:
                                 AdvancedShaderNodeElement_modo401 (
                                        RenderElement_modo401	&render,
                                        const std::string	&itemName);
        virtual			~AdvancedShaderNodeElement_modo401 ();

        void			 SetMaterialTextureEffect (
                                        MaterialTextureEffect effect);

        /*
         * BRDF channels.
         */
        void			 SetDiffuseAmount (double percent);
        void			 SetDiffuseColor (const ColorRGB &color);
        void			 SetConserveEnergy (bool conserve);

        void			 SetSpecularAmount (double percent);
        void			 SetSpecularColor (const ColorRGB &color);

        void			 SetSpecularFresnel (double percent);
        void			 SetRoughness (double percent);
        void			 SetAnisotropy (double percent);
        void			 SetUVMap (const std::string &mapName);

        void			 SetReflectionAmount (double percent);
        void			 SetReflectionFresnel (double percent);
        void			 SetReflectionColor (const ColorRGB &color);

        void			 SetReflectionType (EffectReflectionType type);

        void			 SetBlurryReflection (bool blurry);
        void			 SetReflectionRays (unsigned count);
        void			 SetClearcoatAmount (double percent);

        /*
         * Surface Normal channels.
         */
        void			 SetBumpStrength (double percent);
        void			 SetDisplacementDistance (double distance);
        void			 SetSmoothing (double percent);
        void			 SetSmoothingAngle (double degrees);
        void			 SetDoubleSided (bool isDoubleSided);

        /*
         * Transparency channels.
         */
        void			 SetTransparentAmount (double percent);
        void			 SetTransparentColor (const ColorRGB &color);
        void			 SetAbsorptionDistance (double distance);
        void			 SetRefractiveIndex (double index);
        void			 SetDispersion (double amount);
        void			 SetRefractionRoughness (double percent);
        void			 SetRefractionRays (unsigned count);
        void			 SetDissolveAmount (double percent);

        /*
         * Subsurface Scattering channels.
         */
        void			 SetSubsurfaceAmount (double percent);
        void			 SetSubsurfaceColor (const ColorRGB &color);
        void			 SetScatteringDistance (double distance);
        void			 SetFrontWeighting (double percent);
        void			 SetSubsurfaceSamples (double count);

        /*
         * Luminosity channels.
         */
        void			 SetLuminousIntensity (double watts);
        void			 SetLuminousColor (const ColorRGB &color);

        /*
         * Ray Tracing channels.
         */
        void			 SetExitColor (const ColorRGB &color);

    private:
        struct pv_AdvancedShaderNodeElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Shader Shading Node.
 */

typedef enum en_ShaderShading
{
        SHADER_SHADING_FULL,
        SHADER_SHADING_DIFFUSE,
        SHADER_SHADING_SPECULAR,
        SHADER_SHADING_REFLECTION,
        SHADER_SHADING_TRANSPARENT,
        SHADER_SHADING_SUBSURFACE,
        SHADER_SHADING_LUMINOUS,
        SHADER_SHADING_FOG
} ShaderShading;

/*
 * ---------------------------------------------------------------------------
 * Environment Material Node.
 */

typedef enum en_EnvironmentTextureEffect
{
        /*
         * The "all channels" option is only supported
         * for environment material items.
         */
        ENVIRONMENT_TEXTURE_EFFECT_ALL,

        /*
         * Drivers, group, and layer masks are
         * common to all texture effect types.
         */
        ENVIRONMENT_TEXTURE_EFFECT_DRIVER_A_AMOUNT,
        ENVIRONMENT_TEXTURE_EFFECT_DRIVER_B_AMOUNT,
        ENVIRONMENT_TEXTURE_EFFECT_DRIVER_C_AMOUNT,
        ENVIRONMENT_TEXTURE_EFFECT_DRIVER_D_AMOUNT,
        ENVIRONMENT_TEXTURE_EFFECT_GROUP_MASK,
        ENVIRONMENT_TEXTURE_EFFECT_LAYER_MASK,

        ENVIRONMENT_TEXTURE_EFFECT_ENVIRONMENT_COLOR
} EnvironmentTextureEffect;

class EnvironmentShaderNodeElement_modo401
        :
        public ShaderNodeElement_modo401
{
    public:
                                 EnvironmentShaderNodeElement_modo401 (
                                         EnvironmentElement_modo401	&environment,
                                         const std::string		&itemName);
        virtual			~EnvironmentShaderNodeElement_modo401 ();

        void			 SetEnvironmentTextureEffect (
                                        EnvironmentTextureEffect effect);
};

/*
 * ---------------------------------------------------------------------------
 * Light Material Node.
 */

typedef enum en_LightTextureEffect
{
        /*
         * The "all channels" option is only supported
         * for light material items.
         */
        LIGHT_TEXTURE_EFFECT_ALL,

        /*
         * Drivers, group, and layer masks are
         * common to all texture effect types.
         */
        LIGHT_TEXTURE_EFFECT_DRIVER_A_AMOUNT,
        LIGHT_TEXTURE_EFFECT_DRIVER_B_AMOUNT,
        LIGHT_TEXTURE_EFFECT_DRIVER_C_AMOUNT,
        LIGHT_TEXTURE_EFFECT_DRIVER_D_AMOUNT,
        LIGHT_TEXTURE_EFFECT_GROUP_MASK,
        LIGHT_TEXTURE_EFFECT_LAYER_MASK,

        LIGHT_TEXTURE_EFFECT_LIGHT_COLOR,
        LIGHT_TEXTURE_EFFECT_LIGHT_DIFFUSE_AMOUNT,
        LIGHT_TEXTURE_EFFECT_LIGHT_SHADOW_COLOR,
        LIGHT_TEXTURE_EFFECT_LIGHT_SPECULAR_AMOUNT,
        LIGHT_TEXTURE_EFFECT_VOLUMETRIC_DENSITY_AMOUNT,
        LIGHT_TEXTURE_EFFECT_VOLUMETRIC_SCATTERING_COLOR
} LightTextureEffect;

class LightMaterialShaderNodeElement_modo401
        :
        public ShaderNodeElement_modo401
{
    public:
                                 LightMaterialShaderNodeElement_modo401 (
                                        LightShaderNodeElement_modo401	&light,
                                        const std::string		&itemName);
        virtual			~LightMaterialShaderNodeElement_modo401 ();

        void			 SetLightTextureEffect (
                                        LightTextureEffect effect);
};

/*
 * ---------------------------------------------------------------------------
 * Poly Shader Node Technique Profile modo 401.
 */
class PolyShaderNodeElement_modo401
        :
        public ShaderNodeElement_modo401
{
    public:
                                 PolyShaderNodeElement_modo401 (
                                        RenderElement_modo401		&render,
                                        const std::string		&name,
                                        ShaderLayerType			 layerType);

                                 PolyShaderNodeElement_modo401 (
                                        EnvironmentElement_modo401	&environment,
                                        const std::string		&name,
                                        ShaderLayerType			 layerType);

                                 PolyShaderNodeElement_modo401 (
                                        LightShaderNodeElement_modo401	&light,
                                        const std::string		&name,
                                        ShaderLayerType			 layerType);

                                 PolyShaderNodeElement_modo401 (
                                        ShaderNodeElement_modo401	&node,
                                        const std::string		&name,
                                        ShaderLayerType			 layerType);

        virtual			~PolyShaderNodeElement_modo401 ();

        /*
         * Different sets of texture effects are available, depending
         * on the parent shader node type for a given layer.
         */
        void			 SetMaterialTextureEffect (
                                        MaterialTextureEffect effect);

        void			 SetEnvironmentTextureEffect (
                                        EnvironmentTextureEffect effect);

        void			 SetLightTextureEffect (
                                        LightTextureEffect effect);

    private:
        struct pv_PolyShaderNodeElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Shader Node Constant Technique Profile modo 401.
 */

typedef enum en_EffectConstantStorageType
{
        EFFECT_CONSTANT_STORAGE_COLOR,
        EFFECT_CONSTANT_STORAGE_PERCENT,
        EFFECT_CONSTANT_STORAGE_BOTH,
} EffectConstantStorageType;

class RenderElement_modo401;
class EnvironmentElement_modo401;

class ConstantShaderNodeElement_modo401
        :
        public PolyShaderNodeElement_modo401
{
    public:
                                 /*
                                  * Constant effects can be parented directly
                                  * to a render, an environment, a light, or
                                  * another shader effect.
                                  */
                                 ConstantShaderNodeElement_modo401 (
                                        RenderElement_modo401		&render,
                                        const std::string		&itemName);

                                 ConstantShaderNodeElement_modo401 (
                                        EnvironmentElement_modo401	&environment,
                                        const std::string		&itemName);

                                 ConstantShaderNodeElement_modo401 (
                                        LightShaderNodeElement_modo401	&light,
                                        const std::string		&itemName);

                                 ConstantShaderNodeElement_modo401 (
                                        ShaderNodeElement_modo401	&node,
                                        const std::string		&itemName);

        virtual			~ConstantShaderNodeElement_modo401 ();

        void			 SetColor (const ColorRGB &color);
        void			 SetAmount (double percent);

    private:
        struct pv_ConstantShaderNodeElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Render Node.
 */

typedef enum en_ResolutionUnit
{
        RESOLUTION_UNIT_PIXELS,
        RESOLUTION_UNIT_INCHES
} ResolutionUnit;

typedef enum en_BucketOrder
{
        BUCKET_ORDER_COLUMNS,
        BUCKET_ORDER_HILBERT,
        BUCKET_ORDER_RANDOM,
        BUCKET_ORDER_ROWS,
        BUCKET_ORDER_SPIRAL
} BucketOrder;

class ShaderNodeLibraryElement_modo401;

class RenderElement_modo401 : public Element
{
        friend class ShaderNodeElement_modo401;
        friend class AdvancedShaderNodeElement_modo401;

    public:
                                 RenderElement_modo401 (
                                        ShaderNodeLibraryElement_modo401 &library);
        virtual			~RenderElement_modo401 ();

        /*
         * -------------------------------------------------------------------
         * Frame group.
         */
        void			 SetFrameRangeFirst (unsigned first);
        void			 SetFrameRangeLast (unsigned last);
        void			 SetFrameRangeStep (unsigned step);

        /*
         * See PARAMVALUE_MODO_POLYRENDER_RESOLUTION_UNIT_
         */
        void			 SetResolutionUnit (
                                        const std::string &unit);

        void			 SetFrameDPI (double dpi);
        void			 SetFramePixelAspectRatio (double ratio);

        /*
         * -------------------------------------------------------------------
         * Buckets group.
         */
        void			 SetBucketWidth (unsigned width);
        void			 SetBucketHeight (unsigned height);

        /*
         * See PARAMVALUE_MODO_RENDER_BUCKET_ORDER_
         */
        void			 SetBucketOrder (const std::string &order);

        void			 SetBucketReverseOrder (bool reversed);
        void			 SetBucketWriteToDisk (bool write);
        void			 SetBucketSkipExisting (bool skip);

        /* 
         * -------------------------------------------------------------------
         * Region.
         */
        void			 SetRenderRegion (bool useRegion);
        void			 SetRenderRegionLeft (double left);
        void			 SetRenderRegionRight (double right);
        void			 SetRenderRegionTop (double top);
        void			 SetRenderRegionBottom (double bottom);
 
        /*
         * -------------------------------------------------------------------
         * Antialiasing.
         */

        /*
         * See PARAMVALUE_MODO_RENDER_AA_
         */
        void			 SetAntialiasing (
                                        const std::string &aa);

        /*
         * See PARAMVALUE_MODO_RENDER_AA_FILTER_
         */
        void			 SetAntialiasingFilter (
                                        const std::string &filter);

        void			 SetRefinementShadingRate (double rate);
        void			 SetRefinementThreshold (double threshold);
        void			 SetRefineBucketBorders (bool refine);
        void			 SetRenderDepthOfField (bool dof);
        void			 SetRenderMotionBlur (bool motionBlur);
        void			 SetRenderStereoscopic (bool stereo);

        /*
         * -------------------------------------------------------------------
         * Ray Tracing.
         */
        void			 SetRayTracingShadows (bool shadows);
        void			 SetReflectionDepth (unsigned depth);
        void			 SetRefractionDepth (unsigned depth);
        void			 SetRayThreshold (double threshold);

        /*
         * -------------------------------------------------------------------
         * Geometry.
         */
        void			 SetAdaptiveSubdivision (bool adaptiveSubd);
        void			 SetSubdivisionRate (double rate);
        void			 SetMicropolyDisplacement (bool micro);
        void			 SetDisplacementRate (double rate);
        void			 SetDisplacementRatio (double ratio);
        void			 SetMinimumEdgeLength (double length);
        void			 SetSmoothPositions (bool smooth);

        /*
         * -------------------------------------------------------------------
         * Ambient Light.
         */
        void			 SetAmbientIntensity (double intensity);
        void			 SetAmbientColor (const ColorRGB &color);

        /*
         * -------------------------------------------------------------------
         * Indirect Illumination.
         */
        void			 SetEnableIndirectIllumination (bool enable);

        /*
         * See PARAMVALUE_MODO_INDIRECTILLUMINATIONSCOPE_
         */
        void			 SetIndirectIlluminationScope (
                                        const std::string &scope);

        void			 SetIndirectRays (unsigned rays);
        void			 SetIndirectBounces (unsigned bounces);
        void			 SetIndirectRange (double range);
        void			 SetSubsurfaceScattering (unsigned scattering);
        void			 SetVolumetricsAffectIndirect (bool affect);

        /*
         * -------------------------------------------------------------------
         * Irradiance Caching.
         */
        void			 SetIrradianceCaching (bool caching);
        void			 SetIrradianceRays (unsigned rays);
        void			 SetIndirectSupersampling (bool indirectSuper);
        void			 SetIrradianceRate (double rate);
        void			 SetIrradianceRatio (double ratio);
        void			 SetInterpolationValues (unsigned values);

        /*
         * See PARAMVALUE_MODO_IRRADIANCEGRADIENTS_
         */
        void			 SetIrradianceGradients (
                                        const std::string &gradients);

        void			 SetWalkthroughMode (bool mode);
        void			 SetLoadIrradianceBeforeRender (bool loadBefore);
        void			 SetLoadIrradianceFile (const std::string file);
        void			 SetSaveIrradianceAfterRender (bool saveAfter);
        void			 SetSaveIrradianceFile (const std::string file);

        /*
         * -------------------------------------------------------------------
         * Caustics.
         */
        void			 SetEnableDirectCaustics (bool enable);
        void			 SetCausticsTotalPhotons (unsigned total);
        void			 SetCausticsLocalPhotons (unsigned local);

        /*
         * See PARAMVALUE_MODO_INDIRECTCAUSTICS_
         */
        void			 SetIndirectCaustics (const std::string &indirect);

   protected:
        /*
         * The node layer type must be SHADER_LAYER_ADVANCED_MATERIAL
         * or one of the SHADER_LAYER_POLY_foo types.
         */
        void			 AddShaderNode (
                                        ShaderNodeElement_modo401 *node);

    private:
        struct pv_RenderElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Environment Node.
 */

class EnvironmentElement_modo401 : public Element
{
        friend class ShaderNodeElement_modo401;

    public:
                                 EnvironmentElement_modo401 (
                                        ShaderNodeLibraryElement_modo401 &library);
        virtual			~EnvironmentElement_modo401 ();

        void			 SetIntensity (double intensity);

        void			 SetVisibleToCamera (bool visible);
        void			 SetVisibleToIndirectRays (bool visible);
        void			 SetVisibleToReflectionRays (bool visible);
        void			 SetVisibleToRefractionRays (bool visible);

    protected:
        /*
         * The node layer type must be SHADER_LAYER_ENVIRONMENT_MATERIAL
         * or one of the SHADER_LAYER_POLY_foo types.
         */
        void			 AddShaderNode (
                                        ShaderNodeElement_modo401 *node);

    private:
        struct pv_EnvironmentElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Shader Light Node.
 */
class LightShaderNodeElement_modo401 : public Element
{
        friend class ShaderNodeElement_modo401;

    public:
                                 LightShaderNodeElement_modo401 (
                                        ShaderNodeLibraryElement_modo401	&library,
                                        const std::string			&name);
        virtual			~LightShaderNodeElement_modo401 ();

    protected:
        /*
         * The node layer type must be SHADER_LAYER_LIGHT_MATERIAL
         * or one of the SHADER_LAYER_POLY_foo types.
         */
        void			 AddShaderNode (
                                        ShaderNodeElement_modo401 *node);
};

/*
 * ---------------------------------------------------------------------------
 * Shader Node Library.
 */

class COLLADAElement;

class ShaderNodeLibraryElement_modo401 : public Element
{
        friend class RenderElement_modo401;
        friend class EnvironmentElement_modo401;
        friend class LightShaderNodeElement_modo401;

    public:
                                 ShaderNodeLibraryElement_modo401 (
                                        COLLADAElement &collada);
        virtual			~ShaderNodeLibraryElement_modo401 ();

    protected:
        void			 AddRender (
                                        RenderElement_modo401 &render);

        void			 AddEnvironment (
                                        EnvironmentElement_modo401 &environment);

        void			 AddLight (
                                        LightShaderNodeElement_modo401 &light);
};

} // namespace cio

#endif // CIO_SHADERNODE_H

