/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_SCHEMA_H
#define CIO_SCHEMA_H

namespace cio {

/*
 * -------------------------------------------------------------------
 * COLLADA XML schema identifiers.
 *
 * Clients of cio::File and cio::Element (and its subclasses) should
 * rarely need to reference any of these values.
 *
 * CLIENTS SHOULD NOT MODIFY ANYTHING BELOW THIS LINE!
 */

/*
 * Elements.
 */
extern const char* ELEMENT_ACCESSOR;
extern const char* ELEMENT_AMBIENT;
extern const char* ELEMENT_ANGULAR;
extern const char* ELEMENT_ANGULAR_VELOCITY;
extern const char* ELEMENT_ANIMATION;
extern const char* ELEMENT_ANIMATION_CLIP;
extern const char* ELEMENT_ASPECT_RATIO;
extern const char* ELEMENT_ASSET;
extern const char* ELEMENT_ATTACHMENT;
extern const char* ELEMENT_AUTHOR;
extern const char* ELEMENT_AUTHORING_TOOL;
extern const char* ELEMENT_BIND;
extern const char* ELEMENT_BIND_MATERIAL;
extern const char* ELEMENT_BIND_SHAPE_MATRIX;
extern const char* ELEMENT_BIND_VERTEX_INPUT;
extern const char* ELEMENT_BLINN;
extern const char* ELEMENT_BOOL_ARRAY;
extern const char* ELEMENT_BOX;
extern const char* ELEMENT_CAMERA;
extern const char* ELEMENT_CAPSULE;
extern const char* ELEMENT_CHANNEL;
extern const char* ELEMENT_COLLADA;
extern const char* ELEMENT_COLOR;
extern const char* ELEMENT_COMMENTS;
extern const char* ELEMENT_CONSTANT;
extern const char* ELEMENT_CONSTANT_ATTENUATION;
extern const char* ELEMENT_CONTRIBUTOR;
extern const char* ELEMENT_CONTROLLER;
extern const char* ELEMENT_CONVEX_MESH;
extern const char* ELEMENT_COPYRIGHT;
extern const char* ELEMENT_CREATED;
extern const char* ELEMENT_CYLINDER;
extern const char* ELEMENT_DAMPING;
extern const char* ELEMENT_DENSITY;
extern const char* ELEMENT_DIFFUSE;
extern const char* ELEMENT_DIRECTIONAL;
extern const char* ELEMENT_DYNAMIC;
extern const char* ELEMENT_DYNAMIC_FRICTION;
extern const char* ELEMENT_EFFECT;
extern const char* ELEMENT_EMISSION;
extern const char* ELEMENT_ENABLED;
extern const char* ELEMENT_EQUATION;
extern const char* ELEMENT_EXTRA;
extern const char* ELEMENT_FALLOFF_ANGLE;
extern const char* ELEMENT_FALLOFF_EXPONENT;
extern const char* ELEMENT_FLOAT;
extern const char* ELEMENT_FLOAT3;
extern const char* ELEMENT_FLOAT_ARRAY;
extern const char* ELEMENT_FORCE_FIELD;
extern const char* ELEMENT_FORMAT;
extern const char* ELEMENT_GEOMETRY;
extern const char* ELEMENT_GRAVITY;
extern const char* ELEMENT_H;
extern const char* ELEMENT_HALF_EXTENTS;
extern const char* ELEMENT_HEIGHT;
extern const char* ELEMENT_HOLLOW;
extern const char* ELEMENT_IMAGE;
extern const char* ELEMENT_IMAGER;
extern const char* ELEMENT_INDEX_OF_REFRACTION;
extern const char* ELEMENT_INERTIA;
extern const char* ELEMENT_INIT_FROM;
extern const char* ELEMENT_INPUT;
extern const char* ELEMENT_INSTANCE_CAMERA;
extern const char* ELEMENT_INSTANCE_CONTROLLER;
extern const char* ELEMENT_INSTANCE_EFFECT;
extern const char* ELEMENT_INSTANCE_FORCE_FIELD;
extern const char* ELEMENT_INSTANCE_GEOMETRY;
extern const char* ELEMENT_INSTANCE_LIGHT;
extern const char* ELEMENT_INSTANCE_MATERIAL;
extern const char* ELEMENT_INSTANCE_NODE;
extern const char* ELEMENT_INSTANCE_PHYSICS_MATERIAL;
extern const char* ELEMENT_INSTANCE_PHYSICS_MODEL;
extern const char* ELEMENT_INSTANCE_PHYSICS_SCENE;
extern const char* ELEMENT_INSTANCE_RIGID_BODY;
extern const char* ELEMENT_INSTANCE_RIGID_CONSTRAINT;
extern const char* ELEMENT_INSTANCE_VISUAL_SCENE;
extern const char* ELEMENT_INT_ARRAY;
extern const char* ELEMENT_INTENSITY;
extern const char* ELEMENT_INTERPENETRATE;
extern const char* ELEMENT_JOINTS;
extern const char* ELEMENT_KEYWORDS;
extern const char* ELEMENT_LAMBERT;
extern const char* ELEMENT_LIBRARY_ANIMATIONS;
extern const char* ELEMENT_LIBRARY_ANIMATION_CLIPS;
extern const char* ELEMENT_LIBRARY_CAMERAS;
extern const char* ELEMENT_LIBRARY_CONTROLLERS;
extern const char* ELEMENT_LIBRARY_EFFECTS;
extern const char* ELEMENT_LIBRARY_GEOMETRIES;
extern const char* ELEMENT_LIBRARY_IMAGES;
extern const char* ELEMENT_LIBRARY_LIGHTS;
extern const char* ELEMENT_LIBRARY_MATERIALS;
extern const char* ELEMENT_LIBRARY_NODES;
extern const char* ELEMENT_LIBRARY_PHYSICS_MODELS;
extern const char* ELEMENT_LIBRARY_PHYSICS_SCENES;
extern const char* ELEMENT_LIBRARY_VISUAL_SCENES;
extern const char* ELEMENT_LIGHT;
extern const char* ELEMENT_LIMITS;
extern const char* ELEMENT_LINEAR;
extern const char* ELEMENT_LINEAR_ATTENUATION;
extern const char* ELEMENT_LINES;
extern const char* ELEMENT_LINESTRIPS;
extern const char* ELEMENT_LOOKAT;
extern const char* ELEMENT_MAGFILTER;
extern const char* ELEMENT_MASS;
extern const char* ELEMENT_MASS_FRAME;
extern const char* ELEMENT_MATERIAL;
extern const char* ELEMENT_MATRIX;
extern const char* ELEMENT_MAX;
extern const char* ELEMENT_MESH;
extern const char* ELEMENT_MIN;
extern const char* ELEMENT_MINFILTER;
extern const char* ELEMENT_MODIFIED;
extern const char* ELEMENT_NAME_ARRAY;
extern const char* ELEMENT_NEWPARAM;
extern const char* ELEMENT_NODE;
extern const char* ELEMENT_OPTICS;
extern const char* ELEMENT_ORTHOGRAPHIC;
extern const char* ELEMENT_P;
extern const char* ELEMENT_PARAM;
extern const char* ELEMENT_PERSPECTIVE;
extern const char* ELEMENT_PH;
extern const char* ELEMENT_PHONG;
extern const char* ELEMENT_PHYSICS_MATERIAL;
extern const char* ELEMENT_PHYSICS_MODEL;
extern const char* ELEMENT_PHYSICS_SCENE;
extern const char* ELEMENT_PLANE;
extern const char* ELEMENT_POINT;
extern const char* ELEMENT_POLYGONS;
extern const char* ELEMENT_POLYLIST;
extern const char* ELEMENT_POST_INFINITY;
extern const char* ELEMENT_PRE_INFINITY;
extern const char* ELEMENT_PROFILE_COMMON;
extern const char* ELEMENT_QUADRATIC_ATTENUATION;
extern const char* ELEMENT_RADIUS;
extern const char* ELEMENT_RADIUS1;
extern const char* ELEMENT_RADIUS2;
extern const char* ELEMENT_REF_ATTACHMENT;
extern const char* ELEMENT_REFLECTIVE;
extern const char* ELEMENT_REFLECTIVITY;
extern const char* ELEMENT_RESTITUTION;
extern const char* ELEMENT_REVISION;
extern const char* ELEMENT_RIGID_BODY;
extern const char* ELEMENT_RIGID_CONSTRAINT;
extern const char* ELEMENT_ROTATE;
extern const char* ELEMENT_SAMPLER;
extern const char* ELEMENT_SAMPLER2D;
extern const char* ELEMENT_SCALE;
extern const char* ELEMENT_SCENE;
extern const char* ELEMENT_SETPARAM;
extern const char* ELEMENT_SHAPE;
extern const char* ELEMENT_SHININESS;
extern const char* ELEMENT_SKELETON;
extern const char* ELEMENT_SKEW;
extern const char* ELEMENT_SKIN;
extern const char* ELEMENT_SOURCE;
extern const char* ELEMENT_SOURCE_DATA;
extern const char* ELEMENT_SPECULAR;
extern const char* ELEMENT_SPHERE;
extern const char* ELEMENT_SPOT;
extern const char* ELEMENT_SPRING;
extern const char* ELEMENT_STATIC_FRICTION;
extern const char* ELEMENT_STIFFNESS;
extern const char* ELEMENT_SUBJECT;
extern const char* ELEMENT_SURFACE;
extern const char* ELEMENT_SWING_CONE_AND_TWIST;
extern const char* ELEMENT_TAPERED_CAPSULE;
extern const char* ELEMENT_TAPERED_CYLINDER;
extern const char* ELEMENT_TARGET_VALUE;
extern const char* ELEMENT_TECHNIQUE;
extern const char* ELEMENT_TECHNIQUE_COMMON;
extern const char* ELEMENT_TIME_STEP;
extern const char* ELEMENT_TITLE;
extern const char* ELEMENT_TEXTURE;
extern const char* ELEMENT_TRANSLATE;
extern const char* ELEMENT_TRANSPARENCY;
extern const char* ELEMENT_TRANSPARENT;
extern const char* ELEMENT_TRIANGLES;
extern const char* ELEMENT_TRIFANS;
extern const char* ELEMENT_TRISTRIPS;
extern const char* ELEMENT_UNIT;
extern const char* ELEMENT_UP_AXIS;
extern const char* ELEMENT_V;
extern const char* ELEMENT_VCOUNT;
extern const char* ELEMENT_VELOCITY;
extern const char* ELEMENT_VERTEX_WEIGHTS;
extern const char* ELEMENT_VERTICES;
extern const char* ELEMENT_VISUAL_SCENE;
extern const char* ELEMENT_XFOV;
extern const char* ELEMENT_XMAG;
extern const char* ELEMENT_YFOV;
extern const char* ELEMENT_YMAG;
extern const char* ELEMENT_ZFAR;
extern const char* ELEMENT_ZNEAR;

/*
 * Attributes.
 */
extern const char* ATTRIBUTE_BODY;
extern const char* ATTRIBUTE_CONSTRAINT;
extern const char* ATTRIBUTE_COUNT;
extern const char* ATTRIBUTE_ENCODING;
extern const char* ATTRIBUTE_END;
extern const char* ATTRIBUTE_ID;
extern const char* ATTRIBUTE_INPUT_SEMANTIC;
extern const char* ATTRIBUTE_INPUT_SET;
extern const char* ATTRIBUTE_NAME;
extern const char* ATTRIBUTE_MATERIAL;
extern const char* ATTRIBUTE_METER;
extern const char* ATTRIBUTE_OFFSET;
extern const char* ATTRIBUTE_OPAQUE;
extern const char* ATTRIBUTE_PROFILE;
extern const char* ATTRIBUTE_REF;
extern const char* ATTRIBUTE_SEMANTIC;
extern const char* ATTRIBUTE_SET;
extern const char* ATTRIBUTE_SID;
extern const char* ATTRIBUTE_SOURCE;
extern const char* ATTRIBUTE_START;
extern const char* ATTRIBUTE_STRIDE;
extern const char* ATTRIBUTE_SYMBOL;
extern const char* ATTRIBUTE_TARGET;
extern const char* ATTRIBUTE_TEXCOORD;
extern const char* ATTRIBUTE_TEXTURE;
extern const char* ATTRIBUTE_TYPE;
extern const char* ATTRIBUTE_URL;
extern const char* ATTRIBUTE_VERSION;
extern const char* ATTRIBUTE_XMLNS;

/*
 * Common technique parameters.
 */
extern const char* PARAM_ASPECT_RATIO;
extern const char* PARAM_ASPECT_RATIO_NAME;

extern const char* PARAM_AMBIENT_EFFECT_COLOR;

extern const char* PARAM_AMBIENT_LIGHT_COLOR;

extern const char* PARAM_CONSTANT_ATTENUATION;
extern const char* PARAM_CONSTANT_ATTENUATION_NAME;

extern const char* PARAM_DIFFUSE_EFFECT_COLOR;

extern const char* PARAM_DIRECTIONAL_LIGHT_COLOR;

extern const char* PARAM_EMISSION_EFFECT_COLOR;

extern const char* PARAM_FALLOFF_ANGLE;

extern const char* PARAM_FALLOFF_EXPONENT;

extern const char* PARAM_INDEX_OF_REFRACTION;

extern const char* PARAM_JOINT_NAME;

extern const char* PARAM_LINEAR_ATTENUATION;
extern const char* PARAM_LINEAR_ATTENUATION_NAME;

extern const char* PARAM_POINT_LIGHT_COLOR;
extern const char* PARAM_POINT_LIGHT_COLOR_NAME;

extern const char* PARAM_QUADRATIC_ATTENUATION;
extern const char* PARAM_QUADRATIC_ATTENUATION_NAME;

extern const char* PARAM_REFLECTIVE_EFFECT_COLOR;

extern const char* PARAM_REFLECTIVITY_EFFECT;

extern const char* PARAM_SPECULAR_EFFECT_COLOR;

extern const char* PARAM_SPOT_LIGHT_COLOR;
extern const char* PARAM_SPOT_LIGHT_COLOR_NAME;

extern const char* PARAM_TRANSPARENCY_EFFECT;

extern const char* PARAM_TRANSPARENT_EFFECT_COLOR;

extern const char* PARAM_XFOV;
extern const char* PARAM_XFOV_NAME;

extern const char* PARAM_XMAG;
extern const char* PARAM_XMAG_NAME;

extern const char* PARAM_YFOV;
extern const char* PARAM_YFOV_NAME;

extern const char* PARAM_YMAG;
extern const char* PARAM_YMAG_NAME;

extern const char* PARAM_ZFAR;
extern const char* PARAM_ZFAR_NAME;

extern const char* PARAM_ZNEAR;
extern const char* PARAM_ZNEAR_NAME;

} // namespace cio

#endif // CIO_SCHEMA_H
