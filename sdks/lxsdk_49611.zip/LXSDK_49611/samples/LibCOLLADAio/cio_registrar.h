/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_REGISTRAR_H
#define CIO_REGISTRAR_H

#include "cio_bind.h"

#include <string>

namespace cio {

class ElementParamRegistrar
{
    public:
                                 ElementParamRegistrar (
                                        ElementParamBind &bind);
        virtual			~ElementParamRegistrar ();

    private:
        /*
         * Register targetable parameters for each element type.
         */
        void			 RegisterParameters ();
        void			 RegisterParameter (
                                        const std::string	&parentElementName,
                                        const std::string	&elementName,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Camera parameter registration.
         */

        void			 RegisterCameraParameters ();
        void			 RegisterCameraParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);
        void			 RegisterCameraImagerParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);
        void			 RegisterCameraOpticsCommon (
                                        const std::string	&elementName,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);
        void			 RegisterCameraOpticsProfile_modo401 (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Light parameter registration.
         */

        void			 RegisterLightParameters ();

        void			 RegisterLightLocatorParameters (
                                        const std::string	&parentElementName);

        void			 RegisterLightCommonParameters (
                                        const std::string	&parentElementName);

        void			 RegisterLightTargetParameters (
                                        const std::string	&parentElementName);

        void			 RegisterAreaLightParameters ();
        void			 RegisterAreaLightParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        void			 RegisterCylinderLightParameters ();
        void			 RegisterCylinderLightParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        void			 RegisterDomeLightParameters ();
        void			 RegisterDomeLightParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        void			 RegisterPhotometricLightParameters ();
        void			 RegisterPhotometricLightParameters (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        void			 RegisterPointLightParameters ();
        void			 RegisterPointLightParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        void			 RegisterSpotLightParameters ();
        void			 RegisterSpotLightParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        void			 RegisterSunLightParameters ();
        void			 RegisterSunLightParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Mesh parameter registration.
         */

        void			 RegisterMeshParameters ();
        void			 RegisterMeshParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Render parameter registration.
         */

        void			 RegisterRenderParameters ();
        void			 RegisterRenderParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Environment parameter registration.
         */

        void			 RegisterEnvironmentParameters ();
        void			 RegisterEnvironmentParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Environment Material parameter registration.
         */

        void			 RegisterEnvironmentMaterialParameters ();
        void			 RegisterEnvironmentMaterialParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);


        /*
         * Shader Advanced Material parameter registration.
         */
        void			 RegisterShaderAdvancedMaterialParameters ();
        void			 RegisterShaderAdvancedMaterialParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Shader Constant parameter registration.
         */
        void			 RegisterShaderConstantParameters ();
        void			 RegisterShaderConstantParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Shader Light Material parameter registration.
         */
        void			 RegisterShaderLightMaterialParameters ();
        void			 RegisterShaderLightMaterialParameter (
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        /*
         * Shader Node parameter registration.
         */
        void			 RegisterShaderNodeParameters (
                                        const std::string	&parentElement);
        void			 RegisterShaderNodeParameter (
                                        const std::string	&parentElement,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		 paramType = PARAM_TYPE_FLOAT);

        ElementParamBind	&elementParamBind;
};

} // namespace cio

#endif // CIO_REGISTRAR_H

