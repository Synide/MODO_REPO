/*
 * Plug-in component shader: Halftone Shading
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 */

#include <lx_shade.hpp>
#include <lx_vector.hpp>
#include <lx_package.hpp>
#include <lx_action.hpp>
#include <lx_value.hpp>
#include <lx_log.hpp>
#include <lx_channelui.hpp>
#include <lx_item.hpp>
#include <lxcommand.h>
#include <lxidef.h>
#include <lx_raycast.hpp>
#include <lx_shdr.hpp>

#include <math.h>
#include <string>


        namespace Halftone_Shader {	// disambiguate everything with a namespace



/*
 * Vector Packet definition: Halftone Packet
 * Here we define the packet that will be used to carry the shading parameters through the shading pipe
 */
        
class HalftonePacket : public CLxImpl_VectorPacket
{
    public:
        HalftonePacket () {}

        static LXtTagInfoDesc	descInfo[];

        unsigned int	vpkt_Size () LXx_OVERRIDE;
        const LXtGUID * vpkt_Interface (void) LXx_OVERRIDE;
        LxResult	vpkt_Initialize (void	*packet) LXx_OVERRIDE;
        LxResult	vpkt_Blend (void	*packet,void	*p0,void	*p1,float	t,int	mode) LXx_OVERRIDE;
};

#define SRVs_HTONE_VPACKET		"halftone.shader.packet"
#define LXsP_SAMPLE_HALFTONE		SRVs_HTONE_VPACKET

LXtTagInfoDesc	 HalftonePacket::descInfo[] = {
        { LXsSRV_USERNAME,	"Halftone Shader Packet" },
        { LXsSRV_LOGSUBSYSTEM,	"vector-packet"},
        { LXsVPK_CATEGORY,	LXsCATEGORY_SAMPLE},
        { 0 }
};

typedef struct st_LXpHalftone {
        float		angle;
        float		sinA, cosA;
        float		uvOffset; // percent of cell size
        float		tiles;
        LXtFVector	patColor;
} LXpHalftone;


        unsigned int
HalftonePacket::vpkt_Size (void) 
{
        return	sizeof (LXpHalftone);
}
        
        const LXtGUID *
HalftonePacket::vpkt_Interface (void)
{
        return NULL;
}

        LxResult
HalftonePacket::vpkt_Initialize (
        void			*p) 
{
        LXpHalftone		*csp = (LXpHalftone *)p;

        csp->angle = 0.0;
        csp->sinA = 0.0;
        csp->cosA = 1.0;

        csp->tiles = 64;
        csp->uvOffset = 0;
        LXx_VCLR (csp->patColor);
        return LXe_OK;
}

        LxResult
HalftonePacket::vpkt_Blend (
        void			*p, 
        void			*p0, 
        void			*p1,
        float			 t,
        int			 mode)
{
        return LXe_OK;
}


/*
 * Non-photorealistic Shader Material: Use halftone pattern to replace diffuse/specular shading
 */
class HalftoneMaterial : public CLxImpl_CustomMaterial
{
    public:
        HalftoneMaterial () {}

        static LXtTagInfoDesc	descInfo[];

        LxResult		cmt_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		cmt_LinkChannels  (ILxUnknownID eval, ILxUnknownID item) LXx_OVERRIDE;
        LxResult		cmt_ReadChannels  (ILxUnknownID attr, void **ppvData) LXx_OVERRIDE;
        LxResult		cmt_CustomPacket  (const char	**) LXx_OVERRIDE;
        void			cmt_MaterialEvaluate      (
                                        ILxUnknownID		 vector,
                                        void			*data) LXx_OVERRIDE;
        void			cmt_ShaderEvaluate      (
                                        ILxUnknownID		 vector,
                                        ILxUnknownID		 rayObj,
                                        LXpShadeComponents	*sCmp,
                                        LXpShadeOutput		*sOut,
                                        void			*data) LXx_OVERRIDE;
        void			cmt_Cleanup       (void *data) LXx_OVERRIDE;

        LxResult		cmt_SetOpaque     (int *opaque) LXx_OVERRIDE;
                
        LXtItemType		MyType ();

        CLxUser_PacketService	pkt_service;
        
        unsigned		ray_offset;
        unsigned		nrm_offset;
        unsigned		tex_offset;
        unsigned		pix_offset;
        unsigned		prm_offset;
        unsigned		cst_offset;
        unsigned		res_offset;
        unsigned		pkt_offset;
        
  	LXtItemType		my_type; 	
        
        unsigned                idx[24];     // indices to each data channel in RendData
        
        class RendData {
            public:
                int		pattern;  // which halftone pattern
                int		specPattern;  // which pattern for sepcular
                float		angle;
                float		tiles;
                float		uvOffset; // percent of cell size
                float		sinA, cosA;
                bool		screenCoords;
                float		depthScale; // for screen coords, percent tiling scale per meter depth
                LXtFVector	patColor;
                int		drawSpec;
        };

private:
        int			htMode;
        float HToneCell ( int mode, float u, float v, float level);
};

#define SRVs_HTONE_MATR		"halftone"
#define SRVs_HTONE_MATR_ITEMTYPE		"material." SRVs_HTONE_MATR

LXtTagInfoDesc	 HalftoneMaterial::descInfo[] = {
        { LXsSRV_USERNAME,	"Halftone Shader" },
        { LXsSRV_LOGSUBSYSTEM,	"comp-shader"	},
        { 0 }
};

/*
 * clean up render data
 */
        void
HalftoneMaterial::cmt_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*
 * Setup channels for the item type.
 */

enum {
        HTONE_PAT_DOTS=0,
        HTONE_PAT_LINES,
        HTONE_PAT_HATCH,
        HTONE_PAT_ADAPT
};

static LXtTextValueHint hint_Pattern[] = {
        HTONE_PAT_DOTS,		"dots",
        HTONE_PAT_LINES,	"lines",
        HTONE_PAT_HATCH,	"crosshatch",
        HTONE_PAT_ADAPT,	"adaptive",
        -1,			"=halftone-pattern",
        -1,			 0
};

#define HALFTONE_CH_PATTERN	 "cellPattern"
#define HALFTONE_CH_TILES	 "cellTiles"
#define HALFTONE_CH_CELLANG	 "cellAngle"
#define HALFTONE_CH_SPEC	 "drawSpecular"
#define HALFTONE_CH_EDGES	 "drawEdges"
#define HALFTONE_CH_INCEDGE	 "incidenceEdges"
#define HALFTONE_CH_ANGEDGE	 "angleEdges"
#define HALFTONE_CH_DISTEDGE	 "distanceEdges"
#define HALFTONE_CH_ANGMIN	 "minAngle"
#define HALFTONE_CH_ANGMAX	 "maxAngle"
#define HALFTONE_CH_THRSH	 "distThreshold"
#define HALFTONE_CH_EDWIDTH	 "edgesWidth"
#define HALFTONE_CH_SCREEN	 "screenCoords"
#define HALFTONE_CH_SPECPAT	 "specPattern"
#define HALFTONE_CH_ZSCALE	 "zScale"
#define HALFTONE_CH_PATCOLOR	 "patColor"

        LxResult
HalftoneMaterial::cmt_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
 	LXtVector zero = {0, 0, 0};
    
        ac.NewChannel (HALFTONE_CH_PATTERN,            LXsTYPE_INTEGER);
        ac.SetDefault (0.0, HTONE_PAT_ADAPT);
        ac.SetHint    (hint_Pattern);

        ac.NewChannel (HALFTONE_CH_SPECPAT,            LXsTYPE_INTEGER);
        ac.SetDefault (0.0, HTONE_PAT_DOTS);
        ac.SetHint    (hint_Pattern);

        ac.NewChannel (HALFTONE_CH_TILES,        LXsTYPE_FLOAT);
        ac.SetDefault (64.0, 0);

        ac.NewChannel (HALFTONE_CH_CELLANG,        LXsTYPE_ANGLE);
        ac.SetDefault (0.0, 0);

        ac.NewChannel (HALFTONE_CH_SPEC,            LXsTYPE_BOOLEAN);
        ac.SetDefault (0.0, 1);

        ac.NewChannel (HALFTONE_CH_SCREEN,	       LXsTYPE_BOOLEAN);
        ac.SetDefault (0.0, 1);

        ac.NewChannel (HALFTONE_CH_ZSCALE,        LXsTYPE_PERCENT);
        ac.SetDefault (0.02, 0);

        ac.NewChannel (HALFTONE_CH_PATCOLOR, LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (zero);

        return LXe_OK;
}

/*
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 */
        LxResult
HalftoneMaterial::cmt_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);

        idx[0] = ev.AddChan (item, HALFTONE_CH_PATTERN);		
        idx[1] = ev.AddChan (item, HALFTONE_CH_TILES);
        idx[2] = ev.AddChan (item, HALFTONE_CH_CELLANG);

        idx[3] = ev.AddChan (item, HALFTONE_CH_SPEC);
        idx[4] = ev.AddChan (item, HALFTONE_CH_SCREEN);
        idx[5] = ev.AddChan (item, HALFTONE_CH_SPECPAT);
        idx[6] = ev.AddChan (item, HALFTONE_CH_ZSCALE);
        idx[7] = ev.AddChan (item, HALFTONE_CH_PATCOLOR".R");
        idx[8] = ev.AddChan (item, HALFTONE_CH_PATCOLOR".G");
        idx[9] = ev.AddChan (item, HALFTONE_CH_PATCOLOR".B");

        ray_offset  = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_RAY);
        nrm_offset  = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SURF_NORMAL);
        tex_offset  = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);
        prm_offset  = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_PARMS);
        cst_offset  = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_RAYCAST);
        res_offset  = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_CAM_RESOLUTION);
        pkt_offset  = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_HALFTONE);
        return LXe_OK;
}

/*
 * Read channel values which may have changed.
 */
        LxResult
HalftoneMaterial::cmt_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
   
        rd->pattern             = at.Int (idx[0]);		
        rd->tiles		= at.Int (idx[1]);
        rd->angle	        = at.Float (idx[2]);

        rd->drawSpec            = at.Int (idx[3]);
        rd->screenCoords	= at.Bool (idx[4]);
        rd->specPattern         = at.Int (idx[5]);		
        rd->depthScale          = at.Float (idx[6]);
        rd->patColor[0]		= at.Float (idx[7]);
        rd->patColor[1]		= at.Float (idx[8]);
        rd->patColor[2]		= at.Float (idx[9]);

        ppvData[0] = rd;
        rd->sinA = sin(rd->angle);
        rd->cosA = cos(rd->angle);
        return LXe_OK;
}

        static double
FVectorNormalize (
        LXtFVector		v) 
{
        float		m, p;
        m = LXx_VDOT (v, v);
        if(m<=0)
                return -1;
        m = sqrt (m);
        p = 1.0 / m;
        LXx_VSCL (v, p);
        return m;
}


#define ROOT2			1.414213562
static float xsc = 1.0;


        float
HalftoneMaterial::HToneCell (
           int			 mode,
           float		 u,
           float		 v,
           float		 level) 
{
        static int HTMode = 0;
        static float	minW = 0.1, maxW = 0.5;
        float			r,val = 0;

        if(HTMode==4)
                return (LXxABS(u)<0.1) || (LXxABS(v)<0.1) ? 1 : 0;

        switch (mode) {
                case HTONE_PAT_DOTS: // dot
                        u -= 0.5;
                        v -= 0.5;
                        r=sqrt(u*u + v*v)*ROOT2;
                        val = ( r>level ? 1.0 :((r>level-0.1) ? (0.1 - (level-r))*10:0)  );	// black circle
                        break;
                case HTONE_PAT_LINES: // h line
                        u -= 0.5;
                        v -= 0.5;
                        r = 2*LXxABS(v);
                        val = ( r>level ? 1.0 :((r>level-0.1) ? (0.1 - (level-r))*10:0)  );
                        break;
                case HTONE_PAT_HATCH: // grid
                        level *= 0.5;
                        u -= 0.5;
                        v -= 0.5;
                        u = LXxABS(u);
                        v = LXxABS(v);
                        r = xsc*LXxMIN (u,v);
                        val = ( r>level ? 1.0 :((r>level-0.1) ? (0.1 - (level-r))*10:0)  );
                        break;
                case HTONE_PAT_ADAPT: // dashed line, line, cross, depending on weight
                default: 
                        u -= 0.5;
                        v -= 0.5;
                        u = LXxABS(u);
                        v = LXxABS(v);

                        if(level<minW) {
                                float	lev, v2;
                                r = 2*v;
                                val = ( r>minW ? 1.0 :((r>minW-0.1) ? (0.1 - (minW-r))*10:0)  );
                                r = 2*u; // shorten line 
                                lev = level * 10;
                                v2 = ( r>lev ? 1.0 :((r>lev-0.1) ? (0.1 - (lev-r))*10:0)  );
                                val = LXxMAX (val, v2);
                        }
                        else if(level<maxW) {
                                r = 2*v;
                                val = ( r>level ? 1.0 :((r>level-0.1) ? (0.1 - (level-r))*10:0)  );
                        }
                        else {
                                float	lev, v2;
                                r = 2*v;
                                val = ( r>maxW ? 1.0 :((r>maxW-0.1) ? (0.1 - (maxW-r))*10:0)  );
                                r = 2*u; // crossing line 
                                lev = 2*(level - maxW);
                                v2 = ( r>lev ? 1.0 :((r>lev-0.1) ? (0.1 - (lev-r))*10:0)  );
                                val = LXxMIN (val, v2);
                        }
                        break;
        }

        if(HTMode==3)
                return r;

        return val;
}

/*
 * Like the cel shader, the halftone shader needs shading values to be computed
 * below it, so it can't be opaque.
 */
        LxResult
HalftoneMaterial::cmt_SetOpaque (
        int			*opaque) 
{
        *opaque = 0;

        return LXe_OK;
}

        LxResult
HalftoneMaterial::cmt_CustomPacket (
        const char		**packet)
{
        packet[0] = LXsP_SAMPLE_HALFTONE;
        return LXe_OK;
}

/*
 * Set custom material values at a spot
 */
        void
HalftoneMaterial::cmt_MaterialEvaluate (
        ILxUnknownID            vector,
        void			*data)
{
        LXpHalftone		*sHalf = (LXpHalftone*) pkt_service.FastPacket (vector, pkt_offset);
        RendData*       	 rd = (RendData*)data;

        // set the edge width in the cel shader packet, this is now available for texturing and for other shaders
        sHalf->tiles = rd->tiles;
        sHalf->angle = rd->angle;
        sHalf->sinA = rd->sinA;
        sHalf->cosA = rd->cosA;
        sHalf->uvOffset = rd->uvOffset;
        LXx_VCPY (sHalf->patColor, rd->patColor);
}

/*
 * Evaluate the color at a spot.
 */
        void
HalftoneMaterial::cmt_ShaderEvaluate (
        ILxUnknownID            vector,
        ILxUnknownID		rayObj,
        LXpShadeComponents     *sCmp,
        LXpShadeOutput         *sOut,
        void                    *data)
{
        LXpTextureInput		*tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tex_offset);
        LXpSampleSurfNormal	*sNrm = (LXpSampleSurfNormal*) pkt_service.FastPacket (vector, nrm_offset);
        LXpSampleRay		*sRay = (LXpSampleRay*) pkt_service.FastPacket (vector, ray_offset);
        LXpSampleParms		*sParms = (LXpSampleParms*) pkt_service.FastPacket (vector, prm_offset);
        LXpCameraResolution	*sRes = (LXpCameraResolution*) pkt_service.FastPacket (vector, res_offset);
        LXpHalftone		*sHalf = (LXpHalftone*) pkt_service.FastPacket (vector, pkt_offset);
        RendData		*rd   = (RendData *) data;
        float			 edge, s, tiles, black[3] = {0,0,0};
        int			 i, j;
        CLxLoc_Raycast		 raycast;

        raycast.set (rayObj);

        float		 u, v, r, a, level=0;
        if (!rd->screenCoords) {
                // rotate UV space
                u = (tInp->uvw[0]-0.5);
                v = (tInp->uvw[1]-0.5);
                
                r = u*sHalf->cosA + v*sHalf->sinA;
                v = v*sHalf->cosA - u*sHalf->sinA;
                u = r;

                u += 0.5;
                v += 0.5;
        }
        else {
                int iu, iv;
                raycast.GetBucketPixel (vector, &iu, &iv);
                raycast.GetBucketSubPixel (vector, &u, &v);
                u += iu;
                v += iv;
                if (sRes->width>0 && sRes->height>0) {
                        u /= sRes->width;
                        v /= sRes->height;
                }
                else {
                        u /= 100;
                        v /= 100;
                }
                u -= 0.5; // rotate about center in middle of UVs
                v -= 0.5;

                r = (1.0 + rd->depthScale*sRay->dist);
                u *= r;
                v *= r;
                r = u*sHalf->cosA + v*sHalf->sinA;
                v = v*sHalf->cosA - u*sHalf->sinA;
                u = r;

                u += 0.5;
                v += 0.5;
        }


        tiles = sHalf->tiles; // use textured value
        // scale UV to tile
        u = tiles*LXxABS (u);
        v = tiles*LXxABS (v);

        u += sHalf->uvOffset;
        v += sHalf->uvOffset;

        i = (int)u;
        u -= i;
        j = (int)v;
        v -= j;

        level = sParms->diffAmt*LXx_VLEN(sParms->diffCol);
        level = level>0 ? LXx_VLEN(sCmp->diff)/level : 0;

        level = 1.0 - level; // darkening level

        LXx_VCPY (sCmp->diff, sParms->diffCol);

        htMode = LXxCLAMP (rd->pattern, 0, 3); //HTMode;
        level = HToneCell (htMode, u,v,level);

        LXx_VSCL (sCmp->diff, level);
        LXx_VADDS (sCmp->diff, sHalf->patColor, (1.0 - level));

        if(rd->drawSpec) {
                level = LXx_VLEN(sParms->specCol); //sParms->specAmt*
                level = level>0 ? LXx_VLEN(sCmp->spec)/level : 0;
                //level = 1.0 - level; // darkening level
                LXx_VCLR (sCmp->spec);
                htMode = LXxCLAMP (rd->specPattern, 0, 3); 
                level = HToneCell (htMode, u,v,level);
                //level = 1.0 - level; // darkening level
                LXx_VLERP (sCmp->diff, sParms->specCol, sCmp->diff, level);
        }

        // Update final output color		
        for (i=0;i<3;i++) 
                sOut->color[i] = sCmp->diff[i] + sCmp->spec[i] + sCmp->refl[i] + sCmp->tran[i] + sCmp->subs[i] + sCmp->lumi[i];
}

/*
 * Utility to get the type code for this item type, as needed.
 */
        LXtItemType
HalftoneMaterial::MyType ()
{
        if (my_type != LXiTYPE_NONE)
                return my_type;

        CLxUser_SceneService	 svc;

        my_type = svc.ItemType (SRVs_HTONE_MATR_ITEMTYPE);
        return my_type;
}



/* --------------------------------- */

/*
 * Packet Effects definition: 
 * Here we define the texture effects on the Halftone packet
 */
        
class HTonePFX : public CLxImpl_PacketEffect
{
    public:
        HTonePFX () {}

        static LXtTagInfoDesc	descInfo[];

        LxResult		pfx_Packet (const char **packet) LXx_OVERRIDE;
        unsigned int		pfx_Count (void) LXx_OVERRIDE;
        LxResult		pfx_ByIndex (int idx, const char **name, const char **typeName, int	*type) LXx_OVERRIDE;
        LxResult		pfx_Get (int idx,void *packet,float *val,void *item) LXx_OVERRIDE;
        LxResult		pfx_Set (int idx,void *packet,const float *val,void *item) LXx_OVERRIDE;
};

#define SRVs_HTONE_PFX		"Halftone"
#define SRVs_EDGE_WIDTH_TFX	"halftoneEdgeWidth"
#define SRVs_TILES_TFX		"halftoneTiles"
#define SRVs_COLOR_TFX		"halftoneColor"
#define SRVs_UVOFF_TFX		"halftoneCellOffset"
#define SRVs_ANGLE_TFX		"halftoneAngle"

LXtTagInfoDesc	 HTonePFX::descInfo[] = {
        { LXsSRV_USERNAME,	"Halftone Packet FX" },
        { LXsSRV_LOGSUBSYSTEM,	"texture-effect"},
        { LXsTFX_CATEGORY,	LXsSHADE_SURFACE},
        { 0 }
};

        LxResult
HTonePFX::pfx_Packet (const char	**packet) 
{
        packet[0] = SRVs_HTONE_VPACKET;
        return LXe_OK;
}

        unsigned int
HTonePFX::pfx_Count (void) 
{
        return	4;
}

        LxResult
HTonePFX::pfx_ByIndex (int	id, const char **name, const char **typeName, int *type) 
{
        switch (id) {
                case 0:
                        name[0]     = SRVs_UVOFF_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case 1:
                        name[0]     = SRVs_COLOR_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case 2:
                        name[0]     = SRVs_TILES_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case 3:
                        name[0]     = SRVs_ANGLE_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_ANGLE;
                        break;
        }
                        
        return	LXe_OK;
}

        LxResult
HTonePFX::pfx_Get (int  id, void *packet,float *val,void *item) 
{
        LXpHalftone	*csp = (LXpHalftone *) packet;

        switch (id) {
                case 0:
                        val[0] = csp->uvOffset;
                        break;
                case 1:
                        val[0] = csp->patColor[0];
                        val[1] = csp->patColor[1];
                        val[2] = csp->patColor[2];
                        break;
                case 2:
                        val[0] = csp->tiles;
                        break;
                case 3:
                        val[0] = csp->angle;
                        break;
        }
        
        return LXe_OK;
}
        LxResult
HTonePFX::pfx_Set (int  id, void *packet,const float *val,void *item) 
{
        LXpHalftone	*csp = (LXpHalftone *) packet;

        switch (id) {
                case 0:
                        csp->uvOffset = val[0];
                        break;
                case 1:
                        csp->patColor[0] = val[0];
                        csp->patColor[1] = val[1];
                        csp->patColor[2] = val[2];
                        break;
                case 2:
                        csp->tiles = val[0];
                        break;
                case 3:
                        csp->angle = val[0];
                        csp->sinA = sin(csp->angle);
                        csp->cosA = cos(csp->angle);
                        break;
        }
        
        return LXe_OK;
}




        void
initialize ()
{
    CLxGenericPolymorph*    srv1 = new CLxPolymorph<HalftoneMaterial>;
    CLxGenericPolymorph*    srv2 = new CLxPolymorph<HalftonePacket>;
    CLxGenericPolymorph*    srv3 = new CLxPolymorph<HTonePFX>;

    srv1->AddInterface (new CLxIfc_CustomMaterial<HalftoneMaterial>);
    srv1->AddInterface (new CLxIfc_StaticDesc<HalftoneMaterial>);
    lx::AddServer (SRVs_HTONE_MATR, srv1);

    srv2->AddInterface (new CLxIfc_VectorPacket<HalftonePacket>);
    srv2->AddInterface (new CLxIfc_StaticDesc<HalftonePacket>);
    lx::AddServer (SRVs_HTONE_VPACKET, srv2);

    srv3->AddInterface (new CLxIfc_PacketEffect<HTonePFX>);
    srv3->AddInterface (new CLxIfc_StaticDesc<HTonePFX>);
    lx::AddServer (SRVs_EDGE_WIDTH_TFX, srv3);

}

                };	// END namespace

