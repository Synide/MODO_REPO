/*
 * Plug-in value textures: procedural Water
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Water texture
 *
 *----------------------------------------------------------------------------*/
class WaterTexture : public CLxImpl_ValueTexture
{
    public:
        WaterTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[10];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector  baseColor;

                float       rippleScale;
                float       rippleLevel;
                float       waveScale;
                float       waveLevel;
                float       waveMin;
                float       ripplesPerWave;
                float       stepSize;
        };
};

LXtTagInfoDesc	 WaterTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterWaterTexture (void)
{
        RegisterTexture<WaterTexture>       ("Water.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
WaterTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
WaterTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("baseColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.47, 0.841, 1.0);
        ac.SetDefaultVec (color);

        ac.NewChannel ("rippleScale",           LXsTYPE_FLOAT);
        ac.SetDefault (1.0, 0);
        ac.SetHint    (hint_floatPos);

        ac.NewChannel ("rippleLevel",           LXsTYPE_FLOAT);
        ac.SetDefault (4.0, 0);
        ac.SetHint    (hint_floatZeroTo24);

        ac.NewChannel ("waveScale",             LXsTYPE_FLOAT);
        ac.SetDefault (1.0, 0);
        ac.SetHint    (hint_floatMinZero);

        ac.NewChannel ("waveLevel",             LXsTYPE_FLOAT);
        ac.SetDefault (2.0, 0);
        ac.SetHint    (hint_floatZeroTo24);

        ac.NewChannel ("waveMin",               LXsTYPE_PERCENT);
        ac.SetDefault (0.5, 0);
        ac.SetHint    (hint_floatZeroToOne);

        ac.NewChannel ("ripplesPerWave",        LXsTYPE_FLOAT);
        ac.SetDefault (10.0, 0);
        ac.SetHint    (hint_floatPos);

        ac.NewChannel ("stepSize",              LXsTYPE_FLOAT);
        ac.SetDefault (2.0, 0);
        ac.SetHint    (hint_floatPos);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
WaterTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "baseColor.R");
        idx[index++] = ev.AddChan (item, "baseColor.G");
        idx[index++] = ev.AddChan (item, "baseColor.B");
        idx[index++] = ev.AddChan (item, "rippleScale");
        idx[index++] = ev.AddChan (item, "rippleLevel");
        idx[index++] = ev.AddChan (item, "waveScale");
        idx[index++] = ev.AddChan (item, "waveLevel");
        idx[index++] = ev.AddChan (item, "waveMin");
        idx[index++] = ev.AddChan (item, "ripplesPerWave");
        idx[index++] = ev.AddChan (item, "stepSize");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
WaterTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->baseColor[0]        = at.Float (idx[index++]);
        rd->baseColor[1]        = at.Float (idx[index++]);
        rd->baseColor[2]        = at.Float (idx[index++]);

        rd->rippleScale         = at.Float (idx[index++]);
        rd->rippleLevel         = at.Float (idx[index++]);
        rd->waveScale           = at.Float (idx[index++]);
        rd->waveLevel           = at.Float (idx[index++]);
        rd->waveMin             = at.Float (idx[index++]);
        rd->ripplesPerWave      = at.Float (idx[index++]);
        rd->stepSize            = at.Float (idx[index++]);

        if (rd->rippleLevel > 24.0f)        // Level of detail cannot exceed 24
            rd->rippleLevel = 24.0f;

        if (rd->waveLevel > 24.0f)
            rd->waveLevel = 24.0f;

        if (rd->ripplesPerWave <= 0.0f)
            rd->ripplesPerWave = 0.001f;

        // set up local values (if any)

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
WaterTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
    LXpTextureInput*    tInp    = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
    RendData*           rd      = (RendData *) data;
    bool                wavey   = 0.0 != rd->waveScale;

    tOut->direct   = 1;             // result should NOT be blended
    tOut->alpha[0] = 1.0;           // texture is opaque

    LXtVector           pos, wavePos;

    LXx_VCPY (pos, tInp->tPos);

    if (wavey)
        {
        double      waveFreq = 1.0 / rd->ripplesPerWave;
        LXx_VSCL3 (wavePos, pos, waveFreq);
        }

    NoiseUtils  noiseUtils;
    double      f = rd->rippleScale * noiseUtils.fBm (pos, 1.0, rd->stepSize, rd->rippleLevel);

    if (wavey)
        f *= rd->waveMin + rd->waveScale * noiseUtils.fBm (wavePos, 0.5, rd->stepSize, rd->waveLevel);

    f = 0.5 + fabs (f);

    if (f > 1.0)
        f = 1.0;

    if (LXi_TFX_COLOR == tInp->context)
        LXx_VSCL3 (tOut->color[0], rd->baseColor, f);
    else
        tOut->value[0] = f + f - 1.0;     // scale to 0-1 for bump, displacement, etc.
}

