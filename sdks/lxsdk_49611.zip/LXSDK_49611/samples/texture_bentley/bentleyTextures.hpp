/*
 * defines for all plug-in textures & geometry
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */
#pragma once

#include <lx_shade.hpp>
#include <lx_vector.hpp>
#include <lx_package.hpp>
#include <lx_action.hpp>
#include <lx_value.hpp>
#include <lx_log.hpp>
#include <lx_channelui.hpp>
#include <lx_item.hpp>
#include <lxcommand.h>
#include <lxidef.h>

#include <math.h>
#include <string>

#ifndef PI
    #define PI             (3.1415926535897932384626433832795)
#endif
#ifndef TWOPI
    #define TWOPI          (6.2831853071795864769252867665590)
#endif
#ifndef HALFPI
    #define HALFPI         (1.5707963267948966192313216916398)
#endif
#ifndef PI_OVER_180
    #define PI_OVER_180    (PI/180.0)
#endif

#define EPSILON		1E-4

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * support functions for noise, turbulence, etc.
 *
 *----------------------------------------------------------------------------*/
class NoiseUtils
    {
    private:
        LXtVector   s_posFrac;          // fractional part of the position values
        double      s_range[3][2];      // bounds of the noise position
        double      s_noiseVals[4];

        double      frand (long s);
        void        interpolate (double* values, int i, int n);

    public:
        void        psdes (unsigned& lWord, unsigned& rWord);
        double*     noise3 (LXtVector newPos);
        double      turbulence (LXtVector pos, double level);
        double      fBm (LXtVector point, double H, double lacunarity, double octaves);
    };

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * hints used to define ranges for GUI items
 *
 *----------------------------------------------------------------------------*/
static LXtTextValueHint hint_intPos[] = {
        1,                  "&min",         // integer min 1
        -1,                 NULL
        };

static LXtTextValueHint hint_floatPos[] = {
            1,              "%min",         // float min 0.0001
        -1,                 NULL
        };

static LXtTextValueHint hint_floatZeroToOne[] = {
            0,              "%min",         // float min 0.0
        10000,              "%max",         // float max 1.0
        -1,                 NULL
        };

static LXtTextValueHint hint_floatMinZero[] = {
            0,              "%min",         // float min 0.0
        -1,                 NULL
        };

static LXtTextValueHint hint_floatZeroTo24[] = {    // for turbulence
            0,              "%min",         // float min  0.0
        240000,             "%max",         // float max 24.0
        -1,                 NULL
        };

/*
 * These are common to ALL procedural textures
 */
#define COMMON_VIRTUAL_FUNCS_AND_DATA    \
        static LXtTagInfoDesc	descInfo[]; \
        CLxUser_PacketService	pkt_service; \
        unsigned		tin_offset; \
        LXtItemType		my_type;    \
        LxResult	vtx_SetupChannels (ILxUnknownID addChan); \
        LxResult	vtx_LinkChannels  (ILxUnknownID eval, ILxUnknownID item); \
        LxResult	vtx_ReadChannels  (ILxUnknownID attr, void **ppvData); \
        void		vtx_Evaluate      (ILxUnknownID vector, LXpTextureOutput *tOut, void *data); \
        void		vtx_Cleanup       (void *data);

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * template for a package plugin to register it's class with the server
 *
 *----------------------------------------------------------------------------*/
        template <class PluginClass> void 
RegisterPackage (char const *serverName)
{
    CLxGenericPolymorph*    srv = new CLxPolymorph<PluginClass>;
    srv->AddInterface (new CLxIfc_Package<PluginClass>);
    srv->AddInterface (new CLxIfc_StaticDesc<PluginClass>);

    lx::AddServer (serverName, srv);
}

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * template for a value plugin to register it's class with the server
 *
 *----------------------------------------------------------------------------*/
        template <class PluginClass> void 
RegisterTexture (char const *serverName)
{
    CLxGenericPolymorph*    srv = new CLxPolymorph<PluginClass>;
    srv->AddInterface (new CLxIfc_ValueTexture<PluginClass>);
    srv->AddInterface (new CLxIfc_StaticDesc<PluginClass>);

    lx::AddServer (serverName, srv);
}

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * template for a value plugin to register it's class with the server
 *
 *----------------------------------------------------------------------------*/
        template <class PluginClass> void 
RegisterTextureWithUI (char const *serverName)
{
    CLxGenericPolymorph*    srv = new CLxPolymorph<PluginClass>;
    srv->AddInterface (new CLxIfc_ValueTexture<PluginClass>);
    srv->AddInterface (new CLxIfc_StaticDesc<PluginClass>);
    srv->AddInterface (new CLxIfc_ChannelUI <PluginClass>);

    lx::AddServer (serverName, srv);
}

#if DEBUG_LOGGING
/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * This class can be to send debug messages to the event log
 *
 *----------------------------------------------------------------------------*/
#include <lxu_log.hpp>
#include <lxlog.h>

class DebugMessageLog : public CLxLuxologyLogMessage
{
    public:
        DebugMessageLog ()             : CLxLuxologyLogMessage ()       { Setup (); }
        DebugMessageLog (char *subSys) : CLxLuxologyLogMessage (subSys) { Setup (); }

        virtual ~DebugMessageLog () {}

        virtual const char*     GetFormat ()    { return "Bentley Textures"; }
  
        void    Error (const char* msg, const char* label = NULL)   { Message (LXe_WARNING, GetFormat (), label, msg); }
        void    Info (const char* msg, const char* label = NULL)    { Message (LXe_INFO,    GetFormat (), label, msg); }
};

#endif

