/*
 * Plug-in value textures: procedural Fog
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Fog texture
 *
 *----------------------------------------------------------------------------*/
class FogTexture : public CLxImpl_ValueTexture
{
    public:
        FogTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[11];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector  baseColor;

                float       level;
                float       driftSpeed;
                float       swirlSpeed;
                float       minOpacity;
                float       maxOpacity;
                float       opaque;
                float       power;
                float       animTime;

                // derived values:
        };
};

LXtTagInfoDesc	 FogTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterFogTexture (void)
{
        RegisterTexture<FogTexture>         ("Fog.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
FogTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
FogTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("baseColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 1.0, 0.9, 0.8);
        ac.SetDefaultVec (color);

        ac.NewChannel ("level",                 LXsTYPE_FLOAT);
        ac.SetDefault (3.0, 0);
        ac.SetHint    (hint_floatZeroTo24);

        ac.NewChannel ("driftSpeed",            LXsTYPE_FLOAT);
        ac.SetDefault (0.3, 0);
        ac.SetHint    (hint_floatMinZero);

        ac.NewChannel ("swirlSpeed",            LXsTYPE_FLOAT);
        ac.SetDefault (90.0, 0);
        ac.SetHint    (hint_floatMinZero);


        ac.NewChannel ("minOpacity",            LXsTYPE_PERCENT);
        ac.SetDefault (0.1, 0);
        ac.SetHint    (hint_floatZeroToOne);

        ac.NewChannel ("maxOpacity",            LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);
        ac.SetHint    (hint_floatZeroToOne);

        ac.NewChannel ("opaque",                LXsTYPE_FLOAT);
        ac.SetDefault (1.0, 0);
        ac.SetHint    (hint_floatMinZero);

        ac.NewChannel ("power",                 LXsTYPE_FLOAT);
        ac.SetDefault (1.0, 0);
        ac.SetHint    (hint_floatMinZero);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
FogTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "baseColor.R");
        idx[index++] = ev.AddChan (item, "baseColor.G");
        idx[index++] = ev.AddChan (item, "baseColor.B");
        idx[index++] = ev.AddChan (item, "level");
        idx[index++] = ev.AddChan (item, "driftSpeed");
        idx[index++] = ev.AddChan (item, "swirlSpeed");
        idx[index++] = ev.AddChan (item, "minOpacity");
        idx[index++] = ev.AddChan (item, "maxOpacity");
        idx[index++] = ev.AddChan (item, "opaque");
        idx[index++] = ev.AddChan (item, "power");

        ev.ReadTime (&idx[index++]);

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
FogTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->baseColor[0]        = at.Float (idx[index++]);
        rd->baseColor[1]        = at.Float (idx[index++]);
        rd->baseColor[2]        = at.Float (idx[index++]);

        rd->level               = at.Float (idx[index++]);
        rd->driftSpeed          = at.Float (idx[index++]);
        rd->swirlSpeed          = at.Float (idx[index++]);
        rd->minOpacity          = at.Float (idx[index++]);
        rd->maxOpacity          = at.Float (idx[index++]);
        rd->opaque              = at.Float (idx[index++]);
        rd->power               = at.Float (idx[index++]);

        rd->animTime            = at.Float (idx[index++]);

        if (rd->level > 24.0f)        // Level of detail cannot exceed 24
            rd->level = 24.0f;

        if (rd->opaque < 0.0f)
            rd->opaque = 0.0f;

        if (rd->power < 0.0f)
            rd->power = 0.0f;

        // set up local values (if any)

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Compute the intensity (in a given color channel) for a point within
 * the fog based on its position.                                   
 *
 *----------------------------------------------------------------------------*/
        static double
fogColor (
        LXtVector       p,
        double          oneOverWidth,
        float           oneOverHeight,
        double          colorComponent,
        double          maxColor)
{
    if (colorComponent <= 0.0)
        return 0.0;

    double      scale   = maxColor / colorComponent;
    double      x       = scale * fabs (p[0] * oneOverWidth);
    double      y       = scale * p[1] * oneOverHeight;
    double      d       = x * x + y * y;

    d = d < 1.0 ? 1.0 - d : 0.0;

    return d * d;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
FogTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
    LXpTextureInput*    tInp    = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
    RendData*           rd      = (RendData *) data;
    LXtVector           pos     = { tInp->tPos[0], tInp->tPos[1], tInp->tPos[2] };

    tOut->direct   = 1;             // result should NOT be blended

    /* Compute turbulence value (between 0 and 1) */
    NoiseUtils  noiseUtils;
    double      tmp = fabs (noiseUtils.turbulence (pos, rd->level));

    /* Apply some turbulence to the point so that it appears more random */
    pos[0] = pos[0] + 2.0 + tmp;
    pos[1] = pos[1] + 0.5 + tmp;
    pos[2] = pos[2] - 2.0 - tmp;

    /* For animation, determine how to move the point through the space (helical path) */
    double      theta = rd->animTime * rd->swirlSpeed * PI_OVER_180; 

    LXtVector               direction;
    static double const     s_ellipse1 = 0.10;
    static double const     s_ellipse2 = 0.14;
    double                  cyl[2] =  { s_ellipse1 * cos (theta), s_ellipse2 * sin (theta) };

    direction[0] = pos[0] - rd->animTime * rd->driftSpeed;
    direction[1] = pos[1] + cyl[0]; 
    direction[2] = pos[2] + cyl[1];

    /* Now determine the point's transparency based on its new location in the solid space */ 
    double      alpha   = fabs (noiseUtils.turbulence (direction, rd->level));
    double      density = alpha * rd->opaque;

    density = pow (density, (double)rd->power);
    if (density > 1.0f)
        density = 1.0f;

    /* Scale to min,max range specified by the user */
    density = density * (rd->maxOpacity - rd->minOpacity) + rd->minOpacity;

    if (LXi_TFX_COLOR == tInp->context)
        {
        LXx_VSCL3 (tOut->color[0], rd->baseColor, density);
        tOut->alpha[0] = density;
        }
    else
        tOut->value[0] = density;           // set for bump, displacement, etc.
}

