/*
 * Utiity functions for Bentley procedurals
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Numerical Recipes in C -------------- 12/09
 * 
 * INPUT PARAMETERS:
 *
 *      lWord and rword: a 64-bit word to be hashed
 *
 * RETURN VALUES:
 *
 *      lWord and rWord are both hashed on all bits.
 *
 * DESCRIPTION:
 *
 *      "Pseudo-DES hashing of the 64-bit word (lWord,rWord). Both
 *      32-bit arguments returned hashed on all bits.
 *
 *      This function is taken as is from "Numerical Recipes in C",
 *      2nd edition, pages 302 and 303.
 *      Number of iterations can be reduced to 2 to improve
 *      performance.
 * 
 *----------------------------------------------------------------------------*/
        void 
NoiseUtils::psdes (unsigned& lWord, unsigned& rWord)
{
    static unsigned long const  c1[] = {0xbaa96887L, 0x1e17d32cL, 0x03bcdc3cL, 0x0f33d1b2L};
    static unsigned long const  c2[] = {0x4b0f3b58L, 0xe874f0c3L, 0x6955c5a6L, 0x55a7ca46L};

    static int const    s_nIterations = 4;

    for (int i = 0; i < s_nIterations; i++)
        {
        unsigned    iswap   = rWord;
        unsigned    ia      = iswap ^ c1[i];
        unsigned    itmpl   = ia & 0xffff;
        unsigned    itmph   = ia >> 16;
        unsigned    ib      = itmpl * itmpl + ~(itmph * itmph);

        rWord = (lWord) ^ (((ia = (ib >> 16) | ((ib & 0xffff) << 16)) ^ c2[i]) + itmpl * itmph);
        lWord = iswap;
        }
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * get random number from seed
 *
 *----------------------------------------------------------------------------*/
        double
NoiseUtils::frand (long s)
{
    s = s<<13 ^ s;
    return(1.0-((s*(s*s*15731+789221)+1376312589)&0x7fffffff)/1073741824.0);
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * interpolation for noise values
 *
 *----------------------------------------------------------------------------*/
    void 
NoiseUtils::interpolate (double* values, int i, int n)
{
    if (n == 0)
        {
        #define  rand3a(x,y,z)  frand ( 67 * (x) +  59 * (y) +  71 * (z))
        #define  rand3b(x,y,z)  frand ( 73 * (x) +  79 * (y) +  83 * (z))
        #define  rand3c(x,y,z)  frand ( 89 * (x) +  97 * (y) + 101 * (z))
        #define  rand3d(x,y,z)  frand (103 * (x) + 107 * (y) + 109 * (z))

        values[0] = rand3a (s_range[0][i & 1], s_range[1][i >> 1 & 1], s_range[2][i >> 2]);
        values[1] = rand3b (s_range[0][i & 1], s_range[1][i >> 1 & 1], s_range[2][i >> 2]);
        values[2] = rand3c (s_range[0][i & 1], s_range[1][i >> 1 & 1], s_range[2][i >> 2]);
        values[3] = rand3d (s_range[0][i & 1], s_range[1][i >> 1 & 1], s_range[2][i >> 2]);
        }
    else
        {
        // hermite interpolations:

        #define  hpoly1(t)      ((2.0*t-3.0)*t*t+1.0)
        #define  hpoly2(t)      (-2.0*t+3.0)*t*t
        #define  hpoly3(t)      ((t-2.0)*t+1.0)*t
        #define  hpoly4(t)      (t-1.0)*t*t

        double  f0[4], f1[4];

        interpolate (f0,          i, --n);
        interpolate (f1, i | 1 << n,   n);

        double  hp1 = hpoly1 (s_posFrac[n]);
        double  hp2 = hpoly2 (s_posFrac[n]);

        values[0] = f0[0] * hp1 + f1[0] * hp2;
        values[1] = f0[1] * hp1 + f1[1] * hp2;
        values[2] = f0[2] * hp1 + f1[2] * hp2;
        values[3] = f0[3] * hp1 + f1[3] * hp2 + f0[n] * hpoly3 (s_posFrac[n]) + f1[n] * hpoly4 (s_posFrac[n]);
        }
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * 3D noise function
 *
 * Credit for the smooth algorithm goes to Ken Perlin.
 * (ref. SIGGRAPH Vol 19, No 3, pp 287-96)
 *
 *----------------------------------------------------------------------------*/
        double* 
NoiseUtils::noise3 (LXtVector pos)
{
    static double const     s_latticeSize           = 1.0e9;        // the size of the noise lattice
    static double const     s_latticeSizeInverse    = 1.0e-9;
    static double const     s_latticeSizeHalf       = 0.5e9;
    static long const       s_L_latticeSizeHalf     = (long)s_latticeSizeHalf;

    LXtVector               posMin;

    // Determine the limits of the lattice cell in which the sample resides

    posMin[0]   = floor (pos[0]);
    posMin[1]   = floor (pos[1]);
    posMin[2]   = floor (pos[2]);

    LXx_VSUB3 (s_posFrac, pos, posMin);

    // If the sample is outside the lattice cube, translate it so that it is inside the lattice

    if (posMin[0] > s_latticeSizeHalf || posMin[0] < -s_latticeSizeHalf)
        posMin[0] -= floor (posMin[0] * s_latticeSizeInverse + 0.5) * s_latticeSize;
    if (posMin[1] > s_latticeSizeHalf || posMin[1] < -s_latticeSizeHalf)
        posMin[1] -= floor (posMin[1] * s_latticeSizeInverse + 0.5) * s_latticeSize;
    if (posMin[2] > s_latticeSizeHalf || posMin[2] < -s_latticeSizeHalf)
        posMin[2] -= floor (posMin[2] * s_latticeSizeInverse + 0.5) * s_latticeSize;

    /* If the sample is on the max edge of the lattice, move it to the min edge
       so that the lattice cell will wrap around and avoid a discontinuity */

    if (s_L_latticeSizeHalf == (s_range[0][0] = (long)posMin[0]))
        s_range[0][1] = -s_L_latticeSizeHalf;
    else
        s_range[0][1] = s_range[0][0] + 1;

    if (s_L_latticeSizeHalf == (s_range[1][0] = (long)posMin[1]))
        s_range[1][1] = -s_L_latticeSizeHalf;
    else
        s_range[1][1] = s_range[1][0] + 1;

    if (s_L_latticeSizeHalf == (s_range[2][0] = (long)posMin[2]))
        s_range[2][1] = -s_L_latticeSizeHalf;
    else
        s_range[2][1] = s_range[2][0] + 1;

    interpolate (s_noiseVals, 0, 3);
    return s_noiseVals;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * perturb value using noise
 *
 *----------------------------------------------------------------------------*/
        double
NoiseUtils::turbulence (LXtVector pos, double level)
{
    double          t = 0.0, scale = 1.0;
    long            longLevel = (long)level;
    LXtVector       posScaled;

    LXx_VCPY (posScaled, pos);

    for (int l = 0; l < longLevel; l++)
        {
        double*     noise = noise3 (posScaled);

        t     += scale * noise[0];
        scale *= 0.5;

        LXx_VADD (posScaled, posScaled);
        }

    // Add in fractional level if specified

    double      weight = level - longLevel;
    if (0.0 != weight)
        {
        double*     noise = noise3 (posScaled);

        t += weight * scale * noise[0];
        }

    return t;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * fractal noise
 *
 * Procedural fBm evaluated at "point"; returns value stored in "value".
 *
 * Copyright 1994 F. Kenton Musgrave 
 *
 * "This code may be used freely to modify or create programs that are
 *  for personal use or commercial distribution."
 *
 * Parameters:
 *    H:            the fractal increment parameter
 *    lacunarity:   the gap between successive frequencies
 *    octaves:      the number of frequencies in the fBm
 *
 *----------------------------------------------------------------------------*/
        double
NoiseUtils::fBm (LXtVector point, double H, double lacunarity, double octaves)
{
    static bool       first = true;
    static double     exponentArray[24];

    if (first)        // precompute and store spectral weights
        {
        /* Build exponent array */
        double      frequency = 1.0;

        for (int i = 0; i <= octaves; i++)          // compute weight for each frequency
            {
            exponentArray[i]  = pow (frequency, -H);
            frequency         *= lacunarity;
            }

        first = false;
        }

    double          value = 0.0;
    LXtVector       localPoint;
    int             octave;

    LXx_VCPY (localPoint, point);                   // Make a local copy of the point value (to modify)

    for (octave = 0; octave < octaves; octave++)    // inner loop of spectral construction */
        {
        double*     noise = noise3 (localPoint);

        value += noise[0] * exponentArray[octave];

        LXx_VSCL (localPoint, lacunarity);
        }

    double      remainder = octaves - (int)octaves;

    if (0.0 != remainder)                           // add in "octaves" remainder
        {
        double*     noise = noise3 (localPoint);

        value += remainder * noise[0] * exponentArray[octave];
        }

    return value;
}

