/*
 * Plug-in value textures: procedural marble
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * 3d procedural marble
 *
 *----------------------------------------------------------------------------*/
class MarbleTexture : public CLxImpl_ValueTexture
{
    public:
        MarbleTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[8];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector	baseColor;
                LXtFVector	veinColor;
                float           level;
                float           noisiness;
        };
};

LXtTagInfoDesc	 MarbleTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterMarbleTexture (void)
{
        RegisterTexture<MarbleTexture>      ("Marble.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
MarbleTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
MarbleTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("baseColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefault (1.0, 0);

        ac.NewChannel ("veinColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.2, 0.1, 0.1);
        ac.SetDefaultVec (color);

        ac.NewChannel ("level",                 LXsTYPE_FLOAT);
        ac.SetDefault (2.0, 0);
        ac.SetHint    (hint_floatZeroTo24);
        ac.NewChannel ("noisiness",             LXsTYPE_PERCENT);
        ac.SetDefault (0.707, 0);
        ac.SetHint    (hint_floatZeroToOne);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
MarbleTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "baseColor.R");
        idx[index++] = ev.AddChan (item, "baseColor.G");
        idx[index++] = ev.AddChan (item, "baseColor.B");
        idx[index++] = ev.AddChan (item, "veinColor.R");
        idx[index++] = ev.AddChan (item, "veinColor.G");
        idx[index++] = ev.AddChan (item, "veinColor.B");
        idx[index++] = ev.AddChan (item, "level");
        idx[index++] = ev.AddChan (item, "noisiness");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
MarbleTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->baseColor[0]        = at.Float (idx[index++]);
        rd->baseColor[1]        = at.Float (idx[index++]);
        rd->baseColor[2]        = at.Float (idx[index++]);

        rd->veinColor[0]        = at.Float (idx[index++]);
        rd->veinColor[1]        = at.Float (idx[index++]);
        rd->veinColor[2]        = at.Float (idx[index++]);

        rd->level               = at.Float (idx[index++]);
        rd->noisiness           = at.Float (idx[index++]);

        if (rd->level > 24.0f)          // Level of detail cannot exceed 24
            rd->level = 24.0f;

        // set up local values (if any)

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
MarbleTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
        LXpTextureInput*    tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
        RendData*           rd = (RendData *) data;
        LXtVector           pos;

        tOut->direct   = 1;             // result should NOT be blended
        tOut->alpha[0] = 1.0;           // texture is opaque

        LXx_VCPY (pos, tInp->tPos);

        NoiseUtils  noiseUtils;
        double      noise   = pos[1] + noiseUtils.turbulence (pos, rd->level);
        noise               = sin (PI * noise);
        noise               = sqrt (noise + 1.0) * rd->noisiness;
        noise               = sqrt (noise);
        double  invNoise    = 1.0 - noise;

        if (LXi_TFX_COLOR == tInp->context)
            {
            LXx_VSCL3 (tOut->color[0], rd->baseColor, noise);
            LXx_VADDS (tOut->color[0], rd->veinColor, invNoise);
            }
        else
            tOut->value[0] = invNoise;
}

