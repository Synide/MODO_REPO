/*
 * Plug-in value textures: procedural sand
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Sand texture
 *
 *----------------------------------------------------------------------------*/
class SandTexture : public CLxImpl_ValueTexture
{
    public:
        SandTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[7];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector      sandColor;
                LXtFVector      contrastColor;

                float           fraction;
        };
};

LXtTagInfoDesc	 SandTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterSandTexture (void)
{
        RegisterTexture<SandTexture>        ("Sand.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
SandTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
SandTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("sandColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.96, 0.89, 0.76);
        ac.SetDefaultVec (color);

        ac.NewChannel ("contrastColor",         LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.84, 0.80, 0.63);
        ac.SetDefaultVec (color);

        ac.NewChannel ("fraction",              LXsTYPE_PERCENT);
        ac.SetDefault (0.1, 0);
        ac.SetHint    (hint_floatZeroToOne);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
SandTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "sandColor.R");
        idx[index++] = ev.AddChan (item, "sandColor.G");
        idx[index++] = ev.AddChan (item, "sandColor.B");
        idx[index++] = ev.AddChan (item, "contrastColor.R");
        idx[index++] = ev.AddChan (item, "contrastColor.G");
        idx[index++] = ev.AddChan (item, "contrastColor.B");
        idx[index++] = ev.AddChan (item, "fraction");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
SandTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->sandColor[0]        = at.Float (idx[index++]);
        rd->sandColor[1]        = at.Float (idx[index++]);
        rd->sandColor[2]        = at.Float (idx[index++]);

        rd->contrastColor[0]    = at.Float (idx[index++]);
        rd->contrastColor[1]    = at.Float (idx[index++]);
        rd->contrastColor[2]    = at.Float (idx[index++]);

        rd->fraction            = at.Float (idx[index++]);

        // set up local values (if any)

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
SandTexture::vtx_Evaluate (
        ILxUnknownID            vector,
        LXpTextureOutput        *tOut,
        void                    *data)
{
        LXpTextureInput*    tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
        RendData*           rd   = (RendData *) data;

        tOut->direct   = 1;             // result should NOT be blended
        tOut->alpha[0] = 1.0;           // texture is opaque

        static float const      s_internalScale = 50.0f;
        LXtVector               pos;

        LXx_VSCL3 (pos, tInp->tPos, s_internalScale);

        NoiseUtils      noiseUtils;
        double*         dnoise = noiseUtils.noise3 (pos);
        double          noise  = fabs (dnoise[0]);

        if (LXi_TFX_COLOR == tInp->context)
            if (noise < rd->fraction)
                LXx_VCPY (tOut->color[0], rd->sandColor);
            else
                LXx_VCPY (tOut->color[0], rd->contrastColor);
        else
            tOut->value[0] = noise;
}

