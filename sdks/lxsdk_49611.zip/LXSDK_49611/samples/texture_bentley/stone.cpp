/*
 * Plug-in value textures: procedural stone
 *
 * stone texture (from SIGGRAPH '96 paper by Steven Worley)
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

#include <lxu_log.hpp>
#include <lxlog.h>
#include <lxu_math.hpp>

static void initTables ();

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Stone texture
 *
 *----------------------------------------------------------------------------*/
class StoneTexture : public CLxImpl_ValueTexture
{
    public:
        StoneTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[10];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector      tintColor;
                LXtFVector      mortarColor;

                long            colors;
                long            colorTableOffset;
                float           mortarThickness;
                float           noisiness;
        };
};

LXtTagInfoDesc	 StoneTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterStoneTexture (void)
{
        RegisterTexture<StoneTexture>       ("Stone.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
StoneTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
StoneTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        static LXtTextValueHint hint_int1to32[] = {
                 1,                 "&min",
                32,                 "&max",
                -1,                 NULL
                };

        static LXtTextValueHint hint_int1to31[] = {
                 1,                 "&min",
                31,                 "&max",
                -1,                 NULL
                };

        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel ("tintColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefault (0.75, 0);

        ac.NewChannel ("mortarColor",           LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefault (0.9, 0);

        ac.NewChannel ("colors",                LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 6);
        ac.SetHint    (hint_int1to32);
        ac.NewChannel ("colorTableOffset",      LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 0);
        ac.SetHint    (hint_int1to31);

        ac.NewChannel ("mortarThickness",       LXsTYPE_PERCENT);
        ac.SetDefault (0.1, 0);
        ac.SetHint    (hint_floatZeroToOne);
        ac.NewChannel ("noisiness",             LXsTYPE_PERCENT);
        ac.SetDefault (0.3, 0);
        ac.SetHint    (hint_floatMinZero);

        initTables ();

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
StoneTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "tintColor.R");
        idx[index++] = ev.AddChan (item, "tintColor.G");
        idx[index++] = ev.AddChan (item, "tintColor.B");
        idx[index++] = ev.AddChan (item, "mortarColor.R");
        idx[index++] = ev.AddChan (item, "mortarColor.G");
        idx[index++] = ev.AddChan (item, "mortarColor.B");
        idx[index++] = ev.AddChan (item, "colors");
        idx[index++] = ev.AddChan (item, "colorTableOffset");
        idx[index++] = ev.AddChan (item, "mortarThickness");
        idx[index++] = ev.AddChan (item, "noisiness");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
StoneTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->tintColor[0]        = at.Float (idx[index++]);
        rd->tintColor[1]        = at.Float (idx[index++]);
        rd->tintColor[2]        = at.Float (idx[index++]);

        rd->mortarColor[0]      = at.Float (idx[index++]);
        rd->mortarColor[1]      = at.Float (idx[index++]);
        rd->mortarColor[2]      = at.Float (idx[index++]);

        rd->colors              = at.Int   (idx[index++]);
        rd->colorTableOffset    = at.Int   (idx[index++]);

        rd->mortarThickness     = at.Float (idx[index++]);
        rd->noisiness           = at.Float (idx[index++]);

        // set up local values (if any)
        if (rd->colors > 32)
            rd->colors = 32;                // Stone color table is limited to 32 entries
        else if (rd->colors < 0)
            rd->colors = 0;

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * local defines & data for procedure
 *
 *----------------------------------------------------------------------------*/
typedef struct 
    {
    LXtVector   delta;          // Relative position of a neighboring cube
    double      distSqr;        // Minimum distance squared to that cube
    } Neighbor;

static double const     lambda = 3.0;               // Poisson distribution mean density
static double           probabilityTable[10];       // Cell point probablity table
static short            permutationTable[512];      // Pseudo-random permutation table
static bool             tablesInitialized = false;

static double const     s_randScale = 1.0 / (double)0x01000000;
static double const     s_infinity  = 1e38;

/* The stone color table */
static LXtFVector       colorTable[32] =
    {
        { 0.941f, 0.502f, 0.502f, },        // light coral
        { 1.000f, 0.498f, 0.314f, },        // coral
        { 1.000f, 0.627f, 0.478f, },        // light salmon
        { 0.914f, 0.588f, 0.478f, },        // dark salmon
        { 1.000f, 0.922f, 0.804f, },        // blanched almond
        { 0.980f, 0.502f, 0.447f, },        // salmon
        { 1.000f, 0.714f, 0.757f, },        // light pink
        { 0.737f, 0.561f, 0.561f, },        // rosy brown
        { 1.000f, 0.894f, 0.882f, },        // misty rose
        { 0.980f, 0.922f, 0.843f, },        // antique white
        { 0.804f, 0.522f, 0.247f, },        // peru
        { 1.000f, 0.973f, 0.863f, },        // cornsilk
        { 0.961f, 0.871f, 0.702f, },        // wheat
        { 1.000f, 0.937f, 0.835f, },        // papaya whip
        { 0.933f, 0.867f, 0.510f, },        // light goldenrod
        { 0.933f, 0.910f, 0.667f, },        // pale goldenrod
        { 1.000f, 0.871f, 0.678f, },        // navajo white
        { 0.961f, 0.961f, 0.863f, },        // beige
        { 0.741f, 0.718f, 0.420f, },        // dark khaki
        { 0.627f, 0.322f, 0.176f, },        // sienna
        { 0.871f, 0.498f, 0.314f, },        // burlywood
        { 1.000f, 0.961f, 0.933f, },        // seashell
        { 1.000f, 0.894f, 0.769f, },        // bisque
        { 1.000f, 0.894f, 0.710f, },        // moccasin
        { 0.647f, 0.165f, 0.165f, },        // brown
        { 1.000f, 0.855f, 0.725f, },        // peach puff
        { 0.698f, 0.133f, 0.133f, },        // firebrick
        { 0.957f, 0.643f, 0.376f, },        // sandy brown
        { 0.439f, 0.502f, 0.565f, },        // slate grey
        { 1.000f, 1.000f, 0.941f, },        // ivory
        { 0.824f, 0.706f, 0.549f, },        // tan
        { 0.941f, 0.902f, 0.549f, },        // khaki
    };

#define int255(a)       ((int)floor(a) & 255)
#define ranqd1(a)       a = 1664525L * a + 1013904223L      // Linear congruential random generator
#define random_float(a) ((a & 0x00ffffff) * s_randScale)

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * initialize the probablility & permutatioin tables
 *
 *----------------------------------------------------------------------------*/
static void initTables ()
{
    if (tablesInitialized)
        return;

    /******************************************/
    /* Build the cell point probability table */
    /******************************************/
    double      exponential = exp (lambda);     // set exponential constant
    double      factorial   = 1.0;              // initialize factorial function
    double      power       = 1.0;              // initial power function
    double      probability = 0.0;              // zero cumulative probability

    for (int i = 0; i < 9; i++)
        {
        if (i > 0)
            {
            factorial *= i;
            power     /= lambda;
            }

        probability         += 1.0 / (power * exponential * factorial);
        probabilityTable[i]  = probability;
        }

    /* Clamp probabilities to the range of 1 to 9 points */
    probabilityTable[9]  = 1.0;                     /* No more than 9 points */
    probabilityTable[1] += probabilityTable[0];     /* No less than one point */
    probabilityTable[0]  = 0.0;

    /********************************************/
    /* Build the pseudorandom permutation table */
    /********************************************/
    for (int i = 0; i < 256; i++)
        permutationTable[i] = i;

    long        random = -4122;         /* Use negative value to seed random number generator */

    for (int i = 0; i < 256 ; i++)
        {
        int         j       = (int)(random_float (ranqd1 (random)) * 256.0);    // Get a random table index value
        short       temp    = permutationTable[i];                              // Exchange table elements i and j

        permutationTable[i] = permutationTable[j];
        permutationTable[j] = temp;
        }

    /* Replicate the table (for faster indexing later) */
    for (int i = 0, j = 256; i < 256; i++, j++)
        permutationTable[j] = permutationTable[i];

    tablesInitialized = true;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * build a table of all neighbors within the distance sqaured: distSqrMax
 * return the count: n
 *
 *----------------------------------------------------------------------------*/
    static void 
buildNeighborTable (Neighbor* neighbor, LXtVector fracPos, double distSqrMax, int& n)
{
    /* Compute fractional squared distances */
    double      fx0     = fracPos[0] * fracPos[0];
    double      fy0     = fracPos[1] * fracPos[1];
    double      fz0     = fracPos[2] * fracPos[2];
    double      fx1     = (1.0 - fracPos[0]) * (1.0 - fracPos[0]);
    double      fy1     = (1.0 - fracPos[1]) * (1.0 - fracPos[1]);
    double      fz1     = (1.0 - fracPos[2]) * (1.0 - fracPos[2]);
    double      fx0y0   = fx0 + fy0;
    double      fx0y1   = fx0 + fy1;
    double      fx0z0   = fx0 + fz0;
    double      fx0z1   = fx0 + fz1;
    double      fy0z0   = fy0 + fz0;
    double      fy0z1   = fy0 + fz1;
    double      fx1y0   = fx1 + fy0;
    double      fx1y1   = fx1 + fy1;
    double      fx1z0   = fx1 + fz0;
    double      fx1z1   = fx1 + fz1;
    double      fy1z0   = fy1 + fz0;
    double      fy1z1   = fy1 + fz1;
    double      fx0y0z0 = fx0y0 + fz0;
    double      fx0y0z1 = fx0y0 + fz1;
    double      fx0y1z0 = fx0y1 + fz0;
    double      fx0y1z1 = fx0y1 + fz1;
    double      fx1y0z0 = fx1y0 + fz0;
    double      fx1y0z1 = fx1y0 + fz1;
    double      fx1y1z0 = fx1y1 + fz0;
    double      fx1y1z1 = fx1y1 + fz1;

    n = 0;
    if (fx0 < distSqrMax)
        {
        neighbor->distSqr = (float) fx0;
        LXx_V3SET (neighbor->delta, -1.0,  0.0,  0.0);
        neighbor++; n++;

        if (fx0y0 < distSqrMax)
            {
            neighbor->distSqr = (float) fx0y0;
            LXx_V3SET (neighbor->delta, -1.0, -1.0,  0.0);
            neighbor++; n++;

            if (fx0y0z0 < distSqrMax)
                {
                neighbor->distSqr = (float) fx0y0z0;
                LXx_V3SET (neighbor->delta, -1.0, -1.0, -1.0);
                neighbor++; n++;
                }

            if (fx0y0z1 < distSqrMax)
                {
                neighbor->distSqr = (float) fx0y0z1;
                LXx_V3SET (neighbor->delta, -1.0, -1.0,  1.0);
                neighbor++; n++;
                }
            }

        if (fx0y1 < distSqrMax)
            {
            neighbor->distSqr = (float) fx0y1;
            LXx_V3SET (neighbor->delta, -1.0,  1.0,  0.0);
            neighbor++; n++;

            if (fx0y1z0 < distSqrMax)
                {
                neighbor->distSqr = (float) fx0y1z0;
                LXx_V3SET (neighbor->delta, -1.0,  1.0, -1.0);
                neighbor++; n++;
                }

            if (fx0y1z1 < distSqrMax)
                {
                neighbor->distSqr = (float) fx0y1z1;
                LXx_V3SET (neighbor->delta, -1.0,  1.0,  1.0);
                neighbor++; n++;
                }
            }

        if (fx0z0 < distSqrMax)
            {
            neighbor->distSqr = (float) fx0z0;
            LXx_V3SET (neighbor->delta, -1.0,  0.0, -1.0);
            neighbor++; n++;
            }

        if (fx0z1 < distSqrMax)
            {
            neighbor->distSqr = (float) fx0z1;
            LXx_V3SET (neighbor->delta, -1.0,  0.0,  1.0);
            neighbor++; n++;
            }
        }

    if (fx1 < distSqrMax)
        {
        neighbor->distSqr = (float) fx1;
        LXx_V3SET (neighbor->delta,  1.0,  0.0,  0.0);
        neighbor++; n++;

        if (fx1y0 < distSqrMax)
            {
            neighbor->distSqr = (float) fx1y0;
            LXx_V3SET (neighbor->delta,  1.0, -1.0,  0.0);
            neighbor++; n++;

            if (fx1y0z0 < distSqrMax)
                {
                neighbor->distSqr = (float) fx1y0z0;
                LXx_V3SET (neighbor->delta,  1.0, -1.0, -1.0);
                neighbor++; n++;
                }

            if (fx1y0z1 < distSqrMax)
                {
                neighbor->distSqr = (float) fx1y0z1;
                LXx_V3SET (neighbor->delta,  1.0, -1.0,  1.0);
                neighbor++; n++;
                }
            }

        if (fx1y1 < distSqrMax)
            {
            neighbor->distSqr = (float) fx1y1;
            LXx_V3SET (neighbor->delta,  1.0,  1.0,  0.0);
            neighbor++; n++;

            if (fx1y1z0 < distSqrMax)
                {
                neighbor->distSqr = (float) fx1y1z0;
                LXx_V3SET (neighbor->delta,  1.0,  1.0, -1.0);
                neighbor++; n++;
                }

            if (fx1y1z1 < distSqrMax)
                {
                neighbor->distSqr = (float) fx1y1z1;
                LXx_V3SET (neighbor->delta,  1.0,  1.0,  1.0);
                neighbor++; n++;
                }
            }

        if (fx1z0 < distSqrMax)
            {
            neighbor->distSqr = (float) fx1z0;
            LXx_V3SET (neighbor->delta,  1.0,  0.0, -1.0);
            neighbor++; n++;
            }

        if (fx1z1 < distSqrMax)
            {
            neighbor->distSqr = (float) fx1z1;
            LXx_V3SET (neighbor->delta,  1.0,  0.0,  1.0);
            neighbor++; n++;
            }
        }

    if (fy0 < distSqrMax)
        {
        neighbor->distSqr = (float) fy0;
        LXx_V3SET (neighbor->delta,  0.0, -1.0,  0.0);
        neighbor++; n++;

        if (fy0z0 < distSqrMax)
            {
            neighbor->distSqr = (float) fy0z0;
            LXx_V3SET (neighbor->delta,  0.0, -1.0, -1.0);
            neighbor++; n++;
            }

        if (fy0z1 < distSqrMax)
            {
            neighbor->distSqr = (float) fy0z1;
            LXx_V3SET (neighbor->delta,  0.0, -1.0,  1.0);
            neighbor++; n++;
            }
        }

    if (fy1 < distSqrMax)
        {
        neighbor->distSqr = (float) fy1;
        LXx_V3SET (neighbor->delta,  0.0,  1.0,  0.0);
        neighbor++; n++;

        if (fy1z0 < distSqrMax)
            {
            neighbor->distSqr = (float) fy1z0;
            LXx_V3SET (neighbor->delta,  0.0,  1.0, -1.0);
            neighbor++; n++;
            }

        if (fy1z1 < distSqrMax)
            {
            neighbor->distSqr = (float) fy1z1;
            LXx_V3SET (neighbor->delta,  0.0,  1.0,  1.0);
            neighbor++; n++;
            }
        }

    if (fz0 < distSqrMax)
        {
        neighbor->distSqr = (float) fz0;
        LXx_V3SET (neighbor->delta,  0.0,  0.0, -1.0);
        neighbor++; n++;
        }

    if (fz1 < distSqrMax)
        {
        neighbor->distSqr = (float) fz1;
        LXx_V3SET (neighbor->delta,  0.0,  0.0,  1.0);
        neighbor++; n++;
        }
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Convert this coordinate into a pseudo-random integer value to choose a cube
 *
 *----------------------------------------------------------------------------*/
    static void 
chooseFeatureLocation (LXtVector cubePos, LXtVector offsetPos, int& p1, double& distSqrNear, double& distSqrNear2)
{
    int         cube;

    cube = permutationTable[       int255 (cubePos[0])];
    cube = permutationTable[cube + int255 (cubePos[1])];
    cube = permutationTable[cube + int255 (cubePos[2])];

    /*
     * Determine how many points are in this cube (range is fixed at 1 to 9)
     * (A binary search of the probability table is used to compute this)
     */

    long        seed    = -cube;       // Use negative cube id as the random number seed
    double      random  = random_float (ranqd1 (seed));
    int         low     = 0, high = 9, i = 5, increment = 2;

    do  {               // Perform a binary search
        if (random < probabilityTable[i])
            {
            high = i;
            i -= increment;
            }
        else
            {
            low = i;
            i += increment;
            }

        if (increment > 1)
            increment >>= 1;    // Cut increment in half
        }
    while (high - low > 1);

    int         points  = high;
    int         c       = 10 * cube;

    /*
     * Determine the location of the each feature point
     * Keep track of the distance squared from the texture coordinate to the two closest points
     */

    for (int i = 0; i < points; i++)
        {
        LXtVector       point, dist;
        int             p = c + i;

        point[0] = random_float (ranqd1 (seed));
        point[1] = random_float (ranqd1 (seed));
        point[2] = random_float (ranqd1 (seed));

        LXx_VSUB3 (dist, offsetPos, point);
        double      distSqr = LXx_VDOT (dist, dist);

        if (distSqr < distSqrNear)              // This point is the closest so far
            {
            distSqrNear2 = distSqrNear;         // Keep track of second closest point
            distSqrNear  = distSqr;             // Keep track of closest point
            p1           = p;                   // record which point was nearest
            }

        else if (distSqr < distSqrNear2)        // This point is the second closest so far
            distSqrNear2 = distSqr;
        }
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
StoneTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
    LXpTextureInput*        tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
    RendData*               rd = (RendData *) data;

    tOut->direct   = 1;             // result should NOT be blended
    tOut->alpha[0] = 1.0;           // texture is opaque

    // Apply scale factors to the position
    static double const     s_internalScale = 2.0;
    LXtVector               pos, fracPos, offsetPos, cubePos;

    LXx_VSCL3 (pos, tInp->tPos, s_internalScale);

    /* Compute fractional part of the coordinates */
    fracPos[0] = pos[0] - (double)(int)pos[0];
    fracPos[1] = pos[1] - (double)(int)pos[1];
    fracPos[2] = pos[2] - (double)(int)pos[2];

    if (fracPos[0] < 0.0)
        fracPos[0] += 1.0;
    if (fracPos[1] < 0.0)
        fracPos[1] += 1.0;
    if (fracPos[2] < 0.0)
        fracPos[2] += 1.0;

    /*******************************************************************************/
    /* Convert this coordinate into a pseudo-random integer value to choose a cube */
    /*******************************************************************************/
    int             p1 = 0, n;
    double          distSqrNear     = s_infinity;       // square of dist to nearest point
    double          distSqrNear2    = s_infinity;       // square of dist to 2nd nearest point
    Neighbor        neighborTable[26];                  // Table of neighboring cubes

    chooseFeatureLocation (pos, fracPos, p1, distSqrNear, distSqrNear2);

    buildNeighborTable (neighborTable, fracPos, distSqrNear2, n);   // We need the two closest points

    /*********************************************/
    /* Now start check neighboring cubes as well */
    /*********************************************/
    double          distSqrMin, distSqrMax = distSqrNear2;

    do  {                                                   // Find the nearest neighbor
        Neighbor*       neighbor = neighborTable;
        int             cn;

        distSqrMin = s_infinity;
        for (int ci = 0; ci < n; ++ci, ++neighbor)
            {
            if (neighbor->distSqr < distSqrMin)
                {
                cn = ci;
                distSqrMin = neighbor->distSqr;
                }
            }

        /* Process the nearest neighbor cube */
        if (distSqrMin < distSqrMax)
            {
            LXx_VSUB3 (offsetPos, fracPos, neighborTable[cn].delta);    // Offset 3-D coordinate relative to this cube
            LXx_VADD3 (cubePos,   pos,     neighborTable[cn].delta);    // Compute cube id for this cube

            chooseFeatureLocation (cubePos, offsetPos, p1, distSqrNear, distSqrNear2);

            neighborTable[cn].distSqr = s_infinity;         // This neighbor has been processed
            distSqrMax                = distSqrNear2;       // We need the two closest points
            }
        }
    while (distSqrMin < distSqrMax);

    /* Compute a 3-D black and white noise value */
    LXx_VSCL (pos, 1000.0);

    NoiseUtils  noiseUtils;
    double*     dnoise = noiseUtils.noise3 (pos);
    double      noise  = rd->noisiness * dnoise[2];
    double      f      = lambda * (sqrt (distSqrNear2) - sqrt (distSqrNear));   // Color using diff between the distances

    if (f < rd->mortarThickness || 0 == rd->colors)
        {
        // Return mortar color (with some noise)

        if (LXi_TFX_COLOR == tInp->context)
            {
            noise *= 0.5;                   /* add in some 3-D black and white noise */

            tOut->color[0][0] = noise + rd->mortarColor[0];
            tOut->color[0][1] = noise + rd->mortarColor[1];
            tOut->color[0][2] = noise + rd->mortarColor[2];

            tOut->color[0][0] = LXxCLAMP (tOut->color[0][0], 0.0, 1.0);
            tOut->color[0][1] = LXxCLAMP (tOut->color[0][1], 0.0, 1.0);
            tOut->color[0][2] = LXxCLAMP (tOut->color[0][2], 0.0, 1.0);
            }
        else
            tOut->value[0] = -sqrt (rd->mortarThickness - f) - 0.1 * noise;     // smooth the ramp
        }
    else
        {
        // Get stone color value from the closest point

        if (LXi_TFX_COLOR == tInp->context)
            {
            long        seed = -p1;         // Use negative point id as the random number seed
            int         color_index = 0x1f & (rd->colorTableOffset + (long)(rd->colors * random_float (ranqd1 (seed))));
            float*      colorP = &colorTable[color_index][0];

            /* return the tinted version selected stone color (with noise) */
            tOut->color[0][0] = noise + colorP[0] * rd->tintColor[0];
            tOut->color[0][1] = noise + colorP[1] * rd->tintColor[1];
            tOut->color[0][2] = noise + colorP[2] * rd->tintColor[2];

            tOut->color[0][0] = LXxCLAMP (tOut->color[0][0], 0.0, 1.0);
            tOut->color[0][1] = LXxCLAMP (tOut->color[0][1], 0.0, 1.0);
            tOut->color[0][2] = LXxCLAMP (tOut->color[0][2], 0.0, 1.0);
            }
        else
            tOut->value[0] = rd->mortarThickness + 0.1 * noise;
        }
}

