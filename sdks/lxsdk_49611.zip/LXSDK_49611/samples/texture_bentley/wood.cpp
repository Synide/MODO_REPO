/*
 * Plug-in value textures: procedural wood
 *
 * Wood texture without noise (algorithm from book by Alan Watt)
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Wood texture
 *
 *----------------------------------------------------------------------------*/
class WoodTexture : public CLxImpl_ValueTexture
{
    public:
        WoodTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[6];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector      woodColor;
                LXtFVector      ringColor;
        };
};

LXtTagInfoDesc	 WoodTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterWoodTexture (void)
{
        RegisterTexture<WoodTexture>        ("Wood.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
WoodTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
WoodTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("woodColor",            LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.67, 0.38, 0.16);
        ac.SetDefaultVec (color);

        ac.NewChannel ("ringColor",            LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.44, 0.23, 0.09);
        ac.SetDefaultVec (color);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
WoodTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "woodColor.R");
        idx[index++] = ev.AddChan (item, "woodColor.G");
        idx[index++] = ev.AddChan (item, "woodColor.B");
        idx[index++] = ev.AddChan (item, "ringColor.R");
        idx[index++] = ev.AddChan (item, "ringColor.G");
        idx[index++] = ev.AddChan (item, "ringColor.B");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
WoodTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->woodColor[0]    = at.Float (idx[index++]);
        rd->woodColor[1]    = at.Float (idx[index++]);
        rd->woodColor[2]    = at.Float (idx[index++]);

        rd->ringColor[0]    = at.Float (idx[index++]);
        rd->ringColor[1]    = at.Float (idx[index++]);
        rd->ringColor[2]    = at.Float (idx[index++]);

        // set up local values (if any)

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
WoodTexture::vtx_Evaluate (
        ILxUnknownID            vector,
        LXpTextureOutput        *tOut,
        void                    *data)
{
    LXpTextureInput*    tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
    RendData*           rd   = (RendData *) data;

    tOut->direct   = 1;             // result should NOT be blended
    tOut->alpha[0] = 1.0;           // texture is opaque

    static float const  s_internalScale = 50.0f;
    LXtVector           pos;

    LXx_VSCL3 (pos, tInp->tPos, s_internalScale);

    // Make some concentric cylinders: Apply a sinusoidal perturbation, and a "small" twist

    double      radius  = sqrt (pos[0] * pos[0] + pos[2] * pos[2]);
    double      angle   = 0.0 == pos[2] ? HALFPI : atan2 (pos[0], pos[2]);

    radius += 2.0 * sin (20.0 * angle + pos[1] * (1.0/150.0));

    int         grain   = ((int)(radius + 0.5)) % 60;           // Make grain 2/3 light and 1/3 dark

    if (LXi_TFX_COLOR == tInp->context)
        if (grain < 40)
            LXx_VCPY (tOut->color[0], rd->woodColor);
        else
            LXx_VCPY (tOut->color[0], rd->ringColor);
    else
        tOut->value[0] = grain < 40 ? 1.0 : -1.0;

}

