/*
 * Plug-in value textures: procedural Flame
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Flame texture
 *
 *----------------------------------------------------------------------------*/
class FlameTexture : public CLxImpl_ValueTexture
{
    public:
        FlameTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[9];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector  baseColor;

                float       scale;
                float       level;
                float       flameHeight;
                float       flameWidth;
                float       flickerSpeed;
                float       animTime;

                // derived values:
                float       scaledFlameHeight;
                float       scaledFlameWidth;
                float       scaledFlameHeightInv;
                float       scaledFlameWidthInv;
        };
};

LXtTagInfoDesc	 FlameTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterFlameTexture (void)
{
        RegisterTexture<FlameTexture>       ("Flame.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
FlameTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
FlameTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("baseColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 1.0, 0.65, 0.0);
        ac.SetDefaultVec (color);

        ac.NewChannel ("scale",                 LXsTYPE_FLOAT);
        ac.SetDefault (6.0, 0);
        ac.SetHint    (hint_floatPos);

        ac.NewChannel ("level",                 LXsTYPE_FLOAT);
        ac.SetDefault (6.0, 0);
        ac.SetHint    (hint_floatZeroTo24);

        ac.NewChannel ("flameHeight",           LXsTYPE_PERCENT);
        ac.SetDefault (0.667, 0);
        ac.SetHint    (hint_floatMinZero);

        ac.NewChannel ("flameWidth",            LXsTYPE_PERCENT);
        ac.SetDefault (0.333, 0);
        ac.SetHint    (hint_floatZeroToOne);

        ac.NewChannel ("flickerSpeed",            LXsTYPE_FLOAT);
        ac.SetDefault (0.1, 0);
        ac.SetHint    (hint_floatMinZero);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
FlameTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "baseColor.R");
        idx[index++] = ev.AddChan (item, "baseColor.G");
        idx[index++] = ev.AddChan (item, "baseColor.B");
        idx[index++] = ev.AddChan (item, "scale");
        idx[index++] = ev.AddChan (item, "level");
        idx[index++] = ev.AddChan (item, "flameHeight");
        idx[index++] = ev.AddChan (item, "flameWidth");
        idx[index++] = ev.AddChan (item, "flickerSpeed");

        ev.ReadTime (&idx[index++]);

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
FlameTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->baseColor[0]        = at.Float (idx[index++]);
        rd->baseColor[1]        = at.Float (idx[index++]);
        rd->baseColor[2]        = at.Float (idx[index++]);

        rd->scale               = at.Float (idx[index++]);
        rd->level               = at.Float (idx[index++]);
        rd->flameHeight         = at.Float (idx[index++]);
        rd->flameWidth          = at.Float (idx[index++]);
        rd->flickerSpeed        = at.Float (idx[index++]);

        rd->animTime            = at.Float (idx[index++]);

        if (rd->level > 24.0f)        // Level of detail cannot exceed 24
            rd->level = 24.0f;

        // set up local values (if any)

        // Adjust flame height and width to fill the cell
        static double const     s_heightScale   = 1.25;
        static double const     s_widthScale    = 2.0;

        rd->scaledFlameHeight       = rd->flameHeight * s_heightScale;
        rd->scaledFlameWidth        = rd->flameWidth  * s_widthScale;

        rd->scaledFlameHeightInv    = 1.0f / rd->scaledFlameHeight;
        rd->scaledFlameWidthInv     = 2.0f / rd->scaledFlameWidth;      // really half width

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Compute the intensity (in a given color channel) for a point within
 * the flame based on its position.                                   
 *
 *----------------------------------------------------------------------------*/
        static double
flameColor (
        LXtVector       p,
        double          oneOverWidth,
        float           oneOverHeight,
        double          colorComponent,
        double          maxColor)
{
    if (colorComponent <= 0.0)
        return 0.0;

    double      scale   = maxColor / colorComponent;
    double      x       = scale * fabs (p[0] * oneOverWidth);
    double      y       = scale * p[1] * oneOverHeight;
    double      d       = x * x + y * y;

    d = d < 1.0 ? 1.0 - d : 0.0;

    return d * d;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
FlameTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
    LXpTextureInput*    tInp    = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
    RendData*           rd      = (RendData *) data;
    LXtFVector2         uv      = { tInp->uvw[0], tInp->uvw[1] };
    LXtVector           relativePos;

    tOut->direct   = 1;             // result should NOT be blended

    if (uv[0] < 0.0f)
        uv[0] = uv[0] - (float)floor (uv[0]);

    if (uv[1] >= 0.0f)
        {
        relativePos[0] =        uv[0] - (float)(int)uv[0] - 0.5f;
        relativePos[1] = 1.0f - uv[1] - (float)(int)uv[1];
        }
    else
        {
        uv[1] = -uv[1];
        relativePos[0] = uv[0] - (float)(int)uv[0] - 0.5f;
        relativePos[1] = uv[1] - (float)(int)uv[1];
        }

    relativePos[2] = 0.0f;       // Set a seed value for the turbulence

    if (relativePos[1] >= rd->scaledFlameHeight || relativePos[0] >= rd->scaledFlameWidth)
        {
        if (LXi_TFX_COLOR == tInp->context)
            {
            LXx_VSET (tOut->color[0], 0.0);
            tOut->alpha[0] = 0.0;
            }
        else
            tOut->value[0] = 0.0;               // set for bump, displacement, etc.

        return;
        }

    LXtVector       scaledPos, color, intensity;
    double          max;

    /**********************************************************************************/
    /***** Compute an animated flame texture                                      *****/
    /***** (algorithm from "Advanced Animation and Rendering Techniques", p. 211) *****/
    /**********************************************************************************/

    /* For animation, move point vertically through space */
    scaledPos[0] = rd->scale * (relativePos[0]);
    scaledPos[1] = rd->scale * (relativePos[1] - rd->animTime * rd->flickerSpeed);
    scaledPos[2] = rd->scale * (relativePos[2] - rd->animTime);

    /* Compute a (variable) turbulent brightness value */
    NoiseUtils  noiseUtils;
    double      variance    = 1.0 - flameColor (relativePos, rd->scaledFlameWidthInv, rd->scaledFlameHeightInv, 1.0, 1.0);
    double      turbulnc    = noiseUtils.turbulence (scaledPos, rd->level);
    double      brightness  = 1.0 - variance * fabs (turbulnc) * 0.5;

    if (brightness < 0.0)
        {
        if (LXi_TFX_COLOR == tInp->context)
            {
            LXx_VSET (tOut->color[0], 0.0);
            tOut->alpha[0] = 0.0;
            }
        else
            tOut->value[0] = 0.0;               // set for bump, displacement, etc.

        return;
        }

    LXx_VSCL3 (color, rd->baseColor, brightness);

    /* Get the largest of the RGB color values */
    if (color[0] > color[1])
        max = color[0] > color[2] ? color[0] : color[2];
    else
        max = color[1] > color[2] ? color[1] : color[2];

    intensity[0] = flameColor (relativePos, rd->scaledFlameWidthInv, rd->scaledFlameHeightInv, color[0], max);
    intensity[1] = flameColor (relativePos, rd->scaledFlameWidthInv, rd->scaledFlameHeightInv, color[1], max);
    intensity[2] = flameColor (relativePos, rd->scaledFlameWidthInv, rd->scaledFlameHeightInv, color[2], max);

    /* Compute max intensity (of R, G, B) */
    if (intensity[0] > intensity[1])
        max = intensity[0] > intensity[2] ? intensity[0] : intensity[2];
    else
        max = intensity[1] > intensity[2] ? intensity[1] : intensity[2];

    if (LXi_TFX_COLOR == tInp->context)     // Semi-transparent Flame
        {
        LXx_VMUL3 (tOut->color[0], color, intensity);
        tOut->alpha[0] = max;
        }
    else
        tOut->value[0] = max;               // set for bump, displacement, etc.
}

