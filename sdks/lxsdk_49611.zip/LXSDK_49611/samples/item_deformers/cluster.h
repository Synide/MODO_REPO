/*
 * CLUSTER.H		Vertex Cluster Mesh Influence
 *
 *	Copyright (c) 2008-2012 Luxology LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */

#define CTYPE_ALL		 0
#define CTYPE_WEIGHT		 1
#define CTYPE_PICK		 2
#define CTYPE_MATERIAL		 3
#define CTYPE_PART		 4
#define CTYPE_PSELSET		 5

#define CREATECMD_LOC		 LXsITYPE_VERTEXINFLUENCE    ".create"
#define CREATECMD_NL		 LXsITYPE_VERTEXINFLUENCENL ".create"


/*
 * ------------ vertexInfluence resources (FWIW)

 <!--
        <hash type="Item" key="vertexInfluence@en_US">
            <atom type="UserName">Vertex Influence Locator</atom>

            <hash type="Channel" key="type">
                <atom type="UserName">Type</atom>
                <atom type="Tooltip">Selects the subset of vertices for deformation.</atom>
                <atom type="ArgumentType">vertex-cluster-type</atom>
            </hash>
            <hash type="Channel" key="name">
                <atom type="UserName">Name</atom>
                <atom type="Tooltip">Name of the vertex map or polygon tag.</atom>
            </hash>

            <hash type="Message" key="all">Entire Mesh</hash>
            <hash type="Message" key="mapWeight">Weight: %1</hash>
            <hash type="Message" key="mapPick">Vertex Set: %1</hash>
            <hash type="Message" key="ptagMaterial">Material: %1</hash>
            <hash type="Message" key="ptagPart">Part: %1</hash>
            <hash type="Message" key="ptagPick">Polygon Set: %1</hash>
        </hash>
        <hash type="Item" key="vertexInfluenceNL@en_US">
            <atom type="UserName">Vertex Influence</atom>

            <hash type="Channel" key="type">
                <atom type="UserName">Type</atom>
                <atom type="Tooltip">Selects the subset of vertices for deformation.</atom>
                <atom type="ArgumentType">vertex-cluster-type</atom>
            </hash>
            <hash type="Channel" key="name">
                <atom type="UserName">Name</atom>
                <atom type="Tooltip">Name of the vertex map or polygon tag.</atom>
            </hash>
        </hash>
   -->

 <!--
        <hash type="Preset"     key="vertexInfluence.item:filterPreset">
            <atom type="Name">Vertex Influence Locator</atom>
            <atom type="Enable">1</atom>
            <list type="Node">1 .group 0 &quot;&quot;</list>
            <list type="Node">1 itemtype 0 1 &quot;vertexInfluence&quot;</list>
            <list type="Node">-1 .endgroup </list>
        </hash>
        <hash type="Preset"     key="vertexInfluenceNL.item:filterPreset">
            <atom type="Name">Vertex Influence</atom>
            <atom type="Enable">1</atom>
            <list type="Node">1 .group 0 &quot;&quot;</list>
            <list type="Node">1 itemtype 0 1 &quot;vertexInfluenceNL&quot;</list>
            <list type="Node">-1 .endgroup </list>
        </hash>
   -->

 <!--
        <hash type="Sheet" key="vertexInfluence.item:sheet">
            <atom type="Label">Vertex Influence</atom>
            <atom type="Filter">vertexInfluence.item:filterPreset</atom>
            <atom type="Group">itemprops/render</atom>

            <hash type="InCategory" key="itemprops:general#head">
                <atom type="Ordinal">129</atom>
            </hash>

            <list type="Control" val="ref 11145884454:sheet"></list>
            <list type="Control" val="ref 80746857872:sheet"></list>

            <list type="Control" val="div ">
                <atom type="Label">Vertex Influence</atom>
                <atom type="Hash">03948590201:control</atom>
                <atom type="Alignment">full</atom>
            </list>

            <list type="Control" val="cmd item.channel vertexInfluence$enable ?"/>
            <list type="Control" val="cmd item.channel vertexInfluence$type ?"/>
            <list type="Control" val="cmd vertexInfluence.setName ?">
              <atom type="Label">Name</atom>
            </list>
        </hash>

        <hash type="Sheet" key="vertexInfluenceNL.item:sheet">
            <atom type="Label">Vertex Influence</atom>
            <atom type="Filter">vertexInfluenceNL.item:filterPreset</atom>
            <atom type="Group">itemprops/render</atom>

            <hash type="InCategory" key="itemprops:general#head">
                <atom type="Ordinal">129</atom>
            </hash>

            <list type="Control" val="cmd item.name type:vertexInfluenceNL name:?"></list>

            <list type="Control" val="div ">
                <atom type="Label">Vertex Influence</atom>
                <atom type="Hash">VD948590201:control</atom>
                <atom type="Alignment">full</atom>
            </list>

            <list type="Control" val="cmd item.channel vertexInfluenceNL$enable ?"/>
            <list type="Control" val="cmd item.channel vertexInfluenceNL$type ?"/>
            <list type="Control" val="cmd vertexInfluence.setName ?">
              <atom type="Label">Name</atom>
            </list>
        </hash>
   -->



 *
 */

