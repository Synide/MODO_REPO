/*
 * GROUP.CPP	Group Mesh Influence
 *
 *	Copyright (c) 2008-2012 Luxology LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_item.hpp>
#include <lx_group.hpp>
#include <lx_package.hpp>
#include <lx_visitor.hpp>
#include <lx_listener.hpp>
#include <lx_plugin.hpp>
#include <lx_filter.hpp>
#include <lx_action.hpp>
#include <lx_value.hpp>
#include <lx_mesh.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxidef.h>
#include <string>
#include <vector>
#include <map>
#include <math.h>

#include <lx_log.hpp>


        namespace Influence_Group {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		"meshInfluenceGroup"
#define SRVNAME_MODIFIER		"meshInfluenceGroup"
#define SPWNAME_INSTANCE		"group.instance"
#define SPWNAME_INFLUENCE		"group.influence"


/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CPackage;

class CInstance :
                public CLxImpl_PackageInstance
{
    public:
        CPackage	*src_pkg;
        CLxUser_Item	 m_item;

        LxResult	 pins_Initialize (ILxUnknownID item, ILxUnknownID super)	LXx_OVERRIDE;
        void		 pins_Cleanup (void)						LXx_OVERRIDE;
};

class CPackage :
                public CLxImpl_Package
{
    public:
        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 inst_spawn;

        CPackage () : inst_spawn (SPWNAME_INSTANCE) {}

        LxResult	 pkg_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult	 pkg_TestInterface (const LXtGUID *guid) LXx_OVERRIDE;
        LxResult	 pkg_Attach (void **ppvObj) LXx_OVERRIDE;
};



/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
/*
 * The package has a set of standard channels with default values. These
 * are setup at the start using the AddChannel interface.
 */
#define Cs_MESHINF		"meshInf"
#define Cs_ENABLE		"enable"

LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,		LXsITYPE_GROUP		},
        { LXsPKG_MESHINF_CHANNEL,	Cs_MESHINF		},
        { LXsPKG_MESHINF_FLAGS,		"+esWX"			},
        { 0 }
};

        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (Cs_MESHINF,	LXsTYPE_OBJREF);
        ac.SetInternal ();

        ac.NewChannel  (Cs_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);

        return LXe_OK;
}

/*
 * TestInterface() is required so that nexus knows what interfaces instance
 * of this package support. Necessary to prevent query loops.
 */
        LxResult
CPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return inst_spawn.TestInterfaceRC (guid);
}

/*
 * Attach is called to create a new instance of this item. The returned
 * object implements a specific item of this type in the scene.
 */
        LxResult
CPackage::pkg_Attach (
        void		       **ppvObj)
{
        CInstance		*inst = inst_spawn.Alloc (ppvObj);

        inst->src_pkg = this;
        return LXe_OK;
}


/*
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
        LxResult
CInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        m_item.set (item);
        return LXe_OK;
}

        void
CInstance::pins_Cleanup (void)
{
        m_item.clear ();
}


/*
 * ----------------------------------------------------------------
 * Source List
 *
 * This is a list of the mesh influence items in the group which are used
 * to compose the influence.
 */
class SourceElt {
    public:
        const char		*ident;
        unsigned		 index;
};
class CSourceList :
                public std::vector<SourceElt>,
                public CLxImpl_AbstractVisitor
{
    public:
        CLxUser_DeformerService	 d_S;
        CLxUser_GroupEnumerator	 gr_enum;

        void		Build    (ILxUnknownID);
        bool		Compare  (CSourceList &);
        void		Attach   (CLxUser_Scene &, CLxUser_Evaluation &);
//	void		Eval     (CLxUser_Attributes &, );

        LxResult	Evaluate ()	LXx_OVERRIDE;	// visitor evaluate
};

typedef std::vector<SourceElt>::iterator	 SourceList_Itr;

/*
 * Building the list just scans group members and adds any that can act as a mesh
 * influence. We just store the ident string so we don't maintain persistent
 * locks on the items themselves.
 */
        void
CSourceList::Build (
        ILxUnknownID		 item)
{
        CLxUser_GroupItem	 group (item);
        CLxUser_Item		 sub;

        clear ();
        group.GetEnumerator (gr_enum);
        gr_enum.Enum (this, LXfGRPTYPE_ITEM);
        gr_enum.clear ();
}

        LxResult
CSourceList::Evaluate ()
{
        CLxUser_Item		 item;
        SourceElt		 elt;

        gr_enum.GetItem (item);
        if (!d_S.HasMeshInfluence (item))
                return LXe_OK;

        item.Ident (&elt.ident);
        push_back (elt);
        return LXe_OK;
}

        void
CSourceList::Attach (
        CLxUser_Scene		&scene,
        CLxUser_Evaluation	&eval)
{
        SourceList_Itr		 sli;
        CLxUser_Item		 item;
        unsigned		 chan;

        for (sli = begin (); sli != end (); sli++) {
                scene.GetItem (sli->ident, item);
                if (LXx_OK (d_S.MeshInfluenceChannel (item, &chan)))
                        sli->index = eval.AddChan (item, chan);
                else
                        sli->index = ~0;
        }
}

/*
 * Compare this list to another one. If the elements aren't exactly the same
 * we return false. (How come "vector" doesn't have this method?)
 */
        bool
CSourceList::Compare (
        CSourceList		&that)
{
        SourceList_Itr		 sli1, sli2;

        sli1 = begin ();
        sli2 = that.begin ();

        while (sli1 != end () && sli2 != that.end ()) {
                if (strcmp (sli1->ident, sli2->ident))
                        return false;

                sli1++;
                sli2++;
        }

        return (sli1 == end () && sli2 == that.end ());
}



/*
 * ----------------------------------------------------------------
 * Mesh Cache
 *
 * For each mesh we pre-compute a table of weights that affect each vertex.
 * The table maps point IDs to vertex data, and the data for a vertex is a
 * list of mesh influence indices and weight. This has to be done in order
 * to normalize the weights for each vertex, and to improve performance on
 * offset-only changes. It has to be recomputed if the mesh or weights
 * change.
 */
class CMeshCache :
                public CLxImpl_MeshListener,
                public CLxSingletonPolymorph
{
    public:
        LXxSINGLETON_METHOD;

        class VrtWeight {
            public:
                int		 index;
                float		 weight;
        };

        typedef std::vector<CLxUser_MeshInfluence>		MifList;
        typedef std::vector<CLxUser_MeshInfluence>::iterator	MifList_Itr;
        typedef std::vector<VrtWeight>				VrtData;
        typedef std::vector<VrtWeight>::iterator		VrtData_Itr;
        typedef std::map<LXtPointID,VrtData>			VrtTable;
        typedef std::map<LXtPointID,VrtData>::iterator		VrtTable_Itr;
        typedef std::pair<LXtPointID,VrtData>			VrtTable_Elt;
        typedef std::pair<VrtTable_Itr,bool>			VrtTable_Find;

        class CInflVertexVisitor : public CLxImpl_AbstractVisitor
        {
            public:
                CLxUser_MeshInfluence
                                *mif;
                VrtTable	*table;
                VrtWeight	 wt;
                VrtData		 empty;

                LxResult	 Evaluate ();
        };

                         CMeshCache (ILxUnknownID, LXtMatrix4, MifList &, CLxList<CMeshCache> &);
                        ~CMeshCache ();

        LxResult	 Enumerate (ILxUnknownID);
        LxResult	 SetPoint (LXtPointID);
        LXtPointID	 Point ();
        void		 Offset (MifList &, LXtVector);

        void		 ml_Destroy ();

        CLxList<CMeshCache>	&client_list;
        CLxUser_Mesh		 m_mesh;
        VrtTable_Itr		 cur_point;
        VrtTable		 v_table;

        CMeshCache		*next, *prev;
};


/*
 * The constructor initializes the weight tables for a specific mesh.
 */
CMeshCache::CMeshCache (
        ILxUnknownID		 mesh,
        LXtMatrix4		 xfrm,
        MifList			&list,
        CLxList<CMeshCache>	&clist) : client_list (clist)
{
        /*
         * We store the mesh locally and attach to it so we can detect when
         * it's destroyed.
         */
        CLxUser_ListenerPort	port;

        AddInterface (new CLxIfc_MeshListener<CMeshCache>);

        m_mesh.set (mesh);
        port.set (mesh);
        port.AddListener (*this);

        /*
         * Initializing the table scans the mesh influences and enumerates the 
         * contents of each. The visitor builds the tables of which vertices are
         * affected by which influences.
         */
        CInflVertexVisitor	 vis;
        LxResult		 rc;

        vis.table = &v_table;
        for (vis.wt.index = 0; vis.wt.index < list.size (); vis.wt.index++) {
                vis.mif = & list[vis.wt.index];
                if (vis.mif->Flags () & LXfMESHINF_NO_OFFSET)
                        continue;

                vis.mif->SetMesh (mesh, xfrm);
                rc = vis.mif->Enum (&vis);
                if (LXx_FAIL (rc))
                        throw (rc);

                vis.mif->SetMesh (0, xfrm);
        }

        cur_point = v_table.end ();

        /*
         * Finally we walk list and normalize all the weights on a specific
         * vertex so that all the influences add up to 1.0.
         */
        VrtTable_Itr		 vti;
        VrtData_Itr		 vdi;
        double			 sum;

        for (vti = v_table.begin() ; vti != v_table.end(); vti++) {
                sum = 0.0;
                for (vdi = vti->second.begin() ; vdi != vti->second.end(); vdi++)
                        sum += vdi->weight;

                for (vdi = vti->second.begin() ; vdi != vti->second.end(); vdi++)
                        vdi->weight /= sum;
        }

        /*
         * Add ourselves to the client list.
         */
        client_list.AddTail (this);
}

/*
 * Building the vertex table is done with a visitor. For each vertex of each
 * source mesh influence we get the weight. For non-zero weights we find the
 * entry in the table for this vertex and add this influence and weight.
 */
        LxResult
CMeshCache::CInflVertexVisitor::Evaluate ()
{
        LXtPointID	 vrt;
        VrtTable_Find	 loc;

        wt.weight = mif->Weight ();
        if (wt.weight <= 0.0)
                return LXe_OK;

        vrt = mif->Point ();
        loc = table->insert (VrtTable_Elt (vrt, empty));

        VrtData		&dst = loc.first->second;

        dst.push_back (wt);
        return LXe_OK;
}

/*
 * Given a visitor from the client, we walk through all the vertices. The current
 * vertex is stored as an iterator for the table so it can also be set directly.
 */
        LxResult
CMeshCache::Enumerate (
        ILxUnknownID		 visitor)
{
        CLxUser_Visitor		 vis (visitor);
        LxResult		 rc;

        for (cur_point = v_table.begin (); cur_point != v_table.end (); cur_point++) {
                rc = vis.Evaluate ();
                if (LXx_FAIL (rc))
                        return rc;
        }

        return LXe_OK;
}

        LxResult
CMeshCache::SetPoint (
        LXtPointID		 point)
{
        cur_point = v_table.find (point);
        if (cur_point == v_table.end ())
                return LXe_NOTFOUND;

        return LXe_OK;
}

        LXtPointID
CMeshCache::Point ()
{
        return cur_point->first;
}


/*
 * The offset is easily computed by asking each influence on the point for its
 * current offset and returning the weighted sum.
 */
        void
CMeshCache::Offset (
        MifList			&list,
        LXtVector		 offset)
{
        VrtData_Itr		 vdi;
        LXtVector		 sub;

        LXx_VCLR (offset);

        for (vdi = cur_point->second.begin (); vdi != cur_point->second.end (); vdi ++) {
                CLxUser_MeshInfluence	&mif = list[vdi->index];

                mif.SetPoint (cur_point->first);
                mif.Offset (sub);
                LXx_VADDS (offset, sub, vdi->weight);
        }
}

/*
 * On mesh destroy events we just destroy ourselves, thus eliminating any
 * problem of being out of date.
 */
        void
CMeshCache::ml_Destroy ()
{
        delete this;
}

/*
 * The destructor undoes the create, removing ourselves from the list and
 * from the mesh listener.
 */
CMeshCache::~CMeshCache ()
{
        CLxUser_ListenerPort	 port (m_mesh);

        port.RemoveListener (*this);
        client_list.Remove (this);
}


/*
 * ----------------------------------------------------------------
 * Mesh Influence
 *
 * We generate a mesh influence from scratch since we don't fit the map or
 * marking model.
 */
class CInfluence :
                public CLxImpl_MeshInfluence
{
    public:
        CMeshCache		*c;
        CMeshCache::MifList	 mif_list;
        CLxList<CMeshCache>	 mesh_list;
        bool			 is_enabled;

        unsigned	 minf_Flags ()					LXx_OVERRIDE;
        LxResult	 minf_SetMesh (ILxUnknownID mesh, LXtMatrix4)	LXx_OVERRIDE;
        LxResult	 minf_Enumerate (ILxUnknownID visitor)		LXx_OVERRIDE;
        LxResult	 minf_SetPoint (LXtPointID point)		LXx_OVERRIDE;
        LXtPointID	 minf_Point ()					LXx_OVERRIDE;
        void		 minf_Offset (LXtVector offset)			LXx_OVERRIDE;

        void		 Init (CLxUser_Attributes &, CSourceList &);
        void		 Invalidate ();
};

/*
 * Initializing the influence grabs all the sources and puts them into a list.
 * As long as the contents and order are the same this may get re-allocated
 * during fast-path evaluations.
 */
        void
CInfluence::Init (
        CLxUser_Attributes	&attr,
        CSourceList		&list)
{
        SourceList_Itr		 sli;
        CLxUser_ValueReference	 ref;
        CLxUser_MeshInfluence	 mif;

        mif_list.clear ();

        for (sli = list.begin (); sli != list.end (); sli++) {
                if (sli->index == ~0)
                        continue;

                attr.ObjectRO (sli->index, ref);
                if (ref.Get (mif))
                        mif_list.push_back (mif);
        }
}

/*
 * Explicit invalidation of the cache just deletes all the entries in the
 * cache list. They remove themselves when deleted.
 */
        void
CInfluence::Invalidate ()
{
        while (mesh_list.first)
                delete mesh_list.first;
}

        unsigned
CInfluence::minf_Flags ()
{
        return /*LXfMESHINF_REQ_WEIGHT |*/ LXfMESHINF_REQ_OFFSET | LXfMESHINF_NO_WEIGHT | LXfMESHINF_NO_XFRM;
}

/*
 * Setting the mesh looks up or allocates the appropriate mesh cache in the cache
 * list.
 *
 * NOTE: not sure how to deal with transform changes. The same mesh with a
 * different transform may or may not have different weights.
 */
        LxResult
CInfluence::minf_SetMesh (
        ILxUnknownID		 mesh,
        LXtMatrix4		 xfrm)
{
        if (!is_enabled)
                return LXe_OK;

        if (mesh) {
                for (c = mesh_list.first; c; c = c->next)
                        if (c->m_mesh.IsSame (mesh))
                                break;

                if (!c)
                        c = new CMeshCache (mesh, xfrm, mif_list, mesh_list);
        } else
                c = 0;

        CMeshCache::MifList_Itr	 mli;

        for (mli = mif_list.begin (); mli != mif_list.end (); mli++)
                mli->SetMesh (mesh, xfrm);

        return LXe_OK;
}

/*
 * Given a visitor from the client, we walk through all the vertices. The current
 * vertex is stored as an iterator for the table so it can also be set directly.
 */
        LxResult
CInfluence::minf_Enumerate (
        ILxUnknownID		 visitor)
{
        if (!is_enabled)
                return LXe_OK;
        else
                return c->Enumerate (visitor);
}

        LxResult
CInfluence::minf_SetPoint (
        LXtPointID		 point)
{
        if (!is_enabled)
                return LXe_INVALIDARG;
        else
                return c->SetPoint (point);
}

        LXtPointID
CInfluence::minf_Point ()
{
        return c->Point ();
}


/*
 * The offset is easily computed by asking each influence on the point for its
 * current offset and returning the weighted sum.
 */
        void
CInfluence::minf_Offset (
        LXtVector		 offset)
{
        c->Offset (mif_list, offset);
}


/*
 * ----------------------------------------------------------------
 * Modifier
 */
class CCacheState :
                public CLxObject
{
    public:
        CInfluence		*infl;
        CLxUser_MeshInfluence	 last;
        LxResult		 state;

        CCacheState () : state (LXeMESHINF_DIFFERENT) {}
};

/*
 * The modifier operates on all items of this type, and sets the mesh influence
 * channel to an object allocated using the input parameters for the modifier.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        CLxSpawner<CInfluence>	 spawn;
        const char *		 grp_ident;
        CSourceList		 src_list;
        unsigned		 idx_enab;

        CModifierElement () : spawn (SPWNAME_INFLUENCE) {}

                void
        Attach (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
        {
                CLxUser_Item		 itm (item);
                CLxUser_Scene		 scene;

                itm.Ident (&grp_ident);

                idx_enab = eval.AddChan (item, Cs_ENABLE);

                scene.from (itm);
                src_list.Build (item);
                src_list.Attach (scene, eval);
        }

                bool
        Test (
                ILxUnknownID		 item)		LXx_OVERRIDE
        {
                CSourceList		 tmp;

                tmp.Build (item);
                return src_list.Compare (tmp);
        }

                CLxObject *
        Cache ()					LXx_OVERRIDE
        {
                return new CCacheState;
        }

                LxResult
        EvalCache (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr,
                CLxObject		*cacheRaw,
                bool			 prev)		LXx_OVERRIDE
        {
                CCacheState		*cache = dynamic_cast<CCacheState *> (cacheRaw);
                CLxUser_ValueReference	 ref;
                LxResult		 rc;

                rc = cache->state;
                if (rc == LXeMESHINF_DIFFERENT)
                        cache->infl = spawn.Alloc (cache->last);

                attr.ObjectRW (0, ref);
                ref.SetObject (cache->last);

                cache->infl->is_enabled = attr.Bool (idx_enab);
                cache->infl->Init (attr, src_list);

                cache->state = LXeMESHINF_IDENTICAL;
                return rc;
        }

        /*
         * This reacts to input channels as they get validated. Any fully different
         * inputs cause this modifier to be fully different as well, as do changes
         * on the group item itself (enable). If the change is less than fully
         * different and the cache already is different, it stays the same. The
         * remaining case is a NEWOFFSET input influence, which makes this NEWOFFSET
         * as well.
         */
                bool
        Validate (
                CLxObject		*cacheRaw,
                CLxUser_Item		&item,
                unsigned		 channel,
                LxResult		 rc)
        {
                CCacheState		*cache = dynamic_cast<CCacheState *> (cacheRaw);
                const char		*ident;

                if (rc == LXeMESHINF_DIFFERENT || rc == LXeMESHINF_NEWWEIGHT)
                        cache->state = LXeMESHINF_DIFFERENT;
                else {
                        item.Ident (&ident);
                        if (strcmp (ident, grp_ident) == 0)
                                cache->state = LXeMESHINF_DIFFERENT;
                        else if (cache->state == LXeMESHINF_DIFFERENT)
                                ;
                        else if (rc == LXeMESHINF_NEWOFFSET)
                                cache->state = LXeMESHINF_NEWOFFSET;
                }

                if (cache->state == LXeMESHINF_DIFFERENT)
                        cache->infl->Invalidate ();

                return true;
        }
};

class CModifier :
                public CLxItemModifierServer
{
    public:
                const char *
        ItemType ()
        {
                return SRVNAME_ITEMTYPE;
        }

                const char *
        GraphNames ()
        {
                return LXsGRAPH_GROUPS " " LXsGRAPH_ITEMGROUPS;
        }

                CLxItemModifierElement *
        Alloc (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
        {
                CModifierElement	*elt;

                elt = new CModifierElement;
                eval.AddChan (item, Cs_MESHINF, LXfECHAN_WRITE);

                elt->Attach (eval, item);
                return elt;
        }
};



/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackage>;
        srv->AddInterface (new CLxIfc_Package   <CPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc<CPackage>);
        lx::AddServer (SRVNAME_ITEMTYPE, srv);

        srv = new CLxPolymorph<CInstance>;
        srv->AddInterface (new CLxIfc_PackageInstance<CInstance>);
        lx::AddSpawner (SPWNAME_INSTANCE, srv);

        srv = new CLxPolymorph<CInfluence>;
        srv->AddInterface (new CLxIfc_MeshInfluence<CInfluence>);
        lx::AddSpawner (SPWNAME_INFLUENCE, srv);

        CLxExport_ItemModifierServer<CModifier> (SRVNAME_MODIFIER);
}

        };	// END namespace



