/*
 * Plug-in custom shader: 
 * Hair Shader - based off "An Artist-Friendly Hair Shading System"
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 */

#include <lx_shade.hpp>
#include <lx_vector.hpp>
#include <lx_package.hpp>
#include <lx_action.hpp>
#include <lx_value.hpp>
#include <lx_log.hpp>
#include <lx_channelui.hpp>
#include <lx_item.hpp>
#include <lxcommand.h>
#include <lxidef.h>
#include <lx_raycast.hpp>
#include <lxtableau.h>
#include <lxlocator.h>
#include <lxvmath.h>
#include <lx_thread.hpp>
#include <lx_shdr.hpp>
#include <lx_log.hpp>

#include <math.h>
#include <string>
#include <stdlib.h>

#define TABLE_ENTRIES 32
#define HALF_TABLE_ENTRIES 16
#define INTEGRAL_SAMPLES 32

#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define CLAMP(value, low, high) (((value)<(low))?(low):(((value)>(high))?(high):(value)))

        int
IEEEFloatTest (
        float			 val) 
{
        unsigned int		 n, exp, mant;

        n = ((unsigned int *) &val) [0];
        exp = (n & 0x7F800000) >> 23;
        if (exp != 255)
                return 0;

        mant = (n & 0x007FFFFF);
        if (mant != 0)
                return -1;	// NAN
        else
                return +1;	// INFINITY
}

        void
Desaturate (
        LXtFVector		col)
{
        float avg;
        avg = sqrtf((col[0]*col[0] + col[1]*col[1] + col[2]*col[2])/3.0f);
        LXx_VSET (col, avg);
}

        void
Desaturate (
        LXtVector		col)
{
        double avg;
        avg = sqrtf((col[0]*col[0] + col[1]*col[1] + col[2]*col[2])/3.0);
        LXx_VSET (col, avg);
}

        void
Resaturate (
        LXtFVector		col,
        LXtFVector		target)
{
        LXtFVector		targetCpy;
        float avg;

        LXx_VCPY (targetCpy, target);
        
        avg = (targetCpy[0] + targetCpy[1] + targetCpy[2])/3.0f;
        LXx_VSCL (targetCpy, avg);
        LXx_VMUL (col, targetCpy);
}

        void
Resaturate (
        LXtVector		col,
        LXtVector		target)
{
        LXtVector		targetCpy;
        double avg;

        LXx_VCPY (targetCpy, target);

        avg = (targetCpy[0] + targetCpy[1] + targetCpy[2])/3.0;
        LXx_VSCL (targetCpy, avg);
        LXx_VMUL (col, targetCpy);
}

static LXtTextValueHint hint_giType[] = {
                0,		"none", 
                1,		"recv",
                2,		"cast",
                3,		"both",
                3
};

#define SRVs_HAIR_VPACKET		"hair.shader.packet"
#define LXsP_SAMPLE_HAIRSHADER		SRVs_HAIR_VPACKET

/*------------------------------- Luxology LLC --------------------------- 8/31/11
 *
 * This defines all the data that exists in the hair material, which makes it
 * easy to pass around between the hair shader packet and hair material.
 *
 *----------------------------------------------------------------------------*/

class HairMaterialData {
            public:
                        HairMaterialData () {
                                this->densityFactor = .7;
                        }

                        LXtFVector	primaryHighlightColor;
                        float		primaryHighlightIntensity;
                        float		primaryHighlightLongWidth;
                        float		primaryHighlightLongShift;
                
                        LXtFVector	secondaryHighlightColor;
                        float		secondaryHighlightIntensity;
                        float		secondaryHighlightLongWidth;
                        float		secondaryHighlightLongShift;

                        LXtFVector	rimLightColor;
                        float		rimLightIntensity;
                        float		rimLightLongWidth;
                        float		rimLightLongShift;
                        float		rimLightAzimuthalWidth;

                        LXtFVector	glintsColor;
                        float		glintsIntensity;
                        float		glintsFrequency;

                        LXtFVector	fwdScatteringColorAdj;
                        float		fwdScatteringIntensityAdj;
                        float		fwdScatteringSaturation;

                        LXtFVector	bwdScatteringColorAdj;
                        float		bwdScatteringIntensityAdj;
                        float		bwdScatteringLongWidthAdj;
                        float		bwdScatteringLongShift;
                        float		bwdScatteringSaturation;

                        float		globalScatteringSaturation;

                        float		densityFactor;

                        int		giType;
                        int		giRays;

                        int		singleScatteringOn;
};

/*------------------------------- Luxology LLC --------------------------- 8/31/11
 *
 * The Hair Shader packet definition.
 *
 *----------------------------------------------------------------------------*/
        
class HairPacket : public CLxImpl_VectorPacket
{
    public:
        HairPacket () {}

        static LXtTagInfoDesc	descInfo[];

        unsigned int	vpkt_Size () LXx_OVERRIDE;
        const LXtGUID * vpkt_Interface (void) LXx_OVERRIDE;
        LxResult	vpkt_Initialize (void	*packet) LXx_OVERRIDE;
        LxResult	vpkt_Blend (void	*packet,void	*p0,void	*p1,float	t,int	mode) LXx_OVERRIDE;
};


LXtTagInfoDesc	 HairPacket::descInfo[] = {
        { LXsSRV_USERNAME,	"Hair Shader Packet" },
        { LXsSRV_LOGSUBSYSTEM,	"vector-packet"},
        { LXsVPK_CATEGORY,	LXsCATEGORY_SAMPLE},
        { 0 }
};

typedef struct st_LXpHairShader {
        HairMaterialData		matrData;
} LXpHairShader;


        unsigned int
HairPacket::vpkt_Size (void) 
{
        return	sizeof (LXpHairShader);
}
        
        const LXtGUID *
HairPacket::vpkt_Interface (void) 
{
        return NULL;
}

        LxResult
HairPacket::vpkt_Initialize (
        void			*p) 
{
        LXpHairShader		*hsp = (LXpHairShader *)p;

        return LXe_OK;
}

        LxResult
HairPacket::vpkt_Blend (
        void			*p, 
        void			*p0, 
        void			*p1,
        float			 t,
        int			 mode)
{
        LXpHairShader		*hsp = (LXpHairShader *)p;
        LXpHairShader		*hsp0 = (LXpHairShader *)p0;
        LXpHairShader		*hsp1 = (LXpHairShader *)p1;

        CLxLoc_ShaderService	 shdrSrv;

        HairMaterialData		*matrData = &hsp->matrData;

        /*
         * Color values
         */
        shdrSrv.ColorBlendValue (matrData->primaryHighlightColor,
                                hsp0->matrData.primaryHighlightColor, 
                                hsp1->matrData.primaryHighlightColor, 
                                t, 
                                mode);
        shdrSrv.ColorBlendValue (matrData->secondaryHighlightColor,
                                hsp0->matrData.secondaryHighlightColor, 
                                hsp1->matrData.secondaryHighlightColor, 
                                t, 
                                mode);
        shdrSrv.ColorBlendValue (matrData->rimLightColor,
                                hsp0->matrData.rimLightColor, 
                                hsp1->matrData.rimLightColor, 
                                t, 
                                mode);
        shdrSrv.ColorBlendValue (matrData->fwdScatteringColorAdj,
                                hsp0->matrData.fwdScatteringColorAdj, 
                                hsp1->matrData.fwdScatteringColorAdj, 
                                t, 
                                mode);
        shdrSrv.ColorBlendValue (matrData->bwdScatteringColorAdj,
                                hsp0->matrData.bwdScatteringColorAdj, 
                                hsp1->matrData.bwdScatteringColorAdj, 
                                t, 
                                mode);

        /*
         * Intensity values
         */
        matrData->primaryHighlightIntensity = shdrSrv.ScalarBlendValue (hsp0->matrData.primaryHighlightIntensity,
                                                                        hsp1->matrData.primaryHighlightIntensity,
                                                                        t,
                                                                        mode);
        matrData->secondaryHighlightIntensity = shdrSrv.ScalarBlendValue (hsp0->matrData.secondaryHighlightIntensity,
                                                                        hsp1->matrData.secondaryHighlightIntensity,
                                                                        t,
                                                                        mode);
        matrData->rimLightIntensity = shdrSrv.ScalarBlendValue (hsp0->matrData.rimLightIntensity,
                                                                hsp1->matrData.rimLightIntensity,
                                                                t,
                                                                mode);
        matrData->glintsIntensity = shdrSrv.ScalarBlendValue (hsp0->matrData.glintsIntensity,
                                                                hsp1->matrData.glintsIntensity,
                                                                t,
                                                                mode);
        matrData->fwdScatteringIntensityAdj = shdrSrv.ScalarBlendValue (hsp0->matrData.fwdScatteringIntensityAdj,
                                                                                hsp1->matrData.fwdScatteringIntensityAdj,
                                                                                t,
                                                                                mode);
        matrData->bwdScatteringIntensityAdj = shdrSrv.ScalarBlendValue (hsp0->matrData.bwdScatteringIntensityAdj,
                                                                                hsp1->matrData.bwdScatteringIntensityAdj,
                                                                                t,
                                                                                mode);

        /*
         * Widths
         */
        matrData->primaryHighlightLongWidth = shdrSrv.ScalarBlendValue (hsp0->matrData.primaryHighlightLongWidth,
                                                                                hsp1->matrData.primaryHighlightLongWidth,
                                                                                t,
                                                                                mode);
        matrData->secondaryHighlightLongWidth = shdrSrv.ScalarBlendValue (hsp0->matrData.secondaryHighlightLongWidth,
                                                                                        hsp1->matrData.secondaryHighlightLongWidth,
                                                                                        t,
                                                                                        mode);
        matrData->rimLightLongWidth = shdrSrv.ScalarBlendValue (hsp0->matrData.rimLightLongWidth,
                                                                        hsp1->matrData.rimLightLongWidth,
                                                                        t,
                                                                        mode);
        matrData->rimLightAzimuthalWidth = shdrSrv.ScalarBlendValue (hsp0->matrData.rimLightAzimuthalWidth,
                                                                        hsp1->matrData.rimLightAzimuthalWidth,
                                                                        t,
                                                                        mode);
        matrData->glintsFrequency = shdrSrv.ScalarBlendValue (hsp0->matrData.glintsFrequency,
                                                                hsp1->matrData.glintsFrequency,
                                                                t,
                                                                mode);
        matrData->bwdScatteringLongWidthAdj = shdrSrv.ScalarBlendValue (hsp0->matrData.bwdScatteringLongWidthAdj,
                                                                                        hsp1->matrData.bwdScatteringLongWidthAdj,
                                                                                        t,
                                                                                        mode);

        /*
         * Shifts
         */
        matrData->primaryHighlightLongShift = shdrSrv.ScalarBlendValue (hsp0->matrData.primaryHighlightLongShift,
                                                                                hsp1->matrData.primaryHighlightLongShift,
                                                                                t,
                                                                                mode);
        matrData->secondaryHighlightLongShift = shdrSrv.ScalarBlendValue (hsp0->matrData.secondaryHighlightLongShift,
                                                                                hsp1->matrData.secondaryHighlightLongShift,
                                                                                t,
                                                                                mode);
        matrData->rimLightLongShift = shdrSrv.ScalarBlendValue (hsp0->matrData.rimLightLongShift,
                                                                        hsp1->matrData.rimLightLongShift,
                                                                        t,
                                                                        mode);
        matrData->bwdScatteringLongShift = shdrSrv.ScalarBlendValue (hsp0->matrData.bwdScatteringLongShift,
                                                                                hsp1->matrData.bwdScatteringLongShift,
                                                                                t,
                                                                                mode);

        /*
         * Other things
         */
        matrData->densityFactor = shdrSrv.ScalarBlendValue (hsp0->matrData.densityFactor,
                                                                hsp1->matrData.densityFactor,
                                                                t,
                                                                mode);
        matrData->fwdScatteringSaturation = shdrSrv.ScalarBlendValue (hsp0->matrData.fwdScatteringSaturation,
                                                                                hsp1->matrData.fwdScatteringSaturation,
                                                                                t,
                                                                                mode);
        matrData->bwdScatteringSaturation = shdrSrv.ScalarBlendValue (hsp0->matrData.bwdScatteringSaturation,
                                                                                hsp1->matrData.bwdScatteringSaturation,
                                                                                t,
                                                                                mode);
        matrData->globalScatteringSaturation = shdrSrv.ScalarBlendValue (hsp0->matrData.globalScatteringSaturation,
                                                                                hsp1->matrData.globalScatteringSaturation,
                                                                                t,
                                                                                mode);
        matrData->giType = hsp1->matrData.giType;
        matrData->giRays = MAX (hsp0->matrData.giRays, hsp1->matrData.giRays);

        matrData->singleScatteringOn = MAX (hsp0->matrData.singleScatteringOn, hsp1->matrData.singleScatteringOn);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 8/31/11
 *
 * The Hair Material itself.
 *
 *----------------------------------------------------------------------------*/

class HairMaterial : public CLxImpl_CustomMaterial, public CLxImpl_ChannelUI
{
    public:
        HairMaterial () {
                CLxUser_ThreadService	threadService;
                threadService.set();

                threadService.NewMutex(this->precomputeMutex);

                this->isPrecomputed = false;
        }

        static LXtTagInfoDesc	descInfo[];

        /*
         *  Custom Material Interface
         */
        LxResult		cmt_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		cmt_LinkChannels  (ILxUnknownID eval, ILxUnknownID item) LXx_OVERRIDE;
        LxResult		cmt_ReadChannels  (ILxUnknownID attr, void **ppvData) LXx_OVERRIDE;
        LxResult		cmt_CustomPacket  (const char	**) LXx_OVERRIDE;
        void			cmt_MaterialEvaluate (ILxUnknownID vector, void *) LXx_OVERRIDE;
        void			cmt_ShaderEvaluate      (ILxUnknownID vector, ILxUnknownID rayObj, LXpShadeComponents *sCmp, LXpShadeOutput *sOut, void *data) LXx_OVERRIDE;
        void			cmt_Cleanup       (void *data) LXx_OVERRIDE;

        /*
         * Channel UI Interface
         */
        LxResult		cui_Enabled (
                                        const char	*channelName,
                                        ILxUnknownID	 msg,
                                        ILxUnknownID	 item,
                                        ILxUnknownID	 read) LXx_OVERRIDE;

        LxResult		cui_DependencyCount (
                                        const char	*channelName,
                                        unsigned	*count) LXx_OVERRIDE;

        LxResult		cui_DependencyByIndex (
                                        const char	*channelName,
                                        unsigned	 index,
                                        LXtItemType	*depItemType,
                                        const char	**depChannelName) LXx_OVERRIDE;

        static double		GetLongAngle (LXtFVector hairTangent, LXtFVector rayDir);
        static double		GetAzimuthalAngle (LXtFVector hairTangent, LXtFVector rayInDir, LXtFVector rayOutDir);

        void			AdjustMaterialData (HairMaterialData &matrData);
        void			CopyHairPacket (LXpHairShader *sHair, HairMaterialData &target);

        /*
         * This is used just for debugging
         */
        void			PrintHairMaterialData (HairMaterialData *matrData);

        /*
         * Functions to do precomputations
         */

        void			PrecomputeNormFactors (HairMaterialData	*matrData);
        void			PrecomputeaBar_f ();
        void			PrecomputeaBar_b ();
        void			PrecomputeAlphaBar_f ();
        void			PrecomputeAlphaBar_b ();
        void			PrecomputeBetaBar_f ();
        void			PrecomputeBetaBar_b ();
        void			PrecomputeDeltaBar_b ();
        void			PrecomputeSigmaBar_b ();
        void			PrecomputeABar_b ();
        void			PrecomputeNG_R ();
        void			PrecomputeNG_TT ();
        void			PrecomputeNG_TRT ();
        void			PrecomputeShaderTables (HairMaterialData	*matrData);

        /*
         * These are the functions actually used in shading
         */

        void			ComputeGlobalScattering(ILxUnknownID		 vector, 
                                                        ILxUnknownID		 rayObj,
                                                        double			 importance,
                                                        LXtFVector		 rayDir,
                                                        int			 flags,
                                                        HairMaterialData	*matrData,
                                                        LXtVector		*T_f, 
                                                        LXtVector		*sigmaBarSqr_f, 
                                                        double			*directFraction,
                                                        LXtFVector		*shadeColor,
                                                        bool			 gi);
        void			ComputeGlobalScatteringGI(ILxUnknownID		 vector, 
                                                        ILxUnknownID		 rayObj,
                                                        double			 importance,
                                                        LXtFVector		 rayDir,
                                                        int			 flags,
                                                        HairMaterialData	*matrData,
                                                        LXtVector		*T_f, 
                                                        LXtVector		*sigmaBarSqr_f, 
                                                        double			*directFraction,
                                                        LXtFVector		*shadeColor);
        void			ComputeGlobalScatteringShadow(ILxUnknownID	 vector, 
                                                        ILxUnknownID		 rayObj,
                                                        double			 importance,
                                                        LXtFVector		 rayDir,
                                                        int			 flags,
                                                        HairMaterialData	*matrData,
                                                        LXtVector		*T_f, 
                                                        LXtVector		*sigmaBarSqr_f, 
                                                        double			*directFraction);
        void			ComputeFScatter_s (HairMaterialData		*matrData,
                                                        LXtVector		 sigmaBarSqr_f,
                                                        double			 theta_h,
                                                        double			 phi_d,
                                                        LXtVector		 FScatter_s);
        void			ComputeAmbientShading (LXtFVector		 w_i,
                                                        LXtFVector		 hairTangent,
                                                        LXtFVector		 ambientColor,
                                                        LXpShadeComponents	*sCmp);
        void			ComputeShadingForOneRay (LXtVector		 T_f, 
                                                        LXtVector		 sigmaBarSqr_f, 
                                                        double			 directFraction,
                                                        LXtFVector		 hairTangent,
                                                        LXtFVector		 w_i,
                                                        LXtFVector		 w_o,
                                                        double			 gAngle,
                                                        HairMaterialData	*matrData,
                                                        LXpShadeComponents	*sCmp);
        void			ComputeDirectShading (ILxUnknownID		 vector,
                                                        ILxUnknownID		 rayObj,
                                                        HairMaterialData	*matrData,
                                                        LXpShadeComponents	*sCmp);
        void			ComputeIndirectShading (ILxUnknownID		 vector,
                                                        ILxUnknownID		 rayObj,
                                                        HairMaterialData	*matrData,
                                                        LXpShadeComponents	*sCmp);

        // We use a mutex so that multiple threads don't precompute the tables
        // at once
        CLxLoc_ThreadMutex	precomputeMutex;

        /*
         * Functions to compute portions of the BSDF
         */

        double			M_R (double theta_h);
        double			M_TT (double theta_h);
        double			M_TRT (double theta_h);
        double			MG_R (double theta_h, double sigma);
        double			MG_TT (double theta_h, double sigma);
        double			MG_TRT (double theta_h, double sigma);
        double			N_R (double Phi);
        double			N_TT (double Phi);
        double			N_TRT (double Phi);
        double			N_GLINTS (double Phi, double gAngle);

        void			fPrime_s (double thetaIn, double thetaOut, 
                                        double phiIn, double phiOut, 
                                        double gAngle, HairMaterialData	*matrData, 
                                        LXtVector *outColor);
        void			fPrime_s (double thetaIn, double thetaOut, 
                                        double phiDiff, double gAngle, 
                                        HairMaterialData *matrData,
                                        LXtVector *outColor);
        void			fPrime_sNoGlints (double thetaIn, double thetaOut, 
                                        double phiIn, double phiOut, HairMaterialData *matrData,
                                        LXtVector *outColor);
        void			fPrime_sNoGlints (double thetaIn, double thetaOut, 
                                        double phiDiff, HairMaterialData *matrData,
                                        LXtVector *outColor);

        /*
         * Functions to lookup values in precomputed tables
         */

        double			lookupNormFactor (double thetaIn);
        void			lookupNormFactor (double theta_in, LXtVector *outColor);

        void			lookupValue (double theta, LXtVector *table, LXtVector *outColor);

        void			lookupaBar_f (double theta_in, LXtVector *outColor);
        void			lookupaBar_b (double theta_in, LXtVector *outColor);
        void			lookupAlphaBar_f (double theta_h, LXtVector *outColor);
        void			lookupAlphaBar_b (double theta_h, LXtVector *outColor);
        void			lookupBetaBar_f (double theta_h, LXtVector *outColor);
        void			lookupBetaBar_b (double theta_h, LXtVector *outColor);
        void			lookupDeltaBar_b (double theta_h, LXtVector *outColor);
        void			lookupSigmaBar_b (double theta_h, LXtVector *outColor);
        void			lookupABar_b (double theta_h, LXtVector *outColor);

        void			ClearShadeComponents (LXpShadeComponents *sCmp);

        bool			isPrecomputed;

        // These are the precomputed tables the shader uses
        LXtVector		normFactors[TABLE_ENTRIES];
        LXtVector		aBar_f[TABLE_ENTRIES];
        LXtVector		aBar_b[TABLE_ENTRIES];
        LXtVector		AlphaBar_f[TABLE_ENTRIES];
        LXtVector		AlphaBar_b[TABLE_ENTRIES];
        LXtVector		BetaBar_f[TABLE_ENTRIES];
        LXtVector		BetaBar_b[TABLE_ENTRIES];
        LXtVector		DeltaBar_b[TABLE_ENTRIES];
        LXtVector		SigmaBar_b[TABLE_ENTRIES];
        LXtVector		ABar_b[TABLE_ENTRIES];

        // In the artist-friendly system, these are constant values
        LXtVector		NG_R;
        LXtVector		NG_TT;
        LXtVector		NG_TRT;

        HairMaterialData	matrData;
                
        LXtItemType		my_type; 
        LXtItemType		MyType ();

        unsigned                idx[40];     // indices to each data channel in RendData

        CLxUser_PacketService	pkt_service;
        
        unsigned		ray_offset, lcol_offset, nrm_offset, 
                                pos_offset, shade_opacity_offset, 
                                pix_offset, particle_sample_offset,
                                shade_flags_offset, global_indirect_offset, 
                                pkt_offset, global_lighting_offset;
};

#define SRVs_HAIR_MATR		"hairMaterial"
#define SRVs_HAIR_MATR_ITEMTYPE	"material." SRVs_HAIR_MATR

LXtTagInfoDesc	 HairMaterial::descInfo[] = {
        { LXsSRV_USERNAME,	"Hair Material" },
        { LXsSRV_LOGSUBSYSTEM,	"comp-shader"	},
        { 0 }
};

const char* HAIR_MATERIAL_GI_TYPE = "gi";
const char* HAIR_MATERIAL_GI_RAYS = "giRays";

static LXtTextValueHint hint_PercentRange[] = {
        0,			"%min",		// float min 0.0
        -1,			NULL
        };

        LxResult
HairMaterial::cmt_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        LXtVector defaultPrimColor = {.98, .92, .85};
        LXtVector defaultSecColor = {.53, .35, .17};
        LXtVector defaultRimColor = {.86, .54, .34};
        LXtVector defaultGlintColor = {.99, .75, .5};
        LXtVector white = {1.0, 1.0, 1.0};
     
        ac.NewChannel ("primHLCol", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (defaultPrimColor);

        ac.NewChannel ("primHLIntensity", LXsTYPE_PERCENT);
        ac.SetDefault (.6, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("primHLLongWidth", LXsTYPE_PERCENT);
        ac.SetDefault (.03, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("primHLLongShift", LXsTYPE_PERCENT);
        ac.SetDefault (-.025, 0);

        ac.NewChannel ("secHLCol", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (defaultSecColor);

        ac.NewChannel ("secHLIntensity", LXsTYPE_PERCENT);
        ac.SetDefault (.2, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("secHLLongWidth", LXsTYPE_PERCENT);
        ac.SetDefault (.2, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("secHLLongShift", LXsTYPE_PERCENT);
        ac.SetDefault (-.1, 0);

        ac.NewChannel ("rimCol", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (defaultRimColor);

        ac.NewChannel ("rimIntensity", LXsTYPE_PERCENT);
        ac.SetDefault (.35, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("rimLongWidth", LXsTYPE_PERCENT);
        ac.SetDefault (.5, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("rimLongShift", LXsTYPE_PERCENT);
        ac.SetDefault (-.05, 0);

        ac.NewChannel ("rimAzWidth", LXsTYPE_PERCENT);
        ac.SetDefault (.5, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("glintsCol", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (defaultGlintColor);

        ac.NewChannel ("glintsIntensity", LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("glintsFreq", LXsTYPE_PERCENT);
        ac.SetDefault (.001, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("fsColAdj", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (white);

        ac.NewChannel ("fsIntAdj", LXsTYPE_FLOAT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel ("fsSat", LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("bsColAdj", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (white);

        ac.NewChannel ("bsIntAdj", LXsTYPE_FLOAT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel ("bsSat", LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);
        ac.SetHint (hint_PercentRange);

        ac.NewChannel ("bsLongWidthAdj", LXsTYPE_PERCENT);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("bsLongShift", LXsTYPE_PERCENT);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("gsSat", LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel (HAIR_MATERIAL_GI_TYPE, LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 3);
        ac.SetHint (hint_giType);

        ac.NewChannel (HAIR_MATERIAL_GI_RAYS, LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 64);

        ac.NewChannel ("singleScattering", LXsTYPE_BOOLEAN);
        ac.SetDefault (0.0, 1);

        return LXe_OK;
}

/*
 * Attach to channel evaluations.
 * This gets the indices for the channels in attributes.
 */
        LxResult
HairMaterial::cmt_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);

        int index = 0;

        idx[index++] = ev.AddChan (item, "primHLCol.R");
        idx[index++] = ev.AddChan (item, "primHLCol.G");	
        idx[index++] = ev.AddChan (item, "primHLCol.B");
        idx[index++] = ev.AddChan (item, "primHLIntensity");
        idx[index++] = ev.AddChan (item, "primHLLongWidth");
        idx[index++] = ev.AddChan (item, "primHLLongShift"); //6

        idx[index++] = ev.AddChan (item, "secHLCol.R");
        idx[index++] = ev.AddChan (item, "secHLCol.G");	
        idx[index++] = ev.AddChan (item, "secHLCol.B");
        idx[index++] = ev.AddChan (item, "secHLIntensity");
        idx[index++] = ev.AddChan (item, "secHLLongWidth");
        idx[index++] = ev.AddChan (item, "secHLLongShift"); //12

        idx[index++] = ev.AddChan (item, "rimCol.R");
        idx[index++] = ev.AddChan (item, "rimCol.G");	
        idx[index++] = ev.AddChan (item, "rimCol.B");
        idx[index++] = ev.AddChan (item, "rimIntensity");
        idx[index++] = ev.AddChan (item, "rimLongWidth");
        idx[index++] = ev.AddChan (item, "rimLongShift");
        idx[index++] = ev.AddChan (item, "rimAzWidth"); //19

        idx[index++] = ev.AddChan (item, "glintsCol.R");
        idx[index++] = ev.AddChan (item, "glintsCol.G");	
        idx[index++] = ev.AddChan (item, "glintsCol.B");
        idx[index++] = ev.AddChan (item, "glintsIntensity");
        idx[index++] = ev.AddChan (item, "glintsFreq"); //24

        idx[index++] = ev.AddChan (item, "fsColAdj.R");
        idx[index++] = ev.AddChan (item, "fsColAdj.G");	
        idx[index++] = ev.AddChan (item, "fsColAdj.B");
        idx[index++] = ev.AddChan (item, "fsIntAdj"); //28
        idx[index++] = ev.AddChan (item, "fsSat");
        
        idx[index++] = ev.AddChan (item, "bsColAdj.R");
        idx[index++] = ev.AddChan (item, "bsColAdj.G");	
        idx[index++] = ev.AddChan (item, "bsColAdj.B");
        idx[index++] = ev.AddChan (item, "bsIntAdj");
        idx[index++] = ev.AddChan (item, "bsLongWidthAdj");
        idx[index++] = ev.AddChan (item, "bsLongShift"); //35
        idx[index++] = ev.AddChan (item, "bsSat");

        idx[index++] = ev.AddChan (item, "gsSat");

        idx[index++] = ev.AddChan (item, "gi"); //38
        idx[index++] = ev.AddChan (item, "giRays"); //39

        idx[index++] = ev.AddChan (item, "singleScattering"); //40

        ray_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_RAY);
        nrm_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SURF_NORMAL);
        pos_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_POSITION);
        shade_opacity_offset	= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SHADE_OPACITY);
        particle_sample_offset	= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_PARTICLE_SAMPLE);
        shade_flags_offset	= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SHADE_FLAGS);
        global_indirect_offset	= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_GLO_INDIRECT);
        global_lighting_offset	= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_GLO_LIGHTING);
        pkt_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_HAIRSHADER);

        return LXe_OK;
}

/*
 * Read channel values which may have changed.
 */
        LxResult
HairMaterial::cmt_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        HairMaterialData*       md = new HairMaterialData;
        HairMaterialData	adjustedData;

        int			index = 0;

        bool			changed = false;

        for (int i = 0; i < 3; i++)
                md->primaryHighlightColor[i]	= at.Float(idx[index++]);
        md->primaryHighlightIntensity		= at.Float(idx[index++]);
        md->primaryHighlightLongWidth		= at.Float(idx[index++]);
        md->primaryHighlightLongShift		= at.Float(idx[index++]); //6

        for (int i = 0; i < 3; i++)
                md->secondaryHighlightColor[i]	= at.Float(idx[index++]);
        md->secondaryHighlightIntensity		= at.Float(idx[index++]);
        md->secondaryHighlightLongWidth		= at.Float(idx[index++]);
        md->secondaryHighlightLongShift		= at.Float(idx[index++]); //12

        for (int i = 0; i < 3; i++)
                md->rimLightColor[i]		= at.Float(idx[index++]);
        md->rimLightIntensity			= at.Float(idx[index++]);
        md->rimLightLongWidth			= at.Float(idx[index++]);
        md->rimLightLongShift			= at.Float(idx[index++]);
        md->rimLightAzimuthalWidth		= at.Float(idx[index++]); //19
        
        for (int i = 0; i < 3; i++)
                md->glintsColor[i]		= at.Float(idx[index++]);
        md->glintsIntensity			= at.Float(idx[index++]);
        md->glintsFrequency			= at.Float(idx[index++]); //24

        for (int i = 0; i < 3; i++)
                md->fwdScatteringColorAdj[i]	= at.Float(idx[index++]);
        md->fwdScatteringIntensityAdj		= at.Float(idx[index++]); //28
        md->fwdScatteringSaturation		= at.Float(idx[index++]);

        for (int i = 0; i < 3; i++)
                md->bwdScatteringColorAdj[i]	= at.Float(idx[index++]);
        md->bwdScatteringIntensityAdj		= at.Float(idx[index++]);
        md->bwdScatteringLongWidthAdj		= at.Float(idx[index++]);
        md->bwdScatteringLongShift		= at.Float(idx[index++]); 
        md->bwdScatteringSaturation		= at.Float(idx[index++]); //36

        md->globalScatteringSaturation		= at.Float(idx[index++]);

        md->giType				= at.Int (idx[index++]); //38
        md->giRays				= at.Int (idx[index++]); //39

        md->singleScatteringOn			= at.Int (idx[index++]); //40

        // Since the widths represent variances, by squaring the input value we make
        // the input values std. deviations, which are more intuitive
        md->primaryHighlightLongWidth		*= md->primaryHighlightLongWidth;
        md->secondaryHighlightLongWidth		*= md->secondaryHighlightLongWidth;
        md->rimLightLongWidth			*= md->rimLightLongWidth;
        md->rimLightAzimuthalWidth		*= md->rimLightAzimuthalWidth;
        md->bwdScatteringLongWidthAdj		*= md->bwdScatteringLongWidthAdj;

        /*
         * Now we need to see if anything has changed
         */

        adjustedData = *md;
        AdjustMaterialData(adjustedData);

        for (int i = 0; i < 3; i++)
                changed |= (adjustedData.primaryHighlightColor[i] != this->matrData.primaryHighlightColor[i]);
        changed |= (adjustedData.primaryHighlightIntensity != this->matrData.primaryHighlightIntensity);
        changed |= (adjustedData.primaryHighlightLongWidth != this->matrData.primaryHighlightLongWidth);
        changed |= (adjustedData.primaryHighlightLongShift != this->matrData.primaryHighlightLongShift);

        for (int i = 0; i < 3; i++)
                changed |= (adjustedData.secondaryHighlightColor[i] != this->matrData.secondaryHighlightColor[i]);
        changed |= (adjustedData.secondaryHighlightIntensity != this->matrData.secondaryHighlightIntensity);
        changed |= (adjustedData.secondaryHighlightLongWidth != this->matrData.secondaryHighlightLongWidth);
        changed |= (adjustedData.secondaryHighlightLongShift != this->matrData.secondaryHighlightLongShift);

        for (int i = 0; i < 3; i++)
                changed |= (adjustedData.rimLightColor[i] != this->matrData.rimLightColor[i]);
        changed |= (adjustedData.rimLightIntensity != this->matrData.rimLightIntensity);
        changed |= (adjustedData.rimLightLongWidth != this->matrData.rimLightLongWidth);
        changed |= (adjustedData.rimLightLongShift != this->matrData.rimLightLongShift);
        changed |= (adjustedData.rimLightAzimuthalWidth != this->matrData.rimLightAzimuthalWidth);

        for (int i = 0; i < 3; i++)
                changed |= (adjustedData.glintsColor[i] != this->matrData.glintsColor[i]);
        changed |= (adjustedData.glintsIntensity != this->matrData.glintsIntensity);
        changed |= (adjustedData.glintsFrequency != this->matrData.glintsFrequency);

        changed |= (adjustedData.fwdScatteringIntensityAdj != this->matrData.fwdScatteringIntensityAdj);

        changed |= (adjustedData.bwdScatteringIntensityAdj != this->matrData.bwdScatteringIntensityAdj);
        changed |= (adjustedData.bwdScatteringLongWidthAdj != this->matrData.bwdScatteringLongWidthAdj);
        changed |= (adjustedData.bwdScatteringLongShift != this->matrData.bwdScatteringLongShift);

        if (changed) {
                this->precomputeMutex.Enter();
                this->matrData = adjustedData;
                this->isPrecomputed = false;
                this->precomputeMutex.Leave();
        }

        ppvData[0] = md;
        return LXe_OK;
}

        LxResult
HairMaterial::cmt_CustomPacket (
        const char		**packet)
{
        packet[0] = LXsP_SAMPLE_HAIRSHADER;
        return LXe_OK;
}

        /*
 * These are used to set up the channel dependencies so that hair GI is
 * disabled if GI is disabled, and the rays is disabled unless hair GI
 * casting is enabled
 */

const char* HAIR_MATERIAL_MSG_TABLE = "material.hairMaterial";

const unsigned HAIR_MATERIAL_GI_RAYS_ENABLED = 1001;
const unsigned HAIR_MATERIAL_GI_ENABLED = 1002;

        LxResult
HairMaterial::cui_Enabled (
        const char	*channelName,
        ILxUnknownID	 msg,
        ILxUnknownID	 item,
        ILxUnknownID	 read)
{
        LxResult		result = LXe_OK;
        CLxUser_SceneService	svc;
        CLxUser_Scene		scene;
        CLxUser_Item		src (item);
        CLxUser_Item		rndr;

        LXtItemType		renderType = svc.ItemType (LXsITYPE_POLYRENDER);

        src.GetContext (scene);
        scene.GetItem (renderType, 0, rndr);

        if ((strcmp (channelName, HAIR_MATERIAL_GI_RAYS) == 0)){
                
                CLxUser_ChannelRead	 chan (read);

                int giType = chan.IValue (src, HAIR_MATERIAL_GI_TYPE);
                bool giEnabled = chan.IValue (rndr, LXsICHAN_RENDER_GLOBENABLE);
                if (!giEnabled) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (HAIR_MATERIAL_MSG_TABLE, HAIR_MATERIAL_GI_ENABLED);

                        result = LXe_CMD_DISABLED;
                }
                else if (giType == 0 || giType == 2) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (HAIR_MATERIAL_MSG_TABLE, HAIR_MATERIAL_GI_RAYS_ENABLED);

                        result = LXe_CMD_DISABLED;
                }
        }
        else if ((strcmp (channelName, HAIR_MATERIAL_GI_TYPE) == 0)){
                
                CLxUser_ChannelRead	 chan (read);

                bool giEnabled = chan.IValue (rndr, LXsICHAN_RENDER_GLOBENABLE);
                if (!giEnabled) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (HAIR_MATERIAL_MSG_TABLE, HAIR_MATERIAL_GI_ENABLED);

                        result = LXe_CMD_DISABLED;
                }
        }

        return result;
}

        LxResult
HairMaterial::cui_DependencyCount (
        const char	*channelName,
        unsigned	*count)
{
        if ((strcmp (channelName, HAIR_MATERIAL_GI_RAYS) == 0) || 
                (strcmp (channelName, HAIR_MATERIAL_GI_TYPE) == 0)) {
                count[0] = 1;
        }
        else {
                count[0] = 0;
        }

        return LXe_OK;
}

        LxResult
HairMaterial::cui_DependencyByIndex (
        const char	*channelName,
        unsigned	 index,
        LXtItemType	*depItemType,
        const char	**depChannelName)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if ((strcmp (channelName, HAIR_MATERIAL_GI_RAYS) == 0)) {
                depItemType[0] = MyType ();
                switch (index) {
                    case 0:
                        depChannelName[0] = HAIR_MATERIAL_GI_TYPE;
                        result = LXe_OK;
                        break;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }
        else if ((strcmp (channelName, HAIR_MATERIAL_GI_TYPE) == 0)) {
                depItemType[0] = MyType ();
                switch (index) {
                    case 0:
                        depChannelName[0] = HAIR_MATERIAL_GI_TYPE;
                        result = LXe_OK;
                        break;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }

        return result;
}

/*
 * Evaluate the color at a spot.
 */
        void
HairMaterial::cmt_MaterialEvaluate (
        ILxUnknownID            vector,
        void			*data)
{
        LXpHairShader		*sHair = (LXpHairShader*) pkt_service.FastPacket (vector, pkt_offset);
        HairMaterialData*        md = (HairMaterialData*)data;

        // Copy the hair shader settings 
        sHair->matrData = *md;
}

        void
HairMaterial::cmt_Cleanup (
        void			*data)
{
        HairMaterialData*       md = (HairMaterialData*)data;

        delete md;
}


        LXtItemType
HairMaterial::MyType ()
{
        if (my_type != LXiTYPE_NONE)
                return my_type;

        CLxUser_SceneService	 svc;

        my_type = svc.ItemType (SRVs_HAIR_MATR_ITEMTYPE);
        return my_type;
}

/*------------------------------- Luxology LLC --------------------------------
 *
 * These are some ad-hoc adjustments to make the values more intuitive
 *
 *----------------------------------------------------------------------------*/
        void
HairMaterial::AdjustMaterialData (
        HairMaterialData	&matrData)
{
        matrData.primaryHighlightIntensity *= .5;
        matrData.secondaryHighlightIntensity *= .5;
        matrData.rimLightIntensity *= .5;

        matrData.primaryHighlightLongShift *= -1.0;
        matrData.secondaryHighlightLongShift *= -1.0;
        matrData.rimLightLongShift *= -1.0;
        matrData.bwdScatteringLongShift *= -1.0;
        matrData.glintsFrequency *= .1;
}
/*------------------------------- Luxology LLC --------------------------------
 *
 * This function copies all the values over from the hair packet, and determines
 * whether something has changed
 *
 *----------------------------------------------------------------------------*/
        void
HairMaterial::CopyHairPacket (
        LXpHairShader		*sHair,
        HairMaterialData	&target)
{
        int			 index = 0;

        double			 newVal;

        bool			 changed = false;

        HairMaterialData	 matrData;

        matrData = sHair->matrData;

        AdjustMaterialData (matrData);

        changed |= (this->matrData.primaryHighlightIntensity != matrData.primaryHighlightIntensity);
        changed |= (this->matrData.primaryHighlightLongWidth != matrData.primaryHighlightLongWidth);
        changed |= (this->matrData.primaryHighlightLongShift != matrData.primaryHighlightLongShift);

        changed |= (this->matrData.secondaryHighlightIntensity != matrData.secondaryHighlightIntensity);
        changed |= (this->matrData.secondaryHighlightLongWidth != matrData.secondaryHighlightLongWidth);
        changed |= (this->matrData.secondaryHighlightLongShift != matrData.secondaryHighlightLongShift);

        changed |= (this->matrData.rimLightIntensity != matrData.rimLightIntensity);
        changed |= (this->matrData.rimLightLongWidth != matrData.rimLightLongWidth);
        changed |= (this->matrData.rimLightLongShift != matrData.rimLightLongShift);
        changed |= (this->matrData.rimLightAzimuthalWidth != matrData.rimLightAzimuthalWidth);

        changed |= (this->matrData.secondaryHighlightIntensity != matrData.secondaryHighlightIntensity);
        changed |= (this->matrData.secondaryHighlightLongWidth != matrData.secondaryHighlightLongWidth);
        changed |= (this->matrData.secondaryHighlightLongShift != matrData.secondaryHighlightLongShift);

        changed |= (this->matrData.glintsIntensity != matrData.glintsIntensity);
        changed |= (this->matrData.glintsFrequency != matrData.glintsFrequency);

        changed |= (this->matrData.fwdScatteringIntensityAdj != matrData.fwdScatteringIntensityAdj);

        changed |= (this->matrData.bwdScatteringIntensityAdj != matrData.bwdScatteringIntensityAdj);
        changed |= (this->matrData.bwdScatteringLongWidthAdj != matrData.bwdScatteringLongWidthAdj);
        changed |= (this->matrData.bwdScatteringLongShift != matrData.bwdScatteringLongShift);

        target = matrData;

        if (changed) {
                this->precomputeMutex.Enter();
                this->matrData = matrData;
                this->isPrecomputed = false;
                this->precomputeMutex.Leave();
        }
}

/*------------------------------- Luxology LLC --------------------------------
 *
 * Useful utilities
 *
 *----------------------------------------------------------------------------*/

        static double
FVectorNormalize (
        LXtFVector		v) 
{
        double		m, p;
        m = LXx_VDOT (v, v);
        if(m<=0)
                return -1;
        m = sqrt (m);
        p = 1.0 / m;
        LXx_VSCL (v, p);
        return m;
}

        static double
UnitAreaGaussian (
        double			variance,
        double			x)
{
        if (variance <= 0.0)
                return 0.0;

        return exp (-(x*x/(2 * variance))) / (sqrtf (2.0 * LXx_PI * variance));
}

        static double
UnitHeightGaussian (
        double			variance,
        double			x)
{
        if (variance <= 0.0)
                return 0.0;

        return exp (-(x*x/(2 * variance)));
}

        double
HairMaterial::GetLongAngle (
        LXtFVector		hairTangent,
        LXtFVector		rayDir)
{
        double			dot, angle, tanLen, outLen;

        tanLen = LXx_VLEN (hairTangent);
        outLen = LXx_VLEN (rayDir);

        if (outLen > .001 && tanLen > .001) {
                dot = LXx_VDOT (hairTangent, rayDir) / (tanLen * outLen);
                dot = CLAMP (dot, -1.0, 1.0);
        }
        else {
                dot = 0.0;
        }

        angle = acos(dot);

        return angle - LXx_HALFPI;
}

        double
HairMaterial::GetAzimuthalAngle (
        LXtFVector		hairTangent,
        LXtFVector		rayInDir,
        LXtFVector		rayOutDir)
{
        double			dot, angle, inLen, outLen;

        LXtFVector		crossIn, crossOut;

        LXx_VCROSS (crossIn, hairTangent, rayInDir);
        LXx_VCROSS (crossOut, hairTangent, rayOutDir);

        inLen = LXx_VLEN (crossIn);
        outLen = LXx_VLEN (crossOut);

        if (inLen > .001 && outLen > .001) {
                dot = LXx_VDOT (crossIn, crossOut) / (inLen * outLen);
                dot = CLAMP (dot, -1.0, 1.0);
        }
        else {
                dot = 0.0;
        }
        return acos(dot);
}

        void
Desaturate (
        LXtVector		color,
        double			saturation)
{
        double avgValue;
        LXtVector avgColor;

        avgValue = (color[0] + color[1] + color[2])/3.0;
        LXx_VSET (avgColor, avgValue);
        LXx_VLERP (color, avgColor, color, saturation);
}

/*------------------------------- Luxology LLC ---------------------------
 *
 * Functions to compute factors of the BSDF
 *
 *----------------------------------------------------------------------------*/
        double
HairMaterial::M_R (
        double			 theta_h)
{
        return UnitHeightGaussian (this->matrData.primaryHighlightLongWidth,
                                        theta_h - this->matrData.primaryHighlightLongShift);
}

        double
HairMaterial::M_TT (
        double			 theta_h)
{
        return UnitHeightGaussian (this->matrData.rimLightLongWidth,
                                        theta_h - this->matrData.rimLightLongShift);
}

        double
HairMaterial::M_TRT (
        double			 theta_h)
{
        return UnitHeightGaussian	(this->matrData.secondaryHighlightLongWidth,
                                        theta_h - this->matrData.secondaryHighlightLongShift);
}

        double
HairMaterial::MG_R (
        double			 theta_h,
        double			 sigma)
{
        return UnitHeightGaussian	(this->matrData.primaryHighlightLongWidth + sigma,
                                        theta_h - this->matrData.primaryHighlightLongShift);
}

        double
HairMaterial::MG_TT (
        double			 theta_h,
        double			 sigma)
{
        return UnitHeightGaussian	(this->matrData.rimLightLongWidth + sigma,
                                        theta_h - this->matrData.rimLightLongShift);
}

        double
HairMaterial::MG_TRT (
        double			 theta_h,
        double			 sigma)
{
        return UnitHeightGaussian	(this->matrData.secondaryHighlightLongWidth + sigma,
                                        theta_h - this->matrData.secondaryHighlightLongShift);
}

        double
HairMaterial::N_R (
        double			 Phi)
{
        Phi = abs(Phi);
        Phi = Phi > LXx_PI ? 2 * LXx_PI - Phi : Phi;
        return MAX(0.0, cos (Phi/2.0));
}

/*
 * N_TT is slightly different than in the papers - I introduce the cosine 
 * factor to lessen backscattering
 */

        double
HairMaterial::N_TT (
        double			 Phi)
{
        double g;

        Phi = abs(Phi);
        Phi = Phi > LXx_PI ? 2 * LXx_PI - Phi : Phi;
        Phi = LXx_PI - Phi; // Reverse the orientation

        g = UnitHeightGaussian (this->matrData.rimLightAzimuthalWidth, Phi);
        Phi *= 2;
        Phi = Phi > LXx_PI ? LXx_PI : Phi;

        return (g * MAX (0.0, .5 + .5 * cos (Phi)));
}

        double
HairMaterial::N_TRT (
        double			 Phi)
{
        Phi = abs(Phi);
        Phi = Phi > LXx_PI ? 2 * LXx_PI - Phi : Phi;
        return MAX(0.0, cos (Phi/2.0));
}

        double
HairMaterial::N_GLINTS (
        double			Phi,
        double			gAngle)
{
        Phi = abs(Phi);
        Phi = Phi > LXx_PI ? 2 * LXx_PI - Phi : Phi;
        return (UnitHeightGaussian (this->matrData.glintsFrequency, gAngle - Phi));
}

        void
HairMaterial::fPrime_s (
        double			thetaIn,
        double			thetaOut,
        double			phiIn,
        double			phiOut,
        double			gAngle,
        HairMaterialData	*matrData,
        LXtVector		*outColor)
{
        // fPrime_s is our BCSDF, taken from "An Artist Friendly Hair Shading System"
        LXtVector tempColor;
        double theta_D = (thetaOut - thetaIn)/2.0;
        double theta_H = (thetaOut + thetaIn)/2.0;
        double phi_D = (phiOut - phiIn);
        double phi_H = (phiOut + phiIn)/2.0;

        double cosTheta = cos (theta_D);
        double cosTheta2 = cosTheta * cosTheta;


        if (phi_D < 0) {
                phi_D = abs (phi_D);
        }
        if (phi_D > LXx_PI) {
                phi_D = 2.0 * LXx_PI - phi_D;
        }

        LXx_VCLR(*outColor);

        LXx_VCPY(tempColor, matrData->primaryHighlightColor);
        LXx_VSCL(tempColor, this->N_R (phi_D));
        LXx_VSCL(tempColor, this->M_R (theta_H));
        LXx_VSCL(tempColor, matrData->primaryHighlightIntensity);
        LXx_VADD(*outColor, tempColor);
        
        LXx_VCPY(tempColor, matrData->secondaryHighlightColor);
        LXx_VSCL(tempColor, this->N_TRT (phi_D));
        LXx_VSCL(tempColor, this->M_TRT (theta_H));
        LXx_VSCL(tempColor, matrData->secondaryHighlightIntensity);
        LXx_VADD(*outColor, tempColor);

        LXx_VCPY(tempColor, matrData->glintsColor);
        LXx_VSCL(tempColor, this->N_GLINTS (phi_D, gAngle));
        LXx_VSCL(tempColor, this->M_TRT (theta_H));
        LXx_VSCL(tempColor, matrData->glintsIntensity);
        // This is in the paper, but it's unintuitive so I'm taking it out
        // LXx_VSCL(tempColor, matrData->secondaryHighlightIntensity); 
        LXx_VADD(*outColor, tempColor);

        LXx_VCPY(tempColor, matrData->rimLightColor);
        LXx_VSCL(tempColor, this->N_TT (phi_D));
        LXx_VSCL(tempColor, this->M_TT (theta_H));
        LXx_VSCL(tempColor, matrData->rimLightIntensity);
        LXx_VADD(*outColor, tempColor);

        LXx_VSCL(*outColor, 1.0/cosTheta2);
}

        void
HairMaterial::fPrime_sNoGlints (
        double			thetaIn,
        double			thetaOut,
        double			phiIn,
        double			phiOut,
        HairMaterialData	*matrData,
        LXtVector		*outColor)
{
        // fPrime_s is our BCSDF, taken from "An Artist Friendly Hair Shading System"
        LXtVector tempColor;
        double theta_D = (thetaOut - thetaIn)/2.0;
        double theta_H = (thetaOut + thetaIn)/2.0;
        double phi_D = (phiOut - phiIn);
        double phi_H = (phiOut + phiIn)/2.0;

        double cosTheta = cos (theta_D);
        double cosTheta2 = cosTheta * cosTheta;


        if (phi_D < 0) {
                phi_D = abs (phi_D);
        }
        if (phi_D > LXx_PI) {
                phi_D = 2.0 * LXx_PI - phi_D;
        }

        LXx_VCLR(*outColor);

        LXx_VCPY(tempColor, matrData->primaryHighlightColor);
        LXx_VSCL(tempColor, this->N_R (phi_D));
        LXx_VSCL(tempColor, this->M_R (theta_H));
        LXx_VSCL(tempColor, matrData->primaryHighlightIntensity);
        LXx_VADD(*outColor, tempColor);
        
        LXx_VCPY(tempColor, matrData->secondaryHighlightColor);
        LXx_VSCL(tempColor, this->N_TRT (phi_D));
        LXx_VSCL(tempColor, this->M_TRT (theta_H));
        LXx_VSCL(tempColor, matrData->secondaryHighlightIntensity);
        LXx_VADD(*outColor, tempColor);

        LXx_VCPY(tempColor, matrData->rimLightColor);
        LXx_VSCL(tempColor, this->N_TT (phi_D));
        LXx_VSCL(tempColor, this->M_TT (theta_H));
        LXx_VSCL(tempColor, matrData->rimLightIntensity);
        LXx_VADD(*outColor, tempColor);

        LXx_VSCL(*outColor, 1.0/cosTheta2);
}

        void
HairMaterial::fPrime_s (
        double			thetaIn,
        double			thetaOut,
        double			phiDiff,
        double			gAngle,
        HairMaterialData	*matrData,
        LXtVector		*outColor)
{
        /*
         * Phi in and Phi out for the BSDF don't actually matter, just the difference,
         * since we assume hairs have circular cross-sections. So this function acts
         * as a wrapper for the version that takes in the input and output Phis.
         */
        this->fPrime_s(thetaIn, thetaOut, 0.0, phiDiff, gAngle, matrData, outColor);
}

        void
HairMaterial::fPrime_sNoGlints (
        double			thetaIn,
        double			thetaOut,
        double			phiDiff,
        HairMaterialData	*matrData,
        LXtVector		*outColor)
{
        /*
         * Phi in and Phi out for the BSDF don't actually matter, just the difference,
         * since we assume hairs have circular cross-sections. So this function acts
         * as a wrapper for the version that takes in the input and output Phis.
         */
        this->fPrime_sNoGlints(thetaIn, thetaOut, 0.0, phiDiff, matrData, outColor);
}

/*------------------------------- Luxology LLC ---------------------------
 *
 * Precomputation Functions
 *
 *----------------------------------------------------------------------------*/

        void
HairMaterial::PrintHairMaterialData (HairMaterialData *matrData)
{
        CLxUser_LogService log_S;

        log_S.DebugOut (LXi_DBLOG_NORMAL, "Hair Material Data: \n");
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Primary Hightlight Color: (%f, %f, %f) \n", 
                                                matrData->primaryHighlightColor[0],
                                                matrData->primaryHighlightColor[1],
                                                matrData->primaryHighlightColor[2]);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Primary Hightlight Intensity: %f \n", 
                                                matrData->primaryHighlightIntensity);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Primary Hightlight Long Width: %f \n", 
                                                matrData->primaryHighlightLongWidth);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Primary Hightlight Long Shift: %f \n", 
                                                matrData->primaryHighlightLongShift);

        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Secondary Hightlight Color: (%f, %f, %f) \n", 
                                                matrData->secondaryHighlightColor[0],
                                                matrData->secondaryHighlightColor[1],
                                                matrData->secondaryHighlightColor[2]);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Secondary Hightlight Intensity: %f \n", 
                                                matrData->secondaryHighlightIntensity);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Secondary Hightlight Long Width: %f \n", 
                                                matrData->secondaryHighlightLongWidth);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Secondary Hightlight Long Shift: %f \n", 
                                                matrData->secondaryHighlightLongShift);

        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Rimlight Color: (%f, %f, %f) \n", 
                                                matrData->rimLightColor[0],
                                                matrData->rimLightColor[1],
                                                matrData->rimLightColor[2]);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Rimlight Intensity: %f \n", 
                                                matrData->rimLightIntensity);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Rimlight Long Width: %f \n", 
                                                matrData->rimLightLongWidth);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Rimlight Shift: %f \n", 
                                                matrData->rimLightLongShift);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Rimlight Azimuthal Width: %f \n", 
                                                matrData->rimLightAzimuthalWidth);

        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Glints Color: (%f, %f, %f) \n", 
                                                matrData->glintsColor[0],
                                                matrData->glintsColor[1],
                                                matrData->glintsColor[2]);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Glints Intensity: %f \n", 
                                                matrData->glintsIntensity);
        log_S.DebugOut (LXi_DBLOG_NORMAL, "\t Glints Frequency: %f \n", 
                                                matrData->glintsFrequency);
}
        

        void
HairMaterial::PrecomputeNormFactors(HairMaterialData *matrData)
{
        // In order to make sure the artist-friendly model is energy conserving for backward
        // scattering, we need to compute the normalization factors for every possible incoming
        // Long inclination. See "An Artist Friendly Hair Shading System" equation 13
        double thetaOutf, phiDiffF, thetaInf, phiInf, sinThetaOut, v;
        LXtVector tempColor;

        double sclAmount = 8.0 * LXx_PI / (INTEGRAL_SAMPLES * INTEGRAL_SAMPLES);

        // We need to compute the normalization factor for each possible in-direction
        for (int i = 0; i < TABLE_ENTRIES; i++) {
                thetaInf = ((double)i + .5)/TABLE_ENTRIES * LXx_PI - LXx_HALFPI;

                LXx_VCLR (this->normFactors[i]);

                // Integrate over the sphere to get the normalization factor
                // We use discrete steps, rather than Monte-Carlo integration, so
                // renders are deterministic
                for (int phiDiff = 0; phiDiff < INTEGRAL_SAMPLES; phiDiff++) {
                        phiDiffF = 2.0 * (((double)phiDiff + .5)/INTEGRAL_SAMPLES) * LXx_PI - LXx_PI;

                        for(int thetaSample = 0; thetaSample < INTEGRAL_SAMPLES/2; thetaSample++) {
                                
                                v = 2.0*((double)thetaSample + .5)/INTEGRAL_SAMPLES;
                                sinThetaOut = sqrtf (abs (2.0*v - 1.0)) * (v >= .5 ? 1 : -1);

                                thetaOutf = asin(sinThetaOut);

                                this->fPrime_sNoGlints (thetaInf, thetaOutf, phiDiffF, matrData, &tempColor);

                                LXx_VSCL (tempColor, sclAmount);
                        
                                LXx_VADD (this->normFactors[i], tempColor);
                        }
                }
        }

}

        void
HairMaterial::PrecomputeaBar_f ()
{
        // See "Dual Scattering Approximation for Fast Multiple Scattering in Hair" equation 6
        double theta_Df, thetaOutf, phiInf, phiOutf, phiDiff, v, sinThetaOut;
        double thetaDf2;
        double cosThetaD;
        LXtVector tempColor, tempColor2, tempColor3, normFactor;

        int sampleCount = INTEGRAL_SAMPLES/2;

        double invSamples = 1.0/sampleCount;

        for (int i = 0; i < TABLE_ENTRIES; i++) {
                theta_Df = LXx_PI * ((.5 + i)/TABLE_ENTRIES) - LXx_HALFPI;
                cosThetaD = cos(theta_Df);

                LXx_VCLR (tempColor);

                for (int phiIn = 0; phiIn < sampleCount; phiIn++) {
                        phiInf = ((.5 + phiIn)/ sampleCount) * LXx_PI - LXx_HALFPI;

                        for (int phiOut = 0; phiOut < sampleCount; phiOut++) {
                                phiOutf = ((.5 + phiOut)/ sampleCount) * LXx_PI + LXx_HALFPI;

                                LXx_VCLR (tempColor2);

                                for (int thetaSample = 0; thetaSample < sampleCount; thetaSample++) {
                                        v = ((double)thetaSample + .5)/sampleCount;
                                        sinThetaOut = sqrtf (abs (2.0*v - 1.0)) * (v >= .5 ? 1 : -1);

                                        thetaOutf = asin(sinThetaOut);

                                        phiDiff = phiOutf - phiInf;

                                        this->fPrime_sNoGlints(theta_Df, thetaOutf, phiDiff, 
                                                &(this->matrData), &tempColor3);
                                        
                                        LXx_VSCL (tempColor3, (2.0 * LXx_PI / this->lookupNormFactor(theta_Df)));

                                        LXx_VADD (tempColor2, tempColor3);
                                }

                                LXx_VSCL (tempColor2, invSamples);
                                LXx_VADD (tempColor, tempColor2);
                        }
                }
                LXx_VSCL (tempColor, invSamples * invSamples * cosThetaD);

                LXx_VCPY (this->aBar_f[i], tempColor);
        }
}

        void
HairMaterial::PrecomputeaBar_b ()
{
        // See "Dual Scattering Approximation for Fast Multiple Scattering in Hair" equation 12
        double theta_Df, thetaOutf, phiInf, phiOutf, phiDiff, v, sinThetaOut;
        double thetaDf2;
        double cosThetaD;
        LXtVector tempColor, tempColor2, tempColor3, normFactor;

        int sampleCount = INTEGRAL_SAMPLES/2;

        double invSamples = 1.0/sampleCount;
        double invSamplesSqr = invSamples * invSamples;

        for (int i = 0; i < TABLE_ENTRIES; i++) {
                theta_Df = LXx_PI * ((.5 + i)/TABLE_ENTRIES) - LXx_HALFPI;
                cosThetaD = cos(theta_Df);

                LXx_VCLR (tempColor);

                for (int phiIn = 0; phiIn < sampleCount; phiIn++) {
                        phiInf = ((.5 + phiIn)/ sampleCount) * LXx_PI - LXx_HALFPI;

                        for (int phiOut = 0; phiOut < sampleCount; phiOut++) {
                                phiOutf = ((.5 + phiOut)/ sampleCount) * LXx_PI - LXx_HALFPI;

                                LXx_VCLR (tempColor2);

                                for (int thetaSample = 0; thetaSample < sampleCount; thetaSample++) {
                                        v = ((double)thetaSample + .5)/sampleCount;
                                        sinThetaOut = sqrtf (abs (2.0*v - 1.0)) * (v >= .5 ? 1 : -1);

                                        thetaOutf = asin(sinThetaOut);

                                        phiDiff = phiOutf - phiInf;

                                        this->fPrime_sNoGlints (theta_Df, thetaOutf, phiDiff, 
                                                &(this->matrData), &tempColor3);
                                        
                                        LXx_VSCL (tempColor3, (2.0 * LXx_PI / this->lookupNormFactor(theta_Df)));

                                        LXx_VADD (tempColor2, tempColor3);
                                }

                                LXx_VSCL (tempColor2, invSamples);
                                LXx_VADD (tempColor, tempColor2);
                        }
                }
                LXx_VSCL (tempColor, invSamples * invSamples * cosThetaD);

                LXx_VCPY (this->aBar_b[i], tempColor);
        }
}

        void
HairMaterial::PrecomputeAlphaBar_f ()
{
        /*
         * See "Efficient Implementation of the Dual Scattering Model in Renderman" 
         * equation 13.
         */
        int sampleCount = INTEGRAL_SAMPLES/2;
        double phiInf, phiOutf, phi_d, thetaf, theta_h, thetaDf;
        LXtVector tempColor, tempColorNum, tempColorDenom;

        double sclFactor;
        double solidAngle;

        LXtVector white = {1.0, 1.0, 1.0};

        double invSamples = 1.0/sampleCount;
        double invSamplesCube = invSamples * invSamples * invSamples;

        LXtVector numerColor, denomColor;

        for (int i = 0; i < TABLE_ENTRIES; i++) 
        {
                thetaDf = ((.5 + i)/TABLE_ENTRIES) * LXx_PI - LXx_HALFPI;

                sclFactor = LXx_PI / 2.0 * invSamplesCube;

                LXx_VCLR (numerColor);
                LXx_VCLR (denomColor);

                // Integrate over the forward scattering hemisphere. For the
                // denominator we are basically just getting the total weight,
                // and for the numerator we are multiply each component by its
                // shift
                for (int theta = 0; theta < sampleCount; theta++) 
                {
                        thetaf = ((.5 + theta)/sampleCount) * LXx_PI - LXx_HALFPI;	
                        theta_h = (thetaf + thetaDf)/2.0;

                                for (int phiIn = 0; phiIn < sampleCount; phiIn++) {
                                        phiInf = ((.5 + phiIn)/ sampleCount) * LXx_PI - LXx_HALFPI;

                                        for (int phiOut = 0; phiOut < sampleCount; phiOut++) {

                                                phiOutf = LXx_HALFPI + ((.5 + phiIn)/ sampleCount) * LXx_PI;

                                                // Compute the phi difference
                                                phi_d = phiOutf - phiInf;
                                                if (phi_d > LXx_PI) {
                                                        phi_d = 2.0 * LXx_PI - phi_d;
                                                }
                                                else if (phi_d < 0) {
                                                        phi_d = abs (phi_d);
                                                        if (phi_d > LXx_PI) {
                                                                phi_d = 2.0 * LXx_PI - phi_d;
                                                        }
                                                }

                                                LXx_VCLR (tempColorNum);
                                                LXx_VCLR (tempColorDenom);

                                                LXx_VCPY(tempColor, white);
                                                LXx_VSCL(tempColor, this->N_R (phi_d));
                                                LXx_VSCL(tempColor, this->M_R (theta_h));
                                                LXx_VSCL(tempColor, this->matrData.primaryHighlightIntensity);
                                                LXx_VADD(tempColorDenom, tempColor);
                                                LXx_VSCL(tempColor, this->matrData.primaryHighlightLongShift);
                                                LXx_VADD(tempColorNum, tempColor);
        
                                                LXx_VCPY(tempColor, white);
                                                LXx_VSCL(tempColor, this->N_TRT (phi_d));
                                                LXx_VSCL(tempColor, this->M_TRT (theta_h));
                                                LXx_VSCL(tempColor, this->matrData.secondaryHighlightIntensity);
                                                LXx_VADD(tempColorDenom, tempColor);
                                                LXx_VSCL(tempColor, this->matrData.secondaryHighlightLongShift);
                                                LXx_VADD(tempColorNum, tempColor);

                                                LXx_VCPY(tempColor, white);
                                                LXx_VSCL(tempColor, this->N_TT (phi_d));
                                                LXx_VSCL(tempColor, this->M_TT (theta_h));
                                                LXx_VSCL(tempColor, this->matrData.rimLightIntensity);
                                                LXx_VADD(tempColorDenom, tempColor);
                                                LXx_VSCL(tempColor, this->matrData.rimLightLongShift);
                                                LXx_VADD(tempColorNum, tempColor);

                                                LXx_VSCL(tempColorNum, sclFactor * sin(thetaf + LXx_HALFPI));
                                                LXx_VADD(numerColor, tempColorNum);

                                                LXx_VSCL(tempColorDenom, sclFactor * sin(thetaf + LXx_HALFPI));
                                                LXx_VADD(denomColor, tempColorDenom);
                                        }
                                }
                }

                // Note: the denominator will also act as a normalization
                for (int j = 0; j < 3; j++) {
                        numerColor[j] = denomColor[j] > 0.0 
                                        ? (numerColor[j] / denomColor[j])
                                        : 0.0;
                }
                LXx_VCPY(this->AlphaBar_f[i], numerColor);
        }
}


        void
HairMaterial::PrecomputeAlphaBar_b ()
{
        /*
         * See "Efficient Implementation of the Dual Scattering Model in Renderman" 
         * equation 14.
         */
        int sampleCount = INTEGRAL_SAMPLES/2;
        double phiInf, phiOutf, phi_d, thetaf, theta_h, thetaDf;
        LXtVector tempColor, tempColorNum, tempColorDenom;

        double sclFactor;
        double solidAngle;

        double invSamples = 1.0/sampleCount;
        double invSamplesCube = invSamples * invSamples * invSamples;

        LXtVector white = {1.0, 1.0, 1.0};

        LXtVector numerColor, denomColor;

        for (int i = 0; i < TABLE_ENTRIES; i++) 
        {
                thetaDf = ((.5 + i)/TABLE_ENTRIES) * LXx_PI - LXx_HALFPI;

                sclFactor = LXx_PI / 2.0 * invSamplesCube;

                LXx_VCLR (numerColor);
                LXx_VCLR (denomColor);

                // Integrate over the forward scattering hemisphere. For the
                // denominator we are basically just getting the total weight,
                // and for the numerator we are multiply each component by its
                // shift
                for (int theta = 0; theta < sampleCount; theta++) 
                {
                        thetaf = ((.5 + theta)/sampleCount) * LXx_PI - LXx_HALFPI;	
                        theta_h = (thetaf + thetaDf)/2.0;

                                for (int phiIn = 0; phiIn < sampleCount; phiIn++) {
                                        phiInf = ((.5 + phiIn)/ sampleCount) * LXx_PI - LXx_HALFPI;

                                        for (int phiOut = 0; phiOut < sampleCount; phiOut++) {

                                                phiOutf = ((.5 + phiIn)/ sampleCount) * LXx_PI - LXx_HALFPI;

                                                // Compute the phi difference
                                                phi_d = phiOutf - phiInf;
                                                if (phi_d > LXx_PI) {
                                                        phi_d = 2.0 * LXx_PI - phi_d;
                                                }
                                                else if (phi_d < 0) {
                                                        phi_d = abs (phi_d);
                                                        if (phi_d > LXx_PI) {
                                                                phi_d = 2.0 * LXx_PI - phi_d;
                                                        }
                                                }

                                                LXx_VCLR (tempColorNum);
                                                LXx_VCLR (tempColorDenom);

                                                LXx_VCPY(tempColor, white);
                                                LXx_VSCL(tempColor, this->N_R (phi_d));
                                                LXx_VSCL(tempColor, this->M_R (theta_h));
                                                LXx_VSCL(tempColor, this->matrData.primaryHighlightIntensity);
                                                LXx_VADD(tempColorDenom, tempColor);
                                                LXx_VSCL(tempColor, this->matrData.primaryHighlightLongShift);
                                                LXx_VADD(tempColorNum, tempColor);
        
                                                LXx_VCPY(tempColor, white);
                                                LXx_VSCL(tempColor, this->N_TRT (phi_d));
                                                LXx_VSCL(tempColor, this->M_TRT (theta_h));
                                                LXx_VSCL(tempColor, this->matrData.secondaryHighlightIntensity);
                                                LXx_VADD(tempColorDenom, tempColor);
                                                LXx_VSCL(tempColor, this->matrData.secondaryHighlightLongShift);
                                                LXx_VADD(tempColorNum, tempColor);

                                                LXx_VCPY(tempColor, white);
                                                LXx_VSCL(tempColor, this->N_TT (phi_d));
                                                LXx_VSCL(tempColor, this->M_TT (theta_h));
                                                LXx_VSCL(tempColor, this->matrData.rimLightIntensity);
                                                LXx_VADD(tempColorDenom, tempColor);
                                                LXx_VSCL(tempColor, this->matrData.rimLightLongShift);
                                                LXx_VADD(tempColorNum, tempColor);

                                                LXx_VSCL(tempColorNum, sclFactor * sin(thetaf + LXx_HALFPI));
                                                LXx_VADD(numerColor, tempColorNum);

                                                LXx_VSCL(tempColorDenom, sclFactor * sin(thetaf + LXx_HALFPI));
                                                LXx_VADD(denomColor, tempColorDenom);
                                        }
                                }
                }

                // Note: the denominator will also act as a normalization
                for (int j = 0; j < 3; j++) {
                        numerColor[j] = denomColor[j] > 0.0 
                                        ? (numerColor[j] / denomColor[j])
                                        : 0.0;
                }
                LXx_VCPY(this->AlphaBar_b[i], numerColor);
        }
}

        void
HairMaterial::PrecomputeBetaBar_f ()
{
        /*
         * See "Efficient Implementation of the Dual Scattering Model in Renderman" 
         * equation 15.
         *
         * Right now we're only taking Long variance into account. This may
         * need to be fixed in the future, particularly with respect to the azimuthal
         * variance of the rim lighting.
         */
        int sampleCount = INTEGRAL_SAMPLES/2;
        double phiInf, phiOutf, phi_d, thetaf, theta_h, thetaDf, v, sinThetaOut;
        LXtVector tempColor, tempColorNum, tempColorDenom;

        double sclFactor;
        double solidAngle;

        double invSamples = 1.0/sampleCount;
        double invSamplesCube = invSamples * invSamples * invSamples;

        LXtVector numerColor, denomColor;

        LXtVector white = {1.0, 1.0, 1.0};

        for (int i = 0; i < TABLE_ENTRIES; i++) 
        {
                thetaDf = ((.5 + i)/TABLE_ENTRIES) * LXx_PI - LXx_HALFPI;

                sclFactor = LXx_PI / 2.0 * invSamplesCube;

                LXx_VCLR (numerColor);
                LXx_VCLR (denomColor);

                // Integrate over the forward scattering hemisphere. For the
                // denominator we are basically just getting the total weight,
                // and for the numerator we are multiply each component by its
                // variance
                for (int theta = 0; theta < sampleCount; theta++) 
                {
                        v = ((double)theta + .5)/sampleCount;
                        sinThetaOut = sqrt (abs (2.0*v - 1.0)) * (v >= .5 ? 1 : -1);

                        thetaf = asin(sinThetaOut);	

                        theta_h = (thetaf - thetaDf)/2.0;

                                for (int phi = 0; phi < sampleCount; phi++) {
                                        phi_d = ((.5 + phi)/ sampleCount) * LXx_PI + LXx_HALFPI;

                                        if (phi_d > LXx_PI) {
                                                phi_d = 2.0 * LXx_PI - phi_d;
                                        }
                                        else if (phi_d < 0) {
                                                phi_d = abs (phi_d);
                                                if (phi_d > LXx_PI) {
                                                        phi_d = 2.0 * LXx_PI - phi_d;
                                                }
                                        }

                                        // Compute the BCSDF for this set of angles
                                        LXx_VCLR (tempColorNum);
                                        LXx_VCLR (tempColorDenom);

                                        LXx_VCPY(tempColor, white);
                                        LXx_VSCL(tempColor, this->N_R (phi_d));
                                        LXx_VSCL(tempColor, this->M_R (theta_h));
                                        LXx_VSCL(tempColor, this->matrData.primaryHighlightIntensity);
                                        LXx_VADD(tempColorDenom, tempColor);
                                        LXx_VSCL(tempColor, this->matrData.primaryHighlightLongWidth);
                                        LXx_VADD(tempColorNum, tempColor);
        
                                        LXx_VCPY(tempColor, white);
                                        LXx_VSCL(tempColor, this->N_TRT (phi_d));
                                        LXx_VSCL(tempColor, this->M_TRT (theta_h));
                                        LXx_VSCL(tempColor, this->matrData.secondaryHighlightIntensity);
                                        LXx_VADD(tempColorDenom, tempColor);
                                        LXx_VSCL(tempColor, this->matrData.secondaryHighlightLongWidth);
                                        LXx_VADD(tempColorNum, tempColor);

                                        LXx_VCPY(tempColor, white);
                                        LXx_VSCL(tempColor, this->N_TT (phi_d));
                                        LXx_VSCL(tempColor, this->M_TT (theta_h));
                                        LXx_VSCL(tempColor, this->matrData.rimLightIntensity);
                                        LXx_VADD(tempColorDenom, tempColor);
                                        LXx_VSCL(tempColor, this->matrData.rimLightLongWidth);
                                        LXx_VADD(tempColorNum, tempColor);

                                        LXx_VSCL(tempColorNum, sclFactor * sin(thetaf + LXx_HALFPI));
                                        LXx_VADD(numerColor, tempColorNum);

                                        LXx_VSCL(tempColorDenom, sclFactor * sin(thetaf + LXx_HALFPI));
                                        LXx_VADD(denomColor, tempColorDenom);
                                }
                }

                // Note: the denominator will also act as a normalization
                for (int j = 0; j < 3; j++) {
                        numerColor[j] = denomColor[j] > 0.0 
                                        ? (numerColor[j] / denomColor[j])
                                        : 0.0;
                }
                LXx_VCPY(this->BetaBar_f[i], numerColor);
        }
}


        void
HairMaterial::PrecomputeBetaBar_b ()
{
        /*
         * See "Efficient Implementation of the Dual Scattering Model in Renderman" 
         * equation 16.
         *
         * Right now we're only taking Longituidnal variance into account. This may
         * need to be fixed in the future, particularly with respect to the azimuthal
         * variance of the rim lighting.
         */
        int sampleCount = INTEGRAL_SAMPLES/2;
        double phiInf, phiOutf, phi_d, thetaf, theta_h, thetaDf, v, sinThetaOut;
        LXtVector tempColor, tempColorNum, tempColorDenom;

        double sclFactor;
        double solidAngle;

        double invSamples = 1.0/sampleCount;
        double invSamplesCube = invSamples * invSamples * invSamples;

        LXtVector numerColor, denomColor;

        LXtVector white = {1.0, 1.0, 1.0};

        for (int i = 0; i < TABLE_ENTRIES; i++) 
        {
                thetaDf = ((.5 + i)/TABLE_ENTRIES) * LXx_PI - LXx_HALFPI;

                sclFactor = LXx_PI / 2.0 * invSamplesCube;

                LXx_VCLR (numerColor);
                LXx_VCLR (denomColor);

                // Integrate over the forward scattering hemisphere. For the
                // denominator we are basically just getting the total weight,
                // and for the numerator we are multiply each component by its
                // variance
                for (int theta = 0; theta < sampleCount; theta++) 
                {
                        v = ((double)theta + .5)/sampleCount;
                        sinThetaOut = sqrt (abs (2.0*v - 1.0)) * (v >= .5 ? 1 : -1);

                        thetaf = asin(sinThetaOut);	

                        theta_h = (thetaf - thetaDf)/2.0;

                                for (int phi = 0; phi < sampleCount; phi++) {
                                        phi_d = ((.5 + phi)/ sampleCount) * LXx_PI - LXx_HALFPI;

                                        if (phi_d > LXx_PI) {
                                                phi_d = 2.0 * LXx_PI - phi_d;
                                        }
                                        else if (phi_d < 0) {
                                                phi_d = abs (phi_d);
                                                if (phi_d > LXx_PI) {
                                                        phi_d = 2.0 * LXx_PI - phi_d;
                                                }
                                        }

                                        // Compute the BCSDF for this set of angles
                                        LXx_VCLR (tempColorNum);
                                        LXx_VCLR (tempColorDenom);

                                        LXx_VCPY(tempColor, white);
                                        LXx_VSCL(tempColor, this->N_R (phi_d));
                                        LXx_VSCL(tempColor, this->M_R (theta_h));
                                        LXx_VSCL(tempColor, this->matrData.primaryHighlightIntensity);
                                        LXx_VADD(tempColorDenom, tempColor);
                                        LXx_VSCL(tempColor, this->matrData.primaryHighlightLongWidth);
                                        LXx_VADD(tempColorNum, tempColor);
        
                                        LXx_VCPY(tempColor, white);
                                        LXx_VSCL(tempColor, this->N_TRT (phi_d));
                                        LXx_VSCL(tempColor, this->M_TRT (theta_h));
                                        LXx_VSCL(tempColor, this->matrData.secondaryHighlightIntensity);
                                        LXx_VADD(tempColorDenom, tempColor);
                                        LXx_VSCL(tempColor, this->matrData.secondaryHighlightLongWidth);
                                        LXx_VADD(tempColorNum, tempColor);

                                        LXx_VCPY(tempColor, white);
                                        LXx_VSCL(tempColor, this->N_TT (phi_d));
                                        LXx_VSCL(tempColor, this->M_TT (theta_h));
                                        LXx_VSCL(tempColor, this->matrData.rimLightIntensity);
                                        LXx_VADD(tempColorDenom, tempColor);
                                        LXx_VSCL(tempColor, this->matrData.rimLightLongWidth);
                                        LXx_VADD(tempColorNum, tempColor);

                                        LXx_VSCL(tempColorNum, sclFactor * sin(thetaf + LXx_HALFPI));
                                        LXx_VADD(numerColor, tempColorNum);

                                        LXx_VSCL(tempColorDenom, sclFactor * sin(thetaf + LXx_HALFPI));
                                        LXx_VADD(denomColor, tempColorDenom);
                                }
                }

                // Note: the denominator will also act as a normalization
                for (int j = 0; j < 3; j++) {
                        numerColor[j] = denomColor[j] > 0.0 
                                        ? (numerColor[j] / denomColor[j])
                                        : 0.0;
                }
                LXx_VCPY(this->BetaBar_b[i], numerColor);
        }
}


        void
HairMaterial::PrecomputeDeltaBar_b () 
{
        /*
         * See "Efficient Implementation of the Dual Scattering Model in Renderman" 
         * equation 11.
         */
        double thetaDf;
        LXtVector alphaBar_b, alphaBar_f, aBar_b, aBar_f, aBar_fSqr, aBar_bSqr;

        LXtVector one;
        LXtVector num1, num2, num2add1, num2add2, den1, den2;
        LXtVector den2sqrTemp;
        LXtVector add1, add2;

        LXx_VSET (one, 1.0);

        for (int i = 0; i < TABLE_ENTRIES; i++) 
        {
                thetaDf = ((.5 + i)/TABLE_ENTRIES) * LXx_PI - LXx_HALFPI;

                this->lookupAlphaBar_f (thetaDf, &alphaBar_f);
                this->lookupAlphaBar_b (thetaDf, &alphaBar_b);
                this->lookupaBar_f (thetaDf, &aBar_f);
                this->lookupaBar_b (thetaDf, &aBar_b);
                LXx_VMUL3 (aBar_fSqr, aBar_f, aBar_f);
                LXx_VMUL3 (aBar_bSqr, aBar_b, aBar_b);

                /*
                 * Compute the left portion of the addition in equation 11
                 */

                // Compute the interior numerator
                LXx_VSCL3 (num1, aBar_bSqr, 2.0);
                // Compute the interior denominator
                LXx_VSUB3 (den1, one, aBar_fSqr);
                LXx_VMUL (den1, den1); // this squares it
                // Compute the whole portion in parentheses
                LXx_VDIV (num1, den1);
                LXx_VSUB3 (add1, one, num1);
                // Multiply by alphaBar_b
                LXx_VMUL (add1, alphaBar_b);

                /*
                 * Compute the right portion
                 */

                // Compute the left portion of the addition in the numerator
                LXx_VSUB3 (num2add1, one, aBar_fSqr);
                LXx_VMUL (num2add1, num2add1);
                LXx_VSCL (num2add1, 2.0);
                // Compute the right portion of the subtraction in the numerator
                LXx_VMUL3 (num2add2, aBar_fSqr, aBar_bSqr);
                LXx_VSCL (num2add2, 4.0);
                // Add them for the numerator
                LXx_VADD3 (num2, num2add1, num2add2);
                // Compute the denominator
                LXx_VSUB3 (den2, one, aBar_fSqr);
                LXx_VMUL3 (den2sqrTemp, den2, den2); // This line and the next
                LXx_VMUL (den2, den2sqrTemp);	     // one compute the cube
                // Compute the whole portion in parentheses
                LXx_VDIV (num2, den2);
                // Multiply by alphaBar_f
                LXx_VMUL3 (add2, num2, alphaBar_f);

                // Finally add them and store the value in the table
                LXx_VADD3 (this->DeltaBar_b[i], add1, add2);

        }
}

        void
HairMaterial::PrecomputeSigmaBar_b () 
{
        /*
         * See "Efficient Implementation of the Dual Scattering Model in Renderman" 
         * equation 12.
         */
        double		thetaDf;
        LXtVector	betaBar_b, betaBar_f,
                        betaBar_bSqr, betaBar_fSqr,
                        aBar_b, aBar_f, 
                        aBar_fSqr, aBar_bSqr;

        LXtVector	one;
        LXtVector	prod1, prod2,
                        num, den, numadd1, numadd2,
                        denparen1, denparen2;

        LXx_VSET (one, 1.0);

        for (int i = 0; i < TABLE_ENTRIES; i++) 
        {
                thetaDf = ((.5 + i)/TABLE_ENTRIES) * LXx_PI - LXx_HALFPI;

                this->lookupBetaBar_f (thetaDf, &betaBar_f);
                this->lookupBetaBar_b (thetaDf, &betaBar_b);
                this->lookupaBar_f (thetaDf, &aBar_f);
                this->lookupaBar_b (thetaDf, &aBar_b);
                LXx_VMUL3 (aBar_fSqr, aBar_f, aBar_f);
                LXx_VMUL3 (aBar_bSqr, aBar_b, aBar_b);
                LXx_VMUL3 (betaBar_fSqr, betaBar_f, betaBar_f);
                LXx_VMUL3 (betaBar_bSqr, betaBar_b, betaBar_b);

                // Compute sigmaBar_b as in equation 12

                        // Compute the left side of the outermost product
                        LXx_VSCL3 (prod1, aBar_fSqr, this->matrData.densityFactor);
                        LXx_VADD (prod1, one);

                        // Compute the right side of the outermost product

                                // Compute the numerator

                                        // Compute the left side of the addition
                                        LXx_VSCL3 (numadd1, betaBar_fSqr, 2.0);
                                        LXx_VADD (numadd1, betaBar_bSqr);
                                        LXx_VUOP (numadd1, sqrtf);
                                        LXx_VMUL (numadd1, aBar_b);

                                        // Compute the right side 
                                        LXx_VMUL3 (numadd2, aBar_b, aBar_b);
                                        LXx_VMUL (numadd2, numadd1);

                                        // Add them together
                                        LXx_VADD3 (num, numadd1, numadd2);

                                // Compute the denominator

                                        // Compute the left side of the addition
                                        // within the parentheses
                                        LXx_VSCL3 (denparen1, betaBar_f, 2.0);

                                        // Compute the right side of the addition
                                        // within the parentheses
                                        LXx_VSCL3 (denparen2, betaBar_b, 3.0);

                                        // Add them together
                                        LXx_VADD3 (den, denparen1, denparen2);

                                        // Multiply by aBar_b cubed
                                        LXx_VMUL (den, aBar_bSqr);
                                        LXx_VMUL (den, aBar_b);

                                        // Add aBar_b
                                        LXx_VADD (den, aBar_b);

                                // Finish computing the outmost right side by dividing
                                for (int j = 0; j < 3; j++) {
                                        num[j] = den[j] > 0.0 
                                                        ? (num[j] / den[j])
                                                        : 0.0;
                                }
                                LXx_VCPY(prod2, num);

                        // Finally, multiply the two terms together and store the result
                        LXx_VMUL3 (this->SigmaBar_b[i], prod1, prod2);
        }
}

        void
HairMaterial::PrecomputeABar_b () 
{
        /*
         * See "Efficient Implementation of the Dual Scattering Model in Renderman" 
         * equation 10.
         */
        double		thetaDf;
        LXtVector	aBar_b, aBar_f, 
                        aBar_fSqr, aBar_bSqr;

        LXtVector	one;
        LXtVector	add1, add2, add1num, add1den,
                        add2num, add2den;

        LXx_VSET (one, 1.0);

        for (int i = 0; i < TABLE_ENTRIES; i++) 
        {
                thetaDf = ((.5 + i)/TABLE_ENTRIES) * LXx_PI - LXx_HALFPI;

                this->lookupaBar_f (thetaDf, &aBar_f);
                this->lookupaBar_b (thetaDf, &aBar_b);
                LXx_VMUL3 (aBar_fSqr, aBar_f, aBar_f);
                LXx_VMUL3 (aBar_bSqr, aBar_b, aBar_b);

                // Compute ABar_b as in equation 10

                        // Compute the left side of the outermost addition

                                // Compute the numerator
                                LXx_VMUL3 (add1num, aBar_b, aBar_fSqr);
                                // Compute the denominator
                                LXx_VSUB3 (add1den, one, aBar_fSqr);

                                // Divide to get the left side
                                LXx_VDIV (add1num, add1den);
                                LXx_VCPY (add1, add1num);

                        // Compute the right side of the outermost addition

                                // Compute the numerator
                                LXx_VMUL3 (add2num, aBar_bSqr, aBar_fSqr);
                                LXx_VMUL (add2num, aBar_b);
                                // Compute the denominator
                                LXx_VSUB3 (add2den, one, aBar_fSqr);
                                LXx_VMUL (add2den, add2den);

                                // Divide to get the right side
                                LXx_VDIV (add2num, add2den);
                                LXx_VCPY (add2, add2num);

                        // Finally, add the two terms together and store the result
                        LXx_VADD3 (this->ABar_b[i], add1, add2);
        }
}

        void
HairMaterial::PrecomputeNG_R () 
{
        /*
         * See "An Artist-Friendly Hair Shading System" pseudocode
         */
        LXtVector result, temp;

        double phiPrime, phiIn;

        LXtVector white = {1.0, 1.0, 1.0};
        LXx_VCLR (result);

        for (int j = 0; j < INTEGRAL_SAMPLES; j++) {
                phiPrime = ((.5 + j)/INTEGRAL_SAMPLES)*LXx_HALFPI + LXx_HALFPI;

                if (phiPrime > LXx_PI)
                        phiPrime = phiPrime - 2.0 * LXx_PI;

                LXx_VCPY (temp, white);
                LXx_VSCL (temp, this->N_R (phiPrime));
                
                LXx_VADD (result, temp);
        }
        LXx_VSCL (result, 1.0/INTEGRAL_SAMPLES);
        LXx_VCPY (this->NG_R, result);
}

        void
HairMaterial::PrecomputeNG_TT () 
{
        /*
         * See "An Artist-Friendly Hair Shading System" pseudocode
         */
        LXtVector result, temp;

        double phiPrime, phiIn;

        LXtVector white = {1.0, 1.0, 1.0};
        LXx_VCLR (result);

        for (int j = 0; j < INTEGRAL_SAMPLES; j++) {
                phiPrime = ((.5 + j)/INTEGRAL_SAMPLES)*LXx_HALFPI + LXx_HALFPI;

                if (phiPrime > LXx_PI)
                        phiPrime = phiPrime - 2.0 * LXx_PI;

                LXx_VCPY (temp, white);
                LXx_VSCL (temp, this->N_TT (phiPrime));
                
                LXx_VADD (result, temp);
        }
        LXx_VSCL (result, 1.0/INTEGRAL_SAMPLES);
        LXx_VCPY (this->NG_TT, result);
}

        void
HairMaterial::PrecomputeNG_TRT () 
{
        /*
         * See "An Artist-Friendly Hair Shading System" pseudocode
         */
        LXtVector result, temp;

        double phiPrime, phiIn;

        LXtVector white = {1.0, 1.0, 1.0};
        LXx_VCLR (result);

        for (int j = 0; j < INTEGRAL_SAMPLES; j++) {
                phiPrime = ((.5 + j)/INTEGRAL_SAMPLES)*LXx_HALFPI + LXx_HALFPI;

                if (phiPrime > LXx_PI)
                        phiPrime = phiPrime - 2.0 * LXx_PI;

                LXx_VCPY (temp, white);
                LXx_VSCL (temp, this->N_TRT (phiPrime));
                
                LXx_VADD (result, temp);
        }
        LXx_VSCL (result, 1.0/INTEGRAL_SAMPLES);
        LXx_VCPY (this->NG_TRT, result);
}

        void
HairMaterial::PrecomputeShaderTables (
        HairMaterialData	*matrData)
{
        // We don't want many threads doing all this precomputation
        // in parallel - although there wouldn't be any race
        // conditions, it seems like it may cause memory thrashing. 
        // Either way, it unnecessarily occupies all the threads doing
        // duplicate work.
        // So we lock the precomputation with a Mutex
                
        this->precomputeMutex.Enter();

        // Check again, in case another thread did set it
        if (!this->isPrecomputed) {
                PrecomputeNormFactors(matrData);
                PrecomputeaBar_f ();
                PrecomputeaBar_b ();
                PrecomputeAlphaBar_f ();
                PrecomputeAlphaBar_b ();
                PrecomputeBetaBar_f ();
                PrecomputeBetaBar_b ();
                PrecomputeDeltaBar_b ();
                PrecomputeSigmaBar_b ();
                PrecomputeABar_b ();
                PrecomputeNG_R ();
                PrecomputeNG_TT ();
                PrecomputeNG_TRT ();

                this->isPrecomputed = true;
        }

        this->precomputeMutex.Leave();
}

/*------------------------------- Luxology LLC --------------------------------
 *
 * Functions to lookup in the precomputed tables
 *
 *----------------------------------------------------------------------------*/

        double			
HairMaterial::lookupNormFactor (
        double			 thetaIn)
{
        double			 result = -1.0;
        LXtVector		 temp;

        int thetaIndex = (thetaIn + LXx_HALFPI)/LXx_PI * TABLE_ENTRIES - .5;

        thetaIndex = CLAMP (thetaIndex, 0, (TABLE_ENTRIES - 1));

        LXx_VCPY (temp, this->normFactors[thetaIndex]);

        for (int i = 0; i < 3; i++)
                result = MAX (result, temp[i]);

        if (result >= .8)
                result = .8 + (result - .8)*1.1;

        result = MAX (result, 1.0);

        return result;
}

        void		
HairMaterial::lookupNormFactor (
        double			 thetaIn,
        LXtVector		*outColor)
{
        this->lookupValue (thetaIn, this->normFactors, outColor);
}

        void			
HairMaterial::lookupValue (
        double			 theta, 
        LXtVector		*table,
        LXtVector		*outColor)
{
        // This is used for looking up a generic value in a theta-based table. Right now it does linear
        // interpolation between the two nearest values
        LXtVector		 temp;

        int index0 = (int)((theta + LXx_HALFPI)/LXx_PI * TABLE_ENTRIES);
        index0 = CLAMP (index0, 0, TABLE_ENTRIES - 1);
        int index1 = index0 + 1;
        index1 = CLAMP (index1, 0, TABLE_ENTRIES - 1);

        if (index0 == index1) {
                LXx_VCPY (*outColor, table[index0]);
                return;
        }

        double off0 = theta - (((double)index0 + .5)/TABLE_ENTRIES*LXx_PI - LXx_HALFPI);
        double off1 = (((double)index1 + .5)/TABLE_ENTRIES*LXx_PI - LXx_HALFPI) - theta;

        LXx_VSCL3 (temp, table[index0], 1.0 - off0/(off0 + off1));
        LXx_VADDS (temp, table[index1], off0/(off0 + off1));

        LXx_VCPY (*outColor, temp);
}

        void			
HairMaterial::lookupaBar_f (
        double			 theta_in, 
        LXtVector		*outColor)
{
        this->lookupValue (theta_in, this->aBar_f, outColor);
}

        void			
HairMaterial::lookupaBar_b (
        double			 theta_in, 
        LXtVector		*outColor)
{
        this->lookupValue (theta_in, this->aBar_b, outColor);
}

        void			
HairMaterial::lookupAlphaBar_f (
        double			 theta_h, 
        LXtVector		*outColor)
{
        this->lookupValue (theta_h, this->AlphaBar_f, outColor);
}

        void			
HairMaterial::lookupAlphaBar_b (
        double			 theta_h, 
        LXtVector		*outColor)
{
        this->lookupValue (theta_h, this->AlphaBar_b, outColor);
}

        void			
HairMaterial::lookupBetaBar_f (
        double			 theta_h, 
        LXtVector		*outColor)
{
        this->lookupValue (theta_h, this->BetaBar_f, outColor);
}

        void			
HairMaterial::lookupBetaBar_b (
        double			 theta_h, 
        LXtVector		*outColor)
{
        this->lookupValue (theta_h, this->BetaBar_b, outColor);
}

        void			
HairMaterial::lookupDeltaBar_b (
        double			 theta_h, 
        LXtVector		*outColor)
{
        this->lookupValue(theta_h, this->DeltaBar_b, outColor);
}

        void			
HairMaterial::lookupSigmaBar_b (
        double			 theta_h, 
        LXtVector		*outColor)
{
        this->lookupValue(theta_h, this->SigmaBar_b, outColor);
}

        void			
HairMaterial::lookupABar_b (
        double			 theta_h, 
        LXtVector		*outColor)
{
        this->lookupValue(theta_h, this->ABar_b, outColor);
}

        void
HairMaterial::ClearShadeComponents (
        LXpShadeComponents	*sCmp) 
{
        LXx_VCLR (sCmp->diff);
        LXx_VCLR (sCmp->diffDir);
        LXx_VCLR (sCmp->diffInd);
        LXx_VCLR (sCmp->diffUns);
        LXx_VCLR (sCmp->spec);
        LXx_VCLR (sCmp->refl);
        LXx_VCLR (sCmp->tran);
        LXx_VCLR (sCmp->subs);
        LXx_VCLR (sCmp->lumi);
        LXx_VCLR (sCmp->illum);
        LXx_VCLR (sCmp->illumDir);
        LXx_VCLR (sCmp->illumInd);
        LXx_VCLR (sCmp->illumUns);
        LXx_VCLR (sCmp->volLum);
        LXx_VCLR (sCmp->volOpa);
}

/*------------------------------- Luxology LLC -------------------------------
 *
 * Compute Global Scattering Essentially Fires a Shadow or GI Ray through hair
 * strands and accumulates the information along the ray, which is then used
 * for the hair shading.
 *
 *----------------------------------------------------------------------------*/
        void
HairMaterial::ComputeGlobalScattering (
        ILxUnknownID		 vector, 
        ILxUnknownID		 rayObj, 
        double			 importance,
        LXtFVector		 rayDir,
        int			 flags,
        HairMaterialData	*matrData,
        LXtVector		*T_f, 
        LXtVector		*sigmaBarSqr_f, 
        double			*directFraction,
        LXtFVector		*shadeColor,
        bool			 gi)
{
        ILxUnknownID		 shadeVector;

        CLxLoc_Raycast		 rayCast;

        LXpSamplePosition	*sPos0		= (LXpSamplePosition*) pkt_service.FastPacket (vector, pos_offset);
        LXpParticleSample	*prtSmp0;

        void			*srf0 = NULL, *srf1 = NULL;

        LXtVector		 rayPos;
        double			 theta_i;
        double			 dist;
        int			 setFlags;
        float			 curID, hitID;

        rayCast.set (rayObj);

        // k will be the number of hits so far
        int k = 0;

        // Get the first surface, so we can check to make sure we are tracing the same surface
        rayCast.GetSurfaceID (vector, &srf0);

        // We need to set the first shadow ray to be exactly on the surface
        LXx_VCPY (rayPos, sPos0->wPos);

        // Set T_f to 1.0
        LXx_VSET(*T_f, 1.0);
        LXx_VSET(*sigmaBarSqr_f, 0.0);
        *directFraction = 1.0;

        shadeVector = rayCast.RayPush (vector);

        prtSmp0 = (LXpParticleSample*) pkt_service.FastPacket (vector, particle_sample_offset);
        curID = prtSmp0->idParm;

        while (true) {
                LXpSampleSurfNormal	*sNrm1 = NULL;
                LXpSamplePosition	*sPos1 = NULL;
                LXpSampleRay		*sRay1 = NULL;
                LXpParticleSample	*prtSmp1 = NULL;

                sRay1 = (LXpSampleRay*) pkt_service.FastPacket (shadeVector, ray_offset);

                // By setting the near clip to 0, modo will automatically adapt it
                // so that it doesn't intersect the current surface
                sRay1->nearClip = 0.0;
                sRay1->importance = importance;

                setFlags = LXfRAY_SCOPE_POLYGONS | LXfRAY_SCOPE_IMPLICITSURF  | LXfRAY_SCOPE_VOLUMETRICS | \
                                 LXfRAY_EVAL_OPACITY | LXfRAY_TYPE_SHADOW | LXfRAY_TYPE_SHADOW_INFO;

                // Trace the shadow ray: Raytrace won't push/pop rays for you,
                // and won't set the ray importance
                dist = rayCast.Raytrace (shadeVector, rayPos, rayDir, setFlags);

                if (dist > 0.0) {
                        // Get information about the intersection
                        rayCast.GetSurfaceID (shadeVector, &srf1);
                        sNrm1 = (LXpSampleSurfNormal*) pkt_service.FastPacket (shadeVector, nrm_offset);
                        sPos1 = (LXpSamplePosition*) pkt_service.FastPacket (shadeVector, pos_offset);
                        prtSmp1 = (LXpParticleSample*) pkt_service.FastPacket (shadeVector, particle_sample_offset);
                        hitID = prtSmp1->idParm;
                }
                else {
                        srf1 = NULL;
                }

                // Don't intersect if it's the same strand, this is most likely
                // a capsule end hit
                if (srf1 && hitID == curID && rayCast.GetSurfaceType(shadeVector) == LXi_SURF_FUR) {
                        // We need to set the next shadow ray to be at this ray
                        LXx_VCPY (rayPos, sPos1->wPos);
                        continue;
                }
                else if (srf1)
                        curID = hitID;
                
                if (srf1 == srf0) { // If it's still the same surface
                        LXtVector temp;

                        theta_i = this->GetLongAngle(sNrm1->tangent, rayDir);

                        // update T_f
                        lookupaBar_f (theta_i, &temp);
                        LXx_VMUL (*T_f, temp);

                        // update sigmaBarSqr_f
                        lookupBetaBar_f (theta_i, &temp);
                        LXx_VMUL (temp, temp); // need to square it
                        LXx_VADD (*sigmaBarSqr_f, temp);

                        *directFraction = 0.0;

                        // We need to set the next shadow ray to be at this ray
                        LXx_VCPY (rayPos, sPos1->wPos);
                }
                else { // If it's not the same surface
                        if (gi) { // And it's a GI ray
                                // Retrace the last ray to get the final color
                                flags |= LXfRAY_EVAL_SHADING;

                                sRay1->nearClip = 0.0;
                                sRay1->importance = importance;

                                rayCast.Raytrace (shadeVector, rayPos, rayDir, flags);

                                LXx_VCPY (*shadeColor, sRay1->color);
                        }
                        else if (srf1) { // And it's a normal shadow ray
                                // The hair isn't shaded
                                LXx_VCLR (*T_f);
                                LXx_VCLR (*sigmaBarSqr_f);
                                *directFraction = 0.0;
                        }

                        break;
                }

                k++;
        }

        Desaturate (*T_f, matrData->globalScatteringSaturation);

        rayCast.RayPop (vector);

        LXx_VSCL (*T_f, matrData->densityFactor);
}

/*
 * These are just basic wrapped functions for clarity.
 */

        void
HairMaterial::ComputeGlobalScatteringGI (
        ILxUnknownID		 vector, 
        ILxUnknownID		 rayObj, 
        double			 importance,
        LXtFVector		 rayDir,
        int			 flags,
        HairMaterialData	*matrData,
        LXtVector		*T_f, 
        LXtVector		*sigmaBarSqr_f, 
        double			*directFraction,
        LXtFVector		*shadeColor)
{
        ComputeGlobalScattering (vector, rayObj, importance, rayDir, flags, matrData, T_f, sigmaBarSqr_f, directFraction, shadeColor, true);
}

        void
HairMaterial::ComputeGlobalScatteringShadow (
        ILxUnknownID		 vector, 
        ILxUnknownID		 rayObj, 
        double			 importance,
        LXtFVector		 rayDir,
        int			 flags,
        HairMaterialData	*matrData,
        LXtVector		*T_f, 
        LXtVector		*sigmaBarSqr_f, 
        double			*directFraction)
{
        LXtFVector nothing;
        ComputeGlobalScattering (vector, rayObj, importance, rayDir, flags, matrData, T_f, sigmaBarSqr_f, directFraction, &nothing, false);
}

/*------------------------------- Luxology LLC -------------------------------
 *
 * These are the actual shading code, which is essentially a copy
 * of the pseudo-code provided in the Artist-Friendly Hair Shading paper
 * and the Efficient Implementation of the Dual Scattering Model paper.
 *
 *----------------------------------------------------------------------------*/

        void
HairMaterial::ComputeFScatter_s (
        HairMaterialData	*matrData,
        LXtVector		 sigmaBarSqr_f,
        double			 theta_h,
        double			 phi_d,
        LXtVector		 fScatter_s)
{
        LXtVector tempColor;

        LXx_VCLR (fScatter_s);

        LXx_VCPY(tempColor, matrData->primaryHighlightColor);
        LXx_VMUL(tempColor, this->NG_R);
        for (int i = 0; i < 3; i++) {
                tempColor[i] *= this->MG_R (theta_h, sigmaBarSqr_f[i]);
        }
        LXx_VSCL(tempColor, matrData->primaryHighlightIntensity);
        LXx_VADD(fScatter_s, tempColor);

        LXx_VCPY(tempColor, matrData->secondaryHighlightColor);
        LXx_VMUL(tempColor, this->NG_TRT);
        for (int i = 0; i < 3; i++) {
                tempColor[i] *= this->MG_TRT (theta_h, sigmaBarSqr_f[i]);
        }
        LXx_VSCL(tempColor, matrData->secondaryHighlightIntensity);
        LXx_VADD(fScatter_s, tempColor);

        // Not sure if glints should be here...

        LXx_VCPY(tempColor, matrData->rimLightColor);
        LXx_VMUL(tempColor, this->NG_TT);
        for (int i = 0; i < 3; i++) {
                tempColor[i] *= this->MG_TT (theta_h, sigmaBarSqr_f[i]);
        }
        LXx_VSCL(tempColor, matrData->rimLightIntensity);
        LXx_VADD(fScatter_s, tempColor);

        LXx_VMUL(fScatter_s, matrData->fwdScatteringColorAdj);
        LXx_VSCL(fScatter_s, matrData->fwdScatteringIntensityAdj);
}

        void
HairMaterial::ComputeShadingForOneRay (
        LXtVector		 T_f, 
        LXtVector		 sigmaBarSqr_f, 
        double			 directFraction,
        LXtFVector		 hairTangent,
        LXtFVector		 w_i,
        LXtFVector		 w_o,
        double			 gAngle,
        HairMaterialData	*matrData,
        LXpShadeComponents	*sCmp)
{
        LXtVector		 fDirect_back, fScatter_back, fDirect_s, fScatter_s, FScatter;
        LXtVector		 ABar_b, deltaBar_b, sigmaBar_b, sigmaBarSqr_b;
        LXtVector		 tempColor;

        double			 theta_i, theta_o, theta_d, theta_h, phi;

        theta_o = this->GetLongAngle (hairTangent, w_o);
        theta_i = this->GetLongAngle (hairTangent, w_i);
        theta_d = (theta_o - theta_i)/2.0;
        theta_h = (theta_o + theta_i)/2.0;

        phi = this->GetAzimuthalAngle (hairTangent, w_i, w_o);
        if (phi > LXx_PI) {
                // remap to [-pi, pi]
                phi = phi - 2*LXx_PI;
        }

        // Get values
        this->lookupABar_b (theta_d, &ABar_b);
        this->lookupDeltaBar_b (theta_d, &deltaBar_b);
        this->lookupSigmaBar_b (theta_d, &sigmaBar_b);
        LXx_VMUL3 (sigmaBarSqr_b, sigmaBar_b, sigmaBar_b);

        if (directFraction <= 0.0) {
                // Compute fScatter_back
                for (int i = 0; i < 3; i++) {
                        fScatter_back[i] = UnitAreaGaussian(sigmaBarSqr_b[i] + sigmaBarSqr_f[i] + matrData->bwdScatteringLongWidthAdj,
                                                                theta_h - deltaBar_b[i] + matrData->bwdScatteringLongShift);
                }
                LXx_VMUL (fScatter_back, ABar_b);
                LXx_VSCL (fScatter_back, (2.0 / (LXx_PI * pow (cos (theta_d), 2))));

                LXx_VSCL (fScatter_back, matrData->bwdScatteringIntensityAdj);
                LXx_VMUL (fScatter_back, matrData->bwdScatteringColorAdj);
                Desaturate (fScatter_back, matrData->bwdScatteringSaturation);

                this->ComputeFScatter_s (matrData, sigmaBarSqr_f, theta_h, phi, fScatter_s);
                Desaturate (fScatter_s, matrData->fwdScatteringSaturation);

                // Add FScatter to the shade components
                LXx_VADDS3 (FScatter, fScatter_s, fScatter_back, (LXx_PI * matrData->densityFactor));
                LXx_VMUL (FScatter, T_f);
                LXx_VSCL (FScatter, matrData->densityFactor);

                LXx_VSCL3 (sCmp->subs, FScatter, cos(theta_i));
        }
        else {
                /*
                 * Compute fDirect_back
                 */
                for (int i = 0; i < 3; i++) {
                        fDirect_back[i] = UnitAreaGaussian(sigmaBarSqr_b[i] + matrData->bwdScatteringLongWidthAdj,
                                                                theta_h - deltaBar_b[i] + matrData->bwdScatteringLongShift);
                }
                LXx_VMUL (fDirect_back, ABar_b);
                LXx_VSCL (fDirect_back, (2.0 / (LXx_PI * pow (cos (theta_d), 2))));

                LXx_VSCL (fDirect_back, matrData->bwdScatteringIntensityAdj);
                LXx_VMUL (fDirect_back, matrData->bwdScatteringColorAdj);
                Desaturate (fDirect_back, matrData->bwdScatteringSaturation);

                /*
                 * Compute fDirect_s
                 */
                if (matrData->singleScatteringOn) {
                        this->fPrime_s (theta_i, theta_o, phi, gAngle, matrData, &fDirect_s);
                        LXx_VSCL (fDirect_s, pow(cos (theta_d), 2));
                }
                else {
                        LXx_VCLR (fDirect_s);
                }

                /*
                 * Add to shade components
                 */
                LXx_VSCL3 (sCmp->spec, fDirect_s, cos(theta_i));
                LXx_VSCL3 (sCmp->subs, fDirect_back, matrData->densityFactor * cos(theta_i));
        }
}

        void
HairMaterial::ComputeAmbientShading (
        LXtFVector		 w_i,
        LXtFVector		 hairTangent,
        LXtFVector		 ambientColor,
        LXpShadeComponents	*sCmp)
{
        double			 theta_i, theta_o, theta_d, theta_h, phi;
        LXtVector		 totalIntegrationColor;

        theta_i = this->GetLongAngle (hairTangent, w_i);
        this->lookupNormFactor(theta_i, &totalIntegrationColor);

        LXx_VMUL3 (sCmp->subs, ambientColor, totalIntegrationColor);
}
        void
HairMaterial::ComputeDirectShading (
        ILxUnknownID		 vector,
        ILxUnknownID		 rayObj,
        HairMaterialData	*matrData,
        LXpShadeComponents	*sCmp)
{
        LXpSamplePosition	*samplePosition		= (LXpSamplePosition*) pkt_service.FastPacket (vector, pos_offset);
        LXpSampleSurfNormal	*sNrm			= (LXpSampleSurfNormal*) pkt_service.FastPacket (vector, nrm_offset);
        LXpSampleRay		*sRay			= (LXpSampleRay*) pkt_service.FastPacket (vector, ray_offset);
        LXpParticleSample	*prtSmp			= (LXpParticleSample*) pkt_service.FastPacket (vector, particle_sample_offset);
        LXpGlobalIndirect	*globInd		= (LXpGlobalIndirect*) pkt_service.FastPacket (vector, global_indirect_offset);	
        LXpSamplePosition	 initialSamplePosition	= *samplePosition;

        LXpShadeComponents	 sCmpTemp;

        LxResult		 result;

        int			 lights, lightSamples;
        double			 gAngle;

        LXtVector		 T_f;
        LXtVector		 sigmaBarSqr_f;
        double			 directFraction;

        LXtVector		 rayPos;
        LXtFVector		 rayDir;

        int			 flags;
        int			 shadType;
        int			 castGI = (matrData->giType == 1) || (matrData->giType == 3);

        LXtFVector		 lColor;
        float			 lBrightness;

        LXtFVector		 w_o, w_i;

        CLxLoc_Raycast		 rayCast;
        rayCast.set (rayObj);

        // Get the number of lights
        lights = rayCast.LightCount (vector);

        // Set up Gangle - particle ID is a random number between 0.0 and 1.0
        gAngle = ((prtSmp->idParm) * LXx_HALFPI + LXx_PI)/6.0;

        // Set the outgoing ray direction to the flipped incoming ray
        LXx_VSCL3 (w_o, sRay->dir, -1.0);
        // Sample all the lights
        for (int i = 0; i < lights; i++) {

                lightSamples = rayCast.LightSampleCountByLight (vector, i);
                lightSamples *= sRay->importance;
                lightSamples = MAX (lightSamples, 1);

                // For a raytraced light, we need to compute shading for each shadow sample
                shadType = rayCast.LightShadowType (vector, i);
                if (shadType == LXiICVAL_LIGHT_SHADTYPE_RAYTRACE ||
                        (shadType == LXiICVAL_LIGHT_SHADTYPE_PORTAL && castGI)) {
                        // For each light sample
                        for (int j = 0; j < lightSamples; j++) {

                                // Get the first shadow ray
                                result = rayCast.GetNextShadowRay (vector, i, initialSamplePosition.wPos, &rayDir, &flags);
                                FVectorNormalize(rayDir);

                                if (result == LXe_OK || result == LXe_FALSE) {
                                        this->ComputeGlobalScatteringShadow(vector, rayObj, 
                                                                        (sRay->importance/lightSamples), rayDir, flags,
                                                                        matrData,
                                                                        &T_f, &sigmaBarSqr_f, &directFraction);
                                }
                                else {
                                        LXx_VCLR (T_f);
                                        directFraction = 0.0;
                                }

                                // If T_f and directFraction are both 0.0, it means the shadow ray hit another light
                                // and no shading needs to be done
                                if (LXx_VDOT (T_f, T_f) != 0.0 || directFraction != 0.0) {
                                        result = rayCast.GetLightSampleDirection (vector, i, initialSamplePosition.wPos, &rayDir);

                                        this->ClearShadeComponents (&sCmpTemp);

                                        if (result == LXe_OK) {
                                                LXx_VCPY (w_i, rayDir);

                                                ComputeShadingForOneRay (T_f, sigmaBarSqr_f, 
                                                                directFraction, sNrm->tangent, 
                                                                w_i, w_o, gAngle, matrData, &sCmpTemp);
                        
                                                LXx_VCPY (samplePosition->wPos, initialSamplePosition.wPos);

                                                // This has to be done for each sample
                                                rayCast.LightValue (vector, i, &lColor, &lBrightness);

                                                LXx_VMUL (sCmpTemp.spec, lColor);
                                                LXx_VSCL (sCmpTemp.spec, (lBrightness / lightSamples));

                                                LXx_VMUL (sCmpTemp.subs, lColor);
                                                LXx_VSCL (sCmpTemp.subs, (lBrightness / lightSamples));
                                        }

                                        // Add it to the overall shade components
                                        LXx_VADD(sCmp->spec, sCmpTemp.spec);
                                        LXx_VADD(sCmp->subs, sCmpTemp.subs);
                                }
                        }
                }
                else {
                        // Eventually Deep Shadow Mapping Code should go here, we need to compute shading once
                }
        }
}

        void
HairMaterial::ComputeIndirectShading (
        ILxUnknownID		 vector,
        ILxUnknownID		 rayObj,
        HairMaterialData	*matrData,
        LXpShadeComponents	*sCmp)
{
        LXpSamplePosition	*samplePosition		= (LXpSamplePosition*) pkt_service.FastPacket (vector, pos_offset);
        LXpSampleSurfNormal	*sNrm			= (LXpSampleSurfNormal*) pkt_service.FastPacket (vector, nrm_offset);
        LXpSampleRay		*sRay			= (LXpSampleRay*) pkt_service.FastPacket (vector, ray_offset);
        LXpParticleSample	*prtSmp			= (LXpParticleSample*) pkt_service.FastPacket (vector, particle_sample_offset);
        LXpGlobalIndirect	*globInd		= (LXpGlobalIndirect*) pkt_service.FastPacket (vector, global_indirect_offset);	
        LXpGlobalLighting	*globLgt		= (LXpGlobalLighting*) pkt_service.FastPacket (vector, global_lighting_offset);	
        LXpSamplePosition	 initialSamplePosition	= *samplePosition;

        LXpShadeComponents	 sCmpTemp;

        LxResult		 result;

        int			 giRays = 0;
        double			 gAngle;

        LXtVector		 T_f;
        LXtVector		 sigmaBarSqr_f;
        double			 directFraction;

        LXtVector		 rayPos;
        LXtFVector		 rayDir;

        LXtFVector		 lColor;

        LXtFVector		 w_o, w_i;

        CLxLoc_Raycast		 rayCast;
        rayCast.set (rayObj);

        // Set up Gangle - particle ID is a random number between 0.0 and 1.0
        gAngle = ((prtSmp->idParm) * LXx_HALFPI + LXx_PI)/6.0;

        // Set the outgoing ray direction to the flipped incoming ray
        LXx_VSCL3 (w_o, sRay->dir, -1.0);

        /* Set the number of giRays */
        if ((matrData->giType == 1 || matrData->giType == 3) && globInd->enable) {
                int curBounce;

                rayCast.GetBucketGlobalBounce (vector, &curBounce);

                // We only receive GI if the current bounce is less than the
                // maximum bounces
                if (curBounce < globInd->limit) {
                        giRays = matrData->giRays * sRay->importance * pow (globInd->irrRays2, curBounce);
                        giRays = MAX (giRays, 1);
                }
        }

        // Sample Global Illumination (using monte-carlo)
        for (int i = 0; i < giRays; i++) {
                        int flags;

                        result = rayCast.GetNextGIRaySphere (vector, &rayDir, &flags);

                        if (result == LXe_OK || result == LXe_FALSE) {
                                this->ComputeGlobalScatteringGI (vector, rayObj, 
                                                                (sRay->importance/giRays), rayDir, flags,
                                                                matrData,
                                                                &T_f, &sigmaBarSqr_f, &directFraction, &lColor);
                        }
                        else {
                                LXx_VCLR (T_f);
                                directFraction = 0.0;
                        }
                        
                        // If the surface it hits is black, don't worry about shading it
                        if (LXx_VDOT (lColor, lColor) != 0.0) {
                                LXx_VCPY (w_i, rayDir);

                                this->ClearShadeComponents (&sCmpTemp);

                                ComputeShadingForOneRay (T_f, sigmaBarSqr_f, 
                                                directFraction, sNrm->tangent, 
                                                w_i, w_o, gAngle, matrData, &sCmpTemp);
                        
                                LXx_VCPY (samplePosition->wPos, initialSamplePosition.wPos);

                                // Since lcolor represents the returned GI color, we
                                // need to Adj it for giRays AND we need to multiply
                                // by 4 * pi since we're sampling a whole sphere, for
                                // some reason
                                LXx_VSCL (sCmpTemp.spec, 4.0 * LXx_PI / giRays);
                                LXx_VSCL (sCmpTemp.subs, 4.0 * LXx_PI / giRays);

                                LXx_VMUL (sCmpTemp.spec, lColor);
                                LXx_VMUL (sCmpTemp.subs, lColor);

                                // Add it to the overall shade components
                                LXx_VADD(sCmp->spec, sCmpTemp.spec);
                                LXx_VADD(sCmp->subs, sCmpTemp.subs);
                        }
        }

        /* If there is no global illumination use ambient color */
        if (!globInd->enable) {
                LXtFVector ambientColor;

                LXx_VCPY (w_i, sRay->dir);
                LXx_VSCL3 (ambientColor, globLgt->ambientColor, globLgt->ambientIntensity);

                this->ClearShadeComponents (&sCmpTemp);
                ComputeAmbientShading (w_i, sNrm->tangent, ambientColor, &sCmpTemp);
                LXx_VADD(sCmp->subs, sCmpTemp.subs);
        }
}

        void
HairMaterial::cmt_ShaderEvaluate (
        ILxUnknownID             vector,
        ILxUnknownID		 rayObj,
        LXpShadeComponents     *sCmp,
        LXpShadeOutput         *sOut,
        void                    *data)
{
        LXpSamplePosition	*samplePosition		= (LXpSamplePosition*) pkt_service.FastPacket (vector, pos_offset);
        LXpSampleSurfNormal	*sNrm			= (LXpSampleSurfNormal*) pkt_service.FastPacket (vector, nrm_offset);
        LXpSampleRay		*sRay			= (LXpSampleRay*) pkt_service.FastPacket (vector, ray_offset);
        LXpParticleSample	*prtSmp			= (LXpParticleSample*) pkt_service.FastPacket (vector, particle_sample_offset);
        LXpGlobalIndirect	*globInd		= (LXpGlobalIndirect*) pkt_service.FastPacket (vector, global_indirect_offset);	
        LXpGlobalLighting	*globLgt		= (LXpGlobalLighting*) pkt_service.FastPacket (vector, global_lighting_offset);	
        LXpHairShader		*sHair			= (LXpHairShader*) pkt_service.FastPacket (vector, pkt_offset);

        LXpShadeComponents	 sCmpTemp;
        LXpShadeComponents	 sCmp2;
        
        int			 lights;

        double			 gAngle;

        HairMaterialData	 matrData;

        CLxLoc_Raycast		 rayCast;
        rayCast.set (rayObj);

        lights = rayCast.LightCount (vector);

        this->CopyHairPacket (sHair, matrData);

        // Return if there's no lighting
        if (lights < 1 && 
                (matrData.giType == 0 || matrData.giType == 2 || matrData.giRays <= 0) &&
                 globLgt->ambientIntensity == 0.0) {
                LXx_VCLR (sOut->color);
                return;
        }

        // Return if this isn't a fur strand
        if (rayCast.GetSurfaceType(vector) != LXi_SURF_FUR) {
                return;
        }

        // Set up Gangle - particle ID is a random number between 0.0 and 1.0
        gAngle = ((prtSmp->idParm) * LXx_HALFPI + LXx_PI)/6.0;

        if (!this->isPrecomputed) {
                PrecomputeShaderTables(&matrData);
        }

        // Clear the shade components
        this->ClearShadeComponents (&sCmp2);

        /* 
         * If it's an indirect ray, we check to see if we cast indirect rays,
         * and if we don't then we exit
         */
        if ((sRay->flags & LXfRAY_TYPE_INDIRECT) && globInd->enable) {
                if (matrData.giType == 0 || matrData.giType == 1) {
                        LXx_VSET (sOut->color, 0.0);

                        return;
                }
        }

        // Compute the shading from direct lighting
        this->ClearShadeComponents (&sCmpTemp);
        this->ComputeDirectShading (vector, rayObj, &matrData, &sCmpTemp);
        LXx_VADD (sCmp2.subs, sCmpTemp.subs);
        LXx_VADD (sCmp2.spec, sCmpTemp.spec);

        // Compute the shading from indirect lighting
        this->ClearShadeComponents (&sCmpTemp);
        this->ComputeIndirectShading (vector, rayObj, &matrData, &sCmpTemp);
        LXx_VADD (sCmp2.subs, sCmpTemp.subs);
        LXx_VADD (sCmp2.spec, sCmpTemp.spec);

        // Copy the shade components
        *sCmp = sCmp2;

        // Compute the final color
        for (int i = 0; i < 3; i++) 
                sOut->color[i] = sCmp->diff[i] + sCmp->spec[i] + sCmp->refl[i] + sCmp->subs[i];
}

/* -------------------------------------------------------------------------
 *
 * Packet Effects definition:
 * This section is used to define all the possible texture effects for the
 * hair material
 *
 * ------------------------------------------------------------------------- */

class HairPFX : public CLxImpl_PacketEffect
{
        public:
                HairPFX () {}

                static LXtTagInfoDesc	descInfo[];

                LxResult		pfx_Packet (const char **packet) LXx_OVERRIDE;
                unsigned int		pfx_Count (void) LXx_OVERRIDE;
                LxResult		pfx_ByIndex (int idx, const char **name, const char **typeName, int *type) LXx_OVERRIDE;
                LxResult		pfx_Get (int idx,void *packet, float *val, void *item) LXx_OVERRIDE;
                LxResult		pfx_Set (int idx,void *packet, const float *val, void *item) LXx_OVERRIDE;
};

#define SRVs_HAIR_PFX		SRVs_HAIR_MATR

enum {
        SRVs_PRIM_COL_IDX = 0,
        SRVs_SEC_COL_IDX,
        SRVs_RIM_COL_IDX,
        SRVs_GLINTS_COL_IDX,
        SRVs_FS_COL_IDX,
        SRVs_BS_COL_IDX
};

#define SRVs_PRIM_COL_TFX	"primHLCol"
#define SRVs_SEC_COL_TFX	"secHLCol"
#define SRVs_RIM_COL_TFX	"rimCol"
#define SRVs_GLINTS_COL_TFX	"glintsCol"
#define SRVs_FS_COL_TFX		"fsColAdj"
#define SRVs_BS_COL_TFX		"bsColAdj"

LXtTagInfoDesc HairPFX::descInfo[] = {
        { LXsSRV_USERNAME,	"Hair Packet FX" },
        { LXsSRV_LOGSUBSYSTEM,	"texture-effect"},
        { LXsTFX_CATEGORY,	LXsSHADE_SURFACE},
        { 0 }
};

        LxResult
HairPFX::pfx_Packet (const char	**packet) 
{
        packet[0] = SRVs_HAIR_VPACKET;
        return LXe_OK;
}

        unsigned int
HairPFX::pfx_Count (void) 
{
        return 6;
}

        LxResult
HairPFX::pfx_ByIndex (int id, const char **name, const char **typeName, int *type) 
{
        switch (id) {
                case SRVs_PRIM_COL_IDX:
                        name[0]     = SRVs_PRIM_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_SEC_COL_IDX:
                        name[0]     = SRVs_SEC_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_RIM_COL_IDX:
                        name[0]     = SRVs_RIM_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_GLINTS_COL_IDX:
                        name[0]     = SRVs_GLINTS_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_FS_COL_IDX:
                        name[0]     = SRVs_FS_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_BS_COL_IDX:
                        name[0]     = SRVs_BS_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
        }
                        
        return	LXe_OK;
}

        LxResult
HairPFX::pfx_Get (int id, void *packet, float *val, void *item) 
{
        LXpHairShader	*hairPacket = (LXpHairShader *) packet;

        switch (id) {
                case SRVs_PRIM_COL_IDX:
                        val[0] = hairPacket->matrData.primaryHighlightColor[0];
                        val[1] = hairPacket->matrData.primaryHighlightColor[1];
                        val[2] = hairPacket->matrData.primaryHighlightColor[2];
                        break;
                case SRVs_SEC_COL_IDX:
                        val[0] = hairPacket->matrData.secondaryHighlightColor[0];
                        val[1] = hairPacket->matrData.secondaryHighlightColor[1];
                        val[2] = hairPacket->matrData.secondaryHighlightColor[2];
                        break;
                case SRVs_RIM_COL_IDX:
                        val[0] = hairPacket->matrData.rimLightColor[0];
                        val[1] = hairPacket->matrData.rimLightColor[1];
                        val[2] = hairPacket->matrData.rimLightColor[2];
                        break;
                case SRVs_GLINTS_COL_IDX:
                        val[0] = hairPacket->matrData.glintsColor[0];
                        val[1] = hairPacket->matrData.glintsColor[1];
                        val[2] = hairPacket->matrData.glintsColor[2];
                        break;
                case SRVs_FS_COL_IDX:
                        val[0] = hairPacket->matrData.fwdScatteringColorAdj[0];
                        val[1] = hairPacket->matrData.fwdScatteringColorAdj[1];
                        val[2] = hairPacket->matrData.fwdScatteringColorAdj[2];
                        break;
                case SRVs_BS_COL_IDX:
                        val[0] = hairPacket->matrData.bwdScatteringColorAdj[0];
                        val[1] = hairPacket->matrData.bwdScatteringColorAdj[1];
                        val[2] = hairPacket->matrData.bwdScatteringColorAdj[2];
                        break;
        }
        
        return LXe_OK;
}

        LxResult
HairPFX::pfx_Set (int id, void *packet, const float *val, void *item) 
{
        LXpHairShader	*hairPacket = (LXpHairShader *) packet;

        switch (id) {
                case SRVs_PRIM_COL_IDX:
                        hairPacket->matrData.primaryHighlightColor[0] = val[0];
                        hairPacket->matrData.primaryHighlightColor[1] = val[1];
                        hairPacket->matrData.primaryHighlightColor[2] = val[2];
                        break;
                case SRVs_SEC_COL_IDX:
                        hairPacket->matrData.secondaryHighlightColor[0] = val[0];
                        hairPacket->matrData.secondaryHighlightColor[1] = val[1];
                        hairPacket->matrData.secondaryHighlightColor[2] = val[2];
                        break;
                case SRVs_RIM_COL_IDX:
                        hairPacket->matrData.rimLightColor[0] = val[0];
                        hairPacket->matrData.rimLightColor[1] = val[1];
                        hairPacket->matrData.rimLightColor[2] = val[2];
                        break;
                case SRVs_GLINTS_COL_IDX:
                        hairPacket->matrData.glintsColor[0] = val[0];
                        hairPacket->matrData.glintsColor[1] = val[1];
                        hairPacket->matrData.glintsColor[2] = val[2];
                        break;
                case SRVs_FS_COL_IDX:
                        hairPacket->matrData.fwdScatteringColorAdj[0] = val[0];
                        hairPacket->matrData.fwdScatteringColorAdj[1] = val[1];
                        hairPacket->matrData.fwdScatteringColorAdj[2] = val[2];
                        break;
                case SRVs_BS_COL_IDX:
                        hairPacket->matrData.bwdScatteringColorAdj[0] = val[0];
                        hairPacket->matrData.bwdScatteringColorAdj[1] = val[1];
                        hairPacket->matrData.bwdScatteringColorAdj[2] = val[2];
                        break;
        }
        
        return LXe_OK;
}

        void
initialize ()
{
        CLxGenericPolymorph*    materialServer = new CLxPolymorph<HairMaterial>;
        CLxGenericPolymorph*    packetServer = new CLxPolymorph<HairPacket>;
        CLxGenericPolymorph*    FXServer = new CLxPolymorph<HairPFX>;

        materialServer->AddInterface (new CLxIfc_CustomMaterial<HairMaterial>);
        materialServer->AddInterface (new CLxIfc_ChannelUI<HairMaterial>);
        materialServer->AddInterface (new CLxIfc_StaticDesc<HairMaterial>);
        lx::AddServer (SRVs_HAIR_MATR, materialServer);

        packetServer->AddInterface (new CLxIfc_VectorPacket<HairPacket>);
        packetServer->AddInterface (new CLxIfc_StaticDesc<HairPacket>);
        lx::AddServer (SRVs_HAIR_VPACKET, packetServer);

        FXServer->AddInterface (new CLxIfc_PacketEffect<HairPFX>);
        FXServer->AddInterface (new CLxIfc_StaticDesc<HairPFX>);
        lx::AddServer (SRVs_HAIR_PFX, FXServer);
}

