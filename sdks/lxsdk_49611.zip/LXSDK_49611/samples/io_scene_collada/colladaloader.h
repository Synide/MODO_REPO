/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef COLLADALOADER_H
#define COLLADALOADER_H

#include "colladaserver.h"
#include "colladacontainers.h"
#include "colladaprefs.h"

#include "../libcolladaio/cio_animation.h"
#include "../libcolladaio/cio_asset.h"
#include "../libcolladaio/cio_camera.h"
#include "../libcolladaio/cio_element.h"
#include "../libcolladaio/cio_effect.h"
#include "../libcolladaio/cio_file.h"
#include "../libcolladaio/cio_geometry.h"
#include "../libcolladaio/cio_image.h"
#include "../libcolladaio/cio_effect.h"
#include "../libcolladaio/cio_light.h"
#include "../libcolladaio/cio_node.h"
#include "../libcolladaio/cio_visualscene.h"

#include <lxu_scene.hpp>

#include <set>
#include <string>

/*
 * ----------------------------------------------------------------
 * COLLADA Scene Loader
 *
 * A custom scene loader.
 */

class COLLADASceneLoader
        :
        public CLxSceneLoader,
        public CLxFileParser,
        public cio::ImageVisitor
{
        COLLADALogMessage	 log;
        LxResult		 LogError (
                                        LxResult		 result,
                                        const std::string	&msg);

    public:
                                 COLLADASceneLoader ();
                                ~COLLADASceneLoader ();

        /*
         * -------------------------------------------------------------------
         * CLxSceneLoader overrides.
         */
        virtual CLxFileParser *	 sl_Parser    ()	{ return this; }

        virtual bool		 sl_Recognize ();
        virtual bool		 sl_ParseInit ();
        virtual bool		 sl_ParseDone ();
        virtual bool		 sl_Parse     (LxResult *);

        /*
         * -------------------------------------------------------------------
         * CLxFileParser overrides.
         */
        virtual bool		 fp_Open       (const char *);
        virtual void		 fp_SetMonitor (LXtObjectID);
        virtual bool		 fp_HasError   ();
        virtual LxResult	 fp_ErrorCode  ();
        virtual void		 fp_Cleanup    ();

        static LXtTagInfoDesc	 descInfo[];

    protected:
        /*
         * -------------------------------------------------------------------
         * Element loaders.
         */
        LxResult		 TallyVisualSceneLibrary (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&visualSceneID);

        LxResult		 TallyVisualScene (
                                        cio::COLLADAElement	&collada,
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 TallyNode (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node);

        LxResult		 LoadAsset (
                                        cio::COLLADAElement	&collada,
                                        Asset			&asset);

        LxResult		 LoadAnimationLibrary (
                                        cio::COLLADAElement	&collada);

        LxResult		 MapAnimation (
                                        cio::AnimationElement	&animation);

        LxResult		 LoadImageLibrary (
                                        cio::COLLADAElement	&collada);
        virtual bool		 VisitImage (cio::ImageElement	&image);

        LxResult		 LoadVisualSceneLibrary (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&visualSceneID,
                                        Asset			&asset);

        LxResult		 LoadVisualScene (
                                        cio::COLLADAElement	&collada,
                                        cio::VisualSceneElement	&visualScene,
                                        Asset			&asset);

        LxResult		 LoadVisualScene_modo401 (
                                        cio::VisualSceneElement_modo401 &modoTech);
        LxResult		 LoadVisualScene_3dsMax (
                                        cio::VisualSceneElement_3dsMax &maxTech);
        LxResult		 LoadVisualScene_FCOLLADA (
                                        cio::VisualSceneElement_FCOLLADA &fTech);
        LxResult		 LoadVisualScene_Maya (
                                        cio::VisualSceneElement_Maya &mayaTech);
        LxResult		 LoadVisualScene_XSI (
                                        cio::VisualSceneElement_XSI &xsiTech);

        LxResult		 LoadNode (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node);

        LxResult		 LoadInstanceNode (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node);

        LxResult		 InstanceLight (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node,
                                        unsigned		&lightItemIndex);

        LxResult		 LinkTargets ();

        LxResult		 LoadCamera (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node,
                                        unsigned		 cameraItemIndex);

        LxResult		 LoadCameraOptics (
                                        cio::COLLADAElement	&collada,
                                        cio::OpticsElement	&optics,
                                        unsigned		 cameraItemIndex);

        LxResult		 LoadCameraOptics_modo401 (
                                        cio::COLLADAElement	&collada,
                                        cio::OpticsElement	&optics,
                                        unsigned		 cameraItemIndex);

        LxResult		 LoadCameraImager (
                                        cio::COLLADAElement	&collada,
                                        cio::ImagerElement	&imager);

        LxResult		 LoadLight (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node,
                                        unsigned		 lightItemIndex);

        LxResult		 LoadDirectionalLight (
                                        cio::COLLADAElement		&collada,
                                        cio::DirectionalLightElement	&light,
                                        unsigned			 lightItemIndex);

        LxResult		 LoadPointLight (
                                        cio::COLLADAElement	&collada,
                                        cio::PointLightElement	&light,
                                        unsigned		 lightItemIndex);

        LxResult		 LoadSpotLight (
                                        cio::COLLADAElement	&collada,
                                        cio::SpotlightElement	&light,
                                        unsigned		 lightItemIndex);

        LxResult		 LoadInstanceController (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node);

        LxResult		 LoadInstanceGeometry (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node);

        LxResult		 LoadTransforms (
                                        cio::COLLADAElement	&collada,
                                        cio::NodeElement	&node);

        LxResult		 LoadTransform (
                                        cio::COLLADAElement		&collada,
                                        cio::NodeElement		&node,
                                        cio::TransformElement		&transform,
                                        cio::TransformTypeArray		&transformTypes,
                                        cio::RotateAxisArray		&rotateOrders);

        LxResult		 LoadLookAtTransform (
                                        cio::TransformElement		&transform,
                                        cio::TransformTypeArray		&transformTypes);

        LxResult		 LoadMatrixTransform (
                                        cio::COLLADAElement		&collada,
                                        cio::NodeElement		&node,
                                        cio::TransformElement		&transform,
                                        cio::TransformTypeArray		&transformTypes);

        LxResult		 LoadScaleTransform (
                                        cio::COLLADAElement		&collada,
                                        cio::NodeElement		&node,
                                        cio::TransformElement		&transform,
                                        cio::TransformTypeArray		&transformTypes);

        LxResult		 LoadRotateTransform (
                                        cio::COLLADAElement		&collada,
                                        cio::NodeElement		&node,
                                        cio::TransformElement		&transform,
                                        cio::TransformTypeArray		&transformTypes,
                                        cio::RotateAxisArray		&rotateOrders);

        LxResult		 LoadSkewTransform (
                                        cio::TransformElement		&transform,
                                        cio::TransformTypeArray		&transformTypes);

        LxResult		 LoadTranslateTransform (
                                        cio::COLLADAElement		&collada,
                                        cio::NodeElement		&node,
                                        cio::TransformElement		&transform,
                                        cio::TransformTypeArray		&transformTypes);

        bool			 HasTargetAnimation (
                                        cio::COLLADAElement		&collada,
                                        const std::string		&nodeTargetURI) const;

        LxResult		 LoadTargetAnimation (
                                        cio::COLLADAElement		&collada,
                                        const std::string		&nodeTargetURI,
                                        const std::string		&channelName,
                                        double				 valueScale = 1.0);

        LxResult		 LoadTargetAnimation (
                                        cio::COLLADAElement		&collada,
                                        const std::string		&nodeTargetURI,
                                        unsigned			 scaleItem,
                                        unsigned			 rotateItem,
                                        unsigned			 translateItem);

        LxResult		 LoadAnimationSampler (
                                        cio::AnimationElement		&animation,
                                        cio::AnimationSamplerElement	&sampler,
                                        const std::string		&channelName,
                                        double				 valueScale = 1.0);

        LxResult		 LoadAnimationSampler (
                                        cio::AnimationElement		&animation,
                                        cio::AnimationSamplerElement	&sampler,
                                        unsigned			 scaleItem,
                                        unsigned			 rotateItem,
                                        unsigned			 translateItem);

        LxResult		 LoadAnimationEnvelope (
                                        cio::AnimationSourceElement	&sourceInput,
                                        cio::AnimationSourceElement	&sourceOutput,
                                        cio::AnimationSourceElement	&sourceInterpolation,
                                        const std::string		&channelName,
                                        double				 valueScale = 1.0);

        LxResult		 LoadAnimationEnvelopeTangents (
                                        cio::AnimationSourceElement	&sourceInput,
                                        cio::AnimationSourceElement	&sourceOutput,
                                        cio::AnimationSourceElement	&sourceInterpolation,
                                        cio::AnimationSourceElement	*sourceInTangents,
                                        cio::AnimationSourceElement	*sourceOutTangents,
                                        const std::string		&channelName,
                                        double				 valueScale = 1.0);

        LxResult		 LoadAnimationEnvelopeTangents_modo501 (
                                        cio::AnimationSourceElement	&sourceInput,
                                        cio::AnimationSourceElement	&sourceOutput,
                                        cio::AnimationSourceElement	&sourceInterpolation,
                                        cio::AnimationSourceElement	&sourceInTanSlopeWeights,
                                        cio::AnimationSourceElement	&sourceOutTanSlopeWeights,
                                        const std::string		&channelName,
                                        double				 valueScale = 1.0);

        LxResult		 LoadAnimationEnvelopeTangentsBroken_modo501 (
                                        cio::AnimationSourceElement	&sourceInput,
                                        cio::AnimationSourceElement	&sourceOutput,
                                        cio::AnimationSourceElement	&sourceInterpolation,
                                        cio::AnimationSourceElement	&sourceInTanSlopeWeights,
                                        cio::AnimationSourceElement	&sourceOutTanSlopeWeights,
                                        cio::AnimationSourceElement	&sourceBrokenOutputs,
                                        cio::AnimationSourceElement	&sourceBrokenOutputTimes,
                                        cio::AnimationSourceElement	&sourceBrokenInTangentOutputs,
                                        cio::AnimationSourceElement	&sourceBrokenOutTangentOutputs,
                                        const std::string		&channelName,
                                        double				 valueScale = 1.0);

        LxResult		 LoadAnimationEnvelope (
                                        cio::AnimationSourceElement	&sourceInput,
                                        cio::AnimationSourceElement	&sourceOutput,
                                        cio::AnimationSourceElement	&sourceInterpolation,
                                        unsigned			 scaleItem,
                                        unsigned			 rotateItem,
                                        unsigned			 translateItem);

        void			 AddAnimationEnvelope (
                                        const std::string		&baseChannelName,
                                        unsigned			 item,
                                        CLxUser_Envelope		 envelopes[3]);

        LxResult		 LoadInstanceMaterial (
                                        cio::COLLADAElement		&collada,
                                        const std::string		&geometryID,
                                        cio::InstanceMaterialElement	&instanceMaterial);

        LxResult		 LoadEffect (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&geometryID,
                                        const std::string	&materialSymbol,
                                        const std::string	&bviSemantic,
                                        bool			 hasBVIInputSet,
                                        unsigned		 bviInputSet,
                                        cio::EffectElement	&effect);

        LxResult		 LoadPhong (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&geometryID,
                                        const std::string	&materialSymbol,
                                        const std::string	&bviSemantic,
                                        bool			 hasBVIInputSet,
                                        unsigned		 bviInputSet,
                                        cio::EffectElement	&effect,
                                        cio::PhongElement	&phong);

        LxResult		 LoadBlinn (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&geometryID,
                                        const std::string	&materialSymbol,
                                        const std::string	&bviSemantic,
                                        bool			 hasBVIInputSet,
                                        unsigned		 bviInputSet,
                                        cio::EffectElement	&effect,
                                        cio::BlinnElement	&blinn);

        LxResult		 LoadLambert (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&geometryID,
                                        const std::string	&materialSymbol,
                                        const std::string	&bviSemantic,
                                        bool			 hasBVIInputSet,
                                        unsigned		 bviInputSet,
                                        cio::EffectElement	&effect,
                                        cio::LambertElement	&lambert);

        LxResult		 LoadConstant (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&geometryID,
                                        const std::string	&materialSymbol,
                                        const std::string	&bviSemantic,
                                        bool			 hasBVIInputSet,
                                        unsigned		 bviInputSet,
                                        cio::EffectElement	&effect,
                                        cio::ConstantElement	&constant);

        LxResult		 InterpretTransparency (
                                        cio::FX_Opaque			 opaqueMode,
                                        bool				 hasTransparency,
                                        double				 transparency,
                                        bool				 hasTransparentColor,
                                        const cio::Element::ColorRGBA	&color);

        LxResult		 LoadTexture (
                                        cio::COLLADAElement	&collada,
                                        const std::string	&geometryID,
                                        const std::string	&materialSymbol,
                                        const std::string	&bviSemantic,
                                        bool			 hasBVIInputSet,
                                        unsigned		 bviInputSet,
                                        cio::EffectElement	&effect,
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet,
                                        const std::string	&effectChannel);

        LxResult		 LoadMeshTexture (
                                        cio::MeshElement	&mesh,
                                        cio::ImageElement	&image,
                                        const std::string	&materialSymbol,
                                        bool			 hasBVIInputSet,
                                        unsigned		 bviInputSet,
                                        const std::string	&texcoordSet,
                                        const std::string	&effectChannel);

        LxResult		 LoadImageMap (
                                        cio::ImageElement	&image,
                                        const std::string	&texcoordSet,
                                        const std::string	&effect);

        LxResult		 SetChannelColorAmount (
                                        const std::string	&amountChannel,
                                        const std::string	&colorChannel,
                                        cio::Element::ColorRGBA	&color);

        LxResult		 LoadGeometry (
                                        cio::COLLADAElement	&collada,
                                        cio::GeometryElement	&geometry);

        LxResult		 LoadPolygons (
                                        cio::MeshElement	&mesh);

        LxResult		 BuildPolygons (cio::PolygonsElement &polygons);

        LxResult		 LoadVertices (
                                        cio::MeshElement	&mesh,
                                        cio::PolygonsElement	&polygons);

        LxResult		 LoadPolylists (
                                        cio::MeshElement	&mesh);

        LxResult		 BuildPolylist (cio::PolylistElement &polylist);

        LxResult		 SetPolyVertexMaps (
                                        bool			 hasNormals,
                                        bool			 hasTexcoords,
                                        bool			 hasColors,
                                        bool			 hasWeights,
                                        unsigned		 polyIndex,
                                        unsigned		 vertexPolyCount,
                                        unsigned		 inputIndicesIndex,
                                        unsigned		 maxOffset);

        LxResult		 LoadVertices (
                                        cio::MeshElement	&mesh,
                                        cio::PolylistElement	&polylist);

        LxResult		 LoadTriangles (
                                        cio::MeshElement	&mesh);

        LxResult		 BuildTriangles (
                                        cio::TrianglesElement	&triangles);

        LxResult		 LoadVertices (
                                        cio::MeshElement	&mesh,
                                        cio::TrianglesElement	&triangles);

        LxResult		 LoadLines (
                                        cio::MeshElement	&mesh);

        LxResult		 BuildLines (
                                        cio::LinesElement	&lines);

        LxResult		 LoadVertices (
                                        cio::MeshElement	&mesh,
                                        cio::LinesElement	&lines);

        LxResult		 LoadVertices (
                                        cio::MeshElement	&mesh);

        LxResult		 LoadPositionsSource (
                                        cio::SourceElement	&source);

        LxResult		 LoadNormals (
                                        cio::MeshElement		&mesh,
                                        const cio::VertexMapInputHub	&inputHub);

        LxResult		 LoadTexcoords (
                                        cio::MeshElement		&mesh,
                                        const cio::VertexMapInputHub	&inputHub);

        LxResult		 LoadColors (
                                        cio::MeshElement		&mesh,
                                        const cio::VertexMapInputHub	&inputHub);

        LxResult		 LoadWeights (
                                        cio::MeshElement		&mesh,
                                        const cio::VertexMapInputHub	&inputHub);

        LxResult		 LoadScene (
                                        cio::COLLADAElement	&collada,
                                        std::string		&visualSceneID);

        const COLLADAprefs&	 GetPrefs () const;

    private:
        static bool		 HasTransformType (
                                        cio::TransformType		 transformType,
                                        const cio::TransformTypeArray	&transformTypes);

        std::string		 filename;
        cio::File		 file;
        CLxUser_Monitor		 mon;
        LxResult		 error;
        unsigned		 steps;

        COLLADAprefs		 prefs;

        std::string		 nodeName;
        NodeIDIndexMap		 nodeIDIndexMap;
        NodeIDIndexMap		 transformIDIndexMap;
        unsigned		 parentItem;
        unsigned		 lastNodeItem;

        typedef std::map<std::string, unsigned>	InstanceMap;
        InstanceMap		 instances;

        typedef struct en_CameraTarget
        {
                std::string	 nodeID;
                bool		 enabled;
                bool		 setFocus;
                double		 distance;
                double		 roll;
        } CameraTarget;

        typedef std::map<unsigned, CameraTarget> CameraTargetMap;
        CameraTargetMap		 cameraTargets;

        /*
         * Store the last point index as a base, in case
         * we're loading more than one geometry per mesh.
         */
        unsigned		 lastPointIndex;
        unsigned		 basePointIndex;

        unsigned		 pointOffset;
        std::vector<float>	 points;

        unsigned		 normalOffset;
        std::vector<float>	 normals;
        unsigned		 normalMap;

        std::vector<unsigned>	 texcoordOffsets;
        std::vector<cio::Element::FloatArray> texcoords;
        std::set<std::string>	 texcoordUVMapIDs;
        std::vector<unsigned>	 texcoordUVMaps;

        std::vector<unsigned>	 colorOffsets;
        std::vector<cio::Element::FloatArray> colors;
        std::set<std::string>	 colorMapIDs;
        std::vector<unsigned>	 colorMaps;
        std::vector<unsigned>	 colorMapStrides;

        std::vector<unsigned>	 weightOffsets;
        std::vector<cio::Element::FloatArray> weights;
        std::set<std::string>	 weightMapIDs;
        std::vector<unsigned>	 weightMaps;

        std::vector<unsigned>	 polyVertexCounts;
        std::vector<unsigned>	 polyVertexIndices;

        MaterialSet		 materialTagSet;
        std::string		 materialTag;
        std::string		 materialName;

        /*
         * Map material symbols onto their targets.
         * The MaterialBindKey is a pair of (geometry ID, material symbol),
         * which is used to look up the corresponding material target value.
         */
        typedef std::pair<std::string, std::string> MaterialBindKey;
        MaterialBindKey		 materialBindKey;

        typedef std::map<MaterialBindKey, std::string> MaterialMap;
        MaterialMap		 materialMap;

        /*
         * Map material targets onto their user-friendly names, (when a user-
         * friendly name is available), to hide the raw material ID.
         */
        typedef std::map<std::string, std::string> MaterialTargetNameMap;
        MaterialTargetNameMap	 materialTargetNameMap;

        /*
         * Map node and transform URI fragments onto animation IDs.
         */
        typedef std::map<std::string, std::string> AnimationMap;
        AnimationMap		 animationMap;
};

#endif // COLLADALOADER_H

