/*
 * Copyright (c) 2008-2019 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <lxidef.h>
#include "lxoCopy.hpp"

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * The LxoTranslate class extends LxoCopy to read an LXO file, copying the
 * file to a new file, but modifying the paths ro filenames in the new copy.
 *
 * For this example, we'll just change all filenames to be "REPLACEMENT FILENAME"
 *
 *----------------------------------------------------------------------------*/
class LxoTranslate : public LxoCopy {

    public:
        LxoTranslate (char* lxoInName, char* lxoOutName) : LxoCopy (lxoInName, lxoOutName) {}

        virtual LXChunkUsage    ChunkUsage ()   // only process chunks that may contain sub-chunks with filenames
            {
            switch (m_chunkId)
                {
                case 'ITEM':                    // need to look inside the item sub-chunks
                    return LXChunk_Process;
                }

            return LXChunk_Copy;                // just copy other chunks without processing
            }

        virtual LXChunkUsage    ItemSubChunkUsage ()    // only process sub-chunks that may contain filenames
            {
            switch (m_subChunkId)
                {
                case 'CHNL':                    // Scalar channel value sub-chunk
                case 'CHNS':                    // String channel value sub-chunk
                case 'CHAN':                    // Generalized channel value sub-chunk

                    return LXChunk_Process;     // we'll look in these for filenames to translate
                }

            return LXChunk_Copy;                // just copy other sub-chunks without processing
            }

        virtual LxResult    ProcessItemChannelString (char* name, char* str);
        virtual LxResult    ProcessItemChannelGeneral (LxULong index, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal);
        virtual LxResult    ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length);
};

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Copy item channel value sub-chunks, but if the value is a <filename> string
 * then replace it with an alternate file path
 *
 *----------------------------------------------------------------------------*/
LxResult LxoTranslate::ProcessItemChannelString (char* name, char* str)
    {
    if (0 != strcmp (LXsICHAN_VIDEOSTILL_FILENAME, name))
        return LxoNameStringSubChunk (m_writer).Write (name, str);

    return LxoNameStringSubChunk (m_writer).Write (name, "REPLACEMENT FILENAME");
    }

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Copy item channel value sub-chunks, but if the value is a <filename> string
 * then replace it with an alternate file path
 *
 *----------------------------------------------------------------------------*/
LxResult LxoTranslate::ProcessItemChannelGeneral (LxULong index, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal)
    {
    switch (type & ~LXItemType_UndefState)
        {
        case LXItemType_Int:
        case LXItemType_EnvelopeInt:
            return LxoChannelValueSubChunk (m_writer).Write (index, intVal, envelopeIndex);

        case LXItemType_Float:
        case LXItemType_EnvelopeFloat:
        case LXItemType_FloatAlt:
            return LxoChannelValueSubChunk (m_writer).Write (index, floatVal, envelopeIndex);

        case LXItemType_String:
        case LXItemType_EnvelopeString:
            if (0 != strcmp (LXsICHAN_VIDEOSTILL_FILENAME, GetChannelName (index)))
                return LxoChannelValueSubChunk (m_writer).Write (index, strVal, envelopeIndex);

            return LxoChannelValueSubChunk (m_writer).Write (index, "REPLACEMENT FILENAME", envelopeIndex);
        }

    return LXe_INVALIDARG;
    }

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Copy item channel value sub-chunks, but if the value is a <filename> string
 * then replace it with an alternate file path
 *
 *----------------------------------------------------------------------------*/
LxResult LxoTranslate::ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length)
{
    switch (type & ~LXItemType_UndefState)
        {
        case LXItemType_Int:
            return LxoScalarChannelSubChunk (m_writer).Write (name, intVal);

        case LXItemType_Float:
        case LXItemType_FloatAlt:
            return LxoScalarChannelSubChunk (m_writer).Write (name, floatVal);

        case LXItemType_Variable:
            return LxoScalarChannelSubChunk (m_writer).Write (name, buffer, length);

        case LXItemType_String:
            if (0 != strcmp (LXsICHAN_VIDEOSTILL_FILENAME, name))
                return LxoScalarChannelSubChunk (m_writer).Write (name, strVal);

            return LxoScalarChannelSubChunk (m_writer).Write (name, "REPLACEMENT FILENAME");
        }

    return LXe_INVALIDARG;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * process command line args to specify the input & output LXO files.  Use the
 * LxoTranslate class (subclassed from LxoCopy) to copy the file.
 *
 *----------------------------------------------------------------------------*/
int main (int argc, char* argv[])
{
    static char         usage[] = "Usage: %s inFileName outFileName";

    if (3 != argc)
        return fprintf (stderr, usage, argv[0]);

    LxResult    result = LxoTranslate (argv[1], argv[2]).ReadFile ();

    if (LXe_OK != result)
        fprintf (stderr, "\nError (0x%x) copying LXO file <%s> to <%s>\n", result, argv[1], argv[2]);
    else
        fprintf (stderr, "\nSuccessfully copied <%s> to <%s>\n", argv[1], argv[2]);
}

