/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_image.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"

#include <string>
#include <algorithm>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Image.
 */

struct pv_ImageElement
{
        pv_ImageElement ()
                :
                initFrom(NULL)
        {
        }

        ElementXML		*initFrom;
};

ImageElement::ImageElement (
         ImageLibraryElement	&library,
         const string		&name)
        :
        Element(library.PV ()),
        pv(new pv_ImageElement ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddImage (*this);

                SetID (ItemID (name));
                SetName (name);
        }
}

ImageElement::ImageElement (
         ImageLibraryElement	&library)
        :
        Element(library.PV ()),
        pv(new pv_ImageElement ())
{
}

ImageElement::~ImageElement ()
{
        delete pv;
}

        std::string
ImageElement::GetNativeFilePath () const
{
        string filePath = GetURI ();
        if (!filePath.empty ()) {
                static const unsigned authorityLen = 7;
                if (filePath.length () >= authorityLen) {
                        /*
                         * Trim off the authority leader.
                         */
                        static const char* authorityPrefix = "file://";
                        string fileAuthorityPrefix =
                                filePath.substr (0, authorityLen);
                        std::transform (
                                fileAuthorityPrefix.begin (),
                                fileAuthorityPrefix.end (),
                                fileAuthorityPrefix.begin (),
                                (int(*)(int))tolower);
                        if (fileAuthorityPrefix == string(authorityPrefix)) {
                                filePath = filePath.substr (
                                        authorityLen, filePath.length () - authorityLen);

/*
 * Only trim off the extra slash on Windows. On Mac OS X, we keep the extra
 * slash, since that's the indication that we have an absolute file path.
 */
#if defined(_WIN32) || defined(_WIN64)
                                /*
                                 * Trim off the extra slash if it's a triple.
                                 */
                                if (filePath[0] == '/') {
                                        filePath = filePath.substr (
                                                1, filePath.length () - 1);
                                }
#endif
                        }
                }

#if defined(_WIN32) || defined(_WIN64)
                /*
                 * On Windows, reverse the direction of the slashes.
                 */
                filePath = Replace (filePath, "/", "\\");
#endif

                /*
                 * Replace hex and decimal escape sequences with the space character.
                 */
                filePath = Replace (filePath, "%20", " ");
                filePath = Replace (filePath, "%032", " ");
        }

        return filePath;
}

        void
ImageElement::SetNativeFilePath (
        const std::string	&path,
        bool			setAbsolutePath)
{
        string textureURI;
        if (setAbsolutePath) {
                textureURI = FilePathToAbsoluteURI (path);
        }
        else {
                textureURI = FilePathToRelativeURI (path);
        }

        SetURI(textureURI);
}

        string
ImageElement::GetURI () const
{
        return GetElementValue (GetElementHandle ().FirstChildElement (
                ELEMENT_INIT_FROM).Element ());
}

        void
ImageElement::SetURI (
        const std::string	&path)
{
        if (pv->initFrom) {
                ClearElementValue (pv->initFrom);
        }
        else {
                pv->initFrom = AddElement (ELEMENT_INIT_FROM);
        }

        SetElementValue (pv->initFrom, path);
}

/*
 * ---------------------------------------------------------------------------
 * Image Library.
 */

ImageLibraryElement::ImageLibraryElement (COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddImageLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkImageLibrary (*this);
        }
}

ImageLibraryElement::~ImageLibraryElement ()
{
}

        void
ImageLibraryElement::VisitImages (ImageVisitor *visitor)
{
        bool	keepVisiting(false);
        ImageElement	firstImage(*this);
        firstImage.SetElement (GetElementHandle ().FirstChildElement (
                ELEMENT_IMAGE).Element ());
        if (firstImage.GetElement () != NULL) {
                keepVisiting = visitor->VisitImage (firstImage);
        }

        if (keepVisiting) {
                ElementXML	*iterElement =
                        firstImage.GetElement ()->NextSiblingElement (ELEMENT_IMAGE);
                while (iterElement && keepVisiting) {
                        ImageElement	nextImage(*this);
                        nextImage.SetElement (iterElement);
                        keepVisiting = visitor->VisitImage (nextImage);
                        iterElement = iterElement->NextSiblingElement ();
                }
        }
}

        bool
ImageLibraryElement::LinkImage (
        const std::string	&imageID,
        ImageElement		&image)
{
        return LinkFirstChildElement (ELEMENT_IMAGE, imageID, image);
}

        void
ImageLibraryElement::AddImage (ImageElement &image)
{
        image.SetElement (AddElement (ELEMENT_IMAGE));
}

} // namespace cio

