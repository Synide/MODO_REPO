/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_MATERIAL_H
#define CIO_MATERIAL_H

#include "cio_element.h"

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Instance Effect.
 */

class MaterialElement;

class InstanceEffectElement : public Element
{
    public:
                                 InstanceEffectElement (
                                        MaterialElement	&material);
        virtual			~InstanceEffectElement ();

        std::string		 GetURL () const;

        /*
         * Effect param overrides. These have precedence over their
         * corresponding parameters in the effect.
         */
        bool			 HasSetParamAmbient () const;
        void			 GetSetParamAmbientColor (
                                        ColorRGB		&color);

        bool			 HasSetParamDiffuse () const;
        void			 GetSetParamDiffuseColor (
                                        ColorRGB		&color);

        bool			 HasSetParamSpecularColor () const;
        void			 GetSetParamSpecularColor (
                                        ColorRGB		&color);

        bool			 HasSetParamShininess () const;
        float			 GetSetParamShininess () const;
};

/*
 * ---------------------------------------------------------------------------
 * Material.
 */

class MaterialLibraryElement;

class MaterialElement : public Element
{
        friend class InstanceEffectElement;

    public:
                                 MaterialElement (
                                        MaterialLibraryElement &library,
                                        const std::string	&name);
                                 MaterialElement (
                                        MaterialLibraryElement &library);
        virtual			~MaterialElement ();

        bool			 HasInstanceEffect () const;
        bool			 LinkInstanceEffect (
                                        InstanceEffectElement	&instanceEffect);
};

/*
 * ---------------------------------------------------------------------------
 * Material Library.
 */

class COLLADAElement;

class MaterialLibraryElement : public Element
{
        friend class MaterialElement;

    public:
                                 MaterialLibraryElement (
                                         COLLADAElement &collada);
        virtual			~MaterialLibraryElement ();

        bool			 HasMaterial () const;
        bool			 LinkMaterial (
                                        const std::string	&materialID,
                                        MaterialElement		&material);

    protected:
        void			 AddMaterial (MaterialElement &material);
};

} // namespace cio

#endif // CIO_MATERIAL_H

