/*
 * Plug-in SDK Source: Modifier Wrappers
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Implements modifier wrapper classes.
 */
#include <lxu_modifier.hpp>


/*
 * Allocating the item modifier conjures the spawner for the modifier nodes out
 * of spawner space.
 */
CLxItemModifierServer::CLxItemModifierServer ()
{
        CLxSpawnerCreate<CLxItemModifierNode> sp ("CLxItemModifierServer");

        spawn = sp.spawn;
        if (sp.created)
                sp.AddInterface (new CLxIfc_Modifier<CLxItemModifierNode>);

        i_type = LXiTYPE_NONE;
}


/*
 * The typelist is either given explicitly or it copied from the main item
 * type. If there's a main type we make that the required type, and the
 * graph list is just sent directly if present. Tags are stored in a list
 * since the number is variable.
 */
        unsigned
CLxItemModifierServer::tag_Count ()
{
        if (!l_tags.size ())
        {
                l_tags.push_back (LXsMOD_TYPELIST);
                if (ItemTypeList ())
                        l_vals.push_back (ItemTypeList ());
                else
                        l_vals.push_back (ItemType ());

                if (ItemType ())
                {
                        l_tags.push_back (LXsMOD_REQUIREDTYPE);
                        l_vals.push_back (ItemType ());
                }

                if (GraphNames ())
                {
                        l_tags.push_back (LXsMOD_GRAPHLIST);
                        l_vals.push_back (GraphNames ());
                }
        }

        return (unsigned)l_tags.size ();
}

        LxResult
CLxItemModifierServer::tag_Describe (
        unsigned		 index,
        LXtTagInfoDesc		*desc)
{
        lx_err::check (index < l_tags.size (), LXe_OUTOFBOUNDS);

        desc->type = l_tags[index].c_str ();
        desc->info = l_vals[index].c_str ();
        return LXe_OK;
}


/*
 * These methods control traversal of the candidate items for the modifier.
 * Reset() builds the list (by default all items of the main type), and Next()
 * iterates through them. Subclasses can override UpdateList() to get a
 * different list of items.
 */
        LxResult
CLxItemModifierServer::eval_Reset (
        ILxUnknownID		 scene)
{
        CLxUser_Scene		 sc (scene);

        l_item.clear ();
        l_indx.clear ();
        UpdateList (sc);

        i_scan = 0;
        return LXe_OK;
}

        void
CLxItemModifierServer::UpdateList (
        CLxUser_Scene		&scene)
{
        CLxUser_Item		 item;
        unsigned		 i, n;

        if (i_type == LXiTYPE_NONE)
        {
                CLxUser_SceneService	 srv;

                i_type = srv.ItemType (ItemType ());
        }

        lx_err::check (scene.ItemCount (i_type, &n));
        for (i = 0; i < n; i++)
        {
                lx_err::check (scene.GetItem (i_type, i, item));
                add_entry (item, 0);
        }
}

        void
CLxItemModifierServer::add_entry (
        CLxUser_Item		&item,
        unsigned		 index)
{
        l_item.push_back (item);
        l_indx.push_back (index);
}

        LXtObjectID
CLxItemModifierServer::eval_Next (
        unsigned		*index)
{
        LXtObjectID		 obj;

        if (i_scan >= l_item.size ())
                return 0;

        index[0] = l_indx[i_scan];
        obj = l_item[i_scan].m_loc;
        i_scan ++;
        return obj;
}


/*
 * For each item this method is used to allocate the modifier node. We spawn the
 * object and store the eval context, but the rest is done by the client.
 *
 * Clients that want to link to related items would need a test() method and a way
 * to specify other item types and graphs. That could be added relatively easily.
 */
        LxResult
CLxItemModifierServer::eval_Alloc (
        ILxUnknownID		 item,
        unsigned		 index,
        ILxUnknownID		 eval,
        void		       **ppvObj)
{
        CLxItemModifierNode	*node = spawn->Alloc (ppvObj);

        node->m_eval.set (eval);
        node->m_attr.set (eval);
        node->has_cache = true;

        mod_index = index;
        node->p_elt = Alloc (node->m_eval, item);
        return LXe_OK;
}


/*
 * Free the allocated element.
 */
CLxItemModifierNode::~CLxItemModifierNode ()
{
        delete p_elt;
}


/*
 * Test if this modifier node matches what we would create with Alloc().
 */
        LxResult
CLxItemModifierNode::mod_Test (
        ILxUnknownID		 item,
        unsigned		 index)
{
        return (p_elt->Test (item) ? LXe_TRUE : LXe_FALSE);
}


/*
 * With the setup done, the evaluation defers completely to the client
 * implementation for reading and setting channels.
 */
        LxResult
CLxItemModifierNode::mod_Evaluate ()
{
        CLxObject		*cache = NULL;
        bool			 prev_eval;

        if (has_cache) {
                cache = (CLxObject *) m_eval.GetCache ();
                prev_eval = (cache != 0);
                if (!prev_eval) {
                        cache = p_elt->Cache ();
                        if (!cache)
                                has_cache = false;
                        else
                                m_eval.SetCache (cache);
                }
        }

        if (has_cache)
                return p_elt->EvalCache (m_eval, m_attr, cache, prev_eval);

        p_elt->Eval (m_eval, m_attr);
        return LXe_OK;
}

/*
 * Cache data installed in evalaution is freed here.
 */
        void
CLxItemModifierNode::mod_Free (
        void			*cacheRaw)
{
        CLxObject		*cache = (CLxObject *) cacheRaw;

        delete cache;
}


/*
 * Validate is called for input channels that change on a modifier with
 * cache state. If Validate() not implemented we return NOTIMPL to disable
 * validation on this modifier type forever.
 */
        LxResult
CLxItemModifierNode::mod_Validate (
        ILxUnknownID		 item,
        unsigned		 channel,
        LxResult		 rc)
{
        CLxObject		*cache = (CLxObject *) m_eval.GetCache ();
        CLxUser_Item		 itm (item);

        if (p_elt->Validate (cache, itm, channel, rc))
                return LXe_OK;
        else
                return LXe_NOTIMPL;
}


/*
 * This implements the only non-template method for the CLxObjectRefModifier
 * system. Evaluate index 0 for the value reference; allocate the real object;
 * insert it into the reference. Done.
 */
        void
CLxObjectRefModifierCore::Eval (
        CLxUser_Evaluation	&eval,
        CLxUser_Attributes	&attr)
{
        CLxUser_ValueReference	 ref;
        ILxUnknownID		 obj;

        attr.ObjectRW (0, ref);
        Alloc (eval, attr, 1, obj);
        ref.SetObject (obj);
        lx::UnkRelease (obj);
}

        void
CLxRenderCamera::Camera (
        CLxUser_Evaluation	&eval, 
        CLxUser_Item		&camera)
{
        CLxUser_Scene		 scene (sceneObj);
        int			 index;

        index = scene.GetRenderCameraIndex (eval);
        scene.GetRenderCameraByIndex (index, camera);
}

/*
 * These implement the RenderCamera utility class.
 */

        void
CLxRenderCamera::BuildList (void)
{
        ILxUnknownID		 camObj;
        CLxUser_Scene		 scene (sceneObj);
        CLxUser_Item		 camera;
        int			 count;
        
        cameraList.clear ();

        count = scene.NRenderCameras ();
        if (count == 0) {
                scene.GetRenderCameraByIndex (-1, camera);
                camera.get ((void **) &camObj);
                cameraList.push_back (camObj);
        }
        else {
                for (int i = 0; i < count; i++) {
                        scene.GetRenderCameraByIndex (i, camera);
                        camera.get ((void **) &camObj);
                        cameraList.push_back (camObj);
                }
        }
}

        bool
CLxRenderCamera::ListIsValid (void)
{
        ILxUnknownID		 camObj;
        CLxUser_Scene		 scene (sceneObj);
        CLxUser_Item		 camera;
        int			 count;

        count = scene.NRenderCameras ();
        if (count == 0) {
                if (cameraList.size() != 1)
                        return false;

                scene.GetRenderCameraByIndex (-1, camera);
                camera.get ((void **) &camObj);
                if (camObj != cameraList[0])
                        return false;
        }
        else if (count != cameraList.size ()) {
                return false;
        }
        else {
                for (int i = 0; i < count; i++) {
                        scene.GetRenderCameraByIndex (i, camera);
                        camera.get ((void **) &camObj);
                        if (camObj != cameraList[i])
                                return false;
                }
        }

        return true;
}

        unsigned
CLxRenderCamera::AttachIndexChan (
        CLxUser_Evaluation	&eval)
{
        CLxUser_Scene		 scene (sceneObj);
        CLxUser_Item		 render_item;
        unsigned		 chanIdx;

        scene.GetItem (LXi_CIT_RENDER, 0, render_item);

        render_item.ChannelLookup ("cameraIndex", &chanIdx);

        this->chanIndex = eval.AddChan (render_item, chanIdx);

        return this->chanIndex;
}

        int
CLxRenderCamera::Camera (CLxUser_Attributes &attr)
{
        return attr.Int (this->chanIndex);
}

        size_t
CLxRenderCamera::size (void)
{
        return cameraList.size();
}

        ILxUnknownID &
CLxRenderCamera::operator[] (
        const int		 index)
{
        return cameraList[index];
}


