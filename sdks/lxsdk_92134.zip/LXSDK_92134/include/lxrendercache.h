/*
 * LX rendercache module
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_rendercache_H
#define LX_rendercache_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxRenderCacheService ** ILxRenderCacheServiceID;
typedef struct vt_ILxRenderCache ** ILxRenderCacheID;
typedef struct vt_ILxRenderCacheListener ** ILxRenderCacheListenerID;
typedef struct vt_ILxGeoCacheSegment ** ILxGeoCacheSegmentID;
typedef struct vt_ILxGeoCacheSurface ** ILxGeoCacheSurfaceID;
#include <lxitem.h>
#include <lxshade.h>
#include <lxvertex.h>


typedef struct st_LXtGeoCacheSrfVisibility {
        unsigned        camera          : 1;
        unsigned        indirect        : 1;
        unsigned        reflection      : 1;
        unsigned        refraction      : 1;
        unsigned        subscatter      : 1;
        unsigned        occlusion       : 1;
} LXtGeoCacheSrfVisibility;
typedef struct vt_ILxRenderCacheService {
        ILxUnknown       iunk;
                LXxMETHOD ( LxResult,
        CreateRenderCache) (
                LXtObjectID       self,
                void            **ppvObj,
                unsigned int      createFlags);
} ILxRenderCacheService;
typedef struct vt_ILxRenderCache {
        ILxUnknown       iunk;
                LXxMETHOD ( void,
        Time) (
                LXtObjectID      self,
                double          *time,
                double          *timeOffsets);
                LXxMETHOD ( LxResult,
        Update) (
                LXtObjectID      self,
                double           time,
                int              force);
                LXxMETHOD ( void,
        Clear) (
                LXtObjectID      self);
                LXxMETHOD ( LxResult,
        GeoSurfaceCount) (
                LXtObjectID      self,
                int             *count);
                LXxMETHOD ( LxResult,
        GeoSurfaceAt) (
                LXtObjectID       self,
                int               index,
                void            **srf);
} ILxRenderCache;
typedef struct vt_ILxRenderCacheListener {
        ILxUnknown       iunk;
                LXxMETHOD (void,
        RenderCacheDestroy) (
                LXtObjectID             self);
                LXxMETHOD (void,
        UpdateBegin) (
                LXtObjectID             self);
                LXxMETHOD (void,
        UpdateEnd) (
                LXtObjectID             self);
                LXxMETHOD (void,
        GeoCacheSurfaceAdd )(
                LXtObjectID             self,
                LXtObjectID             geoSrf);
                LXxMETHOD (void,
        GeoCacheSurfaceRemove )(
                LXtObjectID             self,
                LXtObjectID             geoSrf);
                LXxMETHOD (void,
        GeoCacheSurfaceGeoUpdate )(
                LXtObjectID             self,
                LXtObjectID             geoSrf);
                LXxMETHOD (void,
        GeoCacheSurfaceXformUpdate )(
                LXtObjectID             self,
                LXtObjectID             geoSrf);
                LXxMETHOD (void,
        GeoCacheSurfaceShaderUpdate )(
                LXtObjectID             self,
                LXtObjectID             geoSrf);
} ILxRenderCacheListener;
typedef struct vt_ILxGeoCacheSegment {
        ILxUnknown       iunk;
                LXxMETHOD ( LxResult,
        GetBBox ) (
                LXtObjectID              self,
                LXtBBox                 *bbox);
                LXxMETHOD ( void,
        PolygonCount) (
                LXtObjectID              self,
                int                     *count);
                LXxMETHOD ( void,
        VertexCount) (
                LXtObjectID              self,
                int                     *count);
                LXxMETHOD ( void,
        VertsPerPoly) (
                LXtObjectID              self,
                int                     *count);
                LXxMETHOD ( void,
        VertexFeatureCount) (
                LXtObjectID              self,
                int                      feature,
                int                     *count);
                LXxMETHOD ( LxResult,
        GetPolygonVertexFeature) (
                LXtObjectID              self,
                int                      feature,
                void                    *featureData,
                int                      count,
                int                      start);
                LXxMETHOD ( LxResult,
        GetVertexFeature) (
                LXtObjectID              self,
                int                      feature,
                void                    *featureData,
                int                      count,
                int                      start);
                LXxMETHOD (LxResult,
        GetPolygonVertexInds) (
                LXtObjectID              self,
                int                     *polyVertexInds,
                int                      count,
                int                      start);
} ILxGeoCacheSegment;
typedef struct vt_ILxGeoCacheSurface {
        ILxUnknown       iunk;
                LXxMETHOD ( LxResult,
        ShaderMaskName) (
                LXtObjectID               self,
                const char              **name);
                LXxMETHOD ( int,
        ShaderMaskType) (
                LXtObjectID              self);
                LXxMETHOD ( LxResult,
        SourceItem) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD ( int,
        IsInstanced) (
                LXtObjectID               self);
                LXxMETHOD ( int,
        InstanceIndex) (
                LXtObjectID               self);
                LXxMETHOD ( LxResult,
        SourceSurface) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD ( LxResult,
        GetBBox) (
                LXtObjectID              self,
                LXtBBox                 *bbox);
                LXxMETHOD ( LxResult,
        GetXfrm) (
                LXtObjectID               self,
                LXtVector                 pos,
                LXtMatrix                 rot,
                LXtVector                 scl,
                int                               endpoint);
                LXxMETHOD ( void,
        SegmentCount) (
                LXtObjectID              self,
                int                     *count);
                LXxMETHOD ( void,
        PolygonCount) (
                LXtObjectID              self,
                int                     *count);
                LXxMETHOD ( void,
        VertexCount) (
                LXtObjectID              self,
                int                     *count);
                LXxMETHOD ( LxResult,
        SegmentAt) (
                LXtObjectID               self,
                int                       index,
                void                    **segment);
                LXxMETHOD ( LxResult,
        VisibilityFlags) (
                LXtObjectID                      self,
                LXtGeoCacheSrfVisibility        *flags);
                LXxMETHOD ( int,
        ID) (
                LXtObjectID               self);
                LXxMETHOD ( int,
        IsValid) (
                LXtObjectID               self);
                LXxMETHOD ( LxResult,
        LoadSegments) (
                LXtObjectID               self);
                LXxMETHOD ( LxResult,
        UnloadSegments) (
                LXtObjectID               self);
                LXxMETHOD ( ILxTableauVertexID,
        GetVertexDesc )(
                LXtObjectID               self);
                LXxMETHOD (const char*,
        MaterialPTag ) (
                LXtObjectID               self);
                LXxMETHOD (const char*,
        PartPTag ) (
                LXtObjectID               self);
                LXxMETHOD (const char*,
        PickPTag ) (
                LXtObjectID               self);
} ILxGeoCacheSurface;

#define LXu_RENDERCACHESERVICE  "138FF638-1E34-4CC6-BAFC-4F734969F47E"
#define LXa_RENDERCACHESERVICE  "rendercacheservice"

// [python] ILxRenderCacheService:CreateRenderCache             obj RenderCache
#define LXfRENDERCACHE_GEOCACHE_DISPLACE                                0x1
#define LXfRENDERCACHE_GEOCACHE_GENFUR                                  0x2
#define LXfRENDERCACHE_FULL                                             LXfRENDERCACHE_GEOCACHE_DISPLACE | LXfRENDERCACHE_GEOCACHE_GENFUR
#define LXfRENDERCACHE_TRACK_CURRENT_SCENE                              0x100
#define LXfRENDERCACHE_TURN_OFF_AUTO_UPDATES                            0x200
#define LXfRENDERCACHE_FORCE_FULL_UPDATE                                0x400
#define LXu_RENDERCACHE "1ED14AD3-B202-46FF-A720-A1DCFC0B893A"
#define LXa_RENDERCACHE "rendercache"

// [local] ILxRenderCache
#define LXu_RENDERCACHELISTENER "E1EBCD71-B28A-42FB-9AF7-FADA18FEBFC6"

// [export] ILxRenderCacheListener rli
#define LXu_GEOCACHESEGMENT     "CDA6EDAD-8E71-4EA9-A05A-326CEAD7DE9B"
#define LXa_GEOCACHESEGMENT     "rendercachegeosegment"

// [local] ILxGeoCacheSegment
#define LXiRENDERCACHE_GEOVERT_OPOS             0               // Object-space position (LXtFVector)
#define LXiRENDERCACHE_GEOVERT_ONRM             1               // Object-space normal (LXtFVector)
#define LXiRENDERCACHE_GEOVERT_OVEL             2               // Object-space velocity (LXtFVector)
#define LXiRENDERCACHE_GEOVERT_RAD              3               // Vertex radius (float)
#define LXiRENDERCACHE_GEOVERT_FUR              4               // Fur params (LXtFVector [U, V(=lenParm), id])

#define LXiRENDERCACHE_GEOVERT_UV               0x100           // Vertex UV coords. (LXtFVector2)
#define LXiRENDERCACHE_GEOVERT_DPDU             0x200           // Vertex UV derivatives (LXtFVector3)
#define LXiRENDERCACHE_GEOVERT_DPDV             0x300           // Vertex UV derivatives (LXtFVector3)
#define LXu_GEOCACHESURFACE     "770BD566-315B-4EEC-A2A5-266D122D8DDF"
#define LXa_GEOCACHESURFACE     "rendercachegeosurface"

// [local] ILxGeoCacheSurface
// [python] ILxGeoCacheSurface:SegmentAt        obj     GeoCacheSegment

 #ifdef __cplusplus
  }
 #endif
#endif

