#ifndef LX_VERSION_H
#define LX_VERSION_H

#define LXx_INT_STR(i)		#i		// turn an integer into a string
#define LXx_MACRO_STR(a)	LXx_INT_STR(a)	// extra nesting required for turning macro into string

#define LXi_VERSION_BUILD 92134
#define LXs_VERSION_BRANCH "modo901"
#define LXi_VERSION_BASE 9
#define LXi_VERSION_LIB1 900
#define LXi_VERSION_LIB2 0
#define LXi_VERSION_LIB3 9
#define LXi_VERSION_LIB4 2134
#define LXs_VERSION_LIB "901.0.9.2134"
#define LXs_VERSION_NAME "nexus 9"
#define LXs_VERSION_DESC "nexus 9 by The Foundry"
#define LXs_VERSION_MAKER "The Foundry Group LLC"
#define LXs_VERSION_FNBUILD "9.01v92134"
#define LXi_VERSION_YEAR 2015
#define LXs_VERSION_YEAR "2015"
#define LXi_VERSION_MONTH 9
#define LXs_VERSION_MONTH "9"
#define LXi_VERSION_DAY 2
#define LXs_VERSION_DAY "2"
#define LXs_VERSION_TIME "12:04:10"

#endif


