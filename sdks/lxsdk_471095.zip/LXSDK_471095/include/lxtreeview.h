/*
 * LX treeview module
 *
 * Copyright (c) 2008-2017 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_treeview_H
#define LX_treeview_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxTreeView ** ILxTreeViewID;
typedef struct vt_ILxTreeView3 ** ILxTreeView3ID;
typedef struct vt_ILxTreeView2 ** ILxTreeView2ID;
typedef struct vt_ILxTreeView1 ** ILxTreeView1ID;
#include <lxcom.h>
#include <lxtree.h>
#include <lxserver.h>
#include <lxvalue.h>



typedef struct vt_ILxTreeView {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        StoreState) (
                LXtObjectID              self,
                const char              *uid );

                LXxMETHOD(  LxResult,
        RestoreState) (
                LXtObjectID              self,
                const char              *uid );
                LXxMETHOD(  LxResult,
        StyleHints) (
                LXtObjectID              self,
                int                     *flags );
                LXxMETHOD( LxResult,
        ColumnCount) (
                LXtObjectID              self,
                unsigned*                colCount);
                LXxMETHOD( LxResult,
        ColumnByIndex) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len,
                int                     *columnWidth);
                LXxMETHOD( LxResult,
        ColumnInternalName) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);
                LXxMETHOD( LxResult,
        ColumnIconResource) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);
                LXxMETHOD( LxResult,
        ColumnJustification) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                int                     *justification);
                LXxMETHOD( LxResult,
        PrimaryColumnPosition) (
                LXtObjectID              self,
                unsigned                *index);
                LXxMETHOD(  LxResult,
        ToPrimary) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        IsSelected) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        Select) (
                LXtObjectID     self,
                unsigned        mode);
                LXxMETHOD( LxResult,
        CellCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        BatchCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);
                LXxMETHOD( LxResult,
        ToolTip) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);
                LXxMETHOD( LxResult,
        DescriptionText) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);
                LXxMETHOD( LxResult,
        ShowDescriptionText) (
                LXtObjectID     self);
                LXxMETHOD(  LxResult,
        ReservedSpaceForIcons) (
                LXtObjectID               self,
                int                      *columnIndex,
                int                      *width,
                int                      *height,
                int                      *iconAsValue);
                LXxMETHOD( LxResult,
        IconResource) (
                LXtObjectID               self,
                unsigned                  columnIndex,
                int                       width,
                int                       height,
                char                     *buf,
                unsigned                  len);
                LXxMETHOD(  LxResult,
        ReservedSpaceForThumbnails) (
                LXtObjectID               self,
                int                      *columnIndex,
                int                      *width,
                int                      *height);
                LXxMETHOD( LxResult,
        Thumbnail) (
                LXtObjectID               self,
                unsigned                  columnIndex,
                int                       width,
                int                       height,
                void                    **ppvObj,
                char                     *buf,
                unsigned                  len);
                LXxMETHOD( LxResult,
        BadgeType) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 badgeIndex,
                unsigned                *badgeType);
                LXxMETHOD( LxResult,
        BadgeType2) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 badgeIndex,
                unsigned                *badgeType);
                LXxMETHOD( LxResult,
        BadgeDetail) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 badgeIndex,
                unsigned                 badgeDetail,
                char                    *buf,
                unsigned                 len);
                LXxMETHOD( LxResult,
        IsInputRegion) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 regionID);
                LXxMETHOD( LxResult,
        SupportedDragDropSourceTypes) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        GetDragDropSourceObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                const char              *type,
                void                    **ppvObj);

                LXxMETHOD( LxResult,
        GetDragDropDestinationObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 location,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        IsDescendantSelected) (
                LXtObjectID     self);
                LXxMETHOD(  LxResult,
        CanFilter) (
                LXtObjectID      self);

                LXxMETHOD(  LxResult,
        Filter) (
                LXtObjectID      self,
                int             *flags);
} ILxTreeView;
typedef struct vt_ILxTreeView3 {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        StoreState) (
                LXtObjectID              self,
                const char              *uid );

                LXxMETHOD(  LxResult,
        RestoreState) (
                LXtObjectID              self,
                const char              *uid );

                LXxMETHOD( LxResult,
        ColumnCount) (
                LXtObjectID              self,
                unsigned*                colCount);

                LXxMETHOD( LxResult,
        ColumnByIndex) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len,
                int                     *columnWidth);

                LXxMETHOD( LxResult,
        ColumnInternalName) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        ColumnIconResource) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        ColumnJustification) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                int                     *justification);

                LXxMETHOD( LxResult,
        PrimaryColumnPosition) (
                LXtObjectID              self,
                unsigned                *index);

                LXxMETHOD(  LxResult,
        ToPrimary) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        IsSelected) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        Select) (
                LXtObjectID     self,
                unsigned        mode);

                LXxMETHOD( LxResult,
        CellCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        BatchCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        ToolTip) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        BadgeType) (
                LXtObjectID      self,
                unsigned         columnIndex,
                unsigned         badgeIndex,
                unsigned        *badgeType);

                LXxMETHOD( LxResult,
        BadgeDetail) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 badgeIndex,
                unsigned                 badgeDetail,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        IsInputRegion) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 regionID);

                LXxMETHOD( LxResult,
        SupportedDragDropSourceTypes) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        GetDragDropSourceObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                const char              *type,
                void                    **ppvObj);

                LXxMETHOD( LxResult,
        GetDragDropDestinationObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 location,
                void                    **ppvObj);

                LXxMETHOD(  LxResult,
        IsDescendantSelected) (
                LXtObjectID     self);
} ILxTreeView3;
typedef struct vt_ILxTreeView2 {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        StoreState) (
                LXtObjectID              self,
                const char              *uid );

                LXxMETHOD(  LxResult,
        RestoreState) (
                LXtObjectID              self,
                const char              *uid );

                LXxMETHOD( LxResult,
        ColumnCount) (
                LXtObjectID              self,
                unsigned*                colCount);

                LXxMETHOD( LxResult,
        ColumnByIndex) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len,
                int                     *columnWidth);

                LXxMETHOD( LxResult,
        ColumnInternalName) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        ColumnIconResource) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        ColumnJustification) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                int                     *justification);

                LXxMETHOD( LxResult,
        PrimaryColumnPosition) (
                LXtObjectID              self,
                unsigned                *index);

                LXxMETHOD(  LxResult,
        ToPrimary) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        IsSelected) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        Select) (
                LXtObjectID     self,
                unsigned        mode);

                LXxMETHOD( LxResult,
        CellCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        BatchCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        ToolTip) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        BadgeType) (
                LXtObjectID      self,
                unsigned         columnIndex,
                unsigned         badgeIndex,
                unsigned        *badgeType);

                LXxMETHOD( LxResult,
        BadgeDetail) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 badgeIndex,
                unsigned                 badgeDetail,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        IsInputRegion) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 regionID);

                LXxMETHOD( LxResult,
        SupportedDragDropSourceTypes) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        GetDragDropSourceObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                const char              *type,
                void                    **ppvObj);

                LXxMETHOD( LxResult,
        GetDragDropDestinationObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 location,
                void                    **ppvObj);
} ILxTreeView2;
typedef struct vt_ILxTreeView1 {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        StoreState) (
                LXtObjectID              self,
                const char              *uid );

                LXxMETHOD(  LxResult,
        RestoreState) (
                LXtObjectID              self,
                const char              *uid );

                LXxMETHOD( LxResult,
        ColumnCount) (
                LXtObjectID              self,
                unsigned*                colCount);

                LXxMETHOD( LxResult,
        ColumnByIndex) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len,
                int                     *columnWidth);

                LXxMETHOD(  LxResult,
        ToPrimary) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        IsSelected) (
                LXtObjectID     self);

                LXxMETHOD(  LxResult,
        Select) (
                LXtObjectID     self,
                unsigned        mode);

                LXxMETHOD( LxResult,
        CellCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        BatchCommand) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        ToolTip) (
                LXtObjectID     self,
                unsigned        columnIndex,
                char           *buf,
                unsigned        len);

                LXxMETHOD( LxResult,
        BadgeType) (
                LXtObjectID      self,
                unsigned         columnIndex,
                unsigned         badgeIndex,
                unsigned        *badgeType);

                LXxMETHOD( LxResult,
        BadgeDetail) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 badgeIndex,
                unsigned                 badgeDetail,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        IsInputRegion) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                unsigned                 regionID);

                LXxMETHOD( LxResult,
        SupportedDragDropSourceTypes) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                char                    *buf,
                unsigned                 len);

                LXxMETHOD( LxResult,
        GetDragDropSourceObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                const char              *type,
                void                    **ppvObj);

                LXxMETHOD( LxResult,
        GetDragDropDestinationObject) (
                LXtObjectID              self,
                unsigned                 columnIndex,
                void                    **ppvObj);
} ILxTreeView1;

#define LXu_TREEVIEW                    "86e7a5cc-9a4b-4621-9f97-996e6f7f0a62"
#define LXa_TREEVIEW                    "treeview"
//[export] ILxTreeView treeview
//[local]  ILxTreeView
//[python] ILxTreeView:IsSelected                               bool
//[python] ILxTreeView:IsDescendantSelected                     bool
//[python] ILxTreeView:IsInputRegion                            bool
//[python] ILxTreeView:ToPrimary                                bool
//[python] ILxTreeView:IsDescendantSelected                     bool
//[python] ILxTreeView:GetDragDropSourceObject                  obj Unknown
//[python] ILxTreeView:GetDragDropDestinationObject             obj Unknown
//[python] ILxTreeView:Thumbnail                                obj Image
//[python] ILxTreeView:CanFilter                                bool
#define LXsTREEVIEW_TYPE                "TreeViewType"
#define LXsTREEVIEW_EMBEDABILITY        "TreeViewEmbedability"
#define LXsTREEVIEW_OPTIONS_FORM        "TreeViewOptionsForm"
#define LXfTREEVIEWSTYLE_SECTIONS               0x0001
#define LXfTREEVIEWSTYLE_CHILDREN               0x0002
#define LXfTREEVIEWSTYLE_ATTRIBUTES             0x0004

#define LXfTREEVIEWSTYLE_DEFAULT                (LXfTREEVIEWSTYLE_CHILDREN | LXfTREEVIEWSTYLE_ATTRIBUTES)
#define LXiTREEJUST_LEFT                0
#define LXiTREEJUST_CENTER              1
#define LXiTREEJUST_RIGHT               2
#define LXiTREEVIEW_SELECT_PRIMARY              0x001
#define LXiTREEVIEW_SELECT_ADD                  0x002
#define LXiTREEVIEW_SELECT_REMOVE               0x003
#define LXiTREEVIEW_SELECT_CLEAR                0x004

#define LXiTREEVIEW_BATCH_BEGIN                 0x010
#define LXiTREEVIEW_BATCH_END                   0x020

#define LXiTREEVIEW_MAKE_TOPMOST                0x100

#define LXiTREEVIEWm_SELECT                     0x00F
#define LXiTREEVIEWm_BATCH                      0x0F0

#define LXiTREEVIEWx_IS_SELECT(m)               ((m) & TPSELm_SELECT)
#define LXiTREEVIEWx_IS_BATCH(m)                ((m) & TPSELm_BATCH)
#define LXiTREEVIEW_BADGE_INFO                  0x01
#define LXiTREEVIEW_BADGE_TOGGLE_ON             0x02
#define LXiTREEVIEW_BADGE_TOGGLE_OFF            0x03
#define LXiTREEVIEW_BADGE_ACTION                0x04
#define LXiTREEVIEW_BADGE_RATING                0x05
#define LXfTREEVIEW_BADGE_INFO                  0x10000000                      // Always visible badge, usually to indicate some permenant state
#define LXfTREEVIEW_BADGE_TOGGLE                0x20000000                      // Badge that represents a state on the item, and may be on or off
#define LXfTREEVIEW_BADGE_ACTION                0x30000000                      // Badge that is only visible when the mouse moves over the cell, and is usually clicked as a button by the user
#define LXfTREEVIEW_BADGE_STARRATING            0x40000000                      // Special badge that the user can use to choose a star rating

#define LXfTREEVIEW_BADGE_SPECIAL               0x01000000                      // Badge appears immediately to the right of the label, instead of the far right edge of the cell.  Only one badge can have this flag, and it must be the last one in the list.

#define LXfTREEVIEW_BADGE_IS_VISIBLE            0x00100000                      // True if the badge should be drawn; false to hide it
#define LXfTREEVIEW_BADGE_IS_VISIBLE_WHEN_OFF   0x00200000                      // True if a toggle badge should be drawn even off; false if it should only be drawn when on or when the mouse is over the cell

#define LXfTREEVIEW_BADGE_IS_ON                 0x00000001                      // True if the badge should be drawn in its "on" state

#define LXfTREEVIEW_BADGE_VALUE_FROM_QUERY      0x00001000                      // When set, the value is obtained by querying the action command
#define LXiTREEVIEW_BADGE_DETAIL_ICON_ON        0x01
#define LXiTREEVIEW_BADGE_DETAIL_ICON_OFF       0x02
#define LXiTREEVIEW_BADGE_DETAIL_ACTION         0x03
#define LXiTREEVIEW_BADGE_DETAIL_TOOLTIP        0x04
#define LXfTREEFILTER_SHOW                       0x00000
#define LXfTREEFILTER_HIDE                       0x00001

#define LXfTREEFILTER_SHOW_IF_CHILDREN_MATCH     0x00010
#define LXfTREEFILTER_SHOW_WITH_ALL_CHILDREN     0x00020

#define LXfTREEFILTERx_SHOW(f)                   (((f) & LXfTREEFILTER_HIDE) ? 0 : 1)
#define LXu_TREEVIEW3           "ec0c5d6f-9477-4bae-97e8-2205ed1cdb23"
//[export] ILxTreeView3 treeview3
//[local]  ILxTreeView3
//[python] ILxTreeView3:IsSelected      bool
//[python] ILxTreeView3:IsInputRegion   bool
//[python] ILxTreeView3:ToPrimary       bool
//[python] ILxTreeView3:GetDragDropSourceObject         obj Unknown
//[python] ILxTreeView3:GetDragDropDestinationObject    obj Unknown
#define LXu_TREEVIEW2           "8307d6f1-c30b-48e7-a0ee-aab0a45bcf1d"
//[export] ILxTreeView2 treeview2
//[local]  ILxTreeView2
//[python] ILxTreeView2:IsSelected      bool
//[python] ILxTreeView2:IsInputRegion   bool
//[python] ILxTreeView2:ToPrimary       bool
//[python] ILxTreeView2:GetDragDropSourceObject         obj Unknown
//[python] ILxTreeView2:GetDragDropDestinationObject    obj Unknown
#define LXu_TREEVIEW1           "e4b1f6b4-fed6-4668-9b6b-9526b59cd9ee"
//[export] ILxTreeView1 treeview1
//[local]  ILxTreeView1
//[python] ILxTreeView1:IsSelected      bool
//[python] ILxTreeView1:IsInputRegion   bool
//[python] ILxTreeView1:ToPrimary       bool
//[python] ILxTreeView1:GetDragDropSourceObject         obj Unknown
//[python] ILxTreeView1:GetDragDropDestinationObject    obj Unknown

 #ifdef __cplusplus
  }
 #endif
#endif

