/*
 * Plug-in Kelvin color model.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * A plug-in color model that enables picking colors using a
 * Kelvin color temperature component.
 */
#ifndef KELVINCOLORMODEL_H
#define KELVINCOLORMODEL_H

#include <lxlog.h>
#include <lxu_log.hpp>
#include <lx_color.hpp>
#include <lx_image.hpp>

class CKelvinColorModelLog : public CLxLuxologyLogMessage
{
    public:
        CKelvinColorModelLog ()
                :
                CLxLuxologyLogMessage ("kelvin-color-model") { }

        const char *	 GetFormat  () { return "Kelvin Color Model"; }
};

class CKelvinColorModel :
        public CLxImpl_ColorModel
{
        CKelvinColorModelLog	 m_log;

    public:
        static LXtTagInfoDesc	 descInfo[];

                                 CKelvinColorModel ();
        virtual			~CKelvinColorModel ();

        virtual int		 colm_NumComponents (void);

        virtual LxResult	 colm_ComponentType (
                                        unsigned	 componentIndex,
                                        const char	**type);

        virtual LxResult	 colm_ComponentRange (
                                        unsigned	 componentIndex,
                                        float		*minValue,
                                        float		*maxValue);

        virtual LxResult	 colm_ToRGB (
                                        const float	*kelvin,
                                        float		*rgb);

        virtual LxResult	 colm_FromRGB (
                                        const float	*rgb,
                                        float		*kelvin);

        virtual LxResult	 colm_DrawSlice (
                                        ILxUnknownID	 image,
                                        unsigned	 xAxis,
                                        unsigned	 yAxis,
                                        const float	*vec);

        virtual LxResult	 colm_DrawSliceMarker (
                                        ILxUnknownID	 image,
                                        unsigned	 xAxis,
                                        unsigned	 yAxis,
                                        const float	*downVec,
                                        const float	*kelvin);

        virtual LxResult	 colm_CanSliceBeReused (
                                        unsigned	  xAxis,
                                        unsigned	  yAxis,
                                        const float	 *oldVec,
                                        const float	 *newVec);

        virtual LxResult	 colm_ToSlicePos (
                                        unsigned	 xAxis,
                                        unsigned	 yAxis,
                                        unsigned	 imgW,
                                        unsigned	 imgH,
                                        const float	*kelvin,
                                        unsigned	*imgX,
                                        unsigned	*imgY);

        virtual LxResult	 colm_FromSlicePos (
                                        unsigned	 xAxis,
                                        unsigned	 yAxis,
                                        unsigned	 imgW,
                                        unsigned	 imgH,
                                        unsigned	 imgX,
                                        unsigned	 imgY,
                                        float		*downVec,
                                        float		*kelvin);

        virtual LxResult	 colm_StripBaseVector (
                                        unsigned	 axis,
                                        int		 dynamic,
                                        float		*kelvin);

    private:
        unsigned		 MinTemp () const;
        unsigned		 MaxTemp () const;

        CLxUser_ImageService	 imageSvc;
};

#endif // KELVINCOLORMODEL_H

