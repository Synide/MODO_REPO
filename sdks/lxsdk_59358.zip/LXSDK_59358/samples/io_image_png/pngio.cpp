/*
 * Plug-in PNG loader/saver for Images.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * 
 * CAPABILITIES
 * ------------
 * This plug-in loads and saves the following sub-formats:
 *
 * - Grayscale 8- and 16-bits per pixel
 * - RGB 24- and 48-bits per pixel
 * - RGBA 32- and 64-bits per pixel
 *
 * This plug-in also loads the following sub-formats:
 *
 * - Palette-based 1-, 2-, 4-, and 8-bits per pixel
 *
 * The 8-bit color channel sub-formats map onto the modo LXiIMP_GREY8,
 * LXiIMP_RGB24, and LXiIMP_RGBA32 sub-formats respectively.
 *
 * Palette-based images are mapped to the "indexed" LXiIMP_RGB24 format.
 *
 * The 16-bit color channel sub-formats map onto the modo LXiIMP_GREYFP,
 * LXiIMP_RGBFP, and LXiIMP_RGBAFP sub-formats respectively, by converting
 * to and from the ranges 0..1.0 <-> 0..65535. When modo renders values that
 * exceed 1.0, we clip those values to 65535.
 *
 * This plug-in also loads and saves RLE-compressed files in all supported
 * formats.
 *
 * DEPENDENCIES
 * ------------
 * This plug-in uses the LibPNG library to provide compression and
 * decompression services for the PNG file format.
 *
 * BUILD TARGETING
 * ---------------
 * The LibPNG library performs all of the necessary format swapping internally.
 * The signature check and the 24-bit line processing into the Lux 24-bit format
 * uses channel array subscripting, such that it is not endian-dependent.
 */

/*
 * Suppress warnings for deprecated functions.
 */
#ifdef _MSC_VER
        #define _CRT_SECURE_NO_WARNINGS 1
        #define _CRT_SECURE_NO_DEPRECATE 1
        #pragma warning(disable: 4996)
#endif

#include <lx_action.hpp>
#include <lx_io.hpp>
#include <lx_item.hpp>
#include <lx_image.hpp>
#include <lx_value.hpp>
#include <lxu_log.hpp>
#include <lx_log.hpp>
#include <lx_stddialog.hpp>
#include <lx_seltypes.hpp>
#include <lxidef.h>
#include <lxlog.h>
#include <lxu_queries.hpp>

#include <string.h>
#include <string>

using namespace std;

#include "../libpng/png.h"

/*
 * ----------------------------------------------------------------
 * Callback functions for interacting with LibPNG. 
 */ 

        static void
error_handler (png_structp png, const char *error)
{
        /*
         * The exception handler will write an error message to the logging API.
         */
        throw error;
}


        static void
warning_handler (png_structp png, const char *warning)
{
        /*
         * Warnings are disabled.
         */
}

/*
 * Modes to switch PNG loader and saver between file and memory I/O.
 */
typedef enum {
        IO_MODE_FILE,
        IO_MODE_MEMORY,
        IO_MODE_MEMORY_OVERFLOW
} IO_Mode;

/*
 * Allocate a line buffer for I/O.
 */
LXtImageByte* NewLineBuffer(
        size_t			lineSize)
{
#ifdef TESTLOWMEMORY
        #define MAX_LINE_SIZE	32768

        if (lineSize > MAX_LINE_SIZE) {
                return 0;
        }
#endif
        return new LXtImageByte[lineSize];
}

/*
 * Number of bytes that are verified for the PNG file signature.
 */
static const int PNG_BYTES_TO_CHECK	= 8;

/*
 * Used in pixels-per-meter calculations.
 *
 * We have added four more decimal places of accuracy to
 * propagate pixels-per-meter values unchanged.
 */
static const double INCHES_PER_METER = 39.370079;

/*
 * 1-, 4-, and 8-bit files contain a color palette of BGRA entries.
 */
typedef struct tagBGRA {
        unsigned char		blue;
        unsigned char		green;
        unsigned char		red;
        unsigned char		alpha;
} BGRA;

/*
 * Big endian / little endian conversion functions.
 *
 * Some versions of gcc may have BYTE_ORDER or __BYTE_ORDER defined.
 * If your big-endian system isn't being detected, add an OS-specific check.
 */
#if (defined(BYTE_ORDER) && BYTE_ORDER==BIG_ENDIAN) || \
        (defined(__BYTE_ORDER) && __BYTE_ORDER==__BIG_ENDIAN) || \
        defined(__BIG_ENDIAN__)
#define BIGENDIAN
#endif // BYTE_ORDER

/*
 * ----------------------------------------------------------------
 * PNG Loader -- subclass of "Loader" implementation class.
 *
 * Our local data includes an image target, and a file pointer, which are
 * carried over from the load_Recognize function to the load_LoadObject function.
 */
class CPNGLoader : public CLxImpl_Loader1
{
        CLxUser_LogService	 log;
        LXtImageTarget1		 img_target;


        IO_Mode			 ioMode;
        size_t			 ioOffset;
 	LXtImageByte		*ibcBuffer;
        size_t			 ibcBufferSize;
        FILE			*open_file;

        size_t			 lineByteSize;
        LXtImageByte		*lineBuffer;
        size_t			 convertByteSize;
        int			 srcColorType;
        LXtImageByte		*convertBuffer;

        CLxUser_IndexImageWrite	 wimgIndex;
        LXtPixelFormat		 format;

        png_structp		 pngRead;
        png_infop		 pngInfo;

        void			 load_ColorTable ();
        LxResult		 load_MapFormat ();
        LxResult		 load_NewLineBuffers ();
        LxResult		 load_LoadScanlines (
                                        CLxUser_ImageWrite	&wimg,
                                        LXtObjectID		 monitor);
        LxResult		 load_ProcessLine (
                                        CLxUser_ImageWrite	&wimg,
                                        unsigned		 y);

        void			 load_ReadAttrs (
                                        CLxUser_ImageWrite	&wimg,
                                        ILxUnknownID		 dest);
        int			 load_AddAttribute (
                                        CLxUser_ImageWrite	&wimg,
                                        const char		*name,
                                        const char		*type);

    public:
                                 CPNGLoader ();

        void			 load_SetIOMode (
                                        IO_Mode			 saverIOmode,
                                        LXtImageByte		*srcIBCbuffer = NULL,
                                        size_t			 srcIBCbufferSize = 0);
        size_t			 load_GetIO_Offset () const
        {
                return ioOffset;
        }

        LxResult		 load_Recognize  (LXtLoadAccess1 *load) LXx_OVERRIDE;

        const LXtImageTarget1*	 load_GetImageTarget () const
        {
                return &img_target;
        }

        LxResult		 load_RecognizePNG_DataStream ();

        LxResult		 load_LoadObject (
                                        LXtLoadAccess1	*load,
                                        ILxUnknownID	 dest) LXx_OVERRIDE;

        LxResult		 load_LoadImage (
                                        CLxUser_ImageWrite	&wimg,
                                        LXtObjectID		 monitor = NULL);

        LxResult		 load_Cleanup    (LXtLoadAccess1 *load) LXx_OVERRIDE;

        LxResult		 load_ReadBytes (
                                        unsigned char	*bytes,
                                        size_t		 byteCount);

        static LXtTagInfoDesc	 descInfo[];
};

/*
 * The tags for the server indicate that it can load images and provide
 * a file pattern.
 */

LXtTagInfoDesc	 CPNGLoader::descInfo[] = {
        { LXsLOD_CLASSLIST,	LXa_IMAGE		},
        { LXsLOD_DOSPATTERN,	"*.png"			},
        { LXsLOD_THREADSAFE,	"Yes"			},
        { LXsSRV_USERNAME,	"@ImageIO.PNG@loader@"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"		},
        { 0 }
};

/*
 * Constructor.
 */
CPNGLoader::CPNGLoader ()
        :
        ioMode(IO_MODE_FILE),
        ioOffset(0),
        ibcBuffer(NULL),
        ibcBufferSize(0),
        open_file(NULL),
        lineByteSize(0),
        lineBuffer(NULL),
        convertByteSize(0),
        convertBuffer(NULL),
        format(0),
        pngRead(NULL),
        pngInfo(NULL)
{
}

/*
 * Set the mode used for I/O (file or memory).
 */
        void
CPNGLoader::load_SetIOMode (
        IO_Mode			 saverIOmode,
        LXtImageByte		*srcIBCbuffer,
        size_t			 srcIBCbufferSize)
{
        ioMode = saverIOmode;
        ioOffset = 0;
        ibcBuffer = srcIBCbuffer;
        ibcBufferSize = srcIBCbufferSize;
}

/*
 * ----------------------------------------------------------------
 * Callback function for interacting with LibPNG. 
 */ 

/*
 * Read bytes according to the current I/O mode (memory or file).
 */
        static void
ReadProc (png_structp pngRead, unsigned char *data, png_size_t size)
{
        CPNGLoader	*pngLoader =
                reinterpret_cast<CPNGLoader*>(png_get_io_ptr(pngRead));

        LxResult result = pngLoader->load_ReadBytes (data, size);
        if (LXx_FAIL (result)) {
                throw "Read error: invalid or corrupted PNG file";
        }
}

/*
 * Load the color table.
 */
        void
CPNGLoader::load_ColorTable ()
{
        int			paletteEntries = 0;
        png_colorp		pngPalette = NULL;
        LXtImageByte		rgbColor[4];

        /*
         * Grab a pointer to the RGB color table.
         */
        png_get_PLTE (pngRead, pngInfo, &pngPalette, &paletteEntries);

        /*
         * Grab a pointer to a table of indices into the transparent entries.
         */
        int num_trans = 0; 
        png_bytep trans = NULL; 
        if (wimgIndex.Format () == LXiIMP_IRGBA32) {
                if (png_get_valid (pngRead, pngInfo, PNG_INFO_tRNS)) {
                        png_get_tRNS (pngRead, pngInfo, &trans, &num_trans, NULL);
                }
        }

        /*
         * Allocate a color table with RGBA entries for the composite table.
         */
        typedef struct tagRGBA {
                unsigned char		red;
                unsigned char		green;
                unsigned char		blue;
                unsigned char		alpha;
        } RGBA;

        unsigned		 colorIndex;
        RGBA			*colorTable;
        colorTable = new RGBA[paletteEntries];
        if (colorTable) {
                /*
                 * Copy the RGB values into the composite table.
                 */
                for (colorIndex = 0;
                     colorIndex < static_cast<unsigned>(paletteEntries);
                     ++colorIndex) {
                        colorTable[colorIndex].red = pngPalette[colorIndex].red;
                        colorTable[colorIndex].green = pngPalette[colorIndex].green;
                        colorTable[colorIndex].blue = pngPalette[colorIndex].blue;
                        colorTable[colorIndex].alpha = 0xFF;
                }

                LXtPixelFormat format = LXiIMP_RGB24;

                /*
                 * Clear the alpha of the color table entries
                 * indexed by the transparency table.
                 */
                if (trans && num_trans && (num_trans <= 256)) {
                        for (unsigned transIndex = 0;
                             transIndex < static_cast<unsigned>(num_trans); ++transIndex) {
                                colorTable[transIndex].alpha = trans[transIndex];
                        }
                        format = LXiIMP_RGBA32;
                }

                /*
                 * Install the palette into the indexed image.
                 */
                for (colorIndex = 0;
                     colorIndex < static_cast<unsigned>(paletteEntries);
                     ++colorIndex) {
                        rgbColor[0] = colorTable[colorIndex].red;
                        rgbColor[1] = colorTable[colorIndex].green;
                        rgbColor[2] = colorTable[colorIndex].blue;
                        rgbColor[3] = colorTable[colorIndex].alpha;

                        wimgIndex.SetMap (colorIndex, format, rgbColor);
                }

                delete [] colorTable;
        }
}

/*
 * Map the PNG format onto the closest Lux format.
 */
        LxResult
CPNGLoader::load_MapFormat ()
{
        LxResult		result = LXe_FAILED;

        /*
         * Let LibPNG know that we have already read the signature...
         */
        png_set_sig_bytes (pngRead, PNG_BYTES_TO_CHECK);

        /*
         * Read the IHDR chunk.
         */
        png_read_info (pngRead, pngInfo);

        png_uint_32	width, height;

        /* 
         * pixel_depth = bit_depth * channels
         */
        int		bitDepth, pixelDepth;
        png_get_IHDR (
                pngRead, pngInfo,
                &width, &height,
                &bitDepth, &srcColorType,
                NULL, NULL, NULL);

        pixelDepth = pngInfo->pixel_depth;

        convertByteSize = 0;
        if (bitDepth <= 8) {
                if (srcColorType == PNG_COLOR_TYPE_PALETTE) {
                        bool hasTransparency = false;
                        if (png_get_valid (pngRead, pngInfo, PNG_INFO_tRNS)) {
                                int num_trans = 0; 
                                png_bytep trans = NULL; 
                                png_get_tRNS (pngRead, pngInfo, &trans, &num_trans, NULL);
                                hasTransparency = (num_trans > 0);
                        }
                        format = hasTransparency ? LXiIMP_RGBA32 : LXiIMP_RGB24;

                        /*
                         * Expand palette-based formats to 8 bits per pixel.
                         */
                        png_set_packing (pngRead);
                        pixelDepth = 8;
                        convertByteSize = (width * pixelDepth + 31) / 32 * 4;
                        result = LXe_OK;
                }
                else if (srcColorType == PNG_COLOR_TYPE_GRAY) {
                        format = LXiIMP_GREY8;
                        convertByteSize = (width * 8 + 31) / 32 * 4;
                        result = LXe_OK;
                }
                else if (srcColorType == PNG_COLOR_TYPE_GRAY_ALPHA) {
                        format = LXiIMP_RGBA32;
                        png_set_gray_to_rgb (pngRead);
                        convertByteSize = width * 4;
                        pixelDepth = 32;
                        result = LXe_OK;
                }
                else if (srcColorType == PNG_COLOR_TYPE_RGB) {
                        format = LXiIMP_RGB24;
                        convertByteSize = (width * 24 + 31) / 32 * 4;
                        result = LXe_OK;
                }
                else if (srcColorType == PNG_COLOR_TYPE_RGB_ALPHA) {
                        format = LXiIMP_RGBA32;
                        convertByteSize = width * 4;
                        result = LXe_OK;
                }
        }
        else if (bitDepth == 16) {
                if (srcColorType == PNG_COLOR_TYPE_GRAY) {
                        format = LXiIMP_GREYFP;
                        convertByteSize = width * sizeof(LXtImageFloat);
                        result = LXe_OK;
                }
                else if (srcColorType == PNG_COLOR_TYPE_GRAY_ALPHA) {
                        format = LXiIMP_RGBAFP;
                        convertByteSize = width * sizeof(LXtImageFloat) * 4;
                        png_set_gray_to_rgb (pngRead);
                        result = LXe_OK;
                }
                else if (srcColorType == PNG_COLOR_TYPE_RGB) {
                        format = LXiIMP_RGBFP;
                        convertByteSize = width * sizeof(LXtImageFloat) * 3;
                        result = LXe_OK;
                }
                else if (srcColorType == PNG_COLOR_TYPE_RGB_ALPHA) {
                        format = LXiIMP_RGBAFP;
                        convertByteSize = width * sizeof(LXtImageFloat) * 4;
                        result = LXe_OK;
                }

#ifndef BIGENDIAN
                /*
                 * Turn on 16-bit byte swapping.
                 */
                png_set_swap (pngRead);
#endif						
        }

        /*
         * All transformations have been registered; now update pngInfo data.
         */
        png_read_update_info (pngRead, pngInfo);

        /*
         * The color type may have changed, due to our transformations.
         */
        srcColorType = png_get_color_type (pngRead, pngInfo);
        if (srcColorType == PNG_COLOR_TYPE_PALETTE) {
                int			paletteEntries = 0;
                png_colorp		pngPalette = NULL;
                png_get_PLTE (pngRead, pngInfo, &pngPalette, &paletteEntries);
                img_target.ncolor = static_cast<unsigned>(paletteEntries);
        }
        else {
                img_target.ncolor = 0;
        }

        if (result == LXe_OK) {
                img_target.type   = format;
                img_target.w      = width;
                img_target.h      = height;
        }

        return result;
}

/*
 * Allocated the line buffers used for I/O and conversion.
 */
        LxResult
CPNGLoader::load_NewLineBuffers ()
{
        LxResult		 result = LXe_FAILED;
        unsigned		 width = pngInfo->width;
        unsigned		 height = pngInfo->height;

        lineBuffer = 0;
        lineByteSize = 0;
        convertBuffer = 0;

        lineByteSize = (width * pngInfo->pixel_depth + 31) / 32 * 4;
        if (pngInfo->interlace_type != PNG_INTERLACE_NONE) {
                /*
                 * For the interlaced case, attempting to combine multiple
                 * passes over each scanline is not possible due to
                 * transforms, so we punt on scanline I/O mode and read all
                 * of the source image data into a single buffer.
                 */
                lineBuffer = new LXtImageByte [lineByteSize * height];
        }
        else {
                lineBuffer = NewLineBuffer (lineByteSize);
        }

        /*
         * Regardless of the source image interlace mode, we can convert a
         * single scanline at a time.
         */
        convertBuffer = NewLineBuffer (convertByteSize);

        if ((!lineBuffer) || (!convertBuffer)) {
                result = LXe_OUTOFMEMORY;
                log.DebugOutSys (LXi_DBLOG_ERROR, LXsSRV_LOGSUBSYSTEM,
                        "Not enough memory for line buffers.");
        }
        else {
                result = LXe_OK;
        }

        return result;
}

/*
 * Load the image scanlines. The monitor parameter can be NULL.
 */
        LxResult
CPNGLoader::load_LoadScanlines (
        CLxUser_ImageWrite	&wimg,
        LXtObjectID		 monitor)
{
        LxResult		 result = LXe_OK;
        CLxUser_Monitor		 mon;
        unsigned		 height = pngInfo->height;
        unsigned		 y;

        /*
         * Set up a progress indicator.
         */
        if (monitor) {
                mon.set (monitor);
                mon.Init (pngInfo->height);
        }

        if (pngInfo->interlace_type != PNG_INTERLACE_NONE) {
                png_bytepp rows = new png_bytep [height * sizeof(png_bytep)];

                for (png_uint_32 rowIndex = 0; rowIndex < height; ++rowIndex) {
                        rows[rowIndex] = lineBuffer + lineByteSize * rowIndex;
                }

                /*
                 * Read all of the source image data into our row data array.
                 */
                png_read_image (pngRead, rows);

                /*
                 * Temporarily increment the line buffer, and convert each
                 * scanline to the destination Luxology image format.
                 */
                LXtImageByte *lineBufferBase = lineBuffer;
                for (y = 0; y < height; ++y) {
                        lineBuffer = lineBufferBase + lineByteSize * y;
                        result = load_ProcessLine (wimg, y);
                        if (LXx_FAIL (result)) {
                                break;
                        }
                        else if (mon.test () && mon.Step ()) {
                                result = LXe_ABORT;
                                break;
                        }
                }

                /*
                 * Restore the base line buffer pointer.
                 */
                lineBuffer = lineBufferBase;

        }
        else {
                /*
                 * The optimal case for non-interlaced images.
                 */
                for (y = 0; y < height; ++y) {
                        png_read_row (pngRead, lineBuffer, 0);
                        result = load_ProcessLine (wimg, y);
                        if (LXx_FAIL (result)) {
                                break;
                        }
                        else if (mon.test () && mon.Step ()) {
                                result = LXe_ABORT;
                                break;
                        }
                }
        }

        return result;
}

/*
 *
 */
        LxResult
CPNGLoader::load_ProcessLine (
        CLxUser_ImageWrite	&wimg,
        unsigned		 y)
{
        LxResult		 result = LXe_OK;

        unsigned		 width = pngInfo->width;

        if ((format == LXiIMP_GREY8) ||
            (format == LXiIMP_RGB24) ||
            (format == LXiIMP_RGBA32)) {
                if (pngInfo->color_type == PNG_COLOR_TYPE_PALETTE) {
                        /*
                         * Write the palette indices into the indexed image.
                         */
                        LXtImageByte *sourceIter = lineBuffer;
                        for (unsigned x = 0; x < width; ++x) {
                                LXtImageByte color = *sourceIter++;
                                wimgIndex.SetIndex (
                                        x, y,
                                        static_cast<LXtImageIndex>(color));
                        }
                }
                else {
                        /*
                         * Grayscale or true color.
                         */
                        result = wimg.SetLine (y, format, lineBuffer);
                }
        }
        else {

                static const float ONEOVERMAXUINT16 = 1.0f / 65535.0f;

                unsigned short *sourceIter =
                        reinterpret_cast<unsigned short*>(lineBuffer);
                LXtImageFloat *destIter =
                        reinterpret_cast<LXtImageFloat*>(convertBuffer);
                if (format == LXiIMP_GREYFP) {
                        for (unsigned x = 0; x < width; ++x) {
                                unsigned short color16 = *sourceIter++;
                                *destIter++ = static_cast<LXtImageFloat>(
                                        color16) * ONEOVERMAXUINT16;
                        }
                }
                else if (format == LXiIMP_RGBFP) {
                        for (unsigned x = 0; x < width; ++x) {
                                destIter[0] = static_cast<LXtImageFloat>(
                                        sourceIter[0]) * ONEOVERMAXUINT16;
                                destIter[1] = static_cast<LXtImageFloat>(
                                        sourceIter[1]) * ONEOVERMAXUINT16;
                                destIter[2] = static_cast<LXtImageFloat>(
                                        sourceIter[2]) * ONEOVERMAXUINT16;
                                sourceIter += 3;
                                destIter += 3;
                        }
                }
                else if (format == LXiIMP_RGBAFP) {
                        for (unsigned x = 0; x < width; ++x) {
                                destIter[0] = static_cast<LXtImageFloat>(
                                        sourceIter[0]) * ONEOVERMAXUINT16;
                                destIter[1] = static_cast<LXtImageFloat>(
                                        sourceIter[1]) * ONEOVERMAXUINT16;
                                destIter[2] = static_cast<LXtImageFloat>(
                                        sourceIter[2]) * ONEOVERMAXUINT16;
                                destIter[3] = static_cast<LXtImageFloat>(
                                        sourceIter[3]) * ONEOVERMAXUINT16;
                                sourceIter += 4;
                                destIter += 4;
                        }
                }
                /*
                 * Set the processed line.
                 */
                result = wimg.SetLine (y, format, convertBuffer);
        }

        return result;
}

/*
 * Read in any attributes, such as "ToolPreset".
 */
        void
CPNGLoader::load_ReadAttrs (
        CLxUser_ImageWrite	&wimg,
        ILxUnknownID		 dest)
{
        CLxUser_Attributes attr (dest);
        if (attr.test ()) {
                int	attrIndex;

                /*
                 * Starting with Photoshop CS3, PNGs are no longer saved with
                 * the gamma chunk, apparently because so many other apps
                 * mis-interpreted the value. Since older PNGs tend to have
                 * the wrong value, we'll also skip reading gamma.
                 */

                /*
                 * Add the "ToolPreset" attribute for brush preset images.
                 */
                const char *toolPresetTag = "ToolPreset";
                png_textp text_metadata = NULL;
                int num_text = 0;
                if (png_get_text (pngRead, pngInfo, &text_metadata, &num_text) > 0) {
                        for (int i = 0; i < num_text; i++) {
                                if (strcmp (text_metadata[i].key, toolPresetTag) == 0) {
                                        char *textValue = text_metadata[i].text;
                                        if (textValue) {
                                                attrIndex = load_AddAttribute (
                                                        wimg,
                                                        "ToolPreset",
                                                        LXsTYPE_STRING);
                                                if (attrIndex >= 0) {
                                                        attr.Set (attrIndex, textValue);
                                                }
                                        }

                                        /*
                                         * Break after the first tag that matches "ToolPreset".
                                         */
                                        break;
                                }
                        }
                }
        }
}

/*
 * Add an attribute to the image.
 */
        int
CPNGLoader::load_AddAttribute (
        CLxUser_ImageWrite	&wimg,
        const char		*name,
        const char		*type)
{
        unsigned int		 idx;
        LxResult		 rc;

        if (wimg.test ())
                rc = wimg.AddAttribute (name, type, idx);
        else
                rc = wimgIndex.AddAttribute (name, type, idx);

        return LXx_OK (rc) ? idx : -1;
}

/*
 * Check if we recognize a PNG data stream,
 * and then prepare to read it in.
 */
        LxResult
CPNGLoader::load_RecognizePNG_DataStream ()
{
        LxResult	result = LXe_FAILED;

        pngRead = NULL;
        pngInfo = NULL;

        /*
         * Check the first eight bytes in the data stream,
         * to determine if it is in fact a PNG data stream.
         */
        unsigned char pngSignature[PNG_BYTES_TO_CHECK];
        if (LXx_OK (load_ReadBytes (&pngSignature[0], PNG_BYTES_TO_CHECK))) {
                if (png_sig_cmp (pngSignature, static_cast<png_size_t>(0), PNG_BYTES_TO_CHECK) == 0) {
                        pngRead = png_create_read_struct (
                                PNG_LIBPNG_VER_STRING,
                                static_cast<png_voidp>(NULL), error_handler, warning_handler);
                        if (pngRead) {
                                pngInfo = png_create_info_struct (pngRead);
                                if (pngInfo) {
                                        png_set_read_fn (
                                                pngRead,
                                                reinterpret_cast<png_voidp>(this),
                                                ReadProc);
                                        if (setjmp (png_jmpbuf (pngRead))) {
                                                png_destroy_read_struct (
                                                        &pngRead,
                                                        &pngInfo, NULL);
                                                return result;
                                        }
                                        else {
                                                result = load_MapFormat ();
                                                if (LXx_FAIL (result)) {
                                                        png_destroy_read_struct (
                                                                &pngRead,
                                                                &pngInfo,
                                                                static_cast<png_infopp>(NULL));
                                                }
                                        }
                                }
                                else {
                                        png_destroy_read_struct (
                                                &pngRead,
                                                static_cast<png_infopp>(NULL),
                                                static_cast<png_infopp>(NULL));
                                }
                        }
                }
        }

        return result;
}

#define LX_PNG8_SERVER_NAME		"PNG"
#define LX_PNG16_SERVER_NAME		"PNG16"

/*
 * Recognize method must scan the file to see if it finds the data it
 * can understand.
 */
        LxResult
CPNGLoader::load_Recognize (
        LXtLoadAccess1		*load)
{
        LxResult	result = LXe_FAILED;

        /*
         * We start off with a file, but then treat it
         * as an abstract data stream.
         */
        open_file = fopen (load->filename, "rb");
        if (open_file) {
                /*
                 * Check if we recognize a PNG data stream,
                 * and then prepare to read it in.
                 */
                result = load_RecognizePNG_DataStream ();

                /*
                 * LXtLoadAccess1 is only relevant in the file I/O context.
                 */
                if (result == LXe_OK) {
                        load->found = lx::LookupGUID (LXa_IMAGE);
                        load->opaque = 0;
                        load->target = &img_target;
                        if (pngInfo) {
                                if (pngInfo->bit_depth > 8) {
                                        load->format = LX_PNG16_SERVER_NAME;
                                }
                                else {
                                        load->format = LX_PNG8_SERVER_NAME;
                                }
                        }
                        else {
                                load->format = LX_PNG8_SERVER_NAME;
                        }
                }
        }

        return result;
}

/*
 * The load-object method gets an object to fill with image data. Using a
 * user wrapper for the image we proceed to fill it from the file line by line.
 * A monitor is used to check for user abort.
 */
        LxResult
CPNGLoader::load_LoadObject (
        LXtLoadAccess1		*load,
        ILxUnknownID		 dest)
{
        LxResult		 result = LXe_FAILED;
        CLxUser_Monitor		 mon;

        try {
                CLxUser_ImageWrite	 wimg;
                wimg.set (dest);
                wimgIndex.set (dest);
                if (wimg.test () || wimgIndex.test ()) {
                        /*
                         * Load the color table if the image is palette-based.
                         */
                        if ( pngInfo->color_type == PNG_COLOR_TYPE_PALETTE) {
                                load_ColorTable ();
                        }

                        /*
                         * Read in any attributes, such as "ToolPreset".
                         */
                        load_ReadAttrs (wimg, dest);

                        /*
                         * Load the PNG image data stream into wimg,
                         * in file I/O mode.
                         */
                        load_SetIOMode (IO_MODE_FILE);
                        result = load_LoadImage (wimg, load->monitor);
                }
        }
        catch (...) {
                /*
                 * Make sure error doesn't take down the host.
                 */
                log.DebugOutSys (LXi_DBLOG_ERROR, LXsSRV_LOGSUBSYSTEM,
                        "Loader failed with unknown error.");
        }

        if (LXx_OK (result)) {
                log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM, "Image loaded successfully.");
        }

        return result;
}

/*
 * Load a PNG image data stream into the given image.
 */
        LxResult
CPNGLoader::load_LoadImage (
        CLxUser_ImageWrite	&wimg,
        LXtObjectID		 monitor)
{
        LxResult		 result = LXe_FAILED;

        if (load_NewLineBuffers () == LXe_OK) {
                result = load_LoadScanlines (wimg, monitor);

                /*
                 * Free the line I/O mode buffers.
                 */
                delete [] lineBuffer;
                delete [] convertBuffer;
        }

        /*
         * Read the rest of the file, getting any additional
         * chunks in pngInfo.
         */
        png_read_end (pngRead, pngInfo);

        return result;
}

/*
 * Cleanup is called after a failed recognize or after load_LoadObject
 * completes, regardless of the outcome.
 */
        LxResult
CPNGLoader::load_Cleanup (
        LXtLoadAccess1		*load)
{
        if (pngRead && pngInfo) {
                /*
                 * Clean up after the read, and free any allocated memory.
                 */
                png_destroy_read_struct (
                        &pngRead, &pngInfo,
                        static_cast<png_infopp>(NULL));
                pngRead = NULL;
                pngInfo = NULL;
        }

        if (ioMode == IO_MODE_FILE) {
                if (open_file) {
                        fclose (open_file);
                }

                open_file = 0;
        }

        wimgIndex.clear ();

        return LXe_OK;
}

/*
 * Read bytes according to the current I/O mode (memory or file).
 */
        LxResult
CPNGLoader::load_ReadBytes (unsigned char *bytes, size_t byteCount)
{
        LxResult	result(LXe_OK);

        if (ioMode == IO_MODE_FILE) {
                size_t bytesRead = fread (bytes, byteCount, 1, open_file);

                if (byteCount && (bytesRead == 0)) {
                        result = LXe_FAILED;
                }
        }
        else if (ioMode == IO_MODE_MEMORY) {
                if (ioOffset + byteCount <= ibcBufferSize) {
                        /*
                         * Copy from compressed buffer, reading in byteCount
                         * bytes of memory.
                         */
                        memcpy (bytes, ibcBuffer + ioOffset, byteCount);
                        ioOffset += byteCount;
                }
                else {
                        result = LXe_FAILED;
                }
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * PNG Saver -- subclass of "Saver" implementation class.
 */

typedef enum en_PNGSaver_SubFormat {
        PNGSAVER_SUBFORMAT_8Bit,
        PNGSAVER_SUBFORMAT_16Bit
} PNGSaver_SubFormat;

class CPNGSaver : public CLxImpl_Saver
{
        CLxUser_LogService	 log;

        IO_Mode			 ioMode;
        size_t			 ioOffset;
        LXtImageByte		*ibcBuffer;
        size_t			 ibcBufferSize;
        FILE			*open_file;

        size_t			 lineByteSize;
        LXtImageByte		*lineBuffer;
        size_t			 convertByteSize;
        LXtImageByte		*convertBuffer;
        LXtPixelFormat		 format;
        PNGSaver_SubFormat	 subFormat;

        png_structp		 pngWrite;
        png_infop		 pngInfo;

        LxResult		 sav_SaveHeaders (CLxUser_Image &image);
        void			 sav_GetOptions (int &compressionLevel);
        LxResult		 sav_MapFormat (CLxUser_Image &image);
        LxResult		 sav_CopyAttributes (CLxUser_Image &image);
        LxResult		 sav_SavePixels (
                                        CLxUser_Image		&image,
                                        ILxUnknownID		 monitor);
        LxResult		 sav_SaveLine (
                                        CLxUser_Image		&image,
                                        unsigned		 y);
        void			 sav_ConvertLine (
                                        CLxUser_Image		&image,
                                        const LXtImageFloat	*srcLine);
        void			 sav_Cleanup ();

    public:
                                 CPNGSaver (PNGSaver_SubFormat theSubFormat);

        IO_Mode			 sav_GetIOMode () const
        {
                return ioMode;
        }

        void			 sav_SetIOMode (
                                        IO_Mode			 saverIOmode,
                                        LXtImageByte		*destIBCbuffer = NULL,
                                        size_t			 maxIBCbufferSize = 0);
        size_t			 sav_GetIO_Offset () const
        {
                return ioOffset;
        }

        LxResult		 sav_Save (
                                        ILxUnknownID	 source,
                                        const char	*filename,
                                        ILxUnknownID	 monitor);

        LxResult		 sav_SaveImage (
                                        CLxUser_Image		&image,
                                        ILxUnknownID		 monitor = NULL);

        LxResult		 sav_WriteBytes (
                                        const unsigned char	*bytes,
                                        size_t			 byteCount);

        LxResult		 sav_FlushBytes ();

        static LXtTagInfoDesc	 descInfo[];
};

/*
 * Saver tags give the class of object to be saved, and the file extension.
 */
LXtTagInfoDesc	 CPNGSaver::descInfo[] = {
        { LXsSAV_OUTCLASS,	LXa_IMAGE		},
        { LXsSAV_DOSTYPE,	"png"			},
        { LXsSRV_USERNAME,	"@ImageIO.PNG@saver@"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"		},
        { 0 }
};

/*
 * ----------------------------------------------------------------
 * Callback functions for interacting with LibPNG. 
 */

/*
 * Call the PNG saver to write out bytes according to the current
 * I/O mode (memory or file).
 */
        static void
WriteProc (png_structp pngWrite, unsigned char *data, png_size_t size)
{
        CPNGSaver	*pngSaver =
                reinterpret_cast<CPNGSaver*>(png_get_io_ptr(pngWrite));
        LxResult result = pngSaver->sav_WriteBytes (data, size);
        if (LXx_FAIL (result)) {
                throw "Write error: unable to write PNG file";
        }
}

/*
 * Call the PNG saver to flush the written bytes according to the
 * current I/O mode (memory or file).
 */
        static void
FlushProc (png_structp pngWrite)
{
        CPNGSaver	*pngSaver =
                reinterpret_cast<CPNGSaver*>(png_get_io_ptr(pngWrite));
        pngSaver->sav_FlushBytes ();
}

/*
 * Constructor.
 */
CPNGSaver::CPNGSaver (PNGSaver_SubFormat theSubFormat)
        :
        CLxImpl_Saver (),
        ioMode(IO_MODE_FILE),
        ioOffset(0),
        ibcBuffer(NULL),
        ibcBufferSize(0),
        open_file(NULL),
        lineByteSize(0),
        lineBuffer(NULL),
        convertByteSize(0),
        convertBuffer(NULL),
        format(0),
        subFormat (theSubFormat),
        pngWrite(NULL),
        pngInfo(NULL)
{
}

/*
 *
 */
        LxResult
CPNGSaver::sav_SaveHeaders (CLxUser_Image &image)
{
        LxResult		 result = LXe_FAILED;

        /*
         * Create the chunk management structure.
         */
        pngWrite = png_create_write_struct (
                PNG_LIBPNG_VER_STRING,
                static_cast<png_voidp>(NULL),
                error_handler,
                warning_handler);
        if (pngWrite) {
                /*
                 * Allocate and initialize the image
                 * information data.
                 */
                pngInfo = png_create_info_struct (pngWrite);
                if (pngInfo) {
                        png_set_write_fn(
                                pngWrite,
                                reinterpret_cast<png_voidp>(this),
                                WriteProc,
                                FlushProc);

                        result = sav_MapFormat (image);
                }
                else {
                        png_destroy_write_struct(
                                &pngWrite,
                                static_cast<png_infopp>(NULL));
                }
        }

        return result;
}

/*
 * Fetch the user value from the Image I/O prefs.
 *
 * At this time, only PNG Compression Level is supported.
 *
 * ImageIO.PNG.compression.level should be defined with a range of 0..9.
 */
      void
CPNGSaver::sav_GetOptions (int &compressionLevel)
{
        CLxReadUserValue ruv;

        /*
         * The user preference for the PNG compression level is only used for
         * file I/O mode. Memory I/O mode always uses the recommended value.
         */
        if ((ioMode == IO_MODE_FILE) &&
            ruv.Query ("ImageIO.PNG.compression.level")) {
                compressionLevel = ruv.GetInt ();
                if (compressionLevel > 9) {
                        compressionLevel = 9;
                }
                else if (compressionLevel < 0) {
                        compressionLevel = 0;
                }
        }
        else {
                /*
                 * Default to using ZLib level 6 compression level.
                 *
                 * (This default recommended value trades off a small amount of
                 *  speed against the compression ratio).
                 */
                #define PNG_Z_DEFAULT_COMPRESSION	0x0006
                compressionLevel = PNG_Z_DEFAULT_COMPRESSION;
        }
}

/*
 * Map the Luxology image format onto the closest PNG format.
 */
        LxResult
CPNGSaver::sav_MapFormat (CLxUser_Image &image)
{
        LxResult		 result = LXe_FAILED;

        unsigned		 width, height;

        /*
         * Fetch the width and height of the image.
         */
        image.Size (&width, &height);

        bool isSubFormat8Bit = (subFormat == PNGSAVER_SUBFORMAT_8Bit);
        bool isSubFormat16Bit = (subFormat != PNGSAVER_SUBFORMAT_8Bit);

        /*
         * Determine the bit depth and color space.
         */
        convertByteSize = 0;
        int bitDepth;
        int colorType;
        format = image.Format ();

        if ((format == LXiIMP_GREYFP) && isSubFormat8Bit) {
                format = LXiIMP_GREY8;
        }
        else if ((format == LXiIMP_GREY8) && isSubFormat16Bit) {
                format = LXiIMP_GREYFP;
        }
        else if ((format == LXiIMP_RGBAFP) && isSubFormat8Bit) {
                format = LXiIMP_RGBA32;
        }
        else if (((format == LXiIMP_RGBA32) || (format == LXiIMP_IRGBA32)) && isSubFormat16Bit) {
                format = LXiIMP_RGBAFP;
        }
        else if ((format == LXiIMP_RGBFP) && isSubFormat8Bit) {
                format = LXiIMP_RGB24;
        }
        else if (((format == LXiIMP_RGB24) || (format == LXiIMP_IRGB24)) && isSubFormat16Bit) {
                format = LXiIMP_RGBFP;
        }

        switch (format) {
                case LXiIMP_GREY8: {
                        bitDepth = 8;
                        colorType = PNG_COLOR_TYPE_GRAY;

                        /*
                         * Pad 8-bit lines out to four-byte boundaries.
                         */
                        lineByteSize = (width * 8 + 31) / 32 * 4;
                        break;
                }

                case LXiIMP_GREYFP: {
                        bitDepth = 16;
                        colorType = PNG_COLOR_TYPE_GRAY;

                        /*
                         * Pad 16-bit lines out to four-byte boundaries.
                         */
                        lineByteSize = width * sizeof(LXtImageFloat);
                        convertByteSize = (width * 16 + 31) / 32 * 4;
                        break;
                }

                case LXiIMP_RGBA32:
                case LXiIMP_IRGBA32: {
                        bitDepth = 8;
                        colorType = PNG_COLOR_TYPE_RGBA;
                        format = LXiIMP_RGBA32;

                        /*
                         * 32-bit RGB requires no padding.
                         */
                        lineByteSize = width * 4;
                        break;
                }

                case LXiIMP_RGBFP: {
                        bitDepth = 16;
                        colorType = PNG_COLOR_TYPE_RGB;

                        /*
                         * Pad 48-bit lines out to four-byte boundaries.
                         */
                        lineByteSize = width * 3 * sizeof(LXtImageFloat);
                        convertByteSize = (width * 48 + 31) / 32 * 4;
                        break;
                }

                case LXiIMP_RGBAFP: {
                        bitDepth = 16;
                        colorType = PNG_COLOR_TYPE_RGBA;

                        /*
                         * 32-bit RGB float requires no padding.
                         */
                        lineByteSize = width * 4 * sizeof(LXtImageFloat);
                        convertByteSize = width * 4 * sizeof(unsigned short);
                        break;
                }

                case LXiIMP_RGB24:
                default: {
                        bitDepth = 8;
                        colorType = PNG_COLOR_TYPE_RGB;
                        format = LXiIMP_RGB24;

                        /*
                         * Pad 24-bit lines out to four-byte boundaries.
                         */
                        lineByteSize = (width * 24 + 31) / 32 * 4;
                        break;
                }
        }

        /*
         * Grab the compression level setting from the Image I/O prefs.
         */
        int compressionLevel;
        sav_GetOptions (compressionLevel);
        png_set_compression_level (pngWrite, compressionLevel);

        /*
         * Set the compression strategy according to the bit depth.
         */
        if (bitDepth >= 16) {
                png_set_compression_strategy (pngWrite, Z_FILTERED);
                png_set_filter (pngWrite, 0, PNG_FILTER_NONE|PNG_FILTER_SUB|PNG_FILTER_PAETH);
        }
        else {
                png_set_compression_strategy (pngWrite, Z_DEFAULT_STRATEGY);
        }

        /*
         * Set the dimensions, bit depth, and color space.
         */
        png_set_IHDR (pngWrite, pngInfo, width, height, bitDepth, 
                colorType, PNG_INTERLACE_NONE, 
                PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

        /*
         * Write out attributes.
         */
        result = sav_CopyAttributes (image);

        if (result == LXe_OK) {
                /*
                 * Write the file header information.
                 */
                png_write_info (pngWrite, pngInfo);

#ifndef BIGENDIAN
                        if (bitDepth == 16) {
                                /*
                                 * Turn on 16-bit byte swapping.
                                 */
                                png_set_swap (pngWrite);
                        }
#endif
        }

        return result;
}

/*
 * Write out attributes.
 */
        LxResult
CPNGSaver::sav_CopyAttributes (CLxUser_Image &image)
{
        LxResult		 result = LXe_OK;

        CLxUser_Attributes	 attr;
        if (attr.set (image.m_loc)) {
                /*
                 * Set physical resolution if it's available.
                 */
                double	pixelAspect;
                int	index = attr.FindIndex (LXsIATTRNAME_PIXASPECT);
                if (index >= 0) {
                        /*
                         * Could use image metric aspect over size aspect.
                         */
                        pixelAspect = attr.Float (index);
                }
                else {
                        pixelAspect = 1.0;
                }

                index = attr.FindIndex (LXsIATTRNAME_DPI);
                if (index >= 0) {
                        double pitch = attr.Float (index);

                        int xdpm = static_cast<int>(
                                pitch * INCHES_PER_METER);
                        png_uint_32 resX = static_cast<png_uint_32>(xdpm);

                        int ydpm = static_cast<int>(
                                pitch * INCHES_PER_METER * pixelAspect);
                        png_uint_32 resY = static_cast<png_uint_32>(ydpm);

                        if ((resX > 0) && (resY > 0))  {
                                png_set_pHYs (
                                        pngWrite, pngInfo,
                                        resX, resY, PNG_RESOLUTION_METER);
                        }
                }

                /*
                 * It turns out that Photoshop is ignoring the PNG gamma
                 * attribute (as it does for HDR), and QuickTime-based
                 * viewers are interpreting it as a value to be post-multiplied
                 * against the image pixel data, rather than as a
                 * a pre-multiplied value that should merely be propagated
                 * as the file is read and written back out again.
                 *
                 * In the interest of compatibility with such a wide swath
                 * of viewers, we'll stop outputting the PNG gamma attribute.
                 * This matches the original FreeImage "bridge" behavior, and
                 * also matches Photoshop CS3 and later - they stopped writing
                 * the gamma value in PNG files for the same reason!
                 */

#if 0
                /*
                 * For unknown reasons, the FreeImage "bridge" wasn't writing
                 * out the gamma value. We'll go ahead and write out the gamma
                 * attribute if it is available for a given image.
                 */
                index = attr.FindIndex (LXsIATTRNAME_GAMMA);
                if (index >= 0) {
                        double gamma = attr.Float (index);
                        png_set_gAMA (pngWrite, pngInfo, gamma);

                        /*
                         * Log info for the output gamma.
                         */
                        char buffer[256];
                        sprintf (buffer, "Gamma=%g\n", gamma);
                        log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM,
                                buffer);
                }
#endif

                /*
                 * Write out the "ToolPreset" tag, if it's available.
                 */
                static const size_t COMBUF_SIZ	= 4096;
                char			 charBuf[COMBUF_SIZ];
                index = attr.FindIndex ("ToolPreset");
                if (index >= 0 && LXx_OK (attr.GetString (index, charBuf, COMBUF_SIZ))) {
                        png_text text_metadata;

                        memset(&text_metadata, 0, sizeof(png_text));
                        text_metadata.compression = 1;			// iTXt, none
                        text_metadata.key = (char*)"ToolPreset";	// keyword, 1-79 character description of "text"
                        text_metadata.text = charBuf;			// comment, may be an empty string (i.e., "")
                        text_metadata.text_length = strlen (charBuf);	// length of the text string
                        text_metadata.itxt_length = strlen (charBuf);	// length of the itxt string
                        text_metadata.lang = 0;		 // language code, 0-79 characters or a NULL pointer
                        text_metadata.lang_key = 0;	 // keyword translated UTF-8 string, 0 or more chars or a NULL pointer

                        // set the tag 
                        png_set_text (pngWrite, pngInfo, &text_metadata, 1);
                }
        }

        return result;
}

/*
 * Save the image pixel data.
 */
        LxResult
CPNGSaver::sav_SavePixels (
        CLxUser_Image		&image,
        ILxUnknownID		 monitor)
{
        LxResult		 result = LXe_FAILED;
        CLxUser_Monitor		 mon;
        unsigned		 width, height;

        /*
         * Fetch the width and height of the image.
         */
        image.Size (&width, &height);

        // Set up a progress indicator.
        if (monitor) {
                mon.set (monitor);
                mon.Init (height);
        }

        if (convertByteSize) {
                convertBuffer = NewLineBuffer (convertByteSize);
                if (!convertBuffer) {
                        result = LXe_OUTOFMEMORY;
                }
        }
        else {
                convertBuffer = 0;
        }

        /*
         * Allocate line I/O mode buffers.
         * Freed immediately after the line I/O loop.
         */
        lineBuffer = NewLineBuffer (lineByteSize);
        if ((result == LXe_OUTOFMEMORY) || !lineBuffer) {
                log.DebugOutSys (LXi_DBLOG_ERROR, LXsSRV_LOGSUBSYSTEM,
                        "Not enough memory for line buffers.");
                result = LXe_OUTOFMEMORY;
        }
        else {
                result = LXe_OK;

                for (png_uint_32 y = 0; y < height; ++y) {
                        /*
                         * Write out a line of image pixels.
                         */
                        result = sav_SaveLine (image, y);
                        if (result != LXe_OK) {
                                break;
                        }

                        /*
                         * Update the progress monitor, checking for
                         * a user escape action.
                         */
                        if (mon.test () && mon.Step ()) {
                                result = LXe_ABORT;
                                break;
                        }
                }

                /*
                 * Free the line I/O mode buffer.
                 */
                delete [] lineBuffer;
        }

        return result;
}

/*
 * Write out a line of image pixels.
 */
        LxResult
CPNGSaver::sav_SaveLine (
        CLxUser_Image		&image,
        unsigned		 y)
{
        LxResult		 result = LXe_FAILED;

        /*
         * Fetch a scanline for compression.
         */
        const LXtImageByte *srcLine =
                static_cast<const LXtImageByte*>(
                        image.GetLine (y, format, lineBuffer));

        if (srcLine) {
                if (convertBuffer) {
                        sav_ConvertLine (
                                image,
                                reinterpret_cast<LXtImageFloat*>(const_cast<LXtImageByte*>(srcLine)));
                }
                else {
                        png_write_row (
                                pngWrite, const_cast<png_bytep>(srcLine));
                }

                result = LXe_OK;
        }

        return result;
}

/*
 * Min template function.
 */
template <class T> T Min(T a, T b) {
        return (a < b) ? a: b;
}

/*
 * Convert one of the floating-point formats to a 16-bit line.
 */
        void
CPNGSaver::sav_ConvertLine (
        CLxUser_Image		&image,
        const LXtImageFloat	*srcLine)
{
        unsigned		 width, height;
        unsigned		 x;

        /*
         * Fetch the width and height of the image.
         */
        image.Size (&width, &height);

        switch (image.Format () ) {
                case LXiIMP_GREYFP: {
                        LXtImageFloat *iterSrc =
                                const_cast<LXtImageFloat*>(srcLine);
                        unsigned short *iterLine16 =
                                reinterpret_cast<unsigned short*>(convertBuffer);
                        for (x = 0; x < width; ++x) {
                                *iterLine16 = static_cast<unsigned short>(
                                        Min (*iterSrc, 1.0f) * 65535.0F);
                                ++iterSrc;
                                ++iterLine16;
                        }
                        break;
                }

                case LXiIMP_RGBFP: {
                        LXtImageFloat *iterSrc =
                                const_cast<LXtImageFloat*>(srcLine);
                        unsigned short *iterLine16 =
                                reinterpret_cast<unsigned short*>(convertBuffer);
                        for (x = 0; x < width; ++x) {
                                iterLine16[0] = static_cast<unsigned short>(
                                        Min (iterSrc[0], 1.0f) * 65535.0F);
                                iterLine16[1] = static_cast<unsigned short>(
                                        Min (iterSrc[1], 1.0f) * 65535.0F);
                                iterLine16[2] = static_cast<unsigned short>(
                                        Min (iterSrc[2], 1.0f) * 65535.0F);
                                iterSrc += 3;
                                iterLine16 += 3;
                        }
                        break;
                }

                case LXiIMP_RGBAFP: {
                        LXtImageFloat *iterSrc =
                                const_cast<LXtImageFloat*>(srcLine);
                        unsigned short *iterLine16 =
                                reinterpret_cast<unsigned short*>(convertBuffer);
                        for (x = 0; x < width; ++x) {
                                iterLine16[0] = static_cast<unsigned short>(
                                        Min (iterSrc[0], 1.0f) * 65535.0F);
                                iterLine16[1] = static_cast<unsigned short>(
                                        Min (iterSrc[1], 1.0f) * 65535.0F);
                                iterLine16[2] = static_cast<unsigned short>(
                                        Min (iterSrc[2], 1.0f) * 65535.0F);
                                iterLine16[3] = static_cast<unsigned short>(
                                        Min (iterSrc[3], 1.0f) * 65535.0F);
                                iterSrc += 4;
                                iterLine16 += 4;
                        }
                        break;
                }
        }

        png_write_row (pngWrite, const_cast<png_bytep>(convertBuffer));
}

/*
 * Cleanup that takes place regardless of whether or not the file was written.
 */
        void
CPNGSaver::sav_Cleanup ()
{
        if (ioMode == IO_MODE_FILE) {
                if (open_file) {
                        fclose (open_file);
                }

                open_file = 0;
        }
}

/*
 * Generic PNG image data stream saver; works in either file or memory
 * I/O mode for a given input image parameter.
 */
        LxResult
CPNGSaver::sav_SaveImage (
        CLxUser_Image		&image,
        ILxUnknownID		 monitor)
{
        LxResult		 result = LXe_FAILED;

        result = sav_SaveHeaders (image);
        if (result == LXe_OK) {
                /*
                 * Save the image pixel data.
                 */
                result = sav_SavePixels (image, monitor);
                if (result == LXe_OK) {
                        /*
                         * Finish writing the file.
                         */
                        png_write_end (pngWrite, pngInfo);
                }

                png_destroy_write_struct (
                        &pngWrite, &pngInfo);
        }

        return result;
}

/*
 * Set the mode used for I/O (file or memory).
 */
        void
CPNGSaver::sav_SetIOMode (
        IO_Mode			 saverIOmode,
        LXtImageByte		*destIBCbuffer,
        size_t			 maxIBCbufferSize)
{
        ioMode = saverIOmode;
        ioOffset = 0;
        ibcBuffer = destIBCbuffer;
        ibcBufferSize = maxIBCbufferSize;
}

/*
 * The reverse of the load_LoadObject method.  We extract lines from the image
 * line-by-line, converting and writing out one line at a time to the file.
 */
        LxResult
CPNGSaver::sav_Save (
        ILxUnknownID		 source,
        const char		*filename,
        ILxUnknownID		 monitor)
{
        LxResult		 result = LXe_NOACCESS;

        try {
                open_file = 0;
                CLxUser_Image image;
                if (image.set (source)) {
                        /*
                         * Write out the PNG file in binary file I/O mode,
                         * using the generic PNG data stream saver.
                         */
                        open_file = fopen (filename, "wb");
                        if (open_file) {
                                sav_SetIOMode (IO_MODE_FILE);
                                result = sav_SaveImage (image, monitor);
                        }

                        sav_Cleanup ();
                }
        }
        catch (...) {
                if (open_file) {
                        fclose (open_file);
                }

                /*
                 * Make sure error doesn't take down the host.
                 */
                log.DebugOutSys (LXi_DBLOG_ERROR, LXsSRV_LOGSUBSYSTEM,
                        "Saver failed with unknown error.");
        }

        if (LXx_OK (result)) {
                log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM,
                        "Image saved successfully.");
        }

        return result;
}

/*
 * Write bytes according to the current I/O mode (memory or file).
 */
        LxResult
CPNGSaver::sav_WriteBytes (
        const unsigned char	*bytes,
        size_t			 byteCount)
{
        LxResult		result(LXe_OK);

        if (ioMode == IO_MODE_FILE) {
                /*
                 * Write to the open file in file I/O mode.
                 */
                size_t bytesWritten = fwrite (bytes, byteCount, 1, open_file);
                if (byteCount && (bytesWritten == 0)) {
                        result = LXe_FAILED;
                }
        }
        else if (ioMode == IO_MODE_MEMORY) {
                if (ioOffset + byteCount > ibcBufferSize) {
                        ioMode = IO_MODE_MEMORY_OVERFLOW;
                }
                else {
                        /*
                         * Copy the bytes to the IBC buffer
                         * at the current I/O offset.
                         */
                        memcpy (ibcBuffer + ioOffset, bytes, byteCount);

                        /*
                         * Advance the I/O offset for the next write.
                         */
                        ioOffset += byteCount;
                }
        }
        else if (ioMode == IO_MODE_MEMORY_OVERFLOW) {
                /*
                 * Overflow is a non-fatal condition, which simply
                 * causes the offset to stop advancing and copies to
                 * be suspended for all further byte write requests.
                 *
                 * The client should check the I/O mode upon save
                 * completion and fall back to writing out uncompressed
                 * when presented with the overflow condition.
                 */
        }

        return result;
}

/*
 * Flush bytes according to the current I/O mode (memory or file).
 */
        LxResult
CPNGSaver::sav_FlushBytes ()
{
        LxResult		result(LXe_OK);

        return result;
}

/*
 * ----------------------------------------------------------------
 * Layer saver for saving layered images as a sequence of PNGs.
 */

class CPNGLayerSaver : public CLxImpl_Saver
{
    public:
        CPNGLayerSaver (PNGSaver_SubFormat theSubFormat)
                : laySaver (theSubFormat)
        {
                ext = "png";
        }

        virtual LxResult	 sav_Verify (
                                        ILxUnknownID	 source,
                                        ILxUnknownID	 message) LXx_OVERRIDE;

        virtual LxResult	 sav_Save (
                                        ILxUnknownID	 source,
                                        const char	*filename,
                                        ILxUnknownID	 monitor) LXx_OVERRIDE;

        static LXtTagInfoDesc	 descInfo[];

    private:
        CLxUser_LogService	 log;
        const char		*ext;
        CPNGSaver		 laySaver;
};

LXtTagInfoDesc CPNGLayerSaver::descInfo[] = {
        { LXsSAV_OUTCLASS,	LXa_LAYEREDIMAGE		},
        { LXsSAV_DOSTYPE,	"png"				},
        { LXsSRV_USERNAME,	"@ImageIO.PNG@multifilesaver@"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"			},
        { 0 }	};

/*
 * Verify that we have a layered image.
 */
        LxResult
CPNGLayerSaver::sav_Verify (
        ILxUnknownID		 source,
        ILxUnknownID		 msgObj)
{
        CLxUser_LayeredImage	 limg (source);
        CLxUser_Message		 msg (msgObj);

        if (limg.test ())
                return LXe_OK;

        log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM,
                "No layers found.");

        return LXe_OK;
}

/*
 * Filter out NCName reserved characters.
 * 
 * See the table "Names and Tokens", in "Namespaces in XML 1.0":
 *
 *     http://www.w3.org/TR/REC-xml-names/#ns-decl
 */
        string
EscapeNCName (
        const string&	 name)
{
        string filteredStr;
        const char *text = name.c_str ();

        const unsigned char *c;
        for (c = reinterpret_cast<const unsigned char*>(text); *c; ++c) {
                bool legalChar =
                    (*c >= 'a' && *c <= 'z') ||	// lowercase letter
                    (*c >= 'A' && *c <= 'Z') || // uppercase letter
                    (*c >= '0' && *c <= '9') || // digit
                    (*c == '_') || (*c == '-') || (*c == '.'); // safe delimiters

                if (legalChar) {
                        filteredStr += *c;
                }
                else {
                        filteredStr += "_";
                }
        }

        return filteredStr;
}

/*
 * Save out each layer using our contained CPNGSaver class.
 */
        LxResult
CPNGLayerSaver::sav_Save (
        ILxUnknownID		 source,
        const char		*filename,
        ILxUnknownID		 mon)
{
        CLxUser_LayeredImage	 limg (source);
        CLxUser_Image		 image;
        string			 filteredName;
        const char		*name;
        int			 j, n, x;

        if (!limg.test ()) // try straight ILxImage saver
                return laySaver.sav_Save (source, filename, mon);

        n = limg.Count ();
        if (!n)
                return LXe_NOTFOUND;

        x = static_cast<int>(strlen (filename));
        if (x > 4 && filename[x - 4] == '.')
                x -= 4;

        for (j = n - 1; j >= 0; j--) { // save layers backwards??
                string		 layName (filename, x);

                if (!limg.GetImage (j, image))
                        continue;

                if (LXx_FAIL (limg.Name (j, &name)))
                        continue;

                filteredName = EscapeNCName (string(name));

                layName.append (".");
                layName.append (filteredName);
                layName.append (".");
                layName.append (ext);
                laySaver.sav_Save (image, layName.c_str(), mon);
        }

        return n ? LXe_OK : LXe_NOACCESS;
}

/*
 * ----------------------------------------------------------------
 * Specialized saver for saving 8-bit PNG images.
 */

class CPNGSaver8 : public CLxImpl_Saver
{
    public:
                 CPNGSaver8();

        LxResult		 sav_Save (
                                        ILxUnknownID	 source,
                                        const char	*filename,
                                        ILxUnknownID	 monitor) LXx_OVERRIDE;

        static LXtTagInfoDesc	 descInfo[];

    private:
        CLxUser_LogService	 log;
        CPNGSaver		 pngSaver;
};

LXtTagInfoDesc CPNGSaver8::descInfo[] = {
        { LXsSAV_OUTCLASS,	LXa_IMAGE		},
        { LXsSAV_DOSTYPE,	"png"			},
        { LXsSRV_USERNAME,	"@ImageIO.PNG@saver@"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"		},
        { 0 }	};

CPNGSaver8::CPNGSaver8()
        : pngSaver (PNGSAVER_SUBFORMAT_8Bit)
{
}

/*
 * Save out an 8-bit PNG image.
 */
        LxResult
CPNGSaver8::sav_Save (
        ILxUnknownID		 source,
        const char		*filename,
        ILxUnknownID		 mon)
{
        LxResult		 result;

        result = pngSaver.sav_Save (source, filename, mon);

        if (LXx_OK (result)) {
                log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM,
                        "Image saved successfully.");
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * Specialized saver for saving 16-bit PNG images.
 */

class CPNGSaver16 : public CLxImpl_Saver
{
    public:
                 CPNGSaver16();

        LxResult		 sav_Save (
                                        ILxUnknownID	 source,
                                        const char	*filename,
                                        ILxUnknownID	 monitor) LXx_OVERRIDE;

        static LXtTagInfoDesc	 descInfo[];

    private:
        CLxUser_LogService	 log;
        CPNGSaver		 pngSaver;
};

LXtTagInfoDesc CPNGSaver16::descInfo[] = {
        { LXsSAV_OUTCLASS,	LXa_IMAGE		},
        { LXsSAV_DOSTYPE,	"png"			},
        { LXsSRV_USERNAME,	"@ImageIO.PNG@saver16@"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"		},
        { 0 }	};

CPNGSaver16::CPNGSaver16()
        : pngSaver (PNGSAVER_SUBFORMAT_16Bit)
{
}

/*
 * Save out an 16-bit PNG image.
 */
        LxResult
CPNGSaver16::sav_Save (
        ILxUnknownID		 source,
        const char		*filename,
        ILxUnknownID		 mon)
{
        LxResult		 result;

        result = pngSaver.sav_Save (source, filename, mon);

        if (LXx_OK (result)) {
                log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM,
                        "Image saved successfully.");
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * Layer saver for saving layered images as a sequence of 8-bit PNGs.
 */

class CPNG8LayerSaver : public CLxImpl_Saver
{
    public:
        CPNG8LayerSaver()
                : laySaver (PNGSAVER_SUBFORMAT_8Bit)
        {
        }

        virtual LxResult	 sav_Verify (
                                        ILxUnknownID	 source,
                                        ILxUnknownID	 message) LXx_OVERRIDE;

        virtual LxResult	 sav_Save (
                                        ILxUnknownID	 source,
                                        const char	*filename,
                                        ILxUnknownID	 monitor) LXx_OVERRIDE;

        static LXtTagInfoDesc	 descInfo[];

    private:
        CLxUser_LogService	 log;
        CPNGLayerSaver		 laySaver;
};

LXtTagInfoDesc CPNG8LayerSaver::descInfo[] = {
        { LXsSAV_OUTCLASS,	LXa_LAYEREDIMAGE		},
        { LXsSAV_DOSTYPE,	"png"				},
        { LXsSRV_USERNAME,	"@ImageIO.PNG@multifilesaver@"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"			},
        { 0 }	};

/*
 * Verify that we have a layered image.
 */
        LxResult
CPNG8LayerSaver::sav_Verify (
        ILxUnknownID		 source,
        ILxUnknownID		 msgObj)
{
        return laySaver.sav_Verify (source, msgObj);
}

/*
 * Save out each layer using our contained CPNGLayerSaver class.
 */
        LxResult
CPNG8LayerSaver::sav_Save (
        ILxUnknownID		 source,
        const char		*filename,
        ILxUnknownID		 mon)
{
        LxResult		 result;

        result = laySaver.sav_Save (source, filename, mon);

        if (LXx_OK (result)) {
                log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM,
                        "Layered images saved successfully.");
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * Layer saver for saving layered images as a sequence of 16-bit PNGs.
 */

class CPNG16LayerSaver : public CLxImpl_Saver
{
    public:
        CPNG16LayerSaver()
                : laySaver (PNGSAVER_SUBFORMAT_16Bit)
        {
        }

        virtual LxResult	 sav_Verify (
                                        ILxUnknownID	 source,
                                        ILxUnknownID	 message) LXx_OVERRIDE;

        virtual LxResult	 sav_Save (
                                        ILxUnknownID	 source,
                                        const char	*filename,
                                        ILxUnknownID	 monitor) LXx_OVERRIDE;

        static LXtTagInfoDesc	 descInfo[];

    private:
        CLxUser_LogService	 log;
        CPNGLayerSaver		 laySaver;
};

LXtTagInfoDesc CPNG16LayerSaver::descInfo[] = {
        { LXsSAV_OUTCLASS,	LXa_LAYEREDIMAGE			},
        { LXsSAV_DOSTYPE,	"png"					},
        { LXsSRV_USERNAME,	"@ImageIO.PNG@multifilesaver16@"	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"				},
        { 0 }	};

/*
 * Verify that we have a layered image.
 */
        LxResult
CPNG16LayerSaver::sav_Verify (
        ILxUnknownID		 source,
        ILxUnknownID		 msgObj)
{
        return laySaver.sav_Verify (source, msgObj);
}

/*
 * Save out each layer using our contained CPNGLayerSaver class.
 */
        LxResult
CPNG16LayerSaver::sav_Save (
        ILxUnknownID		 source,
        const char		*filename,
        ILxUnknownID		 mon)
{
        LxResult		 result;

        result = laySaver.sav_Save (source, filename, mon);

        if (LXx_OK (result)) {
                log.DebugOutSys (LXi_DBLOG_NORMAL, LXsSRV_LOGSUBSYSTEM,
                        "Layered images saved successfully.");
        }

        return result;
}




// Comment out the next line to test the Cocoa QT movie saver.
//#define NOT_TESTING_COCOAQT	1

/*
 * ----------------------------------------------------------------
 * Exporting Servers
 *
 * The name must be unique among all loaders or savers.
 */
        void
initialize ()
{
        LXx_ADD_SERVER (Saver, CPNGSaver8, LX_PNG8_SERVER_NAME);
        LXx_ADD_SERVER (Saver, CPNGSaver16, LX_PNG16_SERVER_NAME);
        LXx_ADD_SERVER (Saver, CPNG8LayerSaver, "PNGs");
        LXx_ADD_SERVER (Saver, CPNG16LayerSaver, "PNGs16");
        LXx_ADD_SERVER (Loader1, CPNGLoader, "PNG");

}

