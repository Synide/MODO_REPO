/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_schema.h"

namespace cio {

/*
 * -------------------------------------------------------------------
 * COLLADA XML schema identifiers.
 *
 * Clients of cio::File and cio::Element (and its subclasses) rarely need
 * to reference any of these values.
 *
 * CLIENTS SHOULD NOT MODIFY ANYTHING BELOW THIS LINE!
 */

/*
 * Elements.
 */
const char* ELEMENT_ACCESSOR			= "accessor";
const char* ELEMENT_AMBIENT			= "ambient";
const char* ELEMENT_ANGULAR			= "angular";
const char* ELEMENT_ANGULAR_VELOCITY		= "angular_velocity";
const char* ELEMENT_ANIMATION			= "animation";
const char* ELEMENT_ANIMATION_CLIP		= "animation_clip";
const char* ELEMENT_ASPECT_RATIO		= "aspect_ratio";
const char* ELEMENT_ASSET			= "asset";
const char* ELEMENT_ATTACHMENT			= "attachment";
const char* ELEMENT_AUTHOR			= "author";
const char* ELEMENT_AUTHORING_TOOL		= "authoring_tool";
const char* ELEMENT_BIND			= "bind";
const char* ELEMENT_BIND_MATERIAL		= "bind_material";
const char* ELEMENT_BIND_SHAPE_MATRIX		= "bind_shape_matrix";
const char* ELEMENT_BIND_VERTEX_INPUT		= "bind_vertex_input";
const char* ELEMENT_BLINN			= "blinn";
const char* ELEMENT_BOOL_ARRAY			= "bool_array";
const char* ELEMENT_BOX				= "box";
const char* ELEMENT_CAMERA			= "camera";
const char* ELEMENT_CAPSULE			= "capsule";
const char* ELEMENT_CHANNEL			= "channel";
const char* ELEMENT_COLLADA			= "COLLADA";
const char* ELEMENT_COLOR			= "color";
const char* ELEMENT_COMMENTS			= "comments";
const char* ELEMENT_CONSTANT			= "constant";
const char* ELEMENT_CONSTANT_ATTENUATION	= "constant_attenuation";
const char* ELEMENT_CONTRIBUTOR			= "contributor";
const char* ELEMENT_CONTROLLER			= "controller";
const char* ELEMENT_CONVEX_MESH			= "convex_mesh";
const char* ELEMENT_COPYRIGHT			= "copyright";
const char* ELEMENT_CREATED			= "created";
const char* ELEMENT_CYLINDER			= "cylinder";
const char* ELEMENT_DAMPING			= "dampness";
const char* ELEMENT_DENSITY			= "density";
const char* ELEMENT_DIFFUSE			= "diffuse";
const char* ELEMENT_DIRECTIONAL			= "directional";
const char* ELEMENT_DYNAMIC			= "dynamic";
const char* ELEMENT_DYNAMIC_FRICTION		= "dynamic_friction";
const char* ELEMENT_EFFECT			= "effect";
const char* ELEMENT_EMISSION			= "emission";
const char* ELEMENT_ENABLED			= "enabled";
const char* ELEMENT_EQUATION			= "equation";
const char* ELEMENT_EXTRA			= "extra";
const char* ELEMENT_FALLOFF_ANGLE		= "falloff_angle";
const char* ELEMENT_FALLOFF_EXPONENT		= "falloff_exponent";
const char* ELEMENT_FLOAT			= "float";
const char* ELEMENT_FLOAT3			= "float3";
const char* ELEMENT_FLOAT_ARRAY			= "float_array";
const char* ELEMENT_FORCE_FIELD			= "force_field";
const char* ELEMENT_FORMAT			= "format";
const char* ELEMENT_GEOMETRY			= "geometry";
const char* ELEMENT_GRAVITY			= "gravity";
const char* ELEMENT_H				= "h";
const char* ELEMENT_HALF_EXTENTS		= "half_extents";
const char* ELEMENT_HEIGHT			= "height";
const char* ELEMENT_HOLLOW			= "hollow";
const char* ELEMENT_IMAGE			= "image";
const char* ELEMENT_IMAGER			= "imager";
const char* ELEMENT_INDEX_OF_REFRACTION		= "index_of_refraction";
const char* ELEMENT_INERTIA			= "inertia";
const char* ELEMENT_INIT_FROM			= "init_from";
const char* ELEMENT_INPUT			= "input";
const char* ELEMENT_INSTANCE_CAMERA		= "instance_camera";
const char* ELEMENT_INSTANCE_CONTROLLER		= "instance_controller";
const char* ELEMENT_INSTANCE_EFFECT		= "instance_effect";
const char* ELEMENT_INSTANCE_FORCE_FIELD	= "instance_force_field";
const char* ELEMENT_INSTANCE_GEOMETRY		= "instance_geometry";
const char* ELEMENT_INSTANCE_LIGHT		= "instance_light";
const char* ELEMENT_INSTANCE_MATERIAL		= "instance_material";
const char* ELEMENT_INSTANCE_NODE		= "instance_node";
const char* ELEMENT_INSTANCE_PHYSICS_MATERIAL	= "instance_physics_material";
const char* ELEMENT_INSTANCE_PHYSICS_MODEL	= "instance_physics_model";
const char* ELEMENT_INSTANCE_PHYSICS_SCENE	= "instance_physics_scene";
const char* ELEMENT_INSTANCE_RIGID_BODY		= "instance_rigid_body";
const char* ELEMENT_INSTANCE_RIGID_CONSTRAINT	= "instance_rigid_constraint";
const char* ELEMENT_INSTANCE_VISUAL_SCENE	= "instance_visual_scene";
const char* ELEMENT_INT_ARRAY			= "int_array";
const char* ELEMENT_INTENSITY			= "intensity";
const char* ELEMENT_INTERPENETRATE		= "interpenetrate";
const char* ELEMENT_JOINTS			= "joints";
const char* ELEMENT_KEYWORDS			= "keywords";
const char* ELEMENT_LAMBERT			= "lambert";
const char* ELEMENT_LIBRARY_ANIMATIONS		= "library_animations";
const char* ELEMENT_LIBRARY_ANIMATION_CLIPS	= "library_animation_clips";
const char* ELEMENT_LIBRARY_CAMERAS		= "library_cameras";
const char* ELEMENT_LIBRARY_CONTROLLERS		= "library_controllers";
const char* ELEMENT_LIBRARY_EFFECTS		= "library_effects";
const char* ELEMENT_LIBRARY_GEOMETRIES		= "library_geometries";
const char* ELEMENT_LIBRARY_IMAGES		= "library_images";
const char* ELEMENT_LIBRARY_LIGHTS		= "library_lights";
const char* ELEMENT_LIBRARY_MATERIALS		= "library_materials";
const char* ELEMENT_LIBRARY_NODES		= "library_nodes";
const char* ELEMENT_LIBRARY_PHYSICS_MODELS	= "library_physics_models";
const char* ELEMENT_LIBRARY_PHYSICS_SCENES	= "library_physics_scenes";
const char* ELEMENT_LIBRARY_VISUAL_SCENES	= "library_visual_scenes";
const char* ELEMENT_LIGHT			= "light";
const char* ELEMENT_LIMITS			= "limits";
const char* ELEMENT_LINEAR			= "linear";
const char* ELEMENT_LINEAR_ATTENUATION		= "linear_attenuation";
const char* ELEMENT_LINES			= "lines";
const char* ELEMENT_LINESTRIPS			= "linestrips";
const char* ELEMENT_LOOKAT			= "lookat";
const char* ELEMENT_MAGFILTER			= "magfilter";
const char* ELEMENT_MASS			= "mass";
const char* ELEMENT_MASS_FRAME			= "mass_frame";
const char* ELEMENT_MATERIAL			= "material";
const char* ELEMENT_MATRIX			= "matrix";
const char* ELEMENT_MAX				= "max";
const char* ELEMENT_MESH			= "mesh";
const char* ELEMENT_MIN				= "min";
const char* ELEMENT_MINFILTER			= "minfilter";
const char* ELEMENT_MODIFIED			= "modified";
const char* ELEMENT_NAME_ARRAY			= "Name_array";
const char* ELEMENT_NEWPARAM			= "newparam";
const char* ELEMENT_NODE			= "node";
const char* ELEMENT_OPTICS			= "optics";
const char* ELEMENT_ORTHOGRAPHIC		= "orthographic";
const char* ELEMENT_P				= "p";
const char* ELEMENT_PARAM			= "param";
const char* ELEMENT_PERSPECTIVE			= "perspective";
const char* ELEMENT_PH				= "ph";
const char* ELEMENT_PHONG			= "phong";
const char* ELEMENT_PHYSICS_MATERIAL		= "physics_material";
const char* ELEMENT_PHYSICS_MODEL		= "physics_model";
const char* ELEMENT_PHYSICS_SCENE		= "physics_scene";
const char* ELEMENT_PLANE			= "plane";
const char* ELEMENT_POINT			= "point";
const char* ELEMENT_POLYGONS			= "polygons";
const char* ELEMENT_POLYLIST			= "polylist";
const char* ELEMENT_POST_INFINITY		= "post_infinity";
const char* ELEMENT_PRE_INFINITY		= "pre_infinity";
const char* ELEMENT_PROFILE_COMMON		= "profile_COMMON";
const char* ELEMENT_QUADRATIC_ATTENUATION	= "quadratic_attenuation";
const char* ELEMENT_RADIUS			= "radius";
const char* ELEMENT_RADIUS1			= "radius1";
const char* ELEMENT_RADIUS2			= "radius2";
const char* ELEMENT_REF_ATTACHMENT		= "ref_attachment";
const char* ELEMENT_REFLECTIVE			= "reflective";
const char* ELEMENT_REFLECTIVITY		= "reflectivity";
const char* ELEMENT_RESTITUTION			= "restitution";
const char* ELEMENT_REVISION			= "revision";
const char* ELEMENT_RIGID_BODY			= "rigid_body";
const char* ELEMENT_RIGID_CONSTRAINT		= "rigid_constraint";
const char* ELEMENT_ROTATE			= "rotate";
const char* ELEMENT_SAMPLER			= "sampler";
const char* ELEMENT_SAMPLER2D			= "sampler2D";
const char* ELEMENT_SCALE			= "scale";
const char* ELEMENT_SCENE			= "scene";
const char* ELEMENT_SETPARAM			= "setparam";
const char* ELEMENT_SHAPE			= "shape";
const char* ELEMENT_SHININESS			= "shininess";
const char* ELEMENT_SKELETON			= "skeleton";
const char* ELEMENT_SKEW			= "skew";
const char* ELEMENT_SKIN			= "skin";
const char* ELEMENT_SOURCE			= "source";
const char* ELEMENT_SOURCE_DATA			= "source_data";
const char* ELEMENT_SPECULAR			= "specular";
const char* ELEMENT_SPHERE			= "sphere";
const char* ELEMENT_SPOT			= "spot";
const char* ELEMENT_SPRING			= "spring";
const char* ELEMENT_STATIC_FRICTION		= "static_friction";
const char* ELEMENT_STIFFNESS			= "stiffness";
const char* ELEMENT_SUBJECT			= "subject";
const char* ELEMENT_SURFACE			= "surface";
const char* ELEMENT_SWING_CONE_AND_TWIST	= "swing_cone_and_twist";
const char* ELEMENT_TAPERED_CAPSULE		= "tapered_capsule";
const char* ELEMENT_TAPERED_CYLINDER		= "tapered_cylinder";
const char* ELEMENT_TARGET_VALUE		= "target_value";
const char* ELEMENT_TECHNIQUE			= "technique";
const char* ELEMENT_TECHNIQUE_COMMON		= "technique_common";
const char* ELEMENT_TITLE			= "title";
const char* ELEMENT_TEXTURE			= "texture";
const char* ELEMENT_TIME_STEP			= "time_step";
const char* ELEMENT_TRANSLATE			= "translate";
const char* ELEMENT_TRANSPARENCY		= "transparency";
const char* ELEMENT_TRANSPARENT			= "transparent";
const char* ELEMENT_TRIANGLES			= "triangles";
const char* ELEMENT_TRIFANS			= "trifans";
const char* ELEMENT_TRISTRIPS			= "tristrips";
const char* ELEMENT_UNIT			= "unit";
const char* ELEMENT_UP_AXIS			= "up_axis";
const char* ELEMENT_V				= "v";
const char* ELEMENT_VCOUNT			= "vcount";
const char* ELEMENT_VELOCITY			= "velocity";
const char* ELEMENT_VERTEX_WEIGHTS		= "vertex_weights";
const char* ELEMENT_VERTICES			= "vertices";
const char* ELEMENT_VISUAL_SCENE		= "visual_scene";
const char* ELEMENT_XFOV			= "xfov";
const char* ELEMENT_XMAG			= "xmag";
const char* ELEMENT_YFOV			= "yfov";
const char* ELEMENT_YMAG			= "ymag";
const char* ELEMENT_ZFAR			= "zfar";
const char* ELEMENT_ZNEAR			= "znear";

/*
 * Attributes.
 */
const char* ATTRIBUTE_BODY			= "body";
const char* ATTRIBUTE_CONSTRAINT		= "constraint";
const char* ATTRIBUTE_COUNT			= "count";
const char* ATTRIBUTE_ENCODING			= "encoding";
const char* ATTRIBUTE_END			= "end";
const char* ATTRIBUTE_ID			= "id";
const char* ATTRIBUTE_INPUT_SEMANTIC		= "input_semantic";
const char* ATTRIBUTE_INPUT_SET			= "input_set";
const char* ATTRIBUTE_NAME			= "name";
const char* ATTRIBUTE_MATERIAL			= "material";
const char* ATTRIBUTE_METER			= "meter";
const char* ATTRIBUTE_OFFSET			= "offset";
const char* ATTRIBUTE_OPAQUE			= "opaque";
const char* ATTRIBUTE_PROFILE			= "profile";
const char* ATTRIBUTE_REF			= "ref";
const char* ATTRIBUTE_SEMANTIC			= "semantic";
const char* ATTRIBUTE_SET			= "set";
const char* ATTRIBUTE_SID			= "sid";
const char* ATTRIBUTE_SOURCE			= "source";
const char* ATTRIBUTE_START			= "start";
const char* ATTRIBUTE_STRIDE			= "stride";
const char* ATTRIBUTE_SYMBOL			= "symbol";
const char* ATTRIBUTE_TARGET			= "target";
const char* ATTRIBUTE_TEXCOORD			= "texcoord";
const char* ATTRIBUTE_TEXTURE			= "texture";
const char* ATTRIBUTE_TYPE			= "type";
const char* ATTRIBUTE_URL			= "url";
const char* ATTRIBUTE_VERSION			= "version";
const char* ATTRIBUTE_XMLNS			= "xmlns";

/*
 * Common technique parameters.
 */
const char* PARAM_ASPECT_RATIO			= "aspect_ratio";
const char* PARAM_ASPECT_RATIO_NAME		= "Aspect Ratio";

const char* PARAM_AMBIENT_EFFECT_COLOR		= "ambient_effect_rgb";
const char* PARAM_AMBIENT_EFFECT_COLOR_NAME	= "Ambient Effect Color";

const char* PARAM_AMBIENT_LIGHT_COLOR		= "ambient_light_rgb";

const char* PARAM_CONSTANT_ATTENUATION		= "const_atten";
const char* PARAM_CONSTANT_ATTENUATION_NAME	= "Constant Attenuation";

const char* PARAM_DIFFUSE_EFFECT_COLOR		= "diffuse_effect_rgb";

const char* PARAM_DIRECTIONAL_LIGHT_COLOR	= "directional_light_rgb";
const char* PARAM_DIRECTIONAL_LIGHT_COLOR_NAME	= "Directional Light Color";

const char* PARAM_EMISSION_EFFECT_COLOR		= "emission_effect_rgb";

const char* PARAM_FALLOFF_ANGLE			= "falloff_deg";
const char* PARAM_FALLOFF_ANGLE_NAME		= "falloff_angle";

const char* PARAM_FALLOFF_EXPONENT		= "falloff_exponent";
const char* PARAM_FALLOFF_EXPONENT_NAME		= "Falloff Exponent";

const char* PARAM_INDEX_OF_REFRACTION		= "index_of_refraction";

const char* PARAM_JOINT_NAME			= "name";

const char* PARAM_LINEAR_ATTENUATION		= "lin_atten";
const char* PARAM_LINEAR_ATTENUATION_NAME	= "Linear Attenuation";

const char* PARAM_POINT_LIGHT_COLOR		= "point_light_rgb";
const char* PARAM_POINT_LIGHT_COLOR_NAME	= "Point Light Color";

const char* PARAM_QUADRATIC_ATTENUATION		= "quad_atten";
const char* PARAM_QUADRATIC_ATTENUATION_NAME	= "Quadratic Attenuation";

const char* PARAM_REFLECTIVE_EFFECT_COLOR	= "reflective_effect_rgb";

const char* PARAM_REFLECTIVITY_EFFECT		= "reflectivity_effect_float";

const char* PARAM_SHININESS_EFFECT		= "shininess_effect_float";

const char* PARAM_SPECULAR_EFFECT_COLOR		= "specular_effect_rgb";

const char* PARAM_SPOT_LIGHT_COLOR		= "spot_light_rgb";
const char* PARAM_SPOT_LIGHT_COLOR_NAME		= "Spot Light Color";

const char* PARAM_TRANSPARENCY_EFFECT		= "transparency_effect_float";

const char* PARAM_TRANSPARENT_EFFECT_COLOR	= "transparent_effect_rgb";

const char* PARAM_XFOV				= "HFOV";
const char* PARAM_XFOV_NAME			= "Horizontal Field of View";

const char* PARAM_XMAG				= "XMAG";
const char* PARAM_XMAG_NAME			= "Horizontal Magnification";

const char* PARAM_YFOV				= "YFOV";
const char* PARAM_YFOV_NAME			= "Vertical Field of View";

const char* PARAM_YMAG				= "YMAG";
const char* PARAM_YMAG_NAME			= "Vertical Magnification";

const char* PARAM_ZFAR				= "far_clip";
const char* PARAM_ZFAR_NAME			= "Far Clip";

const char* PARAM_ZNEAR				= "near_clip";
const char* PARAM_ZNEAR_NAME			= "Near Clip";

} // namespace cio

