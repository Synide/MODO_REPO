/*
 * Plug-in component shader: Skin Shader
 * This shader essentially layers a bunch of modo shaders together, simplifying
 * the process of setting up an appropriate skin shader. It also makes it much
 * easier to ensure energy conservation.
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 */

#include <lx_shade.hpp>
#include <lx_vector.hpp>
#include <lx_package.hpp>
#include <lx_action.hpp>
#include <lx_value.hpp>
#include <lx_log.hpp>
#include <lx_channelui.hpp>
#include <lx_item.hpp>
#include <lxcommand.h>
#include <lxidef.h>
#include <lx_shdr.hpp>
#include <lx_raycast.hpp>

#include <math.h>
#include <string>

#define CLAMP(value, low, high) (((value)<(low))?(low):(((value)>(high))?(high):(value)))

/* -------------------------------------------------------------------------
 *
 * Vector Packet definition: SkinShader Packet
 *
 * ------------------------------------------------------------------------- */
        
class SkinPacket : public CLxImpl_VectorPacket
{
    public:
        SkinPacket () {}

        static LXtTagInfoDesc	descInfo[];

        unsigned int	vpkt_Size () LXx_OVERRIDE;
        const LXtGUID * vpkt_Interface (void) LXx_OVERRIDE;
        LxResult	vpkt_Initialize (void	*packet) LXx_OVERRIDE;
        LxResult	vpkt_Blend (void	*packet,void	*p0,void	*p1,float	t,int	mode) LXx_OVERRIDE;
};

#define SRVs_SKIN_VPACKET		"skin.shader.packet"
#define LXsP_SAMPLE_SKINSHADER		SRVs_SKIN_VPACKET

LXtTagInfoDesc	 SkinPacket::descInfo[] = {
        { LXsSRV_USERNAME,	"Skin Shader Packet" },
        { LXsSRV_LOGSUBSYSTEM,	"vector-packet"},
        { LXsVPK_CATEGORY,	LXsCATEGORY_SAMPLE},
        { 0 }
};

class SkinMaterialData {
        public:
                SkinMaterialData () {
                        physical = 1;
                        matchSpec = 0;
                        oilBlurRefl = 0;
                        dermColorDist = 0;
                        subColorDist = 0;
                        reflRays = 0;
                        sssRays = 0;
                }

                int		physical;

                LXtFVector	oilSpecColor;
                float		oilSpecAmt;
                float		oilSpecFres;
                float		oilRoughness;

                int		matchSpec;
                LXtFVector	oilReflColor;
                float		oilReflAmt;
                float		oilReflFres;
                int		oilBlurRefl;

                LXtFVector	epiDiffColor;
                float		epiDiffAmt;
                float		epiDiffRoughness;

                LXtFVector	epiSSSColor;
                float		epiSSSAmt;
                float		epiSSSDist;
                float		epiSSSDepth;
                float		epiSSSBias;

                LXtFVector	dermSSSColor;
                float		dermSSSAmt;
                float		dermSSSDist;
                float		dermSSSDepth;
                float		dermSSSBias;
                int		dermColorDist;
                float		dermRedDist;
                float		dermGreenDist;
                float		dermBlueDist;

                LXtFVector	subSSSColor;
                float		subSSSAmt;
                float		subSSSDist;
                float		subSSSDepth;
                float		subSSSBias;
                int		subColorDist;
                float		subRedDist;
                float		subGreenDist;
                float		subBlueDist;

                int		reflRays;
                int		sssRays;

                int		sameSurface;
};

typedef struct st_LXpSkinShader {
        SkinMaterialData	matrData;
} LXpSkinShader;


        unsigned int
SkinPacket::vpkt_Size (void) 
{
        return	sizeof (LXpSkinShader);
}
        
        const LXtGUID *
SkinPacket::vpkt_Interface (void) 
{
        return NULL;
}

        LxResult
SkinPacket::vpkt_Initialize (
        void			*p) 
{
        LXpSkinShader		*ssp = (LXpSkinShader *)p;

        ssp->matrData.physical = 1;
        ssp->matrData.matchSpec = 0;
        ssp->matrData.oilBlurRefl = 0;
        ssp->matrData.dermColorDist = 0;
        ssp->matrData.subColorDist = 0;
        ssp->matrData.reflRays = 0;
        ssp->matrData.sameSurface = 1;
        ssp->matrData.sssRays = 0;

        return LXe_OK;
}

        LxResult
SkinPacket::vpkt_Blend (
        void			*p, 
        void			*p0, 
        void			*p1,
        float			 t,
        int			 mode)
{
        LXpSkinShader		*ssp = (LXpSkinShader *)p;
        LXpSkinShader		*ssp0 = (LXpSkinShader *)p0;
        LXpSkinShader		*ssp1 = (LXpSkinShader *)p1;

        bool			 decision;

        CLxLoc_ShaderService	 shdrSrv;

        /*
         * Do the boolean values first
         */

        decision = (int)(shdrSrv.ScalarBlendValue (1.0, 0.0, t, mode) + .5);

        ssp->matrData.physical = (decision) ?
                                ssp0->matrData.physical :
                                ssp1->matrData.physical;
        ssp->matrData.matchSpec = (decision) ?
                                ssp0->matrData.matchSpec :
                                ssp1->matrData.matchSpec;
        ssp->matrData.dermColorDist = (decision) ?
                                ssp0->matrData.dermColorDist :
                                ssp1->matrData.dermColorDist;
        ssp->matrData.subColorDist = (decision) ?
                                ssp0->matrData.subColorDist :
                                ssp1->matrData.subColorDist;
        ssp->matrData.oilBlurRefl = (decision) ?
                                ssp0->matrData.oilBlurRefl :
                                ssp1->matrData.oilBlurRefl;
        ssp->matrData.sameSurface = (decision) ?
                ssp0->matrData.sameSurface :
                ssp1->matrData.sameSurface;

        /*
         * Do the color values
         */

        shdrSrv.ColorBlendValue (ssp->matrData.oilSpecColor,
                                 ssp0->matrData.oilSpecColor,
                                 ssp1->matrData.oilSpecColor,
                                 t,
                                 mode);
        shdrSrv.ColorBlendValue (ssp->matrData.oilReflColor,
                                ssp0->matrData.oilReflColor,
                                ssp1->matrData.oilReflColor,
                                t,
                                mode);
        shdrSrv.ColorBlendValue (ssp->matrData.epiDiffColor,
                                 ssp0->matrData.epiDiffColor,
                                 ssp1->matrData.epiDiffColor,
                                 t,
                                 mode);
        shdrSrv.ColorBlendValue (ssp->matrData.epiSSSColor,
                                 ssp0->matrData.epiSSSColor,
                                 ssp1->matrData.epiSSSColor,
                                 t,
                                 mode);

        /*
         * Finally do the floats
         */

        ssp->matrData.oilSpecAmt = shdrSrv.ScalarBlendValue (ssp0->matrData.oilSpecAmt,
                                                                ssp1->matrData.oilSpecAmt,
                                                                t,
                                                                mode);
        ssp->matrData.oilSpecFres = shdrSrv.ScalarBlendValue (ssp0->matrData.oilSpecFres,
                                                                ssp1->matrData.oilSpecFres,
                                                                t,
                                                                mode);
        ssp->matrData.oilRoughness = shdrSrv.ScalarBlendValue (ssp0->matrData.oilRoughness,
                                                                ssp1->matrData.oilRoughness,
                                                                t,
                                                                mode);
        ssp->matrData.oilReflAmt = shdrSrv.ScalarBlendValue (ssp0->matrData.oilReflAmt,
                                                                ssp1->matrData.oilReflAmt,
                                                                t,
                                                                mode);
        ssp->matrData.oilReflFres = shdrSrv.ScalarBlendValue (ssp0->matrData.oilReflFres,
                                                                ssp1->matrData.oilReflFres,
                                                                t,
                                                                mode);
        ssp->matrData.epiDiffAmt = shdrSrv.ScalarBlendValue (ssp0->matrData.epiDiffAmt,
                                                                ssp1->matrData.epiDiffAmt,
                                                                t,
                                                                mode);
        ssp->matrData.epiDiffRoughness = shdrSrv.ScalarBlendValue (ssp0->matrData.epiDiffRoughness,
                                                                ssp1->matrData.epiDiffRoughness,
                                                                t,
                                                                mode);
        ssp->matrData.epiSSSAmt = shdrSrv.ScalarBlendValue (ssp0->matrData.epiSSSAmt,
                                                                ssp1->matrData.epiSSSAmt,
                                                                t,
                                                                mode);
        ssp->matrData.epiSSSDist = shdrSrv.ScalarBlendValue (ssp0->matrData.epiSSSDist,
                                                                ssp1->matrData.epiSSSDist,
                                                                t,
                                                                mode);
        ssp->matrData.epiSSSDepth = shdrSrv.ScalarBlendValue (ssp0->matrData.epiSSSDepth,
                                                                ssp1->matrData.epiSSSDepth,
                                                                t,
                                                                mode);
        ssp->matrData.epiSSSBias = shdrSrv.ScalarBlendValue (ssp0->matrData.epiSSSBias,
                                                                ssp1->matrData.epiSSSBias,
                                                                t,
                                                                mode);
        ssp->matrData.dermSSSAmt = shdrSrv.ScalarBlendValue (ssp0->matrData.dermSSSAmt,
                                                                ssp1->matrData.dermSSSAmt,
                                                                t,
                                                                mode);
        ssp->matrData.dermSSSDist = shdrSrv.ScalarBlendValue (ssp0->matrData.dermSSSDist,
                                                                ssp1->matrData.dermSSSDist,
                                                                t,
                                                                mode);
        ssp->matrData.dermSSSDepth = shdrSrv.ScalarBlendValue (ssp0->matrData.dermSSSDepth,
                                                                ssp1->matrData.dermSSSDepth,
                                                                t,																mode);
        ssp->matrData.dermSSSBias = shdrSrv.ScalarBlendValue (ssp0->matrData.dermSSSBias,
                                                                ssp1->matrData.dermSSSBias,
                                                                t,
                                                                mode);
        ssp->matrData.dermRedDist = shdrSrv.ScalarBlendValue (ssp0->matrData.dermRedDist,
                                                                ssp1->matrData.dermRedDist,
                                                                t,
                                                                mode);
        ssp->matrData.dermGreenDist = shdrSrv.ScalarBlendValue (ssp0->matrData.dermGreenDist,
                                                                ssp1->matrData.dermGreenDist,
                                                                t,
                                                                mode);
        ssp->matrData.dermBlueDist = shdrSrv.ScalarBlendValue (ssp0->matrData.dermBlueDist,
                                                                ssp1->matrData.dermBlueDist,
                                                                t,
                                                                mode);
        ssp->matrData.subSSSAmt = shdrSrv.ScalarBlendValue (ssp0->matrData.subSSSAmt,
                                                                ssp1->matrData.subSSSAmt,
                                                                t,
                                                                mode);
        ssp->matrData.subSSSDist = shdrSrv.ScalarBlendValue (ssp0->matrData.subSSSDist,
                                                                ssp1->matrData.subSSSDist,
                                                                t,
                                                                mode);
        ssp->matrData.subSSSDepth = shdrSrv.ScalarBlendValue (ssp0->matrData.subSSSDepth,
                                                                ssp1->matrData.subSSSDepth,
                                                                t,
                                                                mode);
        ssp->matrData.subSSSBias = shdrSrv.ScalarBlendValue (ssp0->matrData.subSSSBias,
                                                                ssp1->matrData.subSSSBias,
                                                                t,
                                                                mode);
        ssp->matrData.subRedDist = shdrSrv.ScalarBlendValue (ssp0->matrData.subRedDist,
                                                                ssp1->matrData.subRedDist,
                                                                t,
                                                                mode);
        ssp->matrData.subGreenDist = shdrSrv.ScalarBlendValue (ssp0->matrData.subGreenDist,
                                                                ssp1->matrData.subGreenDist,
                                                                t,
                                                                mode);
        ssp->matrData.subBlueDist = shdrSrv.ScalarBlendValue (ssp0->matrData.subBlueDist,
                                                                ssp1->matrData.subBlueDist,
                                                                t,
                                                                mode);

        ssp->matrData.reflRays = t * ssp0->matrData.reflRays + (1 - t) * ssp1->matrData.reflRays;
        ssp->matrData.sssRays = t * ssp0->matrData.sssRays + (1 - t) * ssp1->matrData.sssRays;

        return LXe_OK;
}

/* -------------------------------------------------------------------------
 *
 * Skin Material
 *
 * ------------------------------------------------------------------------- */

#define NUM_CHANNELS 53

class SkinMaterial : public CLxImpl_CustomMaterial, public CLxImpl_ChannelUI
{
    public:
        SkinMaterial () {
                DISPLACEMENT_INDEX = -1;
                channelsAreInitialized = 0;
        }

        static LXtTagInfoDesc	descInfo[];

        /*
         *  Custom Material Interface
         */
        int			cmt_Flags () LXx_OVERRIDE;
        LxResult		cmt_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		cmt_LinkChannels  (ILxUnknownID eval, ILxUnknownID item) LXx_OVERRIDE;
        LxResult		cmt_ReadChannels  (ILxUnknownID attr, void **ppvData) LXx_OVERRIDE;
        LxResult		cmt_CustomPacket  (const char	**) LXx_OVERRIDE;
        void			cmt_MaterialEvaluate (ILxUnknownID vector, void *) LXx_OVERRIDE;
        void			cmt_ShaderEvaluate      (ILxUnknownID		 vector,
                                                        ILxUnknownID		 rayObj,
                                                        LXpShadeComponents	*sCmp,
                                                        LXpShadeOutput		*sOut,
                                                        void			*data) LXx_OVERRIDE;
        void			cmt_Cleanup       (void *data) LXx_OVERRIDE;
        LxResult		cmt_SetBump (float *bumpAmp, int *clearBump) LXx_OVERRIDE;
        LxResult		cmt_SetDisplacement (float *dispDist) LXx_OVERRIDE;
        LxResult		cmt_SetSmoothing (double *smooth, double *angle) LXx_OVERRIDE;
        LxResult		cmt_UpdatePreview (int chanIdx, int *flags) LXx_OVERRIDE;

        /*
         *  Channel UI Interface
         */
        LxResult		cui_Enabled (
                                        const char	*channelName,
                                        ILxUnknownID	 msg,
                                        ILxUnknownID	 item,
                                        ILxUnknownID	 read) LXx_OVERRIDE;

        LxResult		cui_DependencyCount (
                                        const char	*channelName,
                                        unsigned	*count) LXx_OVERRIDE;

        LxResult		cui_DependencyByIndex (
                                        const char	*channelName,
                                        unsigned	 index,
                                        LXtItemType	*depItemType,
                                        const char	**depChannelName) LXx_OVERRIDE;


        LxResult		ShadeLowerDermalLayer(
                                        ILxUnknownID			 vector, 
                                        CLxLoc_Raycast			*raycast, 
                                        SkinMaterialData		*matrData,
                                        float				*energy,
                                        LXpShadeComponents		*sCmp, 
                                        LXpShadeComponents		*sCmpOut);
        LxResult		ShadeUpperDermalLayer(
                                        ILxUnknownID			 vector, 
                                        CLxLoc_Raycast			*raycast, 
                                        SkinMaterialData		*matrData,
                                        float				*energy,
                                        LXpShadeComponents		*sCmp, 
                                        LXpShadeComponents		*sCmpOut);
        LxResult		ShadeEpidermalLayer(
                                        ILxUnknownID			 vector, 
                                        CLxLoc_Raycast			*raycast, 
                                        SkinMaterialData		*matrData,
                                        float				*energy,
                                        LXpShadeComponents		*sCmp, 
                                        LXpShadeComponents		*sCmpOut);
        LxResult		ShadeOilLayer(
                                        ILxUnknownID			 vector, 
                                        CLxLoc_Raycast			*raycast, 
                                        SkinMaterialData		*matrData,
                                        float				*energy,
                                        LXpShadeComponents		*sCmp, 
                                        LXpShadeComponents		*sCmpOut);

        void			ClearShader (LXpSampleParms *sParm);
        void			ClearShadeComponents (LXpShadeComponents *sCmp);
                
        LXtItemType		MyType ();

        CLxUser_PacketService	pkt_service;	
        unsigned		parms_offset;
        unsigned		ray_offset;
        unsigned		nrm_offset;
        unsigned		smth_offset;
        unsigned		pkt_offset;	

  	LXtItemType		my_type; 

        int			channelsAreInitialized;
        int			idx[NUM_CHANNELS];
        int			DISPLACEMENT_INDEX;

        float			bumpAmp, dispDist;
};

#define SRVs_SKIN_MATR		"skinMaterial"
#define SRVs_SKIN_MATR_ITEMTYPE	"material." SRVs_SKIN_MATR

LXtTagInfoDesc	 SkinMaterial::descInfo[] = {
        { LXsSRV_USERNAME,	"Skin Material" },
        { LXsSRV_LOGSUBSYSTEM,	"comp-shader"	},
        { 0 }
};

/*
 * Some useful utilities
 */
        static double
FVectorNormalize (
        LXtFVector		v) 
{
        float		m, p;
        m = LXx_VDOT (v, v);
        if(m<=0)
                return -1;
        m = sqrt (m);
        p = 1.0 / m;
        LXx_VSCL (v, p);
        return m;
}

        void
SkinMaterial::ClearShader (
        LXpSampleParms		*sParm) 
{
        sParm->diffAmt = 0.0;
        sParm->specAmt = 0.0;
        sParm->reflAmt = 0.0;
        sParm->tranAmt = 0.0;
        sParm->subsAmt = 0.0;
        sParm->lumiAmt = 0.0;
        sParm->coatAmt = 0.0;
        sParm->dissAmt = 0.0;
}

        void
SkinMaterial::ClearShadeComponents (
        LXpShadeComponents	*sCmp) 
{
        LXx_VCLR (sCmp->diff);
        LXx_VCLR (sCmp->diffDir);
        LXx_VCLR (sCmp->diffInd);
        LXx_VCLR (sCmp->diffUns);
        LXx_VCLR (sCmp->spec);
        LXx_VCLR (sCmp->refl);
        LXx_VCLR (sCmp->tran);
        LXx_VCLR (sCmp->subs);
        LXx_VCLR (sCmp->lumi);
        LXx_VCLR (sCmp->illum);
        LXx_VCLR (sCmp->illumDir);
        LXx_VCLR (sCmp->illumInd);
        LXx_VCLR (sCmp->illumUns);
        LXx_VCLR (sCmp->volLum);
        LXx_VCLR (sCmp->volOpa);
}

        int 
floatTest (
        float			 val) 
{
        unsigned int		 n, exp, mant;

        n = ((unsigned int *) &val) [0];
        exp = (n & 0x7F800000) >> 23;
        if (exp != 255)
                return 0;

        mant = (n & 0x007FFFFF);
        if (mant != 0)
                return -1;	// NAN
        else
                return +1;	// INFINITY
}

/*
 * Add all the channels to the skin material item
 */
const char* SUB_COLOR_DIST	= "subSSSColorDist";
const char* SUB_RED_DIST	= "subSSSRedDist";
const char* SUB_GREEN_DIST	= "subSSSGreenDist";
const char* SUB_BLUE_DIST	= "subSSSBlueDist";
const char* DERM_COLOR_DIST	= "dermSSSColorDist";
const char* DERM_RED_DIST	= "dermSSSRedDist";
const char* DERM_GREEN_DIST	= "dermSSSGreenDist";
const char* DERM_BLUE_DIST	= "dermSSSBlueDist";

        int
SkinMaterial::cmt_Flags ()
{
        return 0; // shader doesn't require any special behavior
}
        
        LxResult
SkinMaterial::cmt_SetupChannels (
        ILxUnknownID		 addChan)
{
                CLxUser_AddChannel	 ac (addChan);

        LXtVector white = {1.0, 1.0, 1.0};

        LXtVector epiColor = {.98, .79, .68};
        LXtVector epiSSSColor = {.98, .83, .74};
        LXtVector dermColor = {.98, .26, .2};
        LXtVector subColor = {.98, .03, .03};

        ac.NewChannel ("physical", LXsTYPE_BOOLEAN);
        ac.SetDefault (0, 1);
     
        ac.NewChannel ("oilSpecColor", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (white);

        ac.NewChannel ("oilSpecAmt", LXsTYPE_PERCENT);
        ac.SetDefault (.02, 0);

        ac.NewChannel ("oilSpecFres", LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel ("oilRoughness", LXsTYPE_PERCENT);
        ac.SetDefault (.85, 0);

        ac.NewChannel ("oilMatchSpec", LXsTYPE_BOOLEAN); // 5
        ac.SetDefault (0, 0);

        ac.NewChannel ("oilReflColor", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (white);

        ac.NewChannel ("oilReflAmt", LXsTYPE_PERCENT);
        ac.SetDefault (0.01, 0);

        ac.NewChannel ("oilReflFres", LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel ("oilBlurRefl", LXsTYPE_BOOLEAN);
        ac.SetDefault (0, 0);

        ac.NewChannel ("epiDiffColor", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (epiColor);

        ac.NewChannel ("epiDiffAmt", LXsTYPE_PERCENT);
        ac.SetDefault (.2, 0);

        ac.NewChannel ("epiDiffRoughness", LXsTYPE_PERCENT);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("epiSSSColor", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (epiColor);

        ac.NewChannel ("epiSSSAmt", LXsTYPE_PERCENT);
        ac.SetDefault (.4, 0);

        ac.NewChannel ("epiSSSDist", LXsTYPE_DISTANCE);
        ac.SetDefault (.001, 0);

        ac.NewChannel ("epiSSSDepth", LXsTYPE_DISTANCE); 
        ac.SetDefault (.001, 0);

        ac.NewChannel ("epiSSSBias", LXsTYPE_PERCENT);
        ac.SetDefault (.95, 0);

        ac.NewChannel ("dermSSSColor", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (dermColor);

        ac.NewChannel ("dermSSSAmt", LXsTYPE_PERCENT);
        ac.SetDefault (.4, 0);

        ac.NewChannel ("dermSSSDist", LXsTYPE_DISTANCE);
        ac.SetDefault (.001, 0);

        ac.NewChannel (DERM_COLOR_DIST, LXsTYPE_BOOLEAN);
        ac.SetDefault (.0, 0);

        ac.NewChannel (DERM_RED_DIST, LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel (DERM_GREEN_DIST, LXsTYPE_PERCENT);
        ac.SetDefault (.6, 0);

        ac.NewChannel (DERM_BLUE_DIST, LXsTYPE_PERCENT);
        ac.SetDefault (.4, 0);

        ac.NewChannel ("dermSSSDepth", LXsTYPE_DISTANCE);
        ac.SetDefault (.0025, 0);

        ac.NewChannel ("dermSSSBias", LXsTYPE_PERCENT);
        ac.SetDefault (.95, 0);

        ac.NewChannel ("subSSSColor", LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefaultVec (subColor);

        ac.NewChannel ("subSSSAmt", LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel ("subSSSDist", LXsTYPE_DISTANCE);
        ac.SetDefault (.003, 0);

        ac.NewChannel (SUB_COLOR_DIST, LXsTYPE_BOOLEAN);
        ac.SetDefault (0.0, 0);

        ac.NewChannel (SUB_RED_DIST, LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 0);

        ac.NewChannel (SUB_GREEN_DIST, LXsTYPE_PERCENT);
        ac.SetDefault (.6, 0);

        ac.NewChannel (SUB_BLUE_DIST, LXsTYPE_PERCENT);
        ac.SetDefault (.4, 0);

        ac.NewChannel ("subSSSDepth", LXsTYPE_DISTANCE);
        ac.SetDefault (.015, 0);

        ac.NewChannel ("subSSSBias", LXsTYPE_PERCENT);
        ac.SetDefault (.2, 0);

        ac.NewChannel ("bumpAmp", LXsTYPE_DISTANCE);
        ac.SetDefault (.005, 0);

        ac.NewChannel ("reflRays", LXsTYPE_INTEGER);
        ac.SetDefault (0, 256);

        ac.NewChannel ("sssRays", LXsTYPE_INTEGER);
        ac.SetDefault (0, 64);

        ac.NewChannel ("dispDist", LXsTYPE_DISTANCE);
        ac.SetDefault (.02, 64);

        ac.NewChannel ("sameSurface", LXsTYPE_BOOLEAN);
        ac.SetDefault (0, 0);

        return LXe_OK;
}

/*
 * Attach to channel evaluations.
 * This gets the indices for the channels in attributes.
 */
        LxResult
SkinMaterial::cmt_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);

        int			 i = 0;

        idx[i++] = ev.AddChan (item, "physical"); // 0

        idx[i++] = ev.AddChan (item, "oilSpecColor.R");
        idx[i++] = ev.AddChan (item, "oilSpecColor.G");
        idx[i++] = ev.AddChan (item, "oilSpecColor.B");
        idx[i++] = ev.AddChan (item, "oilSpecAmt");
        idx[i++] = ev.AddChan (item, "oilSpecFres");
        idx[i++] = ev.AddChan (item, "oilRoughness"); // 6

        idx[i++] = ev.AddChan (item, "oilMatchSpec");
        idx[i++] = ev.AddChan (item, "oilReflColor.R");
        idx[i++] = ev.AddChan (item, "oilReflColor.G");
        idx[i++] = ev.AddChan (item, "oilReflColor.B");
        idx[i++] = ev.AddChan (item, "oilReflAmt");
        idx[i++] = ev.AddChan (item, "oilReflFres"); // 12
        idx[i++] = ev.AddChan (item, "oilBlurRefl"); // 13

        idx[i++] = ev.AddChan (item, "epiDiffColor.R");
        idx[i++] = ev.AddChan (item, "epiDiffColor.G");
        idx[i++] = ev.AddChan (item, "epiDiffColor.B");
        idx[i++] = ev.AddChan (item, "epiDiffAmt");
        idx[i++] = ev.AddChan (item, "epiDiffRoughness"); // 18

        idx[i++] = ev.AddChan (item, "epiSSSColor.R");
        idx[i++] = ev.AddChan (item, "epiSSSColor.G");
        idx[i++] = ev.AddChan (item, "epiSSSColor.B");
        idx[i++] = ev.AddChan (item, "epiSSSAmt");
        idx[i++] = ev.AddChan (item, "epiSSSDist");
        idx[i++] = ev.AddChan (item, "epiSSSDepth");
        idx[i++] = ev.AddChan (item, "epiSSSBias"); // 25

        idx[i++] = ev.AddChan (item, "dermSSSColor.R");
        idx[i++] = ev.AddChan (item, "dermSSSColor.G");
        idx[i++] = ev.AddChan (item, "dermSSSColor.B");
        idx[i++] = ev.AddChan (item, "dermSSSAmt");
        idx[i++] = ev.AddChan (item, "dermSSSDist");
        idx[i++] = ev.AddChan (item, DERM_COLOR_DIST);
        idx[i++] = ev.AddChan (item, DERM_RED_DIST);
        idx[i++] = ev.AddChan (item, DERM_GREEN_DIST);
        idx[i++] = ev.AddChan (item, DERM_BLUE_DIST);
        idx[i++] = ev.AddChan (item, "dermSSSDepth");
        idx[i++] = ev.AddChan (item, "dermSSSBias"); //36

        idx[i++] = ev.AddChan (item, "subSSSColor.R");
        idx[i++] = ev.AddChan (item, "subSSSColor.G");
        idx[i++] = ev.AddChan (item, "subSSSColor.B");
        idx[i++] = ev.AddChan (item, "subSSSAmt");
        idx[i++] = ev.AddChan (item, "subSSSDist");
        idx[i++] = ev.AddChan (item, SUB_COLOR_DIST);
        idx[i++] = ev.AddChan (item, SUB_RED_DIST);
        idx[i++] = ev.AddChan (item, SUB_GREEN_DIST);
        idx[i++] = ev.AddChan (item, SUB_BLUE_DIST);
        idx[i++] = ev.AddChan (item, "subSSSDepth");
        idx[i++] = ev.AddChan (item, "subSSSBias"); // 47

        idx[i++] = ev.AddChan (item, "bumpAmp"); // 48
        idx[i++] = ev.AddChan (item, "reflRays"); // 49
        idx[i++] = ev.AddChan (item, "sssRays"); // 50

        DISPLACEMENT_INDEX	= i;
        idx[i++] = ev.AddChan (item, "dispDist"); // 51

        idx[i++] = ev.AddChan (item, "sameSurface"); // 0

        // This is to make sure we don't go out of bounds
        if (i > NUM_CHANNELS)
                abort();

        parms_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_PARMS);
        ray_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_RAY);
        nrm_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SURF_NORMAL);
        pkt_offset		= pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_SAMPLE_SKINSHADER);

        channelsAreInitialized = 1;

        return LXe_OK;
}

/*
 * Read channel values which may have changed.
 */
        LxResult
SkinMaterial::cmt_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        SkinMaterialData*       md = new SkinMaterialData;

        int			index = 0;

        md->physical		= at.Int (idx[index++]); // 0

        md->oilSpecColor[0]	= at.Float (idx[index++]);
        md->oilSpecColor[1]	= at.Float (idx[index++]);
        md->oilSpecColor[2]	= at.Float (idx[index++]);
        md->oilSpecAmt		= at.Float (idx[index++]);
        md->oilSpecFres		= at.Float (idx[index++]);
        md->oilRoughness	= at.Float (idx[index++]); // 6

        md->matchSpec		= at.Int (idx[index++]);

        if (md->matchSpec) {
                md->oilReflColor[0]	= md->oilSpecColor[0];
                md->oilReflColor[1]	= md->oilSpecColor[1];
                md->oilReflColor[2]	= md->oilSpecColor[2];
                md->oilReflAmt		= md->oilSpecAmt;
                md->oilReflFres		= md->oilSpecFres;
                index += 5;
        }
        else {
                md->oilReflColor[0]	= at.Float (idx[index++]);
                md->oilReflColor[1]	= at.Float (idx[index++]);
                md->oilReflColor[2]	= at.Float (idx[index++]);
                md->oilReflAmt		= at.Float (idx[index++]);
                md->oilReflFres		= at.Float (idx[index++]);
        }
        md->oilBlurRefl		= at.Int (idx[index++]);

        md->epiDiffColor[0]	= at.Float (idx[index++]);
        md->epiDiffColor[1]	= at.Float (idx[index++]);
        md->epiDiffColor[2]	= at.Float (idx[index++]);
        md->epiDiffAmt		= at.Float (idx[index++]);
        md->epiDiffRoughness	= at.Float (idx[index++]); // 18

        md->epiSSSColor[0]	= at.Float (idx[index++]);
        md->epiSSSColor[1]	= at.Float (idx[index++]);
        md->epiSSSColor[2]	= at.Float (idx[index++]);
        md->epiSSSAmt		= at.Float (idx[index++]);
        md->epiSSSDist		= at.Float (idx[index++]);
        md->epiSSSDepth		= at.Float (idx[index++]);
        md->epiSSSBias		= at.Float (idx[index++]); // 25

        md->dermSSSColor[0]	= at.Float (idx[index++]);
        md->dermSSSColor[1]	= at.Float (idx[index++]);
        md->dermSSSColor[2]	= at.Float (idx[index++]);
        md->dermSSSAmt		= at.Float (idx[index++]);
        md->dermSSSDist		= at.Float (idx[index++]);
        md->dermColorDist	= at.Int (idx[index++]);
        md->dermRedDist		= at.Float (idx[index++]);
        md->dermGreenDist	= at.Float (idx[index++]);
        md->dermBlueDist	= at.Float (idx[index++]);
        md->dermSSSDepth	= at.Float (idx[index++]);
        md->dermSSSBias		= at.Float (idx[index++]); // 36

        md->subSSSColor[0]	= at.Float (idx[index++]);
        md->subSSSColor[1]	= at.Float (idx[index++]);
        md->subSSSColor[2]	= at.Float (idx[index++]);
        md->subSSSAmt		= at.Float (idx[index++]);
        md->subSSSDist		= at.Float (idx[index++]);
        md->subColorDist	= at.Int (idx[index++]);
        md->subRedDist		= at.Float (idx[index++]);
        md->subGreenDist	= at.Float (idx[index++]);
        md->subBlueDist		= at.Float (idx[index++]);
        md->subSSSDepth		= at.Float (idx[index++]);
        md->subSSSBias		= at.Float (idx[index++]); // 47

        this->bumpAmp		= at.Float (idx[index++]); // 48

        md->reflRays		= at.Int (idx[index++]); // 49
        md->sssRays		= at.Int (idx[index++]); // 50

        this->dispDist		= at.Float (idx[index++]); // 51

        md->sameSurface		= at.Int (idx[index++]);

        // This is to make sure we don't go out of bounds
        if (index > NUM_CHANNELS)
                abort();
        
        ppvData[0] = md;
        return LXe_OK;
}

        LxResult
SkinMaterial::cmt_CustomPacket (
        const char		**packet)
{
        packet[0] = LXsP_SAMPLE_SKINSHADER;
        return LXe_OK;
}
/*
 * Channel UI Functions
 */
const char* SKIN_MATERIAL_MSG_TABLE = "material.skinMaterial";

const unsigned SKIN_MATERIAL_PER_COLOR_SCATTERING_MSG = 1001;

        LxResult
SkinMaterial::cui_Enabled (
        const char	*channelName,
        ILxUnknownID	 msg,
        ILxUnknownID	 item,
        ILxUnknownID	 read)
{
        CLxUser_ChannelRead	chan (read);
        CLxUser_Item		src (item);
        LxResult		result = LXe_OK;

        if ((strcmp (channelName, SUB_RED_DIST) == 0) || 
                (strcmp (channelName, SUB_GREEN_DIST) == 0) ||
                (strcmp (channelName, SUB_BLUE_DIST) == 0))
        {
                int perColorDist = chan.IValue (src, SUB_COLOR_DIST);

                if (!perColorDist) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (SKIN_MATERIAL_MSG_TABLE, SKIN_MATERIAL_PER_COLOR_SCATTERING_MSG);

                        result = LXe_CMD_DISABLED;
                }
        }
        else if ((strcmp (channelName, DERM_RED_DIST) == 0) ||
                (strcmp (channelName, DERM_GREEN_DIST) == 0) ||
                (strcmp (channelName, DERM_BLUE_DIST) == 0))
        {
                int perColorDist = chan.IValue (src, DERM_COLOR_DIST);

                if (!perColorDist) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (SKIN_MATERIAL_MSG_TABLE, SKIN_MATERIAL_PER_COLOR_SCATTERING_MSG);

                        result = LXe_CMD_DISABLED;
                }
        }

        return result;
}

        LxResult
SkinMaterial::cui_DependencyCount (
        const char	*channelName,
        unsigned	*count)
{
        if ((strcmp (channelName, SUB_RED_DIST) == 0) || 
                (strcmp (channelName, SUB_GREEN_DIST) == 0) ||
                (strcmp (channelName, SUB_BLUE_DIST) == 0) ||
                (strcmp (channelName, DERM_RED_DIST) == 0) ||
                (strcmp (channelName, DERM_GREEN_DIST) == 0) ||
                (strcmp (channelName, DERM_BLUE_DIST) == 0)) {
                count[0] = 1;
        }
        else {
                count[0] = 0;
        }

        return LXe_OK;
}

        LxResult
SkinMaterial::cui_DependencyByIndex (
        const char	*channelName,
        unsigned	 index,
        LXtItemType	*depItemType,
        const char	**depChannelName)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if ((strcmp (channelName, SUB_RED_DIST) == 0) || 
                (strcmp (channelName, SUB_GREEN_DIST) == 0) ||
                (strcmp (channelName, SUB_BLUE_DIST) == 0)) 
        {
                depItemType[0] = MyType ();
                switch (index) {
                    case 0:
                        depChannelName[0] = SUB_COLOR_DIST;
                        result = LXe_OK;
                        break;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }
        else if ((strcmp (channelName, DERM_RED_DIST) == 0) ||
                (strcmp (channelName, DERM_GREEN_DIST) == 0) ||
                (strcmp (channelName, DERM_BLUE_DIST) == 0)) 
        {
                depItemType[0] = MyType ();
                switch (index) {
                    case 0:
                        depChannelName[0] = DERM_COLOR_DIST;
                        result = LXe_OK;
                        break;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }

        return result;
}


/*
 * Functions for shading the individual layers
 */
        LxResult		
SkinMaterial::ShadeLowerDermalLayer(
        ILxUnknownID		 vector, 
        CLxLoc_Raycast		*raycast, 
        SkinMaterialData	*matrData,
        float			*energy,
        LXpShadeComponents	*sCmp, 
        LXpShadeComponents	*sCmpOut)
{
        LXpSampleParms		*sampleParameters	= 
                (LXpSampleParms*) pkt_service.FastPacket (vector, parms_offset);
        LxResult		 result;

        if (!matrData->subColorDist) {
                LXx_VCPY (sampleParameters->subsCol, matrData->subSSSColor);
                sampleParameters->subsAmt	= matrData->subSSSAmt * (*energy);
                sampleParameters->subsDist	= matrData->subSSSDist;
                sampleParameters->subsPhase	= matrData->subSSSBias;
                sampleParameters->subsDepth	= matrData->subSSSDepth;

                result = raycast->InternalShade (vector);

                if (result != LXe_OK)
                        return result;

                LXx_VADD (sCmpOut->subs, sCmp->subs);
        }
        else {
                float* dist[3];
                dist[0] = &(matrData->subRedDist);
                dist[1] = &(matrData->subGreenDist);
                dist[2] = &(matrData->subBlueDist);

                sampleParameters->subsAmt	= matrData->subSSSAmt * (*energy);
                sampleParameters->subsPhase	= matrData->subSSSBias;
                sampleParameters->subsDepth	= matrData->subSSSDepth;

                for (int i = 0; i < 3; i++) {
                        LXx_VCLR (sampleParameters->subsCol);
                        sampleParameters->subsCol[i]	= matrData->subSSSColor[i];
                        sampleParameters->subsDist	= matrData->subSSSDist * (*(dist[i]));

                        result = raycast->InternalShade (vector);

                        if (result != LXe_OK)
                                return result;

                        LXx_VADD (sCmpOut->subs, sCmp->subs);
                }
        }

        return LXe_OK;
}

        LxResult		
SkinMaterial::ShadeUpperDermalLayer(
        ILxUnknownID		 vector, 
        CLxLoc_Raycast		*raycast, 
        SkinMaterialData	*matrData,
        float			*energy,
        LXpShadeComponents	*sCmp, 
        LXpShadeComponents	*sCmpOut)
{
        LXpSampleParms		*sampleParameters	= 
                (LXpSampleParms*) pkt_service.FastPacket (vector, parms_offset);
        LxResult		 result;

                if (!matrData->dermColorDist) {
                LXx_VCPY (sampleParameters->subsCol, matrData->dermSSSColor);
                sampleParameters->subsAmt	= matrData->dermSSSAmt * (*energy);
                sampleParameters->subsDist	= matrData->dermSSSDist;
                sampleParameters->subsPhase	= matrData->dermSSSBias;
                sampleParameters->subsDepth	= matrData->dermSSSDepth;

                result = raycast->InternalShade (vector);

                if (result != LXe_OK)
                        return result;

                LXx_VADD (sCmpOut->subs, sCmp->subs);
        }
        else {
                float* dist[3];
                dist[0] = &(matrData->dermRedDist);
                dist[1] = &(matrData->dermGreenDist);
                dist[2] = &(matrData->dermBlueDist);

                sampleParameters->subsAmt	= matrData->dermSSSAmt * (*energy);
                sampleParameters->subsPhase	= matrData->dermSSSBias;
                sampleParameters->subsDepth	= matrData->dermSSSDepth;

                for (int i = 0; i < 3; i++) {
                        LXx_VCLR (sampleParameters->subsCol);
                        sampleParameters->subsCol[i] = matrData->dermSSSColor[i];
                        sampleParameters->subsDist = matrData->dermSSSDist * (*(dist[i]));

                        result = raycast->InternalShade (vector);

                        if (result != LXe_OK)
                                return result;

                        LXx_VADD (sCmpOut->subs, sCmp->subs);
                }
        }

        if (matrData->physical) {
                (*energy) *= (1.0 - CLAMP(matrData->dermSSSAmt, 0.0, 1.0));
        }

        sampleParameters->subsAmt = 0.0;

        return LXe_OK;
}

        LxResult		
SkinMaterial::ShadeEpidermalLayer(
        ILxUnknownID		 vector, 
        CLxLoc_Raycast		*raycast, 
        SkinMaterialData	*matrData,
        float			*energy,
        LXpShadeComponents	*sCmp, 
        LXpShadeComponents	*sCmpOut)
{
        LXpSampleParms		*sampleParameters	= 
                (LXpSampleParms*) pkt_service.FastPacket (vector, parms_offset);
        LxResult		 result;

        LXx_VCPY (sampleParameters->diffCol, matrData->epiDiffColor);
        sampleParameters->diffAmt	= matrData->epiDiffAmt * (*energy);
        sampleParameters->diffRough	= matrData->epiDiffRoughness;

        LXx_VCPY (sampleParameters->subsCol, matrData->epiSSSColor);
        sampleParameters->subsAmt	= matrData->epiSSSAmt * (*energy);
        sampleParameters->subsDist	= matrData->epiSSSDist;
        sampleParameters->subsPhase	= matrData->epiSSSBias;
        sampleParameters->subsDepth	= matrData->epiSSSDepth;

        result = raycast->InternalShade (vector);

        if (result != LXe_OK)
                return result;

        // Add in the resulting shade components
        LXx_VADD (sCmpOut->diff,	sCmp->diff);
        LXx_VADD (sCmpOut->diffDir,	sCmp->diffDir);
        LXx_VADD (sCmpOut->diffInd,	sCmp->diffInd);
        LXx_VADD (sCmpOut->diffUns,	sCmp->diffUns);
        LXx_VADD (sCmpOut->illum,	sCmp->illum);
        LXx_VADD (sCmpOut->illumDir,	sCmp->illumDir);
        LXx_VADD (sCmpOut->illumInd,	sCmp->illumInd);
        LXx_VADD (sCmpOut->illumUns,	sCmp->illumUns);
        LXx_VADD (sCmpOut->subs,	sCmp->subs);

        if (matrData->physical) {
                (*energy) *= (1.0 - CLAMP(matrData->epiDiffAmt, 0.0, 1.0));
                (*energy) *= (1.0 - CLAMP(matrData->epiSSSAmt, 0.0, 1.0));
        }

        // Reset the diffuse and subsurface amounts
        sampleParameters->diffAmt = 0.0;
        sampleParameters->subsAmt = 0.0;

        return LXe_OK;
}

        LxResult		
SkinMaterial::ShadeOilLayer(
        ILxUnknownID		 vector, 
        CLxLoc_Raycast		*raycast, 
        SkinMaterialData	*matrData,
        float			*energy,
        LXpShadeComponents	*sCmp, 
        LXpShadeComponents	*sCmpOut)
{
        LXpSampleParms		*sampleParameters	= 
                (LXpSampleParms*) pkt_service.FastPacket (vector, parms_offset);
        LXpSampleSurfNormal	*sampleNormal		= 
                (LXpSampleSurfNormal*) pkt_service.FastPacket (vector, nrm_offset);
        LXpSampleRay		*sampleRay		= 
                (LXpSampleRay*) pkt_service.FastPacket (vector, ray_offset);
        LxResult		 result;
        CLxLoc_ShaderService	 shdrSrv;

        if (matrData->oilBlurRefl)
                sampleParameters->flags |= LXfSURF_REFLBLUR;
        else
                sampleParameters->flags &= ~LXfSURF_REFLBLUR;

        LXx_VCPY (sampleParameters->specCol, matrData->oilSpecColor);
        sampleParameters->specAmt	= matrData->oilSpecAmt;
        sampleParameters->specFres	= matrData->oilSpecFres;
        sampleParameters->rough		= matrData->oilRoughness;
        LXx_VCPY (sampleParameters->reflCol, matrData->oilReflColor);
        sampleParameters->reflAmt	= matrData->oilReflAmt;
        sampleParameters->reflFres	= matrData->oilReflFres;
        sampleParameters->rough		= matrData->oilRoughness;

        result = raycast->InternalShade (vector);

        if (result != LXe_OK) {
                return result;
        }

        // Add in the relevant shade components
        LXx_VADD (sCmpOut->spec, sCmp->spec);
        LXx_VADD (sCmpOut->refl, sCmp->refl);

        if (matrData->physical) {
                float energyLossSpec, energyLossRefl;
                LXtFVector view;

                LXx_VSCL3 (view, sampleRay->dir, -1.0);

                energyLossSpec = shdrSrv.ComputeFresnel (view, sampleNormal->wNorm, matrData->oilSpecAmt);
                energyLossSpec = (matrData->oilSpecFres * energyLossSpec) + ((1.0 - matrData->oilSpecFres) * matrData->oilSpecAmt);

                energyLossRefl = shdrSrv.ComputeFresnel (view, sampleNormal->wNorm, matrData->oilReflAmt);
                energyLossRefl = (matrData->oilReflFres * energyLossRefl) + ((1.0 - matrData->oilReflFres) * matrData->oilReflAmt);

                (*energy) *= (1.0 - CLAMP(LXxMAX (energyLossSpec, energyLossRefl), 0.0, 1.0));
        }

        // Reset the specularity and reflection amounts
        sampleParameters->specAmt = 0.0;
        sampleParameters->reflAmt = 0.0;
        sampleParameters->specFres = 0.0;
        sampleParameters->reflFres = 0.0;

        return LXe_OK;
}

/*
 * Evaluate the color at a spot.
 */
        void
SkinMaterial::cmt_MaterialEvaluate (
        ILxUnknownID            vector,
        void			*data)
{
        LXpSkinShader		*sSkin = (LXpSkinShader*) pkt_service.FastPacket (vector, pkt_offset);
        SkinMaterialData*       md = (SkinMaterialData* )data;

        // Copy over the material data
        sSkin->matrData = *md;
}

        void
SkinMaterial::cmt_Cleanup (
        void			*data)
{
        SkinMaterialData*       md = (SkinMaterialData* )data;

        delete md;
}

        LxResult
SkinMaterial::cmt_SetBump (
        float			*bumpAmp,
        int			*clearBump)
{
        *bumpAmp = this->bumpAmp;
        *clearBump = 1;

        return LXe_OK;
}

        LxResult
SkinMaterial::cmt_SetDisplacement (
        float			*dispDist)
{
        *dispDist = this->dispDist;

        return LXe_OK;
}

/*
 * Skin should be smooth!
 */
        LxResult
SkinMaterial::cmt_SetSmoothing (
        double			*smooth,
        double			*angle)
{
        *smooth = 1.0;
        *angle = 90.0;

        return LXe_OK;
}
/*
 * If displacement distance has changed, we need to update geometry. Otherwise
 * we return LXe_NOTIMPL so that it will use the default updating.
 */

        LxResult
SkinMaterial::cmt_UpdatePreview (
        int			 chanIdx,
        int			*flags)
{
        LxResult returnResult = LXe_NOTIMPL;

        if (channelsAreInitialized) {
                if (chanIdx == idx[DISPLACEMENT_INDEX]) {
                        *flags = LXfPREV_UPDATE_GEOMETRY;
                        returnResult = LXe_OK;
                }
        }

        return returnResult;
}
/*
 * Evaluate the color at a spot.
 */
        void
SkinMaterial::cmt_ShaderEvaluate (
        ILxUnknownID            vector,
        ILxUnknownID		rayObj,
        LXpShadeComponents     *sCmp,
        LXpShadeOutput         *sOut,
        void                   *data)
{
        LXpSampleParms		*sampleParameters	= 
                (LXpSampleParms*) pkt_service.FastPacket (vector, parms_offset);
        LXpSkinShader		*sSkin			= 
                (LXpSkinShader*) pkt_service.FastPacket (vector, pkt_offset);
        SkinMaterialData	*matrData = &(sSkin->matrData);

        LXpShadeComponents	 sCmpOut;

        LxResult		 result;

        LXtFVector		 purple = {1.0, 0.0, 1.0};
        
        CLxLoc_Raycast		 raycast;

        // This is used for Energy Conservation
        float			 energy = 1.0;
        
        // Initialize the raycast object
        raycast.set (rayObj);

        if (matrData->physical)
                sampleParameters->flags |= LXfSURF_PHYSICAL;

        if (matrData->sameSurface)
                sampleParameters->flags |= LXfSURF_SAMESURF;

        /*
         * Set the quality settings
         */
        sampleParameters->reflRays = matrData->reflRays;
        sampleParameters->subsRays = matrData->sssRays;

        /*
         * Initialize the shading by setting everything to zero
         */
        this->ClearShader (sampleParameters);
        this->ClearShadeComponents (&sCmpOut);

        /*
         * Compute all the shading
         */

        result = ShadeOilLayer(vector, &raycast, matrData, &energy, sCmp, &sCmpOut);
        if (result != LXe_OK) {
                LXx_VCPY (sOut->color, purple);
                return;
        }

        result = ShadeEpidermalLayer(vector, &raycast, matrData, &energy, sCmp, &sCmpOut);
        if (result != LXe_OK) {
                LXx_VCPY (sOut->color, purple);
                return;
        }

        result = ShadeUpperDermalLayer(vector, &raycast, matrData, &energy, sCmp, &sCmpOut);
        if (result != LXe_OK) {
                LXx_VCPY (sOut->color, purple);
                return;
        }

        result = ShadeLowerDermalLayer(vector, &raycast, matrData, &energy, sCmp, &sCmpOut);
        if (result != LXe_OK) {
                LXx_VCPY (sOut->color, purple);
                return;
        }

        // Copy the final new shade components out
        *sCmp = sCmpOut;

        // Compute the final color
        for (int i = 0; i < 3; i++) 
                sOut->color[i] = sCmp->diff[i] + sCmp->spec[i] + sCmp->refl[i] + sCmp->subs[i];

        if (floatTest(sOut->color[0]) || floatTest(sOut->color[1]) || floatTest(sOut->color[2])) {
                LXx_VCPY (sOut->color, purple);
        }

        // Set the final alpha to zero
        sOut->alpha = 1.0;
}
        
        LXtItemType
SkinMaterial::MyType ()
{
        if (my_type != LXiTYPE_NONE)
                return my_type;

        CLxUser_SceneService	 svc;

        my_type = svc.ItemType (SRVs_SKIN_MATR_ITEMTYPE);
        return my_type;
}

/* -------------------------------------------------------------------------
 *
 * Packet Effects definition:
 * This section is used to define all the various texture effects that
 * can be used with the skin shader.
 *
 * ------------------------------------------------------------------------- */

class SkinPFX : public CLxImpl_PacketEffect
{
        public:
                SkinPFX () {}

                static LXtTagInfoDesc	descInfo[];

                LxResult		pfx_Packet (const char **packet) LXx_OVERRIDE;
                unsigned int		pfx_Count (void) LXx_OVERRIDE;
                LxResult		pfx_ByIndex (int idx, const char **name, const char **typeName, int *type) LXx_OVERRIDE;
                LxResult		pfx_Get (int idx,void *packet, float *val, void *item) LXx_OVERRIDE;
                LxResult		pfx_Set (int idx,void *packet, const float *val, void *item) LXx_OVERRIDE;
};

#define SRVs_SKIN_PFX		SRVs_SKIN_MATR

enum {
        SRVs_OIL_SPEC_COL_IDX = 0,
        SRVs_OIL_SPEC_AMT_IDX,
        SRVs_OIL_SPEC_FRES_IDX,
        SRVs_OIL_ROUGH_IDX,
        SRVs_OIL_REFL_COL_IDX,
        SRVs_OIL_REFL_AMT_IDX,
        SRVs_OIL_REFL_FRES_IDX,
        SRVs_EPI_DIFF_COL_IDX,
        SRVs_EPI_DIFF_AMT_IDX,
        SRVs_EPI_DIFF_ROUGH_IDX,
        SRVs_EPI_SSS_COL_IDX,
        SRVs_EPI_SSS_AMT_IDX,
        SRVs_EPI_SSS_DEPTH_IDX,
        SRVs_DERM_SSS_COL_IDX,
        SRVs_DERM_SSS_AMT_IDX,
        SRVs_DERM_SSS_DEPTH_IDX,
        SRVs_SUB_SSS_COL_IDX,
        SRVs_SUB_SSS_AMT_IDX,
        SRVs_SUB_SSS_DEPTH_IDX
};

#define SRVs_OIL_SPEC_COL_TFX	"oilSpecColor"
#define SRVs_OIL_SPEC_AMT_TFX	"oilSpecAmt"
#define SRVs_OIL_SPEC_FRES_TFX	"oilSpecFres"
#define SRVs_OIL_ROUGH_TFX	"oilRoughness"
#define SRVs_OIL_REFL_COL_TFX	"oilReflColor"
#define SRVs_OIL_REFL_AMT_TFX	"oilReflAmt"
#define SRVs_OIL_REFL_FRES_TFX	"oilReflFres"
#define SRVs_EPI_DIFF_COL_TFX	"epiDiffColor"
#define SRVs_EPI_DIFF_AMT_TFX	"epiDiffAmt"
#define SRVs_EPI_DIFF_ROUGH_TFX	"epiDiffRoughness"
#define SRVs_EPI_SSS_COL_TFX	"epiSSSColor"
#define SRVs_EPI_SSS_AMT_TFX	"epiSSSAmt"
#define SRVs_EPI_SSS_DEPTH_TFX	"epiSSSDepth"
#define SRVs_DERM_SSS_COL_TFX	"dermSSSColor"
#define SRVs_DERM_SSS_AMT_TFX	"dermSSSAmt"
#define SRVs_DERM_SSS_DEPTH_TFX	"dermSSSDepth"
#define SRVs_SUB_SSS_COL_TFX	"subSSSColor"
#define SRVs_SUB_SSS_AMT_TFX	"subSSSAmt"
#define SRVs_SUB_SSS_DEPTH_TFX	"subSSSDepth"

LXtTagInfoDesc SkinPFX::descInfo[] = {
        { LXsSRV_USERNAME,	"Skin Packet FX" },
        { LXsSRV_LOGSUBSYSTEM,	"texture-effect"},
        { LXsTFX_CATEGORY,	LXsSHADE_SURFACE},
        { 0 }
};

        LxResult
SkinPFX::pfx_Packet (const char	**packet) 
{
        packet[0] = SRVs_SKIN_VPACKET;
        return LXe_OK;
}

        unsigned int
SkinPFX::pfx_Count (void) 
{
        return 19;
}

        LxResult
SkinPFX::pfx_ByIndex (int id, const char **name, const char **typeName, int *type) 
{
        switch (id) {
                case SRVs_OIL_SPEC_COL_IDX:
                        name[0]     = SRVs_OIL_SPEC_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_OIL_SPEC_AMT_IDX:
                        name[0]     = SRVs_OIL_SPEC_AMT_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case SRVs_OIL_SPEC_FRES_IDX:
                        name[0]     = SRVs_OIL_SPEC_FRES_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case SRVs_OIL_ROUGH_IDX:
                        name[0]     = SRVs_OIL_ROUGH_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;

                case SRVs_OIL_REFL_COL_IDX:
                        name[0]     = SRVs_OIL_REFL_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_OIL_REFL_AMT_IDX:
                        name[0]     = SRVs_OIL_REFL_AMT_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case SRVs_OIL_REFL_FRES_IDX:
                        name[0]     = SRVs_OIL_REFL_FRES_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;

                case SRVs_EPI_DIFF_COL_IDX:
                        name[0]     = SRVs_EPI_DIFF_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_EPI_DIFF_AMT_IDX:
                        name[0]     = SRVs_EPI_DIFF_AMT_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case SRVs_EPI_DIFF_ROUGH_IDX:
                        name[0]     = SRVs_EPI_DIFF_ROUGH_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;

                case SRVs_EPI_SSS_COL_IDX:
                        name[0]     = SRVs_EPI_SSS_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_EPI_SSS_AMT_IDX:
                        name[0]     = SRVs_EPI_SSS_AMT_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case SRVs_EPI_SSS_DEPTH_IDX:
                        name[0]     = SRVs_EPI_SSS_DEPTH_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;

                case SRVs_DERM_SSS_COL_IDX:
                        name[0]     = SRVs_DERM_SSS_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_DERM_SSS_AMT_IDX:
                        name[0]     = SRVs_DERM_SSS_AMT_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case SRVs_DERM_SSS_DEPTH_IDX:
                        name[0]     = SRVs_DERM_SSS_DEPTH_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;

                case SRVs_SUB_SSS_COL_IDX:
                        name[0]     = SRVs_SUB_SSS_COL_TFX;
                        type[0]     = LXi_TFX_COLOR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_COLOR1;
                        break;
                case SRVs_SUB_SSS_AMT_IDX:
                        name[0]     = SRVs_SUB_SSS_AMT_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
                case SRVs_SUB_SSS_DEPTH_IDX:
                        name[0]     = SRVs_SUB_SSS_DEPTH_TFX;
                        type[0]     = LXi_TFX_SCALAR | LXf_TFX_READ | LXf_TFX_WRITE;
                        typeName[0] = LXsTYPE_FLOAT;
                        break;
        }
                        
        return	LXe_OK;
}

        LxResult
SkinPFX::pfx_Get (int id, void *packet, float *val, void *item) 
{
        LXpSkinShader	*skinPacket = (LXpSkinShader *) packet;

        switch (id) {
                case SRVs_OIL_SPEC_COL_IDX:
                        val[0] = skinPacket->matrData.oilSpecColor[0];
                        val[1] = skinPacket->matrData.oilSpecColor[1];
                        val[2] = skinPacket->matrData.oilSpecColor[2];
                        break;
                case SRVs_OIL_SPEC_AMT_IDX:
                        val[0] = skinPacket->matrData.oilSpecAmt;
                        break;
                case SRVs_OIL_SPEC_FRES_IDX:
                        val[0] = skinPacket->matrData.oilSpecFres;
                        break;
                case SRVs_OIL_ROUGH_IDX:
                        val[0] = skinPacket->matrData.oilRoughness;
                        break;

                case SRVs_OIL_REFL_COL_IDX:
                        val[0] = skinPacket->matrData.oilReflColor[0];
                        val[1] = skinPacket->matrData.oilReflColor[1];
                        val[2] = skinPacket->matrData.oilReflColor[2];
                        break;
                case SRVs_OIL_REFL_AMT_IDX:
                        val[0] = skinPacket->matrData.oilReflAmt;
                        break;
                case SRVs_OIL_REFL_FRES_IDX:
                        val[0] = skinPacket->matrData.oilReflFres;
                        break;

                case SRVs_EPI_DIFF_COL_IDX:
                        val[0] = skinPacket->matrData.epiDiffColor[0];
                        val[1] = skinPacket->matrData.epiDiffColor[1];
                        val[2] = skinPacket->matrData.epiDiffColor[2];
                        break;
                case SRVs_EPI_DIFF_AMT_IDX:
                        val[0] = skinPacket->matrData.epiDiffAmt;
                        break;
                case SRVs_EPI_DIFF_ROUGH_IDX:
                        val[0] = skinPacket->matrData.oilRoughness;
                        break;

                case SRVs_EPI_SSS_COL_IDX:
                        val[0] = skinPacket->matrData.epiSSSColor[0];
                        val[1] = skinPacket->matrData.epiSSSColor[1];
                        val[2] = skinPacket->matrData.epiSSSColor[2];
                        break;
                case SRVs_EPI_SSS_AMT_IDX:
                        val[0] = skinPacket->matrData.epiSSSAmt;
                        break;
                case SRVs_EPI_SSS_DEPTH_IDX:
                        val[0] = skinPacket->matrData.epiSSSDepth;
                        break;

                case SRVs_DERM_SSS_COL_IDX:
                        val[0] = skinPacket->matrData.dermSSSColor[0];
                        val[1] = skinPacket->matrData.dermSSSColor[1];
                        val[2] = skinPacket->matrData.dermSSSColor[2];
                        break;
                case SRVs_DERM_SSS_AMT_IDX:
                        val[0] = skinPacket->matrData.dermSSSAmt;
                        break;
                case SRVs_DERM_SSS_DEPTH_IDX:
                        val[0] = skinPacket->matrData.dermSSSDepth;
                        break;

                case SRVs_SUB_SSS_COL_IDX:
                        val[0] = skinPacket->matrData.subSSSColor[0];
                        val[1] = skinPacket->matrData.subSSSColor[1];
                        val[2] = skinPacket->matrData.subSSSColor[2];
                        break;
                case SRVs_SUB_SSS_AMT_IDX:
                        val[0] = skinPacket->matrData.subSSSAmt;
                        break;
                case SRVs_SUB_SSS_DEPTH_IDX:
                        val[0] = skinPacket->matrData.subSSSDepth;
                        break;
        }
        
        return LXe_OK;
}

        LxResult
SkinPFX::pfx_Set (int id, void *packet, const float *val, void *item) 
{
        LXpSkinShader	*skinPacket = (LXpSkinShader *) packet;

        switch (id) {
                case SRVs_OIL_SPEC_COL_IDX:
                        skinPacket->matrData.oilSpecColor[0] = val[0];
                        skinPacket->matrData.oilSpecColor[1] = val[1];
                        skinPacket->matrData.oilSpecColor[2] = val[2];
                        break;
                case SRVs_OIL_SPEC_AMT_IDX:
                        skinPacket->matrData.oilSpecAmt = val[0];
                        break;
                case SRVs_OIL_SPEC_FRES_IDX:
                        skinPacket->matrData.oilSpecFres = val[0];
                        break;
                case SRVs_OIL_ROUGH_IDX:
                        skinPacket->matrData.oilRoughness = val[0];
                        break;

                case SRVs_OIL_REFL_COL_IDX:
                        skinPacket->matrData.oilReflColor[0] = val[0];
                        skinPacket->matrData.oilReflColor[1] = val[1];
                        skinPacket->matrData.oilReflColor[2] = val[2];
                        break;
                case SRVs_OIL_REFL_AMT_IDX:
                        skinPacket->matrData.oilReflAmt = val[0];
                        break;
                case SRVs_OIL_REFL_FRES_IDX:
                        skinPacket->matrData.oilReflFres = val[0];
                        break;

                case SRVs_EPI_DIFF_COL_IDX:
                        skinPacket->matrData.epiDiffColor[0] = val[0];
                        skinPacket->matrData.epiDiffColor[1] = val[1];
                        skinPacket->matrData.epiDiffColor[2] = val[2];
                        break;
                case SRVs_EPI_DIFF_AMT_IDX:
                        skinPacket->matrData.epiDiffAmt = val[0];
                        break;
                case SRVs_EPI_DIFF_ROUGH_IDX:
                        skinPacket->matrData.oilRoughness = val[0];
                        break;

                case SRVs_EPI_SSS_COL_IDX:
                        skinPacket->matrData.epiSSSColor[0] = val[0];
                        skinPacket->matrData.epiSSSColor[1] = val[1];
                        skinPacket->matrData.epiSSSColor[2] = val[2];
                        break;
                case SRVs_EPI_SSS_AMT_IDX:
                        skinPacket->matrData.epiSSSAmt = val[0];
                        break;
                case SRVs_EPI_SSS_DEPTH_IDX:
                        skinPacket->matrData.epiSSSDepth = val[0];
                        break;

                case SRVs_DERM_SSS_COL_IDX:
                        skinPacket->matrData.dermSSSColor[0] = val[0];
                        skinPacket->matrData.dermSSSColor[1] = val[1];
                        skinPacket->matrData.dermSSSColor[2] = val[2];
                        break;
                case SRVs_DERM_SSS_AMT_IDX:
                        skinPacket->matrData.dermSSSAmt = val[0];
                        break;
                case SRVs_DERM_SSS_DEPTH_IDX:
                        skinPacket->matrData.dermSSSDepth = val[0];
                        break;

                case SRVs_SUB_SSS_COL_IDX:
                        skinPacket->matrData.subSSSColor[0] = val[0];
                        skinPacket->matrData.subSSSColor[1] = val[1];
                        skinPacket->matrData.subSSSColor[2] = val[2];
                        break;
                case SRVs_SUB_SSS_AMT_IDX:
                        skinPacket->matrData.subSSSAmt = val[0];
                        break;
                case SRVs_SUB_SSS_DEPTH_IDX:
                        skinPacket->matrData.subSSSDepth = val[0];
                        break;
        }
        
        return LXe_OK;
}


        void
initialize ()
{
    CLxGenericPolymorph*    materialServer = new CLxPolymorph<SkinMaterial>;
    CLxGenericPolymorph*    packetServer = new CLxPolymorph<SkinPacket>;
    CLxGenericPolymorph*    FXServer = new CLxPolymorph<SkinPFX>;

    materialServer->AddInterface (new CLxIfc_CustomMaterial<SkinMaterial>);
    materialServer->AddInterface (new CLxIfc_ChannelUI<SkinMaterial>);
    materialServer->AddInterface (new CLxIfc_StaticDesc<SkinMaterial>);
    lx::AddServer (SRVs_SKIN_MATR, materialServer);

    packetServer->AddInterface (new CLxIfc_VectorPacket<SkinPacket>);
    packetServer->AddInterface (new CLxIfc_StaticDesc<SkinPacket>);
    lx::AddServer (SRVs_SKIN_VPACKET, packetServer);

    FXServer->AddInterface (new CLxIfc_PacketEffect<SkinPFX>);
    FXServer->AddInterface (new CLxIfc_StaticDesc<SkinPFX>);
    lx::AddServer (SRVs_SKIN_PFX, FXServer);
}
