/*
 * Plug-in QuickTime saver for movies.
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include <lx_image.hpp>
#include <stdlib.h>

extern "C"
{
        #include "qtime.h"
}

using namespace lx;

class CQuickTimeMovie : public CLxImpl_Movie
{
    public:
        LxResult		 mov_BeginMovie (const char*,int, int, int);
        LxResult		 mov_SetFramerate (int);
        LxResult		 mov_AddImage (ILxUnknownID);
        LxResult		 mov_EndMovie (void);

        static LXtTagInfoDesc	 descInfo[];

        QTMovieID		 qtMovie;
};

        LxResult
CQuickTimeMovie::mov_BeginMovie (
        const char              *fname,
        int                      w,
        int                      h,
        int                      flags)
{
        LxResult	result;
        result = QTInitialize ();
        if (LXx_OK (result)) {
                qtMovie = QTMovieCreate (fname, w, h, flags);
                if (qtMovie) {
                        result = LXe_OK;
                }
                else {
                        result = LXe_FAILED;
                }
        }

        return result;
}	

        LxResult
CQuickTimeMovie::mov_SetFramerate (
        int			 frate)
{
        QTMovieSetFramerate (qtMovie, frate);
        return LXe_OK;
}	

        LxResult
CQuickTimeMovie::mov_AddImage (
        ILxUnknownID		 img)
{
        CLxUser_Image		 image (img);
        LXtImageByte		*ln, *buf;
        unsigned int		 rowBytes, y;
        unsigned int		 iw, ih;

        image.Size (&iw, &ih);

        rowBytes = (iw * 3 + 3) & ~3;
        buf = (LXtImageByte *) malloc (rowBytes);

        QTMovieBeginFrame (qtMovie);
        
        for (y = 0; y < ih; y++) {
                ln = (LXtImageByte *) image.GetLine (y, LXiIMP_RGB24, buf);
                QTMovieAddLineToFrame (qtMovie, ln, y);
        }
        
        QTMovieEndFrame (qtMovie);
        
        free (buf);
        
        return LXe_OK;
}

        LxResult
CQuickTimeMovie::mov_EndMovie (void)
{
        QTMovieClose (qtMovie);
        
        return LXe_OK;
}

LXtTagInfoDesc	 CQuickTimeMovie::descInfo[] = {
        { LXsLOD_CLASSLIST,	LXa_MOVIE         },
        { LXsLOD_DOSPATTERN,	"*.mov"           },
        { LXsSAV_DOSTYPE,	"mov"             },
        { LXsSRV_USERNAME,	"Quicktime Movie" },
        { 0 }
};


/*
 * ----------------------------------------------------------------
 * Exporting Servers
 */
        void
initialize ()
{
        LXx_ADD_SERVER (Movie, CQuickTimeMovie, "quicktime");
}


