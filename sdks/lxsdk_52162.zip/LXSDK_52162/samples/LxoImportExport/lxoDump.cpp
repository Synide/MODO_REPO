/*
 * Copyright (c) 2009 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include <lximage.h>
#include <lxenvelope.h>
#include "lxoReader.hpp"

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * convert the 4 byte ID into a printable string
 *
 *----------------------------------------------------------------------------*/
static char* stringFromId (LXtID4 id)
{
    static char     idString[] = "'1234'";

    typedef union {
            LXtID4          id;
            LxByte          b[4];
            } Union4Bytes;

    Union4Bytes*    unionP = (Union4Bytes*)&id;

    idString[1] = unionP->b[3];
    idString[2] = unionP->b[2];
    idString[3] = unionP->b[1];
    idString[4] = unionP->b[0];

    return idString;
}

/*------------------------------- Luxology LLC --------------------------- 07/10
 *
 * convert slope type into a printable string
 *
 *----------------------------------------------------------------------------*/
static char* slopeString (int slopeType)
{
    static char*    slopeTypes[] =
        {
        "Direct",
        "Auto",
        "Linear In",
        "Linear Out",
        "Flat",
        "Autoflat",
        "Stepped",
        };

    static char     slopeStr[512];

    slopeStr[0] = '\0';

    if (slopeType & (1 << (LXiSLOPE_AUTO - 1)))
        strcat (slopeStr, slopeTypes[LXiSLOPE_AUTO]);

    if (slopeType & (1 << (LXiSLOPE_LINEAR_IN - 1)))
        {
        if (slopeStr[0])
            strcat (slopeStr, ",");
        strcat (slopeStr, slopeTypes[LXiSLOPE_LINEAR_IN]);
        }

    if (slopeType & (1 << (LXiSLOPE_LINEAR_OUT - 1)))
        {
        if (slopeStr[0])
            strcat (slopeStr, ",");
        strcat (slopeStr, slopeTypes[LXiSLOPE_LINEAR_OUT]);
        }

    if (slopeType & (1 << (LXiSLOPE_FLAT - 1)))
        {
        if (slopeStr[0])
            strcat (slopeStr, ",");
        strcat (slopeStr, slopeTypes[LXiSLOPE_FLAT]);
        }

    if (slopeType & (1 << (LXiSLOPE_AUTOFLAT - 1)))
        {
        if (slopeStr[0])
            strcat (slopeStr, ",");
        strcat (slopeStr, slopeTypes[LXiSLOPE_AUTOFLAT]);
        }

    if (slopeType & (1 << (LXiSLOPE_STEPPED - 1)))
        {
        if (slopeStr[0])
            strcat (slopeStr, ",");
        strcat (slopeStr, slopeTypes[LXiSLOPE_STEPPED]);
        }

    if ('\0' == slopeStr[0])
        strcpy (slopeStr, slopeTypes[LXiSLOPE_DIRECT]);

    return slopeStr;
}

/*------------------------------- Luxology LLC --------------------------- 07/10
 *
 * convert break type into a printable string
 *
 *----------------------------------------------------------------------------*/
static char* breakString (int breakType)
{
    static char     breakStr[512];

    breakStr[0] = '\0';

    if (breakType & LXfKEYBREAK_VALUE)
        strcat (breakStr, "Value");

    if (breakType & LXfKEYBREAK_SLOPE)
        strcat (breakStr, breakStr[0] ? ",Slope" : "Slope" );

    if (breakType & LXfKEYBREAK_WEIGHT)
        strcat (breakStr, breakStr[0] ? ",Weight" : "Weight" );

    if ('\0' == breakStr[0])
        strcpy (breakStr, "None");

    return breakStr;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * The LxoDump class extends LxoReader to create a human-readable version of the
 * LXO file. The constructor opens up the desired output file (or stdout), and
 * the virtual ProcessXXX methods print the contents of each chunk or header.
 *
 *----------------------------------------------------------------------------*/
class LxoDump : public LxoReader {
    FILE*       m_outFile;
    bool        m_isStdout;
    bool        m_dumpGeom;         // show point/poly arrays

    public:
         LxoDump (char* lxoName, char* outName, bool dumpAll);
        ~LxoDump ();

        void        PrintSubHeader ();
        void        PrintValue (LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer = NULL, LxUShort length = 0);

        virtual LxResult	ProcessHeader ();
        virtual LxResult	ProcessUnknown ();
        virtual LxResult	ProcessVersion (LxULong major, LxULong minor, char* str);
        virtual LxResult	ProcessParent (char* str);
        virtual LxResult	ProcessDescription (char* type, char* desc);
        virtual LxResult        ProcessChannelNames (LxULong count, LXtStringVec chans);
        virtual LxResult	ProcessBoundingBox (LXtFVector min, LXtFVector max);
        virtual LxResult	ProcessPolyTags (LXtID4 id, LxULong count, LXtPolyTag* ptags);
        virtual LxResult	ProcessTags (LXtStringVec tags);
        virtual LxResult	ProcessLayer (LXtLayerChunk& layer);
        virtual LxResult	ProcessSurfaceInfo (LXtSufaceInfo& surf);
        virtual LxResult	ProcessGroupInfo (LXtGroupInfo& group);
        virtual LxResult	ProcessPoints (LxULong count, LXtFVector* points);
        virtual LxResult	ProcessTriangles (LxULong count, LXtVertIndex* tris);
        virtual LxResult	ProcessTextTag (LXtID4 id, char* str);
        virtual LxResult	ProcessPolygon (LXtID4 type, LxUShort nVerts, LxULong* verts);
        virtual LxResult	ProcessVectors (LXtID4 id, char* name, LxULong nVectors, LxULong nComponents, float* coords);
        virtual LxResult	ProcessVertexMap (LXtID4 id, char* name, LxULong nMaps, LxULong nComponents);
        virtual LxResult	ProcessVertexMapFlags (LxULong flags[2]);
        virtual LxResult	ProcessVertexMapEntry (LxULong nComponents, LxULong vertIndex, float* values);
        virtual LxResult	ProcessVertexDMapEntry (LxULong nComponents, LxULong vertIndex, LxULong polyIndex, float* values);
        virtual LxResult	ProcessEdgeMap (LXtID4 id, char* name, LxULong nMaps, LxULong nComponents);
        virtual LxResult	ProcessEdgeDMapEntry (LxULong nComponents, LxULong vertIndex, LxULong polyIndex, float* values);
        virtual LxResult	ProcessPreview (LxUShort width, LxUShort height, LxULong type, LxULong flags, LxULong dataBytes, LxByte* imageData);
        virtual LxResult	ProcessThumbnail (LxUShort width, LxUShort height, LxByte nChannels, LxByte flags, LxULong dataBytes, LxByte* imageData);
        virtual LxResult	ProcessBake (LxULong refId, LxULong samples, float startTime, float sampsPerSec);

        virtual LxResult	ProcessItem (char* itemType, char* name, LxULong refId);
        virtual LxResult	ProcessItemUnknown ();
        virtual LxResult	ProcessItemXref (LxULong index, char* filename, char* idStr);
        virtual LxResult	ProcessItemLayer (LxULong index, LxULong flags, LxULong color);
        virtual LxResult	ProcessItemId (char* name);
        virtual LxResult	ProcessItemIndex (LxULong index);
        virtual LxResult	ProcessItemLink (char* name, LxULong refId, LxULong index);
        virtual LxResult	ProcessChannelLink (char* name, char* fromChannel, LxULong index, char* toChannel, LxULong fromIndex, LxULong toIndex);
        virtual LxResult	ProcessItemPackage (char* name, LxULong bytes, LxByte* buffer);
        virtual LxResult	ProcessItemGradient (char* name, LxULong index, LxULong flags, char* inType, char* outType);
        virtual LxResult	ProcessItemTag (LXtID4 tagType, char* value);
        virtual LxResult	ProcessItemPreview (LxUShort width, LxUShort height, LxULong type, LxULong flags, LxULong dataBytes, LxByte* imageData);

        virtual LxResult	ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length);
        virtual LxResult	ProcessItemChannelGeneral (LxULong index, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal);
        virtual LxResult	ProcessItemChannelVector (char* name, LxUShort type, LxUShort count);
        virtual LxResult	ProcessItemChannelVectorValue (char* name, LxUShort type, int intVal, float floatVal, char* strVal);
        virtual LxResult	ProcessItemChannelString (char* name, char* str);
        virtual LxResult	ProcessCustomChannel (char* name, char* str, LxULong dataBytes, LxByte* customData);
        virtual LxResult	ProcessUserChannel (char* name, char* str);

        virtual LxResult	ProcessEnvelope (LxULong index, LxULong type);
        virtual LxResult	ProcessEnvelopeUnknown ();
        virtual LxResult	ProcessEnvelopeBehavior (LxUShort flag);
        virtual LxResult	ProcessEnvelopeTanIn (LxUShort slopeType, LxUShort weightType, float slope, float weight, float value);
        virtual LxResult	ProcessEnvelopeTanOut (LxULong breaks, LxUShort slopeType, LxUShort weightType, float slope, float weight, float value);
        virtual LxResult	ProcessEnvelopeKey (float time, float value);
        virtual LxResult	ProcessEnvelopeKey (float time, LxULong value);
        virtual LxResult	ProcessEnvelopeFlag (LxULong flag);

        virtual LxResult	ProcessAction (char* actionType, char* name, LxULong refId);
        virtual LxResult	ProcessActionUnknown ();
        virtual LxResult	ProcessActionParent (LxULong index);
        virtual LxResult	ProcessActionItem (LxULong index);
        virtual LxResult	ProcessActionChannelGeneral (LxULong index, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal);
        virtual LxResult	ProcessActionChannelName (char* name, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal);
        virtual LxResult	ProcessActionChannelString (char* name, char* str);
        virtual LxResult	ProcessActionGradient (LxULong index, char *name, LxULong envelopeIndex, LxULong flags);

        virtual LxResult	ProcessAudio ();
        virtual LxResult	ProcessAudioItem (LxULong index);
        virtual LxResult	ProcessAudioSettings (LxUShort loop, LxUShort mute, LxUShort scrub, float start);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * validate and open the input & output files
 *
 *----------------------------------------------------------------------------*/
LxoDump::LxoDump (char* lxoName, char* outName, bool dumpAll) : LxoReader (lxoName)
{
    m_outFile = NULL;
    m_dumpGeom = dumpAll;

    if (! IsLxoValid ())
        return;

    m_isStdout = (NULL == outName || '\0' == *outName);
    if (m_isStdout)
        m_outFile = stdout;

    else if (NULL == (m_outFile = fopen (outName, "w"))) {
        printf ("Error writing output file <%s>\n", outName);
        return;
        }

    fprintf (m_outFile, "=========== Dump of %s ===========\n", lxoName);
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * close the open output file, unless it is stdout, in which case we must leave it
 * open for prints outside this class.
 *
 *----------------------------------------------------------------------------*/
LxoDump::~LxoDump ()
{
    if (m_outFile && !m_isStdout)
        fclose (m_outFile);         // only close *real* files (leave stdout open for prints)
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * override the virtual methods to process the chunk/header information.  Here we simply
 * print it out, but other applications could use this information for import.
 *
 *----------------------------------------------------------------------------*/
LxResult LxoDump::ProcessHeader ()
{
    fprintf (m_outFile, "\nChunk ID: %s  Size: %d\n", stringFromId (m_chunkId), m_chunkSize);

    return LXe_OK;
}

LxResult LxoDump::ProcessUnknown ()
{
    fprintf (stderr, "*** Unknown Chunk ID: %s  Size: %d\n", stringFromId (m_chunkId), m_chunkSize);

    return LXe_OK;
}

LxResult LxoDump::ProcessVersion (LxULong major, LxULong minor, char* str)
{
    fprintf (m_outFile, "\tMajor: %d  Minor: %d <%s>\n", major, minor, str);

    return LXe_OK;
}

LxResult LxoDump::ProcessDescription (char* type, char* desc)
{
    fprintf (m_outFile, "\tType/Description <%s> <%s>\n", type, desc);

    return LXe_OK;
}

LxResult LxoDump::ProcessParent (char* str)
{
    fprintf (m_outFile, "\tParent <%s>\n", str);

    return LXe_OK;
}

LxResult LxoDump::ProcessPreview (LxUShort width, LxUShort height, LxULong type, LxULong flags, LxULong dataBytes, LxByte* imageData)
{
    int     previewFormat = type &  LXiIMD_FLOAT;
    int     previewColors = type & ~LXiIMD_FLOAT;

    fprintf (m_outFile, "\tPreview size: %d x %d, type: %s %s (0x%x), flags: %s (0x%x), # Image bytes: %d\n", width, height,
                        LXiIMV_GREY == previewColors ? "Greyscale" : (LXiIMV_RGB == previewColors ? "RGB" : "RGBA"),
                        LXiIMD_FLOAT == previewFormat ? "Floats" : "Bytes", type,
                        flags ? "Compressed" : "Uncompressed", flags, dataBytes);

    return LXe_OK;
}

LxResult LxoDump::ProcessThumbnail (LxUShort width, LxUShort height, LxByte nChannels, LxByte flags, LxULong dataBytes, LxByte* imageData)
{
    fprintf (m_outFile, "\tThumbnail size: %d x %d, Channels: %d %s, flags: 0x%x, # Image bytes: %d\n", width, height, nChannels,
                        1 == nChannels ? "Greyscale" : (3 == nChannels ? "RGB" : (4 == nChannels ? "RGBA" : "Custom")),
                        flags, dataBytes);

    return LXe_OK;
}

LxResult LxoDump::ProcessBake (LxULong refId, LxULong samples, float startTime, float sampsPerSec)
{
    fprintf (m_outFile, "Reference ID: %d, #Samples: %d, Start Time %f, samples per second: %f\n", refId, samples, startTime, sampsPerSec);

    return LXe_OK;
}

LxResult LxoDump::ProcessChannelNames (LxULong count, LXtStringVec chans)
{
    fprintf (m_outFile, "#Channels: %d\n", count);

    for (LxULong i = 0; i < count; ++i)
        fprintf (m_outFile, "\tChannel %3d: <%s>\n", i, chans[i].c_str());

    return LXe_OK;
}

LxResult LxoDump::ProcessPolyTags (LXtID4 id, LxULong count, LXtPolyTag* ptags)
{
    fprintf (m_outFile, "ID: %s  Count: %d\n", stringFromId (id), count);

    for (LxULong i = 0; i < count; ++i)
        fprintf (m_outFile, "\tPoly Index: %d, Tag index %d <%s>\n", ptags[i].polyIndex, ptags[i].tagIndex,
                 ptags[i].tagIndex < m_tags.size() ? m_tags[ptags[i].tagIndex].c_str() : "***Undefined***");

    return LXe_OK;
}

LxResult LxoDump::ProcessTextTag (LXtID4 id, char* str)
{
    fprintf (m_outFile, "ID: %s  Tag: <%s>\n", stringFromId (id), str);

    return LXe_OK;
}
LxResult LxoDump::ProcessTags (LXtStringVec tags)
{
    int     tagNum = 0;

    for (LXtStringVec::iterator it = tags.begin(); it != tags.end(); it++)
        fprintf (m_outFile, "\tTags[%3d]: <%s>\n", tagNum++, it->c_str());

    return LXe_OK;
}

LxResult LxoDump::ProcessLayer (LXtLayerChunk& layer)
{
    fprintf (m_outFile, "Mesh: Reference ID: %d, Index %d, Flags 0x%x, Pivot (%f,%f,%f), Name: <%s> Parent %d\n",
                        layer.m_ref, layer.m_index, layer.m_flags, layer.m_pivot[0], layer.m_pivot[1], layer.m_pivot[2], layer.m_name, layer.m_parent);
    fprintf (m_outFile, "Spline Level %d, Subdivision Level %f, Curve Angle: %f, Scale Pivot (%f,%f,%f)\n",
                        layer.m_splinePatchLevel, layer.m_subdivisionLevel, layer.m_curveAngle, layer.m_scalePivot[0], layer.m_scalePivot[1], layer.m_scalePivot[2]);

    return LXe_OK;
}

LxResult LxoDump::ProcessSurfaceInfo (LXtSufaceInfo& surf)
{
    fprintf (m_outFile, "#Vertices: %d, #Triangles: %d, #Vectors: %d, #Tags: %d, Unused: %d\n", surf.nVerts, surf.nTris, surf.nVectors, surf.nTags, surf.unused);

    return LXe_OK;
}

LxResult LxoDump::ProcessGroupInfo (LXtGroupInfo& group)
{
    fprintf (m_outFile, "%s: Reference ID: %d, #Surfs: %d, Unused: %d\n", group.triSurfIndex & 0x80000000 ? "BakedTriGroup" : "StaticMesh",
                         group.triSurfIndex & 0x7fffffff, group.nSurfs, group.unused);

    return LXe_OK;
}

LxResult LxoDump::ProcessBoundingBox (LXtFVector min, LXtFVector max)
{
    fprintf (m_outFile, "\tMin: <%15.6f,%15.6f,%15.6f>\n", min[0], min[1], min[2]);
    fprintf (m_outFile, "\tMax: <%15.6f,%15.6f,%15.6f>\n", max[0], max[1], max[2]);

    return LXe_OK;
}

LxResult LxoDump::ProcessPoints (LxULong count, LXtFVector* points)
{
    fprintf (m_outFile, "#Points: %d\n", count);

    if (! m_dumpGeom)
        return LXe_OK;

    for (LxULong i = 0; i < count; ++i)
        fprintf (m_outFile, "\tPoint[%3d]: <%15.6f,%15.6f,%15.6f>\n", i, points[i][0], points[i][1], points[i][2]);

    return LXe_OK;
}

LxResult LxoDump::ProcessTriangles (LxULong count, LXtVertIndex* tris)
{
    fprintf (m_outFile, "#Triangles: %d\n", count);

    if (! m_dumpGeom)
        return LXe_OK;

    for (LxULong i = 0; i < count; ++i)
        fprintf (m_outFile, "\tTriangle[%3d]: [%3d,%3d,%3d]\n", i, tris[i].a, tris[i].b, tris[i].c);

    return LXe_OK;
}

LxResult LxoDump::ProcessPolygon (LXtID4 type, LxUShort nVerts, LxULong* verts)
{
    if (! m_dumpGeom)
        return LXe_OK;

    fprintf (m_outFile, "Poly Type: %s, #Vertices: %d  Flags: 0x%02x\n\t", stringFromId (type), nVerts & 0x3FF, nVerts >> 10);

    for (LxUShort i = 0; i < nVerts; ++i)
        fprintf (m_outFile, " %d", verts[i]);
    fprintf (m_outFile, "\n");

    return LXe_OK;
}

LxResult LxoDump::ProcessVectors (LXtID4 id, char* name, LxULong nVectors, LxULong nComponents, float* coords)
{
    fprintf (m_outFile, "ID: %s, Name: <%s>, #Vectors: %d (%d-D)\n", stringFromId (id), name, nVectors, nComponents);

    if (! m_dumpGeom)
        return LXe_OK;

    for (LxULong i = 0; i < nVectors; ++i)
        {
        fprintf (m_outFile, "\tVector[%3d]:", i);
        for (LxULong j = 0; j < nComponents; ++j)
            fprintf (m_outFile, " %15.6f", *coords++);
        fprintf (m_outFile, "\n");
        }

    return LXe_OK;
}

LxResult LxoDump::ProcessVertexMap (LXtID4 id, char* name, LxULong nMaps, LxULong nComponents)
{
    fprintf (m_outFile, "ID: %s, Name: <%s>, #Maps: %d, (%d-D)\n", stringFromId (id), name, nMaps, nComponents);

    return LXe_OK;
}

LxResult LxoDump::ProcessVertexMapFlags (LxULong flags[2])

{
    fprintf (m_outFile, "\tFlags: 0x%08x 0x%08x\n", flags[0], flags[1]);

    return LXe_OK;
}

LxResult LxoDump::ProcessVertexMapEntry (LxULong nComponents, LxULong vertIndex, float* values)
{
    if (! m_dumpGeom)
        return LXe_OK;

    fprintf (m_outFile, "\tVertex Index: %3d :: ", vertIndex);
    for (LxULong j = 0; j < nComponents; ++j)
        fprintf (m_outFile, " %15.6f", *values++);
    fprintf (m_outFile, "\n");

    return LXe_OK;
}

LxResult LxoDump::ProcessVertexDMapEntry (LxULong nComponents, LxULong vertIndex, LxULong polyIndex, float* values)
{
    if (! m_dumpGeom)
        return LXe_OK;

    fprintf (m_outFile, "\tVertex Index: %3d, PolyIndex: %3d :: ", vertIndex, polyIndex);
    for (LxULong j = 0; j < nComponents; ++j)
        fprintf (m_outFile, " %15.6f", *values++);
    fprintf (m_outFile, "\n");

    return LXe_OK;
}

LxResult LxoDump::ProcessEdgeMap (LXtID4 id, char* name, LxULong nMaps, LxULong nComponents)
{
    fprintf (m_outFile, "ID: %s, Name: <%s>, #Maps: %d, (%d-D)\n", stringFromId (id), name, nMaps, nComponents);

    return LXe_OK;
}

LxResult LxoDump::ProcessEdgeDMapEntry (LxULong nComponents, LxULong vertIndex1, LxULong vertIndex2, float* values)
{
    if (! m_dumpGeom)
        return LXe_OK;

    fprintf (m_outFile, "\tEdge from Vertex Index: %3d, to: %3d :: ", vertIndex1, vertIndex2);
    for (LxULong j = 0; j < nComponents; ++j)
        fprintf (m_outFile, " %15.6f", *values++);
    fprintf (m_outFile, "\n");

    return LXe_OK;
}

LxResult LxoDump::ProcessItem (char* itemType, char* name, LxULong refId)
{
    fprintf (m_outFile, "Type: <%s>, Name: <%s>, Reference ID: %d\n", itemType, name, refId);

    return LXe_OK;
}

void LxoDump::PrintSubHeader ()
{
    fprintf (m_outFile, "\tSubChunk ID: %s Size: %3d:\t", stringFromId (m_subChunkId), m_subChunkSize);
}

LxResult LxoDump::ProcessItemUnknown ()
{
    PrintSubHeader ();
    fprintf (m_outFile, "*** Unknown ***\n");
    fprintf (stderr, "*** Unknown Item Sub-Chunk ID: %s  Size: %d\n", stringFromId (m_subChunkId), m_subChunkSize);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemXref (LxULong index, char* filename, char* idStr)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Index: %3d, FileName: <%s>, Reference ID: <%s>\n", index, filename, idStr);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemLayer (LxULong index, LxULong flags, LxULong color)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Index: %3d, Flags: 0x%x, RGBA: 0x%08x\n", index, flags, color);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemId (char* name)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Name: <%s>\n", name);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemIndex (LxULong index)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Index: %3d\n", index);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemLink (char* name, LxULong refId, LxULong index)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Name: <%s>, Reference ID: %d, Index: %3d\n", name, refId, index);

    return LXe_OK;
}

LxResult LxoDump::ProcessChannelLink (char* name, char* fromChannel, LxULong index, char* toChannel, LxULong fromIndex, LxULong toIndex)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Name: <%s>, Item ID: %d, From Index: %3d to %3d, From Channel: <%s> to: <%s> \n",
             name, index, fromIndex, toIndex, fromChannel, toChannel);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemPackage (char* name, LxULong bytes, LxByte* buffer)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Name: <%s>, Size: %d\n", name, bytes);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemGradient (char* name, LxULong index, LxULong flags, char* inType, char* outType)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Name: <%s>, Index: %3d, Flags: %d", name, index, flags);

    if (inType)
        fprintf (m_outFile, ", inType: <%s>", inType);
    if (outType)
        fprintf (m_outFile, ", outType: <%s>", outType);

    fprintf (m_outFile, "\n");

    return LXe_OK;
}

LxResult LxoDump::ProcessItemTag (LXtID4 tagType, char* value)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Type: <%s>, Value: <%s>\n", stringFromId (tagType), value);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemPreview (LxUShort width, LxUShort height, LxULong type, LxULong flags, LxULong dataBytes, LxByte* imageData)
{
    int     previewFormat = type &  LXiIMD_FLOAT;
    int     previewColors = type & ~LXiIMD_FLOAT;

    PrintSubHeader ();
    fprintf (m_outFile, "Size: %d x %d, type: %s %s (0x%x), flags: %s (0x%x), # Image bytes: %d\n", width, height,
                        LXiIMV_GREY == previewColors ? "Greyscale" : (LXiIMV_RGB == previewColors ? "RGB" : "RGBA"),
                        LXiIMD_FLOAT == previewFormat ? "Floats" : "Bytes", type,
                        flags ? "Compressed" : "Uncompressed", flags, dataBytes);

    return LXe_OK;
}

void LxoDump::PrintValue (LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length)
{
    type = LXItemType_FloatAlt == type ? LXItemType_Float : type & 0xff;

    switch (type & ~LXItemType_UndefState)
        {
        case LXItemType_Int:
        case LXItemType_EnvelopeInt:
            fprintf (m_outFile, "Int: %d\n", intVal);
            break;

        case LXItemType_Float:
        case LXItemType_EnvelopeFloat:
        case LXItemType_FloatAlt:
            fprintf (m_outFile, "Float: %f\n", floatVal);
            break;

        case LXItemType_String:
        case LXItemType_EnvelopeString:
            fprintf (m_outFile, "String: <%s>\n", strVal);
            break;

        case LXItemType_Variable:
            fprintf (m_outFile, "VarLength: %d\n", length);
            break;
        }
}

LxResult LxoDump::ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Chan: <%-21s>, (%d) ", name, type);
    PrintValue (type, intVal, floatVal, strVal, buffer, length);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemChannelGeneral (LxULong index, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Chan[%3d]: <%-16s>", index, GetChannelName (index));

    if (type & LXItemType_Envelope)
        fprintf (m_outFile, ", EnvelopeIndex: %d", envelopeIndex);

    fprintf (m_outFile, " (0x%x) ", type);
    PrintValue (type, intVal, floatVal, strVal);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemChannelVector (char* name, LxUShort type, LxUShort count)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Chan: <%-21s>, Type: %d, #Elements: %d\n", name, type, count);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemChannelVectorValue (char* name, LxUShort type, int intVal, float floatVal, char* strVal)
{
    fprintf (m_outFile, "\t\t<%s> = ", name);
    PrintValue (type, intVal, floatVal, strVal);

    return LXe_OK;
}

LxResult LxoDump::ProcessItemChannelString (char* name, char* str)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Chan: <%-21s>, Value: <%s>\n", name, str);

    return LXe_OK;
}

LxResult LxoDump::ProcessCustomChannel (char* name, char* str, LxULong dataBytes, LxByte* customData)

{
    PrintSubHeader ();
    fprintf (m_outFile, "Chan: <%-21s>, Value: <%s>, bytes: %d\n", name, str, dataBytes);

    return LXe_OK;
}

LxResult LxoDump::ProcessUserChannel (char* name, char* str)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Chan: <%-21s>, Value: <%s>\n", name, str);

    return LXe_OK;
}

LxResult LxoDump::ProcessActionParent (LxULong index)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Index: %3d\n", index);

    return LXe_OK;
}

LxResult LxoDump::ProcessActionItem (LxULong index)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Index: %3d\n", index);

    return LXe_OK;
}

LxResult LxoDump::ProcessActionChannelGeneral (LxULong index, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal)
{
    return ProcessItemChannelGeneral (index, type, envelopeIndex, intVal, floatVal, strVal);
}

LxResult LxoDump::ProcessActionChannelName (char* name, LxUShort type, LxULong envelopeIndex, int intVal, float floatVal, char* strVal)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Chan: <%-21s>", name);

    if (type & LXItemType_Envelope)
        fprintf (m_outFile, ", EnvelopeIndex: %d", envelopeIndex);

    fprintf (m_outFile, " (0x%x) ", type);
    PrintValue (type, intVal, floatVal, strVal);

    return LXe_OK;
}

LxResult LxoDump::ProcessActionChannelString (char* name, char* str)
{
    return ProcessItemChannelString (name, str);
}

LxResult LxoDump::ProcessActionGradient (LxULong index, char *name, LxULong envelopeIndex, LxULong flags)
{
    PrintSubHeader ();
    if (0 == index)
        fprintf (m_outFile, "Chan: <%-21s>", name);
    else
        fprintf (m_outFile, "Chan[%3d]: <%-16s>", index, GetChannelName (index));

    fprintf (m_outFile, ", EnvelopeIndex: %d, Flags: 0x%x\n", envelopeIndex, flags);

    return LXe_OK;
}

LxResult LxoDump::ProcessActionUnknown ()
{
    PrintSubHeader ();
    fprintf (m_outFile, "*** Unknown ***\n");
    fprintf (stderr, "*** Unknown Action Sub-Chunk ID: %s  Size: %d\n", stringFromId (m_subChunkId), m_subChunkSize);

    return LXe_OK;
}

LxResult LxoDump::ProcessAudioItem (LxULong index)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Reference ID: %3d\n", index);

    return LXe_OK;
}

LxResult LxoDump::ProcessAudioSettings (LxUShort loop, LxUShort mute, LxUShort scrub, float start)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Loop: %3d Mute: %3d Scrub: %3d Start: %f\n", loop, mute, scrub, start);

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelope (LxULong index, LxULong type)
{
    fprintf (m_outFile, "\tEnvelope Index: %d, Type: %d (%s)\n", 
             index, type, LXEnvelopeType_Float == type ? "float" : "int");

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelopeUnknown ()
{
    PrintSubHeader ();
    fprintf (m_outFile, "*** Unknown ***\n");
    fprintf (stderr, "*** Unknown Envelope Sub-Chunk ID: %s  Size: %d\n", stringFromId (m_subChunkId), m_subChunkSize);

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelopeBehavior (LxUShort flag)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Flag: 0x%04x\n", flag);

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelopeTanIn (LxUShort slopeType, LxUShort weightType, float slope, float weight, float value)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Slope Type: %d (%s), Weight Type: %d, Slope: %f, Weight: %f, Value: %f\n", slopeType, slopeString (slopeType), weightType, slope, weight, value);

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelopeTanOut (LxULong breaks, LxUShort slopeType, LxUShort weightType, float slope, float weight, float value)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Break: %d (%s), Slope Type: %d (%s), Weight Type: %d, Slope: %f, Weight: %f, Value: %f\n", breaks, breakString (breaks), slopeType, slopeString (slopeType), weightType, slope, weight, value);

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelopeKey (float time, float value)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Time: %f, Value: %f\n", time, value);

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelopeKey (float time, LxULong value)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Time: %f, Value: %d\n", time, value);

    return LXe_OK;
}

LxResult LxoDump::ProcessEnvelopeFlag (LxULong flag)
{
    PrintSubHeader ();
    fprintf (m_outFile, "Flag: 0x%08x\n", flag);

    return LXe_OK;
}

LxResult LxoDump::ProcessAction (char* actionType, char* name, LxULong refId)
{
    fprintf (m_outFile, "Type: <%s>, Name: <%s>, Reference ID: %d\n", actionType, name, refId);

    return LXe_OK;
}

LxResult LxoDump::ProcessAudio ()
{
    fprintf (m_outFile, "Type: <audio>\n");

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * process command line args to specify the input LXO file, and optional output file.
 * Use the LxoDump class (subclassed from LxoReader) to read and print the entire file.
 *
 *----------------------------------------------------------------------------*/
int main (int argc, char* argv[])
{
    static char     usage[] = "Usage: %s [-v] lxoFileName [lxoDumpFileName]\n\t-v - verbose: dump all arrays of points, polys, etc.";
    bool            dumpAll = false;
    int             arg = 1;

    if (argc > 1 && '-' == argv[arg][0])
        {
        if ('v' != argv[arg][1] || '\0' != argv[arg][2])
            return printf (usage, argv[0]);

        dumpAll = true;

        ++arg;
        --argc;
        }

    if (argc < 2 || argc > 3)
        return printf (usage, argv[0]);

    LxResult    result = LxoDump (argv[arg], 3 == argc ? argv[arg+1] : NULL, dumpAll).ReadFile ();

    if (LXe_OK != result)
        fprintf (stderr, "\nError (0x%x) Reading LXO file <%s>\n", result, argv[arg]);
    else
        fprintf (stderr, "\nSuccessfully read <%s>\n", argv[arg]);
}

