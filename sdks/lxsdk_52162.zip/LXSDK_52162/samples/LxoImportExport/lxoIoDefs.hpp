/*
 * Copyright (c) 2009 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * ----------------------------------------------------------------
 * Class to read LXO files
 *
 */

#pragma once

#define _USE_MATH_DEFINES
#include <math.h>

#include <map>
#include <vector>
#include <string>

#include <lxcom.h>
#include <lxvector.h>
#include <lxresult.h>

#ifndef M_PI
#   define M_PI 3.1415926535897932385
#endif

float const      s_degreesToRads = (float)(M_PI / 180.0);
float const      s_radsToDegrees = (float)(180.0 / M_PI);

enum {              // Item Data Types
    LXItemType_Int              = 0x01,
    LXItemType_Float            = 0x02,
    LXItemType_String           = 0x03,
    LXItemType_Variable         = 0x04,
    LXItemType_Envelope         = 0x10,
    LXItemType_UndefState       = 0x20,     // undefined action channel

    LXItemType_EnvelopeInt      = LXItemType_Envelope | LXItemType_Int,
    LXItemType_EnvelopeFloat    = LXItemType_Envelope | LXItemType_Float,
    LXItemType_EnvelopeString   = LXItemType_Envelope | LXItemType_String,

    LXItemType_FloatAlt         = 0x4e56,   // compatibility with some apps

    LXEnvelopeType_Float        = 0,
    LXEnvelopeType_Int          = 1,
    };

typedef     unsigned int                LxULong;
typedef     unsigned short              LxUShort;
typedef     unsigned char               LxByte;
typedef     std::vector<std::string>    LXtStringVec;

enum {              // Flags for Layer Sub-Chunk
    LXLayerFlag_Visible         = 0x01,
    LXLayerFlag_Hidden          = 0x02,
    LXLayerFlag_ForeGround      = 0x04,
    LXLayerFlag_Background      = 0x08,
    LXLayerFlag_BoundingBox     = 0x10,
    LXLayerFlag_LinearUVs       = 0x80,

    LXLayerFlag_Default         = LXLayerFlag_Visible | LXLayerFlag_ForeGround,
    };

enum {              // Item Data Types & values
    LXInt_False                     = 0,
    LXInt_True                      = 1,

    LXMax_FileLength                = 512,

    LXCameraType_Perspective        = 0,
    LXCameraType_Orthographic,
    LXCameraType_Spherical,

    LXLightType_Spot                = 1,
    LXLightType_Point,
    LXLightType_Area,
    LXLightType_Directional,
    LXLightType_Sun,
    LXLightType_SunPhysical,
    LXLightType_Dome,
    LXLightType_Cylinder,

    LXEvironment_Sky                = 0,
    LXEvironment_Image,
    LXEvironment_Solid,
    LXEvironment_Gradient2,
    LXEvironment_Gradient4,

    LXSkyCover_Clear                = 0,
    LXSkyCover_Overcast,

    LXAAFilter_Box                  = 0,
    LXAAFilter_Triangle             = 1,
    LXAAFilter_Gaussian             = 2,

    LXIndirectType_None             = 0,
    LXIndirectType_MonteCarlo       = 1,
    LXIndirectType_IrradianceCache  = 2,

    LXIndirectCaustics_None         = 0,
    LXIndirectCaustics_Reflection   = 1,
    LXIndirectCaustics_Refraction   = 2,
    LXIndirectCaustics_Both         = 3,

    LXIrradianceGrads_None          = 0,
    LXIrradianceGrads_Rotation      = 1,
    LXIrradianceGrads_Translation   = 2,
    LXIrradianceGrads_Both          = 3,

    LXSubsurface_DirectOnly         = 0,
    LXSubsurface_GIAffectsSSS       = 1,
    LXSubsurface_SSSAffectsGI       = 2,
    LXSubsurface_Both               = 3,

    LXAlphaType_Opacity             = 0,
    LXAlphaType_OpacityConstant     = 1,

    LXOutput_Rgba                   = 0,
    LXOutput_AmbientOcclusion,
    LXOutput_Depth,
    LXOutput_Shadow,

    LXBlend_Normal                  = 0,
    LXBlend_Add,
    LXBlend_Colorburn,
    LXBlend_Colordodge,
    LXBlend_Darken,
    LXBlend_Difference,
    LXBlend_Divide,
    LXBlend_Hardlight,
    LXBlend_Lighten,
    LXBlend_Multiply,
    LXBlend_Normalmult,
    LXBlend_Overlay,
    LXBlend_Screen,
    LXBlend_Softlight,
    LXBlend_Subtract,

    LXMaterialLayer_DiffuseColor    = 0,
    LXMaterialLayer_DiffuseAmount,
    LXMaterialLayer_SpecularColor,
    LXMaterialLayer_SpeculcarAmount,
    LXMaterialLayer_ReflectColor,
    LXMaterialLayer_ReflectAmount,
    LXMaterialLayer_TransparentColor,
    LXMaterialLayer_TransparentAmount,
    LXMaterialLayer_Bump,
    LXMaterialLayer_Rough,
    LXMaterialLayer_SubscatterColor,
    LXMaterialLayer_SubscatterAmount,
    LXMaterialLayer_LuminousColor,
    LXMaterialLayer_LuminousAmount,
    LXMaterialLayer_Stencil,
    LXMaterialLayer_EnvColor,
    LXMaterialLayer_Displace,
    LXMaterialLayer_CoatAmount,
    LXMaterialLayer_AnisoDir,
    LXMaterialLayer_LayerMask,

    LXAlphaMode_Ignore              = 0,
    LXAlphaMode_Use,
    LXAlphaMode_Only,

    LXTexureTile_Repeat             = 0,
    LXTexureTile_Reset,
    LXTexureTile_Mirror,
    LXTexureTile_Edge,

    LXProjection_None               = 0,
    LXProjection_Uv,
    LXProjection_Spherical,
    LXProjection_Cylindrical,
    LXProjection_Cubic,
    LXProjection_Front,
    LXProjection_Planar,
    LXProjection_Lightprobe,

    LXFurType_Cylinders             = 0,
    LXFurType_Strips,

    LXFurGuide_None                 = 0,
    LXFurGuide_Dirlength,
    LXFurGuide_Shape,
    LXFurGuide_Range,
    LXFurGuide_Direction,
    LXFurGuide_Clump,
    };

typedef     std::map<std::string, int>  LXtMap_StringIds;

/*
 * Definition of layer data.
 */
struct LXtLayerChunk {
                LxUShort    m_index;
                LxUShort    m_flags;
                float       m_pivot[3];
                char        m_name[256];
                LxUShort    m_parent;
                float       m_subdivisionLevel;
                float       m_curveAngle;
                float       m_scalePivot[3];
                LxULong     m_unused[6];
                LxULong     m_ref;
                LxUShort    m_splinePatchLevel;
                LxUShort    m_future[3];

                LXtLayerChunk () { memset (this, 0, sizeof *this); }
                LXtLayerChunk (LxULong index, LxULong itemRef);
                };

/*
 * Definition for any type of light source.  Not al fields used for all types.
 */
struct LXtLightInfo {
                struct 
                    {
                    unsigned    visible:1;      // is area light geomtry visible?
                    unsigned    castShadows:1;  // can the light cast shadows
                    unsigned    volumetric:1;   // true to enable volumetric effects

                    unsigned    usePosition:1;  // true if the light position is defined
                    unsigned    useDirection:1; // true if the light direction is defined

                    }           flags;

                int             type;
                char            name[256];

                LXtFVector      color;          // color of light
                LXtFVector      position;       // position of light
                LXtFVector      rotation;       // rotation angles from <0,0,1>

                float           lumens;         // not used for Physical Sun

        // used for point, spot & direct lights only (including sun):
                LXpSampleDensity volumeDensity; // volumetric parameters for direct/spot/point lights
                LXpSampleVolume volume;         // volumetric parameters for direct/spot/point lights
                int             volumeSamples;  // number of samples to take for volumetric effects
                float           volumeRadius;   // size of volume for direct & point lights
                float           volumeBase;     // distance from light to start spot light volume
                float           volumeHeight;   // height of volume from spot base or sun position

        // used for spot lights only:
                float           coneAngle;      // angle of entire light cone
                float           edgeAngle;      // anlge of cone falloff

        // used for area lights only:
                float           areaWidth;      // dimensions of area light
                float           areaHeight;

        // used for cylinder lights only:
                float           length;         // length of cylinder

        // used for sunlight only:
                float           longitude;      // in radians
                float           latitude;       // in radians
                float           timeHours;      // time of day in hours since midnight
                LxUShort        dayOfYear;      // number of days of since the begining of the year
                LxUShort        year;
                float           timeZone;       // number of timezones from GMT
                float           north;          // radians between the north vector and the X axis
                float           haze;           // degree of solar haze
                float           cloudiness;     // degree of cloudiness (clear = 0, overcast = 1)

        // used for all lights:
                int             samples;        // number of shadow samples
                float           radius;         // size of bulb/light for all but area lights
                float           iesRotation;    // rotation angle about the light's direction vector
                char            iesFile[LXMax_FileLength];
                };

/*
 * Definition for a standard camera
 */
struct LXtCamera {
                int             projectMode;        // type of projection; LXCameraType_*

                LXtFVector      position;           // position of the camera
                LXtFVector      rotation;           // rotation angles from <0,0,1>
                float           focalDistance;      // distance to target (focal point)

                float           focalLength;        // in meters -- standard lens is 50 mm
                float           filmWidth;          // size of file plane
                float           filmHeight;

                LXtFVector2     offset;		    // film shift when camera aspect doesn't match view
                float           fstop;              // lens apperture (for depth of field)
                float           lensDistortion;     // positive for barrel distortion; negative for pincushion
                };

/*
 * Definition (with initializer) for map layer of a material
 */
struct LXtMaterialLayer {
                LxULong             m_type;         // type of map (diffuse, specular, ...)
                char                m_file[LXMax_FileLength];    // path to image file for map, if any
                LxULong             m_videoStillId; // id for the image file for this layer
                LXtFVector          m_color;        // layer color (if not image file)

                int                 m_blendType;    // how the layer is blended (LXBlend_*)
                int                 m_alphaType;    // how alpha is used (LXAlphaMode_*)
                int                 m_projectMode;  // type of projection (LXProjection_*)
                int                 m_tileModeU;    // how the image is tiled in U (LXTexureTile_*)
                int                 m_tileModeV;    // how the image is tiled in V� (LXTexureTile_*)

                bool                m_invert;       // true if the image colors should be inverted
                bool                m_invertRGB;    // true for amount maps, when RGB needs inversion

                float               m_opacity;      // ��opacity of the layer
                float               m_minValue;     // map black to this amount
                float               m_maxValue;     // map white to this amount

                void    Init (LxULong type, int projectMode = LXProjection_Uv, int tileModeU = LXTexureTile_Repeat, int tileModeV = LXTexureTile_Repeat);

                LXtMaterialLayer (LxULong type, char const* file, int projectMode = LXProjection_Uv, int tileModeU = LXTexureTile_Repeat, int tileModeV = LXTexureTile_Repeat);
                LXtMaterialLayer (LxULong type, LXtFVector color);
                };

typedef     std::vector<LXtMaterialLayer>   LXtLayerVec;

/*
 * Definition (with initializer) for material attributes.  As a general rule, "metallic" materials
 * (anthing that is transparent or reflective) would typically have the same color for all channels.
 * For "plastic" materials, specular would be white and all other channels would be 0.
 */
struct LXtMaterial {
                LxULong             m_uvMapCount;
                char                m_name[256];
                char                m_presetFile[LXMax_FileLength];

                LXpSampleParms      m_param;            // colors and amounts for material components
                LXpShadeFlags       m_shadeFlags;
                LXpDisplace         m_displacement;     // values for displacement mapping
                LXpSampleSurfSmooth m_smoothing;
                LXpFurParms         m_fur;

                LXtLayerVec         m_layers;           // can only memset members ABOVE this

                LXtMaterial () {}
                LXtMaterial (const char* name, LxULong colorRGBA);
                LXtMaterial (const char* name, float r = 1.0f, float g = 1.0f, float b = 1.0f)  { Init (name, r, g, b); }
                LXtMaterial (const char* name, const char* file)  { Init (name, file); }

                void                Init (const char* name, float r = 1.0f, float g = 1.0f, float b = 1.0f);
                void                Init (const char* name, char const* file);
                };

typedef     std::map<std::string, LXtMaterial>      LXtMap_Materials;

/*
 * Definition for the components of a static mesh
 */
struct LXtStaticMesh {
                LXtFVector*     points;         // array of vertex coordinates for the mesh
                LXtFVector*     normals;        // optional array of vertex normals
                LXtFVector2*    uvs;            // optional array of texture coordinates
                LxULong         nVerts;         // number of coordinates in the arrays (all must be same length or NULL)

                LXtUVector*     indices;        // array of triangle vertex indices
                LxULong         nTris;          // number of triangles

                LXtMaterial*    material;       // material to be applied to this mesh

                LxULong         layerId;        // currently unused, should be set to 0
                LxULong         parentId;
                LxULong         parentIndex;
                };

/*
 * structure definition (with initializer) for rendering & output settings
 */
struct LXtEnvironment {
                struct 
                    {
                    unsigned    mode:3;                     // type of environment (LXEvironment_*)

                    unsigned    visibleToCamera:1;
                    unsigned    visibleToIndirect:1;
                    unsigned    visibleToReflect:1;
                    unsigned    visibleToRefract:1;

                    }           m_flags;

                float               m_radiance;		    // brightness of the environment
                LXtFVector          m_color;                // solid environment color

                LXtFVector          m_zenithColor;          // Top color of 2/4 color gradient
                LXtFVector          m_nadirColor;           // Bottom color of 2/4 color gradient
                LXtFVector          m_skyColor;             // Upper-middle color of 4 color gradient
                LXtFVector          m_groundColor;          // Lower-middle color of 4 color gradient
                float               m_skyExponent;          // degree of falloff to sky color
                float               m_groundExponent;       // degree of falloff to ground color

                LXtMaterialLayer*   m_imageLayer;           // definition for env image
                };
/*
 * structure definition (with initializer) for rendering & output settings
 */
struct LXtRenderSettings {
                struct 
                    {
                    unsigned    rawOutput:1;
                    unsigned    directCaustics:1;
                    unsigned    shadows:1;
                    unsigned    indirectIllumination:1;
                    unsigned    irradianceCaching:1;
                    unsigned    indirectSuperSampling:1;
                    unsigned    microPolyDisplacement:1;
                    unsigned    smoothPositions:1;
                    unsigned    reflections:1;
                    unsigned    transparency:1;
                    unsigned    bloom:1;
                    }           m_flags;

                LXpShadeFlags       m_shadeFlags;
                LXtEnvironment      m_environment;

                LXtFVector          m_ambColor;               // ambient color
                float               m_ambLumens;              // ambient intensity (in lumens)
                LXtUVector2         m_resolution;             // output resolution
                int                 m_bucketSize;
                int                 m_outputMode;

                int                 m_degreeOfField;
                int                 m_reflectDepth;           // maximum # of reflections
                int                 m_refractDepth;           // maximum # of refractions

                int                 m_indirectRays;
                int                 m_indirectBounces;
                int                 m_irradianceRays;
                int                 m_interpolationValues;

                int                 m_irradianceGradients;
                int                 m_antialiasingFilter;
                int                 m_antialiasPowerOf2;
                int                 m_indirectCaustics;
                int                 m_subsurfaceScattering;

                int                 m_totalPhotons;
                int                 m_localPhotons;

                float               m_outputGamma;
                float               m_rayThreshold;           // tolerance from 0-1
                float               m_refinementShadingRate;
                float               m_refinementThreshold;    // tolerance from 0-1
                float               m_displacementRate;
                float               m_displacementRatio;
                float               m_minimumEdgeLength;      // in millimeters
                float               m_indirectRange;
                float               m_irradianceRate;
                float               m_irradianceRatio;
                float               m_bloomThreshold;
                float               m_bloomRadius;
                float               m_maxDepth;               // max distance from camera (for all except depth rendering)

                int                 m_occlusionRays;
                float               m_occlusionRange;

                void                Init ();
                };

