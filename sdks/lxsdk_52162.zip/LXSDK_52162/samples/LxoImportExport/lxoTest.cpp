/*
 * Copyright (c) 2009 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include <direct.h>
#include "lxoWriter.hpp"
#include "lxoCommand.hpp"

// the following can be set to 1 to test more capabilities; I set to 0 for faster testing
#define TEST_ALL_LIGHTS             0
#define TEST_FUR                    0
#define TEST_USING_ANTIALIASING     0

/*
 * This is an array of all the Luxology channels & sub-channels used by the application.
 * The constants are defined in lxidef.h.
 */
static char const *     s_channelNames[] = 
    {
    LXsICHAN_RENDER_AMBCOLOR,
    LXsICHAN_RENDER_AMBRAD,
    LXsICHAN_RENDER_RAYTHRESH,
    LXsICHAN_RENDER_RAYSHADOW,
    LXsICHAN_RENDER_REFLDEPTH,
    LXsICHAN_RENDER_REFRDEPTH,
    LXsICHAN_RENDER_GLOBRAYS,
    LXsICHAN_RENDER_GLOBLIMIT,
    LXsICHAN_RENDER_GLOBENABLE,
    LXsICHAN_RENDER_GLOBSUPER,
    LXsICHAN_RENDER_GLOBRANGE,
    LXsICHAN_RENDER_IRRRAYS,
    LXsICHAN_RENDER_IRRVALS,
    LXsICHAN_RENDER_IRRCACHE,
    LXsICHAN_RENDER_IRRRATE,
    LXsICHAN_RENDER_IRRRATIO,
    LXsICHAN_RENDER_IRRGRADS,
    LXsICHAN_RENDER_GLOBCAUS,
    LXsICHAN_RENDER_GLOBSUBS,

    LXsICHAN_RENDER_DISPENABLE,
    LXsICHAN_RENDER_DISPRATE,
    LXsICHAN_RENDER_DISPRATIO,
    LXsICHAN_RENDER_EDGEMIN,
    LXsICHAN_RENDER_DISPSMOOTH,
    LXsICHAN_RENDER_CAUSENABLE,
    LXsICHAN_RENDER_CAUSTOTAL,
    LXsICHAN_RENDER_CAUSLOCAL,

    LXsICHAN_POLYRENDER_AA,
    LXsICHAN_POLYRENDER_AAFILTER,
    LXsICHAN_POLYRENDER_RESX,
    LXsICHAN_POLYRENDER_RESY,
    LXsICHAN_POLYRENDER_DOF,
    LXsICHAN_POLYRENDER_FINERATE,
    LXsICHAN_POLYRENDER_FINETHRESH,
    LXsICHAN_POLYRENDER_BUCKETX,
    LXsICHAN_POLYRENDER_BUCKETY,

    LXsICHAN_RENDEROUTPUT_BLOOM,
    LXsICHAN_RENDEROUTPUT_BLOOMRAD,
    LXsICHAN_RENDEROUTPUT_BLOOMTHR,
    LXsICHAN_RENDEROUTPUT_CLAMP,
    LXsICHAN_RENDEROUTPUT_DEPTHMAX,
    LXsICHAN_RENDEROUTPUT_FILENAME,
    LXsICHAN_RENDEROUTPUT_FORMAT,
    LXsICHAN_RENDEROUTPUT_GAMMA,
    LXsICHAN_RENDEROUTPUT_OCCLRANGE,
    LXsICHAN_RENDEROUTPUT_OCCLRAYS,
    LXsICHAN_RENDEROUTPUT_TONEAMT,
    LXsICHAN_RENDEROUTPUT_WHITE,

    LXsICHAN_SCENE_TIME,
    LXsICHAN_SCENE_SCENES,
    LXsICHAN_SCENE_SCENEE,
    LXsICHAN_SCENE_CURRENTS,
    LXsICHAN_SCENE_CURRENTE,
    LXsICHAN_SCENE_TIMESYS,
    LXsICHAN_SCENE_FPS,
    LXsICHAN_SCENE_DRAWSIZE,

    LXsICHAN_CAMERA_PROJTYPE,
    LXsICHAN_CAMERA_FOCALLEN,
    LXsICHAN_CAMERA_FOCUSDIST,
    LXsICHAN_CAMERA_OFFSETX,
    LXsICHAN_CAMERA_OFFSETY,
    LXsICHAN_CAMERA_FSTOP,
    LXsICHAN_CAMERA_APERTUREX,
    LXsICHAN_CAMERA_APERTUREY,
    LXsICHAN_CAMERA_DISTORT,

    LXsICHAN_TEXTURELAYER_ENABLE,
    LXsICHAN_TEXTURELAYER_OPACITY,
    LXsICHAN_TEXTURELAYER_BLEND,
    LXsICHAN_TEXTURELAYER_INVERT,
    LXsICHAN_TEXTURELAYER_EFFECT,

    LXsICHAN_TEXTURELOC_PROJTYPE,
    LXsICHAN_TEXTURELOC_TILEU,
    LXsICHAN_TEXTURELOC_TILEV,

    LXsICHAN_IMAGEMAP_MIN,
    LXsICHAN_IMAGEMAP_MAX,
    LXsICHAN_IMAGEMAP_ALPHA,
    LXsICHAN_IMAGEMAP_REDINV,
    LXsICHAN_IMAGEMAP_GREENINV,
    LXsICHAN_IMAGEMAP_BLUEINV,

    LXsICHAN_DEFAULTSHADER_FOGCOLOR,
    LXsICHAN_DEFAULTSHADER_SHADERATE,
    LXsICHAN_DEFAULTSHADER_DIRMULT,
    LXsICHAN_DEFAULTSHADER_INDMULT,
    LXsICHAN_DEFAULTSHADER_INDSAT,
    LXsICHAN_DEFAULTSHADER_INDTYPE,
    LXsICHAN_DEFAULTSHADER_SHADCAST,
    LXsICHAN_DEFAULTSHADER_SHADRECV,
    LXsICHAN_DEFAULTSHADER_VISIND,
    LXsICHAN_DEFAULTSHADER_VISCAM,
    LXsICHAN_DEFAULTSHADER_VISREFL,
    LXsICHAN_DEFAULTSHADER_VISREFR,

    LXsICHAN_ADVANCEDMATERIAL_DBLSIDED,
    LXsICHAN_ADVANCEDMATERIAL_PHYSICAL,
    LXsICHAN_ADVANCEDMATERIAL_DIFFAMT,
    LXsICHAN_ADVANCEDMATERIAL_DIFFCOL,
    LXsICHAN_ADVANCEDMATERIAL_BUMP,
    LXsICHAN_ADVANCEDMATERIAL_SPECAMT,
    LXsICHAN_ADVANCEDMATERIAL_SPECFRES,
    LXsICHAN_ADVANCEDMATERIAL_ROUGH,
    LXsICHAN_ADVANCEDMATERIAL_SPECCOL,
    LXsICHAN_ADVANCEDMATERIAL_REFLAMT,
    LXsICHAN_ADVANCEDMATERIAL_REFLFRES,
    LXsICHAN_ADVANCEDMATERIAL_REFLRAYS,
    LXsICHAN_ADVANCEDMATERIAL_COATAMT,
    LXsICHAN_ADVANCEDMATERIAL_REFLTYPE,
    LXsICHAN_ADVANCEDMATERIAL_REFLCOL,
    LXsICHAN_ADVANCEDMATERIAL_REFLBLUR,
    LXsICHAN_ADVANCEDMATERIAL_TRANAMT,
    LXsICHAN_ADVANCEDMATERIAL_REFINDEX,
    LXsICHAN_ADVANCEDMATERIAL_TRANCOL,
    LXsICHAN_ADVANCEDMATERIAL_SUBSAMT,
    LXsICHAN_ADVANCEDMATERIAL_SUBSDIST,
    LXsICHAN_ADVANCEDMATERIAL_DISPERSE,
    LXsICHAN_ADVANCEDMATERIAL_SUBSCOL,
    LXsICHAN_ADVANCEDMATERIAL_SAMESURF,
    LXsICHAN_ADVANCEDMATERIAL_RADIANCE,
    LXsICHAN_ADVANCEDMATERIAL_LUMICOL,
    LXsICHAN_ADVANCEDMATERIAL_EXITCOL,
    LXsICHAN_ADVANCEDMATERIAL_ANISO,
    LXsICHAN_ADVANCEDMATERIAL_TRANRAYS,
    LXsICHAN_ADVANCEDMATERIAL_TRANROUGH,
    LXsICHAN_ADVANCEDMATERIAL_TRANDIST,
    LXsICHAN_ADVANCEDMATERIAL_SUBSSMPS,
    LXsICHAN_ADVANCEDMATERIAL_SUBSPHASE,
    LXsICHAN_ADVANCEDMATERIAL_DISPLACE,

    LXsICHAN_FURMATERIAL_DIST,
    LXsICHAN_FURMATERIAL_LENGTH,
    LXsICHAN_FURMATERIAL_WIDTH,
    LXsICHAN_FURMATERIAL_FLEX,
    LXsICHAN_FURMATERIAL_GROWTHJITTER,
    LXsICHAN_FURMATERIAL_POSJITTER,
    LXsICHAN_FURMATERIAL_SCLJITTER,
    LXsICHAN_FURMATERIAL_NRMJITTER,
    LXsICHAN_FURMATERIAL_MAXSEGMENT,
    LXsICHAN_FURMATERIAL_BUMPAMP,
    LXsICHAN_FURMATERIAL_DENSITY,
    LXsICHAN_FURMATERIAL_DISPLAY,
    LXsICHAN_FURMATERIAL_CURLS,
    LXsICHAN_FURMATERIAL_CLUMPS,
    LXsICHAN_FURMATERIAL_CLUMPSIZE,
    LXsICHAN_FURMATERIAL_TAPER,
    LXsICHAN_FURMATERIAL_TYPE,
    LXsICHAN_FURMATERIAL_ADAPTIVE,
    LXsICHAN_FURMATERIAL_FURONLY,
    LXsICHAN_FURMATERIAL_GUIDES,
    LXsICHAN_FURMATERIAL_TANSHADE,
    LXsICHAN_FURMATERIAL_GUIDERANGE,
    LXsICHAN_FURMATERIAL_GUIDELENGTH,
    LXsICHAN_FURMATERIAL_ROOTBEND,
    LXsICHAN_FURMATERIAL_STRIPROT,
    LXsICHAN_FURMATERIAL_YOFFSET,
    LXsICHAN_FURMATERIAL_RATE,
    LXsICHAN_FURMATERIAL_ANGLE,
    LXsICHAN_FURMATERIAL_GUIDEBLEND,
    LXsICHAN_FURMATERIAL_SEED,
    LXsICHAN_FURMATERIAL_AUTOFADE,

    LXsICHAN_ENVMATERIAL_SKYEXP,
    LXsICHAN_ENVMATERIAL_GNDEXP,

    LXsICHAN_LOCATOR_RENDER,
    LXsICHAN_LOCATOR_VISIBLE,
    LXsICHAN_LOCATOR_DISSOLVE,

    LXsICHAN_MESH_RENDER_CURVES,

    LXsICHAN_TRANSFORM_BLEND,
    LXsICHAN_TRANSFORM_TYPE,
    LXsICHAN_TRANSLATION_POS,

    LXsICHAN_ROTATION_ORDER,
    LXsICHAN_ROTATION_ROT,

    LXsICHAN_LIGHT_RADIANCE,
    LXsICHAN_LIGHT_FAST,
    LXsICHAN_LIGHT_SAMPLES,
    LXsICHAN_LIGHT_SHADTYPE,

    LXsICHAN_SPOTLIGHT_CONE,
    LXsICHAN_SPOTLIGHT_EDGE,
    LXsICHAN_SPOTLIGHT_BASE  ,
    LXsICHAN_SPOTLIGHT_HEIGHT,
    LXsICHAN_SPOTLIGHT_RADIUS,

    LXsICHAN_POINTLIGHT_VOLUMETRICS,
    LXsICHAN_POINTLIGHT_VSAMPLES,
    LXsICHAN_POINTLIGHT_VRAD,

    LXsICHAN_AREALIGHT_WIDTH,
    LXsICHAN_AREALIGHT_HEIGHT,

    LXsICHAN_PHOTOMETRYLIGHT_FILENAME,

    LXsICHAN_SUNLIGHT_AZIMUTH,
    LXsICHAN_SUNLIGHT_CLAMP,
    LXsICHAN_SUNLIGHT_DAY,
    LXsICHAN_SUNLIGHT_HAZE,
    LXsICHAN_SUNLIGHT_LAT,
    LXsICHAN_SUNLIGHT_LON,
    LXsICHAN_SUNLIGHT_NORTH,
    LXsICHAN_SUNLIGHT_SPREAD,
    LXsICHAN_SUNLIGHT_SUNPOS,
    LXsICHAN_SUNLIGHT_TIME,
    LXsICHAN_SUNLIGHT_TIMEZONE,

    LXsICHAN_LIGHTMATERIAL_SCATTER,
    LXsICHAN_LIGHTMATERIAL_SCATCOL,
    LXsICHAN_LIGHTMATERIAL_DENSITY,
    LXsICHAN_LIGHTMATERIAL_ATTENUATE,
    LXsICHAN_LIGHTMATERIAL_SHIFT,

    LXsICHAN_ENVMATERIAL_NORMALIZE,
    LXsICHAN_ENVMATERIAL_DISC,
    };

enum 
    {
    CURVE_COLOR_1   = 0xAA1122FF,       // RGBA
    CURVE_COLOR_2   = 0x8888117f,       // RGBA - 50% transparent
    };

static LXtCamera    defaultCamera = { LXCameraType_Perspective,   // projection
                                      { 25.f,  9.f, 25.f },       // position
                                      { -5.f * s_degreesToRads,   // rotation (in degrees)
                                        45.f * s_degreesToRads,
                                         5.f * s_degreesToRads},
                                      10.f,                       // focalDistance

                                      0.050f,                     // focalLength - 50 mm
                                      0.036f,                     // filmWidth - 36mm
                                      0.036f,                     // filmHeight - assume square aspect

                                      { 0.f, 0.f },               // offset
                                      4.f,                        // fstop
                                      0.f,                        // lensDistortion
                                    };

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * process command line args to specify the output LXO file, and optional output file.
 * Use the LxoWriter class to write an LXO file.
 *
 *----------------------------------------------------------------------------*/
LxResult WriteLxo (char const* lxoFilename)
{
    LxResult    result;
    LxoWriter   writer (lxoFilename, s_channelNames, sizeof s_channelNames / sizeof s_channelNames[0]);

    if (! writer.IsLxoValid ())
        return LXe_NOACCESS;

    /*
     * List all materials used for curves & lines.  These can be in the form of explicitly defined
     * materials, which are listed by name, or simple materials defined by color only.
     *
     * These need to be added BEFORE the call to WriteFileHeader() as they are written into the header.
     */
    writer.AddMaterialTag ("CyanMaterial");
    writer.AddMaterialTag ("GreenMaterial");
    writer.AddMaterialTag (CURVE_COLOR_1);
    writer.AddMaterialTag (CURVE_COLOR_2);

    /*
     * Write the data required at the begining of the LXO file
     */
    if (LXe_OK != (result = writer.WriteFileHeader ("LXO Export Test Application")))
        return result;

    /*
     * This is where you would create and export all of your geometry. For this
     * test application, we just create and export a view types in memory.
     *
     * Note: all positions/distances are in meters.
     */

    LXtFVector      points1[] = {   { 10.f, 10.f, -5.f }, {  0.f, 10.f,  0.f },     // Poly in Z plane
                                    {  0.f,  0.f,  0.f }, { 10.f,  0.f, -5.f },
                                };

    LXtFVector      normals1[] = {  {  0.f,  0.f,  1.f }, {  0.f,  0.f,  1.f },
                                    {  0.f,  0.f,  1.f }, {  0.f,  0.f,  1.f },
                                };

    LXtFVector      points2[] = {   {  0.f, 10.f,  0.f }, {  0.f, 10.f, 10.f },     // Poly in X plane
                                    {  0.f,  0.f, 10.f }, {  0.f,  0.f,  0.f },
                                };

    LXtFVector      normals2[] = {  {  1.f,  0.f,  0.f }, {  1.f,  0.f,  0.f },
                                    {  1.f,  0.f,  0.f }, {  1.f,  0.f,  0.f },
                                };

    LXtFVector      points3[] = {   {  0.f,  0.f,  0.f }, {  0.f,  0.f, 10.f },   // Poly in Y plane
                                    { 10.f,  0.f, 10.f }, { 10.f,  0.f,  0.f },
                                };

    LXtFVector      normals3[] = {  {  0.f,  1.f,  0.f }, {  0.f,  1.f,  0.f },
                                    {  0.f,  1.f,  0.f }, {  0.f,  1.f,  0.f },
                                };

    LXtFVector2     uvs1[]      = { { 0.3f, 0.3f }, { 0.0f, 0.3f },
                                    { 0.0f, 0.0f }, { 0.3f, 0.0f },
                                };

    LXtFVector2     uvs2[]      = { { 1.0f, 1.0f }, { 0.5f, 1.0f },
                                    { 0.5f, 0.5f }, { 1.0f, 0.5f },
                                };

    LXtUVector      tris[]      = { { 0, 1, 2 }, { 0, 2, 3 }, };    // must be CCW

    LXtMaterial         matYellow           ("YellowMaterial",   1.f, 1.f, 0.f);
    LXtMaterial         matRed              ("RedMaterial",      1.f, 0.f, 0.f);
    LXtMaterial         matGreen            ("GreenMaterial",    0.f, 1.f, 0.f);
    LXtMaterial         matCyan             ("CyanMaterial",     0.f, 1.f, 1.f);
    LXtMaterial         matPresetConcrete   ("ConcreteMaterial", "Concrete-09.lxp");
    LXtMaterial         matPresetBronze     ("BronzeMaterial",   "lwDentedBronze.lxp");
    LXtMaterial         matPresetMarble     ("MarbleMaterial",   "lwMarble-Black.lxp");
    LXtMaterial         matPresetFur        ("FurMaterial",      "Cat Fur 01.lxp");

    LXtFVector          green = { 0.f, 1.f, 0.f };

    LXtMaterialLayer    diffuseColorRough    (LXMaterialLayer_DiffuseColor,  "stone.jpg",  LXProjection_Uv);
    LXtMaterialLayer    diffuseAmountKnurl   (LXMaterialLayer_DiffuseAmount, "knurl.tif",  LXProjection_Uv, LXTexureTile_Mirror);
    LXtMaterialLayer    specularColorMarble  (LXMaterialLayer_SpecularColor, "marble.jpg", LXProjection_Uv, LXTexureTile_Reset);
    LXtMaterialLayer    reflectionColorGreen (LXMaterialLayer_ReflectColor,  green);

    matYellow.m_layers.push_back (diffuseAmountKnurl);
    matYellow.m_layers.push_back (diffuseColorRough);
    matYellow.m_layers.push_back (reflectionColorGreen);

#if TEST_FUR
    matYellow.m_fur.enable  = true;
    matYellow.m_fur.minDist = 0.4f;     // spacing in m
    matYellow.m_fur.length  = 2.f;      // length in m
    matYellow.m_fur.guides  = LXFurGuide_Direction;
#endif

    matCyan.m_layers.push_back (specularColorMarble);

    matRed.m_param.reflAmt = 0.2f;

    LXtStaticMesh   mesh = {
                            points1, normals1, uvs1,    // arrays of coordinates, optional normals & optional texture coordinates
                            4,                          // number of entries in all of these arrays

                            tris, 2,                    // array of triangle vertex indices and number of triangles
                            &matYellow,                 // material for this mesh

                            0, 0, 0,                    // layer & parent ids; parent index
                            };

    if (LXe_OK != (result = writer.WriteStaticMesh (mesh)))
        return result;

    LxULong         wallId = writer.GetLastItemId ();   // save ID so we can replicate this item


    mesh.points         = points2;                      // switch to alternate points for other wall
    mesh.normals        = normals2;
    mesh.uvs            = uvs2;

    if (LXe_OK != (result = writer.WriteStaticMesh (mesh)))
        return result;

    mesh.points         = points3;
    mesh.normals        = normals3;
    mesh.material       = &matPresetMarble;

    if (LXe_OK != (result = writer.WriteStaticMesh (mesh)))
        return result;

    LxULong         floorId = writer.GetLastItemId ();  // save ID so we can replicate this item

    if (LXe_OK != (result = writer.WriteLineString (points1, 4, 0.25f, CURVE_COLOR_2)))
        return result;

    if (LXe_OK != (result = writer.WriteLineString (points2, 4, 0.15f, matGreen)))
        return result;

    if (LXe_OK != (result = writer.WriteCurve (points1, 4, 0.35f, CURVE_COLOR_1)))
        return result;

    LxULong         curveId = writer.GetLastItemId ();  // save ID so we can replicate this item

    if (LXe_OK != (result = writer.WriteCurve (points2, 4, 0.45f, matCyan)))
        return result;


    LXtFVector      pos[]    = { { 9.f, 2.f, 9.f }, { 7.f, 6.f, 3.f } };    //  positions of replicated items, transform is applied first
    LXtFMatrix      xforms[] = {
                                { { 0.0f, 0.4f, 0.0f }, { 0.4f, 0.0f, 0.0f }, { 0.0f, 0.0f, 0.4f } },
                                { { 0.2f, 0.0f, 0.0f }, { 0.0f, 0.0f, 0.2f }, { 0.0f, 0.2f, 0.0f } },
                             };    //  transforms of replicated items

    /*
     * replicate some of the above items.  This can be done any time after an item is written
     */

    if (LXe_OK != (result = writer.WriteReplicator (curveId, 1, pos, xforms)))
        return result;

    if (LXe_OK != (result = writer.WriteReplicator (wallId,  2, pos, xforms)))      // replicate TWO copies of this wall
        return result;

    if (LXe_OK != (result = writer.WriteReplicator (floorId, 1, pos, xforms)))
        return result;

    if (LXe_OK != (result = writer.WriteReplicator (floorId, 1, pos+1, xforms+1)))
        return result;

    /*
     * After processing all the geometry, write out the lighting (including lights using some
     * of the geometry).
     */
    LXtLightInfo    light;

    strcpy    (light.name,       "Sunlight");
    LXx_V3SET (light.color,      1.0f, 1.0f, 0.5f);
    LXx_V3SET (light.position,   10.f, 20.f, 30.f);
    LXx_V3SET (light.rotation,   135.f * s_degreesToRads, 150.f * s_degreesToRads, 180.f * s_degreesToRads);

    light.type                  = LXLightType_SunPhysical;
    light.lumens                = 3000.f;
    light.longitude             = -75.f * s_degreesToRads;
    light.latitude              =  45.f * s_degreesToRads;
    light.timeHours             = 12.5f;
    light.dayOfYear             = 65;
    light.year                  = 2009;
    light.timeZone              = -5.f;
    light.north                 = 90.0f * s_degreesToRads;
    light.haze                  = 1.f;
    light.cloudiness            = 0.7f;
    light.samples               = 1;
    light.radius                = 1.0f;
    light.iesFile[0]            = '\0';
    light.iesRotation           = 0.0f;

    light.flags.castShadows     = true;
    light.flags.visible         = false;
    light.flags.volumetric      = false;
    light.flags.usePosition     = false;
    light.flags.useDirection    = true;

#if TEST_ALL_LIGHTS
    if (LXe_OK != (result = writer.WriteLight (light)))
        return result;
#endif

    strcpy    (light.name,     "Spot Light 1");
    LXx_V3SET (light.color,    1.0f, 0.1f, 0.3f);
    LXx_V3SET (light.position, 3.f, 5.f, 1.f);
    LXx_V3SET (light.rotation, -45.f * s_degreesToRads, 45.f * s_degreesToRads, 45.f * s_degreesToRads);

    light.type                  = LXLightType_Spot;
    light.lumens                = 100000.f;
    light.coneAngle             = 50.0f * s_degreesToRads;
    light.edgeAngle             =  5.0f * s_degreesToRads;

    LXx_V3SET (light.volume.scatter,    0.2f, 1.0f, 0.3f);
    light.volume.scatterAmt     =  0.5f;
    light.volumeDensity.density =  0.4f;
    light.volume.attenuate      =  0.3f;
    light.volume.shift          = -0.2f;
    light.volumeBase            = 1.f;      // distance from light to volume start, in meters
    light.volumeHeight          = 4.f;      // distance from base to end of volume, in meters
    light.volumeSamples         = 40;

    light.flags.castShadows     = false;
    light.flags.volumetric      = true;
    light.flags.usePosition     = true;
    light.flags.useDirection    = true;

    if (LXe_OK != (result = writer.WriteLight (light)))
        return result;

#if TEST_ALL_LIGHTS
    strcpy    (light.name,     "Cylinder Light 5");
    LXx_V3SET (light.color,    1.f, 1.0f, 0.1f);
    LXx_V3SET (light.position, 2.f, 5.f, 5.f);
    LXx_V3SET (light.rotation, 45.f * s_degreesToRads, 0.f * s_degreesToRads, 0.f * s_degreesToRads);

    light.type                  = LXLightType_Cylinder;
    light.lumens                = 5000.f;
    light.samples               = 64;

    light.radius                = 1.f;          // radius in meters
    light.length                = 10.f;

    light.flags.castShadows     = true;
    light.flags.volumetric      = false;
    light.flags.usePosition     = true;
    light.flags.useDirection    = true;

    if (LXe_OK != (result = writer.WriteLight (light)))
        return result;
#endif

    strcpy (light.name, "Point Light 2");

    LXx_V3SET (light.color,    0.3f, 1.0f, 0.1f);
    LXx_V3SET (light.position, 4.f, 8.f, 4.f);

    light.type                  = LXLightType_Point;
    light.lumens                = 10000.f;

    light.flags.castShadows     = true;
    light.flags.volumetric      = false;
    light.flags.usePosition     = true;
    light.flags.useDirection    = '\0' != light.iesFile[0];     // need direction for IES lights

    if (LXe_OK != (result = writer.WriteLight (light)))
        return result;

#if TEST_ALL_LIGHTS
    strcpy (light.name,    "Area Light 3");
    strcpy (light.iesFile, "c:/someIesFile.ies");

    LXx_V3SET (light.color,     0.1f, 0.3f, 1.0f);
    LXx_V3SET (light.position,  3.f, 8.f, 8.f);
    LXx_V3SET (light.rotation, -45.f * s_degreesToRads, 45.f * s_degreesToRads, 0.f);

    light.type                  = LXLightType_Area;
    light.lumens                = 10000.f;
    light.areaWidth             = 1.f;
    light.areaHeight            = 2.f;
    light.samples               = 64;

    light.flags.visible         = true;
    light.flags.volumetric      = false;
    light.flags.usePosition     = true;
    light.flags.useDirection    = true;

    if (LXe_OK != (result = writer.WriteLight (light)))
        return result;
#endif

    /*
     * Next write out the rendering settings and all used materials
     */
    LXtRenderSettings   settings;   settings.Init ();

            // here are a few environment variations
#if 0
    settings.m_environment.m_flags.mode = LXEvironment_Solid;
    LXx_V3SET (settings.m_environment.m_color, 1.0f, 1.f, 0.3f);
#elif 0
    settings.m_environment.m_flags.mode     = LXEvironment_Gradient2;
    LXx_V3SET (settings.m_environment.m_zenithColor, 0.1f, 0.2f, 1.0f);
    LXx_V3SET (settings.m_environment.m_nadirColor,  0.1f, 0.1f, 0.1f);
#elif 0
    settings.m_environment.m_flags.mode     = LXEvironment_Gradient4;
    LXx_V3SET (settings.m_environment.m_zenithColor, 0.0f, 0.0f, 1.0f);
    LXx_V3SET (settings.m_environment.m_nadirColor,  1.0f, 0.0f, 0.0f);
    LXx_V3SET (settings.m_environment.m_skyColor,    0.0f, 1.0f, 1.0f);
    LXx_V3SET (settings.m_environment.m_groundColor, 0.0f, 1.0f, 0.0f);
    settings.m_environment.m_skyExponent    = 2.0f;
    settings.m_environment.m_groundExponent = 2.0f;
#elif 1
    settings.m_environment.m_flags.mode = LXEvironment_Image;
    settings.m_environment.m_imageLayer = new LXtMaterialLayer (LXMaterialLayer_EnvColor, "probe_frontYard_FINAL.hdr");
    settings.m_environment.m_imageLayer->m_projectMode = LXProjection_Lightprobe;
#else
    settings.m_environment.m_flags.mode = LXEvironment_Sky;
#endif

    LxULong cameraItemId;

    if (LXe_OK != (result = writer.WriteCamera (defaultCamera, LXs_DEFAULT_CAMERA_NAME, &cameraItemId)))
        return result;

    bool        useDefaultSettings = true;

#if !TEST_USING_ANTIALIASING
    settings.m_antialiasPowerOf2 = 1;
    useDefaultSettings           = false;
#endif

    if (LXe_OK != (result = writer.WriteRenderItems (settings, cameraItemId, useDefaultSettings)))
        return result;

    if (settings.m_environment.m_imageLayer)            // free up layer if allocated
        delete settings.m_environment.m_imageLayer;

    /*
     * Write out global settings, environments, cameras, envelopes
     */

    /*
     * Upon exit, the destructor for the LxoWriter will close the LXO file.
     */
    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 09/09
 *
 * Example listener overriding functionality of the default listener
 *
 *----------------------------------------------------------------------------*/
class   TestListener : public LxoListener
{
        virtual LxResult    Listen () override;
};

/*------------------------------- Luxology LLC --------------------------- 09/09
 *
 * This example simply allows the base class to wait for the results, but
 * prints the results and status messages.  This can eventually be extended
 * to things like progress monitors or intermediate image display.
 *
 *----------------------------------------------------------------------------*/
    LxResult
TestListener::Listen ()
{
    printf ("\nWaiting for Output: %s\n", m_outputFile);

    LxResult    result = __super::Listen ();        // do all normal waiting/processing of the output

    // print out any status messages
    printf ("\nresult: %d\tFile: %s\n\n%s\n", result, m_outputFile, m_mgr->GetCommandLog().c_str ());
    m_mgr->GetCommandLog().clear ();

    return result;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * process command line args to specify the output LXO file, and optional output file.
 * Use the LxoWriter class to write an LXO file.
 *
 *----------------------------------------------------------------------------*/
int main (int argc, char const * const argv[])
{
    static char         usage[] = "Usage: %s lxoFileName [imageName]";

    if (argc < 2)
        return fprintf (stderr, usage, argv[0]);

    LxResult    result;
    char const* lxoName;
    char        lxoPathDefault[LXMax_FileLength];
    char        irrCacheFile[LXMax_FileLength];

    /*
     * Get the base filename of the LXO file, for naming the irradiance cache file later
     */

    char const* lxoFile         = argv[1];
    char const* lastSlash       = strrchr (lxoFile, '/');
    char const* lastBackSlash   = strrchr (lxoFile, '\\');

    if (lastSlash > lastBackSlash)
        lxoName = lastSlash + 1;
    else if (lastBackSlash)
        lxoName = lastBackSlash + 1;
    else
        {
        _getcwd (lxoPathDefault, LXMax_FileLength);
        strcat (lxoPathDefault, "/");
        strcat (lxoPathDefault, lxoName = argv[1]);

        lxoFile = lxoPathDefault;
        }

    if (LXe_OK != (result = WriteLxo (lxoFile)))
        return result;

    if (argc < 3)
        return result;      // no output image requested

    /*
     * Need to get the format of the image file; find the file extension by finding the
     * last '.' then use an uppercase copy of the extension for the format.
     */
    char        imageFileName[LXMax_FileLength];

    strcpy (imageFileName, argv[2]);

    char*       lastDot = strrchr (imageFileName, '.');
    if (NULL == lastDot)
        return fprintf (stderr, "Invalid output file name, no extension: <%s>", argv[2]);

    *lastDot = '\0';                // terminate the file name at the last dot

    char*       imageFileExt = ++lastDot;

    for (char* cP = imageFileExt; *cP; ++cP)    // file type is the uppercase version of the file extension
        *cP = toupper (*cP);

#if USE_ENV_VAR_FOR_MODO_PATH || 1
    char const*     modoPathName = NULL;
    char const*     modoEnvVar   = "MODO_PATH";                 // define modo locataion & file name by environment variable...
#else
    char const*     modoPathName = "u:/apps/modo/modo_cl.exe";  // ...  or by a specific path (perhaps from an app config)
    char const*     modoEnvVar   = NULL;
#endif

    bool                    useDefaultThreads   = true;     // let modo decide how many threads to use
    bool                    useIrradianceFile   = true;     // if you want multiple renderings of the same file
    bool                    leaveRunning        = true;     // to run multiple renders and exit when the class is destroyed
    bool                    waitForResult       = false;    // if you want synchronous renderings

    LxGlobalRenderPrefs     globalPrefs;

    globalPrefs.m_nThreads = useDefaultThreads ? LXThreads_UseDefault : 1;
    globalPrefs.m_quitOnError = true;

    TestListener    listener;
    TestListener*   listenerP = waitForResult ? NULL : &listener;       // use listener for asynchronous renderings

    LxoCommand      cmd (imageFileName, imageFileExt, "polyRender001");                  // set up command structure with initial output file
    LxoManager      mgr (leaveRunning, NULL, NULL, listenerP, LxRunModo_NetPipeHeadless);

    if (LXe_OK != (result = mgr.SetModoPath (modoPathName, modoEnvVar)))
        return result;

    /*
     *  start adding commands to be executed LATER in a mgr.Run() call
     */

    cmd.SetGlobalPrefs (globalPrefs);                   // set up the global flags for all renderings
    cmd.AddCommand (cmd.CmdSceneOpen_S, lxoFile);       // open the lxo file
    cmd.AddCommand (cmd.CmdResolution_II, 300, 200);    // set the output image resolution

#if 0
    // when a shader output is defined in an LXO file, and needs to be disabled, do something like this
    cmd.DisableOutput (LXs_OUTPUT_NAME_DEPTH);

    // to add alpha channel output when none is defined in the LXO, do this:
    cmd.AddCommand (cmd.CmdSelectNone_SS, cmd.GetPolyRenderId (), cmd.GetPolyRenderId ());
    cmd.AddCommand (cmd.CmdRenderOutAlpha);
#endif

    if (useIrradianceFile)                              // for multiple renders of the same file
        {
        strcpy (irrCacheFile, mgr.GetWorkDir ());       // define the (temporary) name/location for the irradiance file
        strcat (irrCacheFile, lxoName);
        strcat (irrCacheFile, ".irr");

        cmd.IrradianceFileLoad (irrCacheFile);                              // identify the file for initial use
        cmd.UpdateIrradianceFile (irrCacheFile, mgr.GetIrrBucketDir ());    // let modo update the irradiance file as necessary
        }

    cmd.RenderToFile (mgr.GetBucketDir ());             // perform the render, using buckets

    cmd.WriteCommandsToFile  ("lxoCmds.txt");           // optional: if you want to see what the commands were

    /*
     * We're demonstarting a few different paths here.  If 'waitForResult' is true, there will be no listener
     * thread, and we Run will wait until the rendering is completed before returning.  If false, we will use
     * a listener to handle errors and the final output. [This still needs some work.]
     */
    if (waitForResult)
        {
        printf ("\nOutput: %s\n", imageFileName);

        result = mgr.Run (cmd);         // run render, synchrounously wait for result

        printf ("\nresult: %d\n\n%s\n", result, mgr.GetCommandLog().c_str ());  // print out any status messages
        }
    else
        {
        if (LXe_OK != (result = mgr.Run (cmd)))     // run render, but don't wait (listener used)
            return result;

#if OPTIONAL_WAIT_DESIRED
        result = listener.WaitForTask ();           // optionally wait for the result
#endif
        }

    if (LXe_OK != result)
        return result;

    // camera setup for next view of same file
    bool            useRange            = false;
    LxRange         viewRange (200.f, 400.f, 100.f, 500.f);
    LXtCamera       modifiedCamera = defaultCamera;

    modifiedCamera.position[0] = 30.f;
    modifiedCamera.position[1] =  7.f;
    modifiedCamera.position[2] =  3.f;

    modifiedCamera.rotation[0] =   0.f * s_degreesToRads;
    modifiedCamera.rotation[1] =  90.f * s_degreesToRads;
    modifiedCamera.rotation[2] =  10.f * s_degreesToRads;

    cmd.Clear ();                               // clear to set a new command sequence
    strcat (imageFileName, "_1");
    cmd.SetOutputFile (imageFileName);          // use an alternate output name
    cmd.SetCamera (modifiedCamera, useRange ? &viewRange : NULL);

    if (useIrradianceFile)
        cmd.UpdateIrradianceFile (irrCacheFile, mgr.GetIrrBucketDir ());

    cmd.RenderToFile (mgr.GetBucketDir ());             // perform the render, using buckets
    cmd.WriteCommandsToFile  ("lxoCmds2.txt");          // optional: if you want to see what the commands were

    if (waitForResult)
        printf ("\nOutput: %s\n", imageFileName);

    result = mgr.Run (cmd);             // run render, synchrounously wait for result unless listener is present

    if (waitForResult)
        printf ("\nresult: %d\n\n%s\n", result, mgr.GetCommandLog().c_str ());       // print out any status messages

    return result;
}

