/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef COLLADAREGISTRAR_H
#define COLLADAREGISTRAR_H

#include "colladabind.h"

#include <string>

class ItemTypeChannelRegistrar
{
    public:
                                 ItemTypeChannelRegistrar (
                                        ItemTypeChannelBind &bind);
        virtual			~ItemTypeChannelRegistrar ();

        /*
         * Register item sub types for convenient type checking.
         */
        void			 RegisterItemSubTypes ();

        /*
         * Register targetable channels for each item type.
         */
        void			 RegisterChannels ();

    private:
        void			 RegisterChannel (
                                        const std::string	&lightItemType,
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        /*
         * Camera channel registration.
         */
        void			 RegisterCameraChannels ();
        void			 RegisterCameraChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        /*
         * Light channel registration.
         */
        void			 RegisterLightChannels ();
        void			 RegisterLightLocatorChannels (
                                        const std::string	&itemType);
        void			 RegisterLightTargetChannels (
                                        const std::string	&itemType);

        void			 RegisterAreaLightChannels ();
        void			 RegisterAreaLightChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        void			 RegisterCylinderLightChannels ();
        void			 RegisterCylinderLightChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        void			 RegisterDomeLightChannels ();
        void			 RegisterDomeLightChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        void			 RegisterPhotometricLightChannels ();
        void			 RegisterPhotometricLightChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        void			 RegisterPointLightChannels ();
        void			 RegisterPointLightChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        void			 RegisterSpotLightChannels ();
        void			 RegisterSpotLightChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        void			 RegisterSunLightChannels ();
        void			 RegisterSunLightChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        /*
         * Mesh channel registration.
         */
        void			 RegisterMeshChannels ();
        void			 RegisterMeshChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        /*
         * Render channel registration.
         */
        void			 RegisterRenderChannels ();
        void			 RegisterRenderChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        /*
         * Environment channel registration.
         */
        void			 RegisterEnvironmentChannels ();
        void			 RegisterEnvironmentChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        /*
         * Environment Material channel registration.
         */
        void			 RegisterEnvironmentMaterialChannels ();
        void			 RegisterEnvironmentMaterialChannel (
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		 paramType = cio::PARAM_TYPE_FLOAT);

        ItemTypeChannelBind	&itemTypeChannels;
};

#endif // COLLADAREGISTRAR_H

