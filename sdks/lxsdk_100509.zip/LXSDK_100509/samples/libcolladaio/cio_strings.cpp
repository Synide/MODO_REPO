/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_strings.h"

#include <sstream>
#include <stdio.h>
#include <stdlib.h>

/*
 * Bring in std::replace and std::transform
 */
#include <algorithm>
#include <math.h>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * IDs
 */

/*
 * Filter out reserved characters.
 * 
 * See RFC 3986, section 2.3 and
 * http://www.w3.org/Addressing/URL/5_URI_BNF.html
 */
        static string
EscapeURIReservedCharacters (
        const string&	 path)
{
        string filteredStr;
        const char *text = path.c_str ();

        const unsigned char *c;
        for (c = reinterpret_cast<const unsigned char*>(text); *c; ++c) {
                char tmp[8];

                /*
                 * Per URI_BNF, allow path char set: alpha | digit | safe | extra [ / path ]
                 */
                bool legalChar =
                    (*c >= 'a' && *c <= 'z') ||
                    (*c >= 'A' && *c <= 'Z') ||
                    /* digit */
                    (*c >= '0' && *c <= '9') ||
                    /* safe */
                    (*c == '$' || *c == '-' || *c == '_' || *c == '@' || *c == '.' || *c == '&') ||
                    /* extra */
                    (*c == '!' || *c == '*' || *c == '"' || *c == '\'' || *c == '(' || *c == ')' || *c == ',');

                /* path or volume separator */
                legalChar = legalChar || (*c == '/' || *c == ':');

                if (legalChar) {
                        filteredStr += *c;
                }
                else {
                        filteredStr += "%";

                        #pragma warning(disable: 4996)
                        sprintf (tmp, "%02X", *c);
                        filteredStr.append (tmp);
                }
        }

        return filteredStr;
}

/*
 * Condition a file path into an absolute URI.
 */
        string
FilePathToAbsoluteURI (const string& fileName)
{
        string filteredFileName(fileName);

        /*
         * Replace backslashes with forward slashes.
         */
        replace (
                filteredFileName.begin (),
                filteredFileName.end (),
                '\\', '/');

        filteredFileName = EscapeURIReservedCharacters (filteredFileName);

        string prefix("file://");
        if (filteredFileName[1] == ':') {
                prefix += '/';
        }

        return prefix + filteredFileName;
}

/*
 * Condition a file path into a relative URI.
 */
        string
FilePathToRelativeURI (const string& fileName)
{
        string filteredFileName(fileName);

        /*
         * Replace backslashes with forward slashes.
         */
        replace(
                filteredFileName.begin (),
                filteredFileName.end (),
                '\\', '/');

        /*
         * Find the position of the last forward slash.
         */
        char separator = '/';
        size_t slashPos = filteredFileName.rfind (
                separator, filteredFileName.length ());

        /*
         * If there was at least one forward slash, the path
         * is relative to an intermediate directory, otherwise
         * it's in the local scene directory.
         */
        string relativePrefix;
        if (slashPos != string::npos)
        {
                relativePrefix = string("../");
        }
        else {
                relativePrefix = string("./");
        }
        filteredFileName = relativePrefix + filteredFileName;

        filteredFileName = EscapeURIReservedCharacters (filteredFileName);

        return filteredFileName;
}

/*
 * Return the file extension, if any.
 */
        string
FileExtension (const string& fileName)
{
        /*
         * Strip off the file extension, and convert to lowercase
         * before the comparison is made.
         */
        string::size_type pos = fileName.find_last_of (".");
        string extension = fileName.substr (
                pos + 1, fileName.length () - pos - 1);
        std::transform (
                extension.begin (),
                extension.end (),
                extension.begin (),
                (int(*)(int))tolower);

        return extension;
}

/*
 * Build a Uniform Resource Identifier reference, of the form:
 *
 * "myGeom" --> "#myGeom"
 */
        string
URI_Ref (const string& id)
{
        return string(ATTRVALUE_URLSYMBOL) + id;
}

        string
StripURI_Ref (const string &uri)
{
        string stripped = uri;

        if ((!stripped.empty ()) && stripped[0] == ATTRVALUE_URLSYMBOL[0]) {
                stripped = stripped.substr (
                        1, stripped.length () - 1);
        }

        return stripped;
}

/*
 * Filter out NCName reserved characters.
 * 
 * See the table "Names and Tokens", in "Namespaces in XML 1.0":
 *
 *     http://www.w3.org/TR/REC-xml-names/#ns-decl
 */
        string
EscapeNCName (
        const string&	 name)
{
        string filteredStr;
        const char *text = name.c_str ();

        const unsigned char *c;
        for (c = reinterpret_cast<const unsigned char*>(text); *c; ++c) {
                bool legalChar =
                    (*c >= 'a' && *c <= 'z') ||	// lowercase letter
                    (*c >= 'A' && *c <= 'Z') || // uppercase letter
                    (*c >= '0' && *c <= '9') || // digit
                    (*c == '_') || (*c == '-') || (*c == '.'); // safe delimiters

                if (legalChar) {
                        filteredStr += *c;
                }
                else {
                        filteredStr += "_";
                }
        }

        return filteredStr;
}

/*
 * Form an item ID from an item name.
 */
        string
ItemID (const string &itemName)
{
        return EscapeNCName (itemName);
}

/*
 * Form a transform ID from an item name.
 */
        string
TransformID (const string &transformName)
{
        return EscapeNCName (transformName);
}

/*
 * Form a node ID from an item ID.
 */
        string
NodeID (const string &itemID)
{
        return itemID + string (ATTRVALUE_NODESUFFIX);
}

/*
 * Form a node channel transform ID from an item name.
 */
        string
NodeChannelTransformID (
        const string	&itemID,
        const string	&transformID,
        const string	&axisName,
        const string	&componentName)
{
        string nodeChannelTransformID =
                itemID +
                string(ATTRVALUE_SEPARATORSYMBOL) +
                transformID + axisName;
        if (!componentName.empty()) {
                nodeChannelTransformID += string(ATTRVALUE_DOTSEPARATORSYMBOL) + componentName;
        }

        return nodeChannelTransformID;
}

        string
NodeChannelTransformID (
        const string	&itemID,
        const string	&transformID)
{
        string nodeChannelTransformID =
                itemID +
                string(ATTRVALUE_SEPARATORSYMBOL) +
                transformID;

        return nodeChannelTransformID;
}

/*
 * Form a target channel param ID from an item name.
 */
        string
TargetChannelParamID (
        const string	&itemID,
        const string	&paramSID)
{
        return itemID + string(ATTRVALUE_SEPARATORSYMBOL) + paramSID;
}

/*
 * Form a camera ID from an item ID.
 */
        string
CameraID (const string &itemID)
{
        return string(ATTRVALUE_CAMERAPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form a controller ID from an item ID.
 */
        string
ControllerID (const string &itemID)
{
        return string(ATTRVALUE_CONTROLLERPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form an effect ID from an item ID.
 */
        string
EffectID (const string &itemID)
{
        return string(ATTRVALUE_EFFECTPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form a geometry ID from an item ID.
 */
        string
GeometryID (const string &itemID)
{
        return string(ATTRVALUE_GEOMETRYPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form an image ID from an item ID.
 */
        string
ImageID (const string &itemID)
{
        return string(ATTRVALUE_IMAGEPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form a light ID from an item ID.
 */
        string
LightID (const string &itemID)
{
        return string(ATTRVALUE_LIGHTPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form a material ID from an item ID.
 */
        string
MaterialID (const string &itemID)
{
        return string(ATTRVALUE_MATERIALPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form a material symbolic ID from an item ID.
 */
        string
MaterialSymbolicID (const string &itemID)
{
        return string(ATTRVALUE_MATERIALSYMBOLPREFIX) +
                string(ATTRVALUE_DASHSEPARATORSYMBOL) + itemID;
}

/*
 * Form a vertices ID from a geometry ID.
 */
        string
VerticesID (const string &geometryID)
{
        return geometryID + string(ATTRVALUE_VERTICESSUFFIX);
}

/*
 * ---------------------------------------------------------------------------
 * Type conversions
 */

/*
 * Convert a bool to a string.
 */
        string
BoolToString (bool inValue)
{
        return inValue ? string("true") : string("false");
}

/*
 * Convert an integer to a string, with optional zero padding.
 */
        string
IntegerToString (
        unsigned value,
        unsigned padding,
        bool asHexadecimal,
        bool withHexPrefix)
{
        ostringstream os;
        string result;

        if (asHexadecimal) {
                os << hex;
        }

        if (padding) {
                unsigned padThreshold = static_cast<unsigned>(powf(
                        10, static_cast<float>(padding)));
                while ((value < padThreshold)) {
                        os << 0;
                        padThreshold /= 10;
                        if (padThreshold == 1) {
                                break;
                        }
                }
        }

        os << value;

        if (asHexadecimal && withHexPrefix) {
                result = string("0x");
        }
        result += os.str ();

        return result;
}

/*
 * Convert a float to a string.
 */
        string
FloatToString(float inValue)
{
        ostringstream os;
        os << inValue;

        return os.str();
}

/*
 * Convert a double to a string.
 */
        string
DoubleToString(double inValue)
{
        ostringstream os;
        os << inValue;

        return os.str();
}

        string
DateTimeToString (const DateTime &dateTime)
{
        string date = IntegerToString (dateTime.year);
        date += "-";
        date += IntegerToString (dateTime.month, 1);
        date += "-";
        date += IntegerToString (dateTime.day, 1);

        string time = string ("T");

        time += IntegerToString (dateTime.hour, 1);
        time += ":";
        time += IntegerToString (dateTime.minute, 1);
        time += ":";
        time += IntegerToString (dateTime.second, 1);
        time += "Z";

        return date + time;
}

/*
 * In the string "s", replace the substring "replace" with the contents of
 * the string "replaceWith".
 *
 * Implementation adapted from the function cdom::replace, in "dae/daeUtils.cpp".
 *
 * Copyright 2006 Sony Computer Entertainment Inc.
 *
 * Licensed under the MIT Open Source License.
 * For details, please see the website:
 *
 * http://www.opensource.org/licenses/mit-license.php
 */
        string
Replace (
        const string& s,
        const string& replace,
        const string& replaceWith)
{
        string result;
        if (replace.empty ()) {
                result = s;
        }
        else {
                size_t pos1 = 0;
                size_t pos2 = s.find (replace);
                while (pos2 != string::npos) {
                        result += s.substr (pos1, pos2 - pos1);
                        result += replaceWith;
                        pos1 = pos2 + replace.length ();
                        pos2 = s.find (replace, pos1);
                }

                result += s.substr (pos1, s.length () - pos1);
        }

        return result;
}

} // namespace cio

