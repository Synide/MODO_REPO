/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_EFFECT_H
#define CIO_EFFECT_H

#include "cio_element.h"

namespace cio {

class EffectElement;

typedef enum en_FX_Opaque
{
        FX_OPAQUE_ALPHA_ONE,
        FX_OPAQUE_RGB_ZERO
} FX_Opaque;

/*
 * ---------------------------------------------------------------------------
 * Constant.
 */
class ConstantElement : public Element
{
        friend class EffectElement;

    public:
                                 ConstantElement (
                                         EffectElement	&effect);
        virtual			~ConstantElement ();

        /*
         * For values which have both "Color" and "ColorMap" APIs, the calls
         * are mutually exclusive - use extra profile params to store any
         * combined color and color map pairs.
         *
         * Per the spec, the Set* APIs must be called in the given order.
         *
         * [TODO] Use insertion indices to enforce the order.
         */
        bool			 GetEmissionColor (ColorRGBA &color);
        void			 SetEmissionColor (const ColorRGBA &color);

        bool			 GetEmissionColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetEmissionColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetReflectiveColor (ColorRGBA &color);
        void			 SetReflectiveColor (const ColorRGBA &color);

        bool			 GetReflectiveColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetReflectiveColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetReflectivity (double &reflection);
        void			 SetReflectivity (double reflection);

        bool			 GetTransparentColor (
                                        ColorRGBA		&color,
                                        FX_Opaque		&mode);
        void			 SetTransparentColor (
                                        const ColorRGBA		&color,
                                        FX_Opaque		 mode = FX_OPAQUE_ALPHA_ONE);

        bool			 GetTransparentColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetTransparentColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetTransparency (double &transparency);
        void			 SetTransparency (double transparency);

        bool			 GetIndexOfRefraction (double &refraction);
        void			 SetIndexOfRefraction (double refraction);

    protected:
        bool			 LinkChannels ();

    private:
        struct pv_ShaderElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Lambert.
 */
class LambertElement : public Element
{
        friend class EffectElement;

    public:
                                 LambertElement (
                                         EffectElement	&effect);
        virtual			~LambertElement ();

        /*
         * For values which have both "Color" and "ColorMap" APIs, the calls
         * are mutually exclusive - use extra profile params to store any
         * combined color and color map pairs.
         *
         * Per the spec, the Set* APIs must be called in the given order.
         *
         * [TODO] Use insertion indices to enforce the order.
         */
        bool			 GetEmissionColor (ColorRGBA &color);
        void			 SetEmissionColor (const ColorRGBA &color);

        bool			 GetEmissionColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetEmissionColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetAmbientColor (ColorRGBA &color);
        void			 SetAmbientColor (const ColorRGBA &color);

        bool			 GetAmbientColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetAmbientColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetDiffuseColor (ColorRGBA &color);
        void			 SetDiffuseColor (const ColorRGBA &color);

        bool			 GetDiffuseColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetDiffuseColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetReflectiveColor (ColorRGBA &color);
        void			 SetReflectiveColor (const ColorRGBA &color);

        bool			 GetReflectiveColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetReflectiveColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetReflectivity (double &reflection);
        void			 SetReflectivity (double reflection);

        bool			 GetTransparentColor (
                                        ColorRGBA		&color,
                                        FX_Opaque		&mode);
        void			 SetTransparentColor (
                                        const ColorRGBA		&color,
                                        FX_Opaque		 mode = FX_OPAQUE_ALPHA_ONE);

        bool			 GetTransparentColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetTransparentColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetTransparency (double &transparency);
        void			 SetTransparency (double transparency);

        bool			 GetIndexOfRefraction (double &refraction);
        void			 SetIndexOfRefraction (double refraction);

    protected:
        bool			 LinkChannels ();

    private:
        struct pv_ShaderElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Blinn.
 */
class BlinnElement : public Element
{
        friend class EffectElement;

    public:
                                 BlinnElement (
                                         EffectElement	&effect);
        virtual			~BlinnElement ();

        /*
         * For values which have both "Color" and "ColorMap" APIs, the calls
         * are mutually exclusive - use extra profile params to store any
         * combined color and color map pairs.
         *
         * Per the spec, the Set* APIs must be called in the given order.
         *
         * [TODO] Use insertion indices to enforce the order.
         */
        bool			 GetEmissionColor (ColorRGBA &color);
        void			 SetEmissionColor (const ColorRGBA &color);

        bool			 GetEmissionColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetEmissionColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetAmbientColor (ColorRGBA &color);
        void			 SetAmbientColor (const ColorRGBA &color);

        bool			 GetAmbientColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetAmbientColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetDiffuseColor (ColorRGBA &color);
        void			 SetDiffuseColor (const ColorRGBA &color);

        bool			 GetDiffuseColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetDiffuseColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetSpecularColor (ColorRGBA &color);
        void			 SetSpecularColor (const ColorRGBA &color);

        bool			 GetSpecularColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetSpecularColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetShininess (double &specularity);
        void			 SetShininess (double specularity);

        bool			 GetReflectiveColor (ColorRGBA &color);
        void			 SetReflectiveColor (const ColorRGBA &color);

        bool			 GetReflectiveColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetReflectiveColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetReflectivity (double &reflection);
        void			 SetReflectivity (double reflection);

        bool			 GetTransparentColor (
                                        ColorRGBA		&color,
                                        FX_Opaque		&mode);
        void			 SetTransparentColor (
                                        const ColorRGBA		&color,
                                        FX_Opaque		 mode = FX_OPAQUE_ALPHA_ONE);

        bool			 GetTransparentColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetTransparentColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetTransparency (double &transparency);
        void			 SetTransparency (double transparency);

        bool			 GetIndexOfRefraction (double &refraction);
        void			 SetIndexOfRefraction (double refraction);

    protected:
        bool			 LinkChannels ();

    private:
        struct pv_ShaderElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Phong.
 */
class PhongElement : public Element
{
        friend class EffectElement;

    public:
                                 PhongElement (
                                         EffectElement	&effect);
        virtual			~PhongElement ();

        /*
         * For values which have both "Color" and "ColorMap" APIs, the calls
         * are mutually exclusive - use extra profile params to store any
         * combined color and color map pairs.
         *
         * Per the spec, the Set* APIs must be called in the given order.
         *
         * [TODO] Use insertion indices to enforce the order.
         */
        bool			 GetEmissionColor (ColorRGBA &color);
        void			 SetEmissionColor (const ColorRGBA &color);

        bool			 GetEmissionColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetEmissionColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetAmbientColor (ColorRGBA &color);
        void			 SetAmbientColor (const ColorRGBA &color);

        bool			 GetAmbientColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetAmbientColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetDiffuseColor (ColorRGBA &color);
        void			 SetDiffuseColor (const ColorRGBA &color);

        bool			 GetDiffuseColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetDiffuseColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetSpecularColor (ColorRGBA &color);
        void			 SetSpecularColor (const ColorRGBA &color);

        bool			 GetSpecularColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetSpecularColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetShininess (double &specularity);
        void			 SetShininess (double specularity);

        bool			 GetReflectiveColor (ColorRGBA &color);
        void			 SetReflectiveColor (const ColorRGBA &color);

        bool			 GetReflectiveColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetReflectiveColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetReflectivity (double &reflection);
        void			 SetReflectivity (double reflection);

        bool			 GetTransparentColor (
                                        ColorRGBA		&color,
                                        FX_Opaque		&mode);
        void			 SetTransparentColor (
                                        const ColorRGBA		&color,
                                        FX_Opaque		 mode = FX_OPAQUE_ALPHA_ONE);

        bool			 GetTransparentColorMap (
                                        std::string		&textureName,
                                        std::string		&texcoordSet);
        void			 SetTransparentColorMap (
                                        const std::string	&textureName,
                                        const std::string	&texcoordSet);

        bool			 GetTransparency (double &transparency);
        void			 SetTransparency (double transparency);

        bool			 GetIndexOfRefraction (double &refraction);
        void			 SetIndexOfRefraction (double refraction);

    protected:
        bool			 LinkChannels ();

    private:
        struct pv_ShaderElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Effect.
 */

class EffectLibraryElement;

class EffectElement : public Element
{
        friend class ConstantElement;
        friend class LambertElement;
        friend class BlinnElement;
        friend class PhongElement;

    public:
                                 EffectElement (
                                         EffectLibraryElement &library,
                                         const std::string	&name);
                                 EffectElement (
                                         EffectLibraryElement &library);
        virtual			~EffectElement ();

        bool			 LinkProfileCOMMON ();

        /*
         * Surfaces and samplers.
         * These are cross-referenced by a shader texture map value.
         */
        bool			 GetSurfaceSamplerImageID (
                                        const std::string	&samplerID,
                                        std::string		&imageID) const;
        void			 AddSurfaceSampler (
                                        const std::string&	imageID);

        /*
         * Shaders. Either Constant, Lambert, Blinn, or Phong.
         */
        bool			 HasConstant () const;
        bool			 HasLambert () const;
        bool			 HasBlinn () const;
        bool			 HasPhong () const;

   protected:
        bool			 LinkConstant (
                                        ConstantElement	&constant);
        void			 AddConstant (
                                        ConstantElement	&constant);

        bool			 LinkLambert (
                                        LambertElement	&lambert);
        void			 AddLambert (
                                        LambertElement	&lambert);

        bool			 LinkBlinn (
                                        BlinnElement	&blinn);
        void			 AddBlinn (
                                        BlinnElement	&blinn);

        bool			 LinkPhong (
                                        PhongElement	&phong);
        void			 AddPhong (
                                        PhongElement	&phong);

    private:
        struct pv_EffectElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Effect Library.
 */
 
class COLLADAElement;

class EffectLibraryElement : public Element
{
        friend class EffectElement;

    public:
                                 EffectLibraryElement (
                                         COLLADAElement &collada);
        virtual			~EffectLibraryElement ();

        bool			 HasEffect () const;
        bool			 LinkEffect (
                                        const std::string	&effectID,
                                        EffectElement		&effect);

    protected:
        void			 AddEffect (EffectElement &effect);

    private:
        struct pv_EffectElementLibrary	*pv;
};

} // namespace cio

#endif // CIO_EFFECT_H

