/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_FORMAT_H
#define CIO_FORMAT_H

namespace cio {

/*
 * -------------------------------------------------------------------
 * Fixed Attribute amd Element Values.
 * DO NOT MODIFY ANY VALUES BELOW THIS LINE!
 */

extern const char* VALUE_SCENE_IO_INTERNAL_NAME;
extern const char* VALUE_SCENE_IO_USER_NAME;

/*
 * The Digital Asset Exchange file extension.
 */
extern const char* VALUE_COLLADA_DOS_PATTERN;
extern const char* VALUE_COLLADA_FILE_EXTENSION;

/*
 * XML Header
 */
extern const char* ATTRVALUE_XMLVERSION;
extern const char* ATTRVALUE_XMLENCODING;

/*
 * COLLADA element attribute values
 */
extern const char* ATTRVALUE_COLLADASCHEMAURL;
extern const char* ATTRVALUE_COLLADAVERSION;

/*
 * Untitled scene file name.
 */
extern const char* ATTRVALUE_DEFAULTSCENEFILENAME;

/*
 * Default scene identifier.
 */
extern const char* ATTRVALUE_DEFAULTSCENEID;
extern const char* ATTRVALUE_DEFAULTSCENEURL;

/*
 * Prefixes and Suffixes.
 */
extern const char* ATTRVALUE_ARRAYSUFFIX;
extern const char* ATTRVALUE_CAMERAPREFIX;
extern const char* ATTRVALUE_CONTROLLERPREFIX;
extern const char* ATTRVALUE_CONTROLLERSUFFIX;
extern const char* ATTRVALUE_EFFECTPREFIX;
extern const char* ATTRVALUE_GEOMETRYPREFIX;
extern const char* ATTRVALUE_IMAGEPREFIX;
extern const char* ATTRVALUE_JOINTSUFFIX;
extern const char* ATTRVALUE_LIGHTPREFIX;
extern const char* ATTRVALUE_MATERIALPREFIX;
extern const char* ATTRVALUE_MATERIALSYMBOLPREFIX;
extern const char* ATTRVALUE_NODESUFFIX;
extern const char* ATTRVALUE_SAMPLERSUFFIX;
extern const char* ATTRVALUE_SURFACESUFFIX;
extern const char* ATTRVALUE_UVSUFFIX;
extern const char* ATTRVALUE_VERTICESSUFFIX;

extern const char* ATTRVALUE_BUMPMAP;
extern const char* ATTRVALUE_DIFFUSECOLORMAP;
extern const char* ATTRVALUE_EMISSIONMAP;
extern const char* ATTRVALUE_REFLECTIONMAP;
extern const char* ATTRVALUE_SPECULARMAP;
extern const char* ATTRVALUE_TRANSPARENCYMAP;

/*
 * Common delimiters and formatting.
 */
extern const char* ATTRVALUE_DASHSEPARATORSYMBOL;
extern const char* ATTRVALUE_DOTSEPARATORSYMBOL;
extern const char* ATTRVALUE_PATHSEPARATORSYMBOL;
extern const char* ATTRVALUE_URLSYMBOL;
extern const char* ATTRVALUE_SEPARATORSYMBOL;
extern const char* ATTRVALUE_SPACE;
extern const char* ATTRVALUE_FLOATARRAYTABSTOP;
extern const char* ATTRVALUE_FLOATARRAYOUTERTABSTOP;
extern const char* ATTRVALUE_MATRIXTABSTOP;

/*
 * Preset attribute values.
 */
extern const char* ATTRVALUE_2D;
extern const char* ATTRVALUE_A;
extern const char* ATTRVALUE_A_ONE;
extern const char* ATTRVALUE_AMBIENT;
extern const char* ATTRVALUE_ANGLE;
extern const char* ATTRVALUE_B;
extern const char* ATTRVALUE_BOOL;
extern const char* ATTRVALUE_COLOR;
extern const char* ATTRVALUE_COLORSETPREFIX;
extern const char* ATTRVALUE_COMMON;
extern const char* ATTRVALUE_DIFFUSE;
extern const char* ATTRVALUE_FLOAT;
extern const char* ATTRVALUE_FLOAT4X4;
extern const char* ATTRVALUE_G;
extern const char* ATTRVALUE_INT;
extern const char* ATTRVALUE_JOINT;
extern const char* ATTRVALUE_MATRIX_SID;
extern const char* ATTRVALUE_NAME;
extern const char* ATTRVALUE_NODE;
extern const char* ATTRVALUE_NORMAL;
extern const char* ATTRVALUE_R;
extern const char* ATTRVALUE_RGB_ZERO;
extern const char* ATTRVALUE_ROTATE;
extern const char* ATTRVALUE_ROTATEX;
extern const char* ATTRVALUE_ROTATEY;
extern const char* ATTRVALUE_ROTATEZ;
extern const char* ATTRVALUE_SCALE;
extern const char* ATTRVALUE_SHININESS;
extern const char* ATTRVALUE_SLOPE;
extern const char* ATTRVALUE_SPECULAR;
extern const char* ATTRVALUE_S;
extern const char* ATTRVALUE_T;
extern const char* ATTRVALUE_TEXCOORD;
extern const char* ATTRVALUE_TEXCOORDSET0;
extern const char* ATTRVALUE_TEXCOORDSET1;
extern const char* ATTRVALUE_TEXCOORDSETPREFIX;
extern const char* ATTRVALUE_TIME;
extern const char* ATTRVALUE_TRANSLATE;
extern const char* ATTRVALUE_VERTEX;
extern const char* ATTRVALUE_WEIGHT;
extern const char* ATTRVALUE_WEIGHTSETPREFIX;
extern const char* ATTRVALUE_X;
extern const char* ATTRVALUE_Y;
extern const char* ATTRVALUE_Z;

/*
 * Preset attribute source name values.
 */
extern const char* ATTRVALUE_BROKEN_OUTPUTS_SOURCE_NAME;
extern const char* ATTRVALUE_BROKEN_OUTPUT_TIMES_SOURCE_NAME;
extern const char* ATTRVALUE_BROKEN_SLOPES_SOURCE_NAME;
extern const char* ATTRVALUE_BROKEN_WEIGHTS_SOURCE_NAME;
extern const char* ATTRVALUE_INPUT_SOURCE_NAME;
extern const char* ATTRVALUE_INTANGENTS_SOURCE_NAME;
extern const char* ATTRVALUE_IN_TANGENT_OUTPUT_SOURCE_NAME;
extern const char* ATTRVALUE_IN_TANGENT_SLOPEWEIGHTS_SOURCE_NAME;
extern const char* ATTRVALUE_INTERPOLATIONS_SOURCE_NAME;
extern const char* ATTRVALUE_JOINTS_SOURCE_NAME;
extern const char* ATTRVALUE_MATRICES_SOURCE_NAME;
extern const char* ATTRVALUE_NORMALS_SOURCE_NAME;
extern const char* ATTRVALUE_OUTPUT_SOURCE_NAME;
extern const char* ATTRVALUE_OUTTANGENTS_SOURCE_NAME;
extern const char* ATTRVALUE_OUT_TANGENT_OUTPUT_SOURCE_NAME;
extern const char* ATTRVALUE_OUTTANGENT_SLOPEWEIGHTS_SOURCE_NAME;
extern const char* ATTRVALUE_POSITIONS_SOURCE_NAME;
extern const char* ATTRVALUE_WEIGHTS_SOURCE_NAME;

/*
 * Semantic identifiers for source inputs.
 */
extern const char* ATTRVALUE_BROKEN_OUTPUTS_INPUT_SEMANTIC;		// modo501
extern const char* ATTRVALUE_BROKEN_OUTPUT_TIMES_INPUT_SEMANTIC;	// modo501
extern const char* ATTRVALUE_BROKEN_SLOPES_INPUT_SEMANTIC;		// modo501
extern const char* ATTRVALUE_BROKEN_WEIGHTS_INPUT_SEMANTIC;		// modo501
extern const char* ATTRVALUE_COLOR_INPUT_SEMANTIC;
extern const char* ATTRVALUE_TIME_INPUT_SEMANTIC;
extern const char* ATTRVALUE_IN_TANGENT_INPUT_SEMANTIC;
extern const char* ATTRVALUE_IN_TANGENT_OUTPUT_INPUT_SEMANTIC;		// modo501
extern const char* ATTRVALUE_IN_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC;	// modo501
extern const char* ATTRVALUE_INTERPOLATION_INPUT_SEMANTIC;
extern const char* ATTRVALUE_INV_BIND_MATRIX_SEMANTIC;
extern const char* ATTRVALUE_JOINT_INPUT_SEMANTIC;
extern const char* ATTRVALUE_OUTPUT_INPUT_SEMANTIC;
extern const char* ATTRVALUE_OUT_TANGENT_INPUT_SEMANTIC;
extern const char* ATTRVALUE_OUT_TANGENT_OUTPUT_INPUT_SEMANTIC;		// modo501
extern const char* ATTRVALUE_OUT_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC;	// modo501
extern const char* ATTRVALUE_POSITION_INPUT_SEMANTIC;
extern const char* ATTRVALUE_WEIGHT_INPUT_SEMANTIC;

/*
 * Other preset values.
 */
extern const char* VALUE_BEZIER;
extern const char* VALUE_LINEAR;
extern const char* VALUE_LINEARMIPMAPLINEAR;
extern const char* VALUE_STEP;

extern const char* VALUE_ROTATE_X_AXIS;
extern const char* VALUE_ROTATE_Y_AXIS;
extern const char* VALUE_ROTATE_Z_AXIS;

} // namespace cio

#endif // CIO_FORMAT_H

