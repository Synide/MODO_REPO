/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_VISUALSCENE_H
#define CIO_VISUALSCENE_H

#include "cio_element.h"
#include "cio_strings.h"

namespace cio {

class NodeElement;
class VisualSceneElement;

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile modo 401.
 */

typedef enum en_TimeSystem
{
        TIME_SYSTEM_SECONDS,
        TIME_SYSTEM_FRAMES,
        TIME_SYSTEM_SMPTE,
        TIME_SYSTEM_FILMCODE
} TimeSystem;

class VisualSceneElement_modo401 : public Element
{
        friend class NodeElement;

    public:
                                 VisualSceneElement_modo401 (
                                        VisualSceneElement		&visualScene);
        virtual			~VisualSceneElement_modo401 ();

        /*
         * Non-channelized parameters that should not change over time.
         */

        bool			 GetFPS (double &fps);
        void			 SetFPS (double fps);
        bool			 GetStartEndTime (
                                        double			&startTime,
                                        double			&endTime);
        void			 SetStartEndTime (
                                        double			 startTime,
                                        double			 endTime);
        bool			 GetCurrentStartEndTime (
                                        double			 startTime,
                                        double			 endTime);
        void			 SetCurrentStartEndTime (
                                        double			 startTime,
                                        double			 endTime);
        bool			 GetTime (double &time);
        void			 SetTime (double time);

        bool			 GetTimeSystem (TimeSystem &timeSystem);
        void			 SetTimeSystem (TimeSystem timeSystem);

        bool			 GetDefaultDrawSize (double &drawSize);
        void			 SetDefaultDrawSize (double drawSize);

    private:
        struct pv_VisualSceneElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile 3dsMax.
 */

class VisualSceneElement_3dsMax : public Element
{
        friend class NodeElement;

    public:
                                 VisualSceneElement_3dsMax (
                                        VisualSceneElement		&visualScene);
        virtual			~VisualSceneElement_3dsMax ();

        /*
         * Non-channelized parameters that should not change over time.
         */

        bool			 GetFrameRate (double &frameRate);
        void			 SetFrameRate (double frameRate);

private:
        struct pv_VisualSceneElement_3dsMax *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile FCOLLADA.
 */

class VisualSceneElement_FCOLLADA : public Element
{
        friend class NodeElement;

    public:
                                 VisualSceneElement_FCOLLADA (
                                        VisualSceneElement	&visualScene);
        virtual			~VisualSceneElement_FCOLLADA ();

        /*
         * Non-channelized parameters that should not change over time.
         */

        bool			 GetStartEndTime (
                                        double			&startTime,
                                        double			&endTime);
        void			 SetStartEndTime (
                                        double			 startTime,
                                        double			 endTime);

private:
        struct pv_VisualSceneElement_FCOLLADA *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile Maya.
 */

class VisualSceneElement_Maya : public Element
{
        friend class NodeElement;

    public:
                                 VisualSceneElement_Maya (
                                        VisualSceneElement	&visualScene);
        virtual			~VisualSceneElement_Maya ();

        /*
         * Non-channelized parameters that should not change over time.
         */

        bool			 GetStartEndTime (
                                        double			&startTime,
                                        double			&endTime);
        void			 SetStartEndTime (
                                        double			 startTime,
                                        double			 endTime);

        /*
         * [TODO] Add the layer IDs. (ELEMENT_LAYER)
         */

private:
        struct pv_VisualSceneElement_Maya *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile Okino.
 */

class VisualSceneElement_Okino : public Element
{
        friend class NodeElement;

    public:
                                 VisualSceneElement_Okino (
                                        VisualSceneElement	&visualScene);
        virtual			~VisualSceneElement_Okino ();

        /*
         * Non-channelized parameters that should not change over time.
         */

        bool			 GetSceneBoundingMin (
                                        double &x, double &y, double &z);
        void			 SetSceneBoundingMin (
                                        double x, double y, double z);

        bool			 GetSceneBoundingMax (
                                        double &x, double &y, double &z);
        void			 SetSceneBoundingMax (
                                        double x, double y, double z);

private:
        struct pv_VisualSceneElement_Okino *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile XSI.
 */

typedef enum en_Timing
{
        TIMING_FRAMES,
        TIMING_SECONDS
} Timing;

class VisualSceneElement_XSI : public Element
{
        friend class NodeElement;

    public:
                                 VisualSceneElement_XSI (
                                        VisualSceneElement	&visualScene);
        virtual			~VisualSceneElement_XSI ();

        /*
         * Non-channelized parameters that should not change over time.
         */

        bool			 GetFrameRate (double &frameRate);
        void			 SetFrameRate (double frameRate);

        bool			 GetStartEndTime (
                                        double			&startTime,
                                        double			&endTime);
        void			 SetStartEndTime (
                                        double			 startTime,
                                        double			 endTime);

        bool			 GetTiming (Timing &timing);
        void			 SetTiming (Timing timing);

private:
        struct pv_VisualSceneElement_XSI *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Visual Scene.
 */

class VisualSceneLibraryElement;

class AssetElement;

class VisualSceneElement : public Element
{
        friend class AssetElement;
        friend class NodeElement;
        friend class VisualSceneElement_modo401;
        friend class VisualSceneElement_3dsMax;
        friend class VisualSceneElement_FCOLLADA;
        friend class VisualSceneElement_Maya;
        friend class VisualSceneElement_Okino;
        friend class VisualSceneElement_XSI;

    public:
                                 VisualSceneElement (
                                        VisualSceneLibraryElement	&library,
                                        const std::string		&name);
                                 VisualSceneElement (
                                        VisualSceneLibraryElement	&library);
        virtual			~VisualSceneElement ();

        bool			 HasAsset () const;

        bool			 HasNode () const;
        bool			 LinkFirstNode (NodeElement &node);
        bool			 LinkNextNode (NodeElement &node);

        bool			 HasTechniqueProfile_modo401 () const;
        bool			 LinkTechniqueProfile_modo401 (
                                        VisualSceneElement_modo401 &modoTech);

        bool			 HasTechniqueProfile_3dsMax () const;
        bool			 LinkTechniqueProfile_3dsMax (
                                        VisualSceneElement_3dsMax &maxTech);

        bool			 HasTechniqueProfile_FCOLLADA () const;
        bool			 LinkTechniqueProfile_FCOLLADA (
                                        VisualSceneElement_FCOLLADA &fTech);

        bool			 HasTechniqueProfile_Maya () const;
        bool			 LinkTechniqueProfile_Maya (
                                        VisualSceneElement_Maya &mayaTech);

        bool			 HasTechniqueProfile_Okino () const;
        bool			 LinkTechniqueProfile_Okino (
                                        VisualSceneElement_Okino &okinoTech);

        bool			 HasTechniqueProfile_XSI () const;
        bool			 LinkTechniqueProfile_XSI (
                                        VisualSceneElement_XSI &xsiTech);

    protected:
        bool			 LinkAsset (AssetElement &asset);
        void			 AddAsset (AssetElement &asset);

        void			 AddNode (NodeElement &node);

        void			 AddTechniqueProfile_modo401 (
                                        VisualSceneElement_modo401 &modoTech);

        void			 AddTechniqueProfile_3dsMax (
                                        VisualSceneElement_3dsMax &maxTech);

        void			 AddTechniqueProfile_FCOLLADA (
                                        VisualSceneElement_FCOLLADA &fTech);

        void			 AddTechniqueProfile_Maya (
                                        VisualSceneElement_Maya &mayaTech);

        void			 AddTechniqueProfile_Okino (
                                        VisualSceneElement_Okino &okinoTech);

        void			 AddTechniqueProfile_XSI (
                                        VisualSceneElement_XSI &xsiTech);

    private:
        void			 AddTechniqueProfile (
                                        ElementXML		**extraElem,
                                        ElementXML		**techniqueElem,
                                        const std::string	&profileName,
                                        Element			&technique);

        struct pv_VisualSceneElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Library.
 */
 
class COLLADAElement;

class VisualSceneLibraryElement : public Element
{
        friend class VisualSceneElement;

    public:
                                 VisualSceneLibraryElement (
                                        COLLADAElement &collada);
        virtual			~VisualSceneLibraryElement ();

        bool			 HasVisualScene () const;
        bool			 LinkVisualScene (
                                        const std::string &visualSceneID,
                                        VisualSceneElement &visualScene);

    protected:
        void			 AddVisualScene (
                                        VisualSceneElement &visualScene);
};

} // namespace cio

#endif // CIO_VISUALSCENE_H

