/*
 * INFLUENCE.CPP	General Influence
 *
 *	Copyright (c) 2008-2015 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_action.hpp>
#include <lx_deform.hpp>
#include <lx_package.hpp>
#include <lx_plugin.hpp>
#include <lx_layer.hpp>
#include <lx_vmodel.hpp>
#include <lx_listener.hpp>
#include <lx_channelui.hpp>
#include <lx_thread.hpp>
#include <lx_undo.hpp>
#include <lx_log.hpp>
#include <lx_io.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxu_command.hpp>
#include <lxu_message.hpp>
#include <lxu_select.hpp>
#include <lxu_simd.hpp>
#include <lxu_math.hpp>
#include <lxw_schematic.hpp>
#include <lxidef.h>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>


        namespace Influence_General {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		LXsITYPE_GENINFLUENCE
#define SRVNAME_MODIFIER		LXsITYPE_GENINFLUENCE
#define SPWNAME_INSTANCE		"genInf.inst"
#define SPWNAME_DEFORMER		"genInf.deform"
#define CMDNAME_CREATE			LXsITYPE_GENINFLUENCE ".create"
#define CMDNAME_SETNAME			LXsITYPE_GENINFLUENCE ".name"

/*
 * Package channels.
 */
#define Cs_MESHINF		LXsICHAN_GENINFLUENCE_INFLUENCE
#define Cs_ENABLE		LXsICHAN_GENINFLUENCE_ENABLE
#define Cs_INTERPOLATION	LXsICHAN_GENINFLUENCE_INTERPOLATION
#define Cs_TYPE			LXsICHAN_GENINFLUENCE_TYPE
#define Cs_NAME			LXsICHAN_GENINFLUENCE_NAME

#define INTERPi_LOCAL		 0
#define INTERPi_LINEAR		 1

static LXtTextValueHint hint_Interp[] = {
        INTERPi_LOCAL,		LXsICVAL_GENINFLUENCE_INTERPOLATION_LOCAL,
        INTERPi_LINEAR,		LXsICVAL_GENINFLUENCE_INTERPOLATION_LINEAR,
        -1,			"=weight-interpolation-type",
        -1,			 0
};

#define TYPEi_ALL		 0
#define TYPEi_WEIGHT		 1
#define TYPEi_PICK		 2
#define TYPEi_MATERIAL		 3
#define TYPEi_PART		 4
#define TYPEi_PSELSET		 5

static LXtTextValueHint hint_Type[] = {
        TYPEi_ALL,		LXsICVAL_GENINFLUENCE_TYPE_ALL,
        TYPEi_WEIGHT,		LXsICVAL_GENINFLUENCE_TYPE_WEIGHT,
        TYPEi_PICK,		LXsICVAL_GENINFLUENCE_TYPE_PICK,
        TYPEi_MATERIAL,		LXsICVAL_GENINFLUENCE_TYPE_MATERIAL,
        TYPEi_PART,		LXsICVAL_GENINFLUENCE_TYPE_PART,
        TYPEi_PSELSET,		LXsICVAL_GENINFLUENCE_TYPE_PSELSET,
        -1,			"=vertex-cluster-type",
        -1,			 0
};

static CLxItemType		 cit_genInf	(SRVNAME_ITEMTYPE);
static CLxItemType		 cit_mesh	(LXsITYPE_MESH);
static CLxItemType		 cit_instance	(LXsITYPE_MESHINST);
static CLxItemType		 cit_locator	(LXsITYPE_LOCATOR);
static CLxItemType		 cit_weightCont	(LXsITYPE_WEIGHTCONTAINER);
static CLxItemType		 cit_morphInf	(LXsITYPE_MORPHDEFORM);
static CLxItemType		 cit_mddInf	(LXsITYPE_MDD2);
static CLxItemType		 cit_wrapInf	(LXsITYPE_WRAPDEFORM);
static CLxItemType		 cit_softLag	(LXsITYPE_SOFTLAG);
static CLxItemType		 cit_modSculpt	(LXsITYPE_MODSCULPT);


/*
 * Template method for getting an array of keys from a map.
 */
        template <class K, class V>
        void
KeyVector (
        const std::map<K,V>	&map,
        std::vector<K>		&keyList)
{
 #ifndef _MSWIN
        typename	// Really, clang? You need a hint?
 #endif
        std::map<K,V>::const_iterator it;

        keyList.clear ();
        for (it = map.begin (); it != map.end (); it++)
                keyList.push_back (it->first);
}


/*
 * Template method putting elements of a list into a set.
 */
        template <class T>
        void
ListIntoSet (
        const std::vector<T>	&list,
        std::set<T>		&set)
{
 #ifndef _MSWIN
        typename	// Et tu, Linux gcc?
 #endif
        std::vector<T>::const_iterator it;

        for (it = list.begin (); it != list.end (); it++)
                set.insert (*it);
}


/*
 * Elements for a partition (mesh) are cached in this object. Elments can come
 * from multiple source influences, each of which thinks of this mesh by its own
 * partition index. Sources have an index, and index zero is this item itself.
 *
 * The complexity comes from having to divide the mesh into segments. We want
 * each segment to some from a unique source, and to have a single segment
 * number from the source. To avoid confusion we call segments that we create
 * 'chunks' and the segments requested by the sources 'segments'.
 */
class CPartElements
{
    public:
        typedef std::pair<unsigned,unsigned>		SrcSeg;	// first is source, second is segment
        typedef std::vector<LXtDeformElt>		DEltList;
        typedef std::vector<LXtDeformElt>::iterator	DEltList_Itr;

        std::map<unsigned,unsigned>		src_partition;
        std::map<unsigned,CLxUser_Deformer>	src_deformer;
        std::map<LXtDeformElt,unsigned>		elt_source;
        std::map<SrcSeg,unsigned>		srcseg_chunk;
        std::map<unsigned,SrcSeg>		chunk_srcseg;
        std::map<unsigned,DEltList>		chunk_points;

        unsigned		 n_chunk;

        CPartElements () : n_chunk (0) {}

        /*
         * Bulding the list calls AddSource() to set the index of the source
         * influence item, the partition that this mesh has in that deformer,
         * and its interface. Or it calls NullSource() to indicate source zero.
         * After that Insert() is used to add points/elements.
         */
        unsigned		 build_source;

                void
        AddSource (
                unsigned		 source,
                unsigned		 partition,
                ILxUnknownID		 ifc)
        {
                src_partition[source] = partition;
                src_deformer [source].set (ifc);

                build_source = source;
        }

                void
        NullSource ()
        {
                build_source = 0;
        }

                void
        Insert (
                LXtDeformElt		 pnt,
                unsigned		 segment)
        {
                SrcSeg			 srcseg (build_source, segment);
                unsigned		 ichunk;

                if (elt_source.find (pnt) != elt_source.end ())
                        return;

                if (srcseg_chunk.find (srcseg) == srcseg_chunk.end ()) {
                        ichunk = n_chunk++;
                        srcseg_chunk[srcseg] = ichunk;
                        chunk_srcseg[ichunk] = srcseg;
                } else
                        ichunk = srcseg_chunk[srcseg];

                chunk_points[ichunk].push_back (pnt);
                elt_source[pnt] = build_source;
        }

        /*
         * Enumeration walks the client visitor through the points for this
         * mesh.
         */
        unsigned		 enum_chunk;
        DEltList_Itr		 enum_pitr;

                LxResult
        Enumerate (
                CLxUser_Visitor		 vis)
        {
                LxResult		 rc;

                for (enum_chunk = 0; enum_chunk < n_chunk; enum_chunk++) {

                        DEltList	&list = chunk_points[enum_chunk];

                        for (enum_pitr = list.begin (); enum_pitr != list.end (); enum_pitr++) {
                                rc = vis.Evaluate ();
                                if (rc != LXe_OK)
                                        return rc;
                        }
                }

                return LXe_OK;
        }

                LXtDeformElt
        EnumElement (
                unsigned		*chunk)
        {
                chunk[0] = enum_chunk;
                return *enum_pitr;
        }

        /*
         * During deformation the client will select this mesh (partition) which
         * means we have to signal the state down to the source deformers.
         */
                void
        SetPartition ()
        {
                std::map<unsigned,unsigned>::const_iterator
                                        pit;

                for (pit = src_partition.begin (); pit != src_partition.end (); pit++)
                        src_deformer[pit->first].SetPartition (pit->second);
        }

        /*
         * The core lookups during deformation happen from the Weight() and
         * WeightRun() method, so we should try to be fast when possible.
         */
                unsigned
        SourceFromChunk (
                unsigned		 chunk,
                unsigned		*segment)
        {
                SrcSeg			&srcseg = chunk_srcseg[chunk];

                segment[0] = srcseg.second;
                return srcseg.first;
        }

                unsigned
        SourceFromElement (
                LXtDeformElt		 pnt)
        {
                return elt_source[pnt];
        }
};


/*
 * -------------------------------------------------------
 *
 * The deformer object is actually broken into two classes. The subclass
 * is the deformer mappings object, which computes the relationships between this
 * deformer item and all the ones it depends on. This is used directly by the item
 * instance to report related meshes and target items.
 */
class CDeformerMappings :
                public CLxImpl_SchematicConnection
{
    public:
        CLxUser_DeformerService	 d_S;

        /*
         * FlowSource defines a sub-influence that targets a mesh, given by the
         * influence item and the partition index. Called flow because it allows
         * us to chain influences together to affect each other.
         */
        class FlowSource {
            public:
                CLxUser_Item		src_def;	// deformer item
                unsigned		src_index;	// deformer index (0 for this)
                unsigned		mesh_index;	// index for the mesh in the mesh sequence
                unsigned		part_index;	// partition index for the mesh

                        bool
                operator== (
                        const FlowSource	&rhs) const
                {
                        return (src_def == rhs.src_def) && (part_index == rhs.part_index);
                }
        };

        typedef std::vector<CLxUser_Item>		ItemList;
        typedef std::vector<CLxUser_Item>::iterator	ItemList_Itr;
        typedef std::vector<FlowSource>			FlowList;
        typedef std::vector<FlowSource>::iterator	FlowList_Itr;
        typedef std::map<CLxUser_Item,FlowList>		FlowMap;

        /*
         * Item relationships. This item, the meshes it deforms, and the
         * sub-influences that provide the content and weights of the meshes.
         */
        CLxUser_Item		 m_item;	// this item
        FlowMap			 flow_map;	// list of FlowSources by target mesh item
        ItemList		 mesh_items;	// list of mesh items (partition order)
        ItemList		 def_items;	// flow deformer items (0 = this)
        FlowList		 item_flow;	// FlowSources providing items
        bool			 has_items;	// true if we have items

        /*
         * Helper class to build the list of deformers. First time we encounter it
         * we add it to the end of the list and remember the index.
         */
        class DeformerTable {
            public:
                ItemList			&def_items;
                std::map<CLxUser_Item,int>	 def_2_idx;
                int				 cur_index;

                DeformerTable (ItemList &list) : def_items (list), cur_index (0) {}

                        int
                Index (
                        CLxUser_Item		&def)
                {
                        if (def_2_idx.find (def) == def_2_idx.end ()) {
                                def_items.push_back (def);
                                def_2_idx[def] = cur_index ++;
                        }

                        return def_2_idx[def];
                }
        };

        /*
         * Initialization reads the item relations and builds the flow_map table. It
         * finds target meshes and all the deformer items (including this one) that
         * affect it. This also extracts the list of mesh items for easier use in
         * the deformer item instance, and builds the deformer list with this
         * item at index zero.
         */
                void
        Init (
                ILxUnknownID		 itemObj)
        {
                CLxUser_Item		 target, mesh;
                CLxUser_ItemGraph	 graph;
                CLxUser_DeformerService	 dSrv;
                CLxUser_MeshInfluence	 mi;
                CLxUser_ItemInfluence	 iif;
                FlowSource		 fsrc;
                DeformerTable		 src (def_items);
                unsigned		 i, n, ii, nn, midx;

                m_item.set (itemObj);
                has_items = false;

                graph.from (m_item, LXsGRAPH_DEFORMERS);
                n = graph.Forward (m_item);
                src.Index (m_item);
                midx = 0;

                for (i = n; i > 0; i--) {
                        graph.Forward (m_item, i - 1, target);

                        if (target.IsA (cit_mesh) || target.IsA (cit_instance)) {
                                fsrc.src_def.set (m_item);
                                fsrc.src_index  = src.Index (fsrc.src_def);
                                fsrc.mesh_index = ~0;	// never used
                                fsrc.part_index = midx++;
                                flow_map[target].push_back (fsrc);
                                continue;
                        }

                        if (mi.set (target)) {
                                fsrc.src_def.set (target);
                                fsrc.src_index = src.Index (fsrc.src_def);

                                nn = mi.MeshCount ();
                                for (ii = 0; ii < nn; ii++) {
                                        mi.GetMesh (ii, mesh);
                                        fsrc.mesh_index = ii;
                                        fsrc.part_index = mi.PartitionIndex (ii);
                                        flow_map[mesh].push_back (fsrc);
                                }

                        } else if (InfluenceChannel (target) >= 0) {
                                fsrc.src_def.set (target);
                                fsrc.src_index = src.Index (fsrc.src_def);

                                d_S.MeshCount (target, &nn);
                                for (ii = 0; ii < nn; ii++) {
                                        d_S.GetMesh (target, ii, mesh);
                                        fsrc.mesh_index = ii;
                                        fsrc.part_index = ii;
                                        flow_map[mesh].push_back (fsrc);
                                }
                        }

                        if (iif.set (target) && iif.HasItems () == LXe_TRUE) {
                                fsrc.src_def.set (target);
                                fsrc.src_index  = src.Index (fsrc.src_def);
                                fsrc.mesh_index = ~0;	// never used
                                fsrc.part_index = 0;
                                item_flow.push_back (fsrc);
                                has_items = true;
                        }
                }

                KeyVector (flow_map, mesh_items);
        }

                int
        InfluenceChannel (
                CLxUser_Item		&item)
        {
                unsigned		 chan;

                if (LXx_OK (d_S.DeformerChannel (item, &chan)))
                        return chan;

                if (item.IsA (cit_weightCont))
                        return item.ChannelIndex (LXsICHAN_WEIGHTCONTAINER_INFLUENCE);

                return -1;
        }

        /*
         * For the purpose of testing whether the modifier node is still valid
         * we just have to test the equivalence of the flow map(s).
         */
                bool
        IsSame (
                const CDeformerMappings	 &that) const
        {
                return	(m_item    == that.m_item  )
                   &&	(flow_map  == that.flow_map)
                   &&	(item_flow == that.item_flow);
        }

        /*
         * Evaluation state for a modifier. EvalAlloc() is called from the
         * deformer cached in the modifier node, which adds channels for reading.
         */
        unsigned			 attr_index;	// base attribute index

                void
        EvalAlloc (
                CLxUser_Evaluation	&eval)
        {
                unsigned		 i;

                attr_index =
                 eval.AddChan (m_item, Cs_TYPE);
                 eval.AddChan (m_item, Cs_NAME);
                 eval.AddChan (m_item, Cs_INTERPOLATION);

                for (i = 1; i < def_items.size (); i++) {
                        CLxUser_Item	&defSrc = def_items[i];

                        eval.AddChan (defSrc, InfluenceChannel (defSrc));
                }
        }

        /*
         * Constructors, with one that takes an item for quick initialization.
         */
        unsigned			 use_count;

        CDeformerMappings ()
        {
                use_count = 1;
        }

        CDeformerMappings (
                ILxUnknownID		 item)
        {
                CDeformerMappings ();
                Init (item);
        }

                CDeformerMappings *
        AddRef ()
        {
                use_count ++;
                return this;
        }

                static void
        Release (
                CDeformerMappings	*dp)
        {
                if (-- dp->use_count == 0)
                        delete dp;
        }

        /*
         * ----------------------------------------------------------------
         * Connection Point
         *
         * The "Geometry" graph is one that we define, using the deformers graph
         * but allows connections from weight containers to general influences.
         *
         * Note that the graph is actually reversed, so while the graph connection
         * is stored from a weight container to mesh, we draw it in reverse, so
         * the mesh appears as an input to the WC.
         */
        static LXtTagInfoDesc	 descInfo[];

                static void
        initialize ()
        {
                CLxGenericPolymorph	*srv;

                srv = new CLxPolymorph<CDeformerMappings>;
                srv->AddInterface (new CLxIfc_SchematicConnection<CDeformerMappings>);
                srv->AddInterface (new CLxIfc_StaticDesc         <CDeformerMappings>);
                lx::AddServer (SRVNAME_ITEMTYPE, srv);
        }

                int
        schm_BaseFlags ()					LXx_OVERRIDE
        {
                return LXfSCON_USESERVER | LXfSCON_REVERSE;
        }

                LxResult
        schm_ItemFlags (
                ILxUnknownID		 item,
                unsigned		*flags)			LXx_OVERRIDE
        {
                CLxUser_Item		 it (item);

                if (  !it.IsA (cit_genInf)  && !it.IsA (cit_weightCont)
                   && !it.IsA (cit_mddInf)  && !it.IsA (cit_morphInf)
                   && !it.IsA (cit_wrapInf) && !it.IsA (cit_softLag)
                   && !it.IsA (cit_modSculpt) )
                        return LXe_NOTFOUND;

                flags[0] = LXfSCON_ORDERED | LXfSCON_USESERVER | LXfSCON_REVERSE;
                return LXe_OK;
        }

                LxResult
        schm_AllowConnect (
                ILxUnknownID		 from,
                ILxUnknownID		 to)			LXx_OVERRIDE
        {
                CLxUser_Item		 itemFrom (from);
                CLxUser_MeshInfluence	 mi;
                CLxUser_ItemInfluence	 iif;

                if (itemFrom.IsA (cit_mesh) || itemFrom.IsA (cit_instance))
                        return LXe_TRUE;

                if (mi.set (itemFrom))
                        return LXe_TRUE;

                if (InfluenceChannel (itemFrom) >= 0)
                        return LXe_TRUE;

                if (iif.set (itemFrom) && iif.HasItems () == LXe_TRUE)
                        return LXe_TRUE;

                return LXe_FALSE;
        }

                LxResult
        schm_Count (
                ILxUnknownID		 to,
                unsigned		 *count)		LXx_OVERRIDE
        {
                CLxUser_Item		 toItem (to);
                CLxUser_ItemGraph	 graph;

                graph.from (toItem, LXsGRAPH_DEFORMERS);
                count[0] = graph.Forward (toItem);
                return LXe_OK;
        }


                LxResult
        schm_ByIndex (
                ILxUnknownID		 to,
                unsigned		 index,
                void			**ppvObj)		LXx_OVERRIDE
        {
                CLxUser_Item		 toItem (to);
                CLxUser_Item		 fromItem;
                CLxUser_ItemGraph	 graph;

                graph.from (toItem, LXsGRAPH_DEFORMERS);
                graph.Forward (toItem, index, fromItem);

                ppvObj[0] = fromItem ? (ILxUnknownID)fromItem: NULL;
                return LXe_OK;
        }

                LxResult
        schm_Connect (
                ILxUnknownID		 itemF,
                ILxUnknownID		 itemT,
                int			 toIndex)		LXx_OVERRIDE
        {
                CLxUser_Item		 fromItem (itemT);	// graph is really reversed
                CLxUser_Item		 toItem (itemF);
                CLxUser_ItemGraph	 graph;

                graph.from (toItem, LXsGRAPH_DEFORMERS);
                return graph.SetLink (fromItem, toIndex, toItem, -1);
        }

                LxResult
        schm_Disconnect (
                ILxUnknownID		 itemF,
                ILxUnknownID		 itemT)		LXx_OVERRIDE
        {
                CLxUser_Item		 fromItem (itemT);	// graph is really reversed
                CLxUser_Item		 toItem (itemF);
                CLxUser_ItemGraph	 graph;

                graph.from (toItem, LXsGRAPH_DEFORMERS);
                return graph.DeleteLink (fromItem, toItem);
        }

                LxResult
        schm_GraphName (
                const char	       **name)			LXx_OVERRIDE
        {
                name[0] = LXsGRAPH_DEFORMERS;
                return LXe_OK;
        }
};


LXtTagInfoDesc	 CDeformerMappings::descInfo[] = {
        { LXsSRV_USERNAME,	 "@SchemaGraphs@Geometry@"	},
        { 0 }
};


/*
 * -------------------------------------------------------
 *
 * The deformer class does everything that the mappings class does, plus it
 * computes deformations.
 */
class CDeformer :
                public CLxImpl_Deformer,
                public CLxImpl_MeshInfluence,
                public CLxImpl_ItemInfluence
{
    public:
        /*
         * The FlowObject is computed from the evaluated state of all the flow-through
         * deformers. It holds the required and optional interfaces, and will be
         * indexed by the deformer index.
         */
        class FlowObject {
            public:
                CLxUser_Deformer	 di;
                CLxUser_MeshInfluence	 mi;
                CLxUser_ItemInfluence	 ii;
        };

        typedef CDeformerMappings::FlowList	 FlowList;
        typedef CDeformerMappings::FlowList_Itr	 FlowList_Itr;

        CLxUser_LogService		 log_S;
        CDeformerMappings		*dp;
        CLxUser_ThreadMutex		 mux_point;

        CDeformer ()
        {
                CLxUser_ThreadService	 tS;

                tS.NewCritSec (mux_point);
                dp = 0;
        }

                void
        SetMappings (
                CDeformerMappings	*map)
        {
                dp = map->AddRef ();
        }

        ~CDeformer ()
        {
                if (dp)
                        CDeformerMappings::Release (dp);
        }

                FlowList &
        GetFlowList (
                unsigned		 index)
        {
                return dp->flow_map [ dp->mesh_items[index] ];
        }

        /*
         * Evaluation state is read by EvalEval() and is passed the cached deformer
         * as an argument to get the base index. ifc_array is only mapped for non-zero
         * indices, since index zero is reserved for this deformer item.
         */
        int				 vc_type;	// vertex cluster type
        std::string			 vc_name;	// weight map / ptag name
        bool				 vc_linear;	// linear interpolation
        std::map<int,FlowObject>	 ifc_array;	// deformer interfaces by index

                void
        EvalEval (
                const CDeformerMappings	&sub,
                CLxUser_Attributes	&attr)
        {
                unsigned		 index = sub.attr_index;

                vc_type = attr.Int (index++);
                attr.String (index++, vc_name);
                vc_linear = (attr.Int (index++) == INTERPi_LINEAR);

                for (int i = 1; i < dp->def_items.size (); i++) {
                        FlowObject		&flow = ifc_array[i];
                        CLxUser_ValueReference	 ref;

                        attr.ObjectRO (index++, ref);
                        if (ref.test ()) {
                                ref.Get (flow.di);
                                ref.Get (flow.mi);
                                ref.Get (flow.ii);
                        }
                }
        }


        /*
         * Evaluation meta-state. We keep the meshes passed to us in a table,
         * and pass meshes and transforms down to sub-deformers.
         */
        std::map<unsigned,CLxUser_Mesh>	 mesh_array;

                unsigned
        minf_PartitionIndex (
                unsigned		 index)
                                LXx_OVERRIDE
        {
                return index + (dp->has_items ? 1 : 0);
        }

                LxResult
        minf_SetMesh (
                unsigned		 index,
                ILxUnknownID		 mesh,
                ILxUnknownID		 item)
                                LXx_OVERRIDE
        {
                if (!mesh_array[index].set (mesh))
                        return LXe_INVALIDARG;

                FlowList		&flst = GetFlowList (index);
                FlowList_Itr		 iflow;
                LxResult		 rc;

                for (iflow = flst.begin (); iflow != flst.end (); iflow ++) {
                        if (!iflow->src_index)
                                continue;

                        if (!ifc_array[iflow->src_index].mi.test ())
                                continue;

                        rc = ifc_array[iflow->src_index].mi.SetMesh (iflow->mesh_index, mesh, item);
                        if (LXx_FAIL (rc))
                                return rc;
                }
                return LXe_OK;
        }

                bool
        valid_mesh_partition (
                unsigned		 index)
        {
                return (mesh_array.find (index) != mesh_array.end ());
        }

                LxResult
        minf_SetTransform (
                unsigned		 index,
                LXtMatrix4		 xfrm)
                                LXx_OVERRIDE
        {
                FlowList		&flst = GetFlowList (index);
                FlowList_Itr		 iflow;
                LxResult		 rc;

                for (iflow = flst.begin (); iflow != flst.end (); iflow ++) {
                        if (!iflow->src_index)
                                continue;

                        if (!ifc_array[iflow->src_index].mi.test ())
                                continue;

                        rc = ifc_array[iflow->src_index].mi.SetTransform (iflow->mesh_index, xfrm);
                        if (LXx_FAIL (rc))
                                return rc;
                }
                return LXe_OK;
        }

                LxResult
        minf_MeshChange (
                unsigned		 index,
                LxResult		 change)
                                LXx_OVERRIDE
        {
                FlowList		&flst = GetFlowList (index);
                FlowList_Itr		 iflow;
                LxResult		 rc;

                if (change != LXeDEFORM_IDENTICAL && change != LXeDEFORM_NEWOFFSET)
                        InvalidatePoints ();

                for (iflow = flst.begin (); iflow != flst.end (); iflow ++) {
                        if (!iflow->src_index)
                                continue;

                        if (!ifc_array[iflow->src_index].mi.test ())
                                continue;

                        rc = ifc_array[iflow->src_index].mi.MeshChange (iflow->mesh_index, change);
                        if (LXx_FAIL (rc))
                                return rc;
                }
                return LXe_OK;
        }

                LxResult
        iinf_AllowTransform (
                unsigned		 index,
                unsigned		*flags)
                                LXx_OVERRIDE
        {
                flags[0] = LXfITEMINF_POSITION | LXfITEMINF_ROTATION | LXfITEMINF_SCALE | LXfITEMINF_PROBEWEIGHTS;
                return LXe_OK;
        }

                unsigned
        dinf_Flags ()
                                LXx_OVERRIDE
        {
                return LXfDEFORMER_NO_OFFSET | (vc_linear ? LXfDEFORMER_USE_LINEAR : 0);
        }


        /*
         * Point cache. This map holds the CPartElements class for each target mesh.
         * We clear it on invalidation so the existence of an entry can be used
         * as a test for validity. To be really tricky, we keep the element list
         * for items as index ~0.
         */
        std::map<unsigned,CPartElements>	mesh_listMap;

                void
        InvalidatePoints ()
        {
                log_S.DebugOutSys (0, "time", "SLOW: flushing GI points\n");
                mesh_listMap.clear ();
        }

        /*
         * Visitor which clears marks on vertices, or set marks on the vertices of
         * tagged polygons.
         */
        class CMarkingVisitor
                        : public CLxImpl_AbstractVisitor
        {
            public:
                CLxUser_Point		*pnt;
                CLxUser_Polygon		 pol;
                CLxUser_StringTag	 tag;
                LXtMarkMode		 mask;
                LXtID4			 type;
                const char		*name;
                bool			 clear;

                        LxResult
                Evaluate ()
                {
                        if (clear) {
                                pnt->SetMarks (mask);
                                return LXe_OK;
                        }

                        const char *val = tag.Value (type);
                        if (val && !strcmp (val, name)) {
                                unsigned	n, i;

                                pol.VertexCount (&n);
                                for (i = 0; i < n; i++) {
                                        pnt->SelectPolygonVertex (pol.ID (), i);
                                        pnt->SetMarks (mask);
                                }
                        }

                        return LXe_OK;
                }
        };

        /*
         * In the PTAG modes we mark the vertices which match the PTAG. First we
         * clear the USER1 mark on all points, then we set it on the vertices of
         * polygons matching the tag.
         */
                LXtMarkMode
        MarkPoints (
                CLxUser_Mesh		&mesh,
                CLxUser_Point		&point)
        {
                CLxUser_MeshService	 mS;
                CMarkingVisitor		 mark;

                mark.pnt = &point;
                mark.pol.fromMesh (mesh);
                mark.tag.set (mark.pol);

                if (vc_type == TYPEi_MATERIAL)
                        mark.type = LXi_PTAG_MATR;
                else if (vc_type == TYPEi_PART)
                        mark.type = LXi_PTAG_PART;
                else
                        mark.type = LXi_PTAG_PICK;	// TODO: logic wrong for this case

                mark.clear = true;
                mark.mask  = mS.ClearMode ("user1");
                mark.pnt->Enum (&mark);

                mark.clear = false;
                mark.name  = vc_name.c_str ();
                mark.mask  = mS.SetMode   ("user1");
                mark.pol.Enum (&mark);

                return mark.mask;
        }

        /*
         * These two visitors add points to the mesh point object. This first
         * one operates on points enumeration directly, so the segment is always 0.
         */
        class CPointEnumVisitor
                        : public CLxImpl_AbstractVisitor
        {
            public:
                CPartElements		*pe;
                CLxUser_Point		 point;
                LXtMarkMode		 visible;

                CPointEnumVisitor ()
                {
                        CLxUser_MeshService mS;

                        visible = mS.ClearMode ("hide");
                }

                        LxResult
                Evaluate ()
                {
                        if (point.TestMarks (visible) == LXe_TRUE)
                                pe->Insert((LXtDeformElt) point.ID (), 0);

                        return LXe_OK;
                }
        };

        /*
         * This one operates on points from a flow-through mesh influence.
         */
        class CPartitionEnumVisitor
                        : public CLxImpl_AbstractVisitor
        {
            public:
                CPartElements		*pe;
                CLxUser_Deformer	*def;

                        LxResult
                Evaluate ()
                {
                        LXtDeformElt		 elt;
                        unsigned		 segment;

                        elt = def->Element (&segment);
                        pe->Insert (elt, segment);
                        return LXe_OK;
                }
        };

        /*
         * Validate the point cache for a given mesh index. If already valid we
         * just return.
         *
         * For each flow in the flow list we gather the points using the visitor.
         * For this item itself we have to enumerate the affected points.
         */
                CPartElements *
        ValidatePoints (
                unsigned		 index)
        {
                if (mesh_listMap.find (index) != mesh_listMap.end ())
                        return &(mesh_listMap[index]);

                CPartElements		*pe = &(mesh_listMap[index]);
                FlowList		&flst = GetFlowList (index);
                FlowList_Itr		 iflow;

                for (iflow = flst.begin (); iflow != flst.end (); iflow ++) {

                        if (iflow->src_index) {
                                CPartitionEnumVisitor	 vis;

                                pe->AddSource (iflow->src_index, iflow->part_index, ifc_array[iflow->src_index].di);

                                vis.pe  = pe;
                                vis.def = &ifc_array[iflow->src_index].di;
                                if (vis.def->test ())
                                        vis.def->EnumPartition (iflow->part_index, &vis);

                                continue;
                        }

                        if (!valid_mesh_partition (index))
                                continue;

                        CLxUser_Mesh		&mesh = mesh_array[index];
                        CPointEnumVisitor	 vis;
                        CLxUser_MeshMap		 map;

                        pe->NullSource ();

                        vis.pe = pe;
                        vis.point.fromMesh (mesh);

                        switch (vc_type) {
                            case TYPEi_ALL:
                                vis.point.Enum (&vis);
                                break;

                            case TYPEi_WEIGHT:
                            case TYPEi_PICK:
                                map.fromMesh (mesh);
                                map.SelectByName ((vc_type == TYPEi_WEIGHT) ? LXi_VMAP_WEIGHT : LXi_VMAP_PICK, vc_name.c_str ());
                                map.EnumContents (&vis, vis.point);
                                break;

                            case TYPEi_MATERIAL:
                            case TYPEi_PART:
                            case TYPEi_PSELSET:
                                vis.point.Enum (&vis, MarkPoints (mesh, vis.point));
                                break;
                        }
                }

                return pe;
        }

        /*
         * Validate the cache for items. If already valid we just return.
         * For each flow in the flow list we gather the elements using the visitor.
         */
                CPartElements *
        ValidateItems ()
        {
                if (mesh_listMap.find (~0) != mesh_listMap.end ())
                        return &(mesh_listMap[~0]);

                CPartElements		*pe = &(mesh_listMap[~0]);
                FlowList_Itr		 iflow;

                for (iflow = dp->item_flow.begin (); iflow != dp->item_flow.end (); iflow ++) {

                        CPartitionEnumVisitor	 vis;

                        pe->AddSource (iflow->src_index, iflow->part_index, ifc_array[iflow->src_index].di);

                        vis.pe  = pe;
                        vis.def = &ifc_array[iflow->src_index].di;
                        if (vis.def->test ())
                                vis.def->EnumPartition (iflow->part_index, &vis);
                }

                return pe;
        }


        /*
         * Deformation evaluation.
         */
        bool			 cur_isItem;	// current partition is for locators
        unsigned		 cur_mesh;	// current mesh partition (if not)
        LXtMeshMapID		 cur_map;	// current weight map in cur_mesh
        CLxUser_Point		 cur_point;	// current point in the mesh
        CPartElements		*cur_pe;	// current mesh points

                unsigned
        dinf_PartitionCount ()
                                LXx_OVERRIDE
        {
                return dp->mesh_items.size () + (dp->has_items ? 1 : 0);
        }

                void
        SetPartition (
                unsigned		 part)
        {
                cur_point.clear ();

                if (dp->has_items) {
                        if (part == 0) {
                                cur_isItem = true;
                                cur_pe = ValidateItems ();
                                return;
                        }

                        part--;
                }

                cur_isItem = false;
                cur_mesh   = part;
                cur_pe     = ValidatePoints (part);
                cur_map    = 0;

                if (vc_type == TYPEi_WEIGHT && vc_name.length () && valid_mesh_partition (part))
                {
                        CLxUser_MeshMap		 map;

                        lx_err::check (map.fromMesh (mesh_array[part]));
                        lx_err::check (map.SelectByName (LXi_VMAP_WEIGHT, vc_name.c_str ()));
                        cur_map = map.ID ();

                        if (cur_map)
                                cur_point.fromMesh (mesh_array[part]);
                }
        }

                LxResult
        dinf_EnumeratePartition (
                ILxUnknownID		 visitor,
                unsigned		 part)
                                LXx_OVERRIDE
        {
                CLxUser_Visitor		 vis (visitor);

                dinf_SetPartition (part);
                return cur_pe->Enumerate (vis);
        }

                LXtDeformElt
        dinf_Element (
                unsigned		*segment)
                                LXx_OVERRIDE
        {
                return cur_pe->EnumElement (segment);
        }

                LxResult
        dinf_SetPartition (
                unsigned		 part)
                                LXx_OVERRIDE
        {
                SetPartition (part);
                cur_pe->SetPartition ();
                return LXe_OK;
        }

                float
        dinf_Weight (
                LXtDeformElt		 elt,
                const LXtFVector	 pos)
                                LXx_OVERRIDE
        {
                unsigned		 src;

                src = cur_pe->SourceFromElement (elt);
                if (src)
                        return ifc_array[src].di.Weight (elt, pos);

                if (!cur_map || cur_isItem)
                        return 1.0;

                float			 w;
                LxResult		 rc;

                mux_point.Enter ();
                cur_point.Select ((LXtPointID) elt);
                rc = cur_point.MapValue (cur_map, &w);
                mux_point.Leave ();

                if (rc == LXe_TRUE)
                        return w;
                else
                        return 0.0;
        }

                LxResult
        dinf_WeightRun (
                unsigned		 chunk,
                const LXtDeformElt	*elt,
                const float	       **pos,
                float			*weight,
                unsigned		 num)
                                LXx_OVERRIDE
        {
                if (cur_isItem)
                        return LXe_NOTIMPL;

                unsigned		 src, segment;

                src = cur_pe->SourceFromChunk (chunk, &segment);
                if (src) {
                        CLxUser_Deformer	&di = ifc_array[src].di;
                        LXtFVector		 tmp;
                        LxResult		 rc;

                        rc = di.WeightRun (segment, elt, pos, weight, num);
                        if (LXx_OK (rc))
                                return rc;

                        for (unsigned i = 0; i < num; i++) {
                                lxsimd::VarrayGet (pos, tmp, i);
                                weight[i] = di.Weight (elt[i], tmp);
                        }

                } else if (cur_map || cur_isItem) {
                        CLxUser_Point		 pt;

                        cur_point.duplicate (pt);
                        memset (weight, 0, sizeof (float) * num);

                        for (unsigned i = 0; i < num; i++) {
                                pt.Select ((LXtPointID) elt[i]);
                                pt.MapValue (cur_map, &weight[i]);
                        }
                } else {
                        for (unsigned i = 0; i < num; i++)
                                weight[i] = 1.0;
                }

                return LXe_OK;
        }


        /*
         * Object management. We hold on to our own spawner, and only add it to
         * the global table so it'll be freed if the plug-in is unloaded. Static
         * methods provide allocation, casting and access to the evalauted
         * deformer for a given item.
         */
        static CLxPolymorph<CDeformer>	*_spawn;

                static void
        initialize ()
        {
                _spawn = new CLxPolymorph<CDeformer>;
                _spawn->AddInterface (new CLxIfc_Deformer     <CDeformer>);
                _spawn->AddInterface (new CLxIfc_MeshInfluence<CDeformer>);
                _spawn->AddInterface (new CLxIfc_ItemInfluence<CDeformer>);
                lx::AddSpawner (SPWNAME_DEFORMER, _spawn);
        }

                static CDeformer *
        Alloc (
                ILxUnknownID		&obj)
        {
                return _spawn->Alloc (obj);
        }

                static CDeformer *
        Cast (
                ILxUnknownID		 obj)
        {
                return _spawn->Cast (obj);
        }
};

CLxPolymorph<CDeformer> *	CDeformer::_spawn;	// C++ is Weird...



/*
 * -------------------------------------------------------
 *
 * The instance implements the interfaces for the influence item. Since most
 * of the work is done by the deformer, the instance really just has to describe
 * the deformer in high-level terms.
 */
class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_MeshInfluence,
                public CLxImpl_ItemInfluence,
                public CLxImpl_WeightMapDeformerItem
{
    public:
        static std::set<CInstance *>		 all_inst;

                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CInstance>;
                srv->AddInterface (new CLxIfc_PackageInstance      <CInstance>);
                srv->AddInterface (new CLxIfc_MeshInfluence        <CInstance>);
                srv->AddInterface (new CLxIfc_ItemInfluence        <CInstance>);
                srv->AddInterface (new CLxIfc_WeightMapDeformerItem<CInstance>);
                lx::AddSpawner (SPWNAME_INSTANCE, srv);
        }

        CLxUser_Item		 m_item;

        /*
         * Remember ourselves.
         */
                LxResult
        pins_Initialize (
                ILxUnknownID		 item,
                ILxUnknownID		 super)
                                LXx_OVERRIDE
        {
                m_item.set (item);
                cur_item = 0;
                all_inst.insert (this);
                return LXe_OK;
        }

                void
        pins_Cleanup (void)
                                LXx_OVERRIDE
        {
                all_inst.erase (this);
                m_item.clear ();
        }

        /*
         * Try to provide a name that describes the target deformation as much
         * as possible.
         */
        CLxUser_DeformerService	 def_S;
        CLxUser_SceneService	 scene_S;
        CLxUser_ChannelUIService chan_S;
        CLxUser_MessageService	 msg_S;
        CLxUser_ValueService	 val_S;

                LxResult
        pins_SynthName (
                char			*buf,
                unsigned		 len)
                                LXx_OVERRIDE
        {
                CLxUser_ChannelRead	 chan;
                CLxUser_Message		 msg;
                CLxUser_Value		 strVal;
                CLxUser_Item		 def;
                const char		*sptr;
                std::string		 key, name, abbrev;
                int			 type;
                bool			 isLoc, hasName;

                if (!def_S.GetDeformerDeformationItem (m_item, def, isLoc))
                        return LXe_NOTIMPL;

                chan.from (m_item);
                type = chan.IValue (m_item, Cs_TYPE);
                val_S.EncodeHint (type, hint_Type, key);
                key = "syn_" + key;

                scene_S.ItemTypeName (def.Type (), &sptr);
                if (!lx::GetMessageText (abbrev, sptr, "deformShort")) {
                        chan_S.ItemTypeName (def.Type (), 1, &sptr);
                        abbrev = sptr;
                }

                hasName = false;
                if (type != TYPEi_ALL) {
                        hasName = true;
                        if (chan.Object (m_item, Cs_NAME, strVal))
                                strVal.String (name);
                        else
                                lx::CommonMessage (name, 125);

                        if (type == TYPEi_WEIGHT) {
                                std::string smap (LXsVMAP_ITEMPREFIX);
                                smap += m_item.IdentPtr ();
                                if (smap == name) {
                                        key += "_self";
                                        hasName = false;
                                } else {
                                        int n = strlen (LXsVMAP_ITEMPREFIX);
                                        if (name.compare (0, n, LXsVMAP_ITEMPREFIX) == 0) {
                                                CLxUser_Scene scene;
                                                CLxUser_Item wc;

                                                scene.from (m_item);
                                                smap = name.substr (n);
                                                if (scene.GetItemByIdent (smap.c_str (), wc))
                                                        wc.GetUniqueName (name);
                                        }
                                }
                        }
                }

                msg_S.NewMessage (msg);
                msg.SetMsg (SRVNAME_ITEMTYPE, key.c_str ());
                msg.SetArg (1, abbrev.c_str ());
                if (hasName)
                        msg.SetArg (2, name.c_str ());

                return msg_S.MessageText (msg, buf, len);
        }

        /*
         * The MeshInfluence and ItemInfluence interfaces list the target items
         * using a cached mappings object. This has to be rebuilt anytime the
         * state changes, which is managed by the package.
         */
        CDeformerMappings		*def_map;

        CInstance ()
        {
                def_map = 0;
        }

        ~CInstance ()
        {
                InvalidateMappings ();
        }

                void
        ValidateMappings ()
        {
                if (!def_map)
                        def_map = new CDeformerMappings (m_item);
        }

                void
        InvalidateMappings ()
        {
                if (def_map) {
                        CDeformerMappings::Release (def_map);
                        def_map = 0;
                }
        }

                static void
        InvalidateAll ()
        {
                std::set<CInstance *>::iterator	 cit;

                for (cit = all_inst.begin (); cit != all_inst.end (); cit++)
                        (*cit)->InvalidateMappings ();
        }

                unsigned
        minf_MeshCount ()
                                LXx_OVERRIDE
        {
                ValidateMappings ();
                return def_map -> mesh_items.size ();
        }

                LxResult
        minf_MeshByIndex (
                unsigned		 index,
                void		       **ppvObj)
                                LXx_OVERRIDE
        {
                ValidateMappings ();
                return def_map -> mesh_items[index].get (ppvObj);
        }

                unsigned
        minf_PartitionIndex (
                unsigned		 index)
                                LXx_OVERRIDE
        {
                return index + (iinf_HasItems () == LXe_TRUE ? 1 : 0);
        }

        /*
         * Listing items is done by enumeration.
         */
                LxResult
        iinf_HasItems ()
                                LXx_OVERRIDE
        {
                ValidateMappings ();
                return def_map -> has_items ? LXe_TRUE : LXe_FALSE;
        }

        class CSrcItemsEnumVisitor
                        : public CLxImpl_AbstractVisitor
        {
            public:
                CLxUser_ItemInfluence	 ii;
                std::set<CLxUser_Item>	 items;

                        LxResult
                Evaluate ()
                {
                        CLxUser_Item	 item;

                        if (ii.CurItem (item))
                                items.insert (item);

                        return LXe_OK;
                }
        };

        const CLxUser_Item		*cur_item;

                LxResult
        iinf_Enumerate (
                ILxUnknownID		 visitor)
                                LXx_OVERRIDE
        {
                CSrcItemsEnumVisitor	 vis;
                CDeformerMappings::FlowList_Itr		 iflow;

                ValidateMappings ();

                for (iflow = def_map->item_flow.begin (); iflow != def_map->item_flow.end (); iflow ++) {
                        vis.ii.set (def_map->def_items[iflow->src_index]);
                        vis.ii.Enum (&vis);
                }

                std::set<CLxUser_Item>::iterator	 iit;
                CLxUser_Visitor		 other (visitor);
                LxResult		 rc = LXe_OK;

                for (iit = vis.items.begin (); iit != vis.items.end (); iit ++) {
                        cur_item = &(*iit);
                        rc = other.Evaluate ();
                        if (rc != LXe_OK)
                                break;
                }

                cur_item = 0;
                return rc;
        }

                LxResult
        iinf_GetItem (
                void		       **ppvObj)
                                LXx_OVERRIDE
        {
                if (cur_item)
                        return cur_item->get (ppvObj);
                else
                        return LXe_OUTOFBOUNDS;
        }

        /*
         * Return the weight map name for this item, if any. If we don't have a
         * local one we try to get exactly one by flow-through.
         */
                LxResult
        wmd_GetMapName (
                ILxUnknownID		 cr,
                char			*buf,
                unsigned		 len)
                                LXx_OVERRIDE
        {
                CLxUser_ChannelRead	 chan (cr);
                std::string		 str;

                if (  chan.IValue    (m_item, Cs_TYPE) == TYPEi_WEIGHT
                  &&  chan.GetString (m_item, Cs_NAME, str))
                {
                        return lx::StringOut (str, buf, len);
                }

                ValidateMappings ();

                if (def_map->def_items.size () == 2) {
                        CLxUser_WeightMapDeformerItem wmd (def_map->def_items[1]);

                        if (wmd.test ())
                                return wmd.GetMapName (cr, buf, len);
                }

                return LXe_NOTFOUND;
        }
};

std::set<CInstance *>		 CInstance::all_inst;	// Weird, weird, weird...



/*
 * -------------------------------------------------------
 *
 * The Package implements the item type itself, defining the channels and
 * spawning the instances.
 */
class CPackage :
                public CLxImpl_Package,
                public CLxImpl_SceneItemListener
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CPackage>;
                srv->AddInterface (new CLxIfc_Package          <CPackage>);
                srv->AddInterface (new CLxIfc_SceneItemListener<CPackage>);
                srv->AddInterface (new CLxIfc_StaticDesc       <CPackage>);
                lx::AddServer (SRVNAME_ITEMTYPE, srv);
        }

        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 inst_spawn;

        CPackage () : inst_spawn (SPWNAME_INSTANCE) {}

                LxResult
        pkg_SetupChannels (
                ILxUnknownID		 addChan)
                                LXx_OVERRIDE
        {
                CLxUser_AddChannel	 ac (addChan);

                ac.NewChannel  (Cs_MESHINF,	LXsTYPE_OBJREF);
                ac.SetInternal ();

                ac.NewChannel  (Cs_ENABLE,	LXsTYPE_BOOLEAN);
                ac.SetDefault  (0.0, 1);

                ac.NewChannel  (Cs_INTERPOLATION, LXsTYPE_INTEGER);
                ac.SetDefault  (0.0, INTERPi_LOCAL);
                ac.SetHint     (hint_Interp);

                ac.NewChannel  (Cs_TYPE,	LXsTYPE_INTEGER);
                ac.SetDefault  (0.0, TYPEi_ALL);
                ac.SetHint     (hint_Type);

                ac.NewChannel  (Cs_NAME,	LXsTYPE_VERTMAPNAME);

                return LXe_OK;
        }

                LxResult
        pkg_TestInterface (
                const LXtGUID		*guid)
                                LXx_OVERRIDE
        {
                return inst_spawn.TestInterfaceRC (guid);
        }

                LxResult
        pkg_Attach (
                void		       **ppvObj)
                                LXx_OVERRIDE
        {
                inst_spawn.Alloc (ppvObj);
                return LXe_OK;
        }

        /*
         * We watch for any event that could invalidate our state. Since there
         * may be long chains of relations affecting the flow-through of weights,
         * we invalidate all cached mappings rather frequently.
         */
                void
        sil_ChannelValue (
                const char		*action,
                ILxUnknownID		 itemObj,
                unsigned		 channel)
        {
                CLxUser_Item		 item (itemObj);
                bool			 any = false;

                if (item.IsA (cit_genInf)) {
                        item.InvalidateName ();
                        any = true;
                }

                if (item.IsA (cit_weightCont)) {
                        CLxUser_Scene	 scene (item);

                        scene.EvalModInvalidate (SRVNAME_MODIFIER);
                        any = true;
                }

                if (any)
                        CInstance::InvalidateAll ();
        }

                void
        sil_ItemRemove (
                ILxUnknownID		 itemObj)
        {
                CInstance::InvalidateAll ();
        }

                void
        GraphChange (
                const char		*graph,
                ILxUnknownID		 item1,
                ILxUnknownID		 item2)
        {
                if (strcmp (graph, LXsGRAPH_DEFORMERS))
                        return;

                CInstance::InvalidateAll ();

                DeformLinkChange (item1);
                DeformLinkChange (item2);
        }

                void
        DeformLinkChange (
                ILxUnknownID		 itemObj)
        {
                CLxUser_Item		 item (itemObj);

                if (item.IsA (cit_genInf))
                        item.InvalidateName ();
        }

                void
        sil_LinkAdd (
                const char		*graph,
                ILxUnknownID		 itemFrom,
                ILxUnknownID		 itemTo)
        {
                GraphChange (graph, itemFrom, itemTo);
        }

                void
        sil_LinkRemAfter (
                const char		*graph,
                ILxUnknownID		 itemFrom,
                ILxUnknownID		 itemTo)
        {
                GraphChange (graph, itemFrom, itemTo);
        }

                void
        sil_LinkSet (
                const char		*graph,
                ILxUnknownID		 itemFrom,
                ILxUnknownID		 itemTo)
        {
                GraphChange (graph, itemFrom, itemTo);
        }
};

/*
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,		"."		},
        { LXsPKG_DEFORMER_CHANNEL,	 Cs_MESHINF	},
        { LXsPKG_DEFORMER_FLAGS,	"+O"		},
        { LXsPKG_DEFORMER_CREATECMD,	 CMDNAME_CREATE	},
        { 0 }
};



/*
 * -------------------------------------------------------
 *
 * The modifier operates on all items of this type, and sets the mesh influence
 * channel to an object allocated using the input parameters for the modifier.
 * When created we store the list of affected meshes and acess the deformer
 * channel for read/write. If the mesh list changes we ditch this modifier elt
 * and get a new one. Evaluation simply spawns the appropriate object.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        class ResultCache : public CLxObject
        {
            public:
                LxResult	 result;
        };

        CLxUser_DeformerService	 d_S;
        CDeformerMappings	*def_local;
        unsigned		 out_index;
        CLxSpawner<CInstance>	 inst_spawn;

        CModifierElement (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
                         : inst_spawn (SPWNAME_INSTANCE)
        {
                out_index = eval.AddChan (item, Cs_MESHINF, LXfECHAN_WRITE);

                def_local = new CDeformerMappings (item);
                def_local->EvalAlloc (eval);
        }

                bool
        Test (
                ILxUnknownID		 item)
                                                LXx_OVERRIDE
        {
                CLxUser_MeshInfluence	 mi (item);
                CInstance		*inst = inst_spawn.Cast (mi);

                inst->ValidateMappings ();

                return def_local->IsSame (*inst->def_map);
        }

                CLxObject *
        Cache ()
                                                LXx_OVERRIDE
        {
                ResultCache		*cache;

                cache = new ResultCache;
                cache->result = LXe_OK;
                return cache;
        }

                LxResult
        EvalCache (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr,
                CLxObject		*cObj,
                bool			 isPrev)
                                                LXx_OVERRIDE
        {
                ResultCache		*cache = dynamic_cast<ResultCache*> (cObj);
                CDeformer		*defEval;
                CLxUser_ValueReference	 ref;
                ILxUnknownID		 obj;
                LxResult		 rc;

                defEval = CDeformer::Alloc (obj);

                attr.ObjectRW (out_index, ref);
                ref.SetObject (obj);
                lx::UnkRelease (obj);

                defEval->SetMappings (def_local);
                defEval->EvalEval (*def_local, attr);

                rc = isPrev ? cache->result : LXe_OK;
                cache->result = LXeDEFORM_IDENTICAL;
                return rc;
        }

                bool
        Validate (
                CLxObject		*cObj,
                CLxUser_Item		&item,
                unsigned		 chan,
                LxResult		 rc)
                                                LXx_OVERRIDE
        {
                ResultCache		*cache = dynamic_cast<ResultCache*> (cObj);

                cache->result = d_S.MergeChangeState (cache->result, rc);
                return true;
        }
};


class CModifier :
                public CLxItemModifierServer
{
    public:
                static void
        initialize ()
        {
                CLxExport_ItemModifierServer<CModifier> (SRVNAME_MODIFIER);
        }

                const char *
        ItemType ()
                                LXx_OVERRIDE
        {
                return SRVNAME_ITEMTYPE;
        }

                const char *
        GraphNames ()
                                LXx_OVERRIDE
        {
                return LXsGRAPH_DEFORMERS;
        }

                CLxItemModifierElement *
        Alloc (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
                                LXx_OVERRIDE
        {
                return new CModifierElement (eval, item);
        }
};


/*
 * -------------------------------------------------------
 *
 * Create command. Create the container and fire the add weights command if
 * possible.
 */
class CCmdCreate
                : public CLxBasicCommand,
                  public CLxVertexMapSelection
{
    public:
                static void
        initialize ()
        {
                CLxExport_BasicCommand<CCmdCreate> (CMDNAME_CREATE);
        }

        CLxSceneSelection		 scene_sel;
        CLxItemSelection		 item_sel;

                int
        basic_CmdFlags ()
                                LXx_OVERRIDE
        {
                return LXfCMD_MODEL | LXfCMD_UNDO;
        }

                void
        cmd_Execute (
                unsigned int		 flags)
                                LXx_OVERRIDE
        {
                CLxUser_Scene		 scene;
                CLxUser_Item		 item;
                std::string		 name;

                if (!scene_sel.Get (scene))
                        throw (LXe_NOTFOUND);

                if (!scene.NewItem (cit_genInf, item))
                        throw (LXe_FAILED);

                if (!First (name))
                        return;

                CLxUser_ChannelWrite	 write;

                write.setupFrom (scene);
                write.Set (item, Cs_TYPE, TYPEi_WEIGHT);
                write.Set (item, Cs_NAME, name.c_str ());
        }

                bool
        Include (
                LXtID4			 type)
                                LXx_OVERRIDE
        {
                return (type == LXi_VMAP_WEIGHT);
        }
};


/*
 * -------------------------------------------------------
 * Utility classes for building the popup. They all use the unique name list
 * which is a wrapper around a string list which keeps the names unique.
 */
class CUniqueNameList
{
    public:
        std::vector<std::string>	&list;
        std::set<std::string>		 already;

        CUniqueNameList (std::vector<std::string> &x) : list (x) {}

                void
        Append (
                const std::string	&name)
        {
                if (already.find (name) == already.end ()) {
                        list.push_back (name);
                        already.insert (name);
                }
        }
};

/*
 * Mesh map enumeration visitor that records map names in the list.
 */
class CMapNameVisitor
                : public CLxImpl_AbstractVisitor
{
    public:
        CUniqueNameList		&list;
        CLxUser_MeshMap		 map;

        CMapNameVisitor (CUniqueNameList &x) : list (x) {}

                LxResult
        Evaluate ()
        {
                const char *	 mapName;

                if (LXx_OK (map.Name (&mapName)) && mapName)
                        list.Append (std::string (mapName));

                return LXe_OK;
        }
};

/*
 * Polygon enumeration visitor that records tag values in the list.
 */
class CPolyTagVisitor
                : public CLxImpl_AbstractVisitor
{
    public:
        CUniqueNameList		&list;
        CLxUser_StringTag	 tag;
        LXtID4			 type;

        CPolyTagVisitor (CUniqueNameList &x) : list (x) {}

                LxResult
        Evaluate ()
        {
                const char *	 val;

                val = tag.Value (type);
                if (val)
                        list.Append (std::string (val));

                return LXe_OK;
        }
};


/*
 * -------------------------------------------------------
 *
 * SetName command. Query command to display the name choices as a popup.
 */
#define ARGi_NAME		 0

class CCmdSetName
                : public CLxBasicCommand
{
    public:
                static void
        initialize ()
        {
                CLxExport_BasicCommand<CCmdSetName> (CMDNAME_SETNAME);
        }

        /*
         * The item selection type we're interested in is our own.
         */
        CLxItemSelectionType	 sel_geni;
        std::string		 spc_none;

        /*
         * One argument: ?name:string
         */
        CCmdSetName ()
                :
                sel_geni (SRVNAME_ITEMTYPE)
        {
                lx::CommonMessage (spc_none, 125);	// looked in commsg.cfg to find that

                dyna_Add ("name", LXsTYPE_STRING);
                basic_SetFlags (ARGi_NAME, LXfCMDARG_QUERY);

                idx_type = idx_name = -1;
        }

                int
        basic_CmdFlags ()
                                                LXx_OVERRIDE
        {
                return LXfCMD_MODEL | LXfCMD_UNDO;
        }

        /*
         * We use a common channel read, and assume that all the items processed
         * in the selection are from the same scene. When we set the read object
         * we record the channel indicies.
         */
        CLxUser_ChannelRead	 read_chan;
        int			 idx_type, idx_name;

                void
        InitRead (
                CLxUser_Item		&item)
        {
                if (!read_chan.test ())
                        read_chan.from (item);

                if (idx_type == -1)
                        idx_type = item.ChannelIndex (LXsICHAN_GENINFLUENCE_TYPE);

                if (idx_name == -1)
                        idx_name = item.ChannelIndex (LXsICHAN_GENINFLUENCE_NAME);
        }

        /*
         * We have to limit the command to operate on items that have the same
         * type setting in order for the popup and editing the value to make
         * sense. This comes from the first selected item of our type.
         */
                int
        CurrentType ()
        {
                CLxUser_Item		 item;
                int			 type;

                if (!sel_geni.GetFirst (item))
                        return -1;

                InitRead (item);
                type = read_chan.IValue (item, idx_type);
                read_chan.clear ();
                return type;
        }

                bool
        basic_ButtonName (
                std::string		&name)
                                                LXx_OVERRIDE
        {
                int			 current = CurrentType ();
                CLxUser_ValueService	 vsrv;
                std::string		 key;

                vsrv.EncodeHint (current, hint_Type, key);
                key = "name_" + key;

                return lx::GetMessageText (name, SRVNAME_ITEMTYPE, key);
        }

        /*
         * Current type has to be something that can set the name in order to
         * enable the command.
         */
                bool
        basic_Enable (
                CLxUser_Message		&msg)
                                                LXx_OVERRIDE
        {
                int			 current = CurrentType ();

                return (current != TYPEi_ALL) && (current != -1);
        }

        /*
         * The disable state depends on the item selection and on type channel
         * changes.
         */
                bool
        basic_Notifier	(
                int			 index,
                std::string		&name,
                std::string		&args)
                                                LXx_OVERRIDE
        {
                if (index == 0) {
                        name = LXsNOTIFIER_SELECT;
                        args = "item +dlv";
                        return true;
                }
                if (index == 1) {
                        name = LXsNOTIFIER_CHANNEL;
                        args = "+dl " Cs_TYPE " " SRVNAME_ITEMTYPE;
                        return true;
                }

                return false;
        }

        /*
         * Building the popup list is done by getting all the input meshes for
         * the selected general influences, and collecting all the names from
         * them of the right type. We also add "(none)" at the top.
         */
                void
        CollectMaps (
                CUniqueNameList		&names,
                CLxUser_Mesh		&mesh,
                LXtID4			 type)
        {
                CMapNameVisitor		 vis (names);

                vis.map.fromMesh (mesh);
                vis.map.FilterByType (type);
                vis.map.Enum (&vis);
        }

                void
        CollectTags (
                CUniqueNameList		&names,
                CLxUser_Mesh		&mesh,
                LXtID4			 type)
        {
                CPolyTagVisitor		 vis (names);
                CLxUser_Polygon		 pol;

                pol.fromMesh (mesh);
                vis.tag.set (pol);
                vis.type = type;
                pol.Enum (&vis);
        }

                void
        GetNameList (
                std::vector<std::string> &list,
                std::vector<std::string> &user)
        {
                CUniqueNameList		 names (list);
                int			 current = CurrentType ();
                std::set<CLxUser_Item>	 meshes;
                std::set<CLxUser_Item>::iterator mit;
                CLxUser_Item		 item;
                std::string		 name;

                names.Append (spc_none);

                sel_geni.LoopInit ();
                while (sel_geni.LoopNext (item)) {
                        InitRead (item);

                        if (read_chan.IValue (item, idx_type) != current)
                                continue;

                        CDeformerMappings map (item);
                        ListIntoSet (map.mesh_items, meshes);
                }

                for (mit = meshes.begin (); mit != meshes.end (); mit++) {
                        CLxUser_Mesh		 mesh;

                        if (!read_chan.Object (*mit, LXsICHAN_MESH_MESH, mesh))
                                continue;

                        switch (current) {
                            case TYPEi_WEIGHT:
                                CollectMaps (names, mesh, LXi_VMAP_WEIGHT);
                                break;

                            case TYPEi_PICK:
                                CollectMaps (names, mesh, LXi_VMAP_PICK);
                                break;

                            case TYPEi_MATERIAL:
                                CollectTags (names, mesh, LXi_POLYTAG_MATERIAL);
                                break;

                            case TYPEi_PART:
                                CollectTags (names, mesh, LXi_POLYTAG_PART);
                                break;

                            case TYPEi_PSELSET:
                                CollectTags (names, mesh, LXi_POLYTAG_PICK);
                                break;
                        }
                }

                std::sort (list.begin () + 1, list.end ());
                read_chan.clear ();

                if (current != TYPEi_WEIGHT) {
                        user = list;
                        return;
                }

                CLxUser_ChannelUIService	 cS;
                std::vector<std::string>::iterator sit;

                user.clear ();
                for (sit = list.begin (); sit != list.end (); sit++) {
                        cS.GetMapUserName (sit->c_str (), 1, name);
                        user.push_back (name);
                }
        }

        /*
         * Querying just lists the names of the valid selected influences,
         * converting nothing to "(none)".
         */
                LxResult
        cmd_Query (
                unsigned int		 index,
                ILxUnknownID		 vaQuery)
                                                LXx_OVERRIDE
        {
                CLxUser_ValueArray	 va (vaQuery);
                int			 current = CurrentType ();
                CLxUser_Item		 item;
                std::string		 name;

                sel_geni.LoopInit ();
                while (sel_geni.LoopNext (item)) {
                        InitRead (item);

                        if (read_chan.IValue (item, idx_type) != current)
                                continue;

                        if (read_chan.GetString (item, idx_name, name) && name.length ())
                                va.Add (name.c_str ());
                        else
                                va.Add (spc_none.c_str ());
                }

                read_chan.clear ();
                return LXe_OK;
        }

        /*
         * Our popup object uses the command object to update the list.
         */
        class CNamePopup
                        : public CLxUIListPopup
        {
            public:
                CCmdSetName		*cmd;

                CNamePopup (CCmdSetName *ptr) : cmd (ptr) {}

                        void
                UpdateLists ()
                {
                        cmd->GetNameList (internal_list, user_list);
                }
        };

                CLxDynamicUIValue *
        atrui_UIValue (
                unsigned		 index)
                                                LXx_OVERRIDE
        {
                return new CNamePopup (this);
        }

        /*
         * Execute is super-simple. Just loop over the valid items and
         * set their name channel.
         */
                void
        cmd_Execute (
                unsigned		 flags)
                                                LXx_OVERRIDE
        {
                std::string		 name;

                if (!dyna_String (ARGi_NAME, name)) {
                        basic_Message () . SetCode (LXe_INVALIDARG);
                        return;
                }
                if (name == spc_none)
                        name = "";

                int			 current = CurrentType ();
                CLxUser_Item		 item;
                CLxUser_ChannelWrite	 wchan;

                sel_geni.LoopInit ();
                while (sel_geni.LoopNext (item)) {
                        InitRead (item);
                        if (!wchan.test ())
                                wchan.from (item);

                        if (read_chan.IValue (item, idx_type) != current)
                                continue;

                        wchan.Set (item, idx_name, name.c_str ());
                }

                read_chan.clear ();
        }
};



/*
 * Initialize all of our exported and spawned objects.
 */
        void
initialize ()
{
        CPackage            ::initialize ();
        CInstance           ::initialize ();
        CDeformer           ::initialize ();
        CModifier           ::initialize ();
        CCmdCreate          ::initialize ();
        CCmdSetName         ::initialize ();
        CDeformerMappings   ::initialize ();
}

        };	// END namespace



