/*
 * LX schematic module
 *
 * Copyright (c) 2008-2019 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_schematic_H
#define LX_schematic_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxSchematicConnection ** ILxSchematicConnectionID;
typedef struct vt_ILxSchematicConnection1 ** ILxSchematicConnection1ID;
typedef struct vt_ILxSchemaDest ** ILxSchemaDestID;
typedef struct vt_ILxSchematicGroup ** ILxSchematicGroupID;
typedef struct vt_ILxSchematicNode ** ILxSchematicNodeID;
typedef struct vt_ILxSchematicNodeConnection ** ILxSchematicNodeConnectionID;
typedef struct vt_ILxSchematicNodeChannel ** ILxSchematicNodeChannelID;
#include <lxcom.h>
#include <lxvalue.h>



typedef struct vt_ILxSchematicConnection {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ItemFlags) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                *flags);
                LXxMETHOD(  LxResult,
        AllowConnect) (
                LXtObjectID              self,
                LXtObjectID              from,
                LXtObjectID              to);
                LXxMETHOD(  LxResult,
        AllowConnectType) (
                LXtObjectID              self,
                LXtObjectID              to,
                unsigned int             type);
                LXxMETHOD(  LxResult,
        GraphName) (
                LXtObjectID              self,
                const char             **name);
                LXxMETHOD(  LxResult,
        Count) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                *count);

                LXxMETHOD(  LxResult,
        ByIndex) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                 index,
                void                   **ppvObj);
                LXxMETHOD(  LxResult,
        Connect) (
                LXtObjectID              self,
                LXtObjectID              from,
                LXtObjectID              to,
                int                      toIndex);

                LXxMETHOD(  LxResult,
        Disconnect) (
                LXtObjectID              self,
                LXtObjectID              from,
                LXtObjectID              to);
                LXxMETHOD(  int,
        BaseFlags) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        PerItemFlags) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                *flags);
                LXxMETHOD(  int,
        ItemFlagsValid) (
                LXtObjectID              self);
} ILxSchematicConnection;
typedef struct vt_ILxSchematicConnection1 {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ItemFlags) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                *flags);

                LXxMETHOD(  LxResult,
        AllowConnect) (
                LXtObjectID              self,
                LXtObjectID              from,
                LXtObjectID              to);

                LXxMETHOD(  LxResult,
        GraphName) (
                LXtObjectID              self,
                const char             **name);

                LXxMETHOD(  LxResult,
        Count) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                *count);

                LXxMETHOD(  LxResult,
        ByIndex) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                 index,
                void                   **ppvObj);

                LXxMETHOD(  LxResult,
        Connect) (
                LXtObjectID              self,
                LXtObjectID              from,
                LXtObjectID              to,
                int                      toIndex);

                LXxMETHOD(  LxResult,
        Disconnect) (
                LXtObjectID              self,
                LXtObjectID              from,
                LXtObjectID              to);

                LXxMETHOD(  int,
        BaseFlags) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        PerItemFlags) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                *flags);

                LXxMETHOD(  int,
        ItemFlagsValid) (
                LXtObjectID              self);
} ILxSchematicConnection1;
typedef struct vt_ILxSchemaDest {
        ILxUnknown       iunk;
                LXxMETHOD( int,
        ViewType) (
                LXtObjectID              self);
                LXxMETHOD( LxResult,
        Position) (
                LXtObjectID              self,
                LXtVector                pos);
                LXxMETHOD( LxResult,
        Group) (
                LXtObjectID              self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Item) (
                LXtObjectID              self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Node) (
                LXtObjectID              self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Channel) (
                LXtObjectID              self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Graph) (
                LXtObjectID              self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Link) (
                LXtObjectID              self,
                void                    **ppvObj);
} ILxSchemaDest;
typedef struct vt_ILxSchematicGroup {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Group) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        IsWorkspace) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        AddItem) (
                LXtObjectID               self,
                LXtObjectID               item,
                void                    **ppvObj);
                LXxMETHOD(  void,
        RemoveItem) (
                LXtObjectID              self,
                LXtObjectID              item);
                LXxMETHOD(  LxResult,
        NodeCount) (
                LXtObjectID              self,
                unsigned int            *count);
                LXxMETHOD(  LxResult,
        NodeByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        InputNode) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        OutputNode) (
                LXtObjectID               self,
                void                    **ppvObj);
} ILxSchematicGroup;
typedef struct vt_ILxSchematicNode {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Group) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Item) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        AddChannel) (
                LXtObjectID              self,
                unsigned int             index);
                LXxMETHOD(  LxResult,
        RemoveChannel) (
                LXtObjectID              self,
                unsigned int             index);
                LXxMETHOD(  LxResult,
        ChannelCount) (
                LXtObjectID              self,
                unsigned int            *count);
                LXxMETHOD(  LxResult,
        ChannelByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                unsigned int              type,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ConnectionCount) (
                LXtObjectID              self,
                unsigned int            *count);
                LXxMETHOD(  LxResult,
        ConnectionByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                unsigned int              type,
                void                    **ppvObj);
                LXxMETHOD (  LxResult,
        IsRoot) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        RootNode) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        SubNodeCount) (
                LXtObjectID              self,
                unsigned int            *count);
                LXxMETHOD(  LxResult,
        SubNodeByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Position) (
                LXtObjectID              self,
                double                  *x,
                double                  *y);
                LXxMETHOD(  LxResult,
        SetPosition) (
                LXtObjectID              self,
                double                   x,
                double                   y);
                LXxMETHOD(  LxResult,
        Size) (
                LXtObjectID              self,
                double                  *width,
                double                  *height);
                LXxMETHOD(  LxResult,
        AbsoluteSize) (
                LXtObjectID              self,
                double                  *width,
                double                  *height);
                LXxMETHOD(  LxResult,
        Expanded) (
                LXtObjectID              self);
} ILxSchematicNode;
typedef struct vt_ILxSchematicNodeConnection {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Flags) (
                LXtObjectID              self,
                unsigned int            *flags);
                LXxMETHOD(  LxResult,
        Node) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Count) (
                LXtObjectID              self,
                unsigned int            *count);
                LXxMETHOD(  LxResult,
        ByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Position) (
                LXtObjectID              self,
                unsigned int             index,
                double                  *x,
                double                  *y);
} ILxSchematicNodeConnection;
typedef struct vt_ILxSchematicNodeChannel {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Flags) (
                LXtObjectID              self,
                unsigned int            *flags);
                LXxMETHOD(  LxResult,
        Node) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Index) (
                LXtObjectID              self,
                unsigned int            *index);
                LXxMETHOD(  LxResult,
        Count) (
                LXtObjectID              self,
                unsigned int            *count);
                LXxMETHOD(  LxResult,
        ByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Position) (
                LXtObjectID              self,
                double                  *x,
                double                  *y);
} ILxSchematicNodeChannel;

#define LXfSCON_SINGLE           0x01
#define LXfSCON_MULTIPLE         0x02
#define LXfSCON_ORDERED          0x04
#define LXfSCON_REVERSE          0x08
#define LXfSCON_PERITEM          0x10
#define LXfSCON_NOLISTS          0x20

#define LXfSCON_USESERVER        0x80
#define LXu_SCHEMATICCONNECTION "7E238C0E-0D64-44ed-A780-13D25A2482D3"
#define LXa_SCHEMATICCONNECTION "schematicConnection.v2"
// [local]   ILxSchematicConnection
// [export]  ILxSchematicConnection schm
// [default] ILxSchematicConnection:BaseFlags           = 0
// [default] ILxSchematicConnection:ItemFlagsValid      = 1
// [python]  ILxSchematicConnection:ByIndex             obj Item
// [python]  ILxSchematicConnection:AllowConnect        bool
// [python]  ILxSchematicConnection:AllowConnectType    bool
#define LXu_SCHEMATICCONNECTION1        "5AC0A075-72B7-4935-8DA5-588DF7999069"
#define LXa_SCHEMATICCONNECTION1        "schematicConnection"
// [local]   ILxSchematicConnection1
// [export]  ILxSchematicConnection1 schm
// [default] ILxSchematicConnection1:BaseFlags = 0
// [default] ILxSchematicConnection1:ItemFlagsValid = 1
// [python]  ILxSchematicConnection1:ByIndex            obj Item
// [python]  ILxSchematicConnection1:AllowConnect       bool
#define LXu_SCHEMADEST                  "AA362F0B-DC2F-4480-82FF-32D38FD57F4F"
#define LXa_SCHEMADEST                  "shemaDest"
// [local]  ILxSchemaDest
// [export] ILxSchemaDest               schmd
// [python] ILxSchemaDest:Group         obj Item
// [python] ILxSchemaDest:Item          obj Item
// [python] ILxSchemaDest:Node          obj Item
enum SchemaViewTypes {
        SCHEMAVIEW_Workspace    =  0,           // schematic view of a workspace
        SCHEMAVIEW_Overview     =  1,           // Hierarchical view of an assembly or all assemblies (if Group returns NULL)
        SCHEMAVIEW_Assembly     =  2,           // schematic view of an assembly
};
#define LXu_SCHEMATICGROUP                      "FD5B73D1-C9E2-44C2-8D8D-23EE7706B3AB"
#define LXa_SCHEMATICGROUP                      "schematicgroup"
// [local]  ILxSchematicGroup
// [python] ILxSchematicGroup:Group             obj Item
// [python] ILxSchematicGroup:AddItem           obj SchematicNode
// [python] ILxSchematicGroup:NodeByIndex       obj SchematicNode
// [python] ILxSchematicGroup:InputNode         obj SchematicNode
// [python] ILxSchematicGroup:OutputNode        obj SchematicNode
// [python] ILxSchematicGroup:IsWorkspace       bool
#define LXu_SCHEMATICNODE                       "686F59FF-1E3F-4599-ADE0-E3613C483D38"
#define LXa_SCHEMATICNODE                       "schematicnode"
// [local]  ILxSchematicNode
// [const]  ILxSchematicNode:ChannelCount
// [const]  ILxSchematicNode:SubNodeCount
// [python] ILxSchematicNode:Group              obj Item
// [python] ILxSchematicNode:Item               obj Item
// [python] ILxSchematicNode:RootNode           obj SchematicNode
// [python] ILxSchematicNode:SubNodeByIndex     obj SchematicNode
// [python] ILxSchematicNode:IsRoot             bool
// [python] ILxSchematicNode:ChannelByIndex     obj SchematicNodeChannel
// [python] ILxSchematicNode:ConnectionByIndex  obj SchematicNodeConnection
// [python] ILxSchematicNode:Expanded           bool
#define LXi_SCHMNODE_INPUT       0
#define LXi_SCHMNODE_OUTPUT      1
#define LXu_SCHEMATICNODECONNECTION             "5E015AAB-E069-4676-8F04-C7C8F88181A5"
#define LXa_SCHEMATICNODECONNECTION             "schematicnodeconnection"
// [local]  ILxSchematicNodeConnection
// [const]  ILxSchematicNodeConnection:Flags
// [const]  ILxSchematicNodeConnection:Count
// [python] ILxSchematicNodeConnection:Node     obj SchematicNode
// [python] ILxSchematicNodeConnection:ByIndex  obj SchematicNodeConnection
#define LXf_SCHMNODECONN_INPUT           0x01
#define LXf_SCHMNODECONN_OUTPUT          0x02
#define LXf_SCHMNODECONN_MULTIPLE        0x04
#define LXf_SCHMNODECONN_ORDERED         0x08
#define LXf_SCHMNODECONN_EXPANDED        0x10
#define LXu_SCHEMATICNODECHANNEL                "322555CC-D635-48A4-BCDB-AE86CCFE29CF"
#define LXa_SCHEMATICNODECHANNEL                "schematicnodechannel"
// [local]  ILxSchematicNodeChannel
// [const]  ILxSchematicNodeChannel:Flags
// [const]  ILxSchematicNodeChannel:Index
// [const]  ILxSchematicNodeChannel:Count
// [python] ILxSchematicNodeChannel:Node        obj SchematicNode
// [python] ILxSchematicNodeChannel:ByIndex     obj SchematicNodeChannel
#define LXf_SCHMNODECHAN_INPUT           0x01
#define LXf_SCHMNODECHAN_OUTPUT          0x02
#define LXf_SCHMNODECHAN_MULTIPLE        0x04

 #ifdef __cplusplus
  }
 #endif
#endif

