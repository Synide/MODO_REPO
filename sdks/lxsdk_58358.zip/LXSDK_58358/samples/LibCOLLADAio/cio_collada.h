/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_COLLADA_H
#define CIO_COLLADA_H

#include "cio_element.h"

namespace cio {

class AssetElement;
class AnimationLibraryElement;
class CameraLibraryElement;
class ControllerLibraryElement;
class EffectLibraryElement;
class GeometryLibraryElement;
class ImageLibraryElement;
class LightLibraryElement;
class MaterialLibraryElement;
class NodeLibraryElement;
class ShaderNodeLibraryElement_modo401;
class VisualSceneLibraryElement;
class SceneElement;

/*
 * ---------------------------------------------------------------------------
 * The root COLLADA element.
 */
class COLLADAElement : public Element
{
        friend class AssetElement;
        friend class AnimationLibraryElement;
        friend class CameraLibraryElement;
        friend class ControllerLibraryElement;
        friend class EffectLibraryElement;
        friend class GeometryLibraryElement;
        friend class ImageLibraryElement;
        friend class LightLibraryElement;
        friend class MaterialLibraryElement;
        friend class NodeLibraryElement;
        friend class ShaderNodeLibraryElement_modo401;
        friend class VisualSceneLibraryElement;
        friend class SceneElement;

    public:
                                /*
                                 * The formattedArrays parameter is observed in
                                 * IO_MODE_SAVE mode.
                                 */
                                 COLLADAElement (
                                        IO_MODE		 ioMode,
                                        bool		 formattedArrays = true);
        virtual			~COLLADAElement ();

        bool			 HasAsset () const;
        bool			 HasAnimationLibrary () const;
        bool			 HasCameraLibrary () const;
        bool			 HasControllerLibrary () const;
        bool			 HasEffectLibrary () const;
        bool			 HasGeometryLibrary () const;
        bool			 HasImageLibrary () const;
        bool			 HasLightLibrary () const;
        bool			 HasMaterialLibrary () const;
        bool			 HasNodeLibrary () const;
        bool			 HasShaderNodeLibraryTechniqueProfile_modo401 () const;
        bool			 HasVisualSceneLibrary () const;

        bool			 HasScene () const;
        bool			 HasExtra () const;

    protected:
        bool			 LinkAsset (AssetElement &asset);
        void			 AddAsset (AssetElement &asset);

        bool			 LinkAnimationLibrary (
                                        AnimationLibraryElement &library);
        void			 AddAnimationLibrary (
                                        AnimationLibraryElement &library);

        bool			 LinkCameraLibrary (
                                        CameraLibraryElement &library);
        void			 AddCameraLibrary (
                                        CameraLibraryElement &library);

        bool			 LinkControllerLibrary (
                                        ControllerLibraryElement &library);
        void			 AddControllerLibrary (
                                        ControllerLibraryElement &library);

        bool			 LinkEffectLibrary (
                                        EffectLibraryElement &library);
        void			 AddEffectLibrary (
                                        EffectLibraryElement &library);

        bool			 LinkGeometryLibrary (
                                        GeometryLibraryElement &library);
        void			 AddGeometryLibrary (
                                        GeometryLibraryElement &library);

        bool			 LinkImageLibrary (
                                        ImageLibraryElement &library);
        void			 AddImageLibrary (
                                        ImageLibraryElement &library);

        bool			 LinkLightLibrary (
                                        LightLibraryElement &library);
        void			 AddLightLibrary (
                                        LightLibraryElement &library);

        bool			 LinkMaterialLibrary (
                                        MaterialLibraryElement &library);
        void			 AddMaterialLibrary (
                                        MaterialLibraryElement &library);

        bool			 LinkShaderNodeLibraryTechniqueProfile_modo401 (
                                        ShaderNodeLibraryElement_modo401 &library);
        void			 AddShaderNodeLibraryTechniqueProfile_modo401 (
                                        ShaderNodeLibraryElement_modo401 &library);

        bool			 LinkNodeLibrary (
                                        NodeLibraryElement &library);
        void			 AddNodeLibrary (
                                        NodeLibraryElement &library);

        bool			 LinkVisualSceneLibrary (
                                        VisualSceneLibraryElement &library);
        void			 AddVisualSceneLibrary (
                                        VisualSceneLibraryElement &library);

        bool			 LinkScene (SceneElement &scene);
        void			 AddScene (SceneElement &scene);

    private:
        struct pv_COLLADAElement	*pv;
};

} // namespace cio

#endif // CIO_COLLADA_H

