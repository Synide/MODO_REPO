/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_IMAGE_H
#define CIO_IMAGE_H

#include "cio_element.h"

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Image.
 */

class ImageLibraryElement;

class ImageElement : public Element
{
    public:
                                 ImageElement (
                                         ImageLibraryElement	&library,
                                         const std::string	&name);
                                 ImageElement (
                                         ImageLibraryElement	&library);
        virtual			~ImageElement ();

        std::string		 GetNativeFilePath () const;
        void			 SetNativeFilePath (
                                        const std::string	&path,
                                        bool			setAbsolutePath);

        std::string		 GetURI () const;
        void			 SetURI (const std::string &imageURI);

    private:
        struct pv_ImageElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Image visitor.
 */
class ImageVisitor
{
    public:
                                 ImageVisitor () {}
        virtual			~ImageVisitor () {}

        virtual bool		 VisitImage (ImageElement &image) = 0;
};

/*
 * ---------------------------------------------------------------------------
 * Image Library.
 */
 
class COLLADAElement;

class ImageLibraryElement : public Element
{
        friend class ImageElement;

    public:
                                 ImageLibraryElement (COLLADAElement &collada);
        virtual			~ImageLibraryElement ();

        void			 VisitImages (ImageVisitor *visitor);
        bool			 LinkImage (
                                        const std::string	&imageID,
                                        ImageElement		&image);

    protected:
        void			 AddImage (ImageElement &image);
};

} // namespace cio

#endif // CIO_IMAGE_H

