/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_ANIMATION_H
#define CIO_ANIMATION_H

#include "cio_element.h"
#include "cio_source.h"
#include "cio_strings.h"

#include <string>
#include <vector>

namespace cio {

class AnimationElement;
class AnimationSamplerElement;

/*
 * ---------------------------------------------------------------------------
 * Animation Channel.
 */
class AnimationChannelElement : public Element
{
    public:
                                 AnimationChannelElement (
                                        AnimationElement		&animation,
                                        const AnimationSamplerElement	&sampler,
                                        const std::string		&itemID,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName,
                                        const std::string		&componentName,
                                        const std::string		&axisName,
                                        bool				 appendAxisToTargetTransformName);

                                 AnimationChannelElement (
                                        AnimationElement		&animation,
                                        const AnimationSamplerElement	&sampler,
                                        const std::string		&itemID,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&paramName);

                                 AnimationChannelElement (
                                        AnimationElement		&animation,
                                        const AnimationSamplerElement	&sampler,
                                        const std::string		&itemID,
                                        const std::string		&targetLibraryElementName);

                                 AnimationChannelElement (
                                        AnimationElement		&animation);

        virtual			~AnimationChannelElement ();

        std::string		 GetSamplerURI () const;

        std::string		 GetTarget () const;
        std::string		 GetTargetNodeID () const;
        std::string		 GetTargetParamName () const;

        bool			 LinkNextChannel (AnimationChannelElement &channel);
};

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Inputs.
 */

class AnimationSourceElement;

class AnimationSamplerInputElement : public Element
{
    public:
                                 AnimationSamplerInputElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

                                 AnimationSamplerInputElement (
                                        AnimationSamplerElement		&sampler);

        virtual			~AnimationSamplerInputElement ();

        void			 InitializeSemantic ();

        /*
         * Derived animation sampler input classes provide a specific semantic.
         */
        virtual std::string	 GetSemantic () const;

        virtual std::string	 GetSourceURI () const;

    private:
        struct pv_AnimationSamplerInputElement *pv;
};

/*
 * Animation Sampler Input for Time.
 */
class AnimationSamplerInputTimeElement : public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputTimeElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputTimeElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Ouput.
 */
class AnimationSamplerInputOutputElement : public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputOutputElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputOutputElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Interpolation.
 */
class AnimationSamplerInputInterpolationElement : public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputInterpolationElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputInterpolationElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for In-Tangent.
 */
class AnimationSamplerInputInTangentElement : public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputInTangentElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputInTangentElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for In-Tangent Output.
 *
 * Used for envelopes that contain one or more keyframes that are broken by value.
 */
class AnimationSamplerInputInTangentOutputElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputInTangentOutputElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputInTangentOutputElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for In-Tangent Slope and Weight.
 *
 * Alternative form for describing the envelope shape by direct slope and
 * weight values, instead of by the common cartesian X, Y tangent form.
 */
class AnimationSamplerInputInTangentSlopeWeightElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputInTangentSlopeWeightElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputInTangentSlopeWeightElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Out-Tangent.
 */
class AnimationSamplerInputOutTangentElement : public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputOutTangentElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputOutTangentElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Out-Tangent Output.
 *
 * Used for envelopes that contain one or more keyframes that are broken by value.
 */
class AnimationSamplerInputOutTangentOutputElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputOutTangentOutputElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputOutTangentOutputElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Out-Tangent Slope and Weight.
 *
 * Alternative form for describing the envelope shape by direct slope and
 * weight values, instead of by the common cartesian X, Y tangent form.
 */
class AnimationSamplerInputOutTangentSlopeWeightElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputOutTangentSlopeWeightElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputOutTangentSlopeWeightElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Broken Output flags.
 *
 * For each input time, indicates whether or not the output at that
 * time is broken into separate in- and out-tangent output values.
 */
class AnimationSamplerInputBrokenOutputElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputBrokenOutputElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputBrokenOutputElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Broken Output Times.
 *
 * Specifies the times at which there are broken outputs, where the output
 * value is broken into separate in- and out-tangent values.
 */
class AnimationSamplerInputBrokenOutputTimeElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputBrokenOutputTimeElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputBrokenOutputTimeElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Broken Slope flags.
 *
 * For each input time, indicates whether or not the slope
 * at that time has broken in- and out-tangent values.
 */
class AnimationSamplerInputBrokenSlopeElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputBrokenSlopeElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputBrokenSlopeElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * Animation Sampler Input for Broken Weight flags.
 *
 * For each input time, indicates whether or not the weight
 * at that time has broken in- and out-tangent values.
 */
class AnimationSamplerInputBrokenWeightElement
        :
        public AnimationSamplerInputElement
{
    public:
                                 AnimationSamplerInputBrokenWeightElement (
                                        AnimationSamplerElement		&sampler,
                                        const AnimationSourceElement	&source);

        virtual			~AnimationSamplerInputBrokenWeightElement ();

    protected:
        virtual std::string	 GetSemantic () const;
};

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler.
 */
class AnimationSamplerElement : public Element
{
        friend class AnimationChannelElement;
        friend class AnimationSamplerInputElement;

    public:
                                 AnimationSamplerElement (
                                        AnimationElement		&animation);
        virtual			~AnimationSamplerElement ();

        bool			 HasInput () const;
        bool			 LinkInput (
                                        const std::string		&semantic,
                                        AnimationSamplerInputElement	&input);

    protected:
        void			 AddAnimationSamplerInput (
                                        AnimationSamplerInputElement	&input);

private:
        struct pv_AnimationSamplerElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Animation Source.
 */

class AnimationSourceElement : public SourceElement
{
    public:
                                 AnimationSourceElement (
                                        AnimationElement	&animation,
                                        const std::string	&arrayTypeName);
                                 AnimationSourceElement (
                                        AnimationElement	&animation);
        virtual			~AnimationSourceElement ();

        typedef enum en_ArrayType {
                ARRAY_TYPE_BOOL,
                ARRAY_TYPE_INT,
                ARRAY_TYPE_FLOAT,
                ARRAY_TYPE_INTERPOLATION,
                ARRAY_TYPE_NAME
        } ArrayType;

        bool			 HasArray (
                                        ArrayType		&type,
                                        unsigned		&count);

        void			 AddInputArray (
                                        const FloatArray	&arrayValues);

        typedef enum en_InfinityBehavior {
                INFINITY_BEHAVIOR_CONSTANT,
                INFINITY_BEHAVIOR_STOP,
                INFINITY_BEHAVIOR_LINEAR,
                INFINITY_BEHAVIOR_REPEAT,
                INFINITY_BEHAVIOR_OSCILLATE,
                INFINITY_BEHAVIOR_OFFSET_REPEAT,
                INFINITY_BEHAVIOR_RESET
        } InfinityBehavior;

        bool			 GetPreInfinityBehavior (
                                        InfinityBehavior	&behavior) const;
        bool			 GetPostInfinityBehavior (
                                        InfinityBehavior	&behavior) const;

        void			 AddInputArray (
                                        const FloatArray	&arrayValues,
                                        bool			 saveModoProfile,
                                        bool			 saveMayaProfile,
                                        InfinityBehavior	 preInfinityBehavior,
                                        InfinityBehavior	 postInfinityBehavior);

        void			 AddOutputArray (
                                        const std::string	&componentName,
                                        const FloatArray	&arrayValues);

        void			 AddOutputArray (
                                        const std::string		&componentName,
                                        const math::Matrix4Array	&arrayValues);

        void			 AddTangentArray (
                                        const FloatArray	&arrayValuesA,
                                        const FloatArray	&arrayValuesB);

        bool			 LinkInterpArray (
                                        InterpArray		&arrayValues);

        void			 AddInterpArray (
                                        const InterpArray	&arrayValues);

        /*
         * Extended sampler inputs provided by modo 501.
         */
        void			 AddSlopeWeightArray (
                                        const FloatArray	&arrayValuesSlopes,
                                        const FloatArray	&arrayValuesWeights);
};

/*
 * ---------------------------------------------------------------------------
 * Animation.
 */

class AnimationLibraryElement;

class AnimationElement : public Element
{
        friend class AnimationChannelElement;
        friend class AnimationSamplerElement;
        friend class SourceElement;

    public:
        /*
         * Common profile sampler source inputs.
         */
        struct Envelope
        {
                FloatArray	 	 times;
                FloatArray	 	 outputs;
                FloatArray	 	 inTanControlX;
                FloatArray	 	 inTanControlY;
                FloatArray	 	 outTanControlX;
                FloatArray	 	 outTanControlY;
                InterpArray	 	 interpolations;

                AnimationSourceElement::InfinityBehavior preInfinityBehavior;
                AnimationSourceElement::InfinityBehavior postInfinityBehavior;
        };

        /*
         * Matrix-based linear sampler source inputs.
         */
        struct MatrixEnvelope
        {
                FloatArray		 times;
                math::Matrix4Array	 outputs;
        };

        /*
         * Extended modo 501 profile sampler source inputs.
         */
        struct Envelope_modo501
        {
                BoolArray		 brokenValues;
                FloatArray		 brokenValueTimes;
                FloatArray		 brokenInTanValues;
                FloatArray		 brokenOutTanValues;

                BoolArray		 brokenWeights;
                FloatArray		 inWeights;
                FloatArray		 outWeights;

                BoolArray		 brokenSlopes;
                FloatArray		 inSlopes;
                FloatArray		 outSlopes;
        };

                                 AnimationElement (
                                        AnimationLibraryElement		&library,
                                        const std::string		&animationID,
                                        const std::string		&componentName,
                                        const Envelope	 		&envelope,
                                        bool				 saveMayaProfile);
                                 AnimationElement (
                                        AnimationLibraryElement		&library,
                                        const std::string		&animationID,
                                        const std::string		&componentName,
                                        const Envelope	 		&envelope,
                                        const Envelope_modo501		&modoEnvelope,
                                        bool				 saveMayaProfile);
                                 AnimationElement (
                                        AnimationLibraryElement		&library,
                                        const std::string		&animationID,
                                        const MatrixEnvelope		&envelope);
                                 AnimationElement (
                                        AnimationLibraryElement	&library);

        virtual			~AnimationElement ();

        bool			 LinkNextAnimation (AnimationElement &animation);

        bool			 HasChannel () const;
        bool			 LinkFirstChannel (AnimationChannelElement &channel);

        bool			 HasSampler () const;
        bool			 LinkSampler (
                                        const std::string		&samplerID,
                                        AnimationSamplerElement		&sampler);

        bool			 LinkSource (
                                        const std::string		&sourceID,
                                        AnimationSourceElement		&source);

    protected:
        void			 AddAnimationChannel (AnimationChannelElement &channel);
        void			 AddAnimationSampler (AnimationSamplerElement &sampler);

        const AnimationSamplerElement* GetSampler () const;

        typedef enum en_Semantic {
                SEMANTIC_INPUT,
                SEMANTIC_OUTPUT,
                SEMANTIC_INTERPOLATION,
                SEMANTIC_IN_TANGENT,
                SEMANTIC_OUT_TANGENT
        } Semantic;

        void			 AddSource (SourceElement		*source);

        void			 AddSource (
                                        AnimationSourceElement		*source,
                                        Semantic			 semantic);

    private:
        struct pv_AnimationElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Parameter Animation.
 */

class ParamAnimationElement : public AnimationElement
{
    public:
                                 ParamAnimationElement (
                                        AnimationLibraryElement	&library,
                                        const std::string	&itemName,
                                        const std::string	&targetLibraryElementName,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        const Envelope	 	&envelope,
                                        bool			 saveMayaProfile);

                                 ParamAnimationElement (
                                        AnimationLibraryElement		&library,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&paramSID,
                                        const std::string		&paramName,
                                        const Envelope	 		&envelope,
                                        const Envelope_modo501		&modoEnvelope,
                                        bool				 saveMayaProfile);
        virtual			~ParamAnimationElement ();
};

/*
 * ---------------------------------------------------------------------------
 * Animation Transform.
 */

class TransformAnimationElement : public AnimationElement
{
    public:
                                 TransformAnimationElement (
                                        AnimationLibraryElement	&library,
                                        const std::string	&itemName,
                                        const std::string	&targetLibraryElementName,
                                        const std::string	&transformName,
                                        const std::string	&axisName,
                                        const std::string	&componentName,
                                        bool			 appendAxisToTargetTransformName,
                                        const Envelope	 	&envelope,
                                        bool			 saveMayaProfile);

                                 TransformAnimationElement (
                                        AnimationLibraryElement	&library,
                                        const std::string	&itemName,
                                        const std::string	&targetLibraryElementName,
                                        const MatrixEnvelope	&envelope);

                                 TransformAnimationElement (
                                        AnimationLibraryElement	&library,
                                        const std::string	&itemName,
                                        const std::string	&targetLibraryElementName,
                                        const std::string	&transformName,
                                        const std::string	&axisName,
                                        const std::string	&componentName,
                                        bool			 appendAxisToTargetTransformName,
                                        const Envelope		&envelope,
                                        const Envelope_modo501	&modoEnvelope,
                                        bool			 saveMayaProfile);

        virtual			~TransformAnimationElement ();
};

/*
 * ---------------------------------------------------------------------------
 * Animation Library.
 */

class COLLADAElement;

class AnimationLibraryElement : public Element
{
        friend class AnimationElement;

    public:
                                 AnimationLibraryElement (
                                         COLLADAElement	&collada);
        virtual			~AnimationLibraryElement ();

        bool			 HasAnimations () const;
        bool			 LinkFirstAnimation (
                                        AnimationElement &animation);
        bool			 LinkAnimation (
                                        const std::string	&animationID,
                                        AnimationElement	&animation);

    protected:
        void			 AddAnimation (AnimationElement &animation);
};

} // namespace cio

#endif // CIO_ANIMATION_H

