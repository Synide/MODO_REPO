/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_node.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_bind.h"
#include "cio_strings.h"
#include "cio_visualscene.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Library instances.
 */

InstanceCameraElement::InstanceCameraElement (
        NodeElement		&node)
        :
        Element(node.PV ())
{
}

InstanceCameraElement::~InstanceCameraElement ()
{
}

/*
 * ---------------------------------------------------------------------------
 */

InstanceControllerElement::InstanceControllerElement (
        NodeElement		&node)
        :
        Element(node.PV ())
{
}

InstanceControllerElement::~InstanceControllerElement ()
{
}

        bool
InstanceControllerElement::HasInstanceMaterial () const
{
        bool found(false);

        ElementXML *bindMaterial = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_MATERIAL).Element ();
        if (bindMaterial) {
                ElementXML *techniqueCommon =
                        GetElementHandle (bindMaterial).FirstChildElement (
                                ELEMENT_TECHNIQUE_COMMON).Element ();
                if (techniqueCommon) {
                        found = (GetElementHandle (techniqueCommon).FirstChildElement (
                                ELEMENT_INSTANCE_MATERIAL).Element () != NULL);
                }
        }

        return found;
}

        bool
InstanceControllerElement::LinkFirstInstanceMaterial (
        InstanceMaterialElement &instanceMaterial)
{
        bool linked(false);

        ElementXML *bindMaterial = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_MATERIAL).Element ();
        if (bindMaterial) {
                ElementXML *techniqueCommon =
                        GetElementHandle (bindMaterial).FirstChildElement (
                                ELEMENT_TECHNIQUE_COMMON).Element ();
                if (techniqueCommon) {
                        ElementXML *instanceMaterialElem =
                                GetElementHandle (techniqueCommon).FirstChildElement (
                                        ELEMENT_INSTANCE_MATERIAL).Element ();
                        if (instanceMaterialElem) {
                                instanceMaterial.SetElement (instanceMaterialElem);
                                linked = true;
                        }
                }
        }

        return linked;
}

/*
 * ---------------------------------------------------------------------------
 */

InstanceMaterialElement::InstanceMaterialElement (
        InstanceControllerElement &controller)
        :
        Element(controller.PV ())
{
}

InstanceMaterialElement::InstanceMaterialElement (
        InstanceGeometryElement &geometry)
        :
        Element(geometry.PV ())
{
}

InstanceMaterialElement::~InstanceMaterialElement ()
{
}

bool
InstanceMaterialElement::LinkNextInstanceMaterial (
        InstanceMaterialElement &instanceMaterial)
{
        bool foundNext(false);

        if (instanceMaterial.GetElement ()) {
                ElementXML *nextInstance =
                        instanceMaterial.GetElement ()->NextSiblingElement (
                                ELEMENT_INSTANCE_MATERIAL);
                if (nextInstance) {
                        instanceMaterial.SetElement (nextInstance);
                        foundNext = true;
                }
        }

        return foundNext;
}

        string
InstanceMaterialElement::GetSymbol () const
{
        return GetAttribute (ATTRIBUTE_SYMBOL);
}

        string
InstanceMaterialElement::GetTarget () const
{
        return StripURI_Ref (GetAttribute (ATTRIBUTE_TARGET));
}

        bool
InstanceMaterialElement::HasBind () const
{
        return (GetElementHandle ().FirstChildElement (
                ELEMENT_BIND).Element () != NULL);
}

        string
InstanceMaterialElement::GetBindSemantic () const
{
        string semantic;

        ElementXML *bind = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND).Element ();
        if (bind) {
                semantic = GetAttribute (bind, ATTRIBUTE_SEMANTIC);
        }

        return semantic;
}

        string
InstanceMaterialElement::GetBindTarget () const
{
        string target;

        ElementXML *bind = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND).Element ();
        if (bind) {
                target = GetAttribute (bind, ATTRIBUTE_TARGET);
        }

        return target;
}

        bool
InstanceMaterialElement::HasBindVertexInput () const
{
        return (GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_VERTEX_INPUT).Element () != NULL);
}

        string
InstanceMaterialElement::GetBVISemantic () const
{
        string	bviSemantic;
        ElementXML *bindVertexInput = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_VERTEX_INPUT).Element ();
        if (bindVertexInput) {
                bviSemantic = GetAttribute (bindVertexInput, ATTRIBUTE_SEMANTIC);
        }

        return bviSemantic;
}

        string
InstanceMaterialElement::GetBVIInputSemantic () const
{
        string	bviInputSemantic;
        ElementXML *bindVertexInput = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_VERTEX_INPUT).Element ();
        if (bindVertexInput) {
                bviInputSemantic = GetAttribute (bindVertexInput, ATTRIBUTE_INPUT_SEMANTIC);
        }

        return bviInputSemantic;
}

        unsigned
InstanceMaterialElement::GetBVIInputSet () const
{
        unsigned	bviInputSet = 0;
        ElementXML *bindVertexInput = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_VERTEX_INPUT).Element ();
        if (bindVertexInput) {
                bviInputSet = GetAttributeUnsigned (bindVertexInput, ATTRIBUTE_INPUT_SET);
        }

        return bviInputSet;
}

/*
 * ---------------------------------------------------------------------------
 */

InstanceGeometryElement::InstanceGeometryElement (
        NodeElement		&node)
        :
        Element(node.PV ())
{
}

InstanceGeometryElement::~InstanceGeometryElement ()
{
}

        bool
InstanceGeometryElement::HasInstanceMaterial () const
{
        bool found(false);

        ElementXML *bindMaterial = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_MATERIAL).Element ();
        if (bindMaterial) {
                ElementXML *techniqueCommon =
                        GetElementHandle (bindMaterial).FirstChildElement (
                                ELEMENT_TECHNIQUE_COMMON).Element ();
                if (techniqueCommon) {
                        found = (GetElementHandle (techniqueCommon).FirstChildElement (
                                ELEMENT_INSTANCE_MATERIAL).Element () != NULL);
                }
        }

        return found;
}

        bool
InstanceGeometryElement::LinkFirstInstanceMaterial (
        InstanceMaterialElement &instanceMaterial)
{
        bool linked(false);

        ElementXML *bindMaterial = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_MATERIAL).Element ();
        if (bindMaterial) {
                ElementXML *techniqueCommon =
                        GetElementHandle (bindMaterial).FirstChildElement (
                                ELEMENT_TECHNIQUE_COMMON).Element ();
                if (techniqueCommon) {
                        ElementXML *instanceMaterialElem =
                                GetElementHandle (techniqueCommon).FirstChildElement (
                                        ELEMENT_INSTANCE_MATERIAL).Element ();
                        if (instanceMaterialElem) {
                                instanceMaterial.SetElement (instanceMaterialElem);
                                linked = true;
                        }
                }
        }

        return linked;
}

/*
 * ---------------------------------------------------------------------------
 */

InstanceLightElement::InstanceLightElement (
        NodeElement		&node)
        :
        Element(node.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                node.AddInstanceLight (*this);
                SetAttribute (
                        ATTRIBUTE_URL,
                        URI_Ref (LightID (ItemID (node.GetID ()))));

        }
}

InstanceLightElement::~InstanceLightElement ()
{
}

/*
 * ---------------------------------------------------------------------------
 */

InstanceNodeElement::InstanceNodeElement (
        NodeElement		&node)
        :
        Element(node.PV ())
{
}

InstanceNodeElement::~InstanceNodeElement ()
{
}

/*
 * ---------------------------------------------------------------------------
 * Transform.
 *
 * A switched element type that represents any of the possible
 * transform element types.
 */

struct pv_TransformElement
{
                                 pv_TransformElement (bool isCollapsible = true);
        virtual			~pv_TransformElement ();

        void			 Reset ();

        bool			 LinkLookAt (
                                        ElementXML		*element,
                                        TransformElement	*aTransform);

        bool			 LinkMatrix (
                                        ElementXML		*element,
                                        TransformElement	*aTransform);

        bool			 LinkScale (
                                        ElementXML		*element,
                                        TransformElement	*aTransform);

        bool			 LinkRotate (
                                        ElementXML		*element,
                                        TransformElement	*aTransform);

        void			 LinkRotateMajorAxis (RotateAxis firstAxis);

        void			 LinkRotateArbitrary ();

        bool			 LinkTranslate (
                                        ElementXML		*element,
                                        TransformElement	*aTransform);

        bool			 LinkSkew (
                                        ElementXML		*element,
                                        TransformElement	*aTransform);

        bool			 collapsible;
        TransformElement	*transform;
        TransformType		 transformType;

        /*
         * LookAt
         */
        bool			 hasLookAt;
        ElementXML		*lookAtElem;
        math::Vector3	 	eyePosition;
        math::Vector3 		 interestPosition;
        math::Vector3 		 upVector;

        /*
         * Matrix
         */
        bool			 hasMatrix;
        ElementXML		*matrixElem;
        math::Matrix4		 m;

        /*
         * Rotate
         */
        bool			 hasRotate;
        ElementXML		*rotateElem;
        math::Vector4	 	 rotate;
        math::Vector3		 rotateAngles;
        RotateAxis		 rotateAxis;
        bool			 hasMultiAxisRotate;
        unsigned		 axisCount;
        math::AxisArray		 axisOrder;
        math::RotationOrder	 order;
        StringArray		 rotateSIDs;

        /*
         * Scale
         */
        bool			 hasScale;
        ElementXML		*scaleElem;
        math::Vector3 		 scale;

        /*
         * Translate
         */
        bool			 hasTranslate;
        ElementXML		*translateElem;
        math::Vector3		 translate;

        /*
         * Skew
         */
        bool					 hasSkew;
        ElementXML				*skewElem;
        TransformElement::DoubleVectorSkew	 skew;
};

pv_TransformElement::pv_TransformElement (bool isCollapsible)
        :
        collapsible(isCollapsible),
        transform(NULL),
        transformType(TRANSFORM_TYPE_UNKNOWN),
        hasLookAt(false),
        lookAtElem(NULL),
        hasMatrix(false),
        matrixElem(NULL),
        hasRotate(false),
        rotateElem(NULL),
        hasMultiAxisRotate(false),
        axisCount(0),
        hasScale(false),
        scaleElem(NULL),
        hasTranslate(false),
        translateElem(NULL),
        hasSkew(false),
        skewElem(NULL)
{
        for (unsigned index = 0; index < 3; ++index) {
                rotateAngles[index] = 0;
        }
}

pv_TransformElement::~pv_TransformElement ()
{
}

        void
pv_TransformElement::Reset ()
{
        hasLookAt = false;
        lookAtElem = NULL;
        hasMatrix = false;
        matrixElem = NULL;

        hasRotate = false;
        rotateElem = NULL;
        for (unsigned index = 0; index < 3; ++index) {
                rotateAngles[index] = 0;
        }
        hasMultiAxisRotate = false;
        axisCount = 0;
        axisOrder.clear ();
        rotateSIDs.clear ();

        hasScale = false;
        scaleElem = NULL;
        hasTranslate = false;
        translateElem = NULL;
        hasSkew = false;
        skewElem = NULL;
}

        bool
pv_TransformElement::LinkLookAt (
        ElementXML		*element,
        TransformElement	*aTransform)
{
        bool	linked(false);

        transform = aTransform;
        transformType = TRANSFORM_TYPE_LOOKAT;
        lookAtElem = element;

        Element::DoubleArray	values;
        transform->GetElementValue (lookAtElem, values);

        /*
         * A lookat element must have exactly nine values.
         */
        linked = (values.size () == 9);
        if (linked) {
                unsigned index;
                for (index = 0; index < 3; ++index) {
                        eyePosition[index] = values[index];
                        interestPosition[index] = values[index + 3];
                        upVector[index] = values[index + 6];
                }
                hasLookAt = true;
        }

        return linked;
}

        bool
pv_TransformElement::LinkMatrix (
        ElementXML		*element,
        TransformElement	*aTransform)
{
        transform = aTransform;
        transformType = TRANSFORM_TYPE_MATRIX;
        matrixElem = element;

        hasMatrix = transform->GetElementValue (matrixElem, m);

        return hasMatrix;
}

        bool
pv_TransformElement::LinkScale (
        ElementXML		*element,
        TransformElement	*aTransform)
{
        bool	linked(false);

        transform = aTransform;
        transformType = TRANSFORM_TYPE_SCALE;
        translateElem = element;

        Element::DoubleArray	values;
        transform->GetElementValue (translateElem, values);

        /*
         * A scale element must have exactly three values.
         */
        linked = (values.size () == 3);
        if (linked) {
                for (unsigned index = 0; index < 3; ++index) {
                        scale[index] = values[index];
                }
                hasScale = true;
                linked = true;
        }

        return linked;
}

/*
 * Return the number of populated axis components.
 */
        static unsigned
AxisCount (const math::Vector4 &rotate, RotateAxis &firstAxis)
{
        /*
         * Check if we have a primary axis of rotation, by building
         * a vector of non-zero axis types.
         */
        std::vector<RotateAxis>	nonZeroAxis;
        for (unsigned axisIndex = ROTATE_AXIS_X; axisIndex <= ROTATE_AXIS_Z; ++axisIndex) {
                if (rotate[axisIndex] != 0) {
                        nonZeroAxis.push_back (
                                static_cast<RotateAxis>(axisIndex));
                }
        }

        if (!nonZeroAxis.empty ()) {
                firstAxis = nonZeroAxis.at (0);
        }

        return static_cast<unsigned>(nonZeroAxis.size ());
}

        static bool
ExtractVector4 (
        ElementXML		*element,
        TransformElement	*aTransform,
        math::Vector4		&vec)
{
        bool	extracted(false);
        Element::DoubleArray	values;
        aTransform->GetElementValue (element, values);

        /*
         * The element must have exactly four values.
         */
        extracted = (values.size () == 4);
        if (extracted) {
                for (unsigned index = 0; index < 4; ++index) {
                        vec[index] = values[index];
                }
        }

        return extracted;
}

        math::RotationOrder
RotationOrderFromAxisArray (const math::AxisArray &axisOrder)
{
        /*
         * Determine the rotation order.
         */
        math::RotationOrder order = math::ROTATION_ORDER_ZXY;
        switch (axisOrder.at (0)) {
                case ROTATE_AXIS_X:
                        if (axisOrder.size () < 2 ||
                            axisOrder.at (1) == math::AXIS_Y) {
                                order = math::ROTATION_ORDER_XYZ;
                        }
                        else {
                                order = math::ROTATION_ORDER_XZY;
                        }
                        break;

                case ROTATE_AXIS_Y:
                        if (axisOrder.size () < 2 ||
                            axisOrder.at (1) == math::AXIS_X) {
                                order = math::ROTATION_ORDER_YXZ;
                        }
                        else {
                                order = math::ROTATION_ORDER_YZX;
                        }
                        break;

                case ROTATE_AXIS_Z:
                        if (axisOrder.size () < 2 ||
                            axisOrder.at (1) == math::AXIS_X) {
                                order = math::ROTATION_ORDER_ZXY;
                        }
                        else {
                                order = math::ROTATION_ORDER_ZYX;
                        }
                        break;
        }

        return order;
}

        bool
pv_TransformElement::LinkRotate (
        ElementXML		*element,
        TransformElement	*aTransform)
{
        transform = aTransform;
        transformType = TRANSFORM_TYPE_ROTATE;
        rotateElem = element;

        hasRotate = ExtractVector4 (rotateElem, transform, rotate);

        /*
         * If rotating around only one major axis.
         */
        RotateAxis firstAxis;
        if (AxisCount (rotate, firstAxis) == 1) {
                LinkRotateMajorAxis (firstAxis);
        }
        else {
                LinkRotateArbitrary ();
        }

        return hasRotate;
}

        void
pv_TransformElement::LinkRotateMajorAxis (RotateAxis firstAxis)
{
        rotateAxis = firstAxis;
        rotateAngles[rotateAxis] = rotate[3] * math::DEG2RAD;
        axisOrder.push_back (static_cast<math::Axis>(rotateAxis));
        rotateSIDs.push_back (transform->GetSID (rotateElem));
        axisCount = 1;

        /*
         * Check if we have a run of two or three rotate elements
         * with unique major-axis rotations.
         */
        if (collapsible) {
                ElementXML *prevElem = rotateElem;
                bool foundAnotherAxis(false);
                RotateAxis curAxis(firstAxis);
                do {
                        prevElem = prevElem->PreviousSiblingElement ();
                        if (prevElem) {
                                if (prevElem->ValueStr () == string(ELEMENT_ROTATE)) {
                                        math::Vector4 prevRotate;
                                        if (ExtractVector4 (prevElem, transform, prevRotate)) {
                                                RotateAxis prevAxis;
                                                /*
                                                 * If this rotate transform has one major axis.
                                                 */
                                                if (AxisCount (prevRotate, prevAxis) == 1) {
                                                        if (prevAxis != curAxis &&
                                                            prevAxis != firstAxis) {
                                                                curAxis = prevAxis;
                                                                rotateAngles[prevAxis] =
                                                                        prevRotate[3] * math::DEG2RAD;
                                                                axisOrder.push_back (
                                                                        static_cast<math::Axis>(
                                                                                prevAxis));
                                                                rotateSIDs.push_back (
                                                                        transform->GetSID (
                                                                                prevElem));
                                                                foundAnotherAxis = true;
                                                                hasMultiAxisRotate = true;
                                                                rotateAxis = ROTATE_AXIS_MULTI;
                                                                axisCount++;
                                                        }
                                                }
                                        }
                                }
                        }
                } while (prevElem && foundAnotherAxis && axisCount < 3);
        }

        /*
         * Determine the rotation order.
         */
        order = RotationOrderFromAxisArray (axisOrder);
}

        void
pv_TransformElement::LinkRotateArbitrary ()
{
        rotateAxis = ROTATE_AXIS_ARBITRARY;
        order = math::ROTATION_ORDER_ZXY;
        hasMultiAxisRotate = false;
        axisCount = 0;

        /*
         * Form a matrix for a rotation about an arbitrary angle,
         * and then call MatrixToEuler to extract the angles. 
         */
        math::Matrix3	m;
        math::Vector3	axis = {rotate[0], rotate[1], rotate[2]};
        math::Normalize (axis);
        math::MatrixAxisRotation (
                m, axis, math::DEG2RAD * rotate[3]);

        /*
         * Extract the Euler angles (in radians) from the matrix.
         */
        math::AxisOrder axisOrder;
        math::RotationAxisOrder (order, axisOrder);
        math::MatrixToEuler (
                m,
                axisOrder[math::AXIS_X],
                axisOrder[math::AXIS_Y],
                axisOrder[math::AXIS_Z],
                rotateAngles);
}

        bool
pv_TransformElement::LinkTranslate (
        ElementXML		*element,
        TransformElement	*aTransform)
{
        bool	linked(false);

        transform = aTransform;
        transformType = TRANSFORM_TYPE_TRANSLATE;
        translateElem = element;

        Element::DoubleArray	values;
        transform->GetElementValue (translateElem, values);

        /*
         * A translate element must have exactly three values.
         */
        linked = (values.size () == 3);
        if (linked) {
                for (unsigned index = 0; index < 3; ++index) {
                        translate[index] = values[index];
                }
                hasTranslate = true;
        }

        return linked;
}

        bool
pv_TransformElement::LinkSkew (
        ElementXML		*element,
        TransformElement	*aTransform)
{
        bool	linked(false);

        transform = aTransform;
        transformType = TRANSFORM_TYPE_SKEW;
        skewElem = element;

        Element::DoubleArray	values;
        transform->GetElementValue (skewElem, values);

        /*
         * A skew element must have exactly seven values, organized
         * into an angle in degrees followed by two column vectors
         * specifying the axes of rotation and translation.
         */
        linked = (values.size () == 7);
        if (linked) {
                for (unsigned index = 0; index < 7; ++index) {
                        skew[index] = values[index];
                }
                hasSkew = true;
        }
        return linked;
}

TransformElement::TransformElement (
        NodeElement		&node,
        bool			 collapsible)
        :
        Element(node.PV ()),
        pv(new pv_TransformElement (collapsible))
{
}

TransformElement::~TransformElement ()
{
        delete pv;
}

        TransformType
TransformElement::GetTransformType () const
{
        return pv->transformType;
}

/*
 * A lookat element contains a position and orientation transformation
 * suitable for aiming a camera.
 */
        bool
TransformElement::GetLookAt (
        math::Vector3 &eyePosition,
        math::Vector3 &interestPosition,
        math::Vector3 &upVector) const
{
        bool	found(false);
        if (pv->hasLookAt) {
                math::Vector3Copy (eyePosition, pv->eyePosition);
                math::Vector3Copy (interestPosition, pv->interestPosition);
                math::Vector3Copy (upVector, pv->upVector);
                found = true;
        }
        return found;
}

        bool
TransformElement::GetMatrix (
        math::Matrix4	&value) const
{
        bool	found(false);

        if (pv->hasMatrix) {
                math::Matrix4Copy(value, pv->m);
                found = true;
        }

        return found;
}

        bool
TransformElement::GetScale (
        math::Vector3 &scale) const
{
        bool	found(false);
        if (pv->hasScale) {
                math::Vector3Copy (scale, pv->scale);
                found = true;
        }
        return found;
}

        RotateAxis
TransformElement::GetRotateAxis () const
{
        RotateAxis	axis(ROTATE_AXIS_ARBITRARY);
        if (pv->hasRotate) {
                axis = pv->rotateAxis;
        }

        return axis;
}

        math::RotationOrder
TransformElement::GetRotationOrder () const
{
        return pv->order;
}

        bool
TransformElement::GetRotateAngles (
        math::Vector3 &rotateAngles) const
{
        bool	found(false);
        if (pv->hasRotate) {
                math::Vector3Copy (rotateAngles, pv->rotateAngles);
                found = true;
        }

        return found;
}

/*
 * Rotation in axis/angle form.
 */
        bool
TransformElement::GetRotate (
        math::Vector4 &rotate) const
{
        bool	found(false);
        if (pv->hasRotate) {
                math::Vector4Copy (rotate, pv->rotate);
                found = true;
        }

        return found;
}

/*
 * Multi-axis rotate transforms cache an array of SIDs for a major-axis run.
 */
        bool
TransformElement::GetRotateAxisSIDs (
        StringArray	&sids) const
{
        bool	haveMultiAxis =
                (GetTransformType () == TRANSFORM_TYPE_ROTATE) &&
                (GetRotateAxis () == ROTATE_AXIS_MULTI) &&
                !pv->rotateSIDs.empty ();
        if (haveMultiAxis) {
                for (StringArray::const_iterator iter = pv->rotateSIDs.begin ();
                        iter != pv->rotateSIDs.end (); ++iter) {
                        sids.push_back (*iter);
                }
        }

        return haveMultiAxis;
}

        bool
TransformElement::GetTranslate (
        math::Vector3 &translate) const
{
        bool	found(false);
        if (pv->hasTranslate) {
                math::Vector3Copy (translate, pv->translate);
                found = true;
        }
        return found;
}

        bool
TransformElement::GetSkew (
        DoubleVectorSkew &skew) const
{
        bool	found(false);
        if (pv->hasSkew) {
                for (unsigned index = 0; index < 7; ++index) {
                        skew[index] = pv->skew[index];
                }
                found = true;
        }
        return found;
}

/*
 * If collapsible transforms are enabled and the current transform is a rotate
 * transform with a major axis, skip over the current run of unique major axis
 * rotation transforms.
 */
        bool
TransformElement::LinkPreviousTransform (
        TransformElement &transform)
{
        bool	linked(false);

        ElementXML *prevElem = GetElement ();
        if (prevElem) {
                /*
                 * Look for the next linkable transform element.
                 */
                do {
                        prevElem = prevElem->PreviousSiblingElement ();
                        if (prevElem) {
                                if (pv->collapsible &&
                                    pv->hasMultiAxisRotate) {
                                        /*
                                         * May have had two or three axis run
                                         * of rotate transforms.
                                         */
                                        for (unsigned skipIndex = 0;
                                                skipIndex < pv->axisCount - 1; ++skipIndex) {
                                                string elementName = prevElem->ValueStr ();
                                                if (elementName == string(ELEMENT_ROTATE)) {
                                                        prevElem = prevElem->PreviousSiblingElement ();
                                                }
                                        }
                                }
                                /*
                                 * If this is not the last element, attempt to
                                 * link the previous element as the previous transform.
                                 */
                                if (prevElem) {
                                        linked = transform.LinkChildElem (prevElem);
                                }
                        }
                } while (prevElem && !linked);
        }

        return linked;
}

        bool
TransformElement::LinkChildElem (ElementXML *childElem)
{
        bool	linked(false);

        pv->Reset ();

        string elementName = childElem->ValueStr ();
        if (elementName == string(ELEMENT_LOOKAT)) {
                linked = pv->LinkLookAt (childElem, this);
        }
        else if (elementName == string(ELEMENT_MATRIX)) {
                linked = pv->LinkMatrix (childElem, this);
        }
        else if (elementName == string(ELEMENT_SCALE)) {
                linked = pv->LinkScale (childElem, this);
        }
        else if (elementName == string(ELEMENT_ROTATE)) {
                linked = pv->LinkRotate (childElem, this);
        }
        else if (elementName == string(ELEMENT_TRANSLATE)) {
                linked = pv->LinkTranslate (childElem, this);
        }
        else if (elementName == string(ELEMENT_SKEW)) {
                linked = pv->LinkSkew (childElem, this);
        }

        if (linked) {
                SetElement (childElem);
        }

        return linked;
}

/*
 * ---------------------------------------------------------------------------
 * Node.
 */

NodeElement::NodeElement (
        NodeLibraryElement	&library)
        :
        Element(library.PV ())
{
}

NodeElement::NodeElement (
        VisualSceneElement	&visualScene,
        const string		&name)
        :
        Element(visualScene.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddNode (*this);

                SetID (NodeID (string(ItemID (name))));
                SetName (name);
                SetType (ATTRVALUE_NODE);
        }
}

NodeElement::NodeElement (
        VisualSceneElement	&visualScene,
        const string		&id,
        const string		&name)
        :
        Element(visualScene.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddNode (*this);

                SetID (id);
                SetName (name);
                SetType (ATTRVALUE_NODE);
        }
}

NodeElement::NodeElement (
        VisualSceneElement	&visualScene,
        const string		&id,
        const string		&name,
        const string		&type)
        :
        Element(visualScene.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddNode (*this);

                SetID (id);
                SetName (name);
                SetType (type);
        }
}

NodeElement::NodeElement (
        VisualSceneElement	&visualScene)
        :
        Element(visualScene.PV ())
{
}

NodeElement::NodeElement (
        NodeElement		&node,
        const string		&name)
        :
        Element(node.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                node.AddNode (*this);

                SetID (NodeID (string(ItemID (name))));
                SetName (name);
                SetType (ATTRVALUE_NODE);
        }
}

NodeElement::NodeElement (
        NodeElement		&node,
        const string		&id,
        const string		&name)
        :
        Element(node.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                node.AddNode (*this);

                SetID (id);
                SetName (name);
                SetType (ATTRVALUE_NODE);
        }
}

NodeElement::NodeElement (
        NodeElement		&node,
        const string		&id,
        const string		&name,
        const string		&type)
        :
        Element(node.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                node.AddNode (*this);

                SetID (id);
                SetName (name);
                SetType (type);
        }
}

NodeElement::NodeElement (
        NodeElement		&node)
        :
        Element(node.PV ())
{
}

NodeElement::~NodeElement ()
{
}

/*
 * Per-item asset tagging.
 */
        bool
NodeElement::HasAsset () const
{
        return (GetElementHandle ().FirstChildElement (
                ELEMENT_ASSET).Element () != NULL);
}

/*
 * ---------------------------------------------------------------------------
 * Transformations.
 */

        bool
NodeElement::HasTransform () const
{
        return HasLookAt () ||
               HasMatrix () ||
               HasRotate () ||
               HasScale () ||
               HasSkew () ||
               HasTranslate ();
}

        bool
NodeElement::HasLookAt () const
{
        return HasChildElement (ELEMENT_LOOKAT);
}

        bool
NodeElement::HasMatrix () const
{
        return HasChildElement (ELEMENT_MATRIX);
}

        bool
NodeElement::HasRotate () const
{
        return HasChildElement (ELEMENT_ROTATE);
}

        bool
NodeElement::HasScale () const
{
        return HasChildElement (ELEMENT_SCALE);
}

        bool
NodeElement::HasSkew () const
{
        return HasChildElement (ELEMENT_SKEW);
}

        bool
NodeElement::HasTranslate () const
{
        return HasChildElement (ELEMENT_TRANSLATE);
}

        bool
NodeElement::LinkFirstTransform (
        TransformElement &transform)
{
        bool	linked(false);

        ElementXML *childElem =
                GetElementHandle ().FirstChildElement ().Element ();
        if (childElem) {
                do {
                        linked = transform.LinkChildElem (childElem);
                        if (!linked) {
                                childElem = childElem->NextSiblingElement ();
                        }
                } while (childElem && !linked);
        }

        return linked;
}

        bool
NodeElement::LinkLastTransform (
        TransformElement &transform)
{
        bool	linked(false);

        ElementXML *childElem =
                GetElementHandle ().LastChildElement ().Element ();
        if (childElem) {
                do {
                        linked = transform.LinkChildElem (childElem);
                        if (!linked) {
                                childElem = childElem->PreviousSiblingElement ();
                        }
                } while (childElem && !linked);
        }

        return linked;
}

/*
 * ---------------------------------------------------------------------------
 * Library instances.
 */

        bool
NodeElement::HasInstanceCamera () const
{
        return HasChildElement (ELEMENT_INSTANCE_CAMERA);
}

        bool
NodeElement::LinkFirstInstanceCamera (
        InstanceCameraElement &instance)
{
        return LinkFirstChildElement (ELEMENT_INSTANCE_CAMERA, instance);
}

        bool
NodeElement::HasInstanceController () const
{
        return HasChildElement (ELEMENT_INSTANCE_CONTROLLER);
}

        bool
NodeElement::LinkFirstInstanceController (
        InstanceControllerElement &instance)
{
        return LinkFirstChildElement (ELEMENT_INSTANCE_CONTROLLER, instance);
}

        bool
NodeElement::LinkNextInstanceController (
        InstanceControllerElement &instance)
{
        bool foundNextInstance(false);

        if (instance.GetElement ()) {
                ElementXML *nextInstance =
                        instance.GetElement ()->NextSiblingElement (
                                ELEMENT_INSTANCE_CONTROLLER);
                if (nextInstance) {
                        instance.SetElement (nextInstance);
                        foundNextInstance = true;
                }
        }

        return foundNextInstance;
}

        bool
NodeElement::HasInstanceGeometry () const
{
        return (GetElementHandle ().FirstChildElement (
                ELEMENT_INSTANCE_GEOMETRY).Element () != NULL);
}

        bool
NodeElement::LinkFirstInstanceGeometry (
        InstanceGeometryElement &instance)
{
        return LinkFirstChildElement (ELEMENT_INSTANCE_GEOMETRY, instance);
}

        bool
NodeElement::LinkNextInstanceGeometry (
        InstanceGeometryElement &instance)
{
        bool foundNextInstance(false);

        if (instance.GetElement ()) {
                ElementXML *nextInstance =
                        instance.GetElement ()->NextSiblingElement (
                                ELEMENT_INSTANCE_GEOMETRY);
                if (nextInstance) {
                        instance.SetElement (nextInstance);
                        foundNextInstance = true;
                }
        }

        return foundNextInstance;
}

        bool
NodeElement::HasInstanceLight () const
{
        return HasChildElement (ELEMENT_INSTANCE_LIGHT);
}

        bool
NodeElement::LinkFirstInstanceLight (
        InstanceLightElement &instance)
{
        return LinkFirstChildElement (ELEMENT_INSTANCE_LIGHT, instance);
}

        bool
NodeElement::HasInstanceNode () const
{
        return HasChildElement (ELEMENT_INSTANCE_NODE);
}

        bool
NodeElement::LinkFirstInstanceNode (
        InstanceNodeElement &instance)
{
        return LinkFirstChildElement (ELEMENT_INSTANCE_NODE, instance);
}

/*
 * @return If this node element has at least one sub node.
 */
        bool
NodeElement::HasSubNode () const
{
        return HasChildElement (ELEMENT_NODE);
}

/*
 * Link the node wrapper to the first sub node.
 */
        bool
NodeElement::LinkFirstSubNode (NodeElement &node)
{
        return LinkFirstChildElement (ELEMENT_NODE, node);
}

        bool
NodeElement::LinkNextNode (NodeElement &node)
{
        bool foundNextNode(false);

        if (node.GetElement ()) {
                ElementXML *nextNode = node.GetElement ()->NextSiblingElement (ELEMENT_NODE);
                if (nextNode) {
                        node.SetElement (nextNode);
                        foundNextNode = true;
                }
        }

        return foundNextNode;
}

        bool
NodeElement::LinkTechniqueProfile_modo401 (
        NodeElement_modo401 &node)
{
        return LinkExtraTechniqueProfile (PROFILE_MODO401, node);
}

        void
NodeElement::AddNode (NodeElement &node)
{
        node.SetElement (AddElement (ELEMENT_NODE));
}

        void
NodeElement::AddInstanceLight (InstanceLightElement &instanceLight)
{
        instanceLight.SetElement (AddElement (ELEMENT_INSTANCE_LIGHT));
}

/*
 * ---------------------------------------------------------------------------
 * Node Technique Profile modo 401.
 */

struct pv_NodeElement_modo401 : public BoundElementParamValue
{
        pv_NodeElement_modo401 ()
                :
                paramRender(NULL),
                paramDisplayVisible(NULL),
                paramDisplaySize(NULL),
                paramDissolve(NULL)
        {
        }

        ElementXML		*paramRender;
        ElementXML		*paramDisplayVisible;
        ElementXML		*paramDisplaySize;
        ElementXML		*paramDissolve;
};

NodeElement_modo401::NodeElement_modo401 (
        NodeElement &node)
        :
        Element(node.PV ()),
        pv(new pv_NodeElement_modo401())
{
}

NodeElement_modo401::~NodeElement_modo401 ()
{
        delete pv;
}

        bool
NodeElement_modo401::GetRender (std::string &render)
{
        return GetParamValue (GetElement (), &pv->paramRender,
                PARAM_MODO_LOCATOR_RENDER, render);
}

        void
NodeElement_modo401::SetRender (const std::string &render)
{
        pv->SetValue (&pv->paramRender,
                PARAM_MODO_LOCATOR_RENDER, render);
}

        bool
NodeElement_modo401::GetDisplayVisible (std::string &render)
{
        return GetParamValue (GetElement (), &pv->paramDisplayVisible,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE, render);
}

        void
NodeElement_modo401::SetDisplayVisible (const std::string &render)
{
        pv->SetValue (&pv->paramDisplayVisible,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE, render);
}

        bool
NodeElement_modo401::GetDisplaySize (double &size)
{
        return GetParamValue (GetElement (), &pv->paramDisplaySize,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE, size);
}

        void
NodeElement_modo401::SetDisplaySize (double size)
{
        pv->SetValue (&pv->paramDisplaySize,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE, size);
}

        bool
NodeElement_modo401::GetDissolve (double &dissolve)
{
        return GetParamValue (GetElement (), &pv->paramDissolve,
                PARAM_MODO_LOCATOR_DISSOLVE, dissolve);
}

 	void
NodeElement_modo401::SetDissolve (double dissolve)
{
        pv->SetValue (&pv->paramDissolve,
                PARAM_MODO_LOCATOR_DISSOLVE, dissolve);
}

        bool
NodeElement_modo401::GetTransformLink (
        const string		&sourceTransformID,
        string			&transformType,
        string			&linkedTransformID)
{
        bool	found(false);

        ElementXML *param = GetElementHandle ().FirstChildElement (
                ELEMENT_PARAM).Element ();
        while (param) {
                if (GetSID (param) == sourceTransformID) {
                        transformType = GetAttribute (param, ATTRIBUTE_SEMANTIC);
                        linkedTransformID = GetElementValue (param);
                        found = true;
                        break;
                }
                param = param->NextSiblingElement (ELEMENT_PARAM);
        }

        return found;
}

/*
 * ---------------------------------------------------------------------------
 * Node Library.
 */

NodeLibraryElement::NodeLibraryElement (
        COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddNodeLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkNodeLibrary (*this);
        }
}

NodeLibraryElement::~NodeLibraryElement ()
{
}

        bool
NodeLibraryElement::HasNode () const
{
        return HasChildElement (ELEMENT_NODE);
}

        bool
NodeLibraryElement::LinkNode (
        const string	&nodeID,
        NodeElement	&node)
{
        return LinkFirstChildElement (ELEMENT_NODE, nodeID, node);
}

        void
NodeLibraryElement::AddNode (
        NodeElement &node)
{
        node.SetElement (AddElement (ELEMENT_NODE));
}

} // namespace cio

