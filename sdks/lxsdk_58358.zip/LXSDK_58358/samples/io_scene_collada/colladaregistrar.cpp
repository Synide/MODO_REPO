/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "colladaregistrar.h"

#include "../libcolladaio/cio_schema.h"
#include "../libcolladaio/cio_profiles.h"

#include <lxidef.h>

using namespace std;
using namespace cio;

ItemTypeChannelRegistrar::ItemTypeChannelRegistrar (
        ItemTypeChannelBind &bind)
        :
        itemTypeChannels(bind)
{
}

ItemTypeChannelRegistrar::~ItemTypeChannelRegistrar ()
{
}

/*
 * Register item sub types for convenient type checking.
 */
        void
ItemTypeChannelRegistrar::RegisterItemSubTypes ()
{
        itemTypeChannels.AddItemSubType (
                LXsITYPE_LIGHT, LXsITYPE_AREALIGHT);

        itemTypeChannels.AddItemSubType (
                LXsITYPE_LIGHT, LXsITYPE_CYLINDERLIGHT);

        itemTypeChannels.AddItemSubType (
                LXsITYPE_LIGHT, LXsITYPE_DOMELIGHT);

        itemTypeChannels.AddItemSubType (
                LXsITYPE_LIGHT, LXsITYPE_PHOTOMETRYLIGHT);

        itemTypeChannels.AddItemSubType (
                LXsITYPE_LIGHT, LXsITYPE_POINTLIGHT);

        itemTypeChannels.AddItemSubType (
                LXsITYPE_LIGHT, LXsITYPE_SPOTLIGHT);

        itemTypeChannels.AddItemSubType (
                LXsITYPE_LIGHT, LXsITYPE_SUNLIGHT);
}

/*
 * Register targetable channels for each item type.
 */
        void
ItemTypeChannelRegistrar::RegisterChannels ()
{
        RegisterCameraChannels ();
        RegisterLightChannels ();
        RegisterMeshChannels ();

        RegisterRenderChannels ();

        RegisterEnvironmentChannels ();
        RegisterEnvironmentMaterialChannels ();
}

        void
ItemTypeChannelRegistrar::RegisterChannel (
        const string		&itemType,
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        itemTypeChannels.AddItemTypeChannel (
                ItemTypeChannel (itemType, channel,
                paramSID, paramName, paramType));
}

/*
 * Camera channel registration.
 */

        void
ItemTypeChannelRegistrar::RegisterCameraChannels ()
{
        RegisterCameraChannel (LXsICHAN_LOCATOR_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE_NAME);
        RegisterCameraChannel (LXsICHAN_LOCATOR_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE_NAME,
                PARAM_TYPE_NAME);

        RegisterCameraChannel (LXsICHAN_CAMERA_APERTUREX,
                PARAM_MODO_CAMERA_APERTURE_WIDTH,
                PARAM_MODO_CAMERA_APERTURE_WIDTH_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_APERTUREY,
                PARAM_MODO_CAMERA_APERTURE_HEIGHT,
                PARAM_MODO_CAMERA_APERTURE_HEIGHT_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_BLURLEN,
                PARAM_MODO_CAMERA_BLUR_LENGTH,
                PARAM_MODO_CAMERA_BLUR_LENGTH_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_BLUROFF,
                PARAM_MODO_CAMERA_BLUR_OFFSET,
                PARAM_MODO_CAMERA_BLUR_OFFSET_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_CONVDIST,
                PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE,
                PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_FOCALLEN,
                PARAM_MODO_CAMERA_FOCAL_LENGTH,
                PARAM_MODO_CAMERA_FOCAL_LENGTH_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_FOCUSDIST,
                PARAM_MODO_CAMERA_FOCUS_DISTANCE,
                PARAM_MODO_CAMERA_FOCUS_DISTANCE_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_FSTOP,
                PARAM_MODO_CAMERA_F_STOP,
                PARAM_MODO_CAMERA_F_STOP_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_IODIST,
                PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE,
                PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_DISTORT,
                PARAM_MODO_CAMERA_LENS_DISTORTION,
                PARAM_MODO_CAMERA_LENS_DISTORTION_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_SQUEEZE,
                PARAM_MODO_CAMERA_LENS_SQUEEZE,
                PARAM_MODO_CAMERA_LENS_SQUEEZE_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_OFFSETX,
                PARAM_MODO_CAMERA_OFFSET_X,
                PARAM_MODO_CAMERA_OFFSET_X_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_OFFSETY,
                PARAM_MODO_CAMERA_OFFSET_Y,
                PARAM_MODO_CAMERA_OFFSET_Y_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_PROJTYPE,
                PARAM_MODO_CAMERA_PROJECTION,
                PARAM_MODO_CAMERA_PROJECTION_NAME,
                PARAM_TYPE_NAME);
        RegisterCameraChannel (LXsICHAN_CAMERA_DOF,
                PARAM_MODO_CAMERA_DEPTH_OF_FIELD,
                PARAM_MODO_CAMERA_DEPTH_OF_FIELD_NAME,
                PARAM_TYPE_BOOL);
        RegisterCameraChannel (LXsICHAN_CAMERA_MOTIONBLUR,
                PARAM_MODO_CAMERA_MOTION_BLUR,
                PARAM_MODO_CAMERA_MOTION_BLUR_NAME,
                PARAM_TYPE_BOOL);
        RegisterCameraChannel (LXsICHAN_CAMERA_STEREO,
                PARAM_MODO_CAMERA_STEREOSCOPIC,
                PARAM_MODO_CAMERA_STEREOSCOPIC_NAME,
                PARAM_TYPE_BOOL);
#if 0
        /*
         * [TODO] Disabled until package support is added into modo
         *        for reading the values back in during scene load.
         *
         * [TODO] These channels should also be made conditional
         *        on the presence of a set target.
         */
        RegisterCameraChannel (LXsICHAN_TARGET_ENABLE,
                PARAM_MODO_TARGET_ENABLE,
                PARAM_MODO_TARGET_ENABLE_NAME,
                PARAM_TYPE_BOOL);
        RegisterCameraChannel (LXsICHAN_TARGET_TARGETFOCUS,
                PARAM_MODO_TARGET_SET_FOCUS,
                PARAM_MODO_TARGET_SET_FOCUS_NAME,
                PARAM_TYPE_BOOL);
        RegisterCameraChannel (LXsICHAN_TARGET_TARGETROLL,
                PARAM_MODO_TARGET_ROLL,
                PARAM_MODO_TARGET_ROLL_NAME);
#endif
}

        void
ItemTypeChannelRegistrar::RegisterCameraChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_CAMERA, channel,
                paramSID, paramName, paramType);
}

/*
 * Light channel registration.
 */

        void
ItemTypeChannelRegistrar::RegisterLightChannels ()
{
        RegisterAreaLightChannels ();
        RegisterCylinderLightChannels ();
        RegisterDomeLightChannels ();
        RegisterPhotometricLightChannels ();
        RegisterPointLightChannels ();
        RegisterSpotLightChannels ();
        RegisterSunLightChannels ();
}

        void
ItemTypeChannelRegistrar::RegisterLightLocatorChannels (
        const string	&itemType)
{
        RegisterChannel (itemType, LXsICHAN_LOCATOR_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE_NAME);
        RegisterChannel (itemType, LXsICHAN_LOCATOR_DISSOLVE,
                PARAM_MODO_LOCATOR_DISSOLVE,
                PARAM_MODO_LOCATOR_DISSOLVE_NAME);
        RegisterChannel (itemType, LXsICHAN_LOCATOR_RENDER,
                PARAM_MODO_LOCATOR_RENDER,
                PARAM_MODO_LOCATOR_RENDER_NAME,
                PARAM_TYPE_NAME);
        RegisterChannel (itemType, LXsICHAN_LOCATOR_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE_NAME,
                PARAM_TYPE_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterLightTargetChannels (
        const string	&itemType)
{
#if 0
        /*
         * [TODO] Disabled until package support is added into modo
         *        for reading the values back in during scene load.
         *
         * [TODO] These channels should also be made conditional
         *        on the presence of a set target.
         */
        RegisterChannel (itemType, LXsICHAN_TARGET_ENABLE,
                PARAM_MODO_TARGET_ENABLE, PARAM_MODO_TARGET_ENABLE_NAME,
                PARAM_TYPE_BOOL);
        RegisterChannel (itemType, LXsICHAN_TARGET_TARGETROLL,
                PARAM_MODO_TARGET_ROLL, PARAM_MODO_TARGET_ROLL_NAME);
#endif
}

        void
ItemTypeChannelRegistrar::RegisterAreaLightChannels ()
{
        RegisterLightLocatorChannels (LXsITYPE_AREALIGHT);
        RegisterLightTargetChannels (LXsITYPE_AREALIGHT);

        RegisterAreaLightChannel (LXsICHAN_AREALIGHT_HEIGHT,
                PARAM_MODO_AREALIGHT_HEIGHT,
                PARAM_MODO_AREALIGHT_HEIGHT_NAME);
        RegisterAreaLightChannel (LXsICHAN_AREALIGHT_SHAPE,
                PARAM_MODO_AREALIGHT_SHAPE,
                PARAM_MODO_AREALIGHT_SHAPE_NAME,
                PARAM_TYPE_NAME);
        RegisterAreaLightChannel (LXsICHAN_AREALIGHT_WIDTH,
                PARAM_MODO_AREALIGHT_WIDTH,
                PARAM_MODO_AREALIGHT_WIDTH_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterAreaLightChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_AREALIGHT, channel,
                paramSID, paramName, paramType);
}

        void
ItemTypeChannelRegistrar::RegisterCylinderLightChannels ()
{
        RegisterLightLocatorChannels (LXsITYPE_CYLINDERLIGHT);
        RegisterLightTargetChannels (LXsITYPE_CYLINDERLIGHT);

        RegisterCylinderLightChannel (LXsICHAN_CYLINDERLIGHT_LENGTH,
                PARAM_MODO_CYLINDERLIGHT_LENGTH,
                PARAM_MODO_CYLINDERLIGHT_LENGTH_NAME);
        RegisterCylinderLightChannel (LXsICHAN_CYLINDERLIGHT_RADIUS,
                PARAM_MODO_CYLINDERLIGHT_RADIUS,
                PARAM_MODO_CYLINDERLIGHT_RADIUS_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterCylinderLightChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_CYLINDERLIGHT, channel,
                paramSID, paramName, paramType);
}

        void
ItemTypeChannelRegistrar::RegisterDomeLightChannels ()
{
        RegisterLightLocatorChannels (LXsITYPE_DOMELIGHT);

        RegisterDomeLightChannel (LXsICHAN_DOMELIGHT_RADIUS,
                PARAM_MODO_DOMELIGHT_RADIUS,
                PARAM_MODO_DOMELIGHT_RADIUS_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterDomeLightChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_DOMELIGHT, channel,
                paramSID, paramName, paramType);
}

        void
ItemTypeChannelRegistrar::RegisterPhotometricLightChannels ()
{
        RegisterLightLocatorChannels (LXsITYPE_PHOTOMETRYLIGHT);
        RegisterLightTargetChannels (LXsITYPE_PHOTOMETRYLIGHT);

        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_CONE,
                PARAM_MODO_PHOTOMETRICLIGHT_CONE_ANGLE,
                PARAM_MODO_PHOTOMETRICLIGHT_CONE_ANGLE_NAME);
        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_EDGE,
                PARAM_MODO_PHOTOMETRICLIGHT_SOFT_EDGE_ANGLE,
                PARAM_MODO_PHOTOMETRICLIGHT_SOFT_EDGE_ANGLE_NAME);

        /*
         * [TODO] Handle LXsICHAN_PHOTOMETRYLIGHT_FILENAME 
         */

        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_HEIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_HEIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_HEIGHT_NAME);
        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_OUTSIDE,
                PARAM_MODO_PHOTOMETRICLIGHT_OUTSIDE,
                PARAM_MODO_PHOTOMETRICLIGHT_OUTSIDE_NAME,
                PARAM_TYPE_BOOL);
        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_VDISSOLVE,
                PARAM_MODO_PHOTOMETRICLIGHT_V_DISSOLVE,
                PARAM_MODO_PHOTOMETRICLIGHT_V_DISSOLVE_NAME);
        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_VOLUMETRICS,
                PARAM_MODO_PHOTOMETRICLIGHT_VOLUMETRICS,
                PARAM_MODO_PHOTOMETRICLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);
        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_VSAMPLES,
                PARAM_MODO_PHOTOMETRICLIGHT_V_SAMPLES,
                PARAM_MODO_PHOTOMETRICLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);
        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_VRAD,
                PARAM_MODO_PHOTOMETRICLIGHT_V_RAD,
                PARAM_MODO_PHOTOMETRICLIGHT_V_RAD_NAME);
        RegisterPhotometricLightChannel (LXsICHAN_PHOTOMETRYLIGHT_WIDTH,
                PARAM_MODO_PHOTOMETRICLIGHT_WIDTH,
                PARAM_MODO_PHOTOMETRICLIGHT_WIDTH_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterPhotometricLightChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_PHOTOMETRYLIGHT, channel,
                paramSID, paramName, paramType);
}

        void
ItemTypeChannelRegistrar::RegisterPointLightChannels ()
{
        RegisterLightLocatorChannels (LXsITYPE_POINTLIGHT);

        RegisterPointLightChannel (LXsICHAN_POINTLIGHT_RADIUS,
                PARAM_MODO_POINTLIGHT_RADIUS,
                PARAM_MODO_POINTLIGHT_RADIUS_NAME);
        RegisterPointLightChannel (LXsICHAN_POINTLIGHT_VDISSOLVE,
                PARAM_MODO_POINTLIGHT_V_DISSOLVE,
                PARAM_MODO_POINTLIGHT_V_DISSOLVE_NAME);
        RegisterPointLightChannel (LXsICHAN_POINTLIGHT_VOLUMETRICS,
                PARAM_MODO_POINTLIGHT_VOLUMETRICS,
                PARAM_MODO_POINTLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);
        RegisterPointLightChannel (LXsICHAN_POINTLIGHT_VSAMPLES,
                PARAM_MODO_POINTLIGHT_V_SAMPLES,
                PARAM_MODO_POINTLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);
        RegisterPointLightChannel (LXsICHAN_POINTLIGHT_VRAD,
                PARAM_MODO_POINTLIGHT_V_RAD,
                PARAM_MODO_POINTLIGHT_V_RAD_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterPointLightChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_POINTLIGHT, channel,
                paramSID, paramName, paramType);
}

        void
ItemTypeChannelRegistrar::RegisterSpotLightChannels ()
{
        RegisterLightLocatorChannels (LXsITYPE_SPOTLIGHT);
        RegisterLightTargetChannels (LXsITYPE_SPOTLIGHT);

        RegisterSpotLightChannel (LXsICHAN_SPOTLIGHT_CONE,
                PARAM_MODO_SPOTLIGHT_CONE_ANGLE,
                PARAM_MODO_SPOTLIGHT_CONE_ANGLE_NAME);
        RegisterSpotLightChannel (LXsICHAN_SPOTLIGHT_EDGE,
                PARAM_MODO_SPOTLIGHT_SOFT_EDGE_ANGLE,
                PARAM_MODO_SPOTLIGHT_SOFT_EDGE_ANGLE_NAME);
        RegisterSpotLightChannel (LXsICHAN_SPOTLIGHT_OUTSIDE,
                PARAM_MODO_SPOTLIGHT_OUTSIDE,
                PARAM_MODO_SPOTLIGHT_OUTSIDE_NAME,
                PARAM_TYPE_BOOL);
        RegisterSpotLightChannel (LXsICHAN_SPOTLIGHT_RADIUS,
                PARAM_MODO_SPOTLIGHT_RADIUS,
                PARAM_MODO_SPOTLIGHT_RADIUS_NAME);
        RegisterSpotLightChannel (LXsICHAN_SPOTLIGHT_VDISSOLVE,
                PARAM_MODO_SPOTLIGHT_V_DISSOLVE,
                PARAM_MODO_SPOTLIGHT_V_DISSOLVE_NAME);
        RegisterSpotLightChannel (LXsICHAN_SPOTLIGHT_VOLUMETRICS,
                PARAM_MODO_SPOTLIGHT_VOLUMETRICS,
                PARAM_MODO_SPOTLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);
        RegisterSpotLightChannel (LXsICHAN_SPOTLIGHT_VSAMPLES,
                PARAM_MODO_SPOTLIGHT_V_SAMPLES,
                PARAM_MODO_SPOTLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);
}

        void
ItemTypeChannelRegistrar::RegisterSpotLightChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_SPOTLIGHT, channel,
                paramSID, paramName, paramType);
}

        void
ItemTypeChannelRegistrar::RegisterSunLightChannels ()
{
        RegisterLightLocatorChannels (LXsITYPE_SUNLIGHT);
        RegisterLightTargetChannels (LXsITYPE_SUNLIGHT);

        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_AZIMUTH,
                PARAM_MODO_SUNLIGHT_AZIMUTH,
                PARAM_MODO_SUNLIGHT_AZIMUTH_NAME);

        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_CLAMP,
                PARAM_MODO_SUNLIGHT_CLAMP_INTENSITY,
                PARAM_MODO_SUNLIGHT_CLAMP_INTENSITY_NAME,
                PARAM_TYPE_BOOL);

        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_DAY,
                PARAM_MODO_SUNLIGHT_DAY,
                PARAM_MODO_SUNLIGHT_DAY_NAME,
                PARAM_TYPE_INT);

        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_ELEVATION,
                PARAM_MODO_SUNLIGHT_ELEVATION,
                PARAM_MODO_SUNLIGHT_ELEVATION_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_HAZE,
                PARAM_MODO_SUNLIGHT_HAZE,
                PARAM_MODO_SUNLIGHT_HAZE_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_HEIGHT,
                PARAM_MODO_SUNLIGHT_HEIGHT,
                PARAM_MODO_SUNLIGHT_HEIGHT_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_LAT,
                PARAM_MODO_SUNLIGHT_LATITUDE,
                PARAM_MODO_SUNLIGHT_LATITUDE_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_LON,
                PARAM_MODO_SUNLIGHT_LONGITUDE,
                PARAM_MODO_SUNLIGHT_LONGITUDE_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_MAPSIZE,
                PARAM_MODO_SUNLIGHT_MAP_SIZE,
                PARAM_MODO_SUNLIGHT_MAP_SIZE_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_NORTH,
                PARAM_MODO_SUNLIGHT_NORTH,
                PARAM_MODO_SUNLIGHT_NORTH_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_RADIUS,
                PARAM_MODO_SUNLIGHT_RADIUS,
                PARAM_MODO_SUNLIGHT_RADIUS_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_SPREAD,
                PARAM_MODO_SUNLIGHT_SPREAD,
                PARAM_MODO_SUNLIGHT_SPREAD_NAME);

        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_SUNPOS,
                PARAM_MODO_SUNLIGHT_POSITION,
                PARAM_MODO_SUNLIGHT_POSITION_NAME,
                PARAM_TYPE_BOOL);

        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_TIME,
                PARAM_MODO_SUNLIGHT_TIME,
                PARAM_MODO_SUNLIGHT_TIME_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_TIMEZONE,
                PARAM_MODO_SUNLIGHT_TIME_ZONE,
                PARAM_MODO_SUNLIGHT_TIME_ZONE_NAME);

        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_VDISSOLVE,
                PARAM_MODO_SUNLIGHT_V_DISSOLVE,
                PARAM_MODO_SUNLIGHT_V_DISSOLVE_NAME);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_VOLUMETRICS,
                PARAM_MODO_SUNLIGHT_VOLUMETRICS,
                PARAM_MODO_SUNLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);
        RegisterSunLightChannel (LXsICHAN_SUNLIGHT_VSAMPLES,
                PARAM_MODO_SUNLIGHT_V_SAMPLES,
                PARAM_MODO_SUNLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);
}

        void
ItemTypeChannelRegistrar::RegisterSunLightChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_SUNLIGHT, channel,
                paramSID, paramName, paramType);
}

/*
 * Mesh channel registration.
 */
        void
ItemTypeChannelRegistrar::RegisterMeshChannels ()
{
        /*
         * Register base locator channels.
         */
        RegisterMeshChannel (LXsICHAN_LOCATOR_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE_NAME);
        RegisterMeshChannel (LXsICHAN_LOCATOR_DISSOLVE,
                PARAM_MODO_LOCATOR_DISSOLVE,
                PARAM_MODO_LOCATOR_DISSOLVE_NAME);
        RegisterMeshChannel (LXsICHAN_LOCATOR_RENDER,
                PARAM_MODO_LOCATOR_RENDER,
                PARAM_MODO_LOCATOR_RENDER_NAME,
                PARAM_TYPE_NAME);
        RegisterMeshChannel (LXsICHAN_LOCATOR_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE_NAME,
                PARAM_TYPE_NAME);

        /*
         * Register mesh-specific channels.
         */
        RegisterMeshChannel (LXsICHAN_MESH_RENDER_CURVES,
                PARAM_MODO_MESH_RENDER_CURVES,
                PARAM_MODO_MESH_RENDER_CURVES_NAME,
                PARAM_TYPE_BOOL);
        RegisterMeshChannel (LXsICHAN_MESH_CURVE_RADIUS,
                PARAM_MODO_MESH_CURVE_RADIUS,
                PARAM_MODO_MESH_CURVE_RADIUS_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterMeshChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_MESH, channel,
                paramSID, paramName, paramType);
}

/*
 * Render channel registration.
 */
        void
ItemTypeChannelRegistrar::RegisterRenderChannels ()
{
        /*
         * Register poly render channels.
         */

        /*
         * Render group.
         */
        RegisterRenderChannel (LXsICHAN_POLYRENDER_FIRST,
                PARAM_MODO_POLYRENDER_FRAME_RANGE_FIRST,
                PARAM_MODO_POLYRENDER_FRAME_RANGE_FIRST_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_LAST,
                PARAM_MODO_POLYRENDER_FRAME_RANGE_LAST,
                PARAM_MODO_POLYRENDER_FRAME_RANGE_LAST_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_STEP,
                PARAM_MODO_POLYRENDER_FRAME_STEP,
                PARAM_MODO_POLYRENDER_FRAME_STEP_NAME,
                PARAM_TYPE_INT);

        /*
         * Frame group.
         */
        RegisterRenderChannel (LXsICHAN_POLYRENDER_RESUNIT,
                PARAM_MODO_POLYRENDER_RESOLUTION_UNIT,
                PARAM_MODO_POLYRENDER_RESOLUTION_UNIT_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_RESX,
                PARAM_MODO_POLYRENDER_FRAME_WIDTH,
                PARAM_MODO_POLYRENDER_FRAME_WIDTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_RESY,
                PARAM_MODO_POLYRENDER_FRAME_HEIGHT,
                PARAM_MODO_POLYRENDER_FRAME_HEIGHT_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_DPI,
                PARAM_MODO_POLYRENDER_FRAME_DPI,
                PARAM_MODO_POLYRENDER_FRAME_DPI_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_PASPECT,
                PARAM_MODO_POLYRENDER_FRAME_PIXEL_ASPECT_RATIO,
                PARAM_MODO_POLYRENDER_FRAME_PIXEL_ASPECT_RATIO_NAME);

        /*
         * Buckets group.
         */
        RegisterRenderChannel (LXsICHAN_POLYRENDER_BUCKETX,
                PARAM_MODO_POLYRENDER_BUCKET_WIDTH,
                PARAM_MODO_POLYRENDER_BUCKET_WIDTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_BUCKETY,
                PARAM_MODO_POLYRENDER_BUCKET_HEIGHT,
                PARAM_MODO_POLYRENDER_BUCKET_HEIGHT_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_BKTORDER,
                PARAM_MODO_POLYRENDER_BUCKET_ORDER,
                PARAM_MODO_POLYRENDER_BUCKET_ORDER_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_BKTREVERSE,
                PARAM_MODO_POLYRENDER_BUCKET_REVERSE_ORDER,
                PARAM_MODO_POLYRENDER_BUCKET_REVERSE_ORDER_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_BKTWRITE,
                PARAM_MODO_POLYRENDER_BUCKET_WRITE_TO_DISK,
                PARAM_MODO_POLYRENDER_BUCKET_WRITE_TO_DISK_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_BKTSKIP,
                PARAM_MODO_POLYRENDER_BUCKET_SKIP_EXISTING,
                PARAM_MODO_POLYRENDER_BUCKET_SKIP_EXISTING_NAME,
                PARAM_TYPE_BOOL);

        /* 
         * Region.
         */
        RegisterRenderChannel (LXsICHAN_POLYRENDER_REGION,
                PARAM_MODO_RENDER_REGION,
                PARAM_MODO_RENDER_REGION_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_REGX0,
                PARAM_MODO_RENDER_REGION_LEFT,
                PARAM_MODO_RENDER_REGION_LEFT_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_REGX1,
                PARAM_MODO_RENDER_REGION_RIGHT,
                PARAM_MODO_RENDER_REGION_RIGHT_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_REGY0,
                PARAM_MODO_RENDER_REGION_TOP,
                PARAM_MODO_RENDER_REGION_TOP_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_REGY1,
                PARAM_MODO_RENDER_REGION_BOTTOM,
                PARAM_MODO_RENDER_REGION_BOTTOM_NAME);

        /*
         * Antialiasing.
         */
        RegisterRenderChannel (LXsICHAN_POLYRENDER_AA,
                PARAM_MODO_POLYRENDER_ANTIALIASING,
                PARAM_MODO_POLYRENDER_ANTIALIASING_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_AAFILTER,
                PARAM_MODO_POLYRENDER_ANTIALIASING_FILTER,
                PARAM_MODO_POLYRENDER_ANTIALIASING_FILTER_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_FINERATE,
                PARAM_MODO_POLYRENDER_REFINEMENT_SHADING_RATE,
                PARAM_MODO_POLYRENDER_REFINEMENT_SHADING_RATE_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_FINETHRESH,
                PARAM_MODO_POLYRENDER_REFINEMENT_THRESHOLD,
                PARAM_MODO_POLYRENDER_REFINEMENT_THRESHOLD_NAME);

        RegisterRenderChannel (LXsICHAN_POLYRENDER_BKTREFINE,
                PARAM_MODO_POLYRENDER_REFINE_BUCKET_BORDERS,
                PARAM_MODO_POLYRENDER_REFINE_BUCKET_BORDERS_NAME,
                PARAM_TYPE_BOOL);

        /*
         * Register render channels.
         */

        /*
         * Ray Tracing.
         */
        RegisterRenderChannel (LXsICHAN_RENDER_RAYSHADOW,
                PARAM_MODO_RENDER_RAY_TRACING_SHADOWS,
                PARAM_MODO_RENDER_RAY_TRACING_SHADOWS_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_REFLDEPTH,
                PARAM_MODO_RENDER_REFLECTION_DEPTH,
                PARAM_MODO_RENDER_REFLECTION_DEPTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_REFRDEPTH,
                PARAM_MODO_RENDER_REFRACTION_DEPTH,
                PARAM_MODO_RENDER_REFRACTION_DEPTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_RAYTHRESH,
                PARAM_MODO_RENDER_RAY_THRESHOLD,
                PARAM_MODO_RENDER_RAY_THRESHOLD_NAME);

        /*
         * Geometry.
         */
        RegisterRenderChannel (LXsICHAN_RENDER_SUBDADAPT,
                PARAM_MODO_RENDER_ADAPTIVE_SUBDIVISION,
                PARAM_MODO_RENDER_ADAPTIVE_SUBDIVISION_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_SUBDRATE,
                PARAM_MODO_RENDER_SUBDIVISION_RATE,
                PARAM_MODO_RENDER_SUBDIVISION_RATE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_DISPENABLE,
                PARAM_MODO_RENDER_MICROPOLY_DISPLACEMENT,
                PARAM_MODO_RENDER_MICROPOLY_DISPLACEMENT_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_DISPRATE,
                PARAM_MODO_RENDER_DISPLACEMENT_RATE,
                PARAM_MODO_RENDER_DISPLACEMENT_RATE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_DISPRATIO,
                PARAM_MODO_RENDER_DISPLACEMENT_RATIO,
                PARAM_MODO_RENDER_DISPLACEMENT_RATIO_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_EDGEMIN,
                PARAM_MODO_RENDER_MINIMUM_EDGE_LENGTH,
                PARAM_MODO_RENDER_MINIMUM_EDGE_LENGTH_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_DISPSMOOTH,
                PARAM_MODO_RENDER_SMOOTH_POSITIONS,
                PARAM_MODO_RENDER_SMOOTH_POSITIONS_NAME,
                PARAM_TYPE_BOOL);

        /*
         * Ambient Light.
         */
        RegisterRenderChannel (LXsICHAN_RENDER_AMBRAD,
                PARAM_MODO_RENDER_AMBIENT_INTENSITY,
                PARAM_MODO_RENDER_AMBIENT_INTENSITY_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_AMBCOLOR,
                PARAM_MODO_RENDER_AMBIENT_COLOR,
                PARAM_MODO_RENDER_AMBIENT_COLOR_NAME,
                PARAM_TYPE_COLOR);

        /*
         * Indirect Illumination.
         */
        RegisterRenderChannel (LXsICHAN_RENDER_GLOBENABLE,
                PARAM_MODO_RENDER_ENABLE_INDIRECT_ILLUMINATION,
                PARAM_MODO_RENDER_ENABLE_INDIRECT_ILLUMINATION_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBSCOPE,
                PARAM_MODO_RENDER_INDIRECT_ILLUMINATION_SCOPE,
                PARAM_MODO_RENDER_INDIRECT_ILLUMINATION_SCOPE_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBRAYS,
                PARAM_MODO_RENDER_INDIRECT_RAYS,
                PARAM_MODO_RENDER_INDIRECT_RAYS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBLIMIT,
                PARAM_MODO_RENDER_INDIRECT_BOUNCES,
                PARAM_MODO_RENDER_INDIRECT_BOUNCES_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBRANGE,
                PARAM_MODO_RENDER_INDIRECT_RANGE,
                PARAM_MODO_RENDER_INDIRECT_RANGE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBSUBS,
                PARAM_MODO_RENDER_SUBSURFACE_SCATTERING,
                PARAM_MODO_RENDER_SUBSURFACE_SCATTERING_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBVOLS,
                PARAM_MODO_RENDER_VOLUMETRICS_AFFECT_INDIRECT,
                PARAM_MODO_RENDER_VOLUMETRICS_AFFECT_INDIRECT_NAME,
                PARAM_TYPE_BOOL);

        /*
         * Irradiance Caching.
         */
        RegisterRenderChannel (LXsICHAN_RENDER_IRRCACHE,
                PARAM_MODO_RENDER_ENABLE_IRRADIANCE_CACHING,
                PARAM_MODO_RENDER_ENABLE_IRRADIANCE_CACHING_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRRAYS,
                PARAM_MODO_RENDER_IRRADIANCE_RAYS,
                PARAM_MODO_RENDER_IRRADIANCE_RAYS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBSUPER,
                PARAM_MODO_RENDER_INDIRECT_SUPERSAMPLING,
                PARAM_MODO_RENDER_INDIRECT_SUPERSAMPLING_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRRATE,
                PARAM_MODO_RENDER_IRRADIANCE_RATE,
                PARAM_MODO_RENDER_IRRADIANCE_RATE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRRATIO,
                PARAM_MODO_RENDER_IRRADIANCE_RATIO,
                PARAM_MODO_RENDER_IRRADIANCE_RATIO_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRVALS,
                PARAM_MODO_RENDER_INTERPOLATION_VALUES,
                PARAM_MODO_RENDER_INTERPOLATION_VALUES_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRGRADS,
                PARAM_MODO_RENDER_IRRADIANCE_GRADIENTS,
                PARAM_MODO_RENDER_IRRADIANCE_GRADIENTS_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRWALK,
                PARAM_MODO_RENDER_WALKTHROUGH_MODE,
                PARAM_MODO_RENDER_WALKTHROUGH_MODE_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRLENABLE,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_BEFORE_RENDER,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_BEFORE_RENDER_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRLNAME,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_FILE,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_FILE_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRSENABLE,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_AFTER_RENDER,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_AFTER_RENDER_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_IRRSNAME,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_FILE,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_FILE_NAME,
                PARAM_TYPE_NAME);

        /*
         * Caustics.
         */
        RegisterRenderChannel (LXsICHAN_RENDER_CAUSENABLE,
                PARAM_MODO_RENDER_ENABLE_DIRECT_CAUSTICS,
                PARAM_MODO_RENDER_ENABLE_DIRECT_CAUSTICS_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderChannel (LXsICHAN_RENDER_CAUSTOTAL,
                PARAM_MODO_RENDER_CAUSTICS_TOTAL_PHOTONS,
                PARAM_MODO_RENDER_CAUSTICS_TOTAL_PHOTONS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_CAUSLOCAL,
                PARAM_MODO_RENDER_CAUSTICS_LOCAL_PHOTONS,
                PARAM_MODO_RENDER_CAUSTICS_LOCAL_PHOTONS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderChannel (LXsICHAN_RENDER_GLOBCAUS,
                PARAM_MODO_RENDER_INDIRECT_CAUSTICS,
                PARAM_MODO_RENDER_INDIRECT_CAUSTICS_NAME,
                PARAM_TYPE_NAME);
}

        void
ItemTypeChannelRegistrar::RegisterRenderChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_POLYRENDER, channel,
                paramSID, paramName, paramType);
}

/*
 * Environment channel registration.
 */
        void
ItemTypeChannelRegistrar::RegisterEnvironmentChannels ()
{
        RegisterEnvironmentChannel (LXsICHAN_ENVIRONMENT_RADIANCE,
                PARAM_MODO_ENVIRONMENT_INTENSITY,
                PARAM_MODO_ENVIRONMENT_INTENSITY_NAME);

        RegisterEnvironmentChannel (LXsICHAN_ENVIRONMENT_VISCAM,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_CAMERA,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_CAMERA_NAME,
                PARAM_TYPE_BOOL);

        RegisterEnvironmentChannel (LXsICHAN_ENVIRONMENT_VISIND,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_INDIRECT_RAYS,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_INDIRECT_RAYS_NAME,
                PARAM_TYPE_BOOL);

        RegisterEnvironmentChannel (LXsICHAN_ENVIRONMENT_VISREFL,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFLECTION_RAYS,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFLECTION_RAYS_NAME,
                PARAM_TYPE_BOOL);

        RegisterEnvironmentChannel (LXsICHAN_ENVIRONMENT_VISREFR,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFRACTION_RAYS,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFRACTION_RAYS_NAME,
                PARAM_TYPE_BOOL);
}

        void
ItemTypeChannelRegistrar::RegisterEnvironmentChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_ENVIRONMENT, channel,
                paramSID, paramName, paramType);
}

/*
 * Environment Material channel registration.
 */
        void
ItemTypeChannelRegistrar::RegisterEnvironmentMaterialChannels ()
{
        /*
         * Environment Material.
         */
        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_TYPE,
                PARAM_MODO_ENVIRONMENT_MATERIAL_TYPE,
                PARAM_MODO_ENVIRONMENT_MATERIAL_TYPE_NAME,
                PARAM_TYPE_NAME);

        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_ZENCOLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_ZENITH_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_ZENITH_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_SKYCOLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_GNDCOLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_NADCOLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_NADIR_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_NADIR_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_SKYEXP,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_EXPONENT,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_EXPONENT_NAME);

        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_GNDEXP,
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_EXPONENT,
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_EXPONENT_NAME);

        /*
         * Physically-based Daylight.
         */
        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_DISC,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SOLAR_DISC_SIZE,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SOLAR_DISC_SIZE_NAME);

        RegisterEnvironmentMaterialChannel (LXsICHAN_ENVMATERIAL_NORMALIZE,
                PARAM_MODO_ENVIRONMENT_MATERIAL_CLAMP_SKY_BRIGHTNESS,
                PARAM_MODO_ENVIRONMENT_MATERIAL_CLAMP_SKY_BRIGHTNESS_NAME,
                PARAM_TYPE_BOOL);
}

        void
ItemTypeChannelRegistrar::RegisterEnvironmentMaterialChannel (
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterChannel (LXsITYPE_ENVMATERIAL, channel,
                paramSID, paramName, paramType);
}

