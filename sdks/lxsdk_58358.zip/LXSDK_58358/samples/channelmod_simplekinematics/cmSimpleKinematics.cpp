/*
 * Plug-in Simple Kinematics channel modifier.
 *
 * This channel modifier applies the equation of motion derived from a constant acceleration to
 * the given channel. The inputs are the initial position and speed, and the acceleration. In addition, 
 * the user can specify a starting time before which the modifier simply returns the initial position.
 * Currently this version does not support animated acceleration, which would require integrating the 
 * acceleration numerically with every evaluation.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cmSimpleKinematics.h"

#include <lx_plugin.hpp>

#include <string>

// Simple Kinematics Instance

        LxResult
CSimpleKinematicsInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        log.Info ("Initialize");
        
        m_item.set (item);
        
        return LXe_OK;
}

        void
CSimpleKinematicsInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

        LxResult
CSimpleKinematicsInstance::pins_SynthName (
        char			*buf,
        unsigned		 len)
{
        std::string name ("Simple Kinematics");
        size_t count = name.size () + 1;
        if (count > len) {
                count = len;
        }
        memcpy (buf, &name[0], count);

        return LXe_OK;
}

        LxResult
CSimpleKinematicsInstance::cmod_Allocate (
        ILxUnknownID		 cmod,		// ILxChannelModifierID
        ILxUnknownID		 eval,		// ILxEvaluationID
        ILxUnknownID		 item,
        void		       **ppvData)
{
        CLxLoc_ChannelModifier	 chanMod (cmod);
        CLxUser_Item		 modItem (item);
        unsigned int		 chanIdx;
        
//	log.Info ("cmod_Allocate Method");
        
        // Lookup the index of the 'startValue' channel and add as an input.
        modItem.ChannelLookup ("startValue", &chanIdx);
        chanMod.AddInput (item, chanIdx);

        // Lookup the index of the 'startTime' channel and add as an input.
        modItem.ChannelLookup ("startTime", &chanIdx);
        chanMod.AddInput (item, chanIdx);

        // Lookup the index of the 'startSpeed' channel and add as an input.
        modItem.ChannelLookup ("startSpeed", &chanIdx);
        chanMod.AddInput (item, chanIdx);

        // Lookup the index of the 'acceleration' channel and add as an input.
        modItem.ChannelLookup ("acceleration", &chanIdx);
        chanMod.AddInput (item, chanIdx);
                
        // we need the time as well
        chanMod.AddTime ();
        
        // Lookup the index of the 'output' channel and add it as an output.
        modItem.ChannelLookup ("output", &chanIdx);
        chanMod.AddOutput (item, chanIdx);
                
        return LXe_OK;
}

        void
CSimpleKinematicsInstance::cmod_Cleanup (
        void			*data)
{

}

        unsigned int
CSimpleKinematicsInstance::cmod_Flags (
        ILxUnknownID		 item,
        unsigned int		 index)
{
        CLxUser_Item		 modItem (item);
        unsigned int		 chanIdx;
        
//	log.Info ("cmod_Flags Method");
        
        if (LXx_OK (modItem.ChannelLookup ("startValue", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_INPUT;
        }
        
        if (LXx_OK (modItem.ChannelLookup ("startTime", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_INPUT;
        }
        
        if (LXx_OK (modItem.ChannelLookup ("startSpeed", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_INPUT;
        }
        
        if (LXx_OK (modItem.ChannelLookup ("acceleration", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_INPUT;
        }
        
        if (LXx_OK (modItem.ChannelLookup ("output", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_OUTPUT;
        }
        
        return 0;
}

        LxResult
CSimpleKinematicsInstance::cmod_Evaluate (
        ILxUnknownID		 cmod,		// ILxChannelModifierID
        ILxUnknownID		 attr,		// ILxAttributesID
        void			*data)		
{
        CLxLoc_ChannelModifier	 chanMod (cmod);
        double			 t0, v0, x0, a, t=1;
        
//	log.Info ("cmod_Evaluate Method");
        
        chanMod.ReadInputFloat (attr, 0, &x0);
        chanMod.ReadInputFloat (attr, 1, &t0);
        chanMod.ReadInputFloat (attr, 2, &v0);
        chanMod.ReadInputFloat (attr, 3, &a);
        chanMod.ReadInputFloat (attr, 4, &t);
        
        if(t>=t0) {
                t -= t0;
                x0 += v0*t + 0.5*a*t*t;
        }
        
        chanMod.WriteOutputFloat (attr, 0, x0);
        
        return LXe_OK;
}

// Package class

LXtTagInfoDesc	 CSimpleKinematicsPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,	"chanModify"	},
        { LXsSRV_LOGSUBSYSTEM,	"cmSimpleKinematics"	},
        { 0 }
};

// Constructor

CSimpleKinematicsPackage::CSimpleKinematicsPackage ()
{
        chanmod_factory.AddInterface (new CLxIfc_PackageInstance<CSimpleKinematicsInstance>);
        chanmod_factory.AddInterface (new CLxIfc_ChannelModItem<CSimpleKinematicsInstance>);
}


        LxResult
CSimpleKinematicsPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        
        ac.NewChannel ("startValue", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("startTime", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);
        
        ac.NewChannel ("startSpeed", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("acceleration", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);
        
        ac.NewChannel ("output", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);

        return LXe_OK;
}

        LxResult
CSimpleKinematicsPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return (chanmod_factory.TestInterface (guid) ? LXe_TRUE : LXe_FALSE);
}

        LxResult
CSimpleKinematicsPackage::pkg_Attach (
        void		       **ppvObj)
{
        CSimpleKinematicsInstance	*chanmod = chanmod_factory.Alloc (ppvObj);

        chanmod->src_pkg  = this;
        chanmod->inst_ifc = (ILxUnknownID) ppvObj[0];

        return LXe_OK;
}

        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CSimpleKinematicsPackage>;
        srv->AddInterface (new CLxIfc_Package          <CSimpleKinematicsPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc       <CSimpleKinematicsPackage>);
        thisModule.AddServer ("cmSimpleKinematics", srv);
}

