/*
 * Copyright (c) 2009 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include "lxoChunks.hpp"
#include "lxoCopy.hpp"

typedef union {
        float           f;
        LxULong         u;
        LxByte          b[4];
        } Union4Bytes;

typedef union {
        LxUShort        u;
        LxByte          b[2];
        } Union2Bytes;

typedef std::map<LxULong, LxULong>  LXtMap_RemapIds;

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Search a list of strings and returns the index of the matching entry; 0 if not found.
 *
 *----------------------------------------------------------------------------*/
static LxUShort GetStringIndex (LXtMap_StringIds& map, const char* name)
{
    LXtMap_StringIds::iterator  iter = map.find (name);

    return iter != map.end() ? iter->second : 0;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * The LxpTest class extends LxoReader to read an LXP file and test if
 * it uses any UV maps.  Stop reading the file as soon as one is found.
 *
 *----------------------------------------------------------------------------*/
class LxpTest : public LxoReader {

    public:
        bool                m_uvMapsUsed;           // true if a projType of "uv" is found

        LxpTest (char const* lxoName) : LxoReader (lxoName) { m_uvMapsUsed = false; }

        bool                    AreUvMapsNeeded ();

        virtual LXChunkUsage    ChunkUsage () { return LxpReaderChunkUsage (m_chunkId); }   // choose which chunks to process/ignore
        virtual LxResult        ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 * look for the projection type and see if it is UV
 *----------------------------------------------------------------------------*/
LxResult LxpTest::ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length)
{
    if ((LXItemType_String != type && LXItemType_EnvelopeString != type)
            || 0 != strcmp (name, LXsICHAN_TEXTURELOC_PROJTYPE)
            || 0 != strcmp (strVal, LXsICVAL_TEXTURELOC_PROJTYPE_UV))
        return LXe_OK;

    m_uvMapsUsed = true;        // one we found a uv map we're done
    return LXe_ABORT;           // stop reading
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * return whether or not any uv maps are required for this LXP
 *----------------------------------------------------------------------------*/
bool LxpTest::AreUvMapsNeeded ()
{
    return LXe_ABORT == ReadFile () && m_uvMapsUsed;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * The LxpImport class extends LxoCopy to read and export a copy of an
 * LXP file, ignoring irrelevant parts and remapping the requred ID's.
 *
 *----------------------------------------------------------------------------*/
class LxpImport : public LxoCopy {

        LxResult            m_result;

        char const*         m_materialName;
        bool                m_materialLinkFound;    // true if a PTAG is found for this LXP

        LxULong             m_rootMaskItemId;       // id of the mask item at the root of this LXP material
        LxULong             m_materialItemId;       // id of the advancedMaterial item of this LXP material
        LxULong             m_uvMapIndex;           // index uf the Nth UV map that this instance uses

        LXtMap_RemapIds     m_remappedItemIds;      // map of old LXP item id and new LXO id
        LXtMap_RemapIds     m_remappedEnvelopeIds;  // map of old LXP envelope id and new LXO id

    public:
        LxoWriteData*       m_writer;               // writer class to use to actually write the chunk
        LxULong             m_rootMaskItemIndex;    // index of the last masked item in this LXP material
        bool                m_materialShaderFound;  // true if a defaultShader is found for this LXP
        bool                m_multipleUvMaps;       // true if a projType of "uv" is found and there are multiple uv maps

        LxpImport (LxoWriteData* writer, char const* materialName, char const* lxoName, bool multipleUvMaps, LxULong uvMapIndex) : LxoCopy (lxoName, writer)
            {
            m_writer                = writer;
            m_materialName          = materialName;
            m_materialLinkFound     = false;
            m_materialShaderFound   = false;
            m_multipleUvMaps        = multipleUvMaps;
            m_rootMaskItemId        = 0;
            m_rootMaskItemIndex     = 0;
            m_materialItemId        = 0;
            m_uvMapIndex            = uvMapIndex;
            }

        LxULong                 GetRemappedItemId (LxULong id);
        LxULong                 GetRemappedEnvelopeId (LxULong id);

        virtual LXChunkUsage    ChunkUsage () { return LxpReaderChunkUsage (m_chunkId); }   // choose chunks to process/ignore
        virtual LXChunkUsage    ItemSubChunkUsage ();                                       // choose items to process/copy

        virtual LxResult	ProcessItem (char* itemType, char* name, LxULong refId);
        virtual LxResult	ProcessItemEnd ();

        virtual LxResult	ProcessItemLink (char* name, LxULong refId, LxULong index);
        virtual LxResult	ProcessItemGradient (char* name, LxULong envelopeIndex, LxULong flags, char* inType, char* outType);
        virtual LxResult	ProcessItemChannelString (char* name, char* str);

        virtual LxResult	ProcessEnvelope (LxULong index, LxULong type);
};

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * find the item id in the new LXO file that corresponds to the id
 * that was imorted from the LXP file.
 *
 *----------------------------------------------------------------------------*/
LxULong LxpImport::GetRemappedItemId (LxULong id)
{
    LXtMap_RemapIds::iterator   iter = m_remappedItemIds.find (id);

    if (iter != m_remappedItemIds.end())
        return iter->second;

    return m_remappedItemIds[id] = ++(m_writer->m_itemId);          // use the next item id for this remapped item
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * find the envelope id in the new LXO file that corresponds to the id
 * that was imorted from the LXP file.
 *
 *----------------------------------------------------------------------------*/
LxULong LxpImport::GetRemappedEnvelopeId (LxULong id)
{
    LXtMap_RemapIds::iterator   iter = m_remappedEnvelopeIds.find (id);

    if (iter != m_remappedEnvelopeIds.end())
        return iter->second;

    return m_remappedEnvelopeIds[id] = ++(m_writer->m_envelopeId);  // use the next envelope id for this remapped item
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * For an LXP file, just copy all chunks other than those listed in the switch,
 * which require special processing for ID remapping.
 *
 *----------------------------------------------------------------------------*/
        LXChunkUsage
LxpImport::ItemSubChunkUsage (void)
{
    switch (m_subChunkId)
        {
        case 'LINK':        // Item linking sub-chunk
        case 'GRAD':        // Gradient channel value sub-chunk
        case 'CHNS':        // String channel value sub-chunk

            return LXChunk_Process;     // perform special processing on these item chunks
        }

    return LXChunk_Copy;                // copy the entire chunk without additional processing
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * export an item chunk to the LXO file.
 *
 * certain item types may need to have some data remapped from the LXP
 *
 *----------------------------------------------------------------------------*/
LxResult LxpImport::ProcessItem (char* itemType, char* name, LxULong refId)
{
    if (0 == strcmp (itemType, LXsITYPE_DEFAULTSHADER))    // need to know a shader was written
        {
        m_materialShaderFound = true;
        }

    else if (0 == strcmp (itemType, LXsITYPE_MASK))         // need to identify 1st mask
        {
        if (0 == m_rootMaskItemId)                          // treat the first, top-level mask as the root for this material
            {
            // record the next item id, which will be the id of this mask, so we can remap
            // all PARENT tags to point to this mask

            m_rootMaskItemId = m_writer->m_itemId + 1;
            if (m_multipleUvMaps)
                name = (char*)m_writer->GetUvMapName (name, m_uvMapIndex);    // rename the material to show there is one per uv map
            }
        }
    else if (0 == strcmp (itemType, LXsITYPE_ADVANCEDMATERIAL))     // app may want to overridesome material attributes
        {
        if (0 == m_materialItemId)
            m_materialItemId = m_writer->m_itemId + 1;      // record the id of this item in case app wants to modify any sub-chunks
        }

    return LxoCopy::ProcessItem (itemType, name, GetRemappedItemId (refId));    // write a copy of the remapped item header
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * close the current item chunk
 *----------------------------------------------------------------------------*/
LxResult LxpImport::ProcessItemEnd ()
{
    if (! m_materialLinkFound && m_writer->m_itemId == m_rootMaskItemId)    // must add link to current material
        {
        // when multiple UV maps are used, each is grouped as a PART mask with a unique name
        // that includes the uv map index; otherwise we just use a material mask with
        // the original material name.

        ReturnOnError (LxoNameStringSubChunk (m_writer).Write (LXsICHAN_MASK_PTAG, m_multipleUvMaps ? m_writer->GetUvMapName (m_materialName, m_uvMapIndex) : m_materialName));
        ReturnOnError (LxoNameStringSubChunk (m_writer).Write (LXsICHAN_MASK_PTYP, m_multipleUvMaps ? "Part" : "Material"));
        }

    return LxoCopy::ProcessItemEnd ();      // close the copy of the item
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * remap the item id in the link sub-chunk and write to the LXO
 *----------------------------------------------------------------------------*/
LxResult LxpImport::ProcessItemLink (char* name, LxULong refId, LxULong index)
{
    if (0xffffffff == refId)                        // links to '-1' cannot be resolved and are not copied
        return LXe_OK;

    if (m_writer->m_itemId == m_rootMaskItemId)     // link the root mask to the renderItem
        return LxoLinkSubChunk (m_writer).Write (name, m_writer->m_renderItemId, m_writer->m_renderItemIndex++);

    LxULong     mappedRefId = GetRemappedItemId (refId);

    if (mappedRefId == m_rootMaskItemId && m_rootMaskItemIndex < index)
        m_rootMaskItemIndex = index;

    return LxoLinkSubChunk (m_writer).Write (name, mappedRefId, index);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * remap the envelope id in the gradient sub-chunk and write to the LXO
 *----------------------------------------------------------------------------*/
LxResult LxpImport::ProcessItemGradient (char* name, LxULong envelopeIndex, LxULong flags, char* inType, char* outType)
{
    return LxoGradientSubChunk (m_writer).Write (name, GetRemappedEnvelopeId (envelopeIndex), flags, inType, outType);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * remap the various strings in an item
 *----------------------------------------------------------------------------*/
LxResult LxpImport::ProcessItemChannelString (char* name, char* str)
{
    if (0 == strcmp (name, LXsICHAN_TEXTURELOC_UVMAP))      // need to remap uvmaps
        return LxoNameStringSubChunk (m_writer).Write (LXsICHAN_TEXTURELOC_UVMAP, m_writer->GetUvMapName (m_materialName, m_uvMapIndex));

    if (m_writer->m_itemId == m_rootMaskItemId)             // must link the top-level mask for the preset to the current material
        {
        // when multiple UV maps are used, each is grouped as a PART mask with a unique name
        // that includes the uv map index; otherwise we just use a material mask with
        // the original material name.

        if (0 == strcmp (name, LXsICHAN_MASK_PTYP))         // the link type depends on if there are multiple UV maps
            return LxoNameStringSubChunk (m_writer).Write (name, m_multipleUvMaps ? "Part" : "Material");

        if (0 == strcmp (name, LXsICHAN_MASK_PTAG))         // use the corrent name to link to
            {
            m_materialLinkFound = true;
            return LxoNameStringSubChunk (m_writer).Write (name, m_multipleUvMaps ? m_writer->GetUvMapName (m_materialName, m_uvMapIndex) : m_materialName);
            }
        }

    if (0 == strcmp (name, LXsICHAN_VIDEOSTILL_FILENAME))   // might need to remap filenames to new locations
        {
        // Not implemented -- just stubbed for future use
        }

    return LxoNameStringSubChunk (m_writer).Write (name, str);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * export a copy of the envelope from a preset, using the CURRENT envelope id
 *
 *----------------------------------------------------------------------------*/
LxResult LxpImport::ProcessEnvelope (LxULong index, LxULong type)
{
    LxULong     count = m_unreadChunkBytes;
    LxByte*     bytes = (LxByte*) _alloca (count);

    if (NULL == bytes)
        return LXe_OUTOFMEMORY;

    ReturnOnError (ReadBytes (bytes, count));

    return LxoEnvelopeChunk (m_writer).Write (type, GetRemappedEnvelopeId (index), bytes, count);
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Values are stored in the file in big-endian order; must be byte reversed
 * for Intel (little-endian) architectures
 *
 *----------------------------------------------------------------------------*/
static void swapBytes (Union4Bytes* val)
{
    Union4Bytes     temp;

    temp.u = val->u;

    val->b[0] = temp.b[3];
    val->b[1] = temp.b[2];
    val->b[2] = temp.b[1];
    val->b[3] = temp.b[0];
}

static void swapBytes (Union2Bytes* val)
{
    Union2Bytes     temp;

    temp.u = val->u;

    val->b[0] = temp.b[1];
    val->b[1] = temp.b[0];
}

static void swapBytes (float& val)      { swapBytes ((Union4Bytes*)&val); }
static void swapBytes (LxULong& val)    { swapBytes ((Union4Bytes*)&val); }
static void swapBytes (LxUShort& val)   { swapBytes ((Union2Bytes*)&val); }

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Constructor for LXO file Writer validates & opens the file
 *
 *----------------------------------------------------------------------------*/
LxoWriteData::LxoWriteData (char const* lxoName, char const** channelNames, int nChannelNames)
{
    m_itemId = m_renderItemId = m_envelopeId = m_layerId = m_itemIdSunlight = 0;

    m_renderItemIndex = 0;
    m_maxLightLumens  = m_skyLumens       = 0.f;

    if (NULL == (m_outFile = fopen (lxoName, "wb")))
        fprintf (stderr, "Error creating LXO file <%s>\n", lxoName);

    /*
     * insert all of the channel names into a sorted map; initially set the index for each to 0.
     */
    for (LxUShort i = 0; i< nChannelNames; i++)
        m_channels.insert (std::pair <std::string, int>(channelNames[i], 0));

    /*
     * Next, iterate through the sorted list, assigning indices starting at 1.
     * [Index 0 is reserved for "unknown" and is the error case.
     */
    int     index = 0;
    for (LXtMap_StringIds::iterator iter = m_channels.begin(), end = m_channels.end(); iter != end; ++iter)
        iter->second = ++index;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Destructor writes the file size into the header, then closes the file.
 *
 *----------------------------------------------------------------------------*/
LxoWriteData::~LxoWriteData ()
{
    if (NULL == m_outFile)
        return;

    static LxULong  s_fileSizePos = 4;      // position of the file size word

    LxULong         fileSize = ftell (m_outFile) - 2 * sizeof (LxULong);

    swapBytes (fileSize);

    fseek  (m_outFile, s_fileSizePos, SEEK_SET);
    fwrite (&fileSize, sizeof fileSize, 1, m_outFile);

    fclose (m_outFile);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * return the UV map name for the given material and index
 *
 *----------------------------------------------------------------------------*/
        char const* 
LxoWriteData::GetUvMapName (char const *materialName, int uvMapIndex)
{
    static char     uvMapName[512];

    sprintf (uvMapName, "%s_uv%d", materialName, uvMapIndex);

    return uvMapName;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This method searches the list of channel names and returns the index
 * of the matching entry, or 0 if not found.
 *
 *----------------------------------------------------------------------------*/
        LxUShort
LxoWriteData::GetChannelIndex (const char* name)
{
    LxUShort    index = GetStringIndex (m_channels, name);

    if (0 == index)
        fprintf (stderr, "Error: Channel <%s> not defined.\n", name);

    return index;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This method searches the list of channel names and returns the index
 * of the matching entry, or 0 if not found.
 *
 *----------------------------------------------------------------------------*/
        LxUShort
LxoWriteData::GetTagIndex (const char* name)
{
    LxUShort    index = GetStringIndex (m_tags, name);

    if (0 == index)
        fprintf (stderr, "Error: tag <%s> not defined.\n", name);

    return index;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write a number of bytes, with no byte swapping.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteBytes (LxByte const* val, LxULong count)
{
        return (NULL == m_outFile || count != fwrite (val, 1, count, m_outFile)) ? LXe_IO_ERROR : LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write any number of values, swapping bytes from big-endian to little-endian.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteShorts (LxUShort const* val, LxULong count)
{
        LxULong         iter    = count;
        LxUShort*       out     = (LxUShort*)_alloca (count * sizeof *val);
        LxUShort*       outP    = out;
        LxUShort const* inP     = val;

        if (NULL == out)
            return LXe_OUTOFMEMORY;

        while (iter-- > 0)
            swapBytes (*outP++ = *inP++);

        return (NULL == m_outFile || count != fwrite (out, sizeof *out, count, m_outFile)) ? LXe_IO_ERROR : LXe_OK;
}

        LxResult
LxoWriteData::WriteLongs (LxULong const* val, LxULong count)
{
        LxULong         iter    = count;
        LxULong*        out     = (LxULong*)_alloca (count * sizeof *val);
        LxULong*        outP    = out;
        LxULong const*  inP     = val;

        if (NULL == out)
            return LXe_OUTOFMEMORY;

        while (iter-- > 0)
            swapBytes (*outP++ = *inP++);

        return (NULL == m_outFile || count != fwrite (out, sizeof *out, count, m_outFile)) ? LXe_IO_ERROR : LXe_OK;
}

        LxResult
LxoWriteData::WriteIndexes (LxULong const* val, LxULong count)
{
        while (count-- > 0)
            ReturnOnError (WriteIndex (*val++));

        return LXe_OK;
}

        LxResult
LxoWriteData::WriteInts (int const* val, LxULong count)
{
        return WriteLongs ((LxULong*)val, count);
}

        LxResult
LxoWriteData::WriteFloats (float const* val, LxULong count)
{
        return WriteLongs ((LxULong*)val, count);
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write a Variable length index, used to represent an index into a list.
 * If the value is < 0xFF, write it as a 2-byte value; otherwise, write it as 
 * a 4-byte value, but put 0xFF in the high byte so it will be known to be
 * stored in 4 bytes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteIndex (LxULong const value)
{
        if (value < 0xFF00)
            return WriteShort ((LxUShort)value);

        return WriteLong (value | 0xFF000000);
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write a null-terminated string.  All strings in the file are padded to an
 * even number of bytes, so if the string is an odd number of bytes, write
 * an extra 0 byte.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteString (char const* val)
{
        if (NULL == m_outFile)
            return LXe_IO_ERROR;

        size_t      outBytes = strlen (val) + 1;        // have to write the NULL too

        if (outBytes != fwrite (val, 1, outBytes, m_outFile))
            return LXe_IO_ERROR;

        // write extra byte if string length is odd
        if (outBytes & 1)
            return 1 != fwrite (val, 1, 1, m_outFile) ? LXe_IO_ERROR : LXe_OK;

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write the ID and a placeholder for the chink size, and record the position
 * of the chunk size in the file.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::BeginChunk (LXtID4 const id)
{
        LxResult    result = WriteLong (id);

        m_chunkSizePos = ftell (m_outFile);

        return LXe_OK == result ? WriteLong (0) : result;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write the ID and a placeholder for the chink size, and record the position
 * of the chunk size in the file.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::EndChunk ()
{
        LxULong     chunkSize = ftell (m_outFile) - m_chunkSizePos - sizeof (LxULong);

        swapBytes (chunkSize);

        fseek  (m_outFile, m_chunkSizePos, SEEK_SET);
        size_t      count = fwrite (&chunkSize, sizeof chunkSize, 1, m_outFile);
        fseek  (m_outFile, 0, SEEK_END);

        return 1 == count ? LXe_OK : LXe_IO_ERROR;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write the ID and a placeholder for the chink size, and record the position
 * of the chunk size in the file.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::BeginSubChunk (LXtID4 const id)
{
        LxResult    result = WriteLong (id);

        m_subChunkSizePos = ftell (m_outFile);

        return LXe_OK == result ? WriteShort (0) : result;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Write the ID and a placeholder for the chink size, and record the position
 * of the chunk size in the file.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::EndSubChunk ()
{
        LxUShort     subChunkSize = (LxUShort)(ftell (m_outFile) - m_subChunkSizePos - sizeof (LxUShort));

        swapBytes (subChunkSize);

        fseek  (m_outFile, m_subChunkSizePos, SEEK_SET);
        size_t      count = fwrite (&subChunkSize, sizeof subChunkSize, 1, m_outFile);
        fseek  (m_outFile, 0, SEEK_END);

        return 1 == count ? LXe_OK : LXe_IO_ERROR;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out all channel names used for this LXO file
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteChannels ()
{
    ReturnOnError (WriteLong   (1 + (LxULong)m_channels.size ()));      // add "unknown" as zero-th entry
    ReturnOnError (WriteString ("unknown"));

    for (LXtMap_StringIds::iterator iter = m_channels.begin(), end = m_channels.end(); iter != end; ++iter)
        ReturnOnError (WriteString (iter->first.c_str()));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out all channel names used for this LXO file
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteChannels (LXtStringVec fileChannels, LxULong count)
{
    ReturnOnError (WriteLong (count));

    for (LxULong i = 0; i < count; ++i)
        {
        m_channels.insert (std::pair <std::string, int>(fileChannels[i], i));
        ReturnOnError (WriteString (fileChannels[i].c_str()));
        }

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out all tags names used for this LXO file
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteTags ()
{
    /*
     * Before writing the tags, iterate through the sorted list, assigning indices starting at 1.
     * [Index 0 is reserved for "default" and is the error case.]
     */
    LxULong     index = 0;
    for (LXtMap_StringIds::iterator iter = m_tags.begin(), end = m_tags.end(); iter != end; ++iter)
        iter->second = ++index;

    ReturnOnError (WriteString (LXsICVAL_LOCATOR_STATE_DEFAULT));  // use "default" as first tag

    for (LXtMap_StringIds::iterator iter = m_tags.begin(), end = m_tags.end(); iter != end; ++iter)
        ReturnOnError (WriteString (iter->first.c_str()));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out a video still, if not already written
 *
 *----------------------------------------------------------------------------*/
        LxULong
LxoWriteData::WriteVideoStill (char const* filename)
{
    LXtMap_StringIds::iterator  iter = m_imageFiles.find (filename);

    if (iter != m_imageFiles.end())
        return iter->second;            // return the id of the video still already written

    if (LXe_OK != LxoVideostillItemChunk (this).Write (filename))
        return 0;

    // record this filename & videoStillId in the map, and return the id
    m_imageFiles.insert (std::pair <std::string, int>(filename, m_itemId));
    return m_itemId;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write the chunks making up a static mesh
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteMaterialPreset (LXtMaterial& material)
{
    bool        multipleUvMaps = false;
    LxULong     uvMapCount = material.m_uvMapCount <= 1 ? 1 : material.m_uvMapCount;

    if (uvMapCount > 1 && false == (multipleUvMaps = LxpTest (material.m_presetFile).AreUvMapsNeeded ()))
        uvMapCount = 1;

    for (LxULong uvMapIndex = 1; uvMapIndex <= uvMapCount; ++uvMapIndex)
        {
        /*
         * The mask item is the parent for the whole material.  Id will be the next item written.
         */
        LxULong     maskItemId = m_itemId + 1;

        LxpImport   lxpImport (this, material.m_name, material.m_presetFile, multipleUvMaps, uvMapIndex);
        LxResult    result = lxpImport.ReadFile ();
        if (LXe_OK != result)
            return result;

        // need a shader for every material
        if (! lxpImport.m_materialShaderFound)
            ReturnOnError (LxoShaderItemChunk (this).Write ("LxpShader", maskItemId, lxpImport.m_rootMaskItemIndex + 1));
        }

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write the chunks making up a static mesh
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteMaterial (LXtMaterial& material)
{
    if ('\0' != material.m_presetFile[0])
        return WriteMaterialPreset (material);

    /*
     * The mask item is the parent for the whole material.
     */
    ReturnOnError (LxoMaskItemChunk (this).Write (material.m_name, m_renderItemId, m_renderItemIndex++));

    LxULong     maskIndex  = 0;
    LxULong     maskItemId = m_itemId;

    ReturnOnError (LxoMaterialItemChunk (this).Write (material, maskItemId, maskIndex++));

    if (material.m_fur.enable)
        ReturnOnError (LxoFurMaterialItemChunk (this).Write (material.m_fur, material.m_name, maskItemId, maskIndex++));

    /*
     * Process each map layer for the material.  First process all layers that do NOT have multiple UV maps
     */
    bool    multipleUvMaps = false;

    for (LXtLayerVec::iterator it = material.m_layers.begin(); it != material.m_layers.end(); it++)
        {
        if (it->m_file[0])
            {
            if (0 == it->m_videoStillId && 0 == (it->m_videoStillId = WriteVideoStill (it->m_file)))
                return LXe_IO_ERROR;

            /*
             * If the projection mode for this layer is using UV maps, we need a texture locator/image map pair
             * for the uv map associated with each element using this material.  Otherwise, we just need one.
             */
            if (LXProjection_Uv == it->m_projectMode && material.m_uvMapCount > 1)
                multipleUvMaps = true;
            else
                {
                ReturnOnError (LxoTextureLocatorItemChunk (this).Write (it->m_tileModeU, it->m_tileModeV, it->m_projectMode,
                                                                        GetUvMapName (material.m_name, 1)));
                ReturnOnError (LxoImageMapItemChunk       (this).Write (*it, maskItemId, maskIndex++, m_itemId));
                }
            }
        else
            ReturnOnError (LxoConstantColorItemChunk (this).Write (maskItemId, maskIndex++, it->m_color, it->m_type)); 
        }

    /*
     * Next, re-process all layers that DO have multiple UV maps, grouping them in a mask
     */
    if (multipleUvMaps)
        for (LxULong i = 1; i <= material.m_uvMapCount; i++)
            {
            char const*     uvMapName = GetUvMapName (material.m_name, i);

            // make a mask to group these layers for the each uv map
            ReturnOnError (LxoMaskItemChunk (this).Write (uvMapName, maskItemId, maskIndex++, "Part"));

            LxULong     subMaskIndex  = 0;
            LxULong     subMaskItemId = m_itemId;

            // write each image map / texture locator pair for all layers as a child of this mask
            for (LXtLayerVec::iterator it = material.m_layers.begin(); it != material.m_layers.end(); it++)
                {
                if (0 == it->m_videoStillId || LXProjection_Uv != it->m_projectMode)
                    continue;

                ReturnOnError (LxoTextureLocatorItemChunk (this).Write (it->m_tileModeU, it->m_tileModeV, it->m_projectMode, uvMapName));
                ReturnOnError (LxoImageMapItemChunk       (this).Write (*it, subMaskItemId, subMaskIndex++, m_itemId));
                }
            }

    // need a shader for every material
    ReturnOnError (LxoShaderItemChunk (this).Write ("MatShader", maskItemId, maskIndex++, &material.m_shadeFlags));

    return LXe_OK;

#if 0
        double      minValue, maxValue;
        getMinMaxMapValue (minValue, maxValue, properties, mapType);

        if (0 == videoStillId)
            videoStillId  = WriteItemChunk (LxoVideoStillItemChunk (supportedImage, m_statistics.m_tempFiles, createAlphaFromBackground, m_tmpTextureDirectory, m_textureRemapList));

        // where we are using layered decals we need to use the alpha mask
        if (NULL != layer && (layer->flags.bgTrans || (mdlMaterialLayer_getCount ((BSIMaterialMap *)const_cast <MaterialMap *>(map)) > 3 && (TRUE == layer->u.data.flags.decalU || TRUE == layer->u.data.flags.decalV))))
            imageAlpha = ALPHA_Use;

        if (LAYER_Stencil == layerTypeToUse)
            {
            invert = TRUE;
            imageAlpha = ALPHA_Only;
            // to combine stencils use multiply for all the layers except the first
            blendType = NULL == layer || NULL == layer->prevP ? BLEND_Normal : BLEND_Multiply;
            }

        imageMapId = WriteItemChunk (LxoImageMapItemChunk (maskId, maskLinkIndex++,  videoStillId, textureLocatorId, alphaMapLinkIndex, layerTypeToUse, invert, opacity, layerType, blendType, imageAlpha, minValue, maxValue, imageInvert));
#endif
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Materials Chunk - write out materials used in this LXO file
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteMaterials ()
{
    for (LXtMap_Materials::iterator iter = m_materials.begin(), end = m_materials.end(); iter != end; ++iter)
        ReturnOnError (WriteMaterial (iter->second));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out a the environment
 *
 *----------------------------------------------------------------------------*/
        LxULong
LxoWriteData::WriteEnvironment (LXtRenderSettings& settings)
{
    LXtFVector      black = { 0.f, 0.f, 0.f};

    ReturnOnError (LxoEnvironmentItemChunk   (this).Write (settings));

    LxULong         envItemId    = m_itemId;       // Id of the top-level environment item just written
    LxULong         envItemIndex = 0;
    bool            envValid     = true;

    switch (settings.m_environment.m_flags.mode)
        {
        case LXEvironment_Sky:
            if (0 != m_itemIdSunlight)
                {
                if (m_skyCloudiness > 0.f)
                    ReturnOnError (LxoSkyEnvironmentItemChunk (this).Write (envItemId, envItemIndex++, m_itemIdSunlight, m_solarDiskSize,
                                                                            "Overcast Environment",  LXSkyCover_Overcast, m_skyCloudiness));
                if (m_skyCloudiness < 1.f)
                    ReturnOnError (LxoSkyEnvironmentItemChunk (this).Write (envItemId, envItemIndex++, m_itemIdSunlight, m_solarDiskSize,
                                                                            "Clear Sky Environment", LXSkyCover_Clear, 1.f - m_skyCloudiness));
                }
            else
                envValid = false;
            break;

        case LXEvironment_Image: {
            LXtMaterialLayer*   layer = settings.m_environment.m_imageLayer;

            if (0 == (layer->m_videoStillId = WriteVideoStill (layer->m_file)))
                return LXe_IO_ERROR;

            ReturnOnError (LxoTextureLocatorItemChunk (this).Write (layer->m_tileModeU, layer->m_tileModeV, layer->m_projectMode, NULL));
            ReturnOnError (LxoImageMapItemChunk       (this).Write (*layer, envItemId, envItemIndex++, m_itemId));
            break;
            }

        case LXEvironment_Solid:
            ReturnOnError (LxoConstantColorItemChunk (this).Write (envItemId, envItemIndex++, settings.m_environment.m_color, LXMaterialLayer_EnvColor));
            break;

        case LXEvironment_Gradient2:
            ReturnOnError (LxoGradientEnvironmentItemChunk (this).Write (envItemId, envItemIndex++, settings.m_environment.m_zenithColor, settings.m_environment.m_nadirColor));
            break;

        case LXEvironment_Gradient4:
            ReturnOnError (LxoGradientEnvironmentItemChunk (this).Write (envItemId, envItemIndex++, settings.m_environment.m_zenithColor, settings.m_environment.m_nadirColor,
                                                                                                    settings.m_environment.m_skyColor,    settings.m_environment.m_groundColor,
                                                                                                    settings.m_environment.m_skyExponent, settings.m_environment.m_groundExponent));
            break;

        default:
            envValid = false;
        }

    // if there is no valid environment, set a constant color
    if (! envValid)
        ReturnOnError (LxoConstantColorItemChunk (this).Write (envItemId, envItemIndex++, black, LXMaterialLayer_EnvColor));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write the header for an item chunk
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriteData::WriteItemHeader (char const* chunkType, char const* chunkName, LxULong itemId)
{
    if (0 == itemId)
        itemId = ++m_itemId;    // if no ID passed in, use next one

    if (NULL == m_outFile
            || LXe_OK != WriteString (chunkType)
            || LXe_OK != WriteString (chunkName)
            || LXe_OK != WriteLong   (itemId))
        return LXe_IO_ERROR;

    return LXe_OK;
}

