/*
 * Plug-in Lua script interpreter.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include <lxaction.h>
#include <lxcommand.h>
#include <lxstddialog.h>
#include <lx_scripts.hpp>
#include <lx_log.hpp>
#include <lx_command.hpp>

using namespace lx;

#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif
#include "../liblua/lua.h"
#include "../liblua/lauxlib.h"
#include "../liblua/lualib.h"
#include "lxlua.h"
#ifdef __cplusplus
}
#endif

extern CLxUser_LogService		*logSrv;
extern CLxUser_CommandService		*cmdSrv;
extern CLxUser_ValueService		*valueSrv;

extern "C" ILxScriptSysServiceID	 scriptSrv;
extern "C" ILxStdDialogServiceID	 dlgSrv;
extern "C" IntrInstance			 intrStack[ MAX_STACK ];
extern "C" int				 intrTop;
extern "C" IntrInstance			*intrCur;

void LogString ( const char *s, LxResult code, int persist );

class CLuaInterpreter : public CLxImpl_TextScriptInterpreter
{
        CLxUser_LogService	logSvc;
        CLxUser_CommandService	cmdSvc;
        CLxUser_ValueService	valueSvc;

    public:
        virtual			~CLuaInterpreter () {}

        virtual LxResult	 tsi_ValidateFileType (
                                        ILxUnknownID	 scriptObj,
                                        const char	*firstLine) LXx_OVERRIDE;
        virtual LxResult	 tsi_Run (
                                        ILxUnknownID	 scriptObj,
                                        int		 execFlags,
                                        const char	*args,
                                        ILxUnknownID	 messObj) LXx_OVERRIDE;
        
        void			 Init ();
        void			 Kill ();

        static LXtTagInfoDesc	 descInfo[];

    private:
        lua_State		*L;
};

/*********************/


        LxResult
CLuaInterpreter::tsi_ValidateFileType (
        ILxUnknownID		  scriptObj,
        const char		 *firstLine)
{
        if (!strstr (firstLine, "lua"))
                return LXe_SCRIPT_UNKNOWN;
        
        return LXe_OK;

}	


/*********************/

        void
CLuaInterpreter::Init()
{
        logSrv = &logSvc;
        cmdSrv = &cmdSvc;
        valueSrv = &valueSvc;

        L = lua_open();
        
        /* Add the new functions to lua */
        lua_pushcfunction(L, l_lxout);
        lua_setglobal(L, "lxout");
        
        lua_pushcfunction(L, l_lx);
        lua_setglobal(L, "lx");
        
        lua_pushcfunction(L, l_lxq);
        lua_setglobal(L, "lxq");

        lua_pushcfunction(L, l_lxqt);
        lua_setglobal(L, "lxqt");

        lua_pushcfunction(L, l_lxeval);
        lua_setglobal(L, "lxeval");

        lua_pushcfunction(L, l_lxok);
        lua_setglobal(L, "lxok");

        lua_pushcfunction(L, l_lxres);
        lua_setglobal(L, "lxres");

        lua_pushcfunction(L, l_lxtrace);
        lua_setglobal(L, "lxtrace");

        lua_pushcfunction(L, l_lxoption);
        lua_setglobal(L, "lxoption");

        lua_pushcfunction(L, l_lxsetOption);
        lua_setglobal(L, "lxsetOption");

        lua_pushcfunction(L, l_lxmonInit);
        lua_setglobal(L, "lxmonInit");
        
        lua_pushcfunction(L, l_lxmonStep);
        lua_setglobal(L, "lxmonStep");

        /* Other lua init */	

        /*
         * Updated for Lua 5.1, per the Lua API Programming FAQ:
         *
         * http://lua-users.org/wiki/LuaFaq
         *
         * See "Why do I get a 'no calling environment' error?"
         */
        luaL_openlibs(L);

        /* Init our level of the stack */
        intrTop++;
        assert( intrTop < MAX_STACK );

        intrCur = &intrStack[ intrTop ];
        intrCur->script               = NULL;
        intrCur->monitor              = NULL;
        intrCur->askedForMonitor      = 0;
        intrCur->rc                   = LXe_OK;
        intrCur->tracing              = 0;
        intrCur->execFlags            = LXfCMD_EXEC_DEFAULT;
        intrCur->queryAnglesAsDegrees = 1;
}

        
        LxResult
CLuaInterpreter::tsi_Run (
        ILxUnknownID		 scriptObj,
        int			 execFlags,
        const char		*args,
        ILxUnknownID		 messObj )
{
        // Hybrid access: Let the localization handle the reference-counting, but
        // extract the interface for old-style direct usage.
        //
        CLxLoc_Script		 u_script (scriptObj);
        CLxLoc_Message		 u_mess   (messObj);
        ILxScriptID		 script = u_script.m_loc;
        ILxMessageID		 mess   = u_mess.m_loc;

        const char		*name, *hash;
        unsigned int		 size = 0;
        const char		*st;
        char			*localBuf, nameBuf[ 512 ];
        LxResult		 rc = LXe_OK;
        int			 error;
        int			 errMsg = -1;
        int			 numArgs = 0;

        Init();
        script[0]->GetBuffer( script, &st, &size );
        size -= 1;	// Remove the \0 from the buffer length

        /* Variable initialization */
        scriptSrv          = (ILxScriptSysServiceID)lx::GetGlobal(LXu_SCRIPTSYSSERVICE);
        dlgSrv             = (ILxStdDialogServiceID)lx::GetGlobal (LXu_STDDIALOGSERVICE);
        intrCur->script    = script;
        intrCur->execFlags = execFlags;

        /* Load up the default libraries */

        /*
         * Updated for Lua 5.1, per the Lua API Programming FAQ:
         *
         * http://lua-users.org/wiki/LuaFaq
         *
         * See "Why do I get a 'no calling environment' error?"
         */
        luaL_openlibs(L);

        /* Log Setup */
        if( LXx_FAIL( script[0]->UserName( script, &name ) ) )
                script[0]->Hash( script, &name );

        sprintf( nameBuf, "%s   (lua script)", name );
        logSvc.NewEntry( LXe_INFO, nameBuf, intrCur->log );

        if( intrTop == 0 ) {
                /* Add the entry to the subsystem */
                CLxLoc_Log	 logSubSys;
                logSvc.GetSubSystem( LXsLOG_SCRIPTSYS, logSubSys );

                logSubSys.AddEntry( ILxUnknownID(intrCur->log) );

        } else {
                /* Add the entry to the parent script's entry */
                intrStack[ intrTop - 1 ].log.AddEntry (intrCur->log);
        }

        /* Load the script into the interpreter */
        error = luaL_loadbuffer(L, st, strlen(st), "lua script");
        if( error ) {
                errMsg = 1;
        } else {
                /* Create the argument table */
                lua_newtable(L);		// arg table

                /* Push the script name onto the table at index 0 */
                script[0]->Hash( script, &hash );

                lua_pushnumber(L, 0);
                lua_pushstring(L, hash);
                lua_settable(L, -3);

                /* Parse the arguments and add them to the table */
                if (args) {
                        int alen = static_cast<int>(strlen (args)) + 1;
                        localBuf = new char [alen];
                        strcpy (localBuf, args);

                        char	*arg = localBuf;
                        char	*endQuote;

                        int	 index = 0;

                        while( (arg != NULL) && (arg[0] != '\0') ) {
                                /* Skip white space */
                                for( /*NULL*/; isspace( arg[0] ) && (arg[0] != '\0'); arg++ ) { ; }

                                if( arg[0] == '\0' )
                                        break;

                                /* Check for quoted arguments */
                                if( arg[0] == '\"' ) {
                                        arg++;
                                        endQuote = strchr( arg, '\"' );
                                        if( endQuote == NULL ) {
                                                /* Unbalanced quotes; fail */
                                                rc = LXe_FAILED;

                                                mess[0]->SetCode           (mess, rc);
                                                mess[0]->SetMessage        (mess, "lualintr", NULL, 3);
                                                mess[0]->SetArgumentString (mess, 1, args);

                                                error  = 1;
                                                errMsg = 2;
                                                break;
                                        }

                                        endQuote[0] = '\0';

                                        lua_pushnumber(L, ++index);
                                        lua_pushstring(L, arg);
                                        lua_settable(L, -3);

                                        numArgs++;

                                        arg = endQuote + 1;

                                } else {
                                        /* Normal space delimiting */
                                        endQuote = strchr( arg, ' ' );
                                        if( endQuote )
                                                endQuote[0] = '\0';

                                        lua_pushnumber(L, ++index);
                                        lua_pushstring(L, arg);
                                        lua_settable(L, -3);
                                        numArgs++;

                                        if( endQuote == NULL )
                                                arg = NULL;
                                        else
                                                arg = endQuote + 1;
                                }
                        }
                }

                /* Make the table into the global "arg" variable */
                lua_setglobal(L, "arg");

                if( !error ) {
                        /* Execute */
                        error = lua_pcall(L, 0, 0, 0);
                        if( error )
                                errMsg = 2;
                }
        }

        if( (errMsg == 1) || (errMsg == 2) ) {
                /* Error Handling */
                const char	*c = lua_tostring(L, -1);

                LogString( c, LXe_FAILED, 0 );
                lua_pop(L, 1);

                rc = LXe_FAILED;

                // TODO:  Figure out how to handle aborts differently from failures

                mess[0]->SetCode(           mess, rc );
                mess[0]->SetMessage(        mess, "luaintr", NULL, errMsg );
                mess[0]->SetArgumentString( mess, 1, c );
        }

        /* Clean Up */
        if (args)
                delete[] localBuf;

        Kill();

        return rc;
}  

/*********************/

        void
CLuaInterpreter::Kill()
{
        lua_close(L);

        /* Clean up our level of the stack */
        intrCur->script    = NULL;
        intrCur->rc        = LXe_OK;
        intrCur->tracing   = 0;
        intrCur->execFlags = LXfCMD_EXEC_DEFAULT;

        if( intrCur->askedForMonitor ) {
                dlgSrv[0]->MonitorRelease( dlgSrv );

                intrCur->askedForMonitor = 0;
                intrCur->monitor         = NULL;
        }

        assert( intrTop >= -1 );

        /* Set the current pointer to the previous level */
        intrTop--;
        intrCur = (intrTop == -1) ? NULL : &intrStack[ intrTop ];

}

LXtTagInfoDesc	 CLuaInterpreter::descInfo[] = {
        { LXsSRV_USERNAME,	"Lua Scripts"	},
        { LXsLOD_DOSPATTERN,	"*.lua"		},
        { 0 }
};


/*
 * ----------------------------------------------------------------
 * Exporting Servers
 */
        void
initialize ()
{
        LXx_ADD_SERVER (TextScriptInterpreter, CLuaInterpreter, "lua");
}

