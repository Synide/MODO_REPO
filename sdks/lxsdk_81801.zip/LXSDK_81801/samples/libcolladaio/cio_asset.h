/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_ASSSET_H
#define CIO_ASSSET_H

#include "cio_element.h"
#include "cio_strings.h"

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Contributor.
 */

class AssetElement;

class ContributorElement : public Element
{
    public:
                                 ContributorElement (AssetElement &asset);
        virtual			~ContributorElement ();

        const std::string	 GetAuthor () const;
        void			 SetAuthor (const std::string &name);

        const std::string	 GetAuthoringTool () const;
        void			 SetAuthoringTool (const std::string &toolName);

        const std::string	 GetComments () const;
        void			 SetComments (const std::string &commentary);

        const StringArray	 GetCommentsList () const;
        void			 SetComments (const StringArray &commentary);

        const std::string	 GetCopyright () const;
        void			 SetCopyright (const std::string &copyrightHolder);

        const std::string	 GetSourceData () const;
        void			 SetSourceData (const std::string &file);

    private:
        struct pv_ContributorElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Asset.
 */

class VisualSceneElement;
        
class COLLADAElement;

class AssetElement : public Element
{
        friend class ContributorElement;

    public:
                                 AssetElement (COLLADAElement &collada);
                                 AssetElement (VisualSceneElement &visualScene);
        virtual			~AssetElement ();

        const std::string	 GetKeywords () const;
        void			 SetKeywords (const std::string &keywordList);

        const StringArray	 GetKeywordsList () const;
        void			 SetKeywords (const StringArray &keywordArray);

        const std::string	 GetRevision () const;
        void			 SetRevision (const std::string &theRevision);

        const std::string	 GetSubject () const;
        void			 SetSubject (const std::string &subjectText);

        const std::string	 GetTitle () const;
        void			 SetTitle (const std::string &theTitle);

        const DateTime		 GetCreationDateTime () const;
        void			 SetCreationDateTime (const DateTime &dateTime);

        const DateTime		 GetModifiedDateTime () const;
        void			 SetModifiedDateTime (const DateTime &dateTime);

        /*
         * Coordinate system.
         */
        const std::string	 GetUnitName () const;
        double			 GetUnitsPerMeter () const;
        void			 SetUnit (
                                        const std::string	&name,
                                        double			 unitsPerMeter = 1.0);

        typedef enum en_UpAxis
        {
                UP_AXIS_X,
                UP_AXIS_Y,
                UP_AXIS_Z
        } UpAxis;

        UpAxis			 GetUpAxis () const;
        void			 SetUpAxis (UpAxis axis);

        bool			 HasContributor () const;

    protected:
        bool			 LinkContributor (
                                        ContributorElement &contributor);
        void			 AddContributor (
                                        ContributorElement &contributor);

    private:
        struct pv_AssetElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Variable element and attribute values.
 */

/*
 * SI and Metric units of measurement.
 */
extern const char* UNITNAME_MICRON;
extern const char* UNITNAME_MILLIMETER;
extern const char* UNITNAME_CENTIMETER;
extern const char* UNITNAME_METER;
extern const char* UNITNAME_KILOMETER;
extern const char* UNITNAME_MEGAMETER;

/*
 * English units of measurement.
 */
extern const char* UNITNAME_MILS;
extern const char* UNITNAME_INCH;
extern const char* UNITNAME_FOOT;
extern const char* UNITNAME_MILE;

/*
 * "Game" unit of measurement.
 */
extern const char* UNITNAME_GAME;

/*
 * Meter conversions.
 */
const double METERS_PER_MICRON			= 0.000001;
const double METERS_PER_MILLIMETER		= 0.001;
const double METERS_PER_CENTIMETER		= 0.01;
const double METERS_PER_KILOMETER		= 1000.0;
const double METERS_PER_MEGAMETER		= 1000000.0;

const double METERS_PER_MIL			= 0.0000254;
const double METERS_PER_INCH			= 0.0254;
const double METERS_PER_FOOT			= 0.3048;
const double METERS_PER_MILE			= 1609.344;

} // namespace cio

#endif // CIO_ASSSET_H

