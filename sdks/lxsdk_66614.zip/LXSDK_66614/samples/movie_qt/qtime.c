/*
 * Plug-in QuickTime saver for movies.
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "qtime.h"

#ifdef _MACOS

#define crash MacOS_crash
#include <Carbon/Carbon.h>
#include <QuickTime/QuickTime.h>
#undef crash

#define STARTQTML 0
#define ENDQTML

#else

#include <windows.h>
#include "QTML.h"
#include "Movies.h"
#include <stdio.h>

#define STARTQTML InitializeQTML(0L)
#define ENDQTML	  TerminateQTML()

#define GetPortPixMap(p) (((CGrafPtr)p)->portPixMap)

#endif

typedef struct st_QTMovie {
        Movie			 movie;
        Media			 media;
        Track			 track;
        DataHandler		 dataHandler;
        Handle			 dataRef;
        OSType			 dataRefType;
        
        int			 bufSize, rowSize;
        int			 ih, iw;
        Handle			 compressedData;
        ImageDescriptionHandle	 imageDesc;
        GWorldPtr		 gWorld;
        unsigned char		*imageBuf;
        CGrafPtr		 oldPort;
        GDHandle		 oldGDeviceH;
        PixMapHandle		 pixMapH;
        Ptr			 compressedDataPtr;
} QTMovie;

static int			 gSampleDuration = 40;	// kMovieTimeScale / fps = 600 / 15 = 40

#define	kMovieTimeScale		 600
#define	kTrackStart		 0
#define	kMediaStart		 0
#define	kQTFLAGS		 (createMovieFileDeleteCurFile | createMovieFileDontCreateResFile)

        LxResult
QTInitialize ()
{
        OSErr		err;

        err = STARTQTML;

        return (err == noErr) ? LXe_OK : LXe_NOTAVAILABLE;
}

        void
QTTerminate ()
{
        ENDQTML;
}

/*
 * Movies are created with the following function.  It creates the movie file
 * and opens it for writing.  It take the full path to the new movie file and
 * a flags field as its arguements.  X and Y specify the size of the movie.
 * For now, all movies will be 30fps.
 */
        QTMovieID
QTMovieCreate (
        const char		*fname,
        int			 w,
        int			 h,
        int			 flags)
{
        QTMovieID		 qtMovie = NULL;
        Movie			 movie;
        Media			 media;
        Track			 track;
        OSErr			 theErr;
        CFStringRef		 cfString;
        Handle			 dataRef;
        OSType			 dataRefType;
        DataHandler		 dataHandler = NULL;
        Rect			 frameSize;
        long			 maxCompressedSize;

        theErr = STARTQTML;
        if (theErr == noErr) {
                EnterMovies ();
        
                cfString = CFStringCreateWithCString (
                        kCFAllocatorDefault, fname, CFStringGetSystemEncoding ());

                theErr = QTNewDataReferenceFromFullPathCFString (
                        cfString, kQTNativeDefaultPathStyle,
                        0, &dataRef, &dataRefType);
                                        
                CFRelease (cfString);
                                        
                if (theErr != noErr)
                        return NULL;	
                
                theErr = CreateMovieStorage (
                        dataRef, dataRefType, FOUR_CHAR_CODE('TVOD'), smCurrentScript,
                        kQTFLAGS, &dataHandler, &movie);
                                        
                if (theErr != noErr) {
                        DisposeHandle (dataRef);
                        return NULL;
                }
        
                track = NewMovieTrack (movie, FixRatio(w,1), FixRatio(h,1), kNoVolume);
        
                media = NewTrackMedia (track, VideoMediaType, kMovieTimeScale, dataRef, dataRefType);
        
                theErr = BeginMediaEdits (media);
        
                /* 
                 * We're now open & ready to add samples
                 */	
                qtMovie = malloc (sizeof (QTMovie));
                        
                qtMovie->movie	     = movie;
                qtMovie->media	     = media;
                qtMovie->track	     = track;
                qtMovie->dataHandler = dataHandler;
                qtMovie->dataRef     = dataRef;
                qtMovie->dataRefType = dataRefType;
        
                /*
                 * Now we set up our image buffer and data for later
                 */
                qtMovie->iw = w;
                qtMovie->ih = h;
                qtMovie->rowSize = (qtMovie->iw * 3 + 3) & ~3;
        
                qtMovie->imageBuf = malloc (qtMovie->rowSize * qtMovie->ih);
        
                frameSize.top = 0;
                frameSize.bottom = h;
                frameSize.left = 0;
                frameSize.right = w;
                theErr = NewGWorld (&qtMovie->gWorld, 24, &frameSize, NULL, NULL, (GWorldFlags)0);
        
                GetGWorld (&qtMovie->oldPort, &qtMovie->oldGDeviceH);
                SetGWorld (qtMovie->gWorld, NULL);
        
                qtMovie->pixMapH = GetPortPixMap (qtMovie->gWorld);
                LockPixels (qtMovie->pixMapH);
        
                theErr = GetMaxCompressionSize (
                        qtMovie->pixMapH, &frameSize, 24, codecMaxQuality,
                        kMPEG4VisualCodecType, (CompressorComponent) bestFidelityCodec, 
                        &maxCompressedSize);

                qtMovie->compressedData = NewHandle(maxCompressedSize);
                MoveHHi (qtMovie->compressedData);
                HLock (qtMovie->compressedData);
                qtMovie->compressedDataPtr = *(qtMovie->compressedData);
                qtMovie->imageDesc = (ImageDescriptionHandle) NewHandleClear ( sizeof(ImageDescription) );
        }

        return qtMovie;
}

        void
QTMovieSetFramerate (
        QTMovieID		 qtMovie,
        int			 frate)
{
        gSampleDuration = (int) (600 / frate);
}


/*
 * This is here for completeness - it's just a no-op.
 */
        void
QTMovieBeginFrame (
        QTMovieID		 qtMovie)
{

        return;
}

/*
 * Adding a line simply copies it to our image buffer.  The real work comes when 
 * we end the frame
 */
        void
QTMovieAddLineToFrame (
        QTMovieID		 qtMovie,
        unsigned char		*rowBytes,
        int			 row)
{
        int			 x, rb;
        unsigned char		*p, *b;

        b   = (unsigned char *) GetPixBaseAddr (qtMovie->pixMapH);
        rb  = QTGetPixMapPtrRowBytes (*qtMovie->pixMapH);

        p = b + row * rb;
//	p = (qtMovie->imageBuf + (row * qtMovie->rowSize));
        for (x = 0; x < qtMovie->iw; x++) {
                #ifdef _MACOS		// Quickdraw ignores the high byte, but only on the Mac
         	  p++;			//  This should really use some function to get the pixel depth
                #endif			//  rather than being hard-coded like this
                *p++ = rowBytes[0];
                *p++ = rowBytes[1]; 
                *p++ = rowBytes[2];
                 rowBytes += 3;
        }
}

        int
QTMovieEndFrame (
        QTMovieID		 qtMovie)
{
        OSErr			 theErr;
        Rect			 frameSize;
        
        frameSize.top    = 0;
        frameSize.bottom = qtMovie->ih;
        frameSize.left   = 0;
        frameSize.right  = qtMovie->iw;
        
        theErr = CompressImage (
                qtMovie->pixMapH,
                &frameSize, codecMaxQuality,
                kMPEG4VisualCodecType,
                qtMovie->imageDesc,
                qtMovie->compressedDataPtr);
                                
        theErr = AddMediaSample2 (
                qtMovie->media,
                qtMovie->compressedDataPtr,
                (**(qtMovie->imageDesc)).dataSize, 
                gSampleDuration, 0,
                (SampleDescriptionHandle)qtMovie->imageDesc,
                1, 0, NULL);
        
        return 1;
}


/* 
 * After all images have been added to the movie,
 * close it and flatten the movie.
 */
        void
QTMovieClose (
        QTMovieID		 qtMovie)
{
        OSErr			 theErr;
        
        UnlockPixels (qtMovie->pixMapH);

        theErr = EndMediaEdits (qtMovie->media);
                
        theErr = InsertMediaIntoTrack (
                qtMovie->track,
                kTrackStart, kMediaStart,
                GetMediaDuration(qtMovie->media), fixed1);

        theErr = AddMovieToStorage (qtMovie->movie, qtMovie->dataHandler);
        
        theErr = CloseMovieStorage (qtMovie->dataHandler);

        DisposeMovie (qtMovie->movie);
        DisposeHandle (qtMovie->dataRef);
        
        ExitMovies ();
        ENDQTML;
        
        SetGWorld (qtMovie->oldPort, qtMovie->oldGDeviceH);
        DisposeHandle ((Handle)qtMovie->imageDesc);
        DisposeHandle (qtMovie->compressedData);
        DisposeGWorld (qtMovie->gWorld);

        free (qtMovie->imageBuf);
        free (qtMovie);
        return;
}


/* 
 * Add audio track as option. This must be called before MovieClose.
 */

        #define kSoundSampleDuration 1

        void
QTMovieAddAudio (
        QTMovieID		 qtMovie,
        ILxAudioID		 audio)
{
        Track			 track;
        Media			 media;
        SoundDescriptionHandle	 hSoundDesc;
        LXtAudioMetrics		 m;
        const UInt8		*dataPtr;
        unsigned int		 dataSize, numberOfSamples;

        // Allocate sound description and set the description.
        hSoundDesc = (SoundDescriptionV2Handle) NewHandleClear (sizeof(SoundDescription));
        HLock (hSoundDesc);

        (audio[0]->Metrics) (audio, &m);

        hSoundDesc[0]->descSize    = sizeof (SoundDescription);
        hSoundDesc[0]->numChannels = m.channels;
        hSoundDesc[0]->sampleSize  = m.type;
        hSoundDesc[0]->sampleRate  = m.frequency << 16;		// 16 bits fixed float.
        switch (m.type) {
            case LXiAUDIO_TYPE_U8:
                hSoundDesc[0]->dataFormat = k8BitOffsetBinaryFormat;
                break;
            case LXiAUDIO_TYPE_I16:
                hSoundDesc[0]->dataFormat = k16BitLittleEndianFormat;
                break;
            case LXiAUDIO_TYPE_F32:
                hSoundDesc[0]->dataFormat = kFloat32Format;
                break;
        }

        dataPtr  = (const UInt8 *) (audio[0]->Data) (audio);	// The pointer of audio data.
        dataSize = (audio[0]->Size) (audio);		// The size of audio data.

        // The number of sample data.
        numberOfSamples = dataSize / (m.channels * m.type / 8);

        // Create new track and media.
        track = NewMovieTrack (qtMovie->movie, 0, 0, kFullVolume);
        media = NewTrackMedia (track, SoundMediaType, FixRound(hSoundDesc[0]->sampleRate), NULL, 0);

        // Add the audio data to the new media.
        BeginMediaEdits (media);

        AddMediaSample2 (media, dataPtr, dataSize, kSoundSampleDuration, 0, 
                (SampleDescriptionHandle) hSoundDesc, numberOfSamples, 0, NULL);

        EndMediaEdits (media);

        // Insert the new media into the new track.
        InsertMediaIntoTrack (track, kTrackStart, kMediaStart, GetMediaDuration (media), fixed1);

        if (hSoundDesc != NULL)
                DisposeHandle ((Handle) hSoundDesc);
}

