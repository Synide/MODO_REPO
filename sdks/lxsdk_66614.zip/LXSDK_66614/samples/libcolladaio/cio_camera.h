/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_CAMERA_H
#define CIO_CAMERA_H

#include "cio_element.h"

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Optics.
 */

static const float ZNEAR_DEFAULT	= 0.01f;
static const float ZFAR_DEFAULT		= 10000.0f;

class CameraElement;
class PerspectiveElement;
class OrthographicElement;
class OpticsElement_modo401;

class OpticsElement : public Element
{
        friend class PerspectiveElement;
        friend class OrthographicElement;
        friend class OpticsElement_modo401;

    public:
                                 OpticsElement (
                                        CameraElement	&camera,
                                        double		 zNear = ZNEAR_DEFAULT,
                                        double		 zFar = ZFAR_DEFAULT);
        virtual			~OpticsElement ();

        bool			 HasPerspective () const;
        bool			 LinkPerspective (
                                        PerspectiveElement &perspective);

        bool			 HasOrthographic () const;
        bool			 LinkOrthographic (
                                        OrthographicElement &orthographic);

        bool			 HasTechniqueProfile_modo401 () const;
        bool			 LinkTechniqueProfile_modo401 (
                                        OpticsElement_modo401 &modoOptics);

    protected:
        void			 AddPerspective (
                                        PerspectiveElement &perspective);
        void			 AddOrthographic (
                                        OrthographicElement &orthographic);
        void			 AddTechniqueProfile_modo401 (
                                        OpticsElement_modo401 &modoOptics);

    private:
        struct pv_OpticsElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Perspective.
 */
class PerspectiveElement : public Element
{
    public:
                                 PerspectiveElement (
                                        OpticsElement	&optics);
        virtual			~PerspectiveElement ();

        bool			 GetFOVs(
                                        double		&xFOVvalue,
                                        double		&yFOVvalue);
        void			 SetFOVs (
                                        double		 xFOVvalue,
                                        double		 yFOVvalue);

        bool			 GetXFOVandAspectRatio (
                                        double		&xFOVvalue,
                                        double		&aspectRatio);
        void			 SetXFOVandAspectRatio (
                                        double		 xFOVvalue,
                                        double		 aspectRatio);

        bool			 GetYFOVandAspectRatio (
                                        double		&yFOVvalue,
                                        double		&aspectRatio);
        void			 SetYFOVandAspectRatio (
                                        double		 yFOVvalue,
                                        double		 aspectRatio);

        bool			 GetZNearFar (
                                        double		&zNear,
                                        double		&zFar);
        void			 SetZNearFar (
                                        double		 zNear = ZNEAR_DEFAULT,
                                        double		 zFar = ZFAR_DEFAULT);

    private:
        struct pv_PerspectiveElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Orthographic.
 */
class OrthographicElement : public Element
{
    public:
                                 OrthographicElement (
                                        OpticsElement	&optics);
        virtual			~OrthographicElement ();

        bool			 GetMags (
                                        double		&xmag,
                                        double		&ymag);
        void			 SetMags (
                                        double		 xmag,
                                        double		 ymag);

        bool			 GetXMagAndAspectRatio (
                                        double		&xmag,
                                        double		&aspectRatio);
        void			 SetXMagAndAspectRatio (
                                        double		 xmag,
                                        double		 aspectRatio);

        bool			 GetYMagAndAspectRatio (
                                        double		 &ymag,
                                        double		 &aspectRatio);
        void			 SetYMagAndAspectRatio (
                                        double		 ymag,
                                        double		 aspectRatio);

        bool			 GetZNearFar (
                                        double		 &zNear,
                                        double		 &zFar);
        void			 SetZNearFar (
                                        double		 zNear = ZNEAR_DEFAULT,
                                        double		 zFar = ZFAR_DEFAULT);

    private:
        struct pv_OrthographicElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Optics Technique Profile modo 401.
 */
class OpticsElement_modo401 : public Element
{
    public:
                                 OpticsElement_modo401 (
                                         OpticsElement &optics);
        virtual			~OpticsElement_modo401 ();

        bool			 GetTargetEnable (bool &enabled);
        void			 SetTargetEnable (bool enabled);

        /*
         * URI fragment ID to linked node.
         */
        bool			 GetTargetNodeID (std::string &nodeID);
        void			 SetTargetNodeID (const std::string &nodeID);

        bool			 GetTargetSetFocus (bool &focused);
        void			 SetTargetSetFocus (bool focused);

        bool			 GetTargetDistance (double &distance);
        void			 SetTargetDistance (double distance);

        bool			 GetTargetRoll (double &degrees);
        void			 SetTargetRoll (double degrees);

        /*
         * See PARAMVALUE_MODO_PROJECTION_TYPE_
         */
        bool			 GetProjection (std::string &type);
        void			 SetProjection (const std::string &type);

        bool			 GetFocalLength (double &focalLength);
        void			 SetFocalLength (double focalLength);

        bool			 GetLensDistortion (double &lensDistortion);
        void			 SetLensDistortion (double lensDistortion);

        bool			 GetLensSqueeze (double &lensSqueeze);
        void			 SetLensSqueeze (double lensSqueeze);

        bool			 GetDepthOfField (bool &dof);
        void			 SetDepthOfField (bool dof);

        bool			 GetFocusDistance (double &distance);
        void			 SetFocusDistance (double distance);

        bool			 GetFStop (double &fStop);
        void			 SetFStop (double fStop);

        bool			 GetMotionBlur (bool &motionBlur);
        void			 SetMotionBlur (bool motionBlur);

        bool			 GetMotionBlurLength (double &length);
        void			 SetMotionBlurLength (double length);

        bool			 GetMotionBlurOffset (double &offset);
        void			 SetMotionBlurOffset (double offset);

        bool			 GetStereoscopic (bool &stereo);
        void			 SetStereoscopic (bool stereo);

        bool			 GetInterocularDistance (double &distance);
        void			 SetInterocularDistance (double distance);

        bool			 GetConvergenceDistance (double &distance);
        void			 SetConvergenceDistance (double distance);

    private:
        struct pv_OpticsElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Imager.
 */

class ImagerElement_modo401;

class ImagerElement : public Element
{
        friend class ImagerElement_modo401;

    public:
                                 ImagerElement (CameraElement &camera);
        virtual			~ImagerElement ();

        bool			 HasTechniqueProfile_modo401 () const;
        bool			 LinkTechniqueProfile_modo401 (
                                        ImagerElement_modo401 &modoImager);

    protected:
        void			 AddTechniqueProfile_modo401 (
                                        ImagerElement_modo401 &modoImager);

    private:
        struct pv_ImagerElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Imager Technique Profile modo 401.
 */
class ImagerElement_modo401 : public Element
{
    public:
                                 ImagerElement_modo401 (
                                         ImagerElement &imager);
        virtual			~ImagerElement_modo401 ();

        bool			 GetAperture (double &width, double &height);
        void			 SetAperture (double width, double height);

        bool			 GetOffset (double &x, double &y);
 	void			 SetOffset (double x, double y);

        bool			 GetFilmFit (std::string &fit);
        void			 SetFilmFit (const std::string &fit);

    private:
        struct pv_ImagerElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Camera.
 */

class CameraLibraryElement;

class CameraElement : public Element
{
        friend class OpticsElement;
        friend class ImagerElement;

    public:
                                 CameraElement (
                                         CameraLibraryElement	&library,
                                         const std::string	&id,
                                         const std::string	&name);
                                 CameraElement (
                                         CameraLibraryElement &library);
        virtual			~CameraElement ();

        bool			 HasOptics () const;
        bool			 LinkOptics (OpticsElement	&optics);

        bool			 HasImager () const;
        bool			 LinkImager (ImagerElement	&imager);

    protected:
        void			 AddOptics (OpticsElement &optics);
        void			 AddImager (ImagerElement &imager);
};

/*
 * ---------------------------------------------------------------------------
 * Camera Library.
 */
        
class COLLADAElement;
        
class CameraLibraryElement : public Element
{
        friend class CameraElement;

    public:
                                 CameraLibraryElement (COLLADAElement &collada);
        virtual			~CameraLibraryElement ();

        bool			 HasCamera () const;
        bool			 LinkCamera (
                                        const std::string	&cameraID,
                                        CameraElement		&camera);

    protected:
        void			 AddCamera (CameraElement &camera);
};

} // namespace cio

#endif // CIO_CAMERA_H

