/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_bind.h"
#include "cio_schema.h"
#include "cio_element.h"
#include "cio_strings.h"

#include <map>
#include <set>
#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Element Param.
 */

ElementParam::ElementParam ()
        :
        paramVarType(PARAM_TYPE_FLOAT)
{
}

ElementParam::ElementParam (
        const string		&parentName,
        const string		&elemName,
        const string		&paramSID,
        const string		&paramName,
        ParamType		&paramType)
        :
        parentElementName(parentName),
        elementName(elemName),
        paramUniqueSID(paramSID),
        paramFriendlyName(paramName),
        paramVarType(paramType)
{
}

ElementParam::~ElementParam ()
{
}

        string
ElementParam::GetParentElementName () const
{
        return parentElementName;
}

        string
ElementParam::GetElementName () const
{
        return elementName;
}

        string
ElementParam::GetParamSID () const
{
        return paramUniqueSID;
}

        string
ElementParam::GetParamName () const
{
        return paramFriendlyName;
}

        ParamType
ElementParam::GetParamType () const
{
        return paramVarType;
}

/*
 * Set the unique parent element name.
 */
        void
ElementParam::SetParentElementName (
        const std::string &name)
{
        parentElementName = name;
}

/*
 * Set the element name.
 */
        void
ElementParam::SetElementName (
        const std::string &name)
{
        elementName = name;
}

/*
 * Set the scoped ID for the parameter.
 */
void
ElementParam::SetParamSID (
        const std::string &sid)
{
        paramUniqueSID = sid;
}

/*
 * Set the human-readable name for the parameter.
 */
        void
ElementParam::SetParamName (
        const std::string &name)
{
        paramFriendlyName = name;
}

/*
 * Set the underlying data type used to store the parameter.
 */
        void
ElementParam::SetParamType (ParamType type)
{
        paramVarType = type;
}

/*
 * ---------------------------------------------------------------------------
 * Element Param map and set.
 */

/*
 * Both containers are primary-keyed by unique parent element type.
 */
typedef multimap<string, ElementParam> ElementParamMap;

typedef set<string> ParentElementNameSet;

/*
 * ---------------------------------------------------------------------------
 * Element Param Bind.
 */

/*
 * ID builders for various types of items.
 */

class ItemIDBuilder
{
    public:
                                 ItemIDBuilder () {}
        virtual			~ItemIDBuilder () {}

        virtual string		 GetItemID (const string &itemName) const = 0;
};

typedef ItemIDBuilder			*ItemIDBuilderRef;
typedef map<string, ItemIDBuilderRef>	 ItemIDBuilderMap;

class CameraIDBuilder : public ItemIDBuilder
{
    public:
                                 CameraIDBuilder () {}
        virtual			~CameraIDBuilder () {}

        string			 GetItemID (const string &itemName) const
        {
                return CameraID (ItemID (itemName));
        }
};

class EffectIDBuilder : public ItemIDBuilder
{
    public:
                                 EffectIDBuilder () {}
        virtual			~EffectIDBuilder () {}

        virtual string		 GetItemID (const string &itemName) const
        {
                return EffectID (ItemID (itemName));
        }
};

class GeometryIDBuilder : public ItemIDBuilder
{
    public:
                                 GeometryIDBuilder () {}
        virtual			~GeometryIDBuilder () {}

        virtual string		 GetItemID (const string &itemName) const
        {
                return GeometryID (ItemID (itemName));
        }
};

class ImageIDBuilder : public ItemIDBuilder
{
    public:
                                 ImageIDBuilder () {}
        virtual			~ImageIDBuilder () {}

        virtual string		 GetItemID (const string &itemName) const
        {
                return ImageID (ItemID (itemName));
        }
};

class LightIDBuilder : public ItemIDBuilder
{
    public:
                                 LightIDBuilder () {}
        virtual			~LightIDBuilder () {}

        virtual string		 GetItemID (const string &itemName) const
        {
                return LightID (ItemID (itemName));
        }
};

class MaterialIDBuilder : public ItemIDBuilder
{
    public:
                                 MaterialIDBuilder () {}
        virtual			~MaterialIDBuilder () {}

        virtual string		 GetItemID (const string &itemName) const
        {
                return MaterialID (ItemID (itemName));
        }
};

class NodeIDBuilder : public ItemIDBuilder
{
    public:
                                 NodeIDBuilder () {}
        virtual			~NodeIDBuilder () {}

        virtual string		 GetItemID (const string &itemName) const
        {
                return NodeID (ItemID (itemName));
        }
};

struct pv_ElementParamBind
{
                                 pv_ElementParamBind ();

        virtual			~pv_ElementParamBind ()
        {
        }

        /*
         * Return the item ID for an item of a given library element name.
         */
        string			 GetItemID (
                                        const string	&libraryElementName,
                                        const string	&itemName);

        /*
         * Add an ID builder for a library element name.
         */
        void			 AddItemIDBuilder (
                                        const string	&libraryElementName,
                                        ItemIDBuilder	*idBuilder);

        ElementParamMap		 elementParams;
        ParentElementNameSet	 parentElementNames;

        CameraIDBuilder		 cameraIDBuilder;
        EffectIDBuilder		 effectIDBuilder;
        GeometryIDBuilder	 geometryIDBuilder;
        ImageIDBuilder		 imageIDBuilder;
        LightIDBuilder		 lightIDBuilder;
        MaterialIDBuilder	 materialIDBuilder;
        NodeIDBuilder		 nodeIDBuilder;

        ItemIDBuilderMap	 itemIDBuilders;
};

pv_ElementParamBind::pv_ElementParamBind ()
{
        AddItemIDBuilder (ELEMENT_CAMERA, &cameraIDBuilder);
        AddItemIDBuilder (ELEMENT_EFFECT, &effectIDBuilder);
        AddItemIDBuilder (ELEMENT_GEOMETRY, &geometryIDBuilder);
        AddItemIDBuilder (ELEMENT_IMAGE, &imageIDBuilder);
        AddItemIDBuilder (ELEMENT_LIGHT, &lightIDBuilder);
        AddItemIDBuilder (ELEMENT_MATERIAL, &materialIDBuilder);
        AddItemIDBuilder (ELEMENT_NODE, &nodeIDBuilder);
}

/*
 * Return the item ID for an item of a given item type.
 */
        string
pv_ElementParamBind::GetItemID (
        const string		&libraryElementName,
        const string		&itemName)
{
        string itemID;

        ItemIDBuilderMap::const_iterator iter =
                itemIDBuilders.find (libraryElementName);

        if (iter != itemIDBuilders.end ()) {
                itemID = iter->second->GetItemID (itemName);
        }
        else {
                itemID = ItemID (itemName);
        }

        return itemID;
}

/*
 * Add an ID builder for an item type.
 */
        void
pv_ElementParamBind::AddItemIDBuilder (
        const string		&libraryElementName,
        ItemIDBuilder		*idBuilder)
{
        itemIDBuilders.insert (
                make_pair (libraryElementName, idBuilder));
}

ElementParamBind::ElementParamBind ()
        :
        pv(new pv_ElementParamBind ())
{
}

ElementParamBind::~ElementParamBind()
{
        delete pv;
}

/*
 * Add an element param binding.
 */
        void
ElementParamBind::AddElementParam (
        const ElementParam	&elementParam)
{
        pv->elementParams.insert (
                make_pair (
                        elementParam.GetParentElementName (),
                        elementParam));

        pv->parentElementNames.insert (elementParam.GetParentElementName ());
}

/*
 * Find an element param by its parent element name and its param SID. 
 */
        bool
ElementParamBind::FindElementParam (
        const std::string	&parentElementName,
        const std::string	&paramSID,
        ElementParam		&param)
{
        bool foundParam(false);
        for (ElementParamMap::iterator iter =
             pv->elementParams.lower_bound (parentElementName);
             iter != pv->elementParams.upper_bound (parentElementName);
             ++iter) {
                if (iter->second.GetParamSID () == paramSID) {
                        param.parentElementName = iter->second.GetParentElementName ();
                        param.elementName = iter->second.GetElementName ();
                        param.paramUniqueSID = iter->second.GetParamSID ();
                        param.paramFriendlyName = iter->second.GetParamName ();
                        param.paramVarType = iter->second.GetParamType ();

                        foundParam = true;
                        break;
                }
        }

        return foundParam;
}

/*
 * Visit all elements and their parameters for the given parent
 * element name.
 */
        void
ElementParamBind::VisitElementParams (
        const std::string		&parentElementName,
        const std::string		&elementName,
        class ElementParamVisitor	*visitor)
{
        for (ElementParamMap::iterator iter =
             pv->elementParams.lower_bound (parentElementName);
             iter != pv->elementParams.upper_bound (parentElementName);
             ++iter) {
                if (iter->second.elementName == elementName) {
                        visitor->ProcessElementParam (iter->second);
                }
        }
}

/*
 * Return the item ID for an item of a given item type.
 */
        string
ElementParamBind::GetItemID (
        const string		&libraryElementName,
        const string		&itemName)
{
        return pv->GetItemID (libraryElementName, itemName);
}

/*
 * ---------------------------------------------------------------------------
 * Element Param visitor.
 */

ElementParamVisitor::ElementParamVisitor ()
{
}

ElementParamVisitor::~ElementParamVisitor ()
{
}

/*
 * ---------------------------------------------------------------------------
 * Bound Element Param Value.
 */

BoundElementParamValue::BoundElementParamValue ()
        :
        boundElement(NULL)
{
}

        void
BoundElementParamValue::SetBoundElement (
        Element			*boundElem,
        const string		&name)
{
        boundElement = boundElem;
        elementName = name;
}

        void
BoundElementParamValue::SetValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        bool			 value)
{
        boundElement->SetBoundParamValue (
                paramElement, elementName, paramSID, value);
}

        void
BoundElementParamValue::SetValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        double			 value)
{
        boundElement->SetBoundParamValue (
                paramElement, elementName, paramSID, value);
}

        void
BoundElementParamValue::SetValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        unsigned		 value)
{
        boundElement->SetBoundParamValue (
                paramElement, elementName, paramSID, value);
}

        void
BoundElementParamValue::SetValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        const string		&value)
{
        boundElement->SetBoundParamValue (
                paramElement, elementName, paramSID, value);
}

        void
BoundElementParamValue::SetValue (
        ElementXML		**paramElement,
        const string		&paramSID,
        const Element::ColorRGB	&value)
{
        boundElement->SetBoundParamValue (
                paramElement, elementName, paramSID, value);
}

} // namespace cio

