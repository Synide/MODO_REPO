/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_GEOMETRY_H
#define CIO_GEOMETRY_H

#include "cio_element.h"
#include "cio_strings.h"

namespace cio {

class MeshElement;

/*
 * ---------------------------------------------------------------------------
 * Vertices.
 */
class VerticesElement : public Element
{
    public:
                                 VerticesElement (
                                        MeshElement		&mesh,
                                        const std::string	&meshPositionSourceID);
                                 VerticesElement (
                                        MeshElement		&mesh);
        virtual			~VerticesElement ();

        bool			 HasPositionInput () const;
        std::string		 PositionInputSourceID () const;

        bool			 HasNormalInput () const;
        std::string		 NormalInputSourceID () const;
};

/*
 * ---------------------------------------------------------------------------
 * VertexMapInputHub
 *
 * A generic hub for vertex map inputs, that enables loaders to test for
 * and get inputs without duplicating code for each geometry container type.
 */
class VertexMapInputHub
{
    public:
                                 VertexMapInputHub (
                                        MeshElement		&geoMesh);
        virtual			~VertexMapInputHub ();

        unsigned		 GetMaxInputOffset () const;

        bool			 HasVertexInput () const;
        std::string		 GetVertexInputSourceID (unsigned &offset) const;
        unsigned		 GetVertexInputOffset () const;

        virtual bool		 HasNormalInput () const;
        std::string		 GetNormalInputSourceID (unsigned &offset) const;
        unsigned		 GetNormalInputOffset () const;

        virtual bool		 HasTexcoordInput () const;
        virtual bool		 GetTexcoordInputSourceIDbyIndex (
                                        unsigned		 sourceIndex,
                                        std::string		&sourceID,
                                        unsigned		&offsetIndex,
                                        unsigned		&setIndex) const;

        virtual bool		 HasColorInput () const;
        virtual bool		 GetColorInputSourceIDbyIndex (
                                        unsigned		 sourceIndex,
                                        std::string		&sourceID,
                                        unsigned		&offsetIndex,
                                        unsigned		&setIndex) const;
        void			 AddColorInputs (
                                        const std::vector<std::string>	&sourceColorIDs,
                                        const std::vector<unsigned>	&setIndices);

        virtual bool		 HasWeightInput () const;
        virtual bool		 GetWeightInputSourceIDbyIndex (
                                        unsigned		 sourceIndex,
                                        std::string		&sourceID,
                                        unsigned		&offsetIndex,
                                        unsigned		&setIndex) const;
        void			 AddWeightInputs (
                                        const std::vector<std::string>	&sourceWeightIDs,
                                        const std::vector<unsigned>	&setIndices);

        void			 AddInputs (
                                        const std::string		&inputSemantic,
                                        const std::vector<std::string>	&sourceInputIDs,
                                        const std::vector<unsigned>	&setIndices,
                                        unsigned			&offset);

    protected:
        void			 LinkToElement (Element	*geoElement);

    private:
        Element			*element;
        MeshElement		&mesh;
};

/*
 * ---------------------------------------------------------------------------
 * Polygons.
 */
class PolygonsElement
        :
        public Element,
        public VertexMapInputHub
{
    public:
                                 PolygonsElement (
                                        MeshElement		&mesh,
                                        unsigned		 polyCount);
                                 PolygonsElement (
                                        MeshElement		&mesh);
        virtual			~PolygonsElement ();

        bool			 LinkNextPolygons (PolygonsElement &polygons);

        unsigned		 GetCount () const;

        std::string		 GetGeometryID () const;

        std::string		 GetMaterialName () const;
        void			 SetMaterialName (
                                        const std::string	&name);

        void			 AddVertexInput ();

        void			 AddNormalInput (
                                        const std::string	&sourceNormalsID);

        void			 AddTexcoordInput (
                                        const std::string	&sourceTexcoordsID,
                                        unsigned		setIndex);

        void			 AddColorInputs (
                                        const std::vector<std::string>	&sourceColorIDs,
                                        const std::vector<unsigned>	&setIndices);

        void			 AddWeightInputs (
                                        const std::vector<std::string>	&sourceWeightIDs,
                                        const std::vector<unsigned>	&setIndices);

        bool			 HasHoleIndices (
                                        unsigned		 polyIndex,
                                        unsigned		&holeCount) const;

        bool			 GetInputIndices (
                                        unsigned		 index,
                                        std::vector<unsigned>	&inputIndices);
        bool			 GetInputIndices (
                                        unsigned		 index,
                                        std::vector<unsigned>	&inputIndices,
                                        std::vector<float>	&points,
                                        std::vector<float>	&normals);

        bool			 GetHoleInputIndices (
                                        unsigned		 polyIndex,
                                        unsigned		 holeIndex,
                                        std::vector<unsigned>	&inputIndices);

        void			 AddInputIndices (
                                        std::vector<unsigned>	&inputIndices);

    private:
        struct pv_PolygonsElement *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Polylist.
 */
class PolylistElement
        :
        public Element,
        public VertexMapInputHub
{
    public:
                                 PolylistElement (
                                        MeshElement		&mesh,
                                        unsigned		 polyCount);
                                 PolylistElement (
                                        MeshElement		&mesh);
        virtual			~PolylistElement ();

        bool			 LinkNextPolylist (PolylistElement &polylist);

        unsigned		 GetCount () const;

        std::string		 GetGeometryID () const;

        std::string		 GetMaterialName () const;
        void			 SetMaterialName (
                                        const std::string	&name);

        void			 AddVertexInput ();

        void			 AddNormalInput (
                                        const std::string	&sourceNormalsID);

        void			 AddTexcoordInputs (
                                        const std::vector<std::string>	&sourceTexcoordsIDs,
                                        const std::vector<unsigned>	&setIndices);

        void			 AddColorInputs (
                                        const std::vector<std::string>	&sourceColorIDs,
                                        const std::vector<unsigned>	&setIndices);

        void			 AddWeightInputs (
                                        const std::vector<std::string>	&sourceWeightIDs,
                                        const std::vector<unsigned>	&setIndices);

        bool			 GetVertexCounts (
                                        std::vector<unsigned>	&vertexCounts);
        void			 AddVertexCounts (
                                        std::vector<unsigned>	&vertexCounts);

        bool			 GetInputIndices (
                                        std::vector<unsigned>	&inputIndices);
        bool			 GetInputIndices (
                                        std::vector<unsigned>	&inputIndices,
                                        std::vector<float>	&points,
                                        std::vector<float>	&normals,
                                        std::vector<float>	&weights);
        void			 AddInputIndices (
                                        std::vector<unsigned>	&inputIndices);

    private:
        struct pv_PolylistElement *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Triangles.
 */
class TrianglesElement
        :
        public Element,
        public VertexMapInputHub
{
    public:
                                 TrianglesElement (
                                        MeshElement		&mesh,
                                        unsigned		 polyCount);
                                 TrianglesElement (
                                        MeshElement		&mesh);
        virtual			~TrianglesElement ();

        bool			 LinkNextTriangles (TrianglesElement &triangles);

        std::string		 GetGeometryID () const;

        std::string		 GetMaterialName () const;
        void			 SetMaterialName (
                                        const std::string	&name);

        unsigned		 GetCount () const;

        void			 AddVertexInput ();

        void			 AddNormalInput (
                                        const std::string	&sourceNormalsID);

        void			 AddTexcoordInputs (
                                        const std::vector<std::string>	&sourceTexcoordsIDs,
                                        const std::vector<unsigned>	&setIndices);

        void			 AddColorInputs (
                                        const std::vector<std::string>	&sourceColorIDs,
                                        const std::vector<unsigned>	&setIndices);

        void			 AddWeightInputs (
                                        const std::vector<std::string>	&sourceWeightIDs,
                                        const std::vector<unsigned>	&setIndices);

        bool			 GetInputIndices (
                                        std::vector<unsigned>	&inputIndices);
        void			 AddInputIndices (
                                        std::vector<unsigned>	&inputIndices);

    private:
        struct pv_TrianglesElement *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Lines.
 */
class LinesElement
        :
        public Element,
        public VertexMapInputHub
{
    public:
                                 LinesElement (
                                        MeshElement		&mesh,
                                        unsigned		 count);
                                 LinesElement (
                                        MeshElement		&mesh);
        virtual			~LinesElement ();

        bool			 LinkNextLines (LinesElement &lines);

        std::string		 GetGeometryID () const;

        std::string		 GetMaterialName () const;
        void			 SetMaterialName (
                                        const std::string	&name);

        unsigned		 GetCount () const;

        void			 AddVertexInput ();

        void			 AddNormalInput (
                                        const std::string	&sourceNormalsID);

        void			 AddTexcoordInput (
                                        const std::string	&sourceTexcoordsID,
                                        unsigned		setIndex);

        void			 AddColorInputs (
                                        const std::vector<std::string>	&sourceColorIDs,
                                        const std::vector<unsigned>	&setIndices);

        void			 AddWeightInputs (
                                        const std::vector<std::string>	&sourceWeightIDs,
                                        const std::vector<unsigned>	&setIndices);

        bool			 GetInputIndices (
                                        std::vector<unsigned>	&inputIndices);
        void			 AddInputIndices (
                                        std::vector<unsigned>	&inputIndices);

    private:
        struct pv_LinesElement *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Mesh Technique Profile modo 401.
 */
class MeshElement_modo401 : public Element
{
    public:
                                 MeshElement_modo401 (
                                         MeshElement &mesh);
        virtual			~MeshElement_modo401 ();

        /*
         * Channelized parameters that can be targeted for animation.
         */
 
        void			 SetRender (const std::string &render);
 	void			 SetDissolve (double dissolve);
        void			 SetRenderCurves (bool renderCurves);
        void			 SetCurveRadius (double radius);

        /*
         * Non-channelized parameters that cannot be targetd for animation.
         */

        void			 SetSubdivisionLevel (unsigned level);
        void			 SetSplinePatchLevel (unsigned level);
        void			 SetCurveRefinementAngle (double angle);
 	void			 SetLinearUVs (bool linearUVs);

    private:
        struct pv_MeshElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Mesh.
 */

class GeometryElement;
class SourceElement;

class MeshElement : public Element
{
 	friend class SourceElement;
 	friend class VerticesElement;
        friend class PolygonsElement;
 	friend class PolylistElement;
        friend class TrianglesElement;
        friend class LinesElement;
        friend class MeshElement_modo401;

    public:
                                 MeshElement (
                                         GeometryElement	&geometry,
                                         const std::string	&name);
                                 MeshElement (
                                         GeometryElement	&geometry);
        virtual			~MeshElement ();

        std::string		 GetGeometryID () const;

        bool			 HasSource () const;
        bool			 LinkSource (
                                        const std::string	&sourceID,
                                        SourceElement		&source);

        bool			 HasVertices () const;
        bool			 LinkVertices (
                                        const std::string	&verticesID,
                                        VerticesElement		&vertices);
        bool			 LinkFirstVertices (VerticesElement &vertices);

        bool			 HasPolygons () const;
        bool			 LinkFirstPolygons (PolygonsElement &polygons);

        bool			 HasPolylist () const;
        bool			 LinkFirstPolylist (PolylistElement &polylist);

        bool			 HasTriangles () const;
        bool			 LinkFirstTriangles (TrianglesElement &triangles);

        bool			 HasLines () const;
        bool			 LinkFirstLines (LinesElement &lines);

    protected:
        void			 AddSource (SourceElement &source);

        void			 AddVertices (VerticesElement &vertices);

        void			 AddPolygons (PolygonsElement &polygons);
        void			 AddPolylist (PolylistElement &polylist);
        void			 AddTriangles (TrianglesElement &triangles);
        void			 AddLines (LinesElement &lines);
        void			 AddTechniqueProfile_modo401 (
                                        MeshElement_modo401 &modoMesh);

    private:
        struct pv_MeshElement	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Geometry.
 */

class GeometryLibraryElement;

class GeometryElement : public Element
{
        friend class MeshElement;

    public:
                                 GeometryElement (
                                         GeometryLibraryElement	&library,
                                         const std::string	&id,
                                         const std::string	&name);
                                 GeometryElement (
                                         GeometryLibraryElement	&library);
        virtual			~GeometryElement ();

        bool			 HasMesh () const;

    protected:
        bool			 LinkMesh (MeshElement &mesh);
        void			 AddMesh (MeshElement &mesh);
};

/*
 * ---------------------------------------------------------------------------
 * Geometry library.
 */

class COLLADAElement;
class GeometryLibraryElement : public Element
{
        friend class GeometryElement;

    public:
                                 GeometryLibraryElement (COLLADAElement &collada);
        virtual			~GeometryLibraryElement ();

        bool			 HasGeometry () const;
        bool			 LinkGeometry (
                                        const std::string	&geometryID,
                                        GeometryElement		&geometry);

    protected:
        void			 AddGeometry (GeometryElement &geometry);
};

} // namespace cio

#endif // CIO_GEOMETRY_H

