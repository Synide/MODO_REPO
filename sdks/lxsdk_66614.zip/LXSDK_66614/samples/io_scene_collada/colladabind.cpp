/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "colladabind.h"

#include <map>
#include <set>

using namespace std;
using namespace cio;

/*
 * ---------------------------------------------------------------------------
 * Item type channel.
 */

ItemTypeChannel::ItemTypeChannel (
        const string		&itemType,
        const string		&channel,
        const string		&paramSID,
        const string		&paramName,
        ParamType		&paramType)
        :
        itemTypeName(itemType),
        channelName(channel),
        paramUniqueSID(paramSID),
        paramFriendlyName(paramName),
        paramVarType(paramType)
{
}

ItemTypeChannel::~ItemTypeChannel ()
{
}

        string
ItemTypeChannel::ItemType () const
{
        return itemTypeName;
}

        string
ItemTypeChannel::Channel () const
{
        return channelName;
}

        string
ItemTypeChannel::GetParamSID () const
{
        return paramUniqueSID;
}

        string
ItemTypeChannel::GetParamName () const
{
        return paramFriendlyName;
}

        ParamType
ItemTypeChannel::GetParamType () const
{
        return paramVarType;
}

/*
 * ---------------------------------------------------------------------------
 * Item type channel maps and sets.
 */

/*
 * Both containers are primary-keyed by item type.
 */
typedef multimap<string, string> ItemSubTypeMap;
typedef multimap<string, ItemTypeChannel> ItemTypeChannelMap;

typedef set<string> ItemTypeSet;

/*
 * ---------------------------------------------------------------------------
 * Item type channel bind.
 */

struct pv_ItemTypeChannelBind
{
                        pv_ItemTypeChannelBind ()
        {
        }

        virtual		~pv_ItemTypeChannelBind ()
        {
        }

        ItemSubTypeMap		itemSubTypes;
        ItemTypeChannelMap	itemTypeChannels;
        ItemTypeSet		itemTypeSet;
};

ItemTypeChannelBind::ItemTypeChannelBind ()
        :
        pv(new pv_ItemTypeChannelBind ())
{
}

ItemTypeChannelBind::~ItemTypeChannelBind()
{
        delete pv;
}

/*
 * Pass back a list of item sub types for a given item type.
 */
        void
ItemTypeChannelBind::GetItemSubTypes (
        const string		&itemType,
        StringArray		&itemSubTypes)
{
        for (ItemSubTypeMap::iterator iter =
             pv->itemSubTypes.lower_bound (itemType);
             iter != pv->itemSubTypes.upper_bound (itemType);
             ++iter) {
                itemSubTypes.push_back (iter->second);
        }
}


/*
 * Add an item sub type for a given item type.
 */
        void
ItemTypeChannelBind::AddItemSubType (
        const string		&itemType,
        const string		&itemSubType)
{
        pv->itemSubTypes.insert (
                make_pair (itemType, itemSubType));
}

/*
 * Add an item type channel binding.
 */
        void
ItemTypeChannelBind::AddItemTypeChannel (
        const ItemTypeChannel	&itemTypeChannel)
{
        pv->itemTypeChannels.insert (
                make_pair (
                        itemTypeChannel.ItemType (),
                        itemTypeChannel));

        pv->itemTypeSet.insert (itemTypeChannel.ItemType ());
}

/*
 * Visit items and their channels according to the
 * extent of the given visitor.
 */
        void
ItemTypeChannelBind::VisitItemTypeChannels (
        ItemTypeChannelVisitor	*visitor)
{
        VisitExtent	extent(visitor->GetVisitExtent ());

        visitor->VisitFirstItemType ();
        for (ItemTypeSet::iterator outerIter = pv->itemTypeSet.begin ();
             outerIter != pv->itemTypeSet.end (); ++outerIter) {
                /*
                 * Let the visitor know we may be about to iterate over the
                 * first item of a given type.
                 */
                bool haveOneItemOfType = visitor->VisitFirstItemType (*outerIter);
                if (haveOneItemOfType &&
                    (extent > VISIT_EXTENT_FIRST_ITEM_OF_EACH_TYPE)) {
                        do {
                                visitor->ProcessItem (*outerIter);
                                if (extent >= VISIT_EXTENT_FIRST_WANTED_CHANNEL) {
                                        for (ItemTypeChannelMap::iterator innerIter =
                                             pv->itemTypeChannels.lower_bound (*outerIter);
                                             innerIter != pv->itemTypeChannels.upper_bound (*outerIter);
                                             ++innerIter) {
                                                bool wantChannel =
                                                        visitor->VisitItemTypeChannel (
                                                                innerIter->second);
                                                if (wantChannel) {
                                                        visitor->ProcessItemTypeChannel (
                                                                innerIter->second);
                                                        if (extent < VISIT_EXTENT_ALL_CHANNELS) {
                                                                break;
                                                        }
                                                }
                                        }
                                }
                        } while (visitor->NextItem ());
                }
        }
}

/*
 * Visit all channels for all item sub types of the given item type,
 * according to the extent of the given visitor, for which valid
 * extent values are VISIT_EXTENT_FIRST_WANTED_CHANNEL and
 * VISIT_EXTENT_ALL_CHANNELS.
 */
        void
ItemTypeChannelBind::VisitItemTypeChannels (
        const string			&itemType,
        class ItemTypeChannelVisitor	*visitor)
{
        VisitExtent	extent(visitor->GetVisitExtent ());

        visitor->VisitFirstItemType ();

        /*
         * First we iterate over any sub types for the given item type.
         */
        bool	hasSubTypes(false);
        bool	firstItem(true);
        for (ItemSubTypeMap::iterator outerIter =
             pv->itemSubTypes.lower_bound (itemType);
             outerIter != pv->itemSubTypes.upper_bound (itemType);
             ++outerIter) {
                hasSubTypes = true;
                /*
                 * Let the visitor know we may be about to iterate over the
                 * first item of a given type.
                 */
                bool haveOneItemOfType =
                        visitor->VisitFirstItemType (outerIter->second);
                if (haveOneItemOfType) {
                        do {
                                if (extent >= VISIT_EXTENT_FIRST_WANTED_CHANNEL) {
                                        bool firstChannel(true);
                                        for (ItemTypeChannelMap::iterator innerIter =
                                             pv->itemTypeChannels.lower_bound (outerIter->second);
                                             innerIter != pv->itemTypeChannels.upper_bound (outerIter->second);
                                             ++innerIter) {
                                                bool wantChannel =
                                                        visitor->VisitItemTypeChannel (
                                                                innerIter->second);
                                                if (wantChannel) {
                                                        if (firstItem) {
                                                                visitor->ProcessFirstItem (
                                                                        itemType);
                                                                firstItem = false;
                                                        }
                                                        if (firstChannel) {
                                                                visitor->ProcessItem (
                                                                        outerIter->second);
                                                                firstChannel = false;
                                                        }
                                                        visitor->ProcessItemTypeChannel (
                                                                innerIter->second);
                                                        if (extent < VISIT_EXTENT_ALL_CHANNELS) {
                                                                break;
                                                        }
                                                }
                                        }
                                }
                                else {
                                        if (firstItem) {
                                                visitor->ProcessFirstItem (
                                                        itemType);
                                                firstItem = false;
                                        }
                                        visitor->ProcessItem (
                                                outerIter->second);
                                }
                        }
                        while (visitor->NextItem ());
                }
        }

        /*
         * If no item sub types were found, iterate over
         * channels for the primary item type.
         */
        if (!hasSubTypes) {
                /*
                 * Let the visitor know we may be about to iterate over the
                 * first item of a given type.
                 */
                bool haveOneItemOfType = visitor->VisitFirstItemType (itemType);
                if (haveOneItemOfType) {
                        bool	firstItem(true);
                        do {
                                if (extent >= VISIT_EXTENT_FIRST_WANTED_CHANNEL) {
                                        bool firstChannel(true);
                                        for (ItemTypeChannelMap::iterator iter =
                                             pv->itemTypeChannels.lower_bound (itemType);
                                             iter != pv->itemTypeChannels.upper_bound (itemType);
                                             ++iter) {
                                                bool wantChannel =
                                                        visitor->VisitItemTypeChannel (
                                                                iter->second);
                                                if (wantChannel) {
                                                        if (firstItem) {
                                                                visitor->ProcessFirstItem (
                                                                        itemType);
                                                                firstItem = false;
                                                        }
                                                        if (firstChannel) {
                                                                visitor->ProcessItem (
                                                                        itemType);
                                                                firstChannel = false;
                                                        }
                                                        visitor->ProcessItemTypeChannel (
                                                                iter->second);
                                                        if (extent < VISIT_EXTENT_ALL_CHANNELS) {
                                                                break;
                                                        }
                                                }
                                        }
                                }
                                else {
                                        if (firstItem) {
                                                visitor->ProcessFirstItem (
                                                        itemType);
                                                firstItem = false;
                                        }
                                        visitor->ProcessItem (itemType);
                                }
                        }
                        while (visitor->NextItem ());
                }
        }
}

/*
 * ---------------------------------------------------------------------------
 * Item type channel visitor.
 */

struct pv_ItemTypeChannelVisitor
{
        pv_ItemTypeChannelVisitor ()
                :
                visitExtent(VISIT_EXTENT_ALL_CHANNELS),
                visitTask(VISIT_TASK_FIND_ITEM_TYPES_AND_ACTIVE_CHANNELS)
        {
        }

        virtual			~pv_ItemTypeChannelVisitor ()
        {
        }

        VisitExtent		 visitExtent;
        VisitTask		 visitTask;

        ItemTypeSet		 foundItemTypes;
        ItemTypeSet		 foundItemTypesWithChannels;
        ItemTypeChannelMap	 foundChannels;
};

ItemTypeChannelVisitor::ItemTypeChannelVisitor ()
        :
        pv(new pv_ItemTypeChannelVisitor ())
{
}

ItemTypeChannelVisitor::~ItemTypeChannelVisitor ()
{
        delete pv;
}

/*
 * Return the extent of the current traversal.
 */
        VisitExtent
ItemTypeChannelVisitor::GetVisitExtent () const
{
        return pv->visitExtent;
}

/*
 * Set the extent of the next visit traversal.
 */
        void
ItemTypeChannelVisitor::SetVisitExtent (VisitExtent extent)
{
        pv->visitExtent = extent;
}

        VisitTask
ItemTypeChannelVisitor::GetVisitTask () const
{
        return pv->visitTask;
}

        void
ItemTypeChannelVisitor::SetVisitTask (VisitTask task)
{
        pv->visitTask = task;
}

/*
 * Process the first item of a given type. Optional override.
 */
        void
ItemTypeChannelVisitor::ProcessFirstItem (
        const std::string	&itemTypeName)
{
        /*
         * Base implementation does nothing.
         */
}

/*
 * Process an item of a given type. Optional override.
 */
        void
ItemTypeChannelVisitor::ProcessItem (
        const std::string	&itemTypeName)
{
        /*
         * Base implementation does nothing.
         */
}

/*
 * Process an item channel. Optional override.
 */
        void
ItemTypeChannelVisitor::ProcessItemTypeChannel (
        const ItemTypeChannel	&itemTypeChannel)
{
        /*
         * Base implementation does nothing.
         */
}

/*
 * Returns true if at least one item of any type was found.
 */
        bool
ItemTypeChannelVisitor::FoundAnyItemType () const
{
        return (!pv->foundItemTypes.empty ());
}

/*
 * Returns true if an item of the given item type was found.
 */
        bool
ItemTypeChannelVisitor::FoundItemType (
        const std::string &itemType) const
{
        return (pv->foundItemTypes.find (itemType) !=
                pv->foundItemTypes.end ());
}

/*
 * Returns true if an item of one of the given item types was found.
 */
        bool
ItemTypeChannelVisitor::FoundItemType (
        const StringArray	&itemTypes) const
{
        bool	foundItemType(false);

        for (StringArray::const_iterator iter = itemTypes.begin();
             iter != itemTypes.end (); ++iter) {
                foundItemType =
                        (pv->foundItemTypes.find (*iter) !=
                         pv->foundItemTypes.end ());
                if (foundItemType) {
                        break;
                }
        }

        return foundItemType;
}

/*
 * Returns true if any channels were in use.
 */
        bool
ItemTypeChannelVisitor::FoundAnyChannel () const
{
        return (!pv->foundChannels.empty ());
}

/*
 * Returns true if a channel was found for the given item type.
 */
        bool
ItemTypeChannelVisitor::FoundChannel (
        const std::string &itemType) const
{
        return (pv->foundChannels.lower_bound (itemType) !=
                pv->foundChannels.upper_bound (itemType));
}

/*
 * Returns true if a channel was found for one of the given item types.
 */
        bool
ItemTypeChannelVisitor::FoundChannel (
        const StringArray	&itemTypes) const
{
        bool	foundChannel(false);

        for (StringArray::const_iterator iter = itemTypes.begin();
             iter != itemTypes.end (); ++iter) {
                foundChannel =
                        (pv->foundChannels.lower_bound (*iter) !=
                         pv->foundChannels.upper_bound (*iter));
                if (foundChannel) {
                        break;
                }
        }

        return foundChannel;
}

/*
 * Returns true if the given channel was found for the given item type.
 */
        bool
ItemTypeChannelVisitor::FoundChannel (
        const std::string	&itemType,
        const std::string	&channel) const
{
        bool foundChannel(false);
        for (ItemTypeChannelMap::iterator iter =
                pv->foundChannels.lower_bound (itemType);
             iter != pv->foundChannels.upper_bound (itemType);
             ++iter) {
                foundChannel = (iter->second.Channel () == channel);
                if (foundChannel) {
                        break;
                }
        }

        return foundChannel;
}

/*
 * Visiting the first item type. Initialize for a new traversal.
 */
        void
ItemTypeChannelVisitor::VisitFirstItemType ()
{
        if (pv->visitTask == VISIT_TASK_FIND_ITEM_TYPES_AND_ACTIVE_CHANNELS) {
                pv->foundItemTypes.clear ();
                pv->foundItemTypesWithChannels.clear ();
                pv->foundChannels.clear ();
        }
}

/*
 * Starts a scan for the first item of a given type.
 *
 * Items can be rejected, so we iterate until we find a good one.
 *
 * Returns true if at least one acceptable item was found.
 */
        bool
ItemTypeChannelVisitor::VisitFirstItemType (
        const std::string	&itemType)
{
        StartItemScan (itemType);

        bool foundItem;
        do {
                foundItem = NextItem ();
                if (foundItem && WantItem ()) {
                        if (pv->visitTask == VISIT_TASK_FIND_ITEM_TYPES_AND_ACTIVE_CHANNELS) {
                                pv->foundItemTypes.insert (itemType);
                        }
                        break;
                }
        } while (foundItem);

        return foundItem;
}

/*
 * Asks the implementor if the channel is in use via WantChannel, and then
 * in "find" task mode, marks the channel and its item type if it's in use.
 */
        bool	
ItemTypeChannelVisitor::VisitItemTypeChannel (
        const ItemTypeChannel	&itemTypeChannel)
 {
        bool wantChannel = WantChannel (
                itemTypeChannel.ItemType (),
                itemTypeChannel.Channel (),
                itemTypeChannel.GetParamType ());

        if (wantChannel &&
            pv->visitTask == VISIT_TASK_FIND_ITEM_TYPES_AND_ACTIVE_CHANNELS) {
                pv->foundItemTypesWithChannels.insert (
                        itemTypeChannel.ItemType ());

                pv->foundChannels.insert (
                        make_pair (
                                itemTypeChannel.ItemType (),
                                itemTypeChannel));
        }

        return wantChannel;
}

