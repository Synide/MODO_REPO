/*
 * MODO SDK SAMPLE
 *
 * ChannelModifier server
 * ======================
 *
 *	Copyright (c) 2008-2017 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 *
 * This implements a ChannelModifier server with one input and one output.
 *
 * CLASSES USED:
 *
 *		CLxChannelModifier
 *		CLxMetaRoot_ChannelModifier
 *
 * TESTING:
 *
 * Modifier can be added in schematic and wired up to an input. The output
 * will be twice the input.
 */
#include <lxu_chanmod.hpp>

using namespace lx_err;


#define SRVNAME_CHANMOD		"csam.chanmod.double"


        namespace ChanModDouble {

/*
 * ----------------------------------------------------------------
 * The operator is the core of the channel modifier. It both sets up the
 * channels for the modifier and serves as the object to hold onto value
 * interfaces.
 */
class COperator :
                public CLxChannelModifier
{
    public:
        CLxUser_Value		 v_input, v_result;

        /*
         * init_chan() is called once to initialize the channels of the
         * modifier.
         *
         * We add the channels with required name and type. Channel modifier
         * inputs and outputs are associated with Value wrappers in the
         * class itself. The INPUT and OUTPU flags tell the schematic which
         * side to put the dot.
         */
                void
        init_chan (
                CLxAttributeDesc	&desc)		LXx_OVERRIDE
        {
                COperator		*op = 0;

                desc.add ("input", LXsTYPE_FLOAT);
                desc.chanmod_chan (LXfCHMOD_INPUT, &op->v_input);

                desc.add ("output", LXsTYPE_FLOAT);
                desc.chanmod_chan (LXfCHMOD_OUTPUT, &op->v_result);
        }

        /*
         * eval() is called to perform operation. Inputs and outputs are
         * bound and can be read and written.
         *
         * Read out input float and output twice its value to the result.
         */
                void
        eval ()						LXx_OVERRIDE
        {
                double			 val;

                check (v_input.GetFlt (&val));
                check (v_result.SetFlt (val * 2.0));
        }
};


/*
 * ----------------------------------------------------------------
 * Metaclass
 *
 * Since no more customization is necessary. this special metaclass installs
 * the server directly without needing an explicit root.
 */
static CLxMetaRoot_ChannelModifier<COperator>		cm_meta (SRVNAME_CHANMOD);

        };	// end namespace


