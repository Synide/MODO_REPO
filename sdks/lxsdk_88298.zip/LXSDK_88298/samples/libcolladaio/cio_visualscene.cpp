/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_visualscene.h"

#include "cio_asset.h"
#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"
#include "cio_node.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile modo 401.
 */

struct pv_VisualSceneElement_modo401
{
        pv_VisualSceneElement_modo401 ()
                :
                paramFPS(NULL),
                paramStartTime(NULL),
                paramEndTime(NULL),
                paramCurrentStartTime(NULL),
                paramCurrentEndTime(NULL),
                paramTime(NULL),
                paramTimeSystem(NULL),
                paramUpAxis(NULL),
                paramDefaultDrawSize(NULL)
        {
        }

        ElementXML			*paramFPS;
        ElementXML			*paramStartTime;
        ElementXML			*paramEndTime;
        ElementXML			*paramCurrentStartTime;
        ElementXML			*paramCurrentEndTime;
        ElementXML			*paramTime;
        ElementXML			*paramTimeSystem;
        ElementXML			*paramUpAxis;
        ElementXML			*paramDefaultDrawSize;
};

VisualSceneElement_modo401::VisualSceneElement_modo401 (
        VisualSceneElement		&visualScene)
        :
        Element (visualScene.PV ()),
        pv(new pv_VisualSceneElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddTechniqueProfile_modo401 (*this);
        }
}

VisualSceneElement_modo401::~VisualSceneElement_modo401 ()
{
        delete pv;
}

/*
 * Channelized parameters that can be target for animation.
 */

        bool
VisualSceneElement_modo401::GetFPS (double &fps)
{
        return GetParamValue (GetElement (), &pv->paramFPS,
                string(PARAM_MODO_SCENE_FPS), fps);
}

        void
VisualSceneElement_modo401::SetFPS (double fps)
{
        SetParamValue (&pv->paramFPS,
                PARAM_MODO_SCENE_FPS,
                PARAM_MODO_SCENE_FPS_NAME,
                fps);
}

        bool
VisualSceneElement_modo401::GetStartEndTime (
        double			&startTime,
        double			&endTime)
{
        bool	found(false);

        if (GetParamValue (GetElement (), &pv->paramStartTime,
                string(PARAM_MODO_SCENE_START_TIME), startTime)) {
                if (GetParamValue (GetElement (), &pv->paramEndTime,
                        string(PARAM_MODO_SCENE_END_TIME), endTime)) {
                                found = true;
                }
        }

        return found;
}

        void
VisualSceneElement_modo401::SetStartEndTime (
        double			 startTime,
        double			 endTime)
{
        SetParamValue (&pv->paramStartTime,
                PARAM_MODO_SCENE_START_TIME,
                PARAM_MODO_SCENE_START_TIME_NAME,
                startTime);
        SetParamValue (&pv->paramEndTime,
                PARAM_MODO_SCENE_END_TIME,
                PARAM_MODO_SCENE_END_TIME_NAME,
                endTime);
}

        bool
VisualSceneElement_modo401::GetCurrentStartEndTime (
        double			 startTime,
        double			 endTime)
{
        bool	found(false);

        if (GetParamValue (GetElement (), &pv->paramCurrentStartTime,
                string(PARAM_MODO_SCENE_CURRENT_START_TIME), startTime)) {
                if (GetParamValue (GetElement (), &pv->paramCurrentEndTime,
                        string(PARAM_MODO_SCENE_CURRENT_END_TIME), endTime)) {
                                found = true;
                }
        }

        return found;
}

        void
VisualSceneElement_modo401::SetCurrentStartEndTime (
        double			 startTime,
        double			 endTime)
{
        SetParamValue (&pv->paramCurrentStartTime,
                PARAM_MODO_SCENE_CURRENT_START_TIME,
                PARAM_MODO_SCENE_CURRENT_START_TIME_NAME,
                startTime);
        SetParamValue (&pv->paramCurrentEndTime,
                PARAM_MODO_SCENE_CURRENT_END_TIME,
                PARAM_MODO_SCENE_CURRENT_END_TIME_NAME,
                endTime);
}

        bool
VisualSceneElement_modo401::GetTime (double &time)
{
        return GetParamValue (GetElement (), &pv->paramTime,
                string(PARAM_MODO_SCENE_TIME), time);
}

        void
VisualSceneElement_modo401::SetTime (double time)
{
        SetParamValue (&pv->paramTime,
                PARAM_MODO_SCENE_TIME,
                PARAM_MODO_SCENE_TIME_NAME,
                time);
}

        bool
VisualSceneElement_modo401::GetTimeSystem (TimeSystem &timeSystem)
{
        bool	found(false);

        string	timeSystemVal;
        if (GetParamValue (GetElement (), &pv->paramTimeSystem,
                string(PARAM_MODO_SCENE_TIME_SYSTEM), timeSystemVal)) {

                if (timeSystemVal == string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_SECONDS)) {
                        timeSystem = TIME_SYSTEM_SECONDS;
                }
                else if (timeSystemVal == string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_FRAMES)) {
                        timeSystem = TIME_SYSTEM_FRAMES;
                }
                else if (timeSystemVal == string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_SMPTE)) {
                        timeSystem = TIME_SYSTEM_SMPTE;
                }
                else if (timeSystemVal == string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_FILMCODE)) {
                        timeSystem = TIME_SYSTEM_FILMCODE;
                }
                found = true;
        }

        return found;
}

        void
VisualSceneElement_modo401::SetTimeSystem (TimeSystem timeSystem)
{
        string	timeSystemVal;
        switch (timeSystem) {
                case TIME_SYSTEM_SECONDS:
                        timeSystemVal = string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_SECONDS);
                        break;
                case TIME_SYSTEM_FRAMES:
                        timeSystemVal = string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_FRAMES);
                        break;
                case TIME_SYSTEM_SMPTE:
                        timeSystemVal = string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_SMPTE);
                        break;
                case TIME_SYSTEM_FILMCODE:
                        timeSystemVal = string(PARAMVALUE_MODO_SCENE_TIME_SYSTEM_FILMCODE);
                        break;
        }

        SetParamValue (&pv->paramTimeSystem,
                PARAM_MODO_SCENE_TIME_SYSTEM,
                PARAM_MODO_SCENE_TIME_SYSTEM_NAME,
                timeSystemVal);
}

        bool
VisualSceneElement_modo401::GetDefaultDrawSize (double &drawSize)
{
        return GetParamValue (GetElement (), &pv->paramDefaultDrawSize,
                string(PARAM_MODO_SCENE_DEFAULT_DRAW_SIZE), drawSize);
}

        void
VisualSceneElement_modo401::SetDefaultDrawSize (double drawSize)
{
        SetParamValue (&pv->paramDefaultDrawSize,
                PARAM_MODO_SCENE_DEFAULT_DRAW_SIZE,
                PARAM_MODO_SCENE_DEFAULT_DRAW_SIZE_NAME,
                drawSize);
}

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile 3ds Max.
 */

struct pv_VisualSceneElement_3dsMax
{
        pv_VisualSceneElement_3dsMax ()
                :
                frameRate(NULL)
        {
        }

        ElementXML			*frameRate;
};

VisualSceneElement_3dsMax::VisualSceneElement_3dsMax (
        VisualSceneElement		&visualScene)
        :
        Element (visualScene.PV ()),
        pv(new pv_VisualSceneElement_3dsMax())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddTechniqueProfile_3dsMax (*this);
        }
}

VisualSceneElement_3dsMax::~VisualSceneElement_3dsMax ()
{
        delete pv;
}

        bool
VisualSceneElement_3dsMax::GetFrameRate (double &frameRate)
{
        bool	linked(false);

        if (!pv->frameRate) {
                pv->frameRate = GetElement ()->FirstChildElement (ELEMENT_FRAME_RATE);
        }

        if (pv->frameRate) {
                frameRate = GetElementValueDouble (pv->frameRate);
                linked = true;
        }

        return linked;
}

        void
VisualSceneElement_3dsMax::SetFrameRate (double frameRate)
{
        if (pv->frameRate) {
                ClearElementValue (pv->frameRate);
        }
        else {
                pv->frameRate = AddElement (ELEMENT_FRAME_RATE);
        }

        SetElementValue (pv->frameRate, frameRate);
}

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile FCOLLADA.
 */

struct pv_VisualSceneElement_FCOLLADA
{
        pv_VisualSceneElement_FCOLLADA ()
                :
                startTime(NULL),
                endTime(NULL)
        {
        }

        ElementXML			*startTime;
        ElementXML			*endTime;
};

VisualSceneElement_FCOLLADA::VisualSceneElement_FCOLLADA (
        VisualSceneElement		&visualScene)
        :
        Element (visualScene.PV ()),
        pv(new pv_VisualSceneElement_FCOLLADA())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddTechniqueProfile_FCOLLADA (*this);
        }
}

VisualSceneElement_FCOLLADA::~VisualSceneElement_FCOLLADA ()
{
        delete pv;
}

/*
 * Non-channelized parameters that should not change over time.
 */

        bool
VisualSceneElement_FCOLLADA::GetStartEndTime (
        double			&startTime,
        double			&endTime)
{
        bool	linked(false);

        if (!pv->startTime) {
                pv->startTime = GetElement ()->FirstChildElement (
                        ELEMENT_START_TIME);
        }

        if (pv->startTime) {
                startTime = GetElementValueDouble (pv->startTime);

                if (!pv->endTime) {
                        pv->endTime = GetElement ()->FirstChildElement (
                                ELEMENT_END_TIME);
                }

                if (pv->endTime) {
                        endTime = GetElementValueDouble (pv->endTime);

                        linked = true;
                }
        }

        return linked;
}

        void
VisualSceneElement_FCOLLADA::SetStartEndTime (
        double			 startTime,
        double			 endTime)
{
        if (pv->startTime) {
                ClearElementValue (pv->startTime);
        }
        else {
                pv->startTime = AddElement (ELEMENT_START_TIME);
        }
        SetElementValue (pv->startTime, startTime);

        if (pv->endTime) {
                ClearElementValue (pv->endTime);
        }
        else {
                pv->endTime = AddElement (ELEMENT_END_TIME);
        }
        SetElementValue (pv->endTime, endTime);
}

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile Maya.
 */

struct pv_VisualSceneElement_Maya
{
        pv_VisualSceneElement_Maya ()
                :
                startTime(NULL),
                endTime(NULL)
        {
        }

        ElementXML			*startTime;
        ElementXML			*endTime;
};

VisualSceneElement_Maya::VisualSceneElement_Maya (
        VisualSceneElement		&visualScene)
        :
        Element (visualScene.PV ()),
        pv(new pv_VisualSceneElement_Maya())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddTechniqueProfile_Maya (*this);
        }
}

VisualSceneElement_Maya::~VisualSceneElement_Maya ()
{
        delete pv;
}

        bool
VisualSceneElement_Maya::GetStartEndTime (
        double			&startTime,
        double			&endTime)
{
        bool	linked(false);

        if (!pv->startTime) {
                pv->startTime = GetElement ()->FirstChildElement (
                        ELEMENT_START_TIME);
        }

        if (pv->startTime) {
                startTime = GetElementValueDouble (pv->startTime);

                if (!pv->endTime) {
                        pv->endTime = GetElement ()->FirstChildElement (
                                ELEMENT_END_TIME);
                }

                if (pv->endTime) {
                        endTime = GetElementValueDouble (pv->endTime);

                        linked = true;
                }
        }

        return linked;
}

        void
VisualSceneElement_Maya::SetStartEndTime (
        double			 startTime,
        double			 endTime)
{
        if (pv->startTime) {
                ClearElementValue (pv->startTime);
        }
        else {
                pv->startTime = AddElement (ELEMENT_START_TIME);
        }
        SetElementValue (pv->startTime, startTime);

        if (pv->endTime) {
                ClearElementValue (pv->endTime);
        }
        else {
                pv->endTime = AddElement (ELEMENT_END_TIME);
        }
        SetElementValue (pv->endTime, endTime);
}

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile Okino.
 */

struct pv_VisualSceneElement_Okino
{
        pv_VisualSceneElement_Okino ()
                :
                sceneBoundingMin(NULL),
                sceneBoundingMax(NULL)
        {
        }

        ElementXML			*sceneBoundingMin;
        ElementXML			*sceneBoundingMax;
};

VisualSceneElement_Okino::VisualSceneElement_Okino (
        VisualSceneElement		&visualScene)
        :
        Element (visualScene.PV ()),
        pv(new pv_VisualSceneElement_Okino())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddTechniqueProfile_Okino (*this);
        }
}

VisualSceneElement_Okino::~VisualSceneElement_Okino ()
{
        delete pv;
}

        bool
VisualSceneElement_Okino::GetSceneBoundingMin (
        double &x, double &y, double &z)
{
        bool linked(false);

        return linked;
}

        void
VisualSceneElement_Okino::SetSceneBoundingMin (
        double x, double y, double z)
{
}

        bool
VisualSceneElement_Okino::GetSceneBoundingMax (
        double &x, double &y, double &z)
{
        bool linked(false);

        return linked;
}

        void
VisualSceneElement_Okino::SetSceneBoundingMax (
        double x, double y, double z)
{
}

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Technique Profile XSI.
 */

struct pv_VisualSceneElement_XSI
{
        pv_VisualSceneElement_XSI ()
                :
                siScene(NULL),
                frameRate(NULL),
                start(NULL),
                end(NULL)
        {
        }

        ElementXML			*siScene;
        ElementXML			*frameRate;
        ElementXML			*start;
        ElementXML			*end;
};

VisualSceneElement_XSI::VisualSceneElement_XSI (
        VisualSceneElement		&visualScene)
        :
        Element (visualScene.PV ()),
        pv(new pv_VisualSceneElement_XSI())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddTechniqueProfile_XSI (*this);
        }
}

VisualSceneElement_XSI::~VisualSceneElement_XSI ()
{
        delete pv;
}

        bool
VisualSceneElement_XSI::GetFrameRate (double &frameRate)
{
        bool	linked(false);

        if (!pv->siScene) {
                pv->siScene = GetElement ()->FirstChildElement (ELEMENT_SI_SCENE);
        }

        if (pv->siScene) {
                if (!pv->frameRate) {
                        pv->frameRate = pv->siScene->FirstChildElement (ELEMENT_FRAME_RATE);
                }

                if (pv->frameRate) {
                        frameRate = GetElementValueDouble (pv->frameRate);
                        linked = true;
                }
        }

        return linked;
}

        void
VisualSceneElement_XSI::SetFrameRate (double frameRate)
{
        if (!pv->siScene) {
                pv->siScene = AddElement (ELEMENT_SI_SCENE);
        }

        if (pv->frameRate) {
                ClearElementValue (pv->frameRate);
        }
        else {
                pv->frameRate = AddElement (pv->siScene, ELEMENT_FRAME_RATE);
        }

        SetElementValue (pv->frameRate, frameRate);
}

        bool
VisualSceneElement_XSI::GetStartEndTime (
        double			&startTime,
        double			&endTime)
{
        bool	found(false);

        return found;
}

        void
VisualSceneElement_XSI::SetStartEndTime (
        double			 startTime,
        double			 endTime)
{
}

/*
 * ---------------------------------------------------------------------------
 * Visual Scene.
 */

struct pv_VisualSceneElement
{
        pv_VisualSceneElement ()
                :
                extra_modo401(NULL),
                technique_modo401(NULL),
                extra_3dsMax(NULL),
                technique_3dsMax(NULL),
                extra_FCOLLADA(NULL),
                technique_FCOLLADA(NULL),
                extra_Maya(NULL),
                technique_Maya(NULL),
                extra_Okino(NULL),
                technique_Okino(NULL),
                extra_XSI(NULL),
                technique_XSI(NULL)
        {
        }

        ElementXML*	GetAsset (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_ASSET).Element ();
        }

        ElementXML		*extra_modo401;
        ElementXML		*technique_modo401;

        ElementXML		*extra_3dsMax;
        ElementXML		*technique_3dsMax;

        ElementXML		*extra_FCOLLADA;
        ElementXML		*technique_FCOLLADA;

        ElementXML		*extra_Maya;
        ElementXML		*technique_Maya;

        ElementXML		*extra_Okino;
        ElementXML		*technique_Okino;

        ElementXML		*extra_XSI;
        ElementXML		*technique_XSI;
};

VisualSceneElement::VisualSceneElement (
         VisualSceneLibraryElement	&library,
         const std::string		&name)
        :
        Element(library.PV ()),
        pv(new pv_VisualSceneElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddVisualScene (*this);

                SetAttribute (ATTRIBUTE_ID, name);
        }
}

VisualSceneElement::VisualSceneElement (
         VisualSceneLibraryElement	&library)
        :
        Element(library.PV ()),
        pv(new pv_VisualSceneElement())
{
}

VisualSceneElement::~VisualSceneElement ()
{
        delete pv;
}

        bool
VisualSceneElement::HasAsset () const
{
        return HasChildElement (ELEMENT_ASSET);
}

        bool
VisualSceneElement::HasNode () const
{
        return HasChildElement (ELEMENT_NODE);
}

        bool
VisualSceneElement::LinkFirstNode (NodeElement &node)
{
        return LinkFirstChildElement (ELEMENT_NODE, node);
}

        bool
VisualSceneElement::LinkNextNode (NodeElement &node)
{
        bool foundNextNode(false);

        if (node.GetElement ()) {
                ElementXML *nextNode =
                        node.GetElement ()->NextSiblingElement (ELEMENT_NODE);
                if (nextNode) {
                        node.SetElement (nextNode);
                        foundNextNode = true;
                }
        }

        return foundNextNode;
}

        bool
VisualSceneElement::HasTechniqueProfile_modo401 () const
{
        return HasExtraTechniqueProfile (PROFILE_MODO401);
}

        bool
VisualSceneElement::LinkTechniqueProfile_modo401 (
        VisualSceneElement_modo401 &modoTech)
{
        return LinkExtraTechniqueProfile (PROFILE_MODO401, modoTech);
}

        bool
VisualSceneElement::HasTechniqueProfile_3dsMax () const
{
        return HasExtraTechniqueProfile (PROFILE_3DS_MAX);
}

        bool
VisualSceneElement::LinkTechniqueProfile_3dsMax (
        VisualSceneElement_3dsMax &maxTech)
{
        return LinkExtraTechniqueProfile (PROFILE_3DS_MAX, maxTech);
}

        bool
VisualSceneElement::HasTechniqueProfile_FCOLLADA () const
{
        return HasExtraTechniqueProfile (PROFILE_FCOLLADA);
}

        bool
VisualSceneElement::LinkTechniqueProfile_FCOLLADA (
        VisualSceneElement_FCOLLADA &fTech)
{
        return LinkExtraTechniqueProfile (PROFILE_FCOLLADA, fTech);
}

        bool
VisualSceneElement::HasTechniqueProfile_Maya () const
{
        return HasExtraTechniqueProfile (PROFILE_MAYA);
}

        bool
VisualSceneElement::LinkTechniqueProfile_Maya (
        VisualSceneElement_Maya &mayaTech)
{
        return LinkExtraTechniqueProfile (PROFILE_MAYA, mayaTech);
}

        bool
VisualSceneElement::HasTechniqueProfile_Okino () const
{
        return HasExtraTechniqueProfile (PROFILE_OKINO);
}

        bool
VisualSceneElement::LinkTechniqueProfile_Okino (
        VisualSceneElement_Okino &okinoTech)
{
        return LinkExtraTechniqueProfile (PROFILE_OKINO, okinoTech);
}

        bool
VisualSceneElement::HasTechniqueProfile_XSI () const
{
        return HasExtraTechniqueProfile (PROFILE_XSI);
}

        bool
VisualSceneElement::LinkTechniqueProfile_XSI (
        VisualSceneElement_XSI &xsiTech)
{
        return LinkExtraTechniqueProfile (PROFILE_XSI, xsiTech);
}

        bool
VisualSceneElement::LinkAsset (AssetElement &asset)
{
        asset.SetElement (pv->GetAsset (GetElement ()));

        return (GetElement () != NULL);
}

        void
VisualSceneElement::AddAsset (AssetElement &asset)
{
        asset.SetElement (AddElement (ELEMENT_ASSET));
}

        void
VisualSceneElement::AddNode (NodeElement &node)
{
        node.SetElement (AddElement (ELEMENT_NODE));
}

        void
VisualSceneElement::AddTechniqueProfile_modo401 (
        VisualSceneElement_modo401 &modoTech)
{
        AddTechniqueProfile (
                &pv->extra_modo401,
                &pv->technique_modo401,
                PROFILE_MODO401,
                modoTech);
}

        void
VisualSceneElement::AddTechniqueProfile_3dsMax (
        VisualSceneElement_3dsMax &maxTech)
{
        AddTechniqueProfile (
                &pv->extra_3dsMax,
                &pv->technique_3dsMax,
                PROFILE_3DS_MAX,
                maxTech);
}

        void
VisualSceneElement::AddTechniqueProfile_FCOLLADA (
        VisualSceneElement_FCOLLADA &fTech)
{
        AddTechniqueProfile (
                &pv->extra_FCOLLADA,
                &pv->technique_FCOLLADA,
                PROFILE_FCOLLADA,
                fTech);
}

        void
VisualSceneElement::AddTechniqueProfile_Maya (
        VisualSceneElement_Maya &mayaTech)
{
        AddTechniqueProfile (
                &pv->extra_Maya,
                &pv->technique_Maya,
                PROFILE_MAYA,
                mayaTech);
}

        void
VisualSceneElement::AddTechniqueProfile_Okino (
        VisualSceneElement_Okino &okinoTech)
{
        AddTechniqueProfile (
                &pv->extra_Okino,
                &pv->technique_Okino,
                PROFILE_OKINO,
                okinoTech);
}

        void
VisualSceneElement::AddTechniqueProfile_XSI (
        VisualSceneElement_XSI &xsiTech)
{
        AddTechniqueProfile (
                &pv->extra_XSI,
                &pv->technique_XSI,
                PROFILE_XSI,
                xsiTech);
}

        void
VisualSceneElement::AddTechniqueProfile (
        ElementXML		**extraElem,
        ElementXML		**techniqueElem,
        const std::string	&profileName,
        Element			&technique)
{
        if (*extraElem) {
                ClearElementValue (*extraElem);
        }
        else {
                *extraElem = AddElement (ELEMENT_EXTRA);
        }

        if (*techniqueElem) {
                ClearElementValue (*techniqueElem);
        }
        else {
                *techniqueElem = AddElement (*extraElem, ELEMENT_TECHNIQUE);
        }

        technique.SetElement (*techniqueElem);
        SetAttribute (*techniqueElem, ATTRIBUTE_PROFILE, profileName);
}

/*
 * ---------------------------------------------------------------------------
 * Visual Scene Library.
 */

VisualSceneLibraryElement::VisualSceneLibraryElement (
        COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddVisualSceneLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkVisualSceneLibrary (*this);
        }
}

VisualSceneLibraryElement::~VisualSceneLibraryElement ()
{
}

        bool
VisualSceneLibraryElement::HasVisualScene () const
{
        return HasChildElement (ELEMENT_VISUAL_SCENE);
}

        bool
VisualSceneLibraryElement::LinkVisualScene (
        const std::string &visualSceneID,
        VisualSceneElement &visualScene)
{
        return LinkFirstChildElement (ELEMENT_VISUAL_SCENE, visualSceneID, visualScene);
}

        void
VisualSceneLibraryElement::AddVisualScene (
        VisualSceneElement &visualScene)
{
        visualScene.SetElement (AddElement (ELEMENT_VISUAL_SCENE));
}

} // namespace cio

