/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_camera.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"
#include "cio_bind.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Optics.
 */

struct pv_OpticsElement
{
        pv_OpticsElement ()
                :
                techniqueCommon(NULL),
                opticsPerspective(NULL),
                opticsOrthographic(NULL),
                technique(NULL)
        {
        }

        ElementXML		*techniqueCommon;
        ElementXML		*opticsPerspective;
        ElementXML		*opticsOrthographic;
        ElementXML		*technique;
};

OpticsElement::OpticsElement (
        CameraElement		&camera,
        double			 zNear,
        double			 zFar)
        :
        Element(camera.PV ()),
        pv(new pv_OpticsElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                camera.AddOptics (*this);
        }
}

OpticsElement::~OpticsElement ()
{
        delete pv;
}

        bool
OpticsElement::HasPerspective () const
{
        return HasGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_PERSPECTIVE);
}

        bool
OpticsElement::LinkPerspective (PerspectiveElement &perspective)
{
        return LinkGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_PERSPECTIVE,
                perspective);
}

        bool
OpticsElement::HasOrthographic () const
{
        return HasGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_ORTHOGRAPHIC);
}

        bool
OpticsElement::LinkOrthographic (OrthographicElement &orthographic)
{
        return LinkGrandchildElement (
                ELEMENT_TECHNIQUE_COMMON, ELEMENT_ORTHOGRAPHIC,
                orthographic);
}

        bool
OpticsElement::HasTechniqueProfile_modo401 () const
{
        return HasTechniqueProfile (PROFILE_MODO401);
}

        bool
OpticsElement::LinkTechniqueProfile_modo401 (
        OpticsElement_modo401 &modoOptics)
{
        return LinkTechniqueProfile (PROFILE_MODO401, modoOptics);
}

        void
OpticsElement::AddPerspective (PerspectiveElement &perspective)
{
        if (pv->techniqueCommon) {
                ClearElementValue (pv->techniqueCommon);
        }
        else {
                pv->techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        }

        pv->opticsPerspective = AddElement (
                pv->techniqueCommon, ELEMENT_PERSPECTIVE);
        perspective.SetElement (pv->opticsPerspective);
}

        void
OpticsElement::AddOrthographic (OrthographicElement &orthographic)
{
        if (pv->techniqueCommon) {
                ClearElementValue (pv->techniqueCommon);
        }
        else {
                pv->techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        }

        pv->opticsOrthographic = AddElement (
                pv->techniqueCommon, ELEMENT_ORTHOGRAPHIC);
        orthographic.SetElement (pv->opticsOrthographic);
}

        void
OpticsElement::AddTechniqueProfile_modo401 (
        OpticsElement_modo401 &modoOptics)
{
        if (pv->technique) {
                ClearElementValue (pv->technique);
        }
        else {
                pv->technique = AddElement (ELEMENT_TECHNIQUE);
        }

        modoOptics.SetElement (pv->technique);
        SetAttribute (pv->technique,
                ATTRIBUTE_PROFILE, PROFILE_MODO401);
}

/*
 * ---------------------------------------------------------------------------
 * Perspective.
 */

struct pv_PerspectiveElement
{
        pv_PerspectiveElement ()
                :
                xfov(NULL),
                yfov(NULL),
                xyAspectRatio(NULL),
                zNearClip(NULL),
                zFarClip(NULL)
        {
        }

        ElementXML		*xfov;
        ElementXML		*yfov;
        ElementXML		*xyAspectRatio;

        ElementXML		*zNearClip;
        ElementXML		*zFarClip;
};

PerspectiveElement::PerspectiveElement (
        OpticsElement		&optics)
        :
        Element(optics.PV ()),
        pv(new pv_PerspectiveElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                optics.AddPerspective (*this);
        }
}

PerspectiveElement::~PerspectiveElement ()
{
        delete pv;
}

        bool
PerspectiveElement::GetFOVs (
        double			 &xFOVvalue,
        double			 &yFOVvalue)
{
        return GetElementValue (&pv->xfov,
                string(ELEMENT_XFOV), xFOVvalue) &&
               GetElementValue (&pv->yfov,
                string(ELEMENT_YFOV), yFOVvalue);
}

        void
PerspectiveElement::SetFOVs (
        double			xFOVvalue,
        double			yFOVvalue)
{
        SetBoundParamValue (&pv->xfov,
                ELEMENT_OPTICS, PARAM_XFOV, xFOVvalue, true);
        SetBoundParamValue (&pv->yfov,
                ELEMENT_OPTICS, PARAM_YFOV, yFOVvalue, true);
}

        bool
PerspectiveElement::GetXFOVandAspectRatio (
        double			 &xFOVvalue,
        double			 &aspectRatio)
{
        return GetElementValue (&pv->xfov,
                string(ELEMENT_XFOV), xFOVvalue) &&
               GetElementValue (&pv->xyAspectRatio,
                string(ELEMENT_ASPECT_RATIO), aspectRatio);
}

        void
PerspectiveElement::SetXFOVandAspectRatio (
        double			xFOVvalue,
        double			aspectRatio)
{
        SetBoundParamValue (&pv->xfov,
                ELEMENT_OPTICS, PARAM_XFOV, xFOVvalue, true);
        SetBoundParamValue (&pv->xyAspectRatio,
                ELEMENT_OPTICS, PARAM_ASPECT_RATIO, aspectRatio, true);
}

        bool
PerspectiveElement::GetYFOVandAspectRatio (
        double			 &yFOVvalue,
        double			 &aspectRatio)
{
        return GetElementValue (&pv->yfov,
                string(ELEMENT_YFOV), yFOVvalue) &&
               GetElementValue (&pv->xyAspectRatio,
                string(ELEMENT_ASPECT_RATIO), aspectRatio);
}

        void
PerspectiveElement::SetYFOVandAspectRatio (
        double			yFOVvalue,
        double			aspectRatio)
{
        SetBoundParamValue (&pv->yfov,
                ELEMENT_OPTICS, PARAM_YFOV, yFOVvalue, true);
        SetBoundParamValue (&pv->xyAspectRatio,
                ELEMENT_OPTICS, PARAM_ASPECT_RATIO, aspectRatio, true);
}

        bool
PerspectiveElement::GetZNearFar (
        double			 &zNear,
        double			 &zFar)
{
        return GetElementValue (&pv->zNearClip,
                string(ELEMENT_ZNEAR), zNear) &&
               GetElementValue (&pv->zFarClip,
                string(ELEMENT_ZFAR), zFar);
}

        void
PerspectiveElement::SetZNearFar (
        double			zNear,
        double			zFar)
{
        SetBoundParamValue (&pv->zNearClip,
                ELEMENT_OPTICS, PARAM_ZNEAR, zNear, true);
        SetBoundParamValue (&pv->zFarClip,
                ELEMENT_OPTICS, PARAM_ZFAR, zFar, true);
}

/*
 * ---------------------------------------------------------------------------
 * Orthographic.
 */

struct pv_OrthographicElement
{
        pv_OrthographicElement ()
                :
                xMagnification(NULL),
                yMagnification(NULL),
                xyAspectRatio(NULL),
                zNearClip(NULL),
                zFarClip(NULL)
        {
        }

        ElementXML		*xMagnification;
        ElementXML		*yMagnification;
        ElementXML		*xyAspectRatio;

        ElementXML		*zNearClip;
        ElementXML		*zFarClip;
};

OrthographicElement::OrthographicElement (
        OpticsElement		&optics)
        :
        Element(optics.PV ()),
        pv(new pv_OrthographicElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                optics.AddOrthographic (*this);
        }
}

OrthographicElement::~OrthographicElement ()
{
        delete pv;
}

        bool
OrthographicElement::GetMags (
        double			&xmag,
        double			&ymag)
{
        return GetElementValue (&pv->xMagnification,
                string(ELEMENT_XMAG), xmag) &&
               GetElementValue (&pv->yMagnification,
                string(ELEMENT_YMAG), ymag);
}

        void
OrthographicElement::SetMags (
        double			xmag,
        double			ymag)
{
        SetBoundParamValue (
                &pv->xMagnification, ELEMENT_OPTICS, PARAM_XMAG, xmag);
        SetBoundParamValue (
                &pv->yMagnification, ELEMENT_OPTICS, PARAM_YMAG, ymag);
}

        bool
OrthographicElement::GetXMagAndAspectRatio (
        double			&xmag,
        double			&aspectRatio)
{
        return GetElementValue (&pv->yMagnification,
                string(ELEMENT_XMAG), xmag) &&
               GetElementValue (&pv->xyAspectRatio,
                string(ELEMENT_ASPECT_RATIO), aspectRatio);
}

        void
OrthographicElement::SetXMagAndAspectRatio (
        double			xmag,
        double			aspectRatio)
{
        SetBoundParamValue (
                &pv->xMagnification,
                ELEMENT_OPTICS,
                PARAM_XMAG,
                xmag);
        SetBoundParamValue (
                &pv->xyAspectRatio,
                ELEMENT_OPTICS,
                PARAM_ASPECT_RATIO,
                aspectRatio);
}

        bool
OrthographicElement::GetYMagAndAspectRatio (
        double			 &ymag,
        double			 &aspectRatio)
{
        return GetElementValue (&pv->yMagnification,
                string(ELEMENT_YMAG), ymag) &&
               GetElementValue (&pv->xyAspectRatio,
                string(ELEMENT_ASPECT_RATIO), aspectRatio);
}

        void
OrthographicElement::SetYMagAndAspectRatio (
        double			ymag,
        double			aspectRatio)
{
        SetBoundParamValue (
                &pv->yMagnification,
                ELEMENT_OPTICS,
                PARAM_YMAG,
                ymag);
        SetBoundParamValue (
                &pv->xyAspectRatio,
                ELEMENT_OPTICS,
                PARAM_ASPECT_RATIO,
                aspectRatio);
}

        bool
OrthographicElement::GetZNearFar (
        double			 &zNear,
        double			 &zFar)
{
        return GetElementValue (&pv->zNearClip,
                string(ELEMENT_ZNEAR), zNear) &&
               GetElementValue (&pv->zFarClip,
                string(ELEMENT_ZFAR), zFar);
}

        void
OrthographicElement::SetZNearFar (
        double			zNear,
        double			zFar)
{
        SetBoundParamValue (
                &pv->zNearClip, ELEMENT_OPTICS, PARAM_ZNEAR, zNear, true);
        SetBoundParamValue (
                &pv->zFarClip, ELEMENT_OPTICS, PARAM_ZFAR, zFar, true);
}

/*
 * ---------------------------------------------------------------------------
 * Optics Technique Profile modo 401.
 */

struct pv_OpticsElement_modo401 : public BoundElementParamValue
{
        pv_OpticsElement_modo401 ()
                :
                paramTargetEnable(NULL),
                paramTargetNodeID(NULL),
                paramTargetSetFocus(NULL),
                paramTargetDistance(NULL),
                paramTargetRoll(NULL),
                paramProjection(NULL),
                paramFocalLength(NULL),
                paramSetLensDistortion(NULL),
                paramSetLensSqueeze(NULL),
                paramDepthOfField(NULL),
                paramFocusDistance(NULL),
                paramFStop(NULL),
                paramMotionBlur(NULL),
                paramMotionBlurLength(NULL),
                paramMotionBlurOffset(NULL),
                paramStereoscopic(NULL),
                paramInterocularDistance(NULL),
                paramConvergenceDistance(NULL)
        {
        }

        ElementXML		*paramTargetEnable;
        ElementXML		*paramTargetNodeID;
        ElementXML		*paramTargetSetFocus;
        ElementXML		*paramTargetDistance;
        ElementXML		*paramTargetRoll;

        ElementXML		*paramProjection;
        ElementXML		*paramFocalLength;
        ElementXML		*paramSetLensDistortion;
        ElementXML		*paramSetLensSqueeze;

        ElementXML		*paramDepthOfField;
        ElementXML		*paramFocusDistance;
        ElementXML		*paramFStop;

        ElementXML		*paramMotionBlur;
        ElementXML		*paramMotionBlurLength;
        ElementXML		*paramMotionBlurOffset;

        ElementXML		*paramStereoscopic;
        ElementXML		*paramInterocularDistance;
        ElementXML		*paramConvergenceDistance;
};

OpticsElement_modo401::OpticsElement_modo401 (
         OpticsElement &optics)
        :
        Element(optics.PV ()),
        pv(new pv_OpticsElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->SetBoundElement (this, ELEMENT_OPTICS);

                optics.AddTechniqueProfile_modo401 (*this);
        }
}

OpticsElement_modo401::~OpticsElement_modo401 ()
{
        delete pv;
}

        bool
OpticsElement_modo401::GetTargetEnable (bool &enabled)
{
        return GetParamValue (GetElement (), &pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

        void
OpticsElement_modo401::SetTargetEnable (bool enabled)
{
        pv->SetValue (&pv->paramTargetEnable,
                PARAM_MODO_TARGET_ENABLE, enabled);
}

/*
 * URI fragment ID to linked node.
 */
        bool
OpticsElement_modo401::GetTargetNodeID (string &nodeID)
{
        return GetParamValue (GetElement (), &pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        void
OpticsElement_modo401::SetTargetNodeID (const string &nodeID)
{
        pv->SetValue (&pv->paramTargetNodeID,
                PARAM_MODO_TARGET_NODE_ID, nodeID);
}

        bool
OpticsElement_modo401::GetTargetSetFocus (bool &focused)
{
        return GetParamValue (GetElement (), &pv->paramTargetSetFocus,
                PARAM_MODO_TARGET_SET_FOCUS, focused);
}

        void
OpticsElement_modo401::SetTargetSetFocus (bool focused)
{
        pv->SetValue (&pv->paramTargetSetFocus,
                PARAM_MODO_TARGET_SET_FOCUS, focused);
}

        bool
OpticsElement_modo401::GetTargetDistance (double &distance)
{
        return GetParamValue (GetElement (), &pv->paramTargetDistance,
                PARAM_MODO_CAMERA_TARGET_DISTANCE, distance);
}

        void
OpticsElement_modo401::SetTargetDistance (double distance)
{
        pv->SetValue (&pv->paramTargetDistance,
                PARAM_MODO_CAMERA_TARGET_DISTANCE, distance);
}

        bool
OpticsElement_modo401::GetTargetRoll (double &degrees)
{
        return GetParamValue (GetElement (), &pv->paramTargetRoll,
                PARAM_MODO_TARGET_ROLL, degrees);
}

        void
OpticsElement_modo401::SetTargetRoll (double degrees)
{
        pv->SetValue (
                &pv->paramTargetRoll, PARAM_MODO_TARGET_ROLL, degrees);
}

        bool
OpticsElement_modo401::GetProjection (string &type)
{
        return GetParamValue (GetElement (), &pv->paramProjection,
                string(PARAM_MODO_CAMERA_PROJECTION), type);
}

        void
OpticsElement_modo401::SetProjection (const string &type)
{
        pv->SetValue (&pv->paramProjection,
                PARAM_MODO_CAMERA_PROJECTION, type);
}

        bool
OpticsElement_modo401::GetFocalLength (double &focalLength)
{
        return GetParamValue (GetElement (), &pv->paramFocalLength,
                string(PARAM_MODO_CAMERA_FOCAL_LENGTH), focalLength);
}

        void
OpticsElement_modo401::SetFocalLength (double focalLength)
{
        pv->SetValue (&pv->paramFocalLength,
                PARAM_MODO_CAMERA_FOCAL_LENGTH, focalLength);
}

        bool
OpticsElement_modo401::GetLensDistortion (double &lensDistortion)
{
        return GetParamValue (GetElement (), &pv->paramSetLensDistortion,
                string(PARAM_MODO_CAMERA_LENS_DISTORTION), lensDistortion);
}

        void
OpticsElement_modo401::SetLensDistortion (double lensDistortion)
{
        pv->SetValue (&pv->paramSetLensDistortion,
                PARAM_MODO_CAMERA_LENS_DISTORTION, lensDistortion);
}

        bool
OpticsElement_modo401::GetLensSqueeze (double &lensSqueeze)
{
        return GetParamValue (GetElement (), &pv->paramSetLensSqueeze,
                string(PARAM_MODO_CAMERA_LENS_SQUEEZE), lensSqueeze);
}

        void
OpticsElement_modo401::SetLensSqueeze (double lensSqueeze)
{
        pv->SetValue (&pv->paramSetLensSqueeze,
                PARAM_MODO_CAMERA_LENS_SQUEEZE, lensSqueeze);
}

        bool
OpticsElement_modo401::GetDepthOfField (bool &dof)
{
        return GetParamValue (GetElement (), &pv->paramDepthOfField,
                string(PARAM_MODO_CAMERA_DEPTH_OF_FIELD), dof);
}

        void
OpticsElement_modo401::SetDepthOfField (bool dof)
{
        pv->SetValue (&pv->paramDepthOfField,
                PARAM_MODO_CAMERA_DEPTH_OF_FIELD, dof);
}

        bool
OpticsElement_modo401::GetFocusDistance (double &distance)
{
        return GetParamValue (GetElement (), &pv->paramFocusDistance,
                string(PARAM_MODO_CAMERA_FOCUS_DISTANCE), distance);
}

        void
OpticsElement_modo401::SetFocusDistance (double distance)
{
        pv->SetValue (&pv->paramFocusDistance,
                PARAM_MODO_CAMERA_FOCUS_DISTANCE, distance);
}

        bool
OpticsElement_modo401::GetFStop (double &fStop)
{
        return GetParamValue (GetElement (), &pv->paramFStop,
                string(PARAM_MODO_CAMERA_F_STOP), fStop);
}

        void
OpticsElement_modo401::SetFStop (double fStop)
{
        pv->SetValue (&pv->paramFStop, PARAM_MODO_CAMERA_F_STOP, fStop);
}

        bool
OpticsElement_modo401::GetMotionBlur (bool &motionBlur)
{
        return GetParamValue (GetElement (), &pv->paramMotionBlur,
                string(PARAM_MODO_CAMERA_MOTION_BLUR), motionBlur);
}

        void
OpticsElement_modo401::SetMotionBlur (bool motionBlur)
{
        pv->SetValue (&pv->paramMotionBlur,
                PARAM_MODO_CAMERA_MOTION_BLUR, motionBlur);
}

        bool
OpticsElement_modo401::GetMotionBlurLength (double &length)
{
        return GetParamValue (GetElement (), &pv->paramMotionBlurLength,
                string(PARAM_MODO_CAMERA_BLUR_LENGTH), length);
}

        void
OpticsElement_modo401::SetMotionBlurLength (double length)
{
        pv->SetValue (&pv->paramMotionBlurLength,
                PARAM_MODO_CAMERA_BLUR_LENGTH, length);
}

        bool
OpticsElement_modo401::GetMotionBlurOffset (double &offset)
{
        return GetParamValue (GetElement (), &pv->paramMotionBlurOffset,
                string(PARAM_MODO_CAMERA_BLUR_OFFSET), offset);
}

        void
OpticsElement_modo401::SetMotionBlurOffset (double offset)
{
        pv->SetValue (&pv->paramMotionBlurOffset,
                PARAM_MODO_CAMERA_BLUR_OFFSET, offset);
}

        bool
OpticsElement_modo401::GetStereoscopic (bool &stereo)
{
        return GetParamValue (GetElement (), &pv->paramStereoscopic,
                string(PARAM_MODO_CAMERA_STEREOSCOPIC), stereo);
}

        void
OpticsElement_modo401::SetStereoscopic (bool stereo)
{
        pv->SetValue (&pv->paramStereoscopic,
                PARAM_MODO_CAMERA_STEREOSCOPIC, stereo);
}

        bool
OpticsElement_modo401::GetInterocularDistance (double &distance)
{
        return GetParamValue (GetElement (), &pv->paramInterocularDistance,
                string(PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE), distance);
}

        void
OpticsElement_modo401::SetInterocularDistance (double distance)
{
        pv->SetValue (&pv->paramInterocularDistance,
                PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE, distance);
}

        bool
OpticsElement_modo401::GetConvergenceDistance (double &distance)
{
        return GetParamValue (GetElement (), &pv->paramConvergenceDistance,
                string(PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE), distance);
}

        void
OpticsElement_modo401::SetConvergenceDistance (double distance)
{
        pv->SetValue (&pv->paramConvergenceDistance,
                PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE, distance);
}

/*
 * ---------------------------------------------------------------------------
 * Imager.
 */

struct pv_ImagerElement
{
        pv_ImagerElement ()
                :
                technique(NULL)
        {
        }

        ElementXML		*technique;
};

ImagerElement::ImagerElement (CameraElement &camera)
        :
        Element(camera.PV ()),
        pv(new pv_ImagerElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                camera.AddImager (*this);
        }
}

ImagerElement::~ImagerElement ()
{
        delete pv;
}

        bool
ImagerElement::HasTechniqueProfile_modo401 () const
{
        return HasTechniqueProfile (PROFILE_MODO401);
}

        bool
ImagerElement::LinkTechniqueProfile_modo401 (
        ImagerElement_modo401 &modoImager)
{
        return LinkTechniqueProfile (PROFILE_MODO401, modoImager);
}

        void
ImagerElement::AddTechniqueProfile_modo401 (
        ImagerElement_modo401 &modoImager)
{
        if (pv->technique) {
                ClearElementValue (pv->technique);
        }
        else {
                pv->technique = AddElement (ELEMENT_TECHNIQUE);
        }
        modoImager.SetElement (pv->technique);
        SetAttribute (pv->technique, ATTRIBUTE_PROFILE, PROFILE_MODO401);
}

/*
 * ---------------------------------------------------------------------------
 * Imager Technique Profile modo 401.
 */

struct pv_ImagerElement_modo401 : public BoundElementParamValue
{
        pv_ImagerElement_modo401 ()
                :
                paramApertureX(NULL),
                paramApertureY(NULL),
                paramOffsetX(NULL),
                paramOffsetY(NULL),
                paramFilmFit(NULL)
        {
        }

        ElementXML		*paramApertureX;
        ElementXML		*paramApertureY;

        ElementXML		*paramOffsetX;
        ElementXML		*paramOffsetY;

        ElementXML		*paramFilmFit;
};


ImagerElement_modo401::ImagerElement_modo401 (
        ImagerElement &imager)
        :
        Element(imager.PV ()),
        pv(new pv_ImagerElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->SetBoundElement (this, ELEMENT_IMAGER);

                imager.AddTechniqueProfile_modo401 (*this);
        }
}

ImagerElement_modo401::~ImagerElement_modo401 ()
{
        delete pv;
}

        bool
ImagerElement_modo401::GetAperture (double &width, double &height)
{
        return GetParamValue (GetElement (), &pv->paramApertureX,
                string(PARAM_MODO_CAMERA_APERTURE_WIDTH), width) &&
               GetParamValue (GetElement (), &pv->paramApertureY,
                string(PARAM_MODO_CAMERA_APERTURE_HEIGHT), height);
}

        void
ImagerElement_modo401::SetAperture (
        double			width,
        double			height)
{
        pv->SetValue (
                &pv->paramApertureX,
                PARAM_MODO_CAMERA_APERTURE_WIDTH,
                width);
        pv->SetValue (
                &pv->paramApertureY,
                PARAM_MODO_CAMERA_APERTURE_HEIGHT,
                height);
}

        bool
ImagerElement_modo401::GetOffset (double &x, double &y)
{
        return GetParamValue (GetElement (), &pv->paramOffsetX,
                string(PARAM_MODO_CAMERA_OFFSET_X), x) &&
               GetParamValue (GetElement (), &pv->paramOffsetY,
                string(PARAM_MODO_CAMERA_OFFSET_Y), y);
}

        void
ImagerElement_modo401::SetOffset (double x, double y)
{
        pv->SetValue (&pv->paramOffsetX, PARAM_MODO_CAMERA_OFFSET_X, x);
        pv->SetValue (&pv->paramOffsetY, PARAM_MODO_CAMERA_OFFSET_Y, y);
}

        bool
ImagerElement_modo401::GetFilmFit (string &fit)
{
        return GetParamValue (GetElement (), &pv->paramFilmFit,
                string(PARAM_MODO_CAMERA_FILM_FIT), fit);
}

        void
ImagerElement_modo401::SetFilmFit (const string &fit)
{
        pv->SetValue (&pv->paramFilmFit, PARAM_MODO_CAMERA_FILM_FIT, fit);
}

/*
 * ---------------------------------------------------------------------------
 * Camera.
 */

CameraElement::CameraElement (
         CameraLibraryElement	&library,
         const std::string	&id,
         const std::string	&name)
        :
        Element(library.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddCamera (*this);

                SetID (CameraID (ItemID (id)));
                SetName (name);
        }
}

CameraElement::CameraElement (
         CameraLibraryElement &library)
        :
        Element(library.PV ())
{
}

CameraElement::~CameraElement ()
{
}

        bool
CameraElement::HasOptics () const
{
        return HasChildElement (ELEMENT_OPTICS);
}

        bool
CameraElement::LinkOptics (
        OpticsElement	&optics)
{
        return LinkFirstChildElement (ELEMENT_OPTICS, optics);
}

        bool
CameraElement::HasImager () const
{
        return HasChildElement (ELEMENT_IMAGER);
}

        bool
CameraElement::LinkImager (
        ImagerElement	&imager)
{
        return LinkFirstChildElement (ELEMENT_IMAGER, imager);
}

        void
CameraElement::AddOptics (OpticsElement &optics)
{
         optics.SetElement (AddElement (ELEMENT_OPTICS));
}

        void
CameraElement::AddImager (ImagerElement &imager)
{
         imager.SetElement (AddElement (ELEMENT_IMAGER));
}

/*
 * ---------------------------------------------------------------------------
 * Camera Library.
 */

CameraLibraryElement::CameraLibraryElement (COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddCameraLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkCameraLibrary (*this);
        }
}

CameraLibraryElement::~CameraLibraryElement ()
{
}

        bool
CameraLibraryElement::HasCamera () const
{
        return HasChildElement (ELEMENT_CAMERA);
}

        bool
CameraLibraryElement::LinkCamera (
        const string		&cameraID,
        CameraElement		&camera)
{
        return LinkFirstChildElement (ELEMENT_CAMERA, cameraID, camera);
}

        void
CameraLibraryElement::AddCamera (CameraElement &camera)
{
        camera.SetElement (AddElement (ELEMENT_CAMERA));
}

} // namespace cio

