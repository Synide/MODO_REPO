/*
 * C++ wrapper for lxvp.h
 *
 *	Copyright (c) 2008-2015 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 *
 */
#ifndef LXW_VP_HPP
#define LXW_VP_HPP

#include <lxvp.h>
#include <lx_wrap.hpp>
#include <string>

namespace lx {
    static const LXtGUID guid_View3DportService = {0xD84FF812,0xE4E9,0x41DC,0xB8,0x2F,0xB5,0x50,0xAC,0xF2,0xE4,0x0A};
    static const LXtGUID guid_View3D = {0x02DBFE75,0xC1AB,0x4E23,0xA4,0xC9,0x90,0x50,0x8C,0x7C,0xD7,0xC3};
};

class CLxLoc_View3DportService : public CLxLocalizedService
{
public:
  ILxView3DportServiceID m_loc;
  void _init() {m_loc=0;}
  CLxLoc_View3DportService() {_init();set();}
 ~CLxLoc_View3DportService() {}
  void set() {if(!m_loc)m_loc=reinterpret_cast<ILxView3DportServiceID>(lx::GetGlobal(&lx::guid_View3DportService));}
    LxResult
  ScriptQuery (void **ppvObj)
  {
    return m_loc[0]->ScriptQuery (m_loc,ppvObj);
  }
    int
  Count (void)
  {
    return m_loc[0]->Count (m_loc);
  }
    int
  Current (void)
  {
    return m_loc[0]->Current (m_loc);
  }
    LxResult
  View (int index, void **ppvObj)
  {
    return m_loc[0]->View (m_loc,index,ppvObj);
  }
    int
  Mouse (int *x, int *y)
  {
    return m_loc[0]->Mouse (m_loc,x,y);
  }
    LxResult
  SetHitUVMap (const char *name)
  {
    return m_loc[0]->SetHitUVMap (m_loc,name);
  }
};

class CLxImpl_View3D {
  public:
    virtual ~CLxImpl_View3D() {}
    virtual LXtID4
      view_Space (void)
        = 0;
    virtual int
      view_Axis (int *cam, LXtVector axis)
        = 0;
    virtual LxResult
      view_Bounds (int *x, int *y, int *w, int *h)
        { return LXe_NOTIMPL; }
    virtual int
      view_Style (int option)
        = 0;
    virtual double
      view_PixelSize (void)
        = 0;
    virtual LxResult
      view_Center (LXtVector center)
        { return LXe_NOTIMPL; }
    virtual double
      view_EyeVector (LXtVector pos, LXtVector dir)
        = 0;
    virtual LxResult
      view_Matrix (LXtMatrix mat, int inverse)
        { return LXe_NOTIMPL; }
    virtual LxResult
      view_Angles (LXtVector hpb)
        { return LXe_NOTIMPL; }
    virtual int
      view_WorkPlane (LXtVector center)
        = 0;
    virtual LxResult
      view_To3D (float x, float y, LXtVector pos, int flags)
        { return LXe_NOTIMPL; }
    virtual LxResult
      view_To3DHit (float x, float y, LXtVector pos, LXtVector nrm)
        { return LXe_NOTIMPL; }
    virtual LxResult
      view_Backdrop (void **item)
        { return LXe_NOTIMPL; }
    virtual const char*
      view_BackdropName (void)
        = 0;
    virtual LxResult
      view_BackdropPlace (double *cx, double *cy, double *w, double *h)
        { return LXe_NOTIMPL; }
    virtual int
      view_BackdropAspect (double *asp)
        = 0;
    virtual int
      view_BackdropOrient (double *ang)
        = 0;
    virtual int
      view_BackdropLook (double *brit, double *cont, double *trns)
        = 0;
    virtual int
      view_BackdropRender (int *resolution, int *blend)
        = 0;
    virtual int
      view_HitElement (LXtID4 type, float x, float y, void **list)
        = 0;
    virtual double
      view_GridSize (void)
        = 0;
};
#define LXxD_View3D_Space LXtID4 view_Space (void)
#define LXxO_View3D_Space LXxD_View3D_Space LXx_OVERRIDE
#define LXxD_View3D_Axis int view_Axis (int *cam, LXtVector axis)
#define LXxO_View3D_Axis LXxD_View3D_Axis LXx_OVERRIDE
#define LXxD_View3D_Bounds LxResult view_Bounds (int *x, int *y, int *w, int *h)
#define LXxO_View3D_Bounds LXxD_View3D_Bounds LXx_OVERRIDE
#define LXxD_View3D_Style int view_Style (int option)
#define LXxO_View3D_Style LXxD_View3D_Style LXx_OVERRIDE
#define LXxD_View3D_PixelSize double view_PixelSize (void)
#define LXxO_View3D_PixelSize LXxD_View3D_PixelSize LXx_OVERRIDE
#define LXxD_View3D_Center LxResult view_Center (LXtVector center)
#define LXxO_View3D_Center LXxD_View3D_Center LXx_OVERRIDE
#define LXxD_View3D_EyeVector double view_EyeVector (LXtVector pos, LXtVector dir)
#define LXxO_View3D_EyeVector LXxD_View3D_EyeVector LXx_OVERRIDE
#define LXxD_View3D_Matrix LxResult view_Matrix (LXtMatrix mat, int inverse)
#define LXxO_View3D_Matrix LXxD_View3D_Matrix LXx_OVERRIDE
#define LXxD_View3D_Angles LxResult view_Angles (LXtVector hpb)
#define LXxO_View3D_Angles LXxD_View3D_Angles LXx_OVERRIDE
#define LXxD_View3D_WorkPlane int view_WorkPlane (LXtVector center)
#define LXxO_View3D_WorkPlane LXxD_View3D_WorkPlane LXx_OVERRIDE
#define LXxD_View3D_To3D LxResult view_To3D (float x, float y, LXtVector pos, int flags)
#define LXxO_View3D_To3D LXxD_View3D_To3D LXx_OVERRIDE
#define LXxD_View3D_To3DHit LxResult view_To3DHit (float x, float y, LXtVector pos, LXtVector nrm)
#define LXxO_View3D_To3DHit LXxD_View3D_To3DHit LXx_OVERRIDE
#define LXxD_View3D_Backdrop LxResult view_Backdrop (void **item)
#define LXxO_View3D_Backdrop LXxD_View3D_Backdrop LXx_OVERRIDE
#define LXxD_View3D_BackdropName const char* view_BackdropName (void)
#define LXxO_View3D_BackdropName LXxD_View3D_BackdropName LXx_OVERRIDE
#define LXxD_View3D_BackdropPlace LxResult view_BackdropPlace (double *cx, double *cy, double *w, double *h)
#define LXxO_View3D_BackdropPlace LXxD_View3D_BackdropPlace LXx_OVERRIDE
#define LXxD_View3D_BackdropAspect int view_BackdropAspect (double *asp)
#define LXxO_View3D_BackdropAspect LXxD_View3D_BackdropAspect LXx_OVERRIDE
#define LXxD_View3D_BackdropOrient int view_BackdropOrient (double *ang)
#define LXxO_View3D_BackdropOrient LXxD_View3D_BackdropOrient LXx_OVERRIDE
#define LXxD_View3D_BackdropLook int view_BackdropLook (double *brit, double *cont, double *trns)
#define LXxO_View3D_BackdropLook LXxD_View3D_BackdropLook LXx_OVERRIDE
#define LXxD_View3D_BackdropRender int view_BackdropRender (int *resolution, int *blend)
#define LXxO_View3D_BackdropRender LXxD_View3D_BackdropRender LXx_OVERRIDE
#define LXxD_View3D_HitElement int view_HitElement (LXtID4 type, float x, float y, void **list)
#define LXxO_View3D_HitElement LXxD_View3D_HitElement LXx_OVERRIDE
#define LXxD_View3D_GridSize double view_GridSize (void)
#define LXxO_View3D_GridSize LXxD_View3D_GridSize LXx_OVERRIDE
template <class T>
class CLxIfc_View3D : public CLxInterface
{
    static LXtID4
  Space (LXtObjectID wcom)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_Space ();
  }
    static int
  Axis (LXtObjectID wcom, int *cam, LXtVector axis)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_Axis (cam,axis);
  }
    static LxResult
  Bounds (LXtObjectID wcom, int *x, int *y, int *w, int *h)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_Bounds (x,y,w,h);
    } catch (LxResult rc) { return rc; }
  }
    static int
  Style (LXtObjectID wcom, int option)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_Style (option);
  }
    static double
  PixelSize (LXtObjectID wcom)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_PixelSize ();
  }
    static LxResult
  Center (LXtObjectID wcom, LXtVector center)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_Center (center);
    } catch (LxResult rc) { return rc; }
  }
    static double
  EyeVector (LXtObjectID wcom, LXtVector pos, LXtVector dir)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_EyeVector (pos,dir);
  }
    static LxResult
  Matrix (LXtObjectID wcom, LXtMatrix mat, int inverse)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_Matrix (mat,inverse);
    } catch (LxResult rc) { return rc; }
  }
    static LxResult
  Angles (LXtObjectID wcom, LXtVector hpb)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_Angles (hpb);
    } catch (LxResult rc) { return rc; }
  }
    static int
  WorkPlane (LXtObjectID wcom, LXtVector center)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_WorkPlane (center);
  }
    static LxResult
  To3D (LXtObjectID wcom, float x, float y, LXtVector pos, int flags)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_To3D (x,y,pos,flags);
    } catch (LxResult rc) { return rc; }
  }
    static LxResult
  To3DHit (LXtObjectID wcom, float x, float y, LXtVector pos, LXtVector nrm)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_To3DHit (x,y,pos,nrm);
    } catch (LxResult rc) { return rc; }
  }
    static LxResult
  Backdrop (LXtObjectID wcom, void **item)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_Backdrop (item);
    } catch (LxResult rc) { return rc; }
  }
    static const char*
  BackdropName (LXtObjectID wcom)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_BackdropName ();
  }
    static LxResult
  BackdropPlace (LXtObjectID wcom, double *cx, double *cy, double *w, double *h)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    try {
      return loc->view_BackdropPlace (cx,cy,w,h);
    } catch (LxResult rc) { return rc; }
  }
    static int
  BackdropAspect (LXtObjectID wcom, double *asp)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_BackdropAspect (asp);
  }
    static int
  BackdropOrient (LXtObjectID wcom, double *ang)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_BackdropOrient (ang);
  }
    static int
  BackdropLook (LXtObjectID wcom, double *brit, double *cont, double *trns)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_BackdropLook (brit,cont,trns);
  }
    static int
  BackdropRender (LXtObjectID wcom, int *resolution, int *blend)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_BackdropRender (resolution,blend);
  }
    static int
  HitElement (LXtObjectID wcom, LXtID4 type, float x, float y, void **list)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_HitElement (type,x,y,list);
  }
    static double
  GridSize (LXtObjectID wcom)
  {
    LXCWxINST (CLxImpl_View3D, loc);
    return loc->view_GridSize ();
  }
  ILxView3D vt;
public:
  CLxIfc_View3D ()
  {
    vt.Space = Space;
    vt.Axis = Axis;
    vt.Bounds = Bounds;
    vt.Style = Style;
    vt.PixelSize = PixelSize;
    vt.Center = Center;
    vt.EyeVector = EyeVector;
    vt.Matrix = Matrix;
    vt.Angles = Angles;
    vt.WorkPlane = WorkPlane;
    vt.To3D = To3D;
    vt.To3DHit = To3DHit;
    vt.Backdrop = Backdrop;
    vt.BackdropName = BackdropName;
    vt.BackdropPlace = BackdropPlace;
    vt.BackdropAspect = BackdropAspect;
    vt.BackdropOrient = BackdropOrient;
    vt.BackdropLook = BackdropLook;
    vt.BackdropRender = BackdropRender;
    vt.HitElement = HitElement;
    vt.GridSize = GridSize;
    vTable = &vt.iunk;
    iid = &lx::guid_View3D;
  }
};
class CLxLoc_View3D : public CLxLocalize<ILxView3DID>
{
public:
  void _init() {m_loc=0;}
  CLxLoc_View3D() {_init();}
  CLxLoc_View3D(ILxUnknownID obj) {_init();set(obj);}
  CLxLoc_View3D(const CLxLoc_View3D &other) {_init();set(other.m_loc);}
  const LXtGUID * guid() const {return &lx::guid_View3D;}
    LXtID4
  Space (void)
  {
    return m_loc[0]->Space (m_loc);
  }
    int
  Axis (int *cam, LXtVector axis)
  {
    return m_loc[0]->Axis (m_loc,cam,axis);
  }
    LxResult
  Bounds (int *x, int *y, int *w, int *h)
  {
    return m_loc[0]->Bounds (m_loc,x,y,w,h);
  }
    int
  Style (int option)
  {
    return m_loc[0]->Style (m_loc,option);
  }
    double
  PixelSize (void)
  {
    return m_loc[0]->PixelSize (m_loc);
  }
    LxResult
  Center (LXtVector center)
  {
    return m_loc[0]->Center (m_loc,center);
  }
    double
  EyeVector (LXtVector pos, LXtVector dir)
  {
    return m_loc[0]->EyeVector (m_loc,pos,dir);
  }
    LxResult
  Matrix (LXtMatrix mat, int inverse)
  {
    return m_loc[0]->Matrix (m_loc,mat,inverse);
  }
    LxResult
  Angles (LXtVector hpb)
  {
    return m_loc[0]->Angles (m_loc,hpb);
  }
    int
  WorkPlane (LXtVector center)
  {
    return m_loc[0]->WorkPlane (m_loc,center);
  }
    LxResult
  To3D (float x, float y, LXtVector pos, int flags)
  {
    return m_loc[0]->To3D (m_loc,x,y,pos,flags);
  }
    LxResult
  To3DHit (float x, float y, LXtVector pos, LXtVector nrm)
  {
    return m_loc[0]->To3DHit (m_loc,x,y,pos,nrm);
  }
    LxResult
  Backdrop (void **item)
  {
    return m_loc[0]->Backdrop (m_loc,item);
  }
    const char*
  BackdropName (void)
  {
    return m_loc[0]->BackdropName (m_loc);
  }
    LxResult
  BackdropPlace (double *cx, double *cy, double *w, double *h)
  {
    return m_loc[0]->BackdropPlace (m_loc,cx,cy,w,h);
  }
    int
  BackdropAspect (double *asp)
  {
    return m_loc[0]->BackdropAspect (m_loc,asp);
  }
    int
  BackdropOrient (double *ang)
  {
    return m_loc[0]->BackdropOrient (m_loc,ang);
  }
    int
  BackdropLook (double *brit, double *cont, double *trns)
  {
    return m_loc[0]->BackdropLook (m_loc,brit,cont,trns);
  }
    int
  BackdropRender (int *resolution, int *blend)
  {
    return m_loc[0]->BackdropRender (m_loc,resolution,blend);
  }
    int
  HitElement (LXtID4 type, float x, float y, void **list)
  {
    return m_loc[0]->HitElement (m_loc,type,x,y,list);
  }
    double
  GridSize (void)
  {
    return m_loc[0]->GridSize (m_loc);
  }
};

#endif

