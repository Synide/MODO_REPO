/*
 * CameraInfo.h - Camera computation utility
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */


enum { // yes, these should probably be in the SDK
        LXiICVAL_CAMERA_FILMFIT_FILL,
        LXiICVAL_CAMERA_FILMFIT_HORIZONTAL,
        LXiICVAL_CAMERA_FILMFIT_VERTICAL,
        LXiICVAL_CAMERA_FILMFIT_OVERSCAN,
};


#define	LXsICHAN_CAMERA_RESOVERRIDE		"resOverride"
#define	LXsICHAN_CAMERA_RESX			"resX"
#define	LXsICHAN_CAMERA_RESY			"resY"
#define	LXsICHAN_CAMERA_OVERSCAN		"overscan"

class CameraInfo {
  public:
        bool			 valid;
        double			 apertureX, apertureY;
        double			 focalLength;
        double			 focusDist;
        double			 targetDist;
        double			 fStop;
        double			 eyeSep;
        double			 convergenceDist;
        int			 filmFit;
        double			 offsetX, offsetY;
        double			 renderX, renderY;
        double			 overscan;
        double			 pixAspect;
        int			 ortho;
        bool			 useSensor;
        
        LXtVector		 pos;
        LXtMatrix4		 xfrm;
        LXtMatrix4		 invXfrm;
        
        CameraInfo(CLxUser_Item &cam);
        
        // Read channels from camera item
        int		 readCameraChannels (CLxUser_ChannelRead chan);
        
        // get image plane coords in u,v=(0-1)
        bool		 WorldToUV (const LXtVector pos, LXtVector2 uv);
        
        // compute 3D position of screen spot at given depth
        bool		 UVToWorld (const LXtVector2 uv, const double z, LXtVector pos);
        
        // compute UV position of 3D position in camera coordinate system.
        bool		 Cam3DToUV (const LXtVector pos, LXtVector2 uv);
        
        // convert UV position in image to 3D position in camera coordinate system, at a depth 'z' from camera
        void		 UVToCam3D (const LXtVector2 uv, const double z, LXtVector pos);
        
        // compute effective aperture given image resolution and film fit modes
        void		 fitAperture (double *apX, double *apY);
  private:
        CLxUser_Item	 m_cam;
        void		 getZooms (double *zoomX, double *zoomY);
        
};


