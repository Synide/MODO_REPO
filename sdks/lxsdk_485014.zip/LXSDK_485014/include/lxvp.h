/*
 * LX vpapi module
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_vpapi_H
#define LX_vpapi_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxView3D ** ILxView3DID;
typedef struct vt_ILxGLViewport ** ILxGLViewportID;
typedef struct vt_ILxGLViewportClient ** ILxGLViewportClientID;
typedef struct vt_ILxView3DportService ** ILxView3DportServiceID;
typedef struct vt_ILxSimulationListener ** ILxSimulationListenerID;
#include <lxvalue.h>
#include <lxvector.h>
#include <lxtool.h>
#include <lxvp.h>
#include <lxhandles.h>



typedef struct vt_ILxView3D {
        ILxUnknown       iunk;
                LXxMETHOD(  LXtID4,
        Space) (
                LXtObjectID              self);


                LXxMETHOD(  int,
        Axis) (
                LXtObjectID              self,
                int                     *cam,
                LXtVector                axis);

                LXxMETHOD(  LxResult,
        Bounds) (
                LXtObjectID              self,
                int                     *x,
                int                     *y,
                int                     *w,
                int                     *h);
                LXxMETHOD(  int,
        Style) (
                LXtObjectID              self,
                int                      option);
                LXxMETHOD(  double,
        PixelSize) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        Center) (
                LXtObjectID              self,
                LXtVector                center);

                LXxMETHOD(  double,
        EyeVector) (
                LXtObjectID              self,
                LXtVector                pos,
                LXtVector                dir);

                LXxMETHOD(  LxResult,
        Matrix) (
                LXtObjectID              self,
                LXtMatrix                mat,
                int                      inverse);

                LXxMETHOD(  LxResult,
        Angles) (
                LXtObjectID              self,
                LXtVector                hpb);

                LXxMETHOD(  int,
        WorkPlane) (
                LXtObjectID              self,
                LXtVector                center);

                LXxMETHOD(  LxResult,
        To3D) (
                LXtObjectID              self,
                float                    x,
                float                    y,
                LXtVector                pos,
                int                      flags);

                LXxMETHOD(  LxResult,
        To3DHit) (
                LXtObjectID              self,
                float                    x,
                float                    y,
                LXtVector                pos,
                LXtVector                nrm);
                LXxMETHOD(  LxResult,
        Backdrop) (
                LXtObjectID              self,
                void                   **item);

                LXxMETHOD(  const char*,
        BackdropName) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        BackdropPlace) (
                LXtObjectID              self,
                double                  *cx,
                double                  *cy,
                double                  *w,
                double                  *h);

                LXxMETHOD(  int,
        BackdropAspect) (
                LXtObjectID              self,
                double                  *asp);

                LXxMETHOD(  int,
        BackdropOrient) (
                LXtObjectID              self,
                double                  *ang);

                LXxMETHOD(  int,
        BackdropLook) (
                LXtObjectID              self,
                double                  *brit,
                double                  *cont,
                double                  *trns);

                LXxMETHOD(  int,
        BackdropRender) (
                LXtObjectID              self,
                int                     *resolution,
                int                     *blend);
                LXxMETHOD(  int,
        HitElement) (
                LXtObjectID              self,
                LXtID4                   type,
                float                    x,
                float                    y,
                void                   **list);
                LXxMETHOD(  double,
        GridSize) (
                LXtObjectID              self);

                LXxMETHOD(  double,
        FrameRate) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        SetMatrix) (
                LXtObjectID             self,
                const LXtMatrix         mat);

                LXxMETHOD(  LxResult,
        SetCenter) (
                LXtObjectID             self,
                const LXtVector         vec);

                LXxMETHOD(  LxResult,
        SetScale) (
                LXtObjectID             self,
                double                  scl);
                LXxMETHOD(  LxResult,
        ItemShade) (
                LXtObjectID              self,
                LXtObjectID              item,
                unsigned                *shade);

                LXxMETHOD(  LxResult,
        ItemColor) (
                LXtObjectID              self,
                LXtObjectID              item,
                LXtFVector4              color);

                LXxMETHOD(  LxResult,
        ItemSelColor) (
                LXtObjectID              self,
                LXtObjectID              item,
                LXtFVector4              color);

                LXxMETHOD(  LxResult,
        ItemWireOverlay) (
                LXtObjectID              self,
                LXtObjectID              item,
                LXtFVector4              color,
                unsigned                *wireframe);
                LXxMETHOD(  LxResult,
        Deformers) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        ItemIsVisible) (
                LXtObjectID              self,
                LXtObjectID              item);
                LXxMETHOD(  LxResult,
        ToUVHit) (
                LXtObjectID              self,
                const char              *name,
                float                    x,
                float                    y,
                unsigned                 layer,
                float                    *u,
                float                    *v);
} ILxView3D;
typedef struct vt_ILxGLViewport {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Initialize) (
                LXtObjectID              self,
                LXtObjectID              client);
                LXxMETHOD(  LxResult,
        SetSize) (
                LXtObjectID              self,
                unsigned                 w,
                unsigned                 h);
                LXxMETHOD(  LxResult,
        Draw) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        MouseEvent) (
                LXtObjectID              self,
                unsigned                 event);
} ILxGLViewport;
typedef struct vt_ILxGLViewportClient {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Invalidate) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        MousePosition) (
                LXtObjectID              self,
                int                     *x,
                int                     *y);
                LXxMETHOD(  LxResult,
        MouseButton) (
                LXtObjectID              self,
                unsigned                *button);
                LXxMETHOD(  LxResult,
        TabletPressure) (
                LXtObjectID              self,
                double                  *press);
                LXxMETHOD(  LxResult,
        TabletTilt) (
                LXtObjectID              self,
                double                  *tilt);
} ILxGLViewportClient;
typedef struct vt_ILxView3DportService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD(  int,
        Count) (
                LXtObjectID              self);

                LXxMETHOD(  int,
        Current) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        View) (
                LXtObjectID              self,
                int                      index,
                void                   **ppvObj);

                LXxMETHOD(  int,
        Mouse) (
                LXtObjectID              self,
                int                     *x,
                int                     *y);

                LXxMETHOD(  LxResult,
        SetHitUVMap) (
                LXtObjectID              self,
                const char              *name);

                LXxMETHOD(  int,
        InvalidateOverrider) (
                LXtObjectID              self,
                LXtObjectID              scene,
                const char              *pkgName);
                LXxMETHOD(  LxResult,
        GLMaterial) (
                LXtObjectID              self,
                LXtObjectID              bin,
                LXtObjectID              item,
                LXtObjectID              view,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        TriGroupToViewObject) (
                LXtObjectID               self,
                unsigned int              type,
                LXtObjectID               triGroup,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ImageToGLImage) (
                LXtObjectID               self,
                LXtObjectID               image,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        AllocGLViewport) (
                LXtObjectID               self,
                void                    **ppvObj);
} ILxView3DportService;
typedef struct vt_ILxSimulationListener {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Start) (
                LXtObjectID              self,
                LXtObjectID              channels);

                LXxMETHOD(  LxResult,
        End) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        Time) (
                LXtObjectID              self,
                double                   time);
                LXxMETHOD(  LxResult,
        Invalidate) (
                LXtObjectID              self);
} ILxSimulationListener;

#define LXu_VIEW3D              "02DBFE75-C1AB-4E23-A4C9-90508C7CD7C3"
#define LXa_VIEW3D              "viewport3d"
// [local] ILxView3D
#define LXi_VPSPACE_MODEL               LXxID4('M','O','3','D')
#define LXi_VPSPACE_TEXTURE             LXxID4('U','V','2','D')
#define LXi_VPSPACE_WORLD               LXxID4('W','O','3','D')
#define LXi_VPSPACE_PREVIEW             LXxID4('P','R','E','V')
#define LXi_VPSPACE_MODEL2D             LXxID4('M','O','2','D')
#define LXi_VPSPACE_GRAPH               LXxID4('V','P','G','E')
#define LXi_VPSPACE_SCHEMATIC           LXxID4('S','C','H','M')
#define LXi_VP_AXIS_X            0
#define LXi_VP_AXIS_Y            1
#define LXi_VP_AXIS_Z            2
#define LXi_VP_AXIS_PERSP       -1
#define LXi_VP_AXIS_UV           LXi_VP_AXIS_Z

#define LXi_VP_CAM_LEFT         0
#define LXi_VP_CAM_RIGHT        1
#define LXi_VP_CAM_TOP          2
#define LXi_VP_CAM_BOTTOM       3
#define LXi_VP_CAM_FRONT        4
#define LXi_VP_CAM_BACK         5
#define LXi_VP_CAM_PERSP        6
enum {
        LXi_VPSTYLE_SHADE,
        LXi_VPSTYLE_WIRE,
        LXi_VPSTYLE_VCOLOR,
        LXi_VPSTYLE_SMOOTH,
        LXi_VPSTYLE_BACK,
        LXi_VPSTYLE_VERTS,
        LXi_VPSTYLE_CAGES,
        LXi_VPSTYLE_GUIDES,
        LXi_VPSTYLE_GRID,
        LXi_VPSTYLE_WPLANE,
        LXi_VPSTYLE_IMAGE,
        LXi_VPSTYLE_SELECT,
        LXi_VPSTYLE_SELNORM,
        LXi_VPSTYLE_SELFILL,
        LXi_VPSTYLE_SELBORD,
        LXi_VPSTYLE_SELROLL,
        LXi_VPSTYLE_OVERLAY,
        LXi_VPSTYLE_NULL,
};

        #define LXi_VPOPT_OFF                   0
        #define LXi_VPOPT_ON                    1

        #define LXi_VPOPT_SHADE_WIRE            0
        #define LXi_VPOPT_SHADE_SKCH            1
        #define LXi_VPOPT_SHADE_VCLR            2
        #define LXi_VPOPT_SHADE_SHAD            3
        #define LXi_VPOPT_SHADE_TEXT            4
        #define LXi_VPOPT_SHADE_REFL            5
        #define LXi_VPOPT_SHADE_PRG1            6
        #define LXi_VPOPT_SHADE_PRG2            7

        #define LXi_VPOPT_WIRE_NONE             0
        #define LXi_VPOPT_WIRE_COLR             1
        #define LXi_VPOPT_WIRE_UNIF             2

        #define LXi_VPOPT_VCLR_SEL              0
        #define LXi_VPOPT_VCLR_WGT              1
        #define LXi_VPOPT_VCLR_RGB              2

        #define LXi_VPOPT_BACK_WIRE             0
        #define LXi_VPOPT_BACK_FLAT             1
        #define LXi_VPOPT_BACK_ACTV             2
#define LXi_VPTO3D_SNAP         1
#define LXi_VPTO3D_WORK         2
#define LXi_VPHIT_VERT          LXxID4('V','E','R','T')
#define LXi_VPHIT_EDGE          LXxID4('E','D','G','E')
#define LXi_VPHIT_POLY          LXxID4('P','O','L','Y')
#define LXi_VPHIT_ITEM          LXxID4('I','T','E','M')
#define LXsPKG_DEFERRED_UPDATE          "pkg.deferredUpdate"
#define LXu_GLVIEWPORT          "9F4D9937-FF49-45E4-9781-8085A9463661"
// [local] ILxGLViewport
#define LXiGLMOUSE_EVENT_NONE           0
#define LXiGLMOUSE_EVENT_ENTER          1
#define LXiGLMOUSE_EVENT_LEAVE          2
#define LXiGLMOUSE_EVENT_DOWN           3
#define LXiGLMOUSE_EVENT_MOVE           4
#define LXiGLMOUSE_EVENT_UP             5
#define LXiGLMOUSE_EVENT_WHEELUP        6
#define LXiGLMOUSE_EVENT_WHEELDOWN      7
#define LXu_GLVIEWPORTCLIENT    "2975C75E-1F2C-4448-98BB-D3FA8ADF8595"
// [export] ILxGLViewportClient glClient
// [local]  ILxGLViewportClient
#define LXiGLMOUSE_BUTTON_NONE          0
#define LXiGLMOUSE_BUTTON_LEFT          1
#define LXiGLMOUSE_BUTTON_RIGHT         2
#define LXiGLMOUSE_BUTTON_MIDDLE        3
#define LXu_VIEW3DPORTSERVICE   "D84FF812-E4E9-41DC-B82F-B550ACF2E40A"
#define LXa_VIEW3DPORTSERVICE   "view3dservice"
#define LXu_SIMULATIONLISTENER  "628A3377-C56B-4801-878C-8BF87A097D29"
#define LXa_SIMULATIONLISTENER  "simulationlistener"
// [local]  ILxSimulationListener

 #ifdef __cplusplus
  }
 #endif
#endif

