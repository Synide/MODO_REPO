/*
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.

 */

/*
 * This file contains the constructors and initializers for the public data
 * types, and the methods of the LxoWriter class for writing data to an
 * LXO file.
 */

#include <stdio.h>
#include "lxoWriter.hpp"

static float const      s_byteToFloat  = 1.f / 255.f;
static float const      s_cos40degrees = (float) cos (40.f * s_degreesToRads);

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Set default shader flags
 *----------------------------------------------------------------------------*/
static void setShaderDefaults (LXpShadeFlags& shadeFlags)
{
    shadeFlags.shadeRate    = 1.0f;
    shadeFlags.dirMult      = 1.0f;

    shadeFlags.indType      = LXIndirectType_IrradianceCache;
    shadeFlags.indMult      = 1.0f;
    shadeFlags.indSat       = 1.0f;

    shadeFlags.alphaType    = LXAlphaType_Opacity;
    shadeFlags.alphaVal     = 1.0f;

    shadeFlags.flags        = LXfSURF_SHADCAST | LXfSURF_SHADRECV | LXfSURF_VISCAM | 
                              LXfSURF_VISIND   | LXfSURF_VISREFL  | LXfSURF_VISREFR;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Constructor to initialize layer chunk.
 *
 *----------------------------------------------------------------------------*/
LXtLayerChunk::LXtLayerChunk (LxULong index, LxULong itemRef)
{
    memset (this, 0, sizeof *this);

    m_parent            = 0xffff;
    m_flags             = LXLayerFlag_Default;
    m_index             = index;
    m_ref               = itemRef;

    m_subdivisionLevel  = 2.f;
    m_splinePatchLevel  = 16;
    m_curveAngle        = 5.f * s_degreesToRads;

    LXx_V3SET (m_scalePivot, 0.f, 0.f, 0.f);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Constructor to initialize material map layer with a file.
 *
 *----------------------------------------------------------------------------*/
void LXtMaterialLayer::Init (LxULong type, int projectMode, int tileModeU, int tileModeV)
{
    m_type          = type;
    m_projectMode   = projectMode;
    m_tileModeU     = tileModeU;
    m_tileModeV     = tileModeV;

    m_videoStillId  = 0;

    m_blendType     = LXBlend_Normal;
    m_alphaType     = LXAlphaMode_Ignore;

    m_invert        = false;
    m_invertRGB     = false;

    m_opacity       = 1.f;
    m_minValue      = 0.f;
    m_maxValue      = 1.f;

    m_file[0]   = '\0';
    m_color[0] = m_color[1] = m_color[2] = 0.0f;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Constructor to initialize material map layer with a file.
 *
 *----------------------------------------------------------------------------*/
LXtMaterialLayer::LXtMaterialLayer (LxULong type, char const* file, int projectMode, int tileModeU, int tileModeV)
{
    Init (type, projectMode, tileModeU, tileModeV);

    strcpy (m_file, file);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Constructor to initialize material map layer with a constant color.
 *
 *----------------------------------------------------------------------------*/
LXtMaterialLayer::LXtMaterialLayer (LxULong type, LXtFVector color)
{
    Init (type, LXProjection_Uv, LXTexureTile_Repeat, LXTexureTile_Repeat);

    LXx_VCPY (m_color, color);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Method to initialize material defaults.
 *
 *----------------------------------------------------------------------------*/
        void
LXtMaterial::Init (const char* name, float r, float g, float b)
{
    memset (this, 0, sizeof *this - sizeof m_layers);   // must not memset the vector!
    strcpy (m_name, name);

    setShaderDefaults (m_shadeFlags);

    m_smoothing.dblSided = true;
    m_smoothing.smooth   = 1.f;
    m_smoothing.csa      = s_cos40degrees;

    m_fur.enable        = false;

    m_fur.minDist       = 0.005f;       //  5 mm spacing
    m_fur.length        = 0.05f;        // 50 mm length
    m_fur.width         = 0.5f;
    m_fur.flex          = 0.5f;
    m_fur.density       = 1.f;
    m_fur.display       = 0.1f;
    m_fur.bumpAmp       = 0.5f;
    m_fur.clumpSize     = 0.05f;        //  50 mm
    m_fur.guideSize     = 0.1f;         // 100 mm
    m_fur.guideLen      = 1.f;
    m_fur.taper         = 0.9f;
    m_fur.rate          = 4.f;
    m_fur.blendAngle    = 45.f * s_degreesToRads;
    m_fur.posJitter     = 0.5f;
    m_fur.sclJitter     = 0.5f;
    m_fur.nrmJitter     = 0.25f;
    m_fur.grwJitter     = 0.25f;
    m_fur.maxSegment    = 8;
    m_fur.type          = LXFurType_Cylinders;
    m_fur.guides        = LXFurGuide_None;
    m_fur.randomSeed    = 1234;

    m_param.diffCol[0] = r;
    m_param.diffCol[1] = g;
    m_param.diffCol[2] = b;

    m_param.specCol[0] = m_param.specCol[1] = m_param.specCol[2] = 1.0f;
    m_param.reflCol[0] = m_param.reflCol[1] = m_param.reflCol[2] = 1.0f;
    m_param.tranCol[0] = m_param.tranCol[1] = m_param.tranCol[2] = 1.0f;
    m_param.lumiCol[0] = m_param.lumiCol[1] = m_param.lumiCol[2] = 1.0f;
    m_param.subsCol[0] = m_param.subsCol[1] = m_param.subsCol[2] = 0.8f;

    m_param.diffAmt    = 0.8f;
    m_param.specAmt    = 0.2f;
    m_param.rough      = 0.4f;
    m_param.bumpAmt    = 1.0f;
    m_param.reflRays   = 64;
    m_param.tranRays   = 64;
    m_param.refIndex   = 1.0f;
    m_param.subsDist   = 0.005f;   // scattering distance 5 mm
    m_param.subsRays   = 64;       // subsurface scattering rays
    m_param.subsPhase  = 0.5f;     // scattering phase function (forward/backward balance)
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Method to initialize material defaults for an LXP preset.
 *
 *----------------------------------------------------------------------------*/
        void
LXtMaterial::Init (const char* name, char const* presetFile)
{
    memset (this, 0, sizeof *this - sizeof m_layers);   // must not memset the vector!
    strcpy (m_name, name);
    strcpy (m_presetFile, presetFile);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Method to initialize a default material with an integer color
 *
 *----------------------------------------------------------------------------*/
LXtMaterial::LXtMaterial (const char* name, LxULong color)
{
    Init (name, s_byteToFloat * (color >> 24), s_byteToFloat * ((color >> 16) & 0xff), s_byteToFloat * ((color >> 8) & 0xff));
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Method to initialize settings defaults.
 *
 *----------------------------------------------------------------------------*/
        void
LXtRenderSettings::Init ()
{
    memset (this, 0, sizeof *this);

    m_flags.shadows                 = true;;
    m_flags.indirectIllumination    = true;;
    m_flags.irradianceCaching       = true;;
    m_flags.indirectSuperSampling   = true;;
    m_flags.microPolyDisplacement   = true;;
    m_flags.smoothPositions         = true;;
    m_flags.reflections             = true;;
    m_flags.transparency            = true;;

    m_environment.m_imageLayer              = NULL;

    m_environment.m_flags.visibleToCamera   = true;
    m_environment.m_flags.visibleToIndirect = true;
    m_environment.m_flags.visibleToReflect  = true;
    m_environment.m_flags.visibleToRefract  = true;

    setShaderDefaults (m_shadeFlags);

    m_resolution[0] = m_resolution[1] = 400;

    m_ambColor[0] = m_ambColor[1] = m_ambColor[2] = 1.0f;

    m_ambLumens                    = 8.95f;         // lumens
    m_bucketSize                   = 40;
    m_outputMode                   = LXOutput_Rgba;

    m_reflectDepth                 =   8;
    m_refractDepth                 =   8;

    m_indirectRays                 =  64;
    m_indirectBounces              =   1;
    m_irradianceRays               = 256;
    m_interpolationValues          =   1;

    m_irradianceGradients          = LXIrradianceGrads_Both;
    m_antialiasingFilter           = LXAAFilter_Gaussian;
    m_antialiasPowerOf2            = 8;
    m_indirectCaustics             = LXIndirectCaustics_Refraction;
    m_subsurfaceScattering         = LXSubsurface_DirectOnly;

    m_totalPhotons                 = 100000;
    m_localPhotons                 =     32;

    m_outputGamma                  = 1.6f;
    m_rayThreshold                 = 0.1f;
    m_refinementShadingRate        = 0.25f;
    m_refinementThreshold          = 0.1f;
    m_displacementRate             = 1.0f;
    m_displacementRatio            = 4.0f;
    m_minimumEdgeLength            = 0.0001f;        // 0.1 mm
    m_irradianceRate               = 2.5f;
    m_irradianceRatio              = 6.0f;
    m_bloomThreshold               = 1.0f;
    m_bloomRadius                  = 0.02f;         // 2%
    m_maxDepth                     = 10.0f;         // 10 meters

    m_occlusionRays                = 64;
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This constructor simply calls the LxoWriteData constructor, but is
 * here so as to keep the LxoWriter class as simple as possible.
 *
 *----------------------------------------------------------------------------*/
LxoWriter::LxoWriter (char const* lxoName, char const** channelNames, int nChannelNames) : LxoWriteData (lxoName, channelNames, nChannelNames)
{
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Add a material to the tags list
 *
 *----------------------------------------------------------------------------*/
        void
LxoWriter::AddMaterialTag (char const* name)
{
    /*
     * Insert each material name into a sorted tags map; initially set the index for each to 0.
     * The actual indices will be assigned just before the tags chunk is written.
     */

    LXtMap_StringIds::iterator  iter = m_tags.find (name);
    if (m_tags.end() == iter)
        m_tags.insert (std::pair <std::string, int>(name, 0));
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * Add a material to the tags list
 *
 *----------------------------------------------------------------------------*/
        void
LxoWriter::AddMaterialTag (LxULong color)
{
    char    name[256];
    sprintf (name, LXs_SOLID_MATERIAL_NAME_TEMPLATE, color >> 8);

    /*
     * Insert each material name into a sorted tags map; initially set the index for each to 0.
     * The actual indices will be assigned just before the tags chunk is written.
     */
    LXtMap_StringIds::iterator  iter = m_tags.find (name);
    if (m_tags.end() == iter)
        m_tags.insert (std::pair <std::string, int>(name, 0));
}

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * This method is provided so the caller can test if the LXO file is valid
 * after instantiating the LxoWriter class (or subclass), without making
 * the file pointer public (m_outFile).
 *
 *----------------------------------------------------------------------------*/
    bool
LxoWriter::IsLxoValid ()
{
    return m_outFile != NULL;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out a standard file header for this LXO file
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteFileHeader (char const* applicationString)
{
    ReturnOnError (LxoFileChunk         (this).Write ());
    ReturnOnError (LxoVersionChunk      (this).Write (LXVersion_Major, LXVersion_Minor, applicationString));
    ReturnOnError (LxoTagsChunk         (this).Write ());
    ReturnOnError (LxoChannelNamesChunk (this).Write ());

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out a camera
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteCamera (LXtCamera& camera, char const* name, LxULong* cameraId)
{
    LxULong     cameraItemId;           // Reference ID of the current camera
    LxULong     cameraItemIndex = 0;    // index of the last child item of the camera

    ReturnOnError (LxoCameraItemChunk (this).Write (camera, name));

    cameraItemId = m_itemId;            // return the id of this camera item

    if (cameraId)
        *cameraId = cameraItemId;       // return the id of this camera item

    ReturnOnError (LxoRotationItemChunk     (this).Write (cameraItemId, cameraItemIndex++, camera.rotation, name));
    ReturnOnError (LxoTranslationItemChunk  (this).Write (cameraItemId, cameraItemIndex++, camera.position, name));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write out the rendering settings items
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteRenderItems (LXtRenderSettings& settings, LxULong cameraItemId, bool useDefaultSettings)
{
    ReturnOnError (LxoPolyRenderItemChunk (this).Write (settings, cameraItemId, 0, useDefaultSettings));

    m_renderItemId      = m_itemId;
    m_renderItemIndex   = 0;

    char*   outputEffect    = LXs_FX_OUTPUT_FINAL_COLOR;
    char*   outputName      = "";

    switch (settings.m_outputMode)
        {
        default:
        case LXOutput_Rgba:
            outputName      = LXs_OUTPUT_NAME_FINAL;
            break;

        case LXOutput_AmbientOcclusion:
            outputEffect    = LXs_FX_OUTPUT_AMBIENT_OCCLUSION;
            break;

        case LXOutput_Depth:
            outputEffect    = LXs_FX_OUTPUT_DEPTH;
            outputName      = LXs_OUTPUT_NAME_DEPTH;
            break;

        case LXOutput_Shadow:
            outputEffect    = LXs_FX_OUTPUT_SHADOW_DENSITY;
            break;
        }

    ReturnOnError (LxoRenderOutputItemChunk (this).Write (settings, outputName, outputEffect));
    if (LXOutput_Depth != settings.m_outputMode)
        ReturnOnError (LxoRenderOutputItemChunk (this).Write (settings, LXs_OUTPUT_NAME_ALPHA, LXs_FX_OUTPUT_ALPHA));

    ReturnOnError (LxoSceneItemChunk (this).Write ());
    ReturnOnError (WriteEnvironment (settings));

    // need a top level shader
    ReturnOnError (LxoShaderItemChunk (this).Write ("DefaultShader", m_renderItemId, m_renderItemIndex++, &settings.m_shadeFlags));

    ReturnOnError (WriteMaterials ());      // write all materials after the render settings & default shader

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write the chunks making up a light source
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteLight (LXtLightInfo& light)
{
    char    lightMat[512];

    sprintf (lightMat, "Mat-%s", light.name);
    ReturnOnError (LxoLightMaterialItemChunk (this).Write (lightMat, light));
    ReturnOnError (LxoLightItemChunk         (this).Write (light));

    LxULong     lightItemId    = m_itemId;      // save id for the light chunk before more chunks get written
    LxULong     lightItemIndex = 0;

    if (light.flags.useDirection)
        ReturnOnError (LxoRotationItemChunk    (this).Write (lightItemId, lightItemIndex++, light.rotation, light.name));

    if (light.flags.usePosition)
        ReturnOnError (LxoTranslationItemChunk (this).Write (lightItemId, lightItemIndex++, light.position, light.name));

    if (light.lumens > m_maxLightLumens)
        m_maxLightLumens = light.lumens;

    if (LXLightType_Sun == light.type || LXLightType_SunPhysical == light.type)
        {
        m_itemIdSunlight = lightItemId;         // track the item id of the sun for the sky environment
        m_skyCloudiness  = light.cloudiness;
        m_solarDiskSize  = light.radius;
        }

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write the chunks making up a curve
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteCurveData (LXtFVector* points, LxULong nPoints, float radius, char const* materialName)
{
    LXtLayerChunk   layer (++m_layerId, m_itemId + 1);      // layer refers to the NEXT mesh item
    sprintf (layer.m_name, "Curve %d", layer.m_ref);

    ReturnOnError (LxoLayerChunk    (this).Write (layer));                              // need layer for this curve to set unique radius
    ReturnOnError (LxoPointsChunk   (this).Write (points, nPoints));                    // write all the points of the curve
    ReturnOnError (LxoPolygonsChunk (this).Write (nPoints));                            // form the 'polygon' for the curve points
    ReturnOnError (LxoPolyTagChunk  (this).Write ('MATR', 0, materialName));            // associate material with this part
    ReturnOnError (LxoMeshItemChunk (this).Write (m_layerId, layer.m_name, radius));    // set the wireframe attributes for this curve

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Write a curve with a fixed color/transparency
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteCurve (LXtFVector* points, LxULong nPoints, float radius, LxULong colorRGBA)
{
    char            materialName[256];
    sprintf (materialName, LXs_SOLID_MATERIAL_NAME_TEMPLATE, colorRGBA >> 8);

    std::string                 name (materialName);
    LXtMap_Materials::iterator  iter = m_materials.find (name);

    if (m_materials.end() == iter)
        {
        LXtMaterial     curveMaterial (materialName, colorRGBA);

        curveMaterial.m_param.specAmt = 0.f;
        LXx_VCPY (curveMaterial.m_param.tranCol, curveMaterial.m_param.diffCol);
        curveMaterial.m_param.diffAmt = (colorRGBA & 0xff) * s_byteToFloat;
        curveMaterial.m_param.tranAmt = 1.f - curveMaterial.m_param.diffAmt;
        m_materials[materialName] = curveMaterial;
        }

    return WriteCurveData (points, nPoints, radius, materialName);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Write a curve with a predefined material
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteCurve (LXtFVector* points, LxULong nPoints, float radius, LXtMaterial& material)
{
    std::string                 name (material.m_name);
    LXtMap_Materials::iterator  iter = m_materials.find (name);

    if (m_materials.end() == iter)
        {
        material.m_uvMapCount = 0;
        m_materials[name]     = material;
        }

    return WriteCurveData (points, nPoints, radius, material.m_name);
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Write a line string with a fixed color/transparency
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteLineString (LXtFVector* points, LxULong nPoints, float radius, LxULong colorRGBA)
{
    char            materialName[256];
    sprintf (materialName, LXs_SOLID_MATERIAL_NAME_TEMPLATE, colorRGBA >> 8);

    std::string                 name (materialName);
    LXtMap_Materials::iterator  iter = m_materials.find (name);

    if (m_materials.end() == iter)
        {
        LXtMaterial     curveMaterial (materialName, colorRGBA);

        curveMaterial.m_param.specAmt = 0.f;
        LXx_VCPY (curveMaterial.m_param.tranCol, curveMaterial.m_param.diffCol);
        curveMaterial.m_param.diffAmt = (colorRGBA & 0xff) * s_byteToFloat;
        curveMaterial.m_param.tranAmt = 1.f - curveMaterial.m_param.diffAmt;
        m_materials[materialName] = curveMaterial;
        }

    while (--nPoints > 0)
        ReturnOnError (WriteCurveData (points++, 2, radius, materialName));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Write a line string with a predefined material
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteLineString (LXtFVector* points, LxULong nPoints, float radius, LXtMaterial& material)
{
    std::string                 name (material.m_name);
    LXtMap_Materials::iterator  iter = m_materials.find (name);

    if (m_materials.end() == iter)
        {
        material.m_uvMapCount = 0;
        m_materials[name]     = material;
        }

    while (--nPoints > 0)
        ReturnOnError (WriteCurveData (points++, 2, radius, material.m_name));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write the chunks making up a static mesh
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteStaticMesh (LXtStaticMesh& mesh)
{
    ReturnOnError (Lxo3dGroupChunk   (this).Write (1, m_itemId + 1));       // refer to the next Surface ITEM that will be written
    ReturnOnError (Lxo3dSurfaceChunk (this).Write (mesh.nVerts, mesh.nTris, 2, 1));
    ReturnOnError (LxoVertexChunk    (this).Write (mesh.points, mesh.nVerts));
    ReturnOnError (LxoVectorChunk    (this).Write ('NORM', "Params", (float*)mesh.normals, 3, mesh.nVerts));
    ReturnOnError (LxoTrianglesChunk (this).Write (mesh.indices, mesh.nTris));

    if (mesh.material)
        {
        LxULong                     uvMapCount;
        std::string                 name (mesh.material->m_name);
        LXtMap_Materials::iterator  iter = m_materials.find (name);

        if (m_materials.end() == iter)
            {
            mesh.material->m_uvMapCount = uvMapCount = mesh.uvs ? 1 : 0;

            m_materials[name] = *mesh.material;
            }

        else if (mesh.uvs)      // record the fact that there is now another UV map associated with this material
            uvMapCount = ++(iter->second.m_uvMapCount);

        if (mesh.uvs)
            {
            char const*     uvMapName = GetUvMapName (mesh.material->m_name, uvMapCount);
            ReturnOnError (LxoTextTagChunk (this).Write ('PART', uvMapName));
            ReturnOnError (LxoVectorChunk  (this).Write ('TXUV', uvMapName, (float*)mesh.uvs, 2, mesh.nVerts));
            }

        ReturnOnError (LxoTextTagChunk (this).Write ('MATR', mesh.material->m_name));
        }

    ReturnOnError (LxoSurfaceItemChunk (this).Write (mesh.layerId, mesh.parentId, mesh.parentIndex));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 *
 * Write the chunks making up a replicated item
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoWriter::WriteReplicator (LxULong sourceItemId, LxULong nInstances, LXtFVector* positions, LXtFMatrix* xforms)
{
    LxULong         replicatorItemId    = 1 + m_itemId;             // save id for the replicator chunk (next item to be written)
    LxULong         meshItemId          = 1 + replicatorItemId;     // save id for the mesh item chunk (next item to be written)

    char            replicatorName[512];
    LXtLayerChunk   layer (++m_layerId, meshItemId);                // define the layer for the mesh item

    sprintf (replicatorName, LXs_REPLICATOR_NAME_TEMPLATE,      sourceItemId, replicatorItemId);
    sprintf (layer.m_name,   LXs_REPLICATOR_MESH_NAME_TEMPLATE, sourceItemId, replicatorItemId);

    ReturnOnError (LxoLayerChunk          (this).Write (layer));                                        // need layer for the mesh for the replicator
    ReturnOnError (LxoPointsChunk         (this).Write (positions, nInstances));                        // write the positions of the replicated item
    ReturnOnError (LxoVertexMapChunk      (this).Write ((float*)xforms, nInstances, 9));                // write the transforms of the replicated item
    ReturnOnError (LxoReplicatorItemChunk (this).Write (sourceItemId, replicatorName));
    ReturnOnError (LxoMeshItemChunk       (this).Write (m_layerId, layer.m_name, replicatorItemId));    // point the mesh item to the replicator item

    return LXe_OK;
}

