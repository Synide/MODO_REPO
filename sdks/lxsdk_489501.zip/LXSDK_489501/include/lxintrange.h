/*
 * LX intrange module
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_intrange_H
#define LX_intrange_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxIntRange ** ILxIntRangeID;




typedef struct vt_ILxIntRange {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        AllBefore) (
                LXtObjectID              self);

                LXxMETHOD( LxResult,
        AllAfter) (
                LXtObjectID              self);
                LXxMETHOD( LxResult,
        Next) (
                LXtObjectID              self,
                int                     *i);

                LXxMETHOD( LxResult,
        Prev) (
                LXtObjectID              self,
                int                     *i);
                LXxMETHOD( LxResult,
        Min) (
                LXtObjectID              self,
                int                     *min);

                LXxMETHOD( LxResult,
        Max) (
                LXtObjectID              self,
                int                     *max);
                LXxMETHOD( LxResult,
        First) (
                LXtObjectID              self,
                int                     *first);

                LXxMETHOD( LxResult,
        Last) (
                LXtObjectID              self,
                int                     *last);
                LXxMETHOD( LxResult,
        Current) (
                LXtObjectID              self,
                int                     *current);
                LXxMETHOD( LxResult,
        Test) (
                LXtObjectID              self,
                int                      i);
} ILxIntRange;

#define LXu_INTRANGE            "FEAF19EC-B819-4C46-ABA3-EC8593F8BE8C"
#define LXa_INTRANGE            "intrange"
#define LXsTYPE_INTRANGE        "+intrange"
//[local]  ILxIntRange
//[const]  ILxIntRange:AllBefore
//[const]  ILxIntRange:AllAfter
//[const]  ILxIntRange:Current
//[const]  ILxIntRange:Test
//[python] ILxIntRange:AllBefore        bool
//[python] ILxIntRange:AllAfter         bool
//[python] ILxIntRange:Test             bool

 #ifdef __cplusplus
  }
 #endif
#endif

