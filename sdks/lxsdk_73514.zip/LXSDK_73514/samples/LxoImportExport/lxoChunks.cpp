/*
 * Copyright (c) 2009 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include <string.h>
#include "lxoChunks.hpp"

static float const      s_lumensToRadiance  = (1.0f / 179.0f);       // conversion factor from lumens to watts
static float const      s_twoPi             = (float)(2.0 * M_PI);

static char const*      s_lightTypeNames[]  = {
                                                "",                     // there is no light type of 0
                                                LXsITYPE_SPOTLIGHT,
                                                LXsITYPE_POINTLIGHT,
                                                LXsITYPE_AREALIGHT,
                                                LXsITYPE_SUNLIGHT,      // sunlight IS just a directional light
                                                LXsITYPE_SUNLIGHT,      // sun with direction & intensity set by application
                                                LXsITYPE_SUNLIGHT,      // physical sun
                                                LXsITYPE_DOMELIGHT,
                                                LXsITYPE_CYLINDERLIGHT,
                                              };

static char const*      s_cameraTypeNames[]  = {
                                                LXsICVAL_CAMERA_PROJTYPE_PERSP,
                                                LXsICVAL_CAMERA_PROJTYPE_ORTHO,
                                                LXsICVAL_CAMERA_PROJTYPE_SPHERICAL,
                                              };

static char const*      s_blendNames[]      = {
                                                LXsICVAL_TEXTURELAYER_BLEND_NORMAL,
                                                LXsICVAL_TEXTURELAYER_BLEND_ADD,
                                                LXsICVAL_TEXTURELAYER_BLEND_COLORBURN,
                                                LXsICVAL_TEXTURELAYER_BLEND_COLORDODGE,
                                                LXsICVAL_TEXTURELAYER_BLEND_DARKEN,
                                                LXsICVAL_TEXTURELAYER_BLEND_DIFFERENCE,
                                                LXsICVAL_TEXTURELAYER_BLEND_DIVIDE,
                                                LXsICVAL_TEXTURELAYER_BLEND_HARDLIGHT,
                                                LXsICVAL_TEXTURELAYER_BLEND_LIGHTEN,
                                                LXsICVAL_TEXTURELAYER_BLEND_MULTIPLY,
                                                LXsICVAL_TEXTURELAYER_BLEND_NORMALMULT,
                                                LXsICVAL_TEXTURELAYER_BLEND_OVERLAY,
                                                LXsICVAL_TEXTURELAYER_BLEND_SCREEN,
                                                LXsICVAL_TEXTURELAYER_BLEND_SOFTLIGHT,
                                                LXsICVAL_TEXTURELAYER_BLEND_SUBTRACT,
                                              };

static char const*      s_materialMapNames[] = {
                                                LXs_FX_DIFFCOLOR,
                                                LXs_FX_DIFFAMOUNT,
                                                LXs_FX_SPECCOLOR,
                                                LXs_FX_SPECAMOUNT,
                                                LXs_FX_REFLCOLOR,
                                                LXs_FX_REFLAMOUNT,
                                                LXs_FX_TRANCOLOR,
                                                LXs_FX_TRANAMOUNT,
                                                LXs_FX_BUMP,
                                                LXs_FX_ROUGH,
                                                LXs_FX_SUBSCOLOR,
                                                LXs_FX_SUBSAMOUNT,
                                                LXs_FX_LUMICOLOR,
                                                LXs_FX_LUMIAMOUNT,
                                                LXs_FX_STENCIL,
                                                LXs_FX_ENVCOLOR,
                                                LXs_FX_DISPLACE,
                                                LXs_FX_COATAMOUNT,
                                                LXs_FX_ANISODIR,
                                                LXs_FX_LAYERMASK,
                                              };

static char const*      s_alphaModeNames[] = {
                                                LXsICVAL_IMAGEMAP_ALPHA_IGNORE,
                                                LXsICVAL_IMAGEMAP_ALPHA_USE,
                                                LXsICVAL_IMAGEMAP_ALPHA_ONLY,
                                              };

static char const*      s_tileModeNames[] = {
                                                LXsICVAL_TEXTURELOC_TILEUV_REPEAT,
                                                LXsICVAL_TEXTURELOC_TILEUV_RESET,
                                                LXsICVAL_TEXTURELOC_TILEUV_MIRROR,
                                                LXsICVAL_TEXTURELOC_TILEUV_EDGE,
                                              };

static char const*      s_projectionNames[] = {
                                                LXsICVAL_TEXTURELOC_PROJTYPE_NONE,
                                                LXsICVAL_TEXTURELOC_PROJTYPE_UV,
                                                LXsICVAL_TEXTURELOC_PROJTYPE_SPHERICAL,
                                                LXsICVAL_TEXTURELOC_PROJTYPE_CYLINDRICAL,
                                                LXsICVAL_TEXTURELOC_PROJTYPE_CUBIC,
                                                LXsICVAL_TEXTURELOC_PROJTYPE_FRONT,
                                                LXsICVAL_TEXTURELOC_PROJTYPE_PLANAR,
                                                LXsICVAL_TEXTURELOC_PROJTYPE_LIGHTPROBE,
                                              };

static char const*      s_furTypeNames[] = {
                                                LXs_FX_FUR_CYLINDERS,
                                                LXs_FX_FUR_STRIPS,
                                              };

static char const*      s_furGuideNames[] = {
                                                LXs_FX_FUR_GUIDE_NONE,
                                                LXs_FX_FUR_GUIDE_DIRLENGTH,
                                                LXs_FX_FUR_GUIDE_SHAPE,
                                                LXs_FX_FUR_GUIDE_RANGE,
                                                LXs_FX_FUR_GUIDE_DIRECTION,
                                                LXs_FX_FUR_GUIDE_CLUMP,
                                              };

/*******************************************************************************
 *
 * The folowing methods are used for sub-chunks of Item & Action chumks
 *
 ******************************************************************************/

/*------------------------------- Luxology LLC --------------------------- 04/09
 * External reference Sub-Chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoXRefSubChunk::Write (LxULong index, char const* filename, char const* id)
{
    WriterReturnOnError (WriteLong   (index));
    WriterReturnOnError (WriteString (filename));
    WriterReturnOnError (WriteString (id));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Layer Sub-Chunk - for name / string-value pairs
 *----------------------------------------------------------------------------*/
        LxResult
LxoLayerSubChunk::Write (LxULong index, LxULong flags, LxULong color)
{
    WriterReturnOnError (WriteLong (index));
    WriterReturnOnError (WriteLong (flags));
    WriterReturnOnError (WriteLong (color));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Link Sub-Chunk - for referencing other items by ID
 *----------------------------------------------------------------------------*/
        LxResult
LxoLinkSubChunk::Write (char const* name, LxULong parentItemId, LxULong linkItemId)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteLong   (parentItemId));
    WriterReturnOnError (WriteLong   (linkItemId));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * 
 *----------------------------------------------------------------------------*/
        LxResult
LxoPackageChunk::Write (char const* name, LxULong bytes, LxByte* data)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteLong   (bytes));
    WriterReturnOnError (WriteBytes  (data, bytes));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Scalar channel Sub-Chunk - writes a single value with name & type
 *
 * Note: this class should generally NOT be used and is only included for
 * legacy files.
 *----------------------------------------------------------------------------*/
        LxResult
LxoScalarChannelSubChunk::Write (char const* name, float value)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteShort  (LXItemType_Float));
    WriterReturnOnError (WriteFloat  (value));

    return CloseChunk ();
}

        LxResult
LxoScalarChannelSubChunk::Write (char const* name, int value)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteShort  (LXItemType_Int));
    WriterReturnOnError (WriteInt    (value));

    return CloseChunk ();
}

        LxResult
LxoScalarChannelSubChunk::Write (char const* name, char const* value)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteShort  (LXItemType_String));
    WriterReturnOnError (WriteString (value));

    return CloseChunk ();
}

        LxResult
LxoScalarChannelSubChunk::Write (char const* name, LxByte* value, LxUShort bytes)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteShort  (LXItemType_Variable));
    WriterReturnOnError (WriteShort  (bytes));
    WriterReturnOnError (WriteBytes  (value, bytes));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * RGB Channel Sub-Chunk - writes an RGB triple into a sub-chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoRgbChannelSubChunk::Write (char const* name, LXtFVector color)
{
    WriterReturnOnError (WriteString (name));

    WriterReturnOnError (WriteShort  (LXItemType_Float));   // Data type
    WriterReturnOnError (WriteShort  (3));                  // Number of elements

    WriterReturnOnError (WriteString ("R"));        WriterReturnOnError (WriteFloat (color[0]));
    WriterReturnOnError (WriteString ("G"));	    WriterReturnOnError (WriteFloat (color[1]));
    WriterReturnOnError (WriteString ("B"));	    WriterReturnOnError (WriteFloat (color[2]));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * XYZ Channel Sub-Chunk - writes an XYZ triple into a sub-chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoXyzChannelSubChunk::Write (char const* name, LXtFVector point)
{
    WriterReturnOnError (WriteString (name));

    WriterReturnOnError (WriteShort  (LXItemType_Float));   // Data type
    WriterReturnOnError (WriteShort  (3));                  // Number of elements

    WriterReturnOnError (WriteString ("X"));        WriterReturnOnError (WriteFloat (point[0]));
    WriterReturnOnError (WriteString ("Y"));	    WriterReturnOnError (WriteFloat (point[1]));
    WriterReturnOnError (WriteString ("Z"));	    WriterReturnOnError (WriteFloat (point[2]));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Name/String Sub-Chunk - for name / string-value pairs
 *----------------------------------------------------------------------------*/
        LxResult
LxoNameStringSubChunk::Write (char const* name, char const* value)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteString (value));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Gradient Sub-Chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoGradientSubChunk::Write (char const* name, LxULong envelopeIndex, LxULong flags, char* inType, char* outType)
{
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteIndex  (envelopeIndex));
    WriterReturnOnError (WriteLong   (flags));

    if ((inType && inType[0]) || (outType && outType[0]))
        {
        WriterReturnOnError (WriteString (inType  ? inType  : ""));
        WriterReturnOnError (WriteString (outType ? outType : ""));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * General Channel Value Sub-Chunk - for writing channel values by channel index
 *----------------------------------------------------------------------------*/
        LxResult
LxoChannelValueSubChunk::Write (LxULong index, LxULong envelopeIndex, LxUShort type)
{
    if (0 == index)
        return LXe_INVALIDARG;

    WriterReturnOnError (WriteIndex (index));

    if (0 == envelopeIndex)
        return m_writer->WriteShort (type);

    // only write envelope if envelopeIndex is real (non-zero)
    WriterReturnOnError (WriteShort (type | LXItemType_Envelope));
    return m_writer->WriteIndex (envelopeIndex);
}

        LxResult
LxoChannelValueSubChunk::Write (LxULong index, int value, LxULong envelopeIndex)
{
    ReturnOnError       (Write    (index, envelopeIndex, LXItemType_Int));
    WriterReturnOnError (WriteInt (value));

    return CloseChunk ();
}

        LxResult
LxoChannelValueSubChunk::Write (LxULong index, float value, LxULong envelopeIndex)
{
    ReturnOnError       (Write      (index, envelopeIndex, LXItemType_Float));
    WriterReturnOnError (WriteFloat (value));

    return CloseChunk ();
}

        LxResult
LxoChannelValueSubChunk::Write (LxULong index, char const *value, LxULong envelopeIndex)
{
    ReturnOnError       (Write       (index, envelopeIndex, LXItemType_String));
    WriterReturnOnError (WriteString (value));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Item Tag Sub-Chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoItemTagSubChunk::Write (LXtID4 type, char const* tag)
{
    WriterReturnOnError (WriteLong   (type));
    WriterReturnOnError (WriteString (tag));

    return CloseChunk ();
}


/*******************************************************************************
 *
 * The folowing methods are used for primary data chunks
 *
 ******************************************************************************/

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Version Chunk - file version & applicationstring
 *----------------------------------------------------------------------------*/
        LxResult
LxoVersionChunk::Write (LxULong major, LxULong minor, char const* appString)
{
    WriterReturnOnError (WriteLong   (major));
    WriterReturnOnError (WriteLong   (minor));
    WriterReturnOnError (WriteString (appString));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Text Tag Chunk - write a text srting with an ID
 *----------------------------------------------------------------------------*/
        LxResult
LxoTextTagChunk::Write (LXtID4 id, char const* name)
{
    WriterReturnOnError (WriteLong (id));
    WriterReturnOnError (WriteString (name));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Poly Tag Chunk - write a text srting using (by index) with a poly ID
 *----------------------------------------------------------------------------*/
        LxResult
LxoPolyTagChunk::Write (LXtID4 id, LxUShort polyId, char const* name)
{
    WriterReturnOnError (WriteLong  (id));
    WriterReturnOnError (WriteShort (polyId));

    LxUShort    tagIndex = m_writer->GetTagIndex (name);
    if (0 == tagIndex)
        fprintf (stderr, "Error: tag <%s> not defined.\n", name);

    WriterReturnOnError (WriteShort (tagIndex));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Layer Chunk - write a layer chunk to group curves
 *----------------------------------------------------------------------------*/
        LxResult
LxoLayerChunk::Write (LXtLayerChunk& layer)
{
    WriterReturnOnError (WriteShort  (layer.m_index));
    WriterReturnOnError (WriteShort  (layer.m_flags));
    WriterReturnOnError (WriteFloats (layer.m_pivot, 3));
    WriterReturnOnError (WriteString (layer.m_name));
    WriterReturnOnError (WriteShort  (layer.m_parent));
    WriterReturnOnError (WriteFloat  (layer.m_subdivisionLevel));
    WriterReturnOnError (WriteFloat  (layer.m_curveAngle));
    WriterReturnOnError (WriteFloats (layer.m_scalePivot, 3));
    WriterReturnOnError (WriteLongs  (layer.m_unused, 6));
    WriterReturnOnError (WriteLong   (layer.m_ref));
    WriterReturnOnError (WriteShort  (layer.m_splinePatchLevel));
    WriterReturnOnError (WriteShorts (layer.m_future, 3));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * 3D Group Chunk - Information about a group of surfaces
 *----------------------------------------------------------------------------*/
        LxResult
Lxo3dGroupChunk::Write (LxULong nSurfs, LxULong surfItemIndex, LxULong unused)
{
    WriterReturnOnError (WriteLong (nSurfs));
    WriterReturnOnError (WriteLong (surfItemIndex));
    WriterReturnOnError (WriteLong (unused));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * 3D Surface Chunk - Information about a surface
 *----------------------------------------------------------------------------*/
        LxResult
Lxo3dSurfaceChunk::Write (LxULong nVerts, LxULong nTris, LxULong nVects, LxULong nTags, LxULong unused)
{
    WriterReturnOnError (WriteLong (nVerts));
    WriterReturnOnError (WriteLong (nTris));
    WriterReturnOnError (WriteLong (nVects));
    WriterReturnOnError (WriteLong (nTags));
    WriterReturnOnError (WriteLong (unused));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Polygons Chunk - list of "polygons" that make up a curve.
 *
 * use all the vertices, just enumerate them from 0 to nPoints
 *----------------------------------------------------------------------------*/
        LxResult
LxoPolygonsChunk::Write (LxULong nPoints)
{
    WriterReturnOnError (WriteLong  ('CURV'));
    WriterReturnOnError (WriteShort (nPoints));

    for (LxULong i = 0; i < nPoints; ++i)
        WriterReturnOnError (WriteIndex (i));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Polygons Chunk - list of "polygons" that make up a line string
 *----------------------------------------------------------------------------*/
        LxResult
LxoPolygonsChunk::Write (LxULong* verts, LxUShort nSegments, LxULong nVertsPerSegment)
{
    WriterReturnOnError (WriteLong ('FACE'));

    while (nSegments-- > 0)
        {
        WriterReturnOnError (WriteShort   (nVertsPerSegment));
        WriterReturnOnError (WriteIndexes (verts, nVertsPerSegment));
        verts += nVertsPerSegment;
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Vertex Chunk - Write out array of vertices
 *----------------------------------------------------------------------------*/
        LxResult
LxoVertexChunk::Write (LXtFVector* verts, LxULong nVerts)
{
    WriterReturnOnError (WriteFloats ((float*)verts, nVerts * 3));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Vertex Map Chunk - Write out a vertex map
 *----------------------------------------------------------------------------*/
        LxResult
LxoVertexMapChunk::Write (float* verts, LxULong nVerts, LxUShort valsPerVert, LXtID4 id, const char *name)
{
    WriterReturnOnError (WriteLong   (id));
    WriterReturnOnError (WriteShort  (valsPerVert));
    WriterReturnOnError (WriteString (name));

    for (LxULong i = 0; i < nVerts; ++i, verts += valsPerVert)
        {
        WriterReturnOnError (WriteIndex  (i));
        WriterReturnOnError (WriteFloats (verts, valsPerVert));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 03/12
 * Discontinuous Vertex Map Chunk - Write out a vertex map
 *----------------------------------------------------------------------------*/
        LxResult
LxoVertexMapDiscChunk::Write (float* verts, LxULong* vInds, LxULong* pInds, LxULong nVerts, LxUShort valsPerVert, LXtID4 id, const char *name)
{
    WriterReturnOnError (WriteLong   (id));
    WriterReturnOnError (WriteShort  (valsPerVert));
    WriterReturnOnError (WriteString (name));

    for (LxULong i = 0; i < nVerts; ++i, verts += valsPerVert)
        {
        WriterReturnOnError (WriteIndex  (*vInds++));
        WriterReturnOnError (WriteIndex  (*pInds++));
        WriterReturnOnError (WriteFloats (verts, valsPerVert));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Points Chunk - Write out array of points - Z reversed in LightWave format
 *----------------------------------------------------------------------------*/
        LxResult
LxoPointsChunk::Write (LXtFVector* points, LxULong nPoints)
{
    for ( ; nPoints-- > 0; ++points)
        {
        WriterReturnOnError (WriteFloat ( points[0][0]));
        WriterReturnOnError (WriteFloat ( points[0][1]));
        WriterReturnOnError (WriteFloat (-points[0][2]));      // reverse Z for LightWave coord sys
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Points Chunk - Write out single position - Z reversed in LightWave format
 *----------------------------------------------------------------------------*/
        LxResult
LxoPointsChunk::Write (LXtFVector point)
{
    WriterReturnOnError (WriteFloat ( point[0]));
    WriterReturnOnError (WriteFloat ( point[1]));
    WriterReturnOnError (WriteFloat (-point[2]));      // reverse Z for LightWave coord sys

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Vector Chunk - Write out n-dimensional arrays
 *----------------------------------------------------------------------------*/
        LxResult
LxoVectorChunk::Write (LXtID4 id, char const* name, float* verts, LxULong nDims, LxULong nFloats)
{
    WriterReturnOnError (WriteLong   (id));
    WriterReturnOnError (WriteLong   (nDims));
    WriterReturnOnError (WriteString (name));
    WriterReturnOnError (WriteFloats (verts, nFloats * nDims));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Triangles Chunk - Write out triples of indices into the array of vertices
 *----------------------------------------------------------------------------*/
        LxResult
LxoTrianglesChunk::Write (LXtUVector* tris, LxULong nTris)
{
    WriterReturnOnError (WriteLongs ((LxULong*)tris, nTris * 3));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Envelope Chunk - Keys for animation
 *----------------------------------------------------------------------------*/
        LxResult
LxoEnvelopeChunk::Write (LxULong type, LxULong envelopeId)
{
    if (0 == envelopeId)
        envelopeId = ++(m_writer->m_envelopeId);        // if no ID passed in, use next one

    WriterReturnOnError (WriteIndex (envelopeId));
    WriterReturnOnError (WriteLong  (type));

    ReturnOnError (WriteData ());

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Envelope Chunk - Keys for animation
 *----------------------------------------------------------------------------*/
        LxResult
LxoEnvelopeChunk::Write (LxULong type, LxULong envelopeId, LxByte* data, LxULong bytes)
{
    if (0 == envelopeId)
        envelopeId = ++(m_writer->m_envelopeId);        // if no ID passed in, use next one

    WriterReturnOnError (WriteIndex (envelopeId));
    WriterReturnOnError (WriteLong  (type));
    WriterReturnOnError (WriteBytes (data, bytes));

    return CloseChunk ();
}

/*******************************************************************************
 *
 * The folowing methods are used for various types of item chunks
 *
 ******************************************************************************/

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Translation Chunk - apply translation to another chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoTranslationItemChunk::Write (LxULong linkId, LxULong linkIndex, LXtFVector translate, char const* name)
{
    char    xformName[512];

    if (name)
        sprintf (xformName, "%s"LXs_MODIFIER_TRANSLATION, name);
    else
        strcpy (xformName, LXs_MODIFIER_TRANSLATION);

    WriterReturnOnError (WriteItemHeader (LXsITYPE_TRANSLATION, xformName));

    ReturnOnError (LxoLinkSubChunk         (m_writer).Write (LXsGRAPH_XFRMCORE,        linkId, linkIndex));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TRANSFORM_TYPE,  "core"));
    ReturnOnError (LxoXyzChannelSubChunk   (m_writer).Write (LXsICHAN_TRANSLATION_POS, translate));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TRANSFORM_BLEND, 1.0f));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Rotation Chunk - apply rotation to another chunk, the 'order' string defines
 * the order in which the angles are applied, such as "yzx".
 *----------------------------------------------------------------------------*/
        LxResult
LxoRotationItemChunk::Write (LxULong linkId, LxULong linkIndex, LXtFVector angles, char const* name, char const* order)
{
    char    xformName[512];

    if (name)
        sprintf (xformName, "%s"LXs_MODIFIER_ROTATION, name);
    else
        strcpy (xformName, LXs_MODIFIER_ROTATION);

    WriterReturnOnError (WriteItemHeader (LXsITYPE_ROTATION, xformName));

    ReturnOnError (LxoLinkSubChunk         (m_writer).Write (LXsGRAPH_XFRMCORE,        linkId, linkIndex));   // link to the NEXT item
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TRANSFORM_BLEND, 1.0f));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TRANSFORM_TYPE,  "core"));
    ReturnOnError (LxoXyzChannelSubChunk   (m_writer).Write (LXsICHAN_ROTATION_ROT,    angles));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ROTATION_ORDER,  order ? order : "yzx"));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Scale Chunk - apply scale to another chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoScaleItemChunk::Write (LxULong linkId, LxULong linkIndex, LXtFVector scale, char const* name)
{
    char    xformName[512];

    if (name)
        sprintf (xformName, "%s"LXs_MODIFIER_SCALE, name);
    else
        strcpy (xformName, LXs_MODIFIER_SCALE);

    WriterReturnOnError (WriteItemHeader (LXsITYPE_SCALE, xformName));

    ReturnOnError (LxoLinkSubChunk         (m_writer).Write (LXsGRAPH_XFRMCORE,        linkId, linkIndex));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TRANSFORM_TYPE,  "core"));
    ReturnOnError (LxoXyzChannelSubChunk   (m_writer).Write (LXsICHAN_SCALE_SCL,       scale));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TRANSFORM_BLEND, 1.0f));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Surface Item Chunk - information about a surface
 *----------------------------------------------------------------------------*/
        LxResult
LxoSurfaceItemChunk::Write (LxULong layerId, LxULong parentId, LxULong parentIndex)
{
    char            meshName[512];

    sprintf (meshName, LXs_STATIC_MESH_NAME_TEMPLATE, m_writer->m_itemId + 1);      // this mesh will use the NEXT item ID

    WriterReturnOnError (WriteItemHeader (LXsITYPE_TRISURF, meshName));

    ReturnOnError (LxoLayerSubChunk (m_writer).Write (layerId, LXLayerFlag_Default, LXLayerColor_Default));

    if (parentId)
        ReturnOnError (LxoLinkSubChunk  (m_writer).Write (LXsGRAPH_PARENT, parentId, parentIndex));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Mesh Item Chunk - information about the current mesh
 *----------------------------------------------------------------------------*/
        LxResult
LxoMeshItemChunk::Write (LxULong layerIndex, char const* layerName, float radius)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_MESH, layerName));

    ReturnOnError (LxoLayerSubChunk          (m_writer).Write (layerIndex, LXLayerFlag_Default, LXLayerColor_Default));
    ReturnOnError (LxoChannelValueSubChunk   (m_writer).Write (LXsICHAN_MESH_RENDER_CURVES, LXInt_True));
    ReturnOnError (LxoChannelValueSubChunk   (m_writer).Write (LXsICHAN_MESH_CURVE_RADIUS,  radius));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Mesh Item Chunk - used for positioning replicators.  For ease of viewing in
 *                   the file, make this a child of the replicator.
 *----------------------------------------------------------------------------*/
        LxResult
LxoMeshItemChunk::Write (LxULong layerIndex, char const* layerName, LxULong replicatorIndex)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_MESH, layerName));

    ReturnOnError (LxoLayerSubChunk (m_writer).Write (layerIndex, LXLayerFlag_Default, LXLayerColor_Default));
    ReturnOnError (LxoLinkSubChunk  (m_writer).Write (LXsGRAPH_PARENT,   replicatorIndex, 0));
    ReturnOnError (LxoLinkSubChunk  (m_writer).Write (LXsGRAPH_PARTICLE, replicatorIndex, 0));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Mesh Instance Item Chunk - transformed instance of an existing mesh item
 *----------------------------------------------------------------------------*/
        LxResult
LxoReplicatorItemChunk::Write (LxULong linkItemId, char const* name)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_REPLICATOR, name));

    ReturnOnError (LxoLinkSubChunk (m_writer).Write (LXsGRAPH_PARTICLE, linkItemId, 0));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Scene Item Chunk - animation settings for the scene
 *----------------------------------------------------------------------------*/
        LxResult
LxoSceneItemChunk::Write ()
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_SCENE, ""));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_TIME,       0.f));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_SCENES,     0.f));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_SCENEE,     5.f));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_CURRENTS,   0.f));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_CURRENTE,   0.f));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_TIMESYS,      0));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_FPS,       24.f));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_SCENE_DRAWSIZE,   1.f));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Render Settings Chunk - top-level render settings
 *----------------------------------------------------------------------------*/
        LxResult
LxoPolyRenderItemChunk::Write (LXtRenderSettings& settings, LxULong cameraId, LxULong cameraIndex, bool useDefaults)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_POLYRENDER, ""));

    ReturnOnError (LxoLinkSubChunk          (m_writer).Write (LXsGRAPH_SHADELOC,                cameraId, cameraIndex));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_POLYRENDER_RESX,         (int)settings.m_resolution[0]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_POLYRENDER_RESY,         (int)settings.m_resolution[1]));
    ReturnOnError (LxoUniqueSubChunk        (m_writer).Write ("polyRender001"));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_GLOBENABLE,       (int)settings.m_flags.indirectIllumination));

    if (useDefaults)
        return CloseChunk ();

    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_RENDER_AMBCOLOR,         settings.m_ambColor));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_AMBRAD,           settings.m_ambLumens));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_POLYRENDER_FINERATE,     settings.m_refinementShadingRate));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_POLYRENDER_FINETHRESH,   settings.m_refinementThreshold));

    if (0 != settings.m_bucketSize)
        {
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_POLYRENDER_BUCKETX, settings.m_bucketSize));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_POLYRENDER_BUCKETY, settings.m_bucketSize));
        }

    static float const  s_minRayThreshold = 0.001f;

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_RAYTHRESH,        settings.m_rayThreshold < s_minRayThreshold ? s_minRayThreshold : settings.m_rayThreshold));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_RAYSHADOW,        (int)settings.m_flags.shadows));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_REFLDEPTH,        settings.m_flags.reflections  ? settings.m_reflectDepth : 0));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_REFRDEPTH,        settings.m_flags.transparency ? settings.m_refractDepth : 0));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_GLOBSUPER,        (int)settings.m_flags.indirectSuperSampling));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_GLOBRANGE,        settings.m_indirectRange));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_GLOBRAYS,         settings.m_indirectRays));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_GLOBLIMIT,        settings.m_indirectBounces));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_IRRRAYS,          settings.m_irradianceRays));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_IRRVALS,          settings.m_interpolationValues));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_IRRCACHE,         (int)settings.m_flags.irradianceCaching));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_IRRRATE,          settings.m_irradianceRate));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_IRRRATIO,         settings.m_irradianceRatio));

    static char*  s_renderIrrGradNames[]  = { LXsICVAL_RENDER_IRRGRADS_NONE, LXsICVAL_RENDER_IRRGRADS_ROTATION,    LXsICVAL_RENDER_IRRGRADS_TRANSLATION, LXsICVAL_RENDER_IRRGRADS_BOTH  };
    static char*  s_renderAAFilterNames[] = { LXsICVAL_RENDER_AAFILTER_BOX,  LXsICVAL_RENDER_AAFILTER_TRIANGLE,    LXsICVAL_RENDER_AAFILTER_GAUSSIAN                                    };
    static char*  s_renderCausticNames[]  = { LXsICVAL_RENDER_GLOBCAUS_NONE, LXsICVAL_RENDER_GLOBCAUS_REFLECTION,  LXsICVAL_RENDER_GLOBCAUS_REFRACTION,  LXsICVAL_RENDER_GLOBCAUS_BOTH  };
    static char*  s_renderSubSurfNames[]  = { LXsICVAL_RENDER_GLOBSUBS_NONE, LXsICVAL_RENDER_GLOBSUBS_GIAFFECTSSS, LXsICVAL_RENDER_GLOBSUBS_SSSAFFECTGI, LXsICVAL_RENDER_GLOBSUBS_BOTH  };

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_IRRGRADS,         s_renderIrrGradNames [settings.m_irradianceGradients]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_POLYRENDER_AAFILTER,     s_renderAAFilterNames[settings.m_antialiasingFilter]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_GLOBCAUS,         s_renderCausticNames [settings.m_indirectCaustics]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_GLOBSUBS,         s_renderSubSurfNames [settings.m_subsurfaceScattering]));

    char    aaString[20];
    sprintf (aaString, "s%d", settings.m_antialiasPowerOf2);
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_POLYRENDER_AA,           aaString));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_DISPENABLE,       (int)settings.m_flags.microPolyDisplacement));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_DISPRATE,         settings.m_displacementRate));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_DISPRATIO,        settings.m_displacementRatio));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_EDGEMIN,          settings.m_minimumEdgeLength));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_DISPSMOOTH,       (int)settings.m_flags.smoothPositions));

    if (settings.m_flags.directCaustics)
        {
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_CAUSENABLE,   LXInt_True));
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_CAUSTOTAL,    settings.m_totalPhotons));
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDER_CAUSLOCAL,    settings.m_localPhotons));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Render Output Settings Chunk - output settings
 *----------------------------------------------------------------------------*/
        LxResult
LxoRenderOutputItemChunk::Write (LXtRenderSettings& settings, char const* name, char const* effectName)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_RENDEROUTPUT, name));

    ReturnOnError (LxoLinkSubChunk          (m_writer).Write (LXsGRAPH_PARENT, m_writer->m_renderItemId, m_writer->m_renderItemIndex++));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELAYER_ENABLE,     LXInt_True));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_GAMMA,      settings.m_outputGamma));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_CLAMP,      LXInt_False));
    ReturnOnError (LxoNameStringSubChunk    (m_writer).Write (LXsICHAN_TEXTURELAYER_EFFECT,     effectName));

    if (LXOutput_AmbientOcclusion == settings.m_outputMode)
        {
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_RENDEROUTPUT_OCCLRAYS,    settings.m_occlusionRays));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_RENDEROUTPUT_OCCLRANGE,   settings.m_occlusionRange));
        }

    if (LXOutput_Depth == settings.m_outputMode)
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_DEPTHMAX,   settings.m_maxDepth));

    if (settings.m_flags.rawOutput) {
        // tell Modo to adapt to 1 l/m^2 so RGB values are output as *actual*, unscaled luminance values.
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_WHITE,      1.0f * s_lumensToRadiance));
        }
    else {
        // tell modo to apply 100% tonemapping
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_TONEAMT,    1.0f));
        }

    if (LXOutput_Rgba == settings.m_outputMode && settings.m_flags.bloom)
        {
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_BLOOM,      LXInt_True));
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_BLOOMTHR,   settings.m_bloomThreshold));
        ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_RENDEROUTPUT_BLOOMRAD,   settings.m_bloomRadius));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Environment Item Chunk - visibility of environment
 *----------------------------------------------------------------------------*/
        LxResult
LxoEnvironmentItemChunk::Write (LXtRenderSettings& settings)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_ENVIRONMENT, ""));

    if (settings.m_environment.m_radiance > 0.f)
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVIRONMENT_RADIANCE, settings.m_environment.m_radiance));

    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVIRONMENT_VISCAM,  (int)settings.m_environment.m_flags.visibleToCamera));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVIRONMENT_VISIND,  (int)settings.m_environment.m_flags.visibleToIndirect));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVIRONMENT_VISREFL, (int)settings.m_environment.m_flags.visibleToReflect));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVIRONMENT_VISREFR, (int)settings.m_environment.m_flags.visibleToRefract));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Sky Environment Item Chunk - data for the sky environment
 *----------------------------------------------------------------------------*/
        LxResult
LxoSkyEnvironmentItemChunk::Write (LxULong environmentId, LxULong environmentIndex, LxULong sunlightId, float solarDiskSize, char const* name, int skyCover, float weight)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_ENVMATERIAL, name));

    ReturnOnError (LxoLinkSubChunk         (m_writer).Write (LXsGRAPH_PARENT, environmentId, environmentIndex));
    ReturnOnError (LxoNameStringSubChunk   (m_writer).Write (LXsICHAN_TEXTURELAYER_EFFECT,   LXs_FX_ENVCOLOR));
    ReturnOnError (LxoLinkSubChunk         (m_writer).Write (LXsGRAPH_SHADELOC,              sunlightId, 0));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TEXTURELAYER_OPACITY,  weight));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_NORMALIZE, LXInt_False));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_DISC,      solarDiskSize));

    if (LXSkyCover_Clear == skyCover)
        {
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_TYPE,  LXsICVAL_ENVMATERIAL_ENVTYPE_PHYSICAL));
        }

    else        // overcast portion - solid color, except bottom is 1/3 top (emiprically from Modo)
        {
        // derived from RT chromaticity of zenith and horizon cloudy colors
        static LXtFVector const     s_overcastColor = { 0.90961039f, 0.89976817f, 1.0f };
        static float const          s_nadirScale = 1.0f / 3.0f;

        LXtFVector      zenithColor, nadirColor;
        LXx_VCPY  (zenithColor, s_overcastColor);
        LXx_VSCL3 (nadirColor, zenithColor, s_nadirScale);

        ReturnOnError (LxoRgbChannelSubChunk   (m_writer).Write (LXsICHAN_ENVMATERIAL_ZENCOLOR, zenithColor));
        ReturnOnError (LxoRgbChannelSubChunk   (m_writer).Write (LXsICHAN_ENVMATERIAL_NADCOLOR, nadirColor));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_TYPE,     LXsICVAL_ENVMATERIAL_ENVTYPE_OVERCAST));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Body of any Environment Gradient Item Chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoGradientEnvironmentItemChunk::WriteBody (LxULong environmentId, LxULong environmentIndex, LXtFVector zenithColor, LXtFVector nadirColor)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_ENVMATERIAL, "Gradient"));

    ReturnOnError (LxoLinkSubChunk         (m_writer).Write (LXsGRAPH_PARENT, environmentId, environmentIndex));
    ReturnOnError (LxoNameStringSubChunk   (m_writer).Write (LXsICHAN_TEXTURELAYER_EFFECT,   LXs_FX_ENVCOLOR));

    ReturnOnError (LxoRgbChannelSubChunk   (m_writer).Write (LXsICHAN_ENVMATERIAL_ZENCOLOR,  zenithColor));
    ReturnOnError (LxoRgbChannelSubChunk   (m_writer).Write (LXsICHAN_ENVMATERIAL_NADCOLOR,  nadirColor));

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Two Color Gradient Environment Item Chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoGradientEnvironmentItemChunk::Write (LxULong environmentId, LxULong environmentIndex, LXtFVector zenithColor, LXtFVector nadirColor)
{
    ReturnOnError (WriteBody (environmentId, environmentIndex, zenithColor, nadirColor));

    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_TYPE, LXsICVAL_ENVMATERIAL_ENVTYPE_GRAD2));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Four Color Gradient Environment Item Chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoGradientEnvironmentItemChunk::Write (LxULong environmentId, LxULong environmentIndex, LXtFVector zenithColor, LXtFVector nadirColor, LXtFVector skyColor, LXtFVector groundColor, float skyExp, float groundExp)
{
    ReturnOnError (WriteBody (environmentId, environmentIndex, zenithColor, nadirColor));

    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_TYPE,     LXsICVAL_ENVMATERIAL_ENVTYPE_GRAD4));

    ReturnOnError (LxoRgbChannelSubChunk   (m_writer).Write (LXsICHAN_ENVMATERIAL_SKYCOLOR, skyColor));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_SKYEXP,   skyExp));
    ReturnOnError (LxoRgbChannelSubChunk   (m_writer).Write (LXsICHAN_ENVMATERIAL_GNDCOLOR, groundColor));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ENVMATERIAL_GNDEXP,   groundExp));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Camera Chunk - camera info
 *----------------------------------------------------------------------------*/
        LxResult
LxoCameraItemChunk::Write (LXtCamera& camera, char const* name)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_CAMERA, name));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_PROJTYPE,     s_cameraTypeNames[camera.projectMode]));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_FOCALLEN,     camera.focalLength));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_FOCUSDIST,    camera.focalDistance));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_OFFSETX,      camera.offset[0]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_OFFSETY,      camera.offset[1]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_FSTOP,        camera.fstop));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_APERTUREX,    camera.filmWidth));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_APERTUREY,    camera.filmHeight));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_CAMERA_DISTORT,      camera.lensDistortion));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Shader Chunk - shading attributes of an item
 *----------------------------------------------------------------------------*/
        LxResult
LxoShaderItemChunk::Write (char const* name, LxULong parentId, LxULong parentIndex, LXpShadeFlags* shader)
{
    static char*  s_indirectTypeNames[] = { "none", "mc",  "ic" };

    WriterReturnOnError (WriteItemHeader (LXsITYPE_DEFAULTSHADER, name));

    ReturnOnError (LxoLinkSubChunk          (m_writer).Write (LXsGRAPH_PARENT,                  parentId, parentIndex));

    if (NULL == shader)
        return CloseChunk ();

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELAYER_ENABLE,     LXInt_True));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELAYER_OPACITY,    1.0f));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELAYER_BLEND,      LXsICVAL_TEXTURELAYER_BLEND_NORMAL));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELAYER_INVERT,     LXInt_False));
    ReturnOnError (LxoNameStringSubChunk    (m_writer).Write (LXsICHAN_TEXTURELAYER_EFFECT,     LXs_FX_SHADER_FULL_SHADING));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_SHADERATE, shader->shadeRate));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_DIRMULT,   shader->dirMult));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_INDMULT,   shader->indMult));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_INDSAT,    shader->indSat));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_INDTYPE,   s_indirectTypeNames[shader->indType]));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_SHADCAST,  0 != (shader->flags & LXfSURF_SHADCAST)));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_SHADRECV,  0 != (shader->flags & LXfSURF_SHADRECV)));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_VISIND,    0 != (shader->flags & LXfSURF_VISIND)));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_VISCAM,    0 != (shader->flags & LXfSURF_VISCAM)));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_VISREFL,   0 != (shader->flags & LXfSURF_VISREFL)));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_DEFAULTSHADER_VISREFR,   0 != (shader->flags & LXfSURF_VISREFR)));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Video Still Chunk - identifies image file on disk
 *----------------------------------------------------------------------------*/
        LxResult
LxoVideostillItemChunk::Write (char const* name)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_VIDEOSTILL, ""));

    ReturnOnError (LxoNameStringSubChunk    (m_writer).Write (LXsICHAN_VIDEOSTILL_FILENAME, name));

    /*
     * Need to get the format of the image file; find the file extension by finding the
     * last '.' then use an uppercase copy of the extension for the format.
     */

    char const*     fileExtP = strrchr (name, '.');

    if (fileExtP)
        {
        char    ext[10];
        char*   extP = ext;
        char*   endP = ext + sizeof ext - 1;

        for (++fileExtP; *fileExtP && extP < endP; )
            *extP++ = toupper (*fileExtP++);
        *extP = '\0';

        ReturnOnError (LxoNameStringSubChunk    (m_writer).Write (LXsICHAN_VIDEOSTILL_FORMAT, ext));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Texture Locator Chunk - defines the mapping type for a texure
 *----------------------------------------------------------------------------*/
        LxResult
LxoTextureLocatorItemChunk::Write (int tileModeU, int tileModeV, int projectMode, char const* uvMapName)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_TEXTURELOC, ""));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELOC_PROJTYPE, s_projectionNames[projectMode]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELOC_TILEU,    s_tileModeNames[tileModeU]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELOC_TILEV,    s_tileModeNames[tileModeV]));

    if (LXProjection_Uv == projectMode)
        ReturnOnError (LxoNameStringSubChunk (m_writer).Write (LXsICHAN_TEXTURELOC_UVMAP,   uvMapName));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Image Map Chunk - associates texture locators & video stills with a material
 *----------------------------------------------------------------------------*/
        LxResult
LxoImageMapItemChunk::Write (LXtMaterialLayer& layer, LxULong maskId, LxULong maskIndex, LxULong textureLocatorId)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_IMAGEMAP, ""));

    ReturnOnError (LxoLinkSubChunk (m_writer).Write (LXsGRAPH_PARENT,   maskId, maskIndex));
    ReturnOnError (LxoLinkSubChunk (m_writer).Write (LXsGRAPH_SHADELOC, textureLocatorId, 0));
    ReturnOnError (LxoLinkSubChunk (m_writer).Write (LXsGRAPH_SHADELOC, layer.m_videoStillId, 0));

    ReturnOnError (LxoNameStringSubChunk (m_writer).Write   (LXsICHAN_TEXTURELAYER_EFFECT,  s_materialMapNames[layer.m_type]));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TEXTURELAYER_OPACITY, layer.m_opacity));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TEXTURELAYER_INVERT,  layer.m_invert));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_TEXTURELAYER_BLEND,   s_blendNames[layer.m_blendType]));

    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_IMAGEMAP_MIN,         layer.m_minValue));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_IMAGEMAP_MAX,         layer.m_maxValue));
    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_IMAGEMAP_ALPHA,       s_alphaModeNames[layer.m_alphaType]));

    if (layer.m_invertRGB)
        {
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_IMAGEMAP_REDINV,      LXInt_True));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_IMAGEMAP_GREENINV,    LXInt_True));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_IMAGEMAP_BLUEINV,     LXInt_True));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Constant Color Chunk - used as a layer of a material
 *----------------------------------------------------------------------------*/
        LxResult
LxoConstantColorItemChunk::Write (LxULong linkId, LxULong linkIndex, LXtFVector color, int mapType, int blendType, float opacity, LxULong alphaMapId)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_CONSTANT, ""));

    ReturnOnError (LxoLinkSubChunk          (m_writer).Write (LXsGRAPH_PARENT,                  linkId, linkIndex));
    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_CONSTANT_COLOR,          color));
    ReturnOnError (LxoNameStringSubChunk    (m_writer).Write (LXsICHAN_TEXTURELAYER_EFFECT,     s_materialMapNames[mapType]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELAYER_BLEND,      s_blendNames[blendType]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_TEXTURELAYER_OPACITY,    opacity));

    if (alphaMapId)
        ReturnOnError (LxoLinkSubChunk      (m_writer).Write (LXsGRAPH_SHADELOC,                alphaMapId, 0));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Material Mask Chunk - associates material with render element
 *----------------------------------------------------------------------------*/
        LxResult
LxoMaskItemChunk::Write (char const* name, LxULong parentId, LxULong parentIndex, char const* partType)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_MASK, name));

    ReturnOnError (LxoLinkSubChunk       (m_writer).Write (LXsGRAPH_PARENT,              parentId, parentIndex));
    ReturnOnError (LxoNameStringSubChunk (m_writer).Write (LXsICHAN_MASK_PTAG,           name));
    ReturnOnError (LxoNameStringSubChunk (m_writer).Write (LXsICHAN_MASK_PTYP,           partType ? partType : "Material"));
    ReturnOnError (LxoNameStringSubChunk (m_writer).Write (LXsICHAN_TEXTURELAYER_EFFECT, ""));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Material Item Chunk - material data
 *----------------------------------------------------------------------------*/
        LxResult
LxoMaterialItemChunk::Write (LXtMaterial& material, LxULong maskId, LxULong maskIndex)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_ADVANCEDMATERIAL, material.m_name));

    ReturnOnError (LxoLinkSubChunk          (m_writer).Write (LXsGRAPH_PARENT,                      maskId, maskIndex));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_DBLSIDED,   (int)material.m_smoothing.dblSided));

    if (material.m_param.flags & LXfSURF_PHYSICAL)
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_PHYSICAL, LXInt_True));

    // diffuse
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_DIFFAMT,    material.m_param.diffAmt));
    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_DIFFCOL,    material.m_param.diffCol));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_BUMP,       material.m_param.bumpAmt));

    // specular
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SPECAMT,    material.m_param.specAmt));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SPECFRES,   material.m_param.specFres));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_ROUGH,      material.m_param.rough));
    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SPECCOL,    material.m_param.specCol));

    // reflection
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_REFLAMT,    material.m_param.reflAmt));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_REFLFRES,   material.m_param.reflFres));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_REFLRAYS,   material.m_param.reflRays));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_COATAMT,    material.m_param.coatAmt));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_REFLTYPE,   material.m_param.reflType));
    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_REFLCOL,    material.m_param.reflCol));

    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_ANISO,      material.m_param.aniso));

    if (material.m_param.flags & LXfSURF_REFLBLUR)
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_REFLBLUR, LXInt_True));

    // transparency
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_TRANAMT,    material.m_param.tranAmt));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_REFINDEX,   material.m_param.refIndex));
    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_TRANCOL,    material.m_param.tranCol));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_TRANRAYS,   material.m_param.tranRays));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_TRANROUGH,  material.m_param.tranRough));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_TRANDIST,   material.m_param.tranDist));

    // translucency - for simple translucency, set subsDist to 0
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SUBSAMT,    material.m_param.subsAmt));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SUBSDIST,   material.m_param.subsDist));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_DISPERSE,   material.m_param.disperse));
    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SUBSCOL,    material.m_param.subsCol));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SUBSSMPS,   material.m_param.subsRays));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SUBSPHASE,  material.m_param.subsPhase));

    if (material.m_param.flags & LXfSURF_SAMESURF)
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_SAMESURF, LXInt_True));

    // glow
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_RADIANCE,   material.m_param.lumiAmt * s_lumensToRadiance));
    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_LUMICOL,    material.m_param.lumiCol));

    ReturnOnError (LxoRgbChannelSubChunk    (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_EXITCOL,    material.m_param.exitCol));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_LOCATOR_DISSOLVE,            material.m_param.dissAmt));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_ADVANCEDMATERIAL_DISPLACE,   material.m_displacement.dist));     // in mm

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 05/09
 * Fur Material Item Chunk -fur  material data
 *----------------------------------------------------------------------------*/
        LxResult
LxoFurMaterialItemChunk::Write (LXpFurParms& fur, char const* name, LxULong maskId, LxULong maskIndex)
{
    static char     furName[512];

    sprintf (furName, "%s_Fur", name);

    WriterReturnOnError (WriteItemHeader (LXsITYPE_FURMATERIAL, furName));

    ReturnOnError (LxoLinkSubChunk          (m_writer).Write (LXsGRAPH_PARENT,                      maskId, maskIndex));


    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_DIST,            fur.minDist));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_LENGTH,          fur.length));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_WIDTH,           fur.width));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_FLEX,            fur.flex));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_GROWTHJITTER,    fur.grwJitter));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_POSJITTER,       fur.posJitter));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_SCLJITTER,       fur.sclJitter));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_NRMJITTER,       fur.nrmJitter));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_MAXSEGMENT,      fur.maxSegment));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_BUMPAMP,         fur.bumpAmp));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_DENSITY,         fur.density));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_DISPLAY,         fur.display));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_CURLS,           fur.curles));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_CLUMPS,          fur.clumps));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_CLUMPSIZE,       fur.clumpSize));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_TAPER,           fur.taper));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_TYPE,            s_furTypeNames[fur.type]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_ADAPTIVE,        fur.adaptive));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_FURONLY,         fur.furOnly));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_GUIDES,          s_furGuideNames[fur.guides]));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_TANSHADE,        fur.tgtShade));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_GUIDERANGE,      fur.guideSize));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_GUIDELENGTH,     fur.guideLen));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_ROOTBEND,        fur.rootBend));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_STRIPROT,        fur.stripRot));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_YOFFSET,         fur.yOffset));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_RATE,            fur.rate));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_ANGLE,           fur.blendAngle));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_GUIDEBLEND,      fur.blendAmount));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_SEED,            fur.randomSeed));
    ReturnOnError (LxoChannelValueSubChunk  (m_writer).Write (LXsICHAN_FURMATERIAL_AUTOFADE,        fur.autoFade));

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Light Material Item Chunk - color & effects information for a light
 *----------------------------------------------------------------------------*/
        LxResult
LxoLightMaterialItemChunk::Write (char const* name, LXtLightInfo& light)
{
    WriterReturnOnError (WriteItemHeader (LXsITYPE_LIGHTMATERIAL, name));

    ReturnOnError (LxoLinkSubChunk       (m_writer).Write (LXsGRAPH_PARENT, m_writer->m_itemId + 1, 0));   // link to the NEXT item
    ReturnOnError (LxoNameStringSubChunk (m_writer).Write (LXsICHAN_TEXTURELAYER_EFFECT, ""));
    ReturnOnError (LxoRgbChannelSubChunk (m_writer).Write (LXsICHAN_LIGHTMATERIAL_LIGHTCOL, light.color));

    if (light.flags.volumetric)
        {
        ReturnOnError (LxoRgbChannelSubChunk   (m_writer).Write (LXsICHAN_LIGHTMATERIAL_SCATCOL,    light.volume.scatter));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHTMATERIAL_SCATTER,    light.volume.scatterAmt));

        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHTMATERIAL_DENSITY,    light.volumeDensity.density));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHTMATERIAL_ATTENUATE,  light.volume.attenuate));
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHTMATERIAL_SHIFT,      light.volume.shift));
        }

    return CloseChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 04/09
 * Light Item Chunk - light position, direction, etc.
 *----------------------------------------------------------------------------*/
        LxResult
LxoLightItemChunk::Write (LXtLightInfo& light)
{
    WriterReturnOnError (WriteItemHeader (s_lightTypeNames[light.type], light.name));

    ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHT_RADIANCE, light.lumens * s_lumensToRadiance));

    switch (light.type)
        {
        case LXLightType_Spot:
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_CONE,   light.coneAngle));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_EDGE,   light.edgeAngle));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_RADIUS, 1 == light.samples ? 0.0f : light.radius));

            if (light.flags.volumetric)
                {
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_VOLUMETRICS, LXInt_True));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_VSAMPLES,    light.volumeSamples));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_BASE,        light.volumeBase));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_HEIGHT,      light.volumeHeight));
                }
            break;

        case LXLightType_Point:
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_CONE,    s_twoPi));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_EDGE,    0.f));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_POINTLIGHT_RADIUS, 1 == light.samples ? 0.0f : light.radius));

            if (light.flags.volumetric)
                {
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_POINTLIGHT_VOLUMETRICS, LXInt_True));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_POINTLIGHT_VSAMPLES,    light.volumeSamples));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_POINTLIGHT_VRAD,        light.volumeRadius));
                }
            break;

        case LXLightType_Area:
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_CONE,   s_twoPi));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SPOTLIGHT_EDGE,   0.f));

            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_AREALIGHT_WIDTH,  light.areaWidth));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_AREALIGHT_HEIGHT, light.areaHeight));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHT_FAST,       LXInt_False));          // disable "simple shading"
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LOCATOR_RENDER,   LXInt_True));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LOCATOR_VISIBLE,  (int)light.flags.visible));
            break;

        case LXLightType_Cylinder:
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_CYLINDERLIGHT_RADIUS, light.radius));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_CYLINDERLIGHT_LENGTH, light.length));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHT_FAST,           LXInt_False));      // disable "simple shading"
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHT_SAMPLES,        light.samples));
            break;

        case LXLightType_Dome:
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHT_SAMPLES,    light.samples));
            break;

        case LXLightType_SunPhysical:
        case LXLightType_Sun:
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_SUNPOS,   LXInt_False));        // only set the direction for sky colors
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_CLAMP,    LXInt_False));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_LON,      light.longitude));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_LAT,      light.latitude));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_TIME,     light.timeHours));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_DAY,      (float)(light.year * 1000 + light.dayOfYear)));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_TIMEZONE, light.timeZone));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_NORTH,    light.north));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_HAZE,     light.haze));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_SUNPOS,   LXLightType_SunPhysical == light.type));

            // fall through to other directional parameters

        case LXLightType_Directional:
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_SPREAD,   1 == light.samples ? 0.0f : 1.0f * s_degreesToRads));   // 1 degree spread

            if (light.flags.volumetric)
                {
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_VOLUMETRICS, LXInt_True));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_VSAMPLES,    light.volumeSamples));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_RADIUS,      light.volumeRadius));
                ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_SUNLIGHT_HEIGHT,      light.volumeHeight));
                }
            break;
        }

    if (light.iesFile[0])
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_PHOTOMETRYLIGHT_FILENAME, light.iesFile));

    if (! light.flags.castShadows)
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHT_SHADTYPE, LXsICVAL_LIGHT_SHADTYPE_NONE));

    else if (LXLightType_Dome != light.type && LXLightType_Cylinder != light.type)
        {
        ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_LIGHT_SAMPLES, light.samples));

        // for non-IES, non-area lights, define the area size for soft shadows by the bulb diameter
        if (light.samples > 1 && '\0' != light.iesFile[0] && LXLightType_Area != light.type)
            {
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_AREALIGHT_WIDTH,  2.0f * light.radius));
            ReturnOnError (LxoChannelValueSubChunk (m_writer).Write (LXsICHAN_AREALIGHT_HEIGHT, 2.0f * light.radius));
            }
        }

    return CloseChunk ();
}


