/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_registrar.h"
#include "cio_schema.h"
#include "cio_profiles.h"

#include <lxidef.h>

using namespace std;

namespace cio {

ElementParamRegistrar::ElementParamRegistrar (
        ElementParamBind &bind)
        :
        elementParamBind(bind)
{
        RegisterParameters ();
}

ElementParamRegistrar::~ElementParamRegistrar ()
{
}

/*
 * Register targetable parameters for each parent element name.
 */
        void
ElementParamRegistrar::RegisterParameters ()
{
        RegisterCameraParameters ();
        RegisterLightParameters ();
        RegisterMeshParameters ();

        RegisterRenderParameters ();

        RegisterEnvironmentParameters ();
        RegisterEnvironmentMaterialParameters ();
}

        void
ElementParamRegistrar::RegisterParameter (
        const std::string	&parentElementName,
        const std::string	&elementName,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        elementParamBind.AddElementParam (
                ElementParam (parentElementName,
                        elementName, paramSID, paramName, paramType));
}

/*
 * Camera parameter registration.
 */

        void
ElementParamRegistrar::RegisterCameraParameters ()
{
        RegisterCameraParameter (
                PARAM_MODO_LOCATOR_DISPLAY_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE_NAME);
        RegisterCameraParameter (
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE_NAME,
                PARAM_TYPE_NAME);

        /*
         * Imager parameters.
         */
        RegisterCameraImagerParameter (
                PARAM_MODO_CAMERA_APERTURE_WIDTH,
                PARAM_MODO_CAMERA_APERTURE_WIDTH_NAME);

        RegisterCameraImagerParameter (
                PARAM_MODO_CAMERA_APERTURE_HEIGHT,
                PARAM_MODO_CAMERA_APERTURE_HEIGHT_NAME);

        RegisterCameraImagerParameter (
                PARAM_MODO_CAMERA_OFFSET_X,
                PARAM_MODO_CAMERA_OFFSET_X_NAME);

        RegisterCameraImagerParameter (
                PARAM_MODO_CAMERA_OFFSET_Y,
                PARAM_MODO_CAMERA_OFFSET_Y_NAME);

        RegisterCameraImagerParameter (
                PARAM_MODO_CAMERA_FILM_FIT,
                PARAM_MODO_CAMERA_FILM_FIT_NAME,
                PARAM_TYPE_NAME);

        /*
         * Optics common parameters.
         */
        RegisterCameraOpticsCommon (
                ELEMENT_XFOV, PARAM_XFOV, PARAM_XFOV_NAME);

        RegisterCameraOpticsCommon (
                ELEMENT_YFOV, PARAM_YFOV, PARAM_YFOV_NAME);

        RegisterCameraOpticsCommon (
                ELEMENT_YFOV, PARAM_YFOV, PARAM_YFOV_NAME);

        RegisterCameraOpticsCommon (
                ELEMENT_ASPECT_RATIO, PARAM_ASPECT_RATIO, PARAM_ASPECT_RATIO_NAME);

        RegisterCameraOpticsCommon (
                ELEMENT_ZNEAR, PARAM_ZNEAR, PARAM_ZNEAR_NAME);

        RegisterCameraOpticsCommon (
                ELEMENT_ZFAR, PARAM_ZFAR, PARAM_ZFAR_NAME);

        /*
         * Optics profile modo 401 parameters.
         */
        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_BLUR_LENGTH,
                PARAM_MODO_CAMERA_BLUR_LENGTH_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_BLUR_OFFSET,
                PARAM_MODO_CAMERA_BLUR_OFFSET_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE,
                PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_FOCAL_LENGTH,
                PARAM_MODO_CAMERA_FOCAL_LENGTH_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_FOCUS_DISTANCE,
                PARAM_MODO_CAMERA_FOCUS_DISTANCE_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_F_STOP,
                PARAM_MODO_CAMERA_F_STOP_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE,
                PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_LENS_DISTORTION,
                PARAM_MODO_CAMERA_LENS_DISTORTION_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_LENS_SQUEEZE,
                PARAM_MODO_CAMERA_LENS_SQUEEZE_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_PROJECTION,
                PARAM_MODO_CAMERA_PROJECTION_NAME,
                PARAM_TYPE_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_DEPTH_OF_FIELD,
                PARAM_MODO_CAMERA_DEPTH_OF_FIELD_NAME,
                PARAM_TYPE_BOOL);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_MOTION_BLUR,
                PARAM_MODO_CAMERA_MOTION_BLUR_NAME,
                PARAM_TYPE_BOOL);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_STEREOSCOPIC,
                PARAM_MODO_CAMERA_STEREOSCOPIC_NAME,
                PARAM_TYPE_BOOL);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_TARGET_ENABLE,
                PARAM_MODO_TARGET_ENABLE_NAME,
                PARAM_TYPE_BOOL);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_TARGET_NODE_ID,
                PARAM_MODO_TARGET_NODE_ID_NAME,
                PARAM_TYPE_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_TARGET_SET_FOCUS,
                PARAM_MODO_TARGET_SET_FOCUS_NAME,
                PARAM_TYPE_BOOL);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_CAMERA_TARGET_DISTANCE,
                PARAM_MODO_CAMERA_TARGET_DISTANCE_NAME);

        RegisterCameraOpticsProfile_modo401 (
                PARAM_MODO_TARGET_ROLL,
                PARAM_MODO_TARGET_ROLL_NAME);
}

        void
ElementParamRegistrar::RegisterCameraParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                ELEMENT_CAMERA, ELEMENT_PARAM, paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterCameraImagerParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                ELEMENT_IMAGER, ELEMENT_PARAM, paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterCameraOpticsCommon (
        const std::string	&elementName,
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                ELEMENT_OPTICS, elementName, paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterCameraOpticsProfile_modo401 (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                ELEMENT_OPTICS, ELEMENT_PARAM, paramSID, paramName, paramType);
}
/*
 * Light parameter registration.
 */

        void
ElementParamRegistrar::RegisterLightParameters ()
{
        RegisterAreaLightParameters ();
        RegisterCylinderLightParameters ();
        RegisterDomeLightParameters ();
        RegisterPhotometricLightParameters ();
        RegisterPointLightParameters ();
        RegisterSpotLightParameters ();
        RegisterSunLightParameters ();
}

        void
ElementParamRegistrar::RegisterLightLocatorParameters (
        const std::string	&parentElementName)
{
        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE_NAME);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LOCATOR_DISSOLVE,
                PARAM_MODO_LOCATOR_DISSOLVE_NAME);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LOCATOR_RENDER,
                PARAM_MODO_LOCATOR_RENDER_NAME,
                PARAM_TYPE_NAME);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE_NAME,
                PARAM_TYPE_NAME);
}

        void
ElementParamRegistrar::RegisterLightCommonParameters (
        const string	&parentElementName)
{
        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LIGHT_TYPE,
                PARAM_MODO_LIGHT_TYPE_NAME,
                PARAM_TYPE_NAME);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LIGHT_RADIANCE,
                PARAM_MODO_LIGHT_RADIANCE_NAME);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LIGHT_SAMPLES,
                PARAM_MODO_LIGHT_SAMPLES_NAME,
                PARAM_TYPE_INT);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LIGHT_SHADOW_TYPE,
                PARAM_MODO_LIGHT_SHADOW_TYPE_NAME,
                PARAM_TYPE_NAME);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LIGHT_SHADOW_RESOLUTION,
                PARAM_MODO_LIGHT_SHADOW_RESOLUTION_NAME,
                PARAM_TYPE_INT);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_LIGHT_SIMPLE_SHADING,
                PARAM_MODO_LIGHT_SIMPLE_SHADING_NAME,
                PARAM_TYPE_BOOL);
}

        void
ElementParamRegistrar::RegisterLightTargetParameters (
        const std::string	&parentElementName)
{
        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_TARGET_ENABLE,
                PARAM_MODO_TARGET_ENABLE_NAME,
                PARAM_TYPE_BOOL);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_TARGET_NODE_ID,
                PARAM_MODO_TARGET_NODE_ID_NAME,
                PARAM_TYPE_NAME);

        RegisterParameter (parentElementName, ELEMENT_PARAM,
                PARAM_MODO_TARGET_ROLL,
                PARAM_MODO_TARGET_ROLL_NAME);
}

        void
ElementParamRegistrar::RegisterAreaLightParameters ()
{
        RegisterLightLocatorParameters (VIRTUAL_ELEMENT_AREA_LIGHT);
        RegisterLightCommonParameters (VIRTUAL_ELEMENT_AREA_LIGHT);
        RegisterLightTargetParameters (VIRTUAL_ELEMENT_AREA_LIGHT);

        RegisterAreaLightParameter (
                PARAM_MODO_AREALIGHT_HEIGHT,
                PARAM_MODO_AREALIGHT_HEIGHT_NAME);

        RegisterAreaLightParameter (
                PARAM_MODO_AREALIGHT_SHAPE,
                PARAM_MODO_AREALIGHT_SHAPE_NAME,
                PARAM_TYPE_INT);

        RegisterAreaLightParameter (
                PARAM_MODO_AREALIGHT_WIDTH,
                PARAM_MODO_AREALIGHT_WIDTH_NAME);
}

        void
ElementParamRegistrar::RegisterAreaLightParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_AREA_LIGHT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterCylinderLightParameters ()
{
        RegisterLightLocatorParameters (VIRTUAL_ELEMENT_CYLINDER_LIGHT);
        RegisterLightCommonParameters (VIRTUAL_ELEMENT_CYLINDER_LIGHT);
        RegisterLightTargetParameters (VIRTUAL_ELEMENT_CYLINDER_LIGHT);

        RegisterCylinderLightParameter (
                PARAM_MODO_CYLINDERLIGHT_LENGTH,
                PARAM_MODO_CYLINDERLIGHT_LENGTH_NAME);

        RegisterCylinderLightParameter (
                PARAM_MODO_CYLINDERLIGHT_RADIUS,
                PARAM_MODO_CYLINDERLIGHT_RADIUS_NAME);
}

        void
ElementParamRegistrar::RegisterCylinderLightParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_CYLINDER_LIGHT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterDomeLightParameters ()
{
        RegisterLightLocatorParameters (VIRTUAL_ELEMENT_DOME_LIGHT);
        RegisterLightCommonParameters (VIRTUAL_ELEMENT_DOME_LIGHT);

        RegisterDomeLightParameter (
                PARAM_MODO_DOMELIGHT_RADIUS,
                PARAM_MODO_DOMELIGHT_RADIUS_NAME);
}

        void
ElementParamRegistrar::RegisterDomeLightParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_DOME_LIGHT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterPhotometricLightParameters ()
{
        RegisterLightLocatorParameters (VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT);
        RegisterLightCommonParameters (VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT);
        RegisterLightTargetParameters (VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_CONE_ANGLE,
                PARAM_MODO_PHOTOMETRICLIGHT_CONE_ANGLE_NAME);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_SOFT_EDGE_ANGLE,
                PARAM_MODO_PHOTOMETRICLIGHT_SOFT_EDGE_ANGLE_NAME);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_HEIGHT,
                PARAM_MODO_PHOTOMETRICLIGHT_HEIGHT_NAME);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_OUTSIDE,
                PARAM_MODO_PHOTOMETRICLIGHT_OUTSIDE_NAME,
                PARAM_TYPE_BOOL);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_V_DISSOLVE,
                PARAM_MODO_PHOTOMETRICLIGHT_V_DISSOLVE_NAME);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_VOLUMETRICS,
                PARAM_MODO_PHOTOMETRICLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_V_SAMPLES,
                PARAM_MODO_PHOTOMETRICLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_V_RAD,
                PARAM_MODO_PHOTOMETRICLIGHT_V_RAD_NAME);

        RegisterPhotometricLightParameters (
                PARAM_MODO_PHOTOMETRICLIGHT_WIDTH,
                PARAM_MODO_PHOTOMETRICLIGHT_WIDTH_NAME);
}

        void
ElementParamRegistrar::RegisterPhotometricLightParameters (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterPointLightParameters ()
{
        RegisterLightLocatorParameters (ELEMENT_POINT);
        RegisterLightCommonParameters (ELEMENT_POINT);

        RegisterPointLightParameter (
                PARAM_MODO_POINTLIGHT_RADIUS,
                PARAM_MODO_POINTLIGHT_RADIUS_NAME);

        RegisterPointLightParameter (
                PARAM_MODO_POINTLIGHT_V_DISSOLVE,
                PARAM_MODO_POINTLIGHT_V_DISSOLVE_NAME);

        RegisterPointLightParameter (
                PARAM_MODO_POINTLIGHT_VOLUMETRICS,
                PARAM_MODO_POINTLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);

        RegisterPointLightParameter (
                PARAM_MODO_POINTLIGHT_V_SAMPLES,
                PARAM_MODO_POINTLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);

        RegisterPointLightParameter (
                PARAM_MODO_POINTLIGHT_V_RAD,
                PARAM_MODO_POINTLIGHT_V_RAD_NAME);
}

        void
ElementParamRegistrar::RegisterPointLightParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                ELEMENT_POINT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterSpotLightParameters ()
{
        RegisterLightLocatorParameters (ELEMENT_SPOT);
        RegisterLightCommonParameters (ELEMENT_SPOT);
        RegisterLightTargetParameters (ELEMENT_SPOT);

        RegisterSpotLightParameter (
                PARAM_MODO_SPOTLIGHT_CONE_ANGLE,
                PARAM_MODO_SPOTLIGHT_CONE_ANGLE_NAME);

        RegisterSpotLightParameter (
                PARAM_MODO_SPOTLIGHT_SOFT_EDGE_ANGLE,
                PARAM_MODO_SPOTLIGHT_SOFT_EDGE_ANGLE_NAME);

        RegisterSpotLightParameter (
                PARAM_MODO_SPOTLIGHT_OUTSIDE,
                PARAM_MODO_SPOTLIGHT_OUTSIDE_NAME,
                PARAM_TYPE_BOOL);

        RegisterSpotLightParameter (
                PARAM_MODO_SPOTLIGHT_RADIUS,
                PARAM_MODO_SPOTLIGHT_RADIUS_NAME);

        RegisterSpotLightParameter (
                PARAM_MODO_SPOTLIGHT_V_DISSOLVE,
                PARAM_MODO_SPOTLIGHT_V_DISSOLVE_NAME);

        RegisterSpotLightParameter (
                PARAM_MODO_SPOTLIGHT_VOLUMETRICS,
                PARAM_MODO_SPOTLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);

        RegisterSpotLightParameter (
                PARAM_MODO_SPOTLIGHT_V_SAMPLES,
                PARAM_MODO_SPOTLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);
}

        void
ElementParamRegistrar::RegisterSpotLightParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                ELEMENT_SPOT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

        void
ElementParamRegistrar::RegisterSunLightParameters ()
{
        RegisterLightLocatorParameters (VIRTUAL_ELEMENT_SUN_LIGHT);
        RegisterLightCommonParameters (VIRTUAL_ELEMENT_SUN_LIGHT);
        RegisterLightTargetParameters (VIRTUAL_ELEMENT_SUN_LIGHT);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_AZIMUTH,
                PARAM_MODO_SUNLIGHT_AZIMUTH_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_CLAMP_INTENSITY,
                PARAM_MODO_SUNLIGHT_CLAMP_INTENSITY_NAME,
                PARAM_TYPE_BOOL);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_DAY,
                PARAM_MODO_SUNLIGHT_DAY_NAME,
                PARAM_TYPE_INT);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_ELEVATION,
                PARAM_MODO_SUNLIGHT_ELEVATION_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_HAZE,
                PARAM_MODO_SUNLIGHT_HAZE_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_HEIGHT,
                PARAM_MODO_SUNLIGHT_HEIGHT_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_LATITUDE,
                PARAM_MODO_SUNLIGHT_LATITUDE_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_LONGITUDE,
                PARAM_MODO_SUNLIGHT_LONGITUDE_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_MAP_SIZE,
                PARAM_MODO_SUNLIGHT_MAP_SIZE_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_NORTH, PARAM_MODO_SUNLIGHT_NORTH_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_RADIUS,
                PARAM_MODO_SUNLIGHT_RADIUS_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_SPREAD,
                PARAM_MODO_SUNLIGHT_SPREAD_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_POSITION,
                PARAM_MODO_SUNLIGHT_POSITION_NAME,
                PARAM_TYPE_BOOL);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_TIME,
                PARAM_MODO_SUNLIGHT_TIME_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_TIME_ZONE,
                PARAM_MODO_SUNLIGHT_TIME_ZONE_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_V_DISSOLVE,
                PARAM_MODO_SUNLIGHT_V_DISSOLVE_NAME);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_VOLUMETRICS,
                PARAM_MODO_SUNLIGHT_VOLUMETRICS_NAME,
                PARAM_TYPE_BOOL);

        RegisterSunLightParameter (
                PARAM_MODO_SUNLIGHT_V_SAMPLES,
                PARAM_MODO_SUNLIGHT_V_SAMPLES_NAME,
                PARAM_TYPE_INT);
}

        void
ElementParamRegistrar::RegisterSunLightParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_SUN_LIGHT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

/*
 * Mesh parameter registration.
 */
        void
ElementParamRegistrar::RegisterMeshParameters ()
{
        /*
         * Register base locator parameters.
         */
        RegisterMeshParameter (
                PARAM_MODO_LOCATOR_DISPLAY_SIZE,
                PARAM_MODO_LOCATOR_DISPLAY_SIZE_NAME);

        RegisterMeshParameter (
                PARAM_MODO_LOCATOR_DISSOLVE,
                PARAM_MODO_LOCATOR_DISSOLVE_NAME);

        RegisterMeshParameter (
                PARAM_MODO_LOCATOR_RENDER,
                PARAM_MODO_LOCATOR_RENDER_NAME,
                PARAM_TYPE_NAME);

        RegisterMeshParameter (
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE,
                PARAM_MODO_LOCATOR_DISPLAY_VISIBLE_NAME,
                PARAM_TYPE_NAME);

        /*
         * Register mesh-specific parameters.
         */
        RegisterMeshParameter (
                PARAM_MODO_MESH_RENDER_CURVES,
                PARAM_MODO_MESH_RENDER_CURVES_NAME,
                PARAM_TYPE_BOOL);

        RegisterMeshParameter (
                PARAM_MODO_MESH_CURVE_RADIUS, PARAM_MODO_MESH_CURVE_RADIUS_NAME);
}

        void
ElementParamRegistrar::RegisterMeshParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                ELEMENT_MESH, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}


/*
 * Render parameter registration.
 */
        void
ElementParamRegistrar::RegisterRenderParameters ()
{
        /*
         * Render group.
         */
        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_FRAME_RANGE_FIRST,
                PARAM_MODO_POLYRENDER_FRAME_RANGE_FIRST_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_FRAME_RANGE_LAST,
                PARAM_MODO_POLYRENDER_FRAME_RANGE_LAST_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_FRAME_STEP,
                PARAM_MODO_POLYRENDER_FRAME_STEP_NAME,
                PARAM_TYPE_INT);

        /*
         * Frame group.
         */
        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_RESOLUTION_UNIT,
                PARAM_MODO_POLYRENDER_RESOLUTION_UNIT_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_FRAME_WIDTH,
                PARAM_MODO_POLYRENDER_FRAME_WIDTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_FRAME_HEIGHT,
                PARAM_MODO_POLYRENDER_FRAME_HEIGHT_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_FRAME_DPI, PARAM_MODO_POLYRENDER_FRAME_DPI_NAME);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_FRAME_PIXEL_ASPECT_RATIO,
                PARAM_MODO_POLYRENDER_FRAME_PIXEL_ASPECT_RATIO_NAME);

        /*
         * Buckets group.
         */
        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_BUCKET_WIDTH,
                PARAM_MODO_POLYRENDER_BUCKET_WIDTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_BUCKET_HEIGHT,
                PARAM_MODO_POLYRENDER_BUCKET_HEIGHT_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_BUCKET_ORDER,
                PARAM_MODO_POLYRENDER_BUCKET_ORDER_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_BUCKET_REVERSE_ORDER,
                PARAM_MODO_POLYRENDER_BUCKET_REVERSE_ORDER_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_BUCKET_WRITE_TO_DISK,
                PARAM_MODO_POLYRENDER_BUCKET_WRITE_TO_DISK_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_BUCKET_SKIP_EXISTING,
                PARAM_MODO_POLYRENDER_BUCKET_SKIP_EXISTING_NAME,
                PARAM_TYPE_BOOL);

        /* 
         * Region.
         */
        RegisterRenderParameter (
                PARAM_MODO_RENDER_REGION, PARAM_MODO_RENDER_REGION_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_REGION_LEFT,
                PARAM_MODO_RENDER_REGION_LEFT_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_REGION_RIGHT,
                PARAM_MODO_RENDER_REGION_RIGHT_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_REGION_TOP,
                PARAM_MODO_RENDER_REGION_TOP_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_REGION_BOTTOM,
                PARAM_MODO_RENDER_REGION_BOTTOM_NAME);

        /*
         * Antialiasing.
         */
        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_ANTIALIASING,
                PARAM_MODO_POLYRENDER_ANTIALIASING_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_ANTIALIASING_FILTER,
                PARAM_MODO_POLYRENDER_ANTIALIASING_FILTER_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_REFINEMENT_SHADING_RATE,
                PARAM_MODO_POLYRENDER_REFINEMENT_SHADING_RATE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_REFINEMENT_THRESHOLD,
                PARAM_MODO_POLYRENDER_REFINEMENT_THRESHOLD_NAME);

        RegisterRenderParameter (
                PARAM_MODO_POLYRENDER_REFINE_BUCKET_BORDERS,
                PARAM_MODO_POLYRENDER_REFINE_BUCKET_BORDERS_NAME,
                PARAM_TYPE_BOOL);

        /*
         * Register render channels.
         */

        /*
         * Ray Tracing.
         */
        RegisterRenderParameter (
                PARAM_MODO_RENDER_RAY_TRACING_SHADOWS,
                PARAM_MODO_RENDER_RAY_TRACING_SHADOWS_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_REFLECTION_DEPTH,
                PARAM_MODO_RENDER_REFLECTION_DEPTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_REFRACTION_DEPTH,
                PARAM_MODO_RENDER_REFRACTION_DEPTH_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_RAY_THRESHOLD,
                PARAM_MODO_RENDER_RAY_THRESHOLD_NAME);

        /*
         * Geometry.
         */
        RegisterRenderParameter (
                PARAM_MODO_RENDER_ADAPTIVE_SUBDIVISION,
                PARAM_MODO_RENDER_ADAPTIVE_SUBDIVISION_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_SUBDIVISION_RATE,
                PARAM_MODO_RENDER_SUBDIVISION_RATE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_MICROPOLY_DISPLACEMENT,
                PARAM_MODO_RENDER_MICROPOLY_DISPLACEMENT_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_DISPLACEMENT_RATE,
                PARAM_MODO_RENDER_DISPLACEMENT_RATE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_DISPLACEMENT_RATIO,
                PARAM_MODO_RENDER_DISPLACEMENT_RATIO_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_MINIMUM_EDGE_LENGTH,
                PARAM_MODO_RENDER_MINIMUM_EDGE_LENGTH_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_SMOOTH_POSITIONS,
                PARAM_MODO_RENDER_SMOOTH_POSITIONS_NAME,
                PARAM_TYPE_BOOL);

        /*
         * Ambient Light.
         */
        RegisterRenderParameter (
                PARAM_MODO_RENDER_AMBIENT_INTENSITY,
                PARAM_MODO_RENDER_AMBIENT_INTENSITY_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_AMBIENT_COLOR,
                PARAM_MODO_RENDER_AMBIENT_COLOR_NAME,
                PARAM_TYPE_COLOR);

        /*
         * Indirect Illumination.
         */
        RegisterRenderParameter (
                PARAM_MODO_RENDER_ENABLE_INDIRECT_ILLUMINATION,
                PARAM_MODO_RENDER_ENABLE_INDIRECT_ILLUMINATION_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_INDIRECT_ILLUMINATION_SCOPE,
                PARAM_MODO_RENDER_INDIRECT_ILLUMINATION_SCOPE_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_INDIRECT_RAYS,
                PARAM_MODO_RENDER_INDIRECT_RAYS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_INDIRECT_BOUNCES,
                PARAM_MODO_RENDER_INDIRECT_BOUNCES_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_INDIRECT_RANGE,
                PARAM_MODO_RENDER_INDIRECT_RANGE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_SUBSURFACE_SCATTERING,
                PARAM_MODO_RENDER_SUBSURFACE_SCATTERING_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_VOLUMETRICS_AFFECT_INDIRECT,
                PARAM_MODO_RENDER_VOLUMETRICS_AFFECT_INDIRECT_NAME,
                PARAM_TYPE_BOOL);

        /*
         * Irradiance Caching.
         */
        RegisterRenderParameter (
                PARAM_MODO_RENDER_ENABLE_IRRADIANCE_CACHING,
                PARAM_MODO_RENDER_ENABLE_IRRADIANCE_CACHING_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_IRRADIANCE_RAYS,
                PARAM_MODO_RENDER_IRRADIANCE_RAYS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_INDIRECT_SUPERSAMPLING,
                PARAM_MODO_RENDER_INDIRECT_SUPERSAMPLING_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_IRRADIANCE_RATE,
                PARAM_MODO_RENDER_IRRADIANCE_RATE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_IRRADIANCE_RATIO,
                PARAM_MODO_RENDER_IRRADIANCE_RATIO_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_INTERPOLATION_VALUES,
                PARAM_MODO_RENDER_INTERPOLATION_VALUES_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_IRRADIANCE_GRADIENTS,
                PARAM_MODO_RENDER_IRRADIANCE_GRADIENTS_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_WALKTHROUGH_MODE,
                PARAM_MODO_RENDER_WALKTHROUGH_MODE_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_BEFORE_RENDER,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_BEFORE_RENDER_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_FILE,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_FILE_NAME,
                PARAM_TYPE_NAME);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_AFTER_RENDER,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_AFTER_RENDER_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_FILE,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_FILE_NAME,
                PARAM_TYPE_NAME);

        /*
         * Caustics.
         */
        RegisterRenderParameter (
                PARAM_MODO_RENDER_ENABLE_DIRECT_CAUSTICS,
                PARAM_MODO_RENDER_ENABLE_DIRECT_CAUSTICS_NAME,
                PARAM_TYPE_BOOL);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_CAUSTICS_TOTAL_PHOTONS,
                PARAM_MODO_RENDER_CAUSTICS_TOTAL_PHOTONS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_CAUSTICS_LOCAL_PHOTONS,
                PARAM_MODO_RENDER_CAUSTICS_LOCAL_PHOTONS_NAME,
                PARAM_TYPE_INT);

        RegisterRenderParameter (
                PARAM_MODO_RENDER_INDIRECT_CAUSTICS,
                PARAM_MODO_RENDER_INDIRECT_CAUSTICS_NAME,
                PARAM_TYPE_NAME);
}

        void
ElementParamRegistrar::RegisterRenderParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_RENDER, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

/*
 * Environment parameter registration.
 */
        void
ElementParamRegistrar::RegisterEnvironmentParameters ()
{
        RegisterEnvironmentParameter (
                PARAM_MODO_ENVIRONMENT_INTENSITY,
                PARAM_MODO_ENVIRONMENT_INTENSITY_NAME);

        RegisterEnvironmentParameter (
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_CAMERA,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_CAMERA_NAME,
                PARAM_TYPE_BOOL);

        RegisterEnvironmentParameter (
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_INDIRECT_RAYS,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_INDIRECT_RAYS_NAME,
                PARAM_TYPE_BOOL);

        RegisterEnvironmentParameter (
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFLECTION_RAYS,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFLECTION_RAYS_NAME,
                PARAM_TYPE_BOOL);

        RegisterEnvironmentParameter (
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFRACTION_RAYS,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFRACTION_RAYS_NAME,
                PARAM_TYPE_BOOL);
}

        void
ElementParamRegistrar::RegisterEnvironmentParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_ENVIRONMENT, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

/*
 * Environment Material parameter registration.
 */
        void
ElementParamRegistrar::RegisterEnvironmentMaterialParameters ()
{
        RegisterShaderNodeParameters (VIRTUAL_ELEMENT_ENVIRONMENT_MATERIAL);

        /*
         * Environment Material.
         */
        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_TYPE,
                PARAM_MODO_ENVIRONMENT_MATERIAL_TYPE_NAME,
                PARAM_TYPE_NAME);

        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_ZENITH_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_ZENITH_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_NADIR_COLOR,
                PARAM_MODO_ENVIRONMENT_MATERIAL_NADIR_COLOR_NAME,
                PARAM_TYPE_COLOR);

        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_EXPONENT,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_EXPONENT_NAME);

        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_EXPONENT,
                PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_EXPONENT_NAME);

        /*
         * Physically-based Daylight.
         */
        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_SOLAR_DISC_SIZE,
                PARAM_MODO_ENVIRONMENT_MATERIAL_SOLAR_DISC_SIZE_NAME);

/*
 * [TODO] Haze isn't a channel, so manually write it out.
 */
//	RegisterEnvironmentMaterialParameter (
//		PARAM_MODO_ENVIRONMENT_MATERIAL_HAZE_AMOUNT,
//		PARAM_MODO_ENVIRONMENT_MATERIAL_HAZE_AMOUNT_NAME);

        RegisterEnvironmentMaterialParameter (
                PARAM_MODO_ENVIRONMENT_MATERIAL_CLAMP_SKY_BRIGHTNESS,
                PARAM_MODO_ENVIRONMENT_MATERIAL_CLAMP_SKY_BRIGHTNESS_NAME,
                PARAM_TYPE_BOOL);
}

        void
ElementParamRegistrar::RegisterEnvironmentMaterialParameter (
        const string		&paramSID,
        const string		&paramName,
        ParamType		 paramType)
{
        RegisterParameter (
                VIRTUAL_ELEMENT_ENVIRONMENT_MATERIAL, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

/*
 * Shader Node parameter registration.
 */
        void
ElementParamRegistrar::RegisterShaderNodeParameters (
        const string	&parentElement)
{
        RegisterShaderNodeParameter (
                parentElement,
                PARAM_MODO_SHADER_NODE_ENABLED,
                PARAM_MODO_SHADER_NODE_ENABLED_NAME,
                PARAM_TYPE_BOOL);

        RegisterShaderNodeParameter (
                parentElement,
                PARAM_MODO_SHADER_NODE_INVERTED,
                PARAM_MODO_SHADER_NODE_INVERTED_NAME,
                PARAM_TYPE_BOOL);

        RegisterShaderNodeParameter (
                parentElement,
                PARAM_MODO_SHADER_NODE_BLEND_MODE,
                PARAM_MODO_SHADER_NODE_BLEND_MODE_NAME,
                PARAM_TYPE_NAME);

        RegisterShaderNodeParameter (
                parentElement,
                PARAM_MODO_SHADER_NODE_OPACITY,
                PARAM_MODO_SHADER_NODE_OPACITY_NAME);
}

        void
ElementParamRegistrar::RegisterShaderNodeParameter (
        const string	&parentElement,
        const string	&paramSID,
        const string	&paramName,
        ParamType	 paramType)
{
        RegisterParameter (
                parentElement, ELEMENT_PARAM,
                paramSID, paramName, paramType);
}

} // namespace cio

