/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_STRINGS_H
#define CIO_STRINGS_H

#include "cio_format.h"

#include <string>
#include <vector>
#include <set>

namespace cio {

typedef std::vector<std::string> StringArray;
typedef std::set<std::string>	 StringSet;

/*
 * ---------------------------------------------------------------------------
 * IDs and File Paths
 */

/*
 * Condition a file path into an absolute URI.
 */
std::string		FilePathToAbsoluteURI (const std::string& fileName);

/*
 * Condition a file path into a relative URI.
 */
std::string		FilePathToRelativeURI (const std::string& fileName);

/*
 * Return the file extension, if any.
 */
std::string		FileExtension (const std::string& fileName);

/*
 * Build a Uniform Resource Identifier reference, of the form:
 *
 * "myGeom" --> "#myGeom"
 */
std::string		URI_Ref (const std::string& id);

/*
 * Strip off the URI fragment prefix, if one is present:
 *
 * "#myGeom" --> "myGeom"
 */
std::string		StripURI_Ref (const std::string &uri);

/*
 * Filter out NCName reserved characters.
 * 
 * See the table "Names and Tokens", in "Namespaces in XML 1.0":
 *
 *     http://www.w3.org/TR/REC-xml-names/#ns-decl
 */
std::string		EscapeNCName (const std::string& name);

/*
 * Form an item ID from an item name.
 */
std::string		ItemID (const std::string &itemName);

/*
 * Form a transform ID from a transform item name.
 */
std::string		TransformID (const std::string &transformName);

/*
 * Form a node ID from an item ID.
 */
std::string		NodeID (const std::string &itemID);

/*
 * Form a node channel transform ID from an item ID.
 */
std::string		NodeChannelTransformID (
                                const std::string	&itemID,
                                const std::string	&transformName,
                                const std::string	&axisName,
                                const std::string	&componentName);
std::string		NodeChannelTransformID (
                                const std::string	&itemID,
                                const std::string	&transformName);

/*
 * Form a target channel param ID from an item ID.
 */
std::string		TargetChannelParamID (
                                const std::string	&itemID,
                                const std::string	&paramSID);

/*
 * Form a camera ID from an item ID.
 */
std::string		CameraID (const std::string &itemID);

/*
 * Form a controller ID from an item ID.
 */
std::string		ControllerID (const std::string &itemID);

/*
 * Form an effect ID from an item ID.
 */
std::string		EffectID (const std::string &itemID);

/*
 * Form a geometry ID from an item ID.
 */
std::string		GeometryID (const std::string &itemID);

/*
 * Form an image ID from an item ID.
 */
std::string		ImageID (const std::string &itemID);

/*
 * Form a light ID from an item ID.
 */
std::string		LightID (const std::string &itemID);

/*
 * Form a material ID from an item ID.
 */
std::string		MaterialID (const std::string &itemID);

/*
 * Form a material symbolic ID from an item ID.
 */
std::string		MaterialSymbolicID (const std::string &itemID);

/*
 * Form a vertices ID from a geometry ID.
 */
std::string		VerticesID (const std::string &geometryID);

/*
 * ---------------------------------------------------------------------------
 * Type conversions
 */

/*
 * Convert a bool to a string.
 */
std::string		BoolToString (bool inValue);

/*
 * Convert an integer to a string, with optional zero padding.
 */
std::string		IntegerToString (
                                unsigned value,
                                unsigned padding = 0,
                                bool asHexadecimal = false,
                                bool withHexPrefix = false);

/*
 * Convert a float to a string.
 */
std::string		FloatToString (float inValue);

/*
 * Convert a double to a string.
 */
std::string		DoubleToString (double inValue);

/*
 * Date and time.
 */
struct DateTime
{
        unsigned year;
        unsigned month;
        unsigned day;

        unsigned hour;
        unsigned minute;
        unsigned second;
};

std::string		DateTimeToString (const DateTime &dateTime);

/*
 * In the string "s", replace the substring "replace" with the contents of
 * the string "replaceWith".
 */
std::string		Replace (
                                const std::string& s,
                                const std::string& replace,
                                const std::string& replaceWith);

} // namespace cio

#endif // CIO_STRINGS_H
