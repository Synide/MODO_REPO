/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_asset.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_strings.h"
#include "cio_visualscene.h"

#include <ctime>
#include <string>

using namespace std;

namespace cio {

namespace {
        /*
         * Up Axis.
         */
        const char* VALUE_UP_AXIS_X	= "X_UP";
        const char* VALUE_UP_AXIS_Y	= "Y_UP";
        const char* VALUE_UP_AXIS_Z	= "Z_UP";
}

/*
 * SI and Metric units of measurement.
 */
const char* UNITNAME_MICRON		= "micron";
const char* UNITNAME_MILLIMETER		= "millimeter";
const char* UNITNAME_CENTIMETER		= "centimeter";
const char* UNITNAME_METER		= "meter";
const char* UNITNAME_KILOMETER		= "kilometer";
const char* UNITNAME_MEGAMETER		= "megameter";

/*
 * English units of measurement.
 */
const char* UNITNAME_MILS		= "mils";
const char* UNITNAME_INCH		= "inch";
const char* UNITNAME_FOOT		= "foot";
const char* UNITNAME_MILE		= "mile";

/*
 * "Game" unit of measurement.
 */
const char* UNITNAME_GAME		= "game";

/*
 * ---------------------------------------------------------------------------
 * Contributor.
 */

struct pv_ContributorElement
{
        pv_ContributorElement ()
                :
                author(NULL),
                authoringTool(NULL),
                comments(NULL),
                copyright(NULL),
                sourceData(NULL)
        {
        }

        ElementXML		*author;
        ElementXML		*authoringTool;
        ElementXML		*comments;
        ElementXML		*copyright;
        ElementXML		*sourceData;
};

ContributorElement::ContributorElement (AssetElement &asset)
        :
        Element(asset.PV ()),
        pv(new pv_ContributorElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                asset.AddContributor (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                asset.LinkContributor (*this);
        }
}

ContributorElement::~ContributorElement ()
{
        delete pv;
}

        const string
ContributorElement::GetAuthor () const
{
        string author;
        GetElementValue (&pv->author, ELEMENT_AUTHOR, author);

        return author;
}

        void
ContributorElement::SetAuthor (const string &name)
{
        if (!name.empty ()) {
                SetElementValue (&pv->author, ELEMENT_AUTHOR, name);
        }
}

        const string
ContributorElement::GetAuthoringTool () const
{
        string toolName;
        GetElementValue (&pv->authoringTool, ELEMENT_AUTHORING_TOOL, toolName);

        return toolName;
}

        void
ContributorElement::SetAuthoringTool (const string &toolName)
{
        SetElementValue (&pv->authoringTool, ELEMENT_AUTHORING_TOOL, toolName);
}

        const string
ContributorElement::GetComments () const
{
        string comments;
        GetElementValue (&pv->comments, ELEMENT_COMMENTS, comments);

        return comments;
}

        void
ContributorElement::SetComments (const string &commentary)
{
        SetElementValue (&pv->comments, ELEMENT_COMMENTS, commentary);
}

        const StringArray
ContributorElement::GetCommentsList () const
{
        return StringArray ();
}

        void
ContributorElement::SetComments (const StringArray &commentary)
{
        SetElementValue (&pv->comments, ELEMENT_COMMENTS, commentary);
}

        const string
ContributorElement::GetCopyright () const
{
        string copyright;
        GetElementValue (&pv->copyright, ELEMENT_COPYRIGHT, copyright);

        return copyright;
}

        void
ContributorElement::SetCopyright (const string &copyrightHolder)
{
        if (!copyrightHolder.empty ()) {
                SetElementValue (&pv->copyright, ELEMENT_COPYRIGHT, copyrightHolder);
        }
}

        const string
ContributorElement::GetSourceData () const
{
        string sourceData;
        GetElementValue (&pv->comments, ELEMENT_SOURCE_DATA, sourceData);

        return sourceData;
}

        void
ContributorElement::SetSourceData (const string &file)
{
        SetElementValue (&pv->sourceData, ELEMENT_SOURCE_DATA, file);
}

/*
 * ---------------------------------------------------------------------------
 * Asset.
 */

struct pv_AssetElement
{
        pv_AssetElement ()
                :
                element(NULL),
                keywords(NULL),
                revision(NULL),
                subject(NULL),
                title(NULL),
                created(NULL),
                modified(NULL),
                unit(NULL),
                upAxis(NULL)
        {
        }

        void			 SetElement (ElementXML *elementLink)
        {
                element = elementLink;
        }
        ElementXML		*element;

        ElementXML* GetUpAxis (ElementXML *element) const
        {
                if (upAxis == NULL) {
                        upAxis = HandleXML(element).FirstChildElement (
                                ELEMENT_UP_AXIS).Element ();
                }
                return upAxis;
        }

        ElementXML		*keywords;
        ElementXML		*revision;
        ElementXML		*subject;
        ElementXML		*title;

        ElementXML		*created;
        ElementXML		*modified;

        ElementXML		*unit;
        mutable ElementXML	*upAxis;
};

AssetElement::AssetElement (COLLADAElement &collada)
        :
        Element(collada.PV ()),
        pv(new pv_AssetElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddAsset (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                if (collada.LinkAsset (*this)) {
                        SetElement (GetElement ());
                }
        }
}

AssetElement::AssetElement (VisualSceneElement &visualScene)
        :
        Element(visualScene.PV ()),
        pv(new pv_AssetElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                visualScene.AddAsset (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                if (visualScene.LinkAsset (*this)) {
                        SetElement (GetElement ());
                }
        }
}

AssetElement::~AssetElement ()
{
        delete pv;
}

        const string
AssetElement::GetKeywords () const
{
        string keywords;
        GetElementValue (&pv->keywords, ELEMENT_KEYWORDS, keywords);

        return keywords;
}

        void
AssetElement::SetKeywords (const std::string &keywordList)
{
        if (!keywordList.empty ()) {
                SetElementValue (&pv->keywords, ELEMENT_KEYWORDS, keywordList);
        }
}

        const StringArray
AssetElement::GetKeywordsList () const
{
        return StringArray ();
}

        void
AssetElement::SetKeywords (const StringArray &keywordArray)
{
        string words;
        for (StringArray::const_iterator iter = keywordArray.begin ();
             iter != keywordArray.end (); ++iter) {
                words += *iter;
        }

        SetKeywords (words);
}

        const std::string
AssetElement::GetRevision () const
{
        string revision;
        GetElementValue (&pv->revision, ELEMENT_REVISION, revision);

        return revision;
}

        void
AssetElement::SetRevision (const std::string &theRevision)
{
        if (!theRevision.empty ()) {
                SetElementValue (&pv->revision, ELEMENT_REVISION, theRevision);
        }
}

        const std::string
AssetElement::GetSubject () const
{
        string subject;
        GetElementValue (&pv->subject, ELEMENT_SUBJECT, subject);

        return subject;
}

        void
AssetElement::SetSubject (const std::string &subjectText)
{
        if (!subjectText.empty ()) {
                SetElementValue (&pv->subject, ELEMENT_SUBJECT, subjectText);
        }
}

        const std::string
AssetElement::GetTitle () const
{
        string title;
        GetElementValue (&pv->title, ELEMENT_TITLE, title);

        return title;
}

        void
AssetElement::SetTitle (const std::string &theTitle)
{
        if (!theTitle.empty ()) {
                SetElementValue (&pv->title, ELEMENT_TITLE, theTitle);
        }
}

        const DateTime
AssetElement::GetCreationDateTime () const
{
        return DateTime ();
}

        void
AssetElement::SetCreationDateTime (const DateTime &dateTime)
{
        if (pv->created) {
                ClearElementValue (pv->created);
        }
        else {
                pv->created = AddElement (ELEMENT_CREATED);
        }

        SetElementValue (pv->created, DateTimeToString (dateTime));
}

        const DateTime
AssetElement::GetModifiedDateTime () const
{
        return DateTime ();
}

        void
AssetElement::SetModifiedDateTime (const DateTime &dateTime)
{
        if (pv->modified) {
                ClearElementValue (pv->modified);
        }
        else {
                pv->modified = AddElement (ELEMENT_MODIFIED);
        }
        SetElementValue (pv->modified, DateTimeToString (dateTime));
}

        const std::string
AssetElement::GetUnitName () const
{
        return string (UNITNAME_METER);
}

        double
AssetElement::GetUnitsPerMeter () const
{
        return 1.0;
}

        void
AssetElement::SetUnit (
        const string	&name,
        double		unitsPerMeter)
{
        if (pv->unit) {
                ClearElementValue (pv->unit);
        }
        else {
                pv->unit = AddElement (ELEMENT_UNIT);
        }

        SetName (pv->unit, name);
        SetAttribute (pv->unit, ATTRIBUTE_METER, DoubleToString (unitsPerMeter));
}

        AssetElement::UpAxis
AssetElement::GetUpAxis () const
{
        AssetElement::UpAxis upAxis(UP_AXIS_Y);

        ElementXML *upAxisElem = pv->GetUpAxis (GetElement ());
        if (upAxisElem) {
                string testStr(GetElementValue (upAxisElem));
                if (testStr == string(VALUE_UP_AXIS_X)) {
                        upAxis = UP_AXIS_X;
                }
                else if (testStr == string(VALUE_UP_AXIS_Y)) {
                        upAxis = UP_AXIS_Y;
                }
                else if (testStr == string(VALUE_UP_AXIS_Z)) {
                        upAxis = UP_AXIS_Z;
                }
        }

        return upAxis;
}

        void
AssetElement::SetUpAxis (UpAxis axis)
{
        if (pv->upAxis) {
                ClearElementValue (pv->upAxis);
        }
        else {
                pv->upAxis = AddElement (ELEMENT_UP_AXIS);
        }

        switch (axis) {
                case UP_AXIS_X:
                        SetElementValue (pv->upAxis, VALUE_UP_AXIS_X);
                        break;

                case UP_AXIS_Y:
                        SetElementValue (pv->upAxis, VALUE_UP_AXIS_Y);
                        break;

                case UP_AXIS_Z:
                        SetElementValue (pv->upAxis, VALUE_UP_AXIS_Z);
                        break;
        }
}

        bool
AssetElement::HasContributor () const
{
        return HasChildElement (ELEMENT_CONTRIBUTOR);
}

        bool
AssetElement::LinkContributor (ContributorElement &contributor)
{
        return LinkFirstChildElement (ELEMENT_CONTRIBUTOR, contributor);
}

        void
AssetElement::AddContributor (ContributorElement &contributor)
{
        contributor.SetElement (AddElement (ELEMENT_CONTRIBUTOR));
}

} // namespace cio

