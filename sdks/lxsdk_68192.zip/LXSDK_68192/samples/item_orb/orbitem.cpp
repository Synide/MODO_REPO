/*
 * Plug-in orb item type.
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * A plug-in item type that creates a procedural orb, that can be varied
 * in various ways (coverage, radius, etc.), with adaptive sampling.
 */

#include "orbitem.h"

#include <lxvmath.h>
#include <lx_action.hpp>
#include <lx_plugin.hpp>
#include <lx_draw.hpp>
#include <lx_locator.hpp>

#include <string>
#include <math.h>
#include <vector>

/*
 * ----------------------------------------------------------------
 * Orb Tableau Element
 *
 * A tableau surface element lives in the tableau and generates geometry
 * for the renderer. It has a bounding box, vertex features, and a sample
 * method.
 */
        LxResult
COrbElement::tsrf_Bound (
        LXtTableauBox		 bbox)
{
        bbox[0] = -m_radius;
        bbox[1] = -m_radius;
        bbox[2] = -m_radius;
        bbox[3] =  m_radius;
        bbox[4] =  m_radius;
        bbox[5] =  m_radius;
        return LXe_OK;
}

        unsigned
COrbElement::tsrf_FeatureCount (
        LXtID4			 type)
{
        return (type == LXiTBLX_BASEFEATURE ? 4 : 0);
}

        LxResult
COrbElement::tsrf_FeatureByIndex (
        LXtID4			 type,
        unsigned		 index,
        const char	       **name)
{
        if (type != LXiTBLX_BASEFEATURE)
                return LXe_NOTFOUND;

        switch (index) {
            case 0:
                name[0] = LXsTBLX_FEATURE_POS;
                return LXe_OK;

            case 1:
                name[0] = LXsTBLX_FEATURE_OBJPOS;
                return LXe_OK;

            case 2:
                name[0] = LXsTBLX_FEATURE_NORMAL;
                return LXe_OK;

            case 3:
                name[0] = LXsTBLX_FEATURE_VEL;
                return LXe_OK;
        }
        return LXe_OUTOFBOUNDS;
}

        LxResult
COrbElement::tsrf_SetVertex (
        ILxUnknownID		 vdesc)
{
        LxResult		 rc;
        const char		*name;
        unsigned		 offset, i;

        if (!vrt_desc.set (vdesc))
                return LXe_NOINTERFACE;

        for (i = 0; i < 4; i++) {
                tsrf_FeatureByIndex (LXiTBLX_BASEFEATURE, i, &name);
                rc = vrt_desc.Lookup (LXiTBLX_BASEFEATURE, name, &offset);
                f_pos[i] = (rc == LXe_OK ? offset : -1);
        }

        return LXe_OK;
}

        LxResult
COrbElement::tsrf_Sample (
        const LXtTableauBox	 bbox,
        float			 scale,
        ILxUnknownID		 trisoup)
{
        CLxUser_TriangleSoup	 soup (trisoup);
        LXtTableauBox		 box;
        LxResult		 rc;
        float			 vec[3 * 4];
        double			 ang, sn, cs;
        unsigned		 index;
        int			 i, n, k;

        orb_log.Info ("Sample test box");

        /*
         * Return early if the bounding box (as determined by our radius
         * channel value) isn't visible.
         */
        box[0] = -m_radius;
        box[1] = -m_radius;
        box[2] = -m_radius * 0.5f;
        box[3] =  m_radius;
        box[4] =  m_radius;
        box[5] =  m_radius * 0.5f;

        if (!soup.TestBox (box))
                return LXe_OK;

        orb_log.Info ("Sample test seg");

        rc = soup.Segment (1, LXiTBLX_SEG_TRIANGLE);
        if (rc == LXe_FALSE)
                return LXe_OK;
        else if (LXx_FAIL (rc))
                return rc;

        orb_log.Info ("Sampling!");

        /*
         * This example doesn't have any velocity for motion blur.
         */
        vec[f_pos[3] + 0] = 0.0;
        vec[f_pos[3] + 1] = 0.0;
        vec[f_pos[3] + 2] = 0.0;

        /*
         * Vary the number of sides by the radius and resolution.
         */
        int res;
        if (scale < 1) {
                scale = 1;
                res = m_resolution;
        }
        else {
                res = 1;
        }
        scale = scale / 40.0f;
        n = (int) (3.142 / sqrt (scale / res / m_radius));
        if (n < 8)
                n = 8;
        else if (n > 1200)
                n = 1200;

        /*
         * Build the vertex list.
         */
        for (i = 0; i < n; i++) {
                ang = 3.14159 * 2.0 * i / n;
                sn  = sin (ang);
                cs  = cos (ang);

                vec[f_pos[0] + 0] = vec[f_pos[1] + 0] = static_cast<float>(sn  * m_radius);
                vec[f_pos[0] + 1] = vec[f_pos[1] + 1] = static_cast<float>(cs  * m_radius);
                vec[f_pos[0] + 2] = vec[f_pos[1] + 2] = static_cast<float>(0.5 * m_radius);

                vec[f_pos[2] + 0] = static_cast<float>(sn);
                vec[f_pos[2] + 1] = static_cast<float>(cs);
                vec[f_pos[2] + 2] = 0.0f;

                soup.Vertex (vec, &index);

                vec[f_pos[0] + 2] = static_cast<float>(-0.5 * m_radius);
                vec[f_pos[1] + 2] = static_cast<float>(-0.5 * m_radius);

                soup.Vertex (vec, &index);
        }

        /*
         * Build the triangle list.
         */
        k = 0;
        for (i = 0; i < n; i++) {
                soup.Polygon (k, (k + 2) % (n * 2), (k + 3) % (n * 2));
                soup.Polygon (k, (k + 3) % (n * 2), (k + 1) % (n * 2));
                k += 2;
        }

        return LXe_OK;
}

        LxResult
COrbElement::tins_Properties (
        ILxUnknownID	 vecstack)
{
        return LXe_OK;
}

        LxResult
COrbElement::tins_GetTransform (
        unsigned	 endPoint,
        LXtVector	 offset,
        LXtMatrix	 xfrm)
{
        LXx_VCPY (offset, m_offset);

        for (unsigned i = 0; i < 3; ++i)
                LXx_VCPY (xfrm[i], m_xfrm[i]);

        return LXe_OK;
}

/*
 * ----------------------------------------------------------------
 * Orb Instance
 *
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
        LxResult
COrbInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        orb_log.Info ("Initialize");
        if (m_item.set (item)) {
                std::string x = "-- got item ";
                orb_log.Info (x.c_str ());
        }
        return LXe_OK;
}

        void
COrbInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

        LxResult
COrbInstance::pins_SynthName (
        char			*buf,
        unsigned		 len)
{
        std::string name("test.orb");
        size_t count = name.size () + 1;
        if (count > len) {
                count = len;
        }
        memcpy (buf, &name[0], count);

        return LXe_OK;
}

        unsigned
COrbInstance::pins_DupType (void)
{
        return 0;
}

        LxResult
COrbInstance::pins_TestParent (
        ILxUnknownID		 item)
{
        return LXe_NOTIMPL;
}

        LxResult
COrbInstance::pins_Newborn (ILxUnknownID original)
{
        return LXe_NOTIMPL;
}

        LxResult
COrbInstance::pins_Loading (void)
{
        return LXe_NOTIMPL;
}

        LxResult
COrbInstance::pins_AfterLoad (void)
{
        return LXe_NOTIMPL;
}

        void
COrbInstance::pins_Doomed (void)
{
}

/*
 * The instance also presents a StringTag interface so it can pretend to have
 * part and material tags for finding a shader.
 */
        LxResult
COrbInstance::stag_Get (
        LXtID4			 type,
        const char	       **tag)
{
        tag[0] = "Default";
        return LXe_OK;
}

/*
 * The instance's TableauSource interface allows it to place elements into the
 * tableau, in this case our orb element.
 */
        LxResult
COrbInstance::tsrc_Elements (
        ILxUnknownID		 tblx)
{
        CLxUser_Tableau		 tbx (tblx);
        CLxUser_ChannelRead	 chan;
        CLxUser_TableauShader	 shader;
        ILxUnknownID		 element;
        LxResult		 rc;
        double			 rad;
        int			 res;
        int			 idx;

        /*
         * This is our opportunity to fetch our custom channel values.
         */
        if (!tbx.GetChannels (chan, 0))
                return LXe_NOINTERFACE;

        idx = m_item.ChannelIndex ("radius");
        if (idx < 0)
                return LXe_NOTFOUND;

        rad = chan.FValue (m_item, idx);

        idx = m_item.ChannelIndex ("resolution");
        if (idx < 0)
                return LXe_NOTFOUND;

        res = chan.IValue (m_item, idx);

        if (!tbx.GetShader (shader, m_item, inst_ifc))
                return LXe_NOTFOUND;

        element = src_pkg->elt_factory.Spawn ();
        if (!element)
                return LXe_FAILED;

        LXCWxOBJ(element,COrbElement)->m_radius = static_cast<float>(rad);
        LXCWxOBJ(element,COrbElement)->m_resolution = res;

        /*
         * We also need to store the locator transform, so it can be looked
         * up later on when TableauInstance::GetTransform is called.
         */
        CLxLoc_Locator locator;
        if (locator.set (m_item)) {
                LXtMatrix	 xfrm;
                LXtVector	 offset;

                locator.WorldTransform (chan, xfrm, offset);

                for (unsigned i = 0; i < 3; ++i)
                        LXx_VCPY (LXCWxOBJ(element,COrbElement)->m_xfrm[i], xfrm[i]);
                LXx_VCPY (LXCWxOBJ(element,COrbElement)->m_offset, offset);
        }

        rc = tbx.AddElement (element, shader);
        lx::UnkRelease (element);

        return rc;
}

        LxResult
COrbInstance::tsrc_PreviewUpdate (
        int			 chanIndex,
        int			*update)
{
        int idx = m_item.ChannelIndex ("radius");
        if (chanIndex == idx) {
                *update = LXfTBLX_PREVIEW_UPDATE_GEOMETRY;
        }
        else {
                *update = LXfTBLX_PREVIEW_UPDATE_NONE;
        }

        return LXe_OK;
}

/*
 * Based on the channel values, draw the abstract item representation
 * using the stroke drawing interface.
 */
        LxResult
COrbInstance::vitm_Draw (
        ILxUnknownID	 itemChanRead,
        ILxUnknownID	 viewStrokeDraw,
        int		 selectionFlags,
        LXtVector	 itemColor)
{
        CLxUser_ChannelRead	 chanRead;
        CLxLoc_StrokeDraw	 strokeDraw;
        float			 lineWidth;
        int			 chanIndex;
        double			 rad;
        double			 ang, sn, cs;
        int			 i, n, k;
        std::vector<lx::GeoPoint> points;

        chanRead.set (itemChanRead);
        strokeDraw.set (viewStrokeDraw);

        /*
         * Fetch the radius value for the current frame.
         */
        chanIndex = m_item.ChannelIndex ("radius");
        if (chanIndex < 0)
                return LXe_NOTFOUND;

        rad = chanRead.FValue (m_item, chanIndex);

        /*
         * Use a thicker line width when selected or rollover.
         */
        if (selectionFlags & LXiSELECTION_SELECTED ||
            selectionFlags & LXiSELECTION_ROLLOVER) {
                lineWidth = 2.0;
        }
        else {
                lineWidth = 1.0;
        }

        /*
         * The item color is automatically set according to the last hit test.
         */
        strokeDraw.BeginW (LXiSTROKE_LINES, itemColor, 1.0, lineWidth);

        LXtVector vert;
        int strokeFlags = LXiSTROKE_ABSOLUTE;

        /*
         * Vary the number of sides by the radius.
         */
        float scale = 1.0;
        scale /= 40.0;
        n = (int) (3.142 / sqrt (scale / rad));
        if (n < 8)
                n = 8;
        else if (n > 1200)
                n = 1200;

        /*
         * Build the vertex list.
         */
        for (i = 0; i < n; i++) {
                ang = 3.14159 * 2.0 * i / n;
                sn  = sin (ang);
                cs  = cos (ang);

                lx::GeoPoint point;
                point.vec[0] = sn  * rad;
                point.vec[1] = cs  * rad;
                point.vec[2] = 0.5 * rad;
                points.push_back (point);

                point.vec[2] = -0.5 * rad;
                points.push_back (point);
        }

        /*
         * Draw the edges of each polygon.
         */
        k = 0;
        for (i = 0; i < n; i++) {
                LXx_VCPY (vert, points[k].vec);
                strokeDraw.Vertex (vert, strokeFlags);
                LXx_VCPY (vert, points[(k + 2) % (n * 2)].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                strokeDraw.Vertex (vert, strokeFlags);
                LXx_VCPY (vert, points[(k + 3) % (n * 2)].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[k].vec);
                strokeDraw.Vertex (vert, strokeFlags);
                LXx_VCPY (vert, points[(k + 3) % (n * 2)].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                strokeDraw.Vertex (vert, strokeFlags);
                LXx_VCPY (vert, points[(k + 1) % (n * 2)].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                k += 2;
        }

        return LXe_OK;
}

        LxResult
COrbInstance::vitm_HandleCount (
        int		*count)
{
        *count = 1;

        return LXe_OK;
}

        LxResult
COrbInstance::vitm_HandleMotion (
        int		 handleIndex,
        int		*motionType,
        double		*min,
        double		*max,
        LXtVector	 plane,
        LXtVector	 offset)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if (handleIndex == 0) {
                *motionType = LXfVHANDLE_DRAW_X;

                *min = 0.0001;
                *max = 10000;

                plane[0] = plane[1] = 1.0;
                plane[3] = 0.0;

                offset[0] = offset[1] = offset[2] = 0.0;

                result = LXe_OK;
        }

        return result;
}

        LxResult
COrbInstance::vitm_HandleChannel (
        int		 handleIndex,
        int		*chanIndex)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if (handleIndex == 0) {
                *chanIndex = m_item.ChannelIndex ("radius");
                result = LXe_OK;
        }

        return result;
}

        LxResult
COrbInstance::vitm_HandleValueToPosition (
        int		 handleIndex,
        double		*chanValue,
        LXtVector	 position)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if (handleIndex == 0) {
                position[0] = *chanValue;
                position[1] = position[2] = 0.0;

                result = LXe_OK;
        }

        return result;
}

        LxResult
COrbInstance::vitm_HandlePositionToValue (
        int		 handleIndex,
        LXtVector	 position,
        double		*chanValue)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if (handleIndex == 0) {
                *chanValue = position[0];

                result = LXe_OK;
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 *
 * Our Orb item type is a subtype of "locator".
 */
LXtTagInfoDesc	 COrbPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,	"locator"	},
        { LXsPKG_IS_MASK,	"."		},
        { LXsSRV_LOGSUBSYSTEM,	"test-orb"	},
        { 0 }
};


COrbPackage::COrbPackage ()
{
        orb_factory.AddInterface (new CLxIfc_PackageInstance<COrbInstance>);
        orb_factory.AddInterface (new CLxIfc_TableauSource<COrbInstance>);
        orb_factory.AddInterface (new CLxIfc_StringTag<COrbInstance>);
        orb_factory.AddInterface (new CLxIfc_ViewItem3D<COrbInstance>);

        elt_factory.AddInterface (new CLxIfc_TableauSurface<COrbElement>);
        elt_factory.AddInterface (new CLxIfc_TableauInstance<COrbElement>);
}

        LxResult
COrbPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel ("radius", "distance");
        ac.SetDefault (1.0, 1);

        ac.NewChannel ("resolution", "integer");
        ac.SetDefault (8.0, 8);

        /*
         * 'scrimshaw' is a dummy channel for an example of an RGBA color.
         */
        ac.NewChannel ("scrimshaw",  "color1");
        ac.SetVector  ("RGBA");

        return LXe_OK;
}

        LxResult
COrbPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return (orb_factory.TestInterface (guid) ? LXe_TRUE : LXe_FALSE);
}

        LxResult
COrbPackage::pkg_Attach (
        void		       **ppvObj)
{
        COrbInstance		*orb = orb_factory.Alloc (ppvObj);

        orb->src_pkg = this;
        orb->inst_ifc    = (ILxUnknownID) ppvObj[0];

        return LXe_OK;
}

/*
 * Our package is going to eavesdrop on selection events. This isn't
 * particularly useful; it's just here as an example.
 */
        void
COrbPackage::selevent_Add (
        LXtID4			 type,
        unsigned int		 subtType)
{
}

        void
COrbPackage::selevent_Current (
        LXtID4			 type)
{
}

        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<COrbPackage>;
        srv->AddInterface (new CLxIfc_Package          <COrbPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc       <COrbPackage>);
        srv->AddInterface (new CLxIfc_SelectionListener<COrbPackage>);
        thisModule.AddServer ("test.orb", srv);
}


