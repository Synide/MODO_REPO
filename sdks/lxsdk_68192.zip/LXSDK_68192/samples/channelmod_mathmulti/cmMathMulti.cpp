/*
 * Plug-in channel modifiers for various math operations.
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cmMathMulti.h"

#include <lx_plugin.hpp>

#include <string>

// Math Multi Instance

        LxResult
CMathMultiInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        log.Info ("Initialize");
        
        m_item.set (item);

        return LXe_OK;
}

        void
CMathMultiInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

        LxResult
CMathMultiInstance::pins_SynthName (
        char			*buf,
        unsigned		 len)
{
        std::string name ("Math Multiple");
        size_t count = name.size () + 1;
        if (count > len) {
                count = len;
        }
        memcpy (buf, &name[0], count);

        return LXe_OK;
}



        LxResult
CMathMultiInstance::cmod_Allocate (
        ILxUnknownID		 cmod,		// ILxChannelModifierID
        ILxUnknownID		 eval,		// ILxEvaluationID
        ILxUnknownID		 item,
        void		       **ppvData)
{
        CLxLoc_ChannelModifier	 chanMod (cmod);
        CLxUser_Item		 modItem (item);
        unsigned int		 chanIdx;
        
//	log.Info ("cmod_Allocate Method");

        // Lookup the index of the 'op' channel and add as an input.
        modItem.ChannelLookup ("operation", &chanIdx);
        chanMod.AddInput (item, chanIdx);
                
        // Lookup the index of the 'inputs' channel and add as an input.
        modItem.ChannelLookup ("inputs", &chanIdx);
        chanMod.AddInput (item, chanIdx);
                
        // Lookup the index of the 'result' channel and add it as an output.
        modItem.ChannelLookup ("result", &chanIdx);
        chanMod.AddOutput (item, chanIdx);
                
        return LXe_OK;
}

        void
CMathMultiInstance::cmod_Cleanup (
        void			*data)
{

}

        unsigned int
CMathMultiInstance::cmod_Flags (
        ILxUnknownID		 item,
        unsigned int		 index)
{
        CLxUser_Item		 modItem (item);
        unsigned int		 chanIdx;
        
//	log.Info ("cmod_Flags Method");
        
        if (LXx_OK (modItem.ChannelLookup ("inputs", &chanIdx))) {
                if (index == chanIdx)
                        return (LXfCHMOD_INPUT | LXfCHMOD_MULTILINK);
        }
        
        if (LXx_OK (modItem.ChannelLookup ("result", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_OUTPUT;
        }
        
        return 0;
}


        LxResult
CMathMultiInstance::cmod_Evaluate (
        ILxUnknownID		 cmod,		// ILxChannelModifierID
        ILxUnknownID		 attr,		// ILxAttributesID
        void			*data)		// User Data
{
        CLxLoc_ChannelModifier	 chanMod (cmod);
        double			 dVal, result = 0.0;
        unsigned int		 nLinks;
        unsigned		 i;
        int			 op;
        
//	log.Info ("cmod_Evaluate Method");
        
        // Read the 'operation' channel.
        chanMod.ReadInputInt (attr, 0, &op);
        
        // Get the number of links into the 'inputs' channel.
        chanMod.InputCount (1, &nLinks);
        
        for (i = 0; i < nLinks; i++) {
        
                // Read the value for this input link.
                chanMod.ReadInputFloatByIndex (attr, 1, i, &dVal);
                
                if (i == 0) {
                        result = dVal;
                }
                else {
                        switch (op) {
                                case 0:		// Add
                                case 4:		// Average
                                        result += dVal;
                                        break;
                        
                                case 1:		// Subtract
                                        result -= dVal;
                                        break;
                                        
                                case 2:		// Multiply
                                        result *= dVal;
                                        break;
                                        
                                case 3:		// Divide
                                        if (dVal != 0.0)
                                                result /= dVal;
                                        break;
                                
                                case 5:		// Min
                                        if (dVal < result)
                                                result = dVal;
                                        break;
                                
                                case 6:		// Max
                                        if (dVal > result)
                                                result = dVal;
                                        break;
                        }
                }
        }
        
        if (op == 4 && nLinks > 1)
                result /= nLinks;
        
        chanMod.WriteOutputFloat (attr, 0, result);
        
        return LXe_OK;
}


// Package class

LXtTagInfoDesc	 CMathMultiPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,	"chanModify"	},
        { LXsSRV_LOGSUBSYSTEM,	"cmMathMulti"	},
        { 0 }
};


// Constructor

CMathMultiPackage::CMathMultiPackage ()
{
        chanmod_factory.AddInterface (new CLxIfc_PackageInstance<CMathMultiInstance>);
        chanmod_factory.AddInterface (new CLxIfc_ChannelModItem<CMathMultiInstance>);
}


static LXtTextValueHint hint_op[] = {
        0,			"add",
        1,			"sub",
        2,			"mul",
        3,			"div",
        4,			"avg",
        5,			"min",
        6,			"max",
        -1,			NULL
        };
        

        LxResult
CMathMultiPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        
        ac.NewChannel ("operation", LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 0);
        ac.SetHint (hint_op);
        
        ac.NewChannel ("inputs", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);
                
        ac.NewChannel ("result", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);

        return LXe_OK;
}



        LxResult
CMathMultiPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return (chanmod_factory.TestInterface (guid) ? LXe_TRUE : LXe_FALSE);
}



        LxResult
CMathMultiPackage::pkg_Attach (
        void		       **ppvObj)
{
        CMathMultiInstance	*chanmod = chanmod_factory.Alloc (ppvObj);

        chanmod->src_pkg  = this;
        chanmod->inst_ifc = (ILxUnknownID) ppvObj[0];

        return LXe_OK;
}





        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CMathMultiPackage>;
        srv->AddInterface (new CLxIfc_Package          <CMathMultiPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc       <CMathMultiPackage>);
        thisModule.AddServer ("cmMathMulti", srv);
}
















