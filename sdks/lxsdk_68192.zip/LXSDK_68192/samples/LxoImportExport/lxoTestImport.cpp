/*
 * Copyright (c) 2009 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <lxidef.h>
#include "lxoReader.hpp"

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * convert the 4 byte ID into a printable string
 *
 *----------------------------------------------------------------------------*/
static char* stringFromId (LXtID4 id)
{
    static char     idString[] = "'1234'";

    typedef union {
            LXtID4          id;
            LxByte          b[4];
            } Union4Bytes;

    Union4Bytes*    unionP = (Union4Bytes*)&id;

    idString[1] = unionP->b[3];
    idString[2] = unionP->b[2];
    idString[3] = unionP->b[1];
    idString[4] = unionP->b[0];

    return idString;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * The LxoImport class extends LxoReader to "import" <advancedMaterial> items
 * from an LXO file. In this case "import" means print out the data from
 * these items.
 *
 *----------------------------------------------------------------------------*/
class LxoImport : public LxoReader {
        char        m_itemType[1024];
        char        m_itemName[1024];

    public:
        LxoImport (char* lxoName) : LxoReader (lxoName) { m_itemType[0] = m_itemName[0] = '\0'; }

        virtual LXChunkUsage    ChunkUsage ()   // decide which chunks we want to process
            {
            switch (m_chunkId)
                {
                case 'ITEM':                    // Item chunk containing sub-chunks
                    return LXChunk_Process;     // yes, process items
                }

            return LXChunk_Ignore;              // ignore other chunk types
            }

        virtual LXChunkUsage    ItemSubChunkUsage ()    // decide which item sub-chunks to process
            {
            switch (m_subChunkId)
                {
                case 'CHNL':                // Scalar channel value sub-chunk
                    return LXChunk_Process; // only interested in CHNL sub-chunks for this example;
                                            // there are other types needed -- just not used here
                }

            return LXChunk_Ignore;          // ignore other sub-chunk types
            }

        virtual LxResult        ProcessItem (char* itemType, char* name, LxULong itemID)
            {
            if (0 != strcmp (LXsITYPE_ADVANCEDMATERIAL, itemType))
                {
                SkipRestOfChunk ();     // ignore all sub-chunks of items other than advancedMaterial
                return LXe_OK;
                }

            strcpy (m_itemType, itemType);      // save the item type
            strcpy (m_itemName, name);          // save the item name
            return LXe_OK;
            }

        virtual LxResult    ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length);
};

/*------------------------------- Luxology LLC --------------------------- 03/09
 *
 * "import" advancedMaterial items by printing their contents
 * Use the LxoDump class (subclassed from LxoReader) to read and print the entire file.
 *
 *----------------------------------------------------------------------------*/
LxResult LxoImport::ProcessItemChannelScalar (char* name, LxUShort type, int intVal, float floatVal, char* strVal, LxByte* buffer, LxUShort length)
{
    printf ("%s :: %s\tSubChunk ID: %s Size: %3d:\t", m_itemType, m_itemName, stringFromId (m_subChunkId), m_subChunkSize);
    printf ("Name: <%s>, (%d) ", name, type);

    switch (type & ~LXItemType_UndefState)
        {
        case LXItemType_Int:
        case LXItemType_EnvelopeInt:
            printf ("Int: %d\n", intVal);
            break;

        case LXItemType_Float:
        case LXItemType_EnvelopeFloat:
        case LXItemType_FloatAlt:
            printf ("Float: %f\n", floatVal);
            break;

        case LXItemType_String:
        case LXItemType_EnvelopeString:
            printf ("String: <%s>\n", strVal);
            break;

        case LXItemType_Variable:
            printf ("VarLength: %d\n", length);
            break;
        }

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * process command line args to specify the input LXO file.  Use the LxoImport
 * class (subclassed from LxoReader) to "import" items of interest.
 *
 *----------------------------------------------------------------------------*/
int main (int argc, char* argv[])
{
    static char         usage[] = "Usage: %s lxoFileName";

    if (2 != argc)
        return fprintf (stderr, usage, argv[0]);

    LxResult    result = LxoImport (argv[1]).ReadFile ();

    if (LXe_OK != result)
        fprintf (stderr, "\nError (0x%x) Importing LXO file <%s>\n", result, argv[1]);
    else
        fprintf (stderr, "\nSuccessfully imported <%s>\n", argv[1]);
}

