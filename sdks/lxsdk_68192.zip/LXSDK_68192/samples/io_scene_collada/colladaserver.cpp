/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#pragma warning(disable: 4786)

#include "colladaloader.h"
#include "colladasaver.h"

#include "../libcolladaio/cio_strings.h"

/*
 * Bring in platform service.
 */
#include <lx_scripts.hpp>
#include <lxcommand.h>

using namespace std;
using namespace cio;

/*
 * Build the authoring tool string using the application name, version number,
 * build number, and platform.
 */
        string
GetAuthoringTool ()
{
        string	authoringTool;

        CLxUser_PlatformService	 platSvc;

        int appVersion, appBuild;
        platSvc.AppVersion (&appVersion);
        platSvc.AppBuild (&appBuild);

        authoringTool =
                platSvc.AppName () + string(" ") +
                IntegerToString(appVersion) + string(" ") +
                string("[Build ") + IntegerToString(appBuild) + string("], ") +
                platSvc.OSName () +
                string(" (") + platSvc.OSVersion () + string (")");

        return authoringTool;
}

/*
 *------------------------------------------------------------------------
 * COLLADALogMessage.
 */

        const char *
COLLADALogMessage::GetFormat ()
{
        return VALUE_SCENE_IO_USER_NAME;
}

        const char *
COLLADALogMessage::GetVersion ()
{
        authoringTool = GetAuthoringTool ();
        return authoringTool.c_str ();
}

        void
COLLADALogMessage::Error (const string &msg)
{
        CLxLogMessage::Error (msg.c_str ());
}

        static string
ResultCodeToString (LxResult rc)
{
        string resultStr;

        switch (rc) {
                case LXe_FAILED:
                        resultStr = string("LXe_FAILED");
                        break;

                case LXe_NOTIMPL:
                        resultStr = string("LXe_NOTIMPL");
                        break;

                case LXe_OUTOFMEMORY:
                        resultStr = string("LXe_OUTOFMEMORY");
                        break;

                case LXe_INVALIDARG:
                        resultStr = string("LXe_INVALIDARG");
                        break;

                case LXe_NOINTERFACE:
                        resultStr = string("LXe_NOINTERFACE");
                        break;

                case LXe_NOACCESS:
                        resultStr = string("LXe_NOACCESS");
                        break;

                case LXe_OUTOFBOUNDS:
                        resultStr = string("LXe_OUTOFBOUNDS");
                        break;

                case LXe_NOTFOUND:
                        resultStr = string("LXe_NOTFOUND");
                        break;

                case LXe_DISABLED:
                        resultStr = string("LXe_DISABLED");
                        break;

                case LXe_ALREADYEXISTS:
                        resultStr = string("LXe_ALREADYEXISTS");
                        break;

                case LXe_NOTAVAILABLE:
                        resultStr = string("LXe_NOTAVAILABLE");
                        break;

                default:
                        resultStr = IntegerToString(
                                rc, 0, true, true);
                        break;
        }

        return resultStr;
}

        void
COLLADALogMessage::Error (const string &msg, LxResult rc)
{
        string errMsg = msg + ResultCodeToString (rc);
        CLxLogMessage::Error (errMsg.c_str ());
}

        void			 
COLLADALogMessage::Info (const string &msg)
{
        CLxLogMessage::Info (msg.c_str ());
}

        void			 
COLLADALogMessage::Info (const string &msg, LxResult rc)
{
        string infoMsg = msg + ResultCodeToString (rc);
        CLxLogMessage::Info (infoMsg.c_str ());
}

/*
 *------------------------------------------------------------------------
 * Exported Servers.
 */
        void
initialize ()
{
        LXx_ADD_SERVER (
                Loader,
                COLLADASceneLoader,
                VALUE_SCENE_IO_INTERNAL_NAME);

        LXx_ADD_SERVER (
                Saver,
                COLLADASceneSaver,
                VALUE_SCENE_IO_INTERNAL_NAME);
}

