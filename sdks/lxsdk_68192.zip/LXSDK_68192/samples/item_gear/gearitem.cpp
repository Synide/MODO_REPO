/*
 * Plug-in gear item type.
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * A plug-in item type that creates a procedural gear, that can be varied
 * in various ways (number of teeth, spacing, number of spokes, etc.).
 */

#include "gearitem.h"

#include <lxcommand.h>

#include <lxu_message.hpp>

#include <lx_draw.hpp>
#include <lx_locator.hpp>

#include <lx_plugin.hpp>

#include <lx_schematic.hpp>

#include <string>
#include <math.h>


using namespace std;
using namespace lx;

/*
 * ---------------------------------------------------------------------------
 * Gear channel values.
 */

/*
 * Circumference is calculated by multiplying the tooth spacing by the
 * number of teeth. Divide the result by pi to calculate the pitch diameter.
 */

const double PI		= 3.1415926535897932384626433832795;
const double HALF_PI	= PI / 2;
const double QUARTER_PI = PI / 4;
const double TWO_PI	= PI * 2;
const double DEG2RAD	= PI / 180;

/*
 * ---------------------------------------------------------------------------
 * Construction channels.
 */

/*
 * How much of the gear is constructed.
 *
 * Useful for animating the construction of the gear.
 */
#define CHANs_GEAR_COVERAGE			"coverage"

#define CHANs_GEAR_TOOTH_SPACING		"tooth_spacing"

/*
 * Contact angle is stored in radians, but displayed in degrees.
 */
#define CHANs_GEAR_CONTACT_ANGLE		"contact_angle"

#define CHANs_GEAR_THICKNESS			"thickness"

/*
 * The number of teeth.
 */
#define CHANs_GEAR_TEETH			"teeth"

#define CHANs_GEAR_SHAFT			"shaft"

#define CHANs_GEAR_HAS_SPOKES			"has_spokes"
#define	CHANs_GEAR_SPOKES			"spokes"

/*
 * ---------------------------------------------------------------------------
 * Trim channels.
 */
#define CHANs_GEAR_HAS_RIM			"has_rim"
#define CHANs_GEAR_RIM_INSET_RATIO		"rim_inset_ratio"
#define CHANs_GEAR_WALL_INSET_RATIO		"wall_inset_ratio"
#define CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO	"axial_shaft_inset_ratio"
#define CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO	"radial_shaft_inset_ratio"
#define CHANs_GEAR_INNER_SPOKE_INSET_RATIO	"inner_spoke_inset_ratio"
#define CHANs_GEAR_OUTER_SPOKE_INSET_RATIO	"outer_spoke_inset_ratio"
#define CHANs_GEAR_SPOKE_SWEEP_RATIO		"spoke_sweep_ratio"
#define CHANs_GEAR_SPOKE_SWIRL_ANGLE		"spoke_swirl_angle"

/*
 * ---------------------------------------------------------------------------
 * Specialized channels.
 */
#define CHANs_GEAR_TEETH_FACING			"teeth_facing"
#define CHANs_GEAR_BEVEL_ANGLE			"bevel_angle"
#define CHANs_GEAR_HELICAL_ANGLE		"helical_angle"
#define CHANs_GEAR_DOUBLE_HELICAL		"double_helical"

#define CHANs_GEAR_TOOTH_FACE_RATIO		"tooth_face_ratio"
#define CHANs_GEAR_TOOTH_TILT_ANGLE		"tooth_tilt_angle"
#define CHANs_GEAR_TOOTH_GROWTH			"tooth_growth"

/*
 * Affects how finely the geometry is tessellated.
 */
#define CHANs_GEAR_RESOLUTION			"resolution"

/*
 * ---------------------------------------------------------------------------
 * Message table.
 */

const char* GEAR_ITEM_MSG_TABLE = "gear.item";

// The name of the Gear item.
const unsigned GEAR_ITEM_MSG_NAME = 1;

// Disabled channel messages.
const unsigned GEAR_ITEM_MSG_SPOKE_OPTIONS_SPOKES_ENABLED = 1001;
const unsigned GEAR_ITEM_MSG_SPOKE_OPTIONS_TEETH_INSIDE = 1002;
const unsigned GEAR_ITEM_MSG_RIM_INSET_RIM_ENABLED = 1003;
const unsigned GEAR_ITEM_MSG_TEETH_FACING_OUTSIDE = 1004;

/*
 * ---------------------------------------------------------------------------
 * Vertex maps.
 */

/*
 * The default UV and dPdu vertex map name.
 */
#define VMAPs_UV_DPDU			"Texture"

typedef enum
{
        WINDING_ORDER_CLOCKWISE,
        WINDING_ORDER_COUNTERCLOCKWISE
} WindingOrder;

/*
 * ---------------------------------------------------------------------------
 * Min and max channel value hints.
 */

static LXtTextValueHint hint_Coverage[] = {
        0,			"%min",		// float min 0.0
        10000,			"%max",		// float max 1.0
        -1,			NULL
        };

static LXtTextValueHint hint_ToothSpacing[] = {
        1,			"%min",		// float min 0.0001
        -1,			NULL
        };

static LXtTextValueHint hint_Teeth[] = {
        4,			"&min",		// integer min 4
        -1,			NULL
        };

static LXtTextValueHint hint_Thickness[] = {
        1,			"%min",		// float min 0.0001
        -1,			NULL
        };

const int FORTYFIVE_DEGREES	= static_cast<int>(10000 * 45);

static LXtTextValueHint hint_ContactAngle[] = {
        0,			"%min",		// float min 0.0
        FORTYFIVE_DEGREES,	"%max",		// float max 45.0
        -1,			NULL
        };

static LXtTextValueHint hint_shaft[] = {
        0,			"%min",		// float min 0.0
        -1,			NULL
        };

static LXtTextValueHint hint_RimInsetRatio[] = {
        100,			"%min",		// float min 1.0
        80000,			"%max",		// float min 800.0
        -1,			NULL
        };

static LXtTextValueHint hint_WallInsetRatio[] = {
        500,			"%min",		// float min 5.0
        9900,			"%max",		// float min 99.0
        -1,			NULL
        };

static LXtTextValueHint hint_AxialShaftInsetRatio[] = {
        0,			"%min",		// float min 0.0
        80000,			"%max",		// float min 800.0
        -1,			NULL
        };

static LXtTextValueHint hint_RadialShaftInsetRatio[] = {
        0,			"%min",		// float min 0.0
        20000,			"%max",		// float min 200.0
        -1,			NULL
        };

static LXtTextValueHint hint_SpokeInsetRatio[] = {
        100,			"%min",		// float min 1.0
        10000,			"%max",		// float min 100.0
        -1,			NULL
        };

static LXtTextValueHint hint_SpokeSweepRatio[] = {
        500,			"%min",		// float min 5.0
        18000,			"%max",		// float min 180.0
        -1,			NULL
        };

const int NINETY_DEGREES	= static_cast<int>(10000 * 90);

static LXtTextValueHint hint_SpokeSwirlAngle[] = {
        -NINETY_DEGREES,	"%min",		// float min -90.0
        NINETY_DEGREES,		"%max",		// float max 90.0
        -1,			NULL
        };

static LXtTextValueHint hint_teethFacing[] = {
        TEETH_FACING_OUTSIDE,   "FacingOutside",
        TEETH_FACING_INSIDE,    "FacingInside",
//      TEETH_FACING_CROWN,     "FacingCrown", // [TODO]
        -1,                     NULL
        };

static LXtTextValueHint hint_BevelAngle[] = {
        0,			"%min",		// float min 0.0  [TODO] allow -45
        FORTYFIVE_DEGREES,	"%max",		// float max 45.0 
        -1,			NULL
        };

static LXtTextValueHint hint_HelicalAngle[] = {
        -FORTYFIVE_DEGREES,	"%min",		// float min -45.0 (in radians)
        FORTYFIVE_DEGREES,	"%max",		// float max 45.0 (in radians)
        -1,			NULL
        };

static LXtTextValueHint hint_Spokes[] = {
        2,			"&min",		// integer min 2
        -1,			NULL
        };

static LXtTextValueHint hint_ToothTiltAngle[] = {
        -FORTYFIVE_DEGREES,	"%min",		// float min -45.0 (in radians)
        FORTYFIVE_DEGREES,	"%max",		// float max 45.0 (in radians)
        -1,			NULL
        };

static LXtTextValueHint hint_ToothGrowth[] = {
        0,			"%min",		// float min 0.0
        -1,			NULL
        };

static LXtTextValueHint hint_Resolution[] = {
        1,			"&min",		// integer min 1
        32,			"&max",		// integer min 1
        -1,			NULL
        };

/*
 * ---------------------------------------------------------------------------
 * Gear Part Tags.
 */
#define GEAR_PART_TAG_TEETH	"Gear Teeth"
#define GEAR_PART_TAG_RIM	"Gear Rim"
#define GEAR_PART_TAG_SPOKES	"Gear Spokes"
#define GEAR_PART_TAG_SHAFT	"Gear Shaft"

#if defined(CORE_IMPLEMENTED)
#define GEAR_PART_TAG_CORE	"Gear Core"
#endif

/*
 * ----------------------------------------------------------------
 * GearPart
 */

        static void
CalcToothRadii (
        double		 toothSpacing,
        unsigned	 teeth,
        unsigned	 teethFacing,
        double		&outerToothRadius,
        double		&innerToothRadius)
{
        if (teethFacing == TEETH_FACING_OUTSIDE) {
                outerToothRadius = toothSpacing * teeth / PI / 2;
                innerToothRadius = outerToothRadius - toothSpacing / 2;
        }
        else if (teethFacing == TEETH_FACING_INSIDE) {
                innerToothRadius = toothSpacing * teeth / PI / 2;
                outerToothRadius = innerToothRadius - toothSpacing / 2;
        }
}

        static double
CalcMaxRadius (
        double		 tooth_spacing,
        unsigned	 teeth,
        double		 thickness,
        unsigned	 teethFacing,
        double		 wallInsetRatio,
        double		 bevelAngle,
        double		 toothGrowth)
{
        double outerRad, innerRad;
        CalcToothRadii (tooth_spacing, teeth, teethFacing, outerRad, innerRad);

        double scaledOuterRadius;
        if (teethFacing == TEETH_FACING_OUTSIDE) {
                scaledOuterRadius = innerRad + (outerRad - innerRad) * toothGrowth;
        }
        else {
                double maxBevelRadiusOffset = innerRad;

                /*
                 * Calculate the bevel radius offset, solving for the adjacent side.
                 */
                double gearHeight = thickness * 2;
                double bevelRadiusOffset = gearHeight / tan (HALF_PI - bevelAngle);
                bevelRadiusOffset = LXxMIN (bevelRadiusOffset, maxBevelRadiusOffset);
                bevelRadiusOffset = -bevelRadiusOffset;

                double beveledInnerToothRadius = innerRad - bevelRadiusOffset;
                double innerWallRadius = beveledInnerToothRadius * (1.0 + (1.0 - wallInsetRatio));
                scaledOuterRadius = innerWallRadius;
        }

        /*
         * We divide by the max radius in numerous places,
         * so set a minimum size for safety.
         */
        const double MIN_RADIUS = 0.000001;
        scaledOuterRadius = LXxMAX (scaledOuterRadius, MIN_RADIUS);

        return scaledOuterRadius;
}

        double
CGearPart::MaxRadius ()
{
        return CalcMaxRadius (
                tooth_spacing, m_teeth, m_thickness,
                teeth_facing,
                wall_inset_ratio,
                bevel_angle, tooth_growth);
}

        LxResult
CGearPart::Bound (
        LXtTableauBox		 bbox)
{
        double halfThickness = m_thickness / 2.0;
        float maxRadius, maxThickness;
        if ((m_part != GEARPART_RIM && m_part != GEARPART_SPOKES) ||
                (m_part == GEARPART_SPOKES && (m_spokes > 0)) ||
                (m_part == GEARPART_RIM && has_rim)) {
                maxRadius = static_cast<float>(MaxRadius ());
                double maxRatio = LXxMAX (rim_inset_ratio, axial_shaft_inset_ratio);
                maxThickness = static_cast<float>(LXxMAX (
                        halfThickness, halfThickness * maxRatio));
        }
        else {
                maxRadius = 0;
                maxThickness = 0;
        }

        bbox[0] = -maxRadius;
        bbox[1] = -maxRadius;
        bbox[2] = -maxThickness;
        bbox[3] =  maxRadius;
        bbox[4] =  maxRadius;
        bbox[5] =  maxThickness;

        return LXe_OK;
}

        unsigned
CGearPart::FeatureCount (
        LXtID4			 type)
{
        unsigned count = 0;

        if (type == LXiTBLX_BASEFEATURE) {
                count = BASE_FEATURE_COUNT;
        }
        else if ((type == LXi_VMAP_TEXTUREUV) || (type == LXiTBLX_DPDU)) {
                count = 1;
        }

        return count;
}

        LxResult
CGearPart::FeatureByIndex (
        LXtID4			 type,
        unsigned		 index,
        const char	       **name)
{
        LxResult	result = LXe_NOTFOUND;

        if (type == LXiTBLX_BASEFEATURE) {
                switch (index) {
                    case FEATURE_POSITION:
                        name[0] = LXsTBLX_FEATURE_POS;
                        return LXe_OK;

                    case FEATURE_OBJECT_POSITION:
                        name[0] = LXsTBLX_FEATURE_OBJPOS;
                        return LXe_OK;

                    case FEATURE_NORMAL:
                        name[0] = LXsTBLX_FEATURE_NORMAL;
                        return LXe_OK;

                    case FEATURE_VELOCITY:
                        name[0] = LXsTBLX_FEATURE_VEL;
                        return LXe_OK;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }
        else if (type == LXi_VMAP_TEXTUREUV) {
                if (index == 0) {
                        name[0] = VMAPs_UV_DPDU;
                        result = LXe_OK;
                }
                else {
                        result = LXe_OUTOFBOUNDS;
                }
        }
        else if (type == LXiTBLX_DPDU) {
                if (index == 0) {
                        name[0] = VMAPs_UV_DPDU;
                        result = LXe_OK;
                }
                else {
                        result = LXe_OUTOFBOUNDS;
                }
        }
        return result;
}

        LxResult
CGearPart::SetVertex (
        ILxUnknownID		 vdesc)
{
        LxResult		 result = LXe_NOINTERFACE;
        const char		*name;
        unsigned		 offset, i;

        hasUVs = false;
        max_f_pos = 0;
        if (vrt_desc.set (vdesc)) {
                result = LXe_OK;

                for (i = 0; i < BASE_FEATURE_COUNT; i++) {
                        result = FeatureByIndex (LXiTBLX_BASEFEATURE, i, &name);
                        result = vrt_desc.Lookup (LXiTBLX_BASEFEATURE, name, &offset);
                        f_pos[i] = (result == LXe_OK ? offset : -1);
                }
                if (LXx_OK (result)) {
                        max_f_pos = offset;
                        max_f_type = FEATURE_VELOCITY;
                        result = FeatureByIndex (LXi_VMAP_TEXTUREUV, 0, &name);
                        if (LXx_OK (result)) {
                                /*
                                 * UVs are optional, so for efficency, they are
                                 * only calculated for shaders upon demand.
                                 */
                                result = vrt_desc.Lookup (LXi_VMAP_TEXTUREUV, name, &offset);
                                if (LXx_OK (result)) {
                                        f_pos[i++] = (result == LXe_OK ? offset : -1);

                                        if (LXx_OK (result)) {
                                                if (offset > max_f_pos) {
                                                        max_f_pos = offset;
                                                        max_f_type = FEATURE_UV;
                                                }
                                                result = FeatureByIndex (LXiTBLX_DPDU, 0, &name);
                                                result = vrt_desc.Lookup (LXiTBLX_DPDU, name, &offset);
                                                f_pos[i++] = (result == LXe_OK ? offset : -1);
                                                hasUVs = LXx_OK (result);
                                                if (LXx_OK (result) &&
                                                    (offset > max_f_pos)) {
                                                        max_f_pos = offset;
                                                        max_f_type = FEATURE_DPDU;
                                                }
                                        }
                                }
                                else if (result == LXe_NOTFOUND) {
                                        /*
                                         * If the UVs are not found, it's not
                                         * a fatal error, so we translate the
                                         * error code into a passable result.
                                         */
                                        result = LXe_FALSE;
                                }
                        }
                }
        }

        return result;
}

/*
 * Calculate geometry-related values useful for constructing the gear.
 */
        static void
BuildGearConstruct (
        GearGeometry		&gear,
        unsigned		 teeth,
        double			 coverage,
        double			 shaftRad,
        double			 innerToothRad,
        double			 outerToothRad,
        double			 halfThickness,
        double			 rimInsetRatio,
        double			 wallInsetRatio,
        double			 axialShaftInsetRatio,
        double			 radialShaftInsetRatio,
        double			 innerSpokeInsetRatio,
        double			 outerSpokeInsetRatio,
        double			 contactAngle,
        unsigned		 teethFacing,
        double			 bevelAngle,
        double			 helicalAngle,
        double			 toothFaceRatio,
        double			 toothTiltAngle,
        double			 toothGrowth)
{
        gear.teeth = teeth;
        gear.contactRatio = contactAngle / QUARTER_PI;
        gear.innerSpokeRad = shaftRad * (1.0 + radialShaftInsetRatio);

        /*
         * Pin the inner spoke radius against the inner tooth radius.
         */
        gear.innerSpokeRad = LXxMIN (gear.innerSpokeRad, innerToothRad);

        /*
         * Calculate the maximum bevel offset, to prevent the bevel from
         * intruding into the rim surrounding the gear shaft.
         */
        double maxBevelRadiusOffset = innerToothRad - gear.innerSpokeRad;
        double gearHeight = halfThickness * 2;

        /*
         * Calculate the bevel radius offset, solving for the adjacent side.
         */
        gear.bevelRadiusOffset = gearHeight / tan (HALF_PI - bevelAngle);
        gear.bevelRadiusOffset = LXxMIN (gear.bevelRadiusOffset, maxBevelRadiusOffset);
        if (teethFacing == TEETH_FACING_INSIDE) {
                gear.bevelRadiusOffset = -gear.bevelRadiusOffset;
        }

        gear.scaledOuterRadius = innerToothRad + (outerToothRad - innerToothRad) * toothGrowth;
        gear.upperBeveledScaledOuterRadius = gear.scaledOuterRadius - gear.bevelRadiusOffset;
        gear.lowerBeveledScaledOuterRadius = gear.upperBeveledScaledOuterRadius +
                (gear.scaledOuterRadius - gear.upperBeveledScaledOuterRadius) * toothFaceRatio;

        gear.beveledInnerToothRadius = innerToothRad - gear.bevelRadiusOffset;
        gear.toothTiltAngle = toothTiltAngle;
        if (teethFacing == TEETH_FACING_INSIDE) {
                gear.innerWallRadius = gear.beveledInnerToothRadius * (1.0 + (1.0 - wallInsetRatio));
        }
        else {
                gear.innerWallRadius = gear.beveledInnerToothRadius * wallInsetRatio;
        }
        gear.outerSpokeRad = gear.innerWallRadius + (gear.beveledInnerToothRadius - gear.innerWallRadius) / 2.0;

        gear.coveredToothCount = static_cast<unsigned>(teeth * coverage);
        gear.scaledThickness = halfThickness * toothFaceRatio;
        gear.rimThickness = halfThickness * rimInsetRatio;
        gear.axialShaftRimThickness = halfThickness * axialShaftInsetRatio;
        gear.inner_spoke_thickness = LXxMIN (gear.axialShaftRimThickness, halfThickness * innerSpokeInsetRatio);
        gear.outer_spoke_thickness = halfThickness * outerSpokeInsetRatio;
}

/*
 * Calculate geometry-related values for constructing the teeth of the gear.
 */
        static void
BuildToothConstruct (
        GearGeometry		&gear,
        unsigned		 toothIndex)
{
        // the leading tooth apex angle
        gear.apex_angle_0 = TWO_PI * toothIndex / gear.teeth;
        gear.apex_angle_12 = TWO_PI * (toothIndex + 1) / gear.teeth;

        // inner tooth - calculated before tilt is applied
        gear.inner_angle = gear.apex_angle_0 + (PI / gear.teeth);

        // contact angles at halfway points
        gear.contact_angle_E = gear.apex_angle_0 + (gear.inner_angle - gear.apex_angle_0) * 0.5;
        gear.contact_angle_N = gear.inner_angle + (gear.apex_angle_12 - gear.inner_angle) * 0.5;

        // leading and trailing edges of contact angles driven by channel
        gear.contact_angle_2 = gear.contact_angle_E - (gear.contact_angle_E - gear.apex_angle_0) * gear.contactRatio;
        gear.contact_angle_4 = gear.contact_angle_E + (gear.inner_angle - gear.contact_angle_E) * gear.contactRatio;

        gear.contact_angle_8 = gear.contact_angle_N - (gear.contact_angle_N - gear.inner_angle) * gear.contactRatio;
        gear.contact_angle_10 = gear.contact_angle_N + (gear.apex_angle_12 - gear.contact_angle_N) * gear.contactRatio;

        gear.contact_angle_2 += gear.toothTiltAngle;
        gear.contact_angle_10 += gear.toothTiltAngle;
        gear.apex_angle_0 += gear.toothTiltAngle;
        gear.apex_angle_12 += gear.toothTiltAngle;
}

        LxResult
CGearPart::Sample (
        const LXtTableauBox	 bbox,
        float			 scale,
        ILxUnknownID		 trisoup)
{
        CLxUser_TriangleSoup	 soup (trisoup);
        LXtTableauBox		 box;
        double			 halfThickness = m_thickness / 2;
        LxResult		 result;

        double outerToothRadius, innerToothRadius;
        CalcToothRadii (tooth_spacing, m_teeth, teeth_facing, outerToothRadius, innerToothRadius);
        BuildGearConstruct (
                *this, m_teeth, m_coverage, m_shaft,
                innerToothRadius, outerToothRadius, halfThickness,
                rim_inset_ratio, wall_inset_ratio,
                axial_shaft_inset_ratio, radial_shaft_inset_ratio,
                inner_spoke_inset_ratio, outer_spoke_inset_ratio,
                contact_angle, teeth_facing, bevel_angle, helical_angle,
                tooth_face_ratio, tooth_tilt_angle, tooth_growth);

        /*
         * Return early if the bounding box (as determined by our radius
         * channel value) isn't visible.
         */
        float radius = static_cast<float>(scaledOuterRadius);
        box[0] = -radius;
        box[1] = -radius;
        box[2] =  static_cast<float>(-halfThickness);
        box[3] =  radius;
        box[4] =  radius;
        box[5] =  static_cast<float>(halfThickness);

        if (!soup.TestBox (box))
                return LXe_OK;

        unsigned segmentID = 1;

        /*
         * Prepare to build the first segment.
         */
        result = soup.Segment (segmentID++, LXiTBLX_SEG_TRIANGLE);
        if (result == LXe_FALSE)
                return LXe_OK;
        else if (LXx_FAIL (result))
                return result;

        /*
         * Build the triangle lists for the segments
         * corresponding to this part.
         */
        switch (m_part) {
                case GEARPART_TEETH:
                        result = SampleGearPartTeeth (soup, segmentID);
                        break;

                case GEARPART_SPOKES:
                        if (m_spokes &&
                            (teeth_facing != TEETH_FACING_INSIDE)) {
                                result = SampleGearPartSpokes (soup, segmentID);
                        }
                        break;

                case GEARPART_RIM:
                        if (has_rim &&
                            (teeth_facing != TEETH_FACING_INSIDE)) {
                                result = SampleGearPartRim (soup, segmentID);
                        }
                        break;

                case GEARPART_SHAFT:
                        if (teeth_facing != TEETH_FACING_INSIDE) {
                                result = SampleGearPartShaft (soup, segmentID);
                        }
                        break;
#if defined(CORE_IMPLEMENTED)
                case GEARPART_CORE:
                        if (m_coverage < 1.0) {
                                result = SampleGearPartCore (soup, segmentID);
                        }
                        break;
#endif
        }

        return result;
}

/*
 * Part configuration.
 */
        void
CGearPart::SetPart (unsigned part)
{
        m_part = part;

        hasUVs = false;
}

        static bool
ReadFloatChannel (
        CLxUser_Item		&m_item,
        CLxUser_ChannelRead	&chanRead,
        const char		*chanName,
        double			&chanValue)
{
        bool channelFound(true);

        int chanIndex = m_item.ChannelIndex (chanName);
        if (chanIndex < 0) {
                channelFound = false;
        }
        else {
                chanValue = chanRead.FValue (m_item, chanIndex);
        }

        return channelFound;
}

        static bool
ReadUnsignedChannel (
        CLxUser_Item		&m_item,
        CLxUser_ChannelRead	&chanRead,
        const char		*chanName,
        unsigned		&chanValue)
{
        bool channelFound(true);

        int chanIndex = m_item.ChannelIndex (chanName);
        if (chanIndex < 0) {
                channelFound = false;
        }
        else {
                chanValue = static_cast<unsigned>(chanRead.IValue (m_item, chanIndex));
        }

        return channelFound;
}

        LxResult
CGearPart::InitializePart (
        CLxUser_Item		&m_item,
        CLxUser_ChannelRead	&chanRead)
{
        bool			 hasSpokes;
        int			 idx;
        LxResult		 result = LXe_OK;

        /*
         * Fetch our custom channel values.
         */
        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_COVERAGE, m_coverage))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_SPACING, tooth_spacing))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_CONTACT_ANGLE, contact_angle))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_THICKNESS, m_thickness))
                return LXe_NOTFOUND;

        if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_TEETH, m_teeth))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_SHAFT, m_shaft))
                return LXe_NOTFOUND;

        idx = m_item.ChannelIndex (CHANs_GEAR_HAS_SPOKES);
        if (idx < 0)
                return LXe_NOTFOUND;
        hasSpokes = chanRead.IValue (m_item, idx) != 0;

        if (hasSpokes) {
                if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_SPOKES, m_spokes))
                        return LXe_NOTFOUND;
        }
        else {
                m_spokes = 0;
        }

        idx = m_item.ChannelIndex (CHANs_GEAR_HAS_RIM);
        if (idx < 0)
                return LXe_NOTFOUND;
        has_rim = chanRead.IValue (m_item, idx) != 0;

        if (has_rim) {
                if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_RIM_INSET_RATIO, rim_inset_ratio))
                        return LXe_NOTFOUND;
        }
        else {
                rim_inset_ratio = 0.0;
        }

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_WALL_INSET_RATIO, wall_inset_ratio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO, axial_shaft_inset_ratio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO, radial_shaft_inset_ratio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_INNER_SPOKE_INSET_RATIO, inner_spoke_inset_ratio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_OUTER_SPOKE_INSET_RATIO, outer_spoke_inset_ratio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_SPOKE_SWEEP_RATIO, spoke_sweep_ratio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_SPOKE_SWIRL_ANGLE, spoke_swirl_angle))
                return LXe_NOTFOUND;

        if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_TEETH_FACING, teeth_facing))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_BEVEL_ANGLE, bevel_angle))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_HELICAL_ANGLE, helical_angle))
                return LXe_NOTFOUND;

        idx = m_item.ChannelIndex (CHANs_GEAR_DOUBLE_HELICAL);
        if (idx < 0)
                return LXe_NOTFOUND;
        double_helical = chanRead.IValue (m_item, idx) != 0;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_FACE_RATIO, tooth_face_ratio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_TILT_ANGLE, tooth_tilt_angle))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_GROWTH, tooth_growth))
                return LXe_NOTFOUND;

        if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_RESOLUTION, m_resolution))
                return LXe_NOTFOUND;

        max_radius = MaxRadius ();

        return result;
}

        LxResult
CGearPart::InitializePart (
        double		coverage,
        double		toothSpacing,
        double		contactAngle,
        double		thickness,
        unsigned	teeth,
        double		shaft,
        unsigned	spokes,
        bool		hasRim,
        double		rimInsetRatio,
        double		wallInsetRatio,
        double		axialShaftInsetRatio,
        double		radialShaftInsetRatio,
        double		innerSpokeInsetRatio,
        double		outerSpokeInsetRatio,
        double		spokeSweepRatio,
        double		spokeSwirlAngle,
        unsigned	teethFacing,
        double		bevelAngle,
        double		helicalAngle,
        bool		doubleHelical,
        double		toothFaceRatio,
        double		toothTiltAngle,
        double		toothGrowth,
        unsigned	resolution,
        double		maxRadius)
{
        m_coverage = coverage;
        tooth_spacing = toothSpacing;
        contact_angle = contactAngle;
        m_thickness = thickness;
        m_teeth = teeth;
        m_shaft = shaft;
        m_spokes = spokes;

        has_rim = hasRim;
        rim_inset_ratio = rimInsetRatio;
        wall_inset_ratio = wallInsetRatio;
        axial_shaft_inset_ratio = axialShaftInsetRatio;
        radial_shaft_inset_ratio = radialShaftInsetRatio;
        inner_spoke_inset_ratio = innerSpokeInsetRatio;
        outer_spoke_inset_ratio = outerSpokeInsetRatio;
        spoke_sweep_ratio = spokeSweepRatio;
        spoke_swirl_angle = spokeSwirlAngle;

        teeth_facing = teethFacing;
        bevel_angle = bevelAngle;
        helical_angle = helicalAngle;
        double_helical = doubleHelical;
        tooth_face_ratio = toothFaceRatio;
        tooth_tilt_angle = toothTiltAngle;
        tooth_growth = toothGrowth;

        m_resolution = resolution;

        max_radius = maxRadius;

        return LXe_OK;
}

static const unsigned MAX_TRIANGLE_COUNT = 1024 * 1024;

        static void
CopyTriangles (
        std::vector<unsigned>	&triangles,
        unsigned		 basePointIndex,
        unsigned		 pointCount,
        int			*indices,
        WindingOrder		 windingOrder = WINDING_ORDER_COUNTERCLOCKWISE)
{
        unsigned triangleIndex = 0;
        bool anotherTriangle = true;
        do {
                for (unsigned subIndex = 0; subIndex < 3; ++subIndex) {
                        int pointIndex;
                        if (windingOrder == WINDING_ORDER_COUNTERCLOCKWISE) {
                                pointIndex = indices[triangleIndex * 3 + subIndex];
                        }
                        else {
                                pointIndex = indices[triangleIndex * 3 + (2 - subIndex)];
                        }
                        if (pointIndex != -1) {
                                triangles.push_back ((basePointIndex + pointIndex) % pointCount);
                        }
                        else {
                                anotherTriangle = false;
                                break;
                        }
                }
                if (anotherTriangle) {
                        ++triangleIndex;
                }
        } while (anotherTriangle && triangleIndex < MAX_TRIANGLE_COUNT);
}

/*
 * Batch a list of triangles into the given soup.
 */
        static LxResult
BrewBigSoup (
        CLxUser_TriangleSoup	&soup,
        std::vector<unsigned>	 triangles,
        WindingOrder		 windingOrder = WINDING_ORDER_COUNTERCLOCKWISE)
{
        LxResult	result = LXe_OK;

        unsigned triangle[3];
        bool connect = true;
        for (unsigned triIndex = 0; triIndex < triangles.size (); triIndex += 3) {
                for (unsigned subIndex = 0; subIndex < 3; ++subIndex) {
                        int pointIndex = triangles[triIndex + subIndex];
                        triangle[subIndex] = pointIndex;
                }
                if (windingOrder == WINDING_ORDER_COUNTERCLOCKWISE) {
                        result = soup.Polygon (triangle[0], triangle[1], triangle[2]);
                }
                else {
                        result = soup.Polygon (triangle[2], triangle[1], triangle[0]);
                }
                if (connect) {
                        soup.Connect (LXiTBLX_CONNECT_QUAD);
                }
                connect = !connect;
        }

        return result;
}


        LxResult
CGearPart::SampleGearPartTeeth (
        CLxUser_TriangleSoup	&soup,
        unsigned		&segmentID)
{
        unsigned		 i, k;
        LxResult		 result;

        double outerToothRadius, innerToothRadius;
        CalcToothRadii (tooth_spacing, m_teeth, teeth_facing, outerToothRadius, innerToothRadius);

        /*
         * Build the first vertex list for the teeth.
         */
        unsigned	pointCount = 0;
        unsigned	pointStride;
        std::vector<GeoPoint>	points;
        std::vector<GeoUV>		uvs;
        std::vector<GeoPoint>	dPdus, dPdvs;
        double		halfThickness = m_thickness / 2;
        for (i = 0; i <= coveredToothCount; ++i) {
                BuildToothConstruct (*this, i);

                PushBeveledHelicalToothRenderPoints (
                        1, 2, 1, // 0; 1,2; 3
                        apex_angle_0 + helical_angle,
                        apex_angle_0,
                        upperBeveledScaledOuterRadius,
                        lowerBeveledScaledOuterRadius,
                        scaledThickness,
                        points, uvs);

                PushBeveledHelicalToothRenderPoints (
                        2, 4, 2, // 4,5; 6,7,8,9; 10,11
                        contact_angle_2 + helical_angle,
                        contact_angle_2,
                        upperBeveledScaledOuterRadius,
                        lowerBeveledScaledOuterRadius,
                        scaledThickness,
                        points, uvs);

                PushBeveledHelicalToothRenderPoints (
                        2, 4, 2, // 12,13; 14,15,16,17; 18,19
                        contact_angle_4 + helical_angle,
                        contact_angle_4,
                        beveledInnerToothRadius, innerToothRadius,
                        halfThickness,
                        points, uvs);

                PushBeveledHelicalToothRenderPoints (
                        1, 2, 1, // 20; 21,22; 23
                        inner_angle + helical_angle,
                        inner_angle,
                        beveledInnerToothRadius, innerToothRadius,
                        halfThickness,
                        points, uvs);

                PushBeveledHelicalToothRenderPoints (
                        2, 4, 2, // 24,25; 26,27,28,29; 30,31
                        contact_angle_8 + helical_angle,
                        contact_angle_8,
                        beveledInnerToothRadius, innerToothRadius,
                        halfThickness,
                        points, uvs);

                PushBeveledHelicalToothRenderPoints (
                        2, 4, 2, // 32,33; 34,35,36,37; 38,39
                        contact_angle_10 + helical_angle,
                        contact_angle_10,
                        upperBeveledScaledOuterRadius,
                        lowerBeveledScaledOuterRadius,
                        scaledThickness,
                        points, uvs);

                if (i == 0) {
                        pointStride = static_cast<unsigned>(points.size ());
                }
        }
        pointCount = static_cast<unsigned>(points.size ());

        std::vector<unsigned> triangles;
        k = 0;
        for (i = 0; i < coveredToothCount; ++i) {
                /*
                 * The teeth.
                 */
                if (double_helical) {
                        /*
                         * See "GearGraph.pdf" for vertex and edge labeling.
                         */
                        static int triangles_dh[] = {
                                0, 4, 6,	// a
                                0, 6, 1,	// b
                                2, 8, 10,	// c
                                2, 10, 3,	// d
                                5, 13, 15,	// e
                                5, 15, 7,	// f
                                9, 17, 19,	// g
                                9, 19, 11,	// h
                                12, 20, 21,	// i
                                12, 21, 14,	// j
                                16, 22, 23,	// k
                                16, 23, 18,	// l
                                20, 24, 26,	// m
                                20, 26, 21,	// n
                                22, 28, 30,	// o
                                22, 30, 23,	// p
                                25, 33, 35,	// q
                                25, 35, 27,	// r
                                29, 37, 39,	// s
                                29, 39, 31,	// t
                                32, 40, 41,	// u
                                32, 41, 34,	// v
                                36, 42, 43,	// w
                                36, 43, 38,	// x
                                -1, -1, -1
                        };

                        CopyTriangles (triangles, k, pointCount, &triangles_dh[0],
                                (teeth_facing == TEETH_FACING_OUTSIDE) ?
                                        WINDING_ORDER_COUNTERCLOCKWISE :
                                        WINDING_ORDER_CLOCKWISE);
                }
                else {
                        /*
                         * See "GearGraph.pdf" for vertex and edge labeling.
                         */
                        static int triangles_sh[] = {
                                0, 2, 4,	// a
                                0, 4, 1,	// b
                                3, 7, 9,	// c
                                3, 9, 5,	// d
                                6, 10, 11,	// e
                                6, 11, 8,	// f
                                10, 12, 14,	// g
                                10, 14, 11,	// h
                                13, 17, 19,	// i
                                13, 19, 15,	// j
                                16, 20, 21,	// k
                                16, 21, 18,	// l
                                -1, -1, -1
                        };

                        CopyTriangles (triangles, k, pointCount, &triangles_sh[0],
                                (teeth_facing == TEETH_FACING_OUTSIDE) ?
                                        WINDING_ORDER_COUNTERCLOCKWISE :
                                        WINDING_ORDER_CLOCKWISE);
                }

                k += pointStride;
        }

        /*
         * Generate the normals using our point and triangle list.
         */
        std::vector<GeoPoint> normals;
        GenerateNormals (points, triangles, normals);

        if (hasUVs) {
                /*
                 * Generate the vertex dPdu/dPdv values using our point, uv, and point lists.
                 */
                GenerateDPDUs (points, uvs, triangles, dPdus, dPdvs);
        }

        /*
         * Pre-populate an array of zero-length velocities.
         */
        std::vector<GeoPoint> velocities;
        GeoPoint	zeroVec;
        LXx_VCLR (zeroVec.vec);
        for (unsigned vecIndex = 0; vecIndex < pointCount; ++vecIndex) {
                velocities.push_back (zeroVec);
        }

        /*
         * Call the big soup brewer, to process all of the teeth in a single batch.
         */
        PushVertexFeatures (soup, points, normals, velocities, uvs, dPdus, dPdvs);
        result = BrewBigSoup (soup, triangles);
        if (LXx_FAIL(result)) {
                return result;
        }

        /*
         * The second and third segments contain the upper and lower
         * walls between the teeth and the edge of the rim and spoke
         * assembly.
         *
         * See the page "PART VIEW: TEETH WALL" in the Gear Item graph
         * diagram "GearGraph.pdf" for the details of these segments.
         */
        for (Layer layer = LAYER_UPPER; layer <= LAYER_LOWER;) {
                points.clear ();
                velocities.clear ();
                uvs.clear ();
                triangles.clear ();

                result = soup.Segment (segmentID++, LXiTBLX_SEG_TRIANGLE);
                if (result == LXe_FALSE)
                        return LXe_OK;
                else if (LXx_FAIL (result))
                        return result;

                pointCount = 0; // Reset the point count for each segment.
                for (i = 0; i <= coveredToothCount; ++i) {
                        BuildToothConstruct (*this, i);

                        PushWallBeveledHelicalRenderPoints (1,
                                apex_angle_0 + helical_angle,
                                apex_angle_0,
                                upperBeveledScaledOuterRadius,
                                lowerBeveledScaledOuterRadius,
                                scaledThickness, layer,
                                points, uvs); // 0

                        PushWallBeveledHelicalRenderPoints (2,
                                apex_angle_0 + helical_angle,
                                apex_angle_0,
                                beveledInnerToothRadius,
                                innerToothRadius,
                                halfThickness, layer,
                                points, uvs); // 1,2

                        PushWallBeveledHelicalRenderPoints (1,
                                apex_angle_0 + helical_angle,
                                apex_angle_0,
                                innerWallRadius,
                                innerWallRadius,
                                halfThickness, layer,
                                points, uvs); // 3

                        PushWallBeveledHelicalRenderPoints (1,
                                contact_angle_2 + helical_angle,
                                contact_angle_2,
                                upperBeveledScaledOuterRadius,
                                lowerBeveledScaledOuterRadius,
                                scaledThickness, layer,
                                points, uvs); // 4

                        PushWallBeveledHelicalRenderPoints (2,
                                contact_angle_4 + helical_angle,
                                contact_angle_4,
                                beveledInnerToothRadius,
                                innerToothRadius,
                                halfThickness, layer,
                                points, uvs); // 5,6

                        PushWallBeveledHelicalRenderPoints (1,
                                contact_angle_E + helical_angle,
                                contact_angle_E,
                                innerWallRadius,
                                innerWallRadius,
                                halfThickness, layer,
                                points, uvs); // 7

                        PushWallBeveledHelicalRenderPoints (1,
                                inner_angle + helical_angle,
                                inner_angle,
                                beveledInnerToothRadius,
                                innerToothRadius,
                                halfThickness, layer,
                                points, uvs); // 8

                        PushWallBeveledHelicalRenderPoints (1,
                                inner_angle + helical_angle,
                                inner_angle,
                                innerWallRadius,
                                innerWallRadius,
                                halfThickness, layer,
                                points, uvs); // 9

                        PushWallBeveledHelicalRenderPoints (1,
                                contact_angle_10 + helical_angle,
                                contact_angle_10,
                                upperBeveledScaledOuterRadius,
                                lowerBeveledScaledOuterRadius,
                                scaledThickness, layer,
                                points, uvs); // 10

                        PushWallBeveledHelicalRenderPoints (2,
                                contact_angle_8 + helical_angle,
                                contact_angle_8,
                                beveledInnerToothRadius,
                                innerToothRadius,
                                halfThickness, layer,
                                points, uvs); // 11,12

                        PushWallBeveledHelicalRenderPoints (1,
                                contact_angle_N + helical_angle,
                                contact_angle_N,
                                innerWallRadius,
                                innerWallRadius,
                                halfThickness, layer,
                                points, uvs); // 13

                        if (i == 0) {
                                pointStride = static_cast<unsigned>(points.size ());
                        }
                }
                pointCount = static_cast<unsigned>(points.size ());

                k = 0;
                for (i = 0; i < coveredToothCount; ++i) {
                        /*
                         * See "GearGraph.pdf" for vertex and edge labeling.
                         */
                        static int triangles_tw_upper[] = {
                                0, 1, 5,	// a
                                0, 5, 4,	// b
                                2, 3, 7,	// c
                                2, 7, 6,	// d
                                6, 7, 9,	// e
                                6, 9, 8,	// f
                                8, 9, 13,	// g
                                8, 13, 12,	// h
                                10, 11, 15,	// i
                                10, 15, 14,	// j
                                12, 13, 17,	// k
                                12, 17, 16,	// l
                                -1, -1, -1
                        };

                        static int triangles_tw_lower[] = {
                                1, 0, 4,	// a
                                1, 4, 5,	// b
                                3, 2, 6,	// c
                                3, 6, 7,	// d
                                7, 6, 8,	// e
                                7, 8, 9,	// f
                                9, 8, 12,	// g
                                9, 12, 13,	// h
                                11, 10, 14,	// i
                                11, 14, 15,	// j
                                13, 12, 16,	// k
                                13, 16, 17,	// l
                                -1, -1, -1
                        };

                        if (((layer == LAYER_UPPER) && (teeth_facing == TEETH_FACING_OUTSIDE)) ||
                            ((layer == LAYER_LOWER) && (teeth_facing == TEETH_FACING_INSIDE))) {
                                CopyTriangles (triangles, k, pointCount, &triangles_tw_upper[0]);
                        }
                        else {
                                CopyTriangles (triangles, k, pointCount, &triangles_tw_lower[0]);
                        }

                        k += pointStride;
                }

                GenerateNormals (points, triangles, normals);

                if (hasUVs) {
                        /*
                         * Generate the vertex dPdu/dPdv values using our point, uv, and point lists.
                         */
                        GenerateDPDUs (points, uvs, triangles, dPdus, dPdvs);
                }

                /*
                 * Pre-populate an array of zero-length velocities.
                 */
                GeoPoint	zeroVec;
                LXx_VCLR (zeroVec.vec);
                for (unsigned vecIndex = 0; vecIndex < pointCount; ++vecIndex) {
                        velocities.push_back (zeroVec);
                }

                /*
                 * Call the big soup brewer, to process all of the teeth in a single batch.
                 */
                PushVertexFeatures (soup, points, normals, velocities, uvs, dPdus, dPdvs);
                result = BrewBigSoup (soup, triangles);
                if (LXx_FAIL(result)) {
                        break;
                }

                if (layer == LAYER_LOWER) {
                        break;
                }
                else {
                        layer = LAYER_LOWER;
                }
        }

        if (rim_inset_ratio <= 1.0) {
                /*
                 * The fourth segment builds the outer rim edge,
                 * which is treated as part of the teeth part.
                 *
                 * [TODO] For a less distorted mesh, rotate by the helical angle?
                 */
                result = BrewRimSoup (soup, segmentID,
                        innerWallRadius, halfThickness,
                        (teeth_facing == TEETH_FACING_OUTSIDE) ?
                                RIM_FACING_INWARDS : RIM_FACING_OUTWARDS,
                        RIM_MAPPING_CONCENTRIC);
        }

        return result;
}

        LxResult
CGearPart::SampleGearPartRim (
        CLxUser_TriangleSoup	&soup,
        unsigned		&segmentID)
{
        LxResult	result = LXe_OK;

        if ((rim_inset_ratio != 1.0) ||
            (axialShaftRimThickness < rimThickness)) {
                /*
                 * The fifth segment builds the inner rim edge.
                 */
                result = BrewRimSoup (soup, segmentID,
                        innerSpokeRad,
                        rimThickness,
                        RIM_FACING_INWARDS);
        }

        if (LXx_OK (result)) {
                if (rim_inset_ratio != 1.0) {
                        /*
                         * The fourth segment builds the outer rim edge,
                         * which fits the rim against the teeth part.
                         */
                        result = BrewRimSoup (soup, segmentID,
                                (rim_inset_ratio >= 1.0) ?
                                        innerWallRadius : outerSpokeRad,
                                rimThickness,
                                RIM_FACING_OUTWARDS);
                }

                if (LXx_OK (result)) {
                        /*
                         * When the rim is inset and isn't flush with the
                         * inner teeth wall, make it protrude into the wall
                         * by the outer spoke radius, as is done with the
                         * spokes, for a clean intersection without gaps.
                         */
                        result = BrewRingSoup (
                                soup, segmentID,
                                (rim_inset_ratio >= 1.0) ?
                                        innerWallRadius : outerSpokeRad,
                                innerSpokeRad,
                                rimThickness,
                                rimThickness,
                                (rim_inset_ratio == 1.0) ?
                                        RING_MAPPING_INSET :
                                        RING_MAPPING_UNIT);
                }
        }

        return result;
}

        static void
CalcSpokeContactAngles (
        unsigned	 index,
        unsigned	 spokes,
        double		 spokeSweepRatio,
        double		&contactAngle2,
        double		&apexAngle0,
        double		&contactAngle10)
{
        double	 leadingInnerAngle, trailingInnerAngle;
        double	 contactAngleE, contactAngleN;

        // the leading spoke apex angle
        apexAngle0 = TWO_PI * index / spokes;

        // inner spoke angles
        leadingInnerAngle = apexAngle0 - (PI / spokes);
        trailingInnerAngle = apexAngle0 + (PI / spokes);

        // contact angles at halfway points
        contactAngleE = apexAngle0 + (trailingInnerAngle - apexAngle0) * 0.5;
        contactAngleN = leadingInnerAngle + (apexAngle0 - leadingInnerAngle) * 0.5;

        // leading and trailing edges of contact angles
        // driven by channel
        contactAngle2 = contactAngleE - (contactAngleE - apexAngle0) * spokeSweepRatio;
        contactAngle10 = contactAngleN + (apexAngle0 - contactAngleN) * spokeSweepRatio;
}

        LxResult
CGearPart::SampleGearPartSpokes (
        CLxUser_TriangleSoup	&soup,
        unsigned		&segmentID)
{
        LxResult		 result = LXe_OK;

        /*
         * Build another vertex list for the spokes.
         */
        std::vector<GeoPoint>	 points;
        std::vector<GeoUV>		 uvs;
        unsigned		 i, pointStride;

        /*
         * Start with a minimum of three segments, to add weight to the edges
         * near the end caps. Additional segments are then distributed
         * evenly within the remaining center span.
         */
        unsigned		 segmentCount = m_resolution + 2;

        for (i = 0; i < m_spokes; ++i) {
                double	 contactAngle2, apexAngle0, contactAngle10;
                CalcSpokeContactAngles (i, m_spokes, 1.0 - spoke_sweep_ratio,
                        contactAngle2, apexAngle0, contactAngle10);

                /*
                 * First push the end caps.
                 */
                PushSpokeEndCapRenderPoints (
                        contactAngle2, apexAngle0, contactAngle10,
                        outerSpokeRad, innerSpokeRad,
                        outer_spoke_thickness, inner_spoke_thickness,
                        points, uvs);

                /*
                 * Next, push the segment spans.
                 */

                // Top Edge
                PushSpokeSpanRenderPoints (
                        contactAngle10,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_UPPER, FACE_UPPER,
                        points, uvs); // 18 + (0, 1)

                PushSpokeSpanRenderPoints (
                        apexAngle0,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_UPPER, FACE_UPPER,
                        points, uvs); // 18 + (2, 3)

                PushSpokeSpanRenderPoints (
                        contactAngle2,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_UPPER, FACE_UPPER,
                        points, uvs); // 18 + (4, 5)

                // Trailing Edge
                PushSpokeSpanRenderPoints (
                        contactAngle2,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_UPPER, FACE_TRAILING,
                        points, uvs); // 18 + (6, 7)

                PushSpokeSpanRenderPoints (
                        contactAngle2,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_MIDDLE, FACE_TRAILING,
                        points, uvs); // 18 + (8, 9)

                PushSpokeSpanRenderPoints (
                        contactAngle2,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_LOWER, FACE_TRAILING,
                        points, uvs); // 18 + (10, 11)

                // Bottom Edge
                PushSpokeSpanRenderPoints (
                        contactAngle2,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_LOWER, FACE_LOWER,
                        points, uvs); // 18 + (12, 13)

                PushSpokeSpanRenderPoints (
                        apexAngle0,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_LOWER, FACE_LOWER,
                        points, uvs); // 18 + (14, 15)

                PushSpokeSpanRenderPoints (
                        contactAngle10,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_LOWER, FACE_LOWER,
                        points, uvs); // 18 + (16, 17)

                // Leading Edge
                PushSpokeSpanRenderPoints (
                        contactAngle10,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_LOWER, FACE_LEADING,
                        points, uvs); // 18 + (18, 19)

                PushSpokeSpanRenderPoints (
                        contactAngle10,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        0, 0,
                        LAYER_MIDDLE, FACE_LEADING,
                        points, uvs); // 18 + (20, 21)

                PushSpokeSpanRenderPoints (
                        contactAngle10,
                        outerSpokeRad, innerSpokeRad,
                        segmentCount,
                        outer_spoke_thickness, inner_spoke_thickness,
                        LAYER_UPPER, FACE_LEADING,
                        points, uvs); // 18 + (22, 23)

                if (i == 0) {
                        pointStride = static_cast<unsigned>(points.size ());
                }
        }
        unsigned pointCount = static_cast<unsigned>(points.size ());

        std::vector<unsigned> triangles;
        unsigned k = 0;
        for (i = 0; i < m_spokes; ++i) {
                /*
                 * See "GearGraph.pdf" for vertex and edge labeling.
                 */
                static int triangles_ec[] = {
                        // end caps
                        0, 1, 2,			// a
                        0, 2, 3,			// b
                        8, 3, 2,			// c
                        8, 2, 7,			// d
                        2, 1, 4,			// e
                        2, 4, 5,			// f
                        2, 5, 6,			// g
                        2, 6, 7,			// h

                        9 + 0, 9 + 1, 9 + 2,		// i
                        9 + 0, 9 + 2, 9 + 3,		// j
                        9 + 8, 9 + 3, 9 + 2,		// k
                        9 + 8, 9 + 2, 9 + 7,		// l
                        9 + 2, 9 + 1, 9 + 4,		// m
                        9 + 2, 9 + 4, 9 + 5,		// n
                        9 + 2, 9 + 5, 9 + 6,		// o
                        9 + 2, 9 + 6, 9 + 7,		// p
                        -1, -1, -1
                };

                CopyTriangles (triangles, k, pointCount, &triangles_ec[0]);

                for (unsigned segIndex = 0; segIndex < segmentCount; ++segIndex) {
                        unsigned stride = segmentCount - 1;
                        int triangles_sp[] = {
                                // spans
                                18 + 0,			18 + 1,			18 + 3 + stride,		// q
                                18 + 0,			18 + 3 + stride,	18 + 2 + stride,		// r
                                18 + 2 + stride,	18 + 3 + stride,	18 + 5 + (stride * 2),		// s
                                18 + 2 + stride,	18 + 5 + (stride * 2),	18 + 4 + (stride * 2),		// t

                                18 + 6 + (stride * 3), 18 + 7 + (stride * 3),	18 + 9 + (stride * 4),		// u
                                18 + 6 + (stride * 3), 18 + 9 + (stride * 4),	18 + 8 + (stride * 4),		// v
                                18 + 8 + (stride * 4), 18 + 9 + (stride * 4),	18 + 11 + (stride * 5),		// w
                                18 + 8 + (stride * 4), 18 + 11 + (stride * 5),	18 + 10 + (stride * 5),		// x

                                18 + 12 + (stride * 6), 18 + 13 + (stride * 6), 18 + 15 + (stride * 7),		// y
                                18 + 12 + (stride * 6), 18 + 15 + (stride * 7), 18 + 14 + (stride * 7),		// z
                                18 + 14 + (stride * 7), 18 + 15 + (stride * 7), 18 + 17 + (stride * 8),		// aa
                                18 + 14 + (stride * 7), 18 + 17 + (stride * 8), 18 + 16 + (stride * 8),		// bb

                                18 + 18 + (stride * 9), 18 + 19 + (stride * 9), 18 + 21 + (stride * 10),	// cc
                                18 + 18 + (stride * 9), 18 + 21 + (stride * 10), 18 + 20 + (stride * 10),	// dd
                                18 + 20 + (stride * 10), 18 + 21 + (stride * 10), 18 + 23 + (stride * 11),	// ee
                                18 + 20 + (stride * 10), 18 + 23 + (stride * 11), 18 + 22 + (stride * 11),	// ff
                                -1, -1, -1
                        };

                        CopyTriangles (triangles, k + segIndex, pointCount, &triangles_sp[0]);
                }

                k += pointStride;
        }

        std::vector<GeoPoint> normals;
        GenerateNormals (points, triangles, normals);

        std::vector<GeoPoint>	dPdus, dPdvs;
        if (hasUVs) {
                /*
                 * Generate the vertex dPdu/dPdv values using our point, uv, and point lists.
                 */
                GenerateDPDUs (points, uvs, triangles, dPdus, dPdvs);
        }

        /*
         * Pre-populate an array of zero-length velocities.
         */
        std::vector<GeoPoint> velocities;
        GeoPoint	zeroVec;
        LXx_VCLR (zeroVec.vec);
        for (unsigned vecIndex = 0; vecIndex < pointCount; ++vecIndex) {
                velocities.push_back (zeroVec);
        }

        /*
         * Call the big soup brewer, to process all of the teeth in a single batch.
         */
        PushVertexFeatures (soup, points, normals, velocities, uvs, dPdus, dPdvs);
        result = BrewBigSoup (soup, triangles);

        return result;
}

        LxResult
CGearPart::SampleGearPartShaft (
        CLxUser_TriangleSoup	&soup,
        unsigned		&segmentID)
{
        LxResult	result = LXe_OK;

        if (m_spokes || rim_inset_ratio < 1.0 ||
            (axial_shaft_inset_ratio > rim_inset_ratio)) {
                result = BrewRimSoup (soup, segmentID,
                        innerSpokeRad, axialShaftRimThickness,
                        RIM_FACING_OUTWARDS);
        }

        if (LXx_OK (result)) {
                result = BrewRimSoup (soup, segmentID,
                        m_shaft, axialShaftRimThickness, RIM_FACING_INWARDS);

                if (LXx_OK (result)) {
                        result = BrewRingSoup (
                                soup, segmentID,
                                innerSpokeRad,
                                m_shaft,
                                axialShaftRimThickness,
                                axialShaftRimThickness);
                }
        }

        return result;
}

#if defined(CORE_IMPLEMENTED)
        LxResult
CGearPart::SampleGearPartCore (
        CLxUser_TriangleSoup	&soup,
        unsigned		&segmentID)
{
        LxResult	result = LXe_OK;

        return result;
}
#endif

/*
 * Push the given vertex features into the soup.
 *
 * All of the vector arrays should have an equal number of entries.
 */
        LxResult
CGearPart::PushVertexFeatures (
        CLxUser_TriangleSoup	&soup,
        std::vector<GeoPoint>	&points,
        std::vector<GeoPoint>	&normals,
        std::vector<GeoPoint>	&velocities,
        std::vector<GeoUV>		&uvs,
        std::vector<GeoPoint>	&dPdus,
        std::vector<GeoPoint>	&dPdvs)
{
        unsigned		 vecSize = 3 * BASE_FEATURE_COUNT;

        switch (max_f_type) {
                case FEATURE_UV:
                        vecSize = max_f_pos + 2;
                        break;
                case FEATURE_DPDU:
                        vecSize = max_f_pos + 6;
                        break;
        }

        float			*vec = new float[vecSize];
        LxResult		 result = LXe_OK;

        for (unsigned pointIndex = 0; pointIndex < points.size (); ++pointIndex) {
                for (unsigned subIndex = 0; subIndex < 3; ++subIndex) {
                        vec[f_pos[FEATURE_POSITION] + subIndex] =
                                static_cast<float>(points[pointIndex].vec[subIndex]);
                        vec[f_pos[FEATURE_OBJECT_POSITION] + subIndex] =
                                static_cast<float>(points[pointIndex].vec[subIndex]);
                        vec[f_pos[FEATURE_NORMAL] + subIndex] =
                                static_cast<float>(normals[pointIndex].vec[subIndex]);
                        vec[f_pos[FEATURE_VELOCITY] + subIndex] =
                                static_cast<float>(velocities[pointIndex].vec[subIndex]);
                        if (hasUVs) {
                                vec[f_pos[FEATURE_DPDU] + subIndex] =
                                        static_cast<float>(dPdus[pointIndex].vec[subIndex]);
                                vec[f_pos[FEATURE_DPDU] + 3 + subIndex] =
                                        static_cast<float>(dPdvs[pointIndex].vec[subIndex]);
                        }
                }
                if (hasUVs) {
                        vec[f_pos[FEATURE_UV] + 0] = uvs[pointIndex].uv[0];
                        vec[f_pos[FEATURE_UV] + 1] = uvs[pointIndex].uv[1];
                }

                unsigned index;
                soup.Vertex (vec, &index);
        }

        delete [] vec;

        return result;
}

/*
 * Push the requested number of points onto the given point and UV arrays,
 * calculating positions and UVs according to the given parameters.
 */
        void
CGearPart::PushBeveledHelicalToothRenderPoints (
        unsigned		 upperCopies,
        unsigned		 middleCopies,
        unsigned		 lowerCopies,
        double			 upperAngle,
        double			 lowerAngle,
        double			 upperRadius,
        double			 lowerRadius,
        double			 thickness,
        std::vector<GeoPoint>	&points,
        std::vector<GeoUV>		&uvs)
{
        double			 sn, cs;
        unsigned		 vertIndex;
        GeoPoint	 		 point;
        GeoUV			 uv;

        // upper position
        sn  = sin (upperAngle);
        cs  = cos (upperAngle);
        point.vec[0] = static_cast<float>(sn * upperRadius);
        point.vec[1] = static_cast<float>(cs * upperRadius);
        point.vec[2] = static_cast<float>(thickness);

        if (hasUVs) {
                // UVs
                uv.uv[0] = static_cast<float>(upperAngle / PI); // wraparound twice
                uv.uv[1] = 0.0f;
        }

        for (vertIndex = 0; vertIndex < upperCopies; ++vertIndex) {
                points.push_back (point);
                if (hasUVs) {
                        uvs.push_back (uv);
                }
        }

        if (double_helical) {
                // middle position
                sn  = sin (lowerAngle);
                cs  = cos (lowerAngle);
                point.vec[0] = static_cast<float>(sn * lowerRadius);
                point.vec[1] = static_cast<float>(cs * lowerRadius);
                point.vec[2] = 0;

                if (hasUVs) {
                        // UVs
                        uv.uv[1] = static_cast<float>(thickness * 0.5);
                }

                for (vertIndex = 0; vertIndex < middleCopies; ++vertIndex) {
                        points.push_back (point);
                        if (hasUVs) {
                                uvs.push_back (uv);
                        }
                }

                // lower position
                sn  = sin (upperAngle);
                cs  = cos (upperAngle);
                point.vec[0] = static_cast<float>(sn * upperRadius);
                point.vec[1] = static_cast<float>(cs * upperRadius);
                point.vec[2] = static_cast<float>(-thickness);
        }
        else {
                // lower position
                sn  = sin (lowerAngle);
                cs  = cos (lowerAngle);
                point.vec[0] = static_cast<float>(sn * lowerRadius);
                point.vec[1] = static_cast<float>(cs * lowerRadius);
                point.vec[2] = static_cast<float>(-thickness);
        }

        if (hasUVs) {
                // UVs
                uv.uv[1] = static_cast<float>(thickness);
        }

        for (vertIndex = 0; vertIndex < lowerCopies; ++vertIndex) {
                points.push_back (point);
                if (hasUVs) {
                        uvs.push_back (uv);
                }
        }
}

        void
CGearPart::PushWallBeveledHelicalRenderPoints (
        unsigned		 copies,
        double			 upperAngle,
        double			 lowerAngle,
        double			 upperRadius,
        double			 lowerRadius,
        double			 thickness,
        Layer			 layer,
        std::vector<GeoPoint>	&points,
        std::vector<GeoUV>		&uvs)
{
        double			 sn, cs;
        GeoPoint	 		 point;
        GeoUV			 uv;

        if (layer == LAYER_UPPER) {
                sn  = sin (upperAngle);
                cs  = cos (upperAngle);
                point.vec[0] = static_cast<float>(sn * upperRadius);
                point.vec[1] = static_cast<float>(cs * upperRadius);
                point.vec[2] = static_cast<float>(thickness);
                if (hasUVs) {
                        // UVs
                        uv.uv[0] = static_cast<float>(sn * upperRadius / max_radius / 2 + 0.5);
                        uv.uv[1] = static_cast<float>(cs * upperRadius / max_radius / 2 + 0.5);
                }
        }
        else {
                // lower position
                if (double_helical) {
                        sn  = sin (upperAngle);
                        cs  = cos (upperAngle);
                        point.vec[0] = static_cast<float>(sn * upperRadius);
                        point.vec[1] = static_cast<float>(cs * upperRadius);
                        point.vec[2] = static_cast<float>(-thickness);
                        if (hasUVs) {
                                // UVs
                                uv.uv[0] = static_cast<float>(sn * upperRadius / max_radius / 2 + 0.5);
                                uv.uv[1] = static_cast<float>(cs * upperRadius / max_radius / 2 + 0.5);
                        }
                }
                else {
                        sn  = sin (lowerAngle);
                        cs  = cos (lowerAngle);
                        point.vec[0] = static_cast<float>(sn * lowerRadius);
                        point.vec[1] = static_cast<float>(cs * lowerRadius);
                        point.vec[2] = static_cast<float>(-thickness);
                        if (hasUVs) {
                                // UVs
                                uv.uv[0] = static_cast<float>(sn * lowerRadius / max_radius / 2 + 0.5);
                                uv.uv[1] = static_cast<float>(cs * lowerRadius / max_radius / 2 + 0.5);
                        }
                }
        }

        for (unsigned vertIndex = 0; vertIndex < copies; ++vertIndex) {
                points.push_back (point);
                if (hasUVs) {
                        uvs.push_back (uv);
                }
        }
}

        static void
PushPointAndUV (
        double			 x,
        double			 y,
        double			 z,
        float			 u,
        float			 v,
        std::vector<GeoPoint>	&points,
        bool			 hasUVs,
        std::vector<GeoUV>		&uvs)
{
        GeoPoint	 		 point;
        GeoUV			 uv;

        point.vec[0] = static_cast<float>(x);
        point.vec[1] = static_cast<float>(y);
        point.vec[2] = static_cast<float>(z);
        points.push_back (point);

        if (hasUVs) {
                uv.uv[0] = u;
                uv.uv[1] = v;
                uvs.push_back (uv);
        }
}

        void
CGearPart::PushSpokeEndCapRenderPoints (
        double			 contactAngle2,
        double			 apexAngle0,
        double			 contactAngle10,
        double			 outerRadius,
        double			 innerRadius,
        double			 outerThickness,
        double			 innerThickness,
        std::vector<GeoPoint>	&points,
        std::vector<GeoUV>		&uvs)
{
        double			 innerSn2, innerCs2,
                                 innerSn0, innerCs0,
                                 innerSn10, innerCs10;
        double			 outerSn2, outerCs2,
                                 outerSn0, outerCs0,
                                 outerSn10, outerCs10;

        /*
         * Pre-calculate various shared positions.
         */
        innerSn2  = sin (contactAngle2);
        innerCs2  = cos (contactAngle2);
        innerSn2 *= innerRadius;
        innerCs2 *= innerRadius;

        outerSn2 = sin (contactAngle2 + spoke_swirl_angle);
        outerCs2 = cos (contactAngle2 + spoke_swirl_angle);
        outerSn2 *= outerRadius;
        outerCs2 *= outerRadius;

        innerSn0  = sin (apexAngle0);
        innerCs0  = cos (apexAngle0);
        innerSn0 *= innerRadius;
        innerCs0 *= innerRadius;

        outerSn0  = sin (apexAngle0 + spoke_swirl_angle);
        outerCs0  = cos (apexAngle0 + spoke_swirl_angle);
        outerSn0 *= outerRadius;
        outerCs0 *= outerRadius;

        innerSn10  = sin (contactAngle10);
        innerCs10  = cos (contactAngle10);
        innerSn10 *= innerRadius;
        innerCs10 *= innerRadius;

        outerSn10  = sin (contactAngle10 + spoke_swirl_angle);
        outerCs10  = cos (contactAngle10 + spoke_swirl_angle);
        outerSn10 *= outerRadius;
        outerCs10 *= outerRadius;

        /*
         * Inner end cap.
         */
        PushPointAndUV (innerSn10, innerCs10, innerThickness,
                0.0f, 1.0f, points, hasUVs, uvs);	// 0

        PushPointAndUV (innerSn10, innerCs10, 0.0,
                0.0f, 0.5f, points, hasUVs, uvs);	// 1

        PushPointAndUV (innerSn0, innerCs0, 0.0,
                0.5f, 0.5f, points, hasUVs, uvs);	// 2

        PushPointAndUV (innerSn0, innerCs0, innerThickness,
                0.5f, 1.0f, points, hasUVs, uvs);	// 3

        PushPointAndUV (innerSn10, innerCs10, -innerThickness,
                0.0f, 0.0f, points, hasUVs, uvs);	// 4

        PushPointAndUV (innerSn0, innerCs0, -innerThickness,
                0.5f, 0.0f, points, hasUVs, uvs);	// 5

        PushPointAndUV (innerSn2, innerCs2, -innerThickness,
                1.0f, 0.0f, points, hasUVs, uvs);	// 6

        PushPointAndUV (innerSn2, innerCs2, 0.0,
                1.0f, 0.5f, points, hasUVs, uvs);	// 7

        PushPointAndUV (innerSn2, innerCs2, innerThickness,
                1.0f, 1.0f, points, hasUVs, uvs);	// 8

        /*
         * Outer end cap.
         */
        PushPointAndUV (outerSn2, outerCs2, outerThickness,
                0.0f, 1.0f, points, hasUVs, uvs);	// 9

        PushPointAndUV (outerSn2, outerCs2, 0,
                0.0f, 0.5f, points, hasUVs, uvs);	// 10

        PushPointAndUV (outerSn0, outerCs0, 0,
                0.5f, 0.5f, points, hasUVs, uvs);	// 11

        PushPointAndUV (outerSn0, outerCs0, outerThickness,
                0.5f, 1.0f, points, hasUVs, uvs);	// 12

        PushPointAndUV (outerSn2, outerCs2, -outerThickness,
                0.0f, 0.0f, points, hasUVs, uvs);	// 13

        PushPointAndUV (outerSn0, outerCs0, -outerThickness,
                0.5f, 0.0f, points, hasUVs, uvs);	// 14

        PushPointAndUV (outerSn10, outerCs10, -outerThickness,
                1.0f, 0.0f, points, hasUVs, uvs);	// 15

        PushPointAndUV (outerSn10, outerCs10, 0.0,
                1.0f, 0.5f, points, hasUVs, uvs);	// 16

        PushPointAndUV (outerSn10, outerCs10, outerThickness,
                1.0f, 1.0f, points, hasUVs, uvs);	// 17
}

        void
CGearPart::PushSpokeSpanRenderPoints (
        double			 angle,
        double			 outerRadius,
        double			 innerRadius,
        unsigned		 segments,
        double			 outerThickness,
        double			 innerThickness,
        Layer			 layer,
        Face			 face,
        std::vector<GeoPoint>	&points,
        std::vector<GeoUV>		&uvs)
{
#ifndef LERP
        #define LERP(a,b,c)	((a) + (c) * ((b) - (a)))
#endif
        double			 sn, cs;
        GeoPoint	 		 point;
        GeoUV			 uv;

        for (unsigned segmentIndex = 0; segmentIndex <= segments; ++segmentIndex) {
                double	span = static_cast<double>(segments - segmentIndex) / segments;
                double	spanRadius = LERP (innerRadius, outerRadius, span);
                double	spanThickness = LERP (innerThickness, outerThickness, span);
                
                double swirlAngle = angle + span * spoke_swirl_angle;
                sn  = sin (swirlAngle);
                cs  = cos (swirlAngle);

                point.vec[0] = static_cast<float>(sn * spanRadius);
                point.vec[1] = static_cast<float>(cs * spanRadius);
                if (layer == LAYER_MIDDLE) {
                        point.vec[2] = 0.0f;
                }
                else {
                        point.vec[2] = static_cast<float>((layer == LAYER_UPPER) ?
                                spanThickness : -spanThickness);
                }
                points.push_back (point);

                if (hasUVs) {
                        uv.uv[0] = static_cast<float>(span);
                        uv.uv[1] = static_cast<float>(angle / TWO_PI);
                        if ((face == FACE_LEADING) || (face == FACE_TRAILING)) {
                                if (layer == LAYER_LOWER) {
                                        uv.uv[1] += static_cast<float>((face == FACE_LEADING) ?
                                                        -spanThickness : spanThickness);
                                }
                        }
                        uvs.push_back (uv);
                }
        }
}

        LxResult
CGearPart::BrewRimSoup (
        CLxUser_TriangleSoup	&soup,
        unsigned		&segmentID,
        double			 radius,
        double			 thickness,
        RimFacing		 facing,
        RimMapping		 rimMapping)
{
        LxResult result = soup.Segment (segmentID++, LXiTBLX_SEG_TRIANGLE);
        if (result == LXe_FALSE)
                return LXe_OK;
        else if (LXx_FAIL (result))
                return result;

        std::vector<GeoPoint>	 points;
        std::vector<GeoUV>		 uvs;
        unsigned pointStride = 0;
        unsigned i;
        for (i = 0; i <= coveredToothCount; ++i) {
                BuildToothConstruct (*this, i);

                PushRimRenderPoints (soup,
                        apex_angle_0,
                        radius, thickness, facing,
                        points, uvs,
                        rimMapping);	// 0, 1
                if (LXx_FAIL (result)) {
                        break;
                }

                PushRimRenderPoints (soup,
                        contact_angle_E,
                        radius, thickness, facing,
                        points, uvs,
                        rimMapping);	// 2, 3
                if (LXx_FAIL (result)) {
                        break;
                }

                PushRimRenderPoints (soup,
                        inner_angle,
                        radius, thickness, facing,
                        points, uvs,
                        rimMapping);	// 4, 5
                if (LXx_FAIL (result)) {
                        break;
                }

                PushRimRenderPoints (soup,
                        contact_angle_N,
                        radius, thickness, facing,
                        points, uvs,
                        rimMapping);	// 6, 7
                if (LXx_FAIL (result)) {
                        break;
                }

                if (i == 0) {
                        pointStride = static_cast<unsigned>(points.size ());
                }
        }
        unsigned pointCount = static_cast<unsigned>(points.size ());

        std::vector<unsigned> triangles;
        unsigned k = 0;
        for (i = 0; i < coveredToothCount; ++i) {
                /*
                 * See "GearGraph.pdf" for vertex and edge labeling.
                 */
                static int triangles_rim_inwards[] = {
                        0, 1, 3,	// a
                        0, 3, 2,	// b
                        2, 3, 5,	// c
                        2, 5, 4,	// d
                        4, 5, 7,	// e
                        4, 7, 6,	// f
                        6, 7, 9,	// g
                        6, 9, 8,	// h
                        -1, -1, -1
                };

                static int triangles_rim_outwards[] = {
                        1, 0, 2,	// a
                        1, 2, 3,	// b
                        3, 2, 4,	// c
                        3, 4, 5,	// d
                        5, 4, 6,	// e
                        5, 6, 7,	// f
                        7, 6, 8,	// g
                        7, 8, 9,	// h
                        -1, -1, -1
                };

                if (facing == RIM_FACING_INWARDS)
                        CopyTriangles (triangles, k, pointCount, &triangles_rim_inwards[0]);
                else {
                        CopyTriangles (triangles, k, pointCount, &triangles_rim_outwards[0]);
                }

                k += pointStride;
        }

        std::vector<GeoPoint> normals;
        GenerateNormals (points, triangles, normals);

        std::vector<GeoPoint>	dPdus, dPdvs;
        if (hasUVs) {
                /*
                 * Generate the vertex dPdu/dPdv values using our point, uv, and point lists.
                 */
                GenerateDPDUs (points, uvs, triangles, dPdus, dPdvs);
        }

        /*
         * Pre-populate an array of zero-length velocities.
         */
        std::vector<GeoPoint> velocities;
        GeoPoint	zeroVec;
        LXx_VCLR (zeroVec.vec);
        for (unsigned vecIndex = 0; vecIndex < pointCount; ++vecIndex) {
                velocities.push_back (zeroVec);
        }

        /*
         * Call the big soup brewer, to process all of the teeth in a single batch.
         */
        PushVertexFeatures (soup, points, normals, velocities, uvs, dPdus, dPdvs);
        result = BrewBigSoup (soup, triangles);

        return result;
}

        void
CGearPart::PushRimRenderPoints (
        CLxUser_TriangleSoup	&soup,
        double			 angle,
        double			 radius,
        double			 thickness,
        RimFacing		 facing,
        std::vector<GeoPoint>	&points,
        std::vector<GeoUV>		&uvs,
        RimMapping		 rimMapping)
{
        double			 sn, cs;
        GeoPoint	 		 point;
        GeoUV			 uv;

        // positions
        sn  = sin (angle);
        cs  = cos (angle);
        point.vec[0] = static_cast<float>(sn * radius);
        point.vec[1] = static_cast<float>(cs * radius);
        point.vec[2] = static_cast<float>(thickness);

        if (hasUVs) {
                if (rimMapping == RIM_MAPPING_CYLINDRICAL) {
                        uv.uv[0] = static_cast<float>(angle / PI); // wraparound twice
                        uv.uv[1] = 0.0f;
                }
                else if (rimMapping == RIM_MAPPING_CONCENTRIC) {
                        uv.uv[0] = static_cast<float>(sn * radius / max_radius / 2 + 0.5);
                        uv.uv[1] = static_cast<float>(cs * radius / max_radius / 2 + 0.5);
                }
                uvs.push_back (uv);
        }

        points.push_back (point);

        point.vec[2] = static_cast<float>(-thickness);

        points.push_back (point);

        if (hasUVs) {
                if (rimMapping == RIM_MAPPING_CYLINDRICAL) {
                        uv.uv[0] = static_cast<float>(angle / PI); // wraparound twice
                        uv.uv[1] = static_cast<float>(thickness);
                }
                else if (rimMapping == RIM_MAPPING_CONCENTRIC) {
                        uv.uv[0] = static_cast<float>(sn * (radius - thickness) / max_radius / 2 + 0.5);
                        uv.uv[1] = static_cast<float>(cs * (radius - thickness) / max_radius / 2 + 0.5);
                }
                uvs.push_back (uv);
        }
}

        static void
PushPointPair (
        std::vector<GeoPoint>	&points,
        double			 angle,
        double			 radius,
        double			 thickness)
{
        GeoPoint point;

        double sn  = sin (angle);
        double cs  = cos (angle);
        point.vec[0] = sn * radius;
        point.vec[1] = cs * radius;

        // upper
        point.vec[2] = thickness;
        points.push_back (point);

        // lower
        point.vec[2] = -thickness;
        points.push_back (point);
}

/*
 * Builds a ring based upon the given construction parameters.
 */
        LxResult
CGearPart::BrewRingSoup (
        CLxUser_TriangleSoup	&soup,
        unsigned 		&segmentID,
        double			 outerRadius,
        double			 innerRadius,
        double			 outerThickness,
        double			 innerThickness,
        RingMapping		 ringMapping)
{
        LxResult		result;

        for (Layer layer = LAYER_UPPER; layer <= LAYER_LOWER;) {
                result = soup.Segment (segmentID++, LXiTBLX_SEG_TRIANGLE);
                if (result == LXe_FALSE)
                        return LXe_OK;
                else if (LXx_FAIL (result))
                        return result;

                unsigned i;
                unsigned pointStride;
                unsigned pointCount = 0; // Reset the point count for each segment.
                std::vector<GeoPoint>	 points;
                std::vector<GeoUV>		 uvs;
                for (i = 0; i < coveredToothCount; ++i) {
                        BuildToothConstruct (*this, i);

                        PushRingRenderPoints (
                                apex_angle_0,
                                outerRadius, innerRadius,
                                outerThickness, innerThickness,
                                layer,
                                points, uvs, ringMapping); // 0, 1

                        PushRingRenderPoints (
                                contact_angle_E,
                                outerRadius, innerRadius,
                                outerThickness, innerThickness,
                                layer,
                                points, uvs, ringMapping); // 2, 3

                        PushRingRenderPoints (
                                inner_angle,
                                outerRadius, innerRadius,
                                outerThickness, innerThickness,
                                layer,
                                points, uvs, ringMapping); // 4, 5

                        PushRingRenderPoints (
                                contact_angle_N,
                                outerRadius, innerRadius,
                                outerThickness, innerThickness,
                                layer,
                                points, uvs, ringMapping); // 6, 7

                        if (i == 0) {
                                pointStride = static_cast<unsigned>(points.size ());
                        }
                }
                pointCount = static_cast<unsigned>(points.size ());

                std::vector<unsigned> triangles;
                unsigned k = 0;
                for (i = 0; i < coveredToothCount; ++i) {
                        /*
                         * See "GearGraph.pdf" for vertex and edge labeling.
                         */
                        static int triangles_in_upper[] = {
                                0, 1, 3,	// a
                                0, 3, 2,	// b
                                2, 3, 5,	// c
                                2, 5, 4,	// d
                                4, 5, 7,	// e
                                4, 7, 6,	// f
                                6, 7, 9,	// g
                                6, 9, 8,	// h
                                -1, -1, -1
                        };

                        static int triangles_in_lower[] = {
                                1, 0, 2,	// a
                                1, 2, 3,	// b
                                3, 2, 4,	// c
                                3, 4, 5,	// d
                                5, 4, 6,	// e
                                5, 6, 7,	// f
                                7, 6, 8,	// g
                                7, 8, 9,	// h
                                -1, -1, -1
                        };

                        if (layer == LAYER_UPPER) {
                                CopyTriangles (triangles, k, pointCount, &triangles_in_upper[0]);
                        }
                        else if (layer == LAYER_LOWER) {
                                CopyTriangles (triangles, k, pointCount, &triangles_in_lower[0]);
                        }

                        k += pointStride;
                }

                std::vector<GeoPoint> normals;
                GenerateNormals (points, triangles, normals);

                std::vector<GeoPoint>	dPdus, dPdvs;
                if (hasUVs) {
                        /*
                         * Generate the vertex dPdu/dPdv values using our point, uv, and point lists.
                         */
                        GenerateDPDUs (points, uvs, triangles, dPdus, dPdvs);
                }

                /*
                 * Pre-populate an array of zero-length velocities.
                 */
                std::vector<GeoPoint> velocities;
                GeoPoint	zeroVec;
                LXx_VCLR (zeroVec.vec);
                for (unsigned vecIndex = 0; vecIndex < pointCount; ++vecIndex) {
                        velocities.push_back (zeroVec);
                }

                /*
                 * Call the big soup brewer, to process all of the teeth in a single batch.
                 */
                PushVertexFeatures (soup, points, normals, velocities, uvs, dPdus, dPdvs);
                result = BrewBigSoup (soup, triangles);
                if (LXx_FAIL(result)) {
                        break;
                }

                if ((layer == LAYER_LOWER) || LXx_FAIL (result)) {
                        break;
                }
                else {
                        layer = LAYER_LOWER;
                }
        }

        return result;
}

        void
CGearPart::PushRingRenderPoints (
        double			 angle,
        double			 outerRadius,
        double			 innerRadius,
        double			 outerThickness,
        double			 innerThickness,
        Layer			 layer,
        std::vector<GeoPoint>	&points,
        std::vector<GeoUV>		&uvs,
        RingMapping		 ringMapping)
{
        double			 sn, cs;
        GeoPoint	 		 point;
        GeoUV			 uv;

        sn  = sin (angle);
        cs  = cos (angle);
        point.vec[0] = static_cast<float>(sn * outerRadius);
        point.vec[1] = static_cast<float>(cs * outerRadius);
        point.vec[2] = static_cast<float>((layer == LAYER_UPPER) ? outerThickness : -outerThickness);
        points.push_back (point);

        double outerScale;
        if (ringMapping == RING_MAPPING_INSET) {
                outerScale = outerRadius;
        }
        else {
                outerScale = max_radius;
        }

        if (hasUVs) {
                uv.uv[0] = static_cast<float>(sn * outerScale / max_radius / 2 + 0.5);
                uv.uv[1] = static_cast<float>(cs * outerScale / max_radius / 2 + 0.5);

                uvs.push_back (uv);
        }

        point.vec[0] = static_cast<float>(sn * innerRadius);
        point.vec[1] = static_cast<float>(cs * innerRadius);
        point.vec[2] = static_cast<float>((layer == LAYER_UPPER) ? innerThickness : -innerThickness);
        points.push_back (point);

        if (hasUVs) {
                uv.uv[0] = static_cast<float>(sn * innerRadius / max_radius / 2 + 0.5);
                uv.uv[1] = static_cast<float>(cs * innerRadius / max_radius / 2 + 0.5);

                uvs.push_back (uv);
        }
}

/*
 * ----------------------------------------------------------------
 * GearItem Tableau Element
 *
 * A tableau surface element lives in the tableau and generates geometry
 * for the renderer. It has a bounding box, vertex features, and a sample
 * method.
 */

CGearItemElement::CGearItemElement()
        :
        element(NULL),
        tableau(NULL),
        tableauElementMap(NULL)
{
}

CGearItemElement::~CGearItemElement()
{
        if (tableauElementMap != NULL) {
                /*
                 * Remove the element from its tableau element map.
                 */
                bool found;
                do {
                        found = false;
                        TableauElementMap::iterator iter;
                        for (iter = tableauElementMap->lower_bound (tableau);
                             iter != tableauElementMap->upper_bound (tableau);
                             ++iter) {
                                if (iter->second == this) {
                                        found = true;
                                        break;
                                }
                        }
                        if (found) {
                                tableauElementMap->erase (iter);
                        }
                } while (found);
        }

        // "element" is freed by the call to XObjectRelease (elt->eltID) in Tableau_FreeEltList (tblx.qq)
}

        LxResult
CGearItemElement::tsrf_Bound (
        LXtTableauBox		 bbox)
{
        return Bound (bbox);
}

        unsigned
CGearItemElement::tsrf_FeatureCount (
        LXtID4			 type)
{
        return FeatureCount (type);
}

        LxResult
CGearItemElement::tsrf_FeatureByIndex (
        LXtID4			 type,
        unsigned		 index,
        const char	       **name)
{
        return FeatureByIndex (type, index, name);
}

        LxResult
CGearItemElement::tsrf_SetVertex (
        ILxUnknownID		 vdesc)
{
        return SetVertex (vdesc);
}

        LxResult
CGearItemElement::tsrf_Sample (
        const LXtTableauBox	 bbox,
        float			 scale,
        ILxUnknownID		 trisoup)
{
        return Sample (bbox, scale, trisoup);
}

        LxResult
CGearItemElement::tins_GetTransform (
        unsigned	 endPoint,
        LXtVector	 offset,
        LXtMatrix	 xfrm)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        /*
         * Fetch the transform associated with the given end point,
         * so that the renderer can perform motion blur calculations.
         */
        if (endPoint == LXiTBLX_ENDPOINT_T0) {
                LXx_VCPY (offset, m_offset0);

                for (unsigned i = 0; i < 3; ++i)
                        LXx_VCPY (xfrm[i], m_xfrm0[i]);

                result = LXe_OK;
        }
        else if (endPoint == LXiTBLX_ENDPOINT_T1) {
                LXx_VCPY (offset, m_offset1);

                for (unsigned i = 0; i < 3; ++i)
                        LXx_VCPY (xfrm[i], m_xfrm1[i]);

                result = LXe_OK;
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * CGearItem SurfaceBin
 *
 * Each part is associated with a bin.
 */

        static void
SetBBoxFromTBox (LXtBBox *bbox, LXtTableauBox tBox)
{
        LXx_V3SET (bbox->min, tBox[0], tBox[1], tBox[2]);
        LXx_V3SET (bbox->max, tBox[3], tBox[4], tBox[5]);
        LXx_V3SET (bbox->extent, tBox[3] - tBox[0], tBox[4] - tBox[1], tBox[5] - tBox[2]);
        LXx_VCLR (bbox->center);
}

        LxResult
CGearItemBin::surfbin_GetBBox (LXtBBox *bbox)
{
        LXtTableauBox	tBox;
        LxResult	result = Bound (tBox);
        SetBBoxFromTBox (bbox, tBox);

        return result;
}

        LxResult
CGearItemBin::surfbin_FrontBBox (
        const LXtVector	 pos,
        const LXtVector	 dir,
        LXtBBox		*bbox)
{
        return LXe_NOTIMPL;
}

/*
 * StringTag interface.
 */
        LxResult
CGearItemBin::stag_Get (LXtID4 type, const char **tag)
{
        switch (m_part)
        {
                case GEARPART_TEETH:
                        tag[0] = GEAR_PART_TAG_TEETH;
                        break;

                case GEARPART_RIM:
                        tag[0] = GEAR_PART_TAG_RIM;
                        break;

                case GEARPART_SPOKES:
                        tag[0] = GEAR_PART_TAG_SPOKES;
                        break;

                case GEARPART_SHAFT:
                        tag[0] = GEAR_PART_TAG_SHAFT;
                        break;
#if defined(CORE_IMPLEMENTED)
                case GEARPART_CORE:
                        tag[0] = GEAR_PART_TAG_CORE;
                        break;
#endif
        }

        return LXe_OK;
}

        LxResult
CGearItemBin::tsrf_Bound (
        LXtTableauBox		 bbox)
{
        return Bound (bbox);
}

        unsigned
CGearItemBin::tsrf_FeatureCount (
        LXtID4			 type)
{
        return FeatureCount (type);
}

        LxResult
CGearItemBin::tsrf_FeatureByIndex (
        LXtID4			 type,
        unsigned		 index,
        const char	       **name)
{
        return FeatureByIndex (type, index, name);
}

        LxResult
CGearItemBin::tsrf_SetVertex (
        ILxUnknownID		 vdesc)
{
        return SetVertex (vdesc);
}

        LxResult
CGearItemBin::tsrf_Sample (
        const LXtTableauBox	 bbox,
        float			 scale,
        ILxUnknownID		 trisoup)
{
        return Sample (bbox, scale, trisoup);
}

/*
 * ----------------------------------------------------------------
 * GearItem Surface.
 */

        LxResult
CGearItemSurface::Initialize (
        CGearItemPackage	*pkg,
        CLxUser_Item		&m_item,
        CLxUser_ChannelRead	&chanRead)
{
        LxResult result = LXe_FAILED;

        src_pkg = pkg;

        result = InitializePart (m_item, chanRead);

        return result;
}

        LxResult
CGearItemSurface::Initialize (
        CGearItemPackage	*pkg,
        double			 coverage,
        double			 toothSpacing,
        double			 contactAngle,
        double			 thickness,
        unsigned		 teeth,
        double			 shaft,
        unsigned		 spokes,
        bool			 hasRim,
        double			 rimInsetRatio,
        double			 wallInsetRatio,
        double			 axialShaftInsetRatio,
        double			 radialShaftInsetRatio,
        double			 innerSpokeInsetRatio,
        double			 outerSpokeInsetRatio,
        double			 spokeSweepRatio,
        double			 spokeSwirlAngle,
        unsigned		 teethFacing,
        double			 bevelAngle,
        double			 helicalAngle,
        bool			 doubleHelical,
        double			 toothFaceRatio,
        double			 toothTiltAngle,
        double			 toothGrowth,
        unsigned		 resolution,
        double			 maxRadius)
{
        LxResult result = LXe_FAILED;

        src_pkg = pkg;

        result = InitializePart (
                coverage, toothSpacing, contactAngle, thickness, teeth,
                shaft, spokes, hasRim, rimInsetRatio,
                wallInsetRatio, axialShaftInsetRatio, radialShaftInsetRatio,
                innerSpokeInsetRatio, outerSpokeInsetRatio, spokeSweepRatio, spokeSwirlAngle,
                teethFacing,
                bevelAngle, helicalAngle, doubleHelical,
                toothFaceRatio, toothTiltAngle, toothGrowth,
                resolution, maxRadius);

        return result;
}

        LxResult
CGearItemSurface::surf_GetBBox (LXtBBox *bbox)
{
        LXtTableauBox	tBox;
        LxResult	result = Bound (tBox);
        SetBBoxFromTBox (bbox, tBox);

        return result;
}

        LxResult
CGearItemSurface::surf_FrontBBox (const LXtVector pos, const LXtVector dir, LXtBBox *bbox)
{
        return LXe_NOTIMPL;
}

        LxResult
CGearItemSurface::surf_RayCast (const LXtRayInfo *ray, LXtRayHit *hit)
{
        return LXe_NOTIMPL;
}

        LxResult
CGearItemSurface::surf_BinCount (unsigned int *count)
{
        *count = GEARPART_COUNT;

        return LXe_OK;
}

        LxResult
CGearItemSurface::surf_BinByIndex (unsigned int index, void **ppvObj)
{
        LxResult result = LXe_FAILED;

        CGearItemBin	*bin = src_pkg->bin_factory.Alloc (ppvObj);
        switch (index) {
                case GEARPART_TEETH:
                        bin->SetPart (GEARPART_TEETH);
                        result = LXe_OK;
                        break;

                case GEARPART_RIM:
                        bin->SetPart (GEARPART_RIM);
                        result = LXe_OK;
                        break;

                case GEARPART_SPOKES:
                        bin->SetPart (GEARPART_SPOKES);
                        result = LXe_OK;
                        break;

                case GEARPART_SHAFT:
                        bin->SetPart (GEARPART_SHAFT);
                        result = LXe_OK;
                        break;

#if defined(CORE_IMPLEMENTED)
                case GEARPART_CORE:
                        bin->SetPart (GEARPART_CORE);
                        result = LXe_OK;
                        break;
#endif
        }

        bin->InitializePart (
                m_coverage, tooth_spacing, contact_angle, m_thickness, m_teeth,
                m_shaft, m_spokes,
                has_rim, rim_inset_ratio,
                wall_inset_ratio, axial_shaft_inset_ratio, radial_shaft_inset_ratio,
                inner_spoke_inset_ratio, outer_spoke_inset_ratio, spoke_sweep_ratio, spoke_swirl_angle,
                teeth_facing,
                bevel_angle, helical_angle, double_helical,
                tooth_face_ratio, tooth_tilt_angle, tooth_growth,
                m_resolution, max_radius);

        return result;
}

        LxResult
CGearItemSurface::surf_TagCount (LXtID4 type, unsigned int *count)
{
        LxResult result = LXe_OK;

        *count = GEARPART_COUNT;

        return result;
}

        LxResult
CGearItemSurface::surf_TagByIndex (
        LXtID4		 type,
        unsigned int	 index,
        const char	**stag)
{
        LxResult result = LXe_OK;

        switch (index)
        {
                case GEARPART_TEETH:
                        stag[0] = GEAR_PART_TAG_TEETH;
                        break;

                case GEARPART_RIM:
                        stag[0] = GEAR_PART_TAG_RIM;
                        break;

                case GEARPART_SPOKES:
                        stag[0] = GEAR_PART_TAG_SPOKES;
                        break;

                case GEARPART_SHAFT:
                        stag[0] = GEAR_PART_TAG_SHAFT;
                        break;
#if defined(CORE_IMPLEMENTED)
                case GEARPART_CORE:
                        stag[0] = GEAR_PART_TAG_CORE;
                        break;
#endif
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * GearItem Instance
 *
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
        LxResult
CGearItemInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        m_item.set (item);

        return LXe_OK;
}

        void
CGearItemInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

        LxResult
CGearItemInstance::pins_SynthName (
        char			*buf,
        unsigned		 len)
{
        string			 name;

        lx::GetMessageText (name, GEAR_ITEM_MSG_TABLE, GEAR_ITEM_MSG_NAME);
        return lx::StringOut (name, buf, len);
}

        unsigned
CGearItemInstance::pins_DupType (void)
{
        return 0;
}

        LxResult
CGearItemInstance::pins_TestParent (
        ILxUnknownID		 item)
{
        return LXe_NOTIMPL;
}

        LxResult
CGearItemInstance::pins_Newborn (
        ILxUnknownID		 original)
{
        return LXe_NOTIMPL;
}

        LxResult
CGearItemInstance::pins_Loading (void)
{
        return LXe_NOTIMPL;
}

        LxResult
CGearItemInstance::pins_AfterLoad (void)
{
        return LXe_NOTIMPL;
}

        void
CGearItemInstance::pins_Doomed (void)
{
}

/*
 * The instance's TableauSource interface allows it to place elements into the
 * tableau, in this case our GearItem element.
 */
        LxResult
CGearItemInstance::tsrc_Elements (
        ILxUnknownID		 tableau)
{
        CLxUser_Tableau		 tbx (tableau);
        CLxUser_ChannelRead	 chan0, chan1;
        CLxUser_TableauShader	 shader;
        ILxUnknownID		 element;
        LxResult		 result;

        /*
         * Fetch our custom channel values.
         */
        if (!tbx.GetChannels (chan0, 0))
                return LXe_NOINTERFACE;

        if (!tbx.GetChannels (chan1, 1))
                return LXe_NOINTERFACE;

        if (tableauElementMap.find (tableau) == tableauElementMap.end ()) {

                if (!listenerMap->TestTableau (tableau))
                        listenerMap->AddTableau (tableau);
                /*
                 * Create an element for each part.
                 */
                for (unsigned partIndex = GEARPART_TEETH; partIndex < GEARPART_COUNT; ++partIndex) {
                        element = src_pkg->elt_factory.Spawn ();
                        if (!element) {
                                result = LXe_FAILED;
                                break;
                        }

                        CLxLoc_SurfaceBin	 binObj;
                        CGearItemBin	*bin = src_pkg->bin_factory.Alloc (binObj);
                        switch (partIndex) {
                                case GEARPART_TEETH:
                                        bin->SetPart (GEARPART_TEETH);
                                        break;

                                case GEARPART_RIM:
                                        bin->SetPart (GEARPART_RIM);
                                        break;

                                case GEARPART_SPOKES:
                                        bin->SetPart (GEARPART_SPOKES);
                                        break;

                                case GEARPART_SHAFT:
                                        bin->SetPart (GEARPART_SHAFT);
                                        break;
        #if defined(CORE_IMPLEMENTED)
                                case GEARPART_CORE:
                                        bin->SetPart (GEARPART_CORE);
                                        break;
        #endif
                        }

                        result = bin->InitializePart (m_item, chan0);

                        if (!tbx.GetShader (shader, m_item, binObj)) {
                                result = LXe_NOTFOUND;
                                break;
                        }

                        CGearItemElement *gearItemElement = LXCWxOBJ(element, CGearItemElement);

                        tableauElementMap.insert (std::make_pair (tableau, gearItemElement));

                        gearItemElement->tableau = tableau;
                        gearItemElement->element = element;
                        gearItemElement->tableauElementMap = &tableauElementMap;

                        gearItemElement->SetPart (partIndex);
                        result = gearItemElement->InitializePart (m_item, chan0);

                        /*
                         * We also need to store the locator transform, so it can be looked
                         * up later on when TableauInstance::GetTransform is called.
                         */
                        CLxLoc_Locator locator;
                        if (locator.set (m_item)) {
                                LXtMatrix	 xfrm0, xfrm1;
                                LXtVector	 offset0, offset1;

                                locator.WorldTransform (chan0, xfrm0, offset0);
                                locator.WorldTransform (chan1, xfrm1, offset1);

                                for (unsigned i = 0; i < 3; ++i) {
                                        LXx_VCPY (gearItemElement->m_xfrm0[i], xfrm0[i]);
                                        LXx_VCPY (gearItemElement->m_xfrm1[i], xfrm1[i]);
                                }
                                LXx_VCPY (gearItemElement->m_offset0, offset0);
                                LXx_VCPY (gearItemElement->m_offset1, offset1);
                        }

                        /*
                         * Add our element to the tableau.
                         */
                        result = tbx.AddElement (element, shader);

                        /*
                         * Release our reference, so that Tableau_FreeEltList can free it later on.
                         */
                        lx::UnkRelease (element);
                }
        }
        else {
                result = LXe_OK;
        }

        return result;
}

        LxResult
CGearItemInstance::tsrc_Instance (
        ILxUnknownID	 tableau,
        ILxUnknownID	 instance)
{
        CLxUser_Tableau		 tbx (tableau);
        LxResult		 result = LXe_OK;

        if (tableauElementMap.empty () ||
            (tableauElementMap.find (tableau) == tableauElementMap.end ())) {
                tsrc_Elements (tableau);
        }

        TableauElementMap::iterator iter;
        for (iter = tableauElementMap.lower_bound (tableau);
             iter != tableauElementMap.upper_bound (tableau);
             ++iter) {
                CGearItemElement *gearItemElement = iter->second;

                /*
                 * The following bin is only allocated to obtain the proper
                 * shader, so it's not necessary to initialize as a Gear part.
                 */
                CLxLoc_SurfaceBin	 binObj;
                CLxUser_TableauShader	 shader;
                CGearItemBin	*bin = src_pkg->bin_factory.Alloc (binObj);
                switch (gearItemElement->m_part) {
                        case GEARPART_TEETH:
                                bin->SetPart (GEARPART_TEETH);
                                break;

                        case GEARPART_RIM:
                                bin->SetPart (GEARPART_RIM);
                                break;

                        case GEARPART_SPOKES:
                                bin->SetPart (GEARPART_SPOKES);
                                break;

                        case GEARPART_SHAFT:
                                bin->SetPart (GEARPART_SHAFT);
                                break;
#if defined(CORE_IMPLEMENTED)
                        case GEARPART_CORE:
                                bin->SetPart (GEARPART_CORE);
                                break;
#endif
                }

                if (!tbx.GetShader (shader, tbx.InstanceItem (), binObj)) {
                        result = LXe_NOTFOUND;
                        break;
                }
                else {
                        tbx.AddInstance (instance, gearItemElement->element, shader);
                }
        }

        return result;
}

        LxResult
CGearItemInstance::tsrc_PreviewUpdate (
        int			 chanIndex,
        int			*update)
{

        *update = LXfTBLX_PREVIEW_UPDATE_NONE;

        return LXe_OK;
}

/*
 * tli_ChannelChange replaces the functionality of PreviewUpdate in the newer
 * tableau event system. It listens for a channel event on a gear item, and
 * triggers a full invalidation if one happens.
 */

        void
CGearTableauListener::tli_ChannelChange (
        ILxUnknownID		 tableauObj,
        ILxUnknownID		 itemObj,
        int			 chan)
{
        CLxUser_Tableau		 tableau (tableauObj);
        CLxUser_Item		 item (itemObj);
        CLxUser_SceneService	 svc;
        LXtItemType		 gear_type;

        gear_type = svc.ItemType (SRVs_GEOMETRY_ITEM);

        if (item.IsA (gear_type))
                tableau.UpdateAll ();
}

        static void
PushBeveledHelicalPointPair (
        std::vector<GeoPoint>	&points,
        double			 upperAngle,
        double			 lowerAngle,
        bool			 doubleHelical,
        double			 upperRadius,
        double			 lowerRadius,
        double			 thickness)
{
        double	 sn, cs;
        GeoPoint	 point;

        // upper
        sn  = sin (upperAngle);
        cs  = cos (upperAngle);
        point.vec[0] = sn * upperRadius;
        point.vec[1] = cs * upperRadius;
        point.vec[2] = thickness;
        points.push_back (point);

        if (doubleHelical) {
                // middle
                sn  = sin (lowerAngle);
                cs  = cos (lowerAngle);
                point.vec[0] = sn * lowerRadius;
                point.vec[1] = cs * lowerRadius;
                point.vec[2] = 0;
                points.push_back (point);

                // lower
                sn  = sin (upperAngle);
                cs  = cos (upperAngle);
                point.vec[0] = sn * upperRadius;
                point.vec[1] = cs * upperRadius;
                point.vec[2] = -thickness;
                points.push_back (point);
        }
        else {
                // lower
                sn  = sin (lowerAngle);
                cs  = cos (lowerAngle);
                point.vec[0] = sn * lowerRadius;
                point.vec[1] = cs * lowerRadius;
                point.vec[2] = -thickness;
                points.push_back (point);
        }
}

/*
 * Build the vertex list for the teeth.
 *
 * See the diagram in "GearGraph.pdf" for vertex and edge labeling.
 */
        static void
BuildToothPointList (
        GearGeometry		&gear,
        std::vector<GeoPoint>	&points,
        unsigned		 teeth,
        double			 coverage,
        double			 shaftRad,
        double			 innerRad,
        double			 outerRad,
        double			 thickness,
        double			 contactAngle,
        unsigned		 teethFacing,
        double			 bevelAngle,
        double			 helicalAngle,
        bool			 doubleHelical,
        double			 toothFaceRatio,
        double			 toothTiltAngle,
        double			 toothGrowth,
        unsigned		&pointCount,
        unsigned		&pointStride)
{
        points.clear ();

        double rimInsetRatio = 0, wallInsetRatio = 0;
        double axialShaftInsetRatio = 0, radialShaftInsetRatio = 0;
        double innerSpokeInsetRatio = 0, outerSpokeInsetRatio = 0; // N/A for teeth
        BuildGearConstruct (gear,
                teeth, coverage, shaftRad, innerRad, outerRad, thickness,
                rimInsetRatio, wallInsetRatio,
                axialShaftInsetRatio, radialShaftInsetRatio,
                innerSpokeInsetRatio, outerSpokeInsetRatio,
                contactAngle, teethFacing, bevelAngle, helicalAngle,
                toothFaceRatio, toothTiltAngle, toothGrowth);

        for (unsigned i = 0; i < gear.coveredToothCount; ++i) {
                BuildToothConstruct (gear, i);

                PushBeveledHelicalPointPair (points,
                        gear.apex_angle_0 + helicalAngle,
                        gear.apex_angle_0, doubleHelical,
                        gear.upperBeveledScaledOuterRadius,
                        gear.lowerBeveledScaledOuterRadius,
                        gear.scaledThickness);

                PushBeveledHelicalPointPair (points,
                        gear.contact_angle_2 + helicalAngle,
                        gear.contact_angle_2, doubleHelical,
                        gear.upperBeveledScaledOuterRadius,
                        gear.lowerBeveledScaledOuterRadius,
                        gear.scaledThickness);

                PushBeveledHelicalPointPair (points,
                        gear.contact_angle_4 + helicalAngle,
                        gear.contact_angle_4, doubleHelical,
                        gear.beveledInnerToothRadius, innerRad, thickness);

                PushBeveledHelicalPointPair (points,
                        gear.inner_angle + helicalAngle,
                        gear.inner_angle, doubleHelical,
                        gear.beveledInnerToothRadius, innerRad, thickness);

                PushBeveledHelicalPointPair (points,
                        gear.contact_angle_8 + helicalAngle,
                        gear.contact_angle_8, doubleHelical,
                        gear.beveledInnerToothRadius, innerRad, thickness);

                PushBeveledHelicalPointPair (points,
                        gear.contact_angle_10 + helicalAngle,
                        gear.contact_angle_10, doubleHelical,
                        gear.upperBeveledScaledOuterRadius,
                        gear.lowerBeveledScaledOuterRadius,
                        gear.scaledThickness);

                // virtual edge S maps to edge A

                if (i == 0) {
                        pointStride = static_cast<unsigned>(points.size ());
                }
        }
        pointCount = static_cast<unsigned>(points.size ());

        /*
         * The center points.
         *
         * (Intentionally not included in the logical point count.)
         */
        GeoPoint point;
        point.vec[0] = 0.0;
        point.vec[1] = 0.0;
        point.vec[2] = thickness;
        points.push_back (point);

        point.vec[2] = -thickness;
        points.push_back (point);
}

/*
 * Draw a wireframe for the given edges and points.
 *
 * The edges array is terminated by the entry (-1, -1).
 */
        static void
DrawWireframeEdges (
        std::vector<GeoPoint>	&points,
        CLxLoc_StrokeDraw	&strokeDraw,
        unsigned		 baseEdgeIndex,
        unsigned		 pointCount,
        int			 edges[])
{
        int strokeFlags = LXiSTROKE_ABSOLUTE;
        static const unsigned MAX_EDGE_COUNT = 1024 * 1024;
        unsigned edgeIndex = 0;
        unsigned edge[2];
        bool anotherEdge = true;
        do {
                for (unsigned subIndex = 0; subIndex < 2; ++subIndex) {
                        int pointIndex = edges[edgeIndex * 2 + subIndex];
                        if (pointIndex == -1) {
                                anotherEdge = false;
                                break;
                        }
                        edge[subIndex] = (baseEdgeIndex + pointIndex) % pointCount;
                }
                if (anotherEdge) {
                        LXtVector vert;

                        LXx_VCPY (vert, points[edge[0] % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        LXx_VCPY (vert, points[edge[1] % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        ++edgeIndex;
                }
        } while (anotherEdge && edgeIndex < MAX_EDGE_COUNT);
}

/*
 * Draw the edges of each tooth.
 */
        static void
DrawToothEdges (
        std::vector<GeoPoint>	&points,
        unsigned		 pointCount,
        unsigned		 pointStride,
        unsigned		 teeth,
        double			 coverage,
        bool			 doubleHelical,
        CLxLoc_StrokeDraw	&strokeDraw,
        LXtVector		 itemColor,
        float			 lineWidth)
{
        /*
         * Draw the edges of each tooth.
         *
         * The item color is automatically set according to the last hit test.
         */
        strokeDraw.BeginW (LXiSTROKE_LINES, itemColor, 1.0, lineWidth);

        /*
         * See the diagram in "GearGraph.pdf" for vertex and edge labeling.
         */
        unsigned k = 0;
        unsigned toothCount = static_cast<unsigned>(teeth * coverage);
        for (unsigned i = 0; i < toothCount; ++i) {
                if (doubleHelical) {
                        static int dhToothEdges[] = {
                                0, 1,	// A
                                1, 2,	// A'
                                0, 3,	// B
                                2, 5,	// C
                                3, 4,	// D
                                4, 5,	// D'
                                1, 4,	// AD
                                3, 6,	// E
                                5, 8,	// F
                                6, 7,	// G
                                7, 8,	// G'
                                4, 7,	// DG
                                6, 9,	// H
                                8, 11,	// I
                                9, 10,	// J
                                10, 11,	// J'
                                7, 10,	// GJ
                                9, 12,	// K
                                11, 14,	// L
                                12, 13,	// M
                                13, 14,	// M'
                                10, 13,	// JM
                                12, 15,	// N
                                14, 17,	// O
                                15, 16,	// P
                                16, 17,	// P'
                                13, 16,	// MP
                                -1, -1
                        };

                        DrawWireframeEdges (points, strokeDraw, k, pointCount, dhToothEdges);

                        /*
                         * Only wrap around to the beginning with full coverage.
                         */
                        if (!(coverage < 1.0 && (i == toothCount - 1))) {
                                static int dhClosedToothEdges[] = {
                                        15, 18,	// Q
                                        17, 20,	// R
                                        16, 19,	// PS
                                        -1, -1
                                };

                                DrawWireframeEdges (points, strokeDraw, k, pointCount, dhClosedToothEdges);
                        }
                }
                else {
                        static int shToothEdges[] = {
                                0, 1,	// A
                                0, 2,	// B
                                1, 3,	// C
                                2, 3,	// D
                                2, 4,	// E
                                3, 5,	// F
                                4, 5,	// G
                                4, 6,	// H
                                5, 7,	// I
                                6, 7,	// J
                                6, 8,	// K
                                7, 9,	// L
                                8, 9,	// M
                                8, 10,	// N
                                9, 11,	// O
                                10, 11,	// P
                                -1, -1
                        };

                        DrawWireframeEdges (points, strokeDraw, k, pointCount, shToothEdges);

                        if (!(coverage < 1.0 && (i == toothCount - 1))) {
                                static int shClosedToothEdges[] = {
                                        10, 12,	// Q
                                        11, 13,	// R
                                        -1, -1
                                };

                                DrawWireframeEdges (points, strokeDraw, k, pointCount, shClosedToothEdges);
                        }
                }

                // Edge S is formed by edge A of the next tooth.

                k += pointStride;
        }
}

/*
 * Build the second vertex list for the shaft.
 */
        static void
BuildShaftPointList (
        std::vector<GeoPoint>	&points,
        double			 shaftRad,
        double			 thickness,
        double			 coverage,
        unsigned		 resolution,
        unsigned		&shaftSides,
        unsigned		&pointCount,
        unsigned		&pointStride)
{
        points.clear ();

        float scale = 1.0;
        scale /= 100.0;
        shaftSides = static_cast<unsigned>(PI / sqrt (scale / shaftRad)) * resolution;
        if (shaftSides < 8)
                shaftSides = 8;
        else if (shaftSides > 1024)
                shaftSides = 1024;

        unsigned coveredShaftSides = static_cast<unsigned>(shaftSides * coverage);
        for (unsigned i = 0; i < coveredShaftSides; ++i) {
                double angle = TWO_PI * i / shaftSides;

                PushPointPair (points, angle, shaftRad, thickness);

                if (i == 0) {
                        pointStride = static_cast<unsigned>(points.size ());
                }
        }
        pointCount = static_cast<unsigned>(points.size ());
}

/*
 * Draw the edges of the shaft.
 */
        static void
DrawShaftEdges (
        std::vector<GeoPoint>	&points,
        unsigned		 shaftSides,
        unsigned		 pointCount,
        unsigned		 pointStride,
        double			 coverage,
        CLxLoc_StrokeDraw	&strokeDraw,
        LXtVector		 itemColor,
        float			 lineWidth)
{
        strokeDraw.BeginW (LXiSTROKE_LINES, itemColor, 1.0, lineWidth);

        LXtVector vert;
        unsigned k = 0;
        int strokeFlags = LXiSTROKE_ABSOLUTE;
        unsigned coveredShaftSides = static_cast<unsigned>(shaftSides * coverage);
        for (unsigned i = 0; i < coveredShaftSides; ++i) {
                // A
                LXx_VCPY (vert, points[k].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 1) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                if (!(coverage < 1.0 && (i == coveredShaftSides - 1))) {
                        // B
                        LXx_VCPY (vert, points[k].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        LXx_VCPY (vert, points[(k + 2) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        // C
                        LXx_VCPY (vert, points[(k + 1) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        LXx_VCPY (vert, points[(k + 3) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);
                }

                k += pointStride;
        }
}

        static void
BuildRimPointList (
        std::vector<GeoPoint>	&points,
        double			 outerSpokeRad,
        double			 innerSpokeRad,
        double			 outerThickness,
        double			 innerThickness,
        double			 coverage,
        unsigned		 resolution,
        unsigned		&rimSides,
        unsigned		&pointCount,
        unsigned		&pointStride)
{
        points.clear ();

        float scale = 1.0;
        scale /= 100.0;
        rimSides = static_cast<unsigned>(PI / sqrt (scale / outerSpokeRad)) * resolution;
        if (rimSides < 8)
                rimSides = 8;
        else if (rimSides > 1024)
                rimSides = 1024;

        unsigned coveredRimSides = static_cast<unsigned>(rimSides * coverage);
        for (unsigned i = 0; i < coveredRimSides; ++i) {
                double angle = TWO_PI * i / rimSides;

                PushPointPair (points, angle, outerSpokeRad, outerThickness);
                PushPointPair (points, angle, innerSpokeRad, innerThickness);

                if (i == 0) {
                        pointStride = static_cast<unsigned>(points.size ());
                }
        }
        pointCount = static_cast<unsigned>(points.size ());
}

/*
 * Draw the edges of the rim.
 */
        static void
DrawRimEdges (
        std::vector<GeoPoint>	&points,
        unsigned		 rimSides,
        unsigned		 pointCount,
        unsigned		 pointStride,
        double			 coverage,
        CLxLoc_StrokeDraw	&strokeDraw,
        LXtVector		 itemColor,
        float			 lineWidth)
{
        strokeDraw.BeginW (LXiSTROKE_LINES, itemColor, 1.0, lineWidth);

        LXtVector vert;
        unsigned k = 0;
        int strokeFlags = LXiSTROKE_ABSOLUTE;
        unsigned coveredRimSides = static_cast<unsigned>(rimSides * coverage);
        for (unsigned i = 0; i < coveredRimSides; ++i) {
                // A
                LXx_VCPY (vert, points[k].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 1) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                // D
                LXx_VCPY (vert, points[(k + 2) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 3) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                if (!(coverage < 1.0 && (i == coveredRimSides - 1))) {
                        // B
                        LXx_VCPY (vert, points[k].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        LXx_VCPY (vert, points[(k + 4) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        // C
                        LXx_VCPY (vert, points[(k + 1) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        LXx_VCPY (vert, points[(k + 5) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        // E
                        LXx_VCPY (vert, points[(k + 2) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        LXx_VCPY (vert, points[(k + 6) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        // F
                        LXx_VCPY (vert, points[(k + 3) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);

                        LXx_VCPY (vert, points[(k + 7) % pointCount].vec);
                        strokeDraw.Vertex (vert, strokeFlags);
                }

                k += pointStride;
        }
}

/*
 * Build a vertex list for the spokes.
 */
        static void
BuildSpokePointList (
        std::vector<GeoPoint>	&points,
        unsigned		 spokes,
        double			 coverage,
        double			 outerSpokeRad,
        double			 innerSpokeRad,
        double			 spokeSweepRatio,
        double			 spokeSwirlAngle,
        double			 innerThickness,
        double			 outerThickness,
        unsigned		&pointCount,
        unsigned		&pointStride)
{
        points.clear ();

        spokeSweepRatio = 1.0 - spokeSweepRatio;
        unsigned coveredSpokes = static_cast<unsigned>(spokes * coverage);
        for (unsigned i = 0; i < coveredSpokes; ++i) {
                double	 contactAngle2, apexAngle0, contactAngle10;
                CalcSpokeContactAngles (i, spokes, spokeSweepRatio,
                        contactAngle2, apexAngle0, contactAngle10);

                PushPointPair (points, contactAngle2, outerSpokeRad, outerThickness);
                PushPointPair (points, contactAngle2, innerSpokeRad, innerThickness);

                PushPointPair (points, contactAngle10, outerSpokeRad, outerThickness);
                PushPointPair (points, contactAngle10, innerSpokeRad, innerThickness);

                if (i == 0) {
                        pointStride = static_cast<unsigned>(points.size ());
                }
        }
        pointCount = static_cast<unsigned>(points.size ());
}

/*
 * Draw the edges of the spokes.
 */
        static void
DrawSpokeEdges (
        std::vector<GeoPoint>	&points,
        unsigned		 spokes,
        unsigned		 pointCount,
        unsigned		 pointStride,
        CLxLoc_StrokeDraw	&strokeDraw,
        LXtVector		 itemColor,
        float			 lineWidth)
{
        strokeDraw.BeginW (LXiSTROKE_LINES, itemColor, 1.0, lineWidth);

        LXtVector vert;
        unsigned k = 0;
        int strokeFlags = LXiSTROKE_ABSOLUTE;
        for (unsigned i = 0; i < spokes; ++i) {
                /*
                 * Leading Edge
                 */

                // A
                LXx_VCPY (vert, points[k].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 1) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                // B
                LXx_VCPY (vert, points[k].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 2) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                // C
                LXx_VCPY (vert, points[(k + 1) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 3) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                // D
                LXx_VCPY (vert, points[(k + 2) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 3) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                /*
                 * Trailing Edge
                 */

                // E
                LXx_VCPY (vert, points[(k + 4) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 5) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                // F
                LXx_VCPY (vert, points[(k + 4) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 6) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                // G
                LXx_VCPY (vert, points[(k + 5) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 7) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                // H
                LXx_VCPY (vert, points[(k + 6) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                LXx_VCPY (vert, points[(k + 7) % pointCount].vec);
                strokeDraw.Vertex (vert, strokeFlags);

                k += pointStride;
        }
}

/*
 * Based on the channel values, draw the abstract item representation
 * using the stroke drawing interface.
 */
        LxResult
CGearItemInstance::vitm_Draw (
        ILxUnknownID	 itemChanRead,
        ILxUnknownID	 viewStrokeDraw,
        int		 selectionFlags,
        LXtVector	 itemColor)
{
        CLxUser_ChannelRead	 chanRead;
        CLxLoc_StrokeDraw	 strokeDraw;
        float			 lineWidth;
        int			 chanIndex;
        double			 coverage;
        double			 toothSpacing;
        unsigned		 teeth;
        double			 outerToothRadius, innerToothRadius, shaftRad;
        double			 contactAngle;
        double			 thickness;
        bool			 hasSpokes;
        unsigned		 spokes = 0;
        bool			 hasRim;
        double			 rimInsetRatio = 0;
        double			 wallInsetRatio;
        double			 axialShaftInsetRatio, radialShaftInsetRatio;
        double			 innerSpokeInsetRatio, outerSpokeInsetRatio;
        double			 spokeSweepRatio, spokeSwirlAngle;
        unsigned		 teethFacing = TEETH_FACING_OUTSIDE;
        double			 bevelAngle, helicalAngle;
        bool			 doubleHelical;
        double			 toothFaceRatio, toothTiltAngle, toothGrowth;
        unsigned		 resolution;

        std::vector<GeoPoint>	 points;

        chanRead.set (itemChanRead);
        strokeDraw.set (viewStrokeDraw);

        /*
         * Fetch the dimension and count values for the current frame.
         */
        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_COVERAGE, coverage))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_SPACING, toothSpacing))
                return LXe_NOTFOUND;

        if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_TEETH, teeth))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_CONTACT_ANGLE, contactAngle))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_THICKNESS, thickness))
                return LXe_NOTFOUND;
        thickness /= 2; // enables use of +/- thickness throughout

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_SHAFT, shaftRad))
                return LXe_NOTFOUND;

        chanIndex = m_item.ChannelIndex (CHANs_GEAR_HAS_SPOKES);
        if (chanIndex < 0)
                return LXe_NOTFOUND;
        hasSpokes = (chanRead.IValue (m_item, chanIndex) != 0);
        if (hasSpokes) {
                if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_SPOKES, spokes))
                        return LXe_NOTFOUND;
        }

        chanIndex = m_item.ChannelIndex (CHANs_GEAR_HAS_RIM);
        if (chanIndex < 0)
                return LXe_NOTFOUND;
        hasRim = (chanRead.IValue (m_item, chanIndex) != 0);
        if (hasRim) {
                if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_RIM_INSET_RATIO, rimInsetRatio))
                        return LXe_NOTFOUND;
        }

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_WALL_INSET_RATIO, wallInsetRatio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO, axialShaftInsetRatio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO, radialShaftInsetRatio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_INNER_SPOKE_INSET_RATIO, innerSpokeInsetRatio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_OUTER_SPOKE_INSET_RATIO, outerSpokeInsetRatio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_SPOKE_SWEEP_RATIO, spokeSweepRatio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_SPOKE_SWIRL_ANGLE, spokeSwirlAngle))
                return LXe_NOTFOUND;

        if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_TEETH_FACING, teethFacing))
                return LXe_NOTFOUND;

        CalcToothRadii (toothSpacing, teeth, teethFacing, outerToothRadius, innerToothRadius);
        handleRadiusFactor = outerToothRadius / toothSpacing;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_BEVEL_ANGLE, bevelAngle))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_HELICAL_ANGLE, helicalAngle))
                return LXe_NOTFOUND;

        chanIndex = m_item.ChannelIndex (CHANs_GEAR_DOUBLE_HELICAL);
        if (chanIndex < 0)
                return LXe_NOTFOUND;
        doubleHelical = (chanRead.IValue (m_item, chanIndex) != 0);

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_FACE_RATIO, toothFaceRatio))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_TILT_ANGLE, toothTiltAngle))
                return LXe_NOTFOUND;

        if (!ReadFloatChannel (m_item, chanRead, CHANs_GEAR_TOOTH_GROWTH, toothGrowth))
                return LXe_NOTFOUND;

        if (!ReadUnsignedChannel (m_item, chanRead, CHANs_GEAR_RESOLUTION, resolution))
                return LXe_NOTFOUND;

        /*
         * Use a thicker line width when selected or rollover.
         */
        if (selectionFlags & LXiSELECTION_SELECTED ||
            selectionFlags & LXiSELECTION_ROLLOVER) {
                lineWidth = 2.0;
        }
        else {
                lineWidth = 1.0;
        }

        /*
         * [TODO] Beveled tooth shape at larger radius/resolution.
         */

        /*
         * Build the first vertex list for the teeth,
         * which form the outer gear shape.
         *
         * See the diagram in "GearGraph.pdf" for vertex and edge labeling.
         */
        GearGeometry	gear;
        unsigned pointStride, pointCount;
        BuildToothPointList (
                gear, points, teeth, coverage, shaftRad,
                innerToothRadius, outerToothRadius, thickness, contactAngle,
                teethFacing,
                bevelAngle, helicalAngle, doubleHelical,
                toothFaceRatio, toothTiltAngle, toothGrowth,
                pointCount, pointStride);

        /*
         * Draw the edges of each tooth.
         */
        DrawToothEdges (
                points, pointCount, pointStride, teeth,
                coverage, doubleHelical,
                strokeDraw, itemColor, lineWidth);

        if (teethFacing == TEETH_FACING_OUTSIDE) {
                /*
                 * Build the second vertex list for the shaft.
                 */
                unsigned shaftSides;
                BuildShaftPointList (
                        points, shaftRad, thickness * axialShaftInsetRatio,
                        coverage, resolution,
                        shaftSides, pointCount, pointStride);

                /*
                 * Draw the edges of the shaft.
                 */
                DrawShaftEdges (points, shaftSides, pointCount, pointStride,
                        coverage, strokeDraw, itemColor, lineWidth);

                /*
                 * Build and draw the spokes.
                 */
                double outerSpokeRad = (innerToothRadius - gear.bevelRadiusOffset) * wallInsetRatio;
                double innerSpokeRad = shaftRad * (1.0 + radialShaftInsetRatio);

                /*
                 * The rim edge and spokes are only drawn if there is sufficient
                 * clearance between the inner tooth radius and the shaft radius.
                 */
                if ((hasSpokes || (rimInsetRatio != 0.0)) && (outerSpokeRad > innerSpokeRad)) {
                        /*
                         * Build the third vertex list for the rims.
                         */
                        unsigned rimSides;
                        double innerRimEdgeRatio;
                        if (axialShaftInsetRatio < rimInsetRatio) {
                                innerRimEdgeRatio = axialShaftInsetRatio;
                        }
                        else {
                                innerRimEdgeRatio = rimInsetRatio;
                        }
                        BuildRimPointList (points, outerSpokeRad, innerSpokeRad,
                                thickness, thickness * innerRimEdgeRatio, coverage, resolution,
                                rimSides, pointCount, pointStride);

                        /*
                         * Draw the edges of the rims.
                         */
                        DrawRimEdges (points, rimSides, pointCount, pointStride,
                                coverage, strokeDraw, itemColor, lineWidth);

                        /*
                         * If the interior of the rim is inset (or outset)
                         * draw an edge along its circumference.
                         */
                        if ((rimInsetRatio != 0) && rimInsetRatio != 1.0) {
                                /*
                                 * Build another vertex list for the inset interior rim.
                                 */
                                unsigned rimSides;
                                BuildRimPointList (points, outerSpokeRad, innerSpokeRad,
                                        thickness * rimInsetRatio, thickness * axialShaftInsetRatio,
                                        coverage, resolution,
                                        rimSides, pointCount, pointStride);

                                /*
                                 * Draw the edges of the rims.
                                 */
                                DrawRimEdges (points, rimSides, pointCount, pointStride,
                                        coverage, strokeDraw, itemColor, lineWidth);
                        }

                        if (hasSpokes) {
                                /*
                                 * Build another vertex list for the spokes.
                                 */
                                BuildSpokePointList (
                                        points, spokes, coverage, outerSpokeRad, innerSpokeRad,
                                        spokeSweepRatio, spokeSwirlAngle,
                                        thickness * innerSpokeInsetRatio,
                                        thickness * outerSpokeInsetRatio,
                                        pointCount, pointStride);

                                /*
                                 * Draw the edges of the spokes.
                                 */
                                unsigned coveredSpokes = static_cast<unsigned>(spokes * coverage);
                                DrawSpokeEdges (points, coveredSpokes, pointCount, pointStride,
                                        strokeDraw, itemColor, lineWidth);
                        }
                }
        }
        else if (teethFacing == TEETH_FACING_INSIDE) {
                double innerWallRadius = gear.beveledInnerToothRadius * (1.0 + (1.0 - wallInsetRatio));

                /*
                 * Build the second vertex list for the outer gear wall.
                 */
                unsigned wallSides;
                BuildShaftPointList (
                        points, innerWallRadius, thickness,
                        coverage, resolution,
                        wallSides, pointCount, pointStride);

                /*
                 * Draw the edges of the outer gear wall.
                 */
                DrawShaftEdges (points, wallSides, pointCount, pointStride,
                        coverage, strokeDraw, itemColor, lineWidth);
        }

        return LXe_OK;
}

        LxResult
CGearItemInstance::vitm_HandleCount (
        int		*count)
{
        *count = 4;

        return LXe_OK;
}
// This method tells the transform tool about the type and constraints for handle[index]
        LxResult
CGearItemInstance::vitm_HandleMotion (
        int		 handleIndex,
        int		*motionFlags,
        double		*min,
        double		*max,
        LXtVector	 plane,
        LXtVector	 offset)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if (handleIndex < 4) {
                *motionFlags = LXfVHANDLE_DRAW_BOX|LXfVHANDLE_CON_LINEAR;

                *min = 0.0001;
                *max = 10000;

                plane[0] = plane[1] = plane[2] = 0.0;
                plane[handleIndex&1] = 1;

                offset[0] = offset[1] = offset[2] = 0.0;
                offset[handleIndex&1] = 1;

                result = LXe_OK;
        }

        return result;
}

// tell tool which channel is edited by handle[index]. 
// For 3D handles with LXfVHANDLE_VAL_VECTOR set in motionFlags, we use 3 consectutive channels 
// starting at chanIndex
        LxResult
CGearItemInstance::vitm_HandleChannel (
        int		 handleIndex,
        int		*chanIndex)
{
        *chanIndex = m_item.ChannelIndex (CHANs_GEAR_TOOTH_SPACING);
        return LXe_OK;
}

// Translate channel value(s) into the handle position
        LxResult
CGearItemInstance::vitm_HandleValueToPosition (
        int		 handleIndex,
        double		*chanValue,
        LXtVector	 position)
{
        float	rad = *chanValue * handleRadiusFactor;
        position[0] = position[1] = position[2] = 0.0;
        position[handleIndex&1] = handleIndex&2 ? -rad : rad;
        return LXe_OK;
}

// Translate handle's 3D position into channel value(s)
        LxResult
CGearItemInstance::vitm_HandlePositionToValue (
        int		 handleIndex,
        LXtVector	 position,
        double		*chanValue)
{
        float spacing = position[handleIndex&1] / handleRadiusFactor;
        *chanValue = LXxABS (spacing);
        return LXe_OK;
}

        LxResult
CGearItemInstance::isurf_GetSurface (
        ILxUnknownID	 chanRead,
        unsigned	 morph,
        void		**ppvObj)
{
        CGearItemSurface	*surface = src_pkg->surf_factory.Alloc (ppvObj);
        if (surface) {
                CLxUser_ChannelRead channelRead(chanRead);
                surface->Initialize (src_pkg, m_item, channelRead);
        }
        else {
                return LXe_FAILED;
        }

        return LXe_OK;
}

        LxResult
CGearItemInstance::isurf_Prepare (
        ILxUnknownID	 eval,
        unsigned	*index)
{
        CLxUser_Evaluation evaluation (eval);

        /*
         * Add our custom channels as attributes.
         */
        unsigned baseChanIndex = evaluation.AddChan (m_item, CHANs_GEAR_COVERAGE);
        *index = baseChanIndex;

        unsigned chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_TOOTH_SPACING);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_CONTACT_ANGLE);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_THICKNESS);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_TEETH);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_SHAFT);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_HAS_SPOKES);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_SPOKES);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_HAS_RIM);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_RIM_INSET_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_WALL_INSET_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_INNER_SPOKE_INSET_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_OUTER_SPOKE_INSET_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_SPOKE_SWEEP_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_SPOKE_SWIRL_ANGLE);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_TEETH_FACING);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_BEVEL_ANGLE);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_HELICAL_ANGLE);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_DOUBLE_HELICAL);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_TOOTH_FACE_RATIO);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_TOOTH_TILT_ANGLE);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_TOOTH_GROWTH);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_RESOLUTION);
        chanIndex = evaluation.AddChan (m_item, CHANs_GEAR_RESOLUTION);

        return LXe_OK;
}

enum
{
        GEAR_COVERAGE,
        GEAR_TOOTH_SPACING,
        GEAR_CONTACT_ANGLE,
        GEAR_THICKNESS,
        GEAR_TEETH,
        GEAR_SHAFT,
        GEAR_HAS_SPOKES,
        GEAR_SPOKES,
        GEAR_HAS_RIM,
        GEAR_RIM_INSET_RATIO,
        GEAR_WALL_INSET_RATIO,
        GEAR_AXIAL_SHAFT_INSET_RATIO,
        GEAR_RADIAL_SHAFT_INSET_RATIO,
        GEAR_INNER_SPOKE_INSET_RATIO,
        GEAR_OUTER_SPOKE_INSET_RATIO,
        GEAR_SPOKE_SWEEP_RATIO,
        GEAR_SPOKE_SWIRL_ANGLE,
        GEAR_TEETH_FACING,
        GEAR_BEVEL_ANGLE,
        GEAR_HELICAL_ANGLE,
        GEAR_DOUBLE_HELICAL,
        GEAR_TOOTH_FACE_RATIO,
        GEAR_TOOTH_TILT_ANGLE,
        GEAR_TOOTH_GROWTH,
        GEAR_RESOLUTION
};

        LxResult
CGearItemInstance::isurf_Evaluate (
        ILxUnknownID	 attr,
        unsigned	 index,
        void		**ppvObj)
{
        CLxUser_Attributes attributes(attr);

        CGearItemSurface	*surface = src_pkg->surf_factory.Alloc (ppvObj);
        if (surface) {
                double coverage = attributes.Float (index + GEAR_COVERAGE);
                double toothSpacing = attributes.Float (index + GEAR_TOOTH_SPACING);
                double contactAngle = attributes.Float (index + GEAR_CONTACT_ANGLE);
                double thickness = attributes.Float (index + GEAR_THICKNESS);
                unsigned teeth = static_cast<unsigned>(attributes.Int (index + GEAR_TEETH));
                double shaft = attributes.Float (index + GEAR_SHAFT);
                bool hasSpokes = attributes.Int (index + GEAR_HAS_SPOKES) ? true : false;
                unsigned spokes = 0;
                if (hasSpokes) {
                        spokes = static_cast<unsigned>(attributes.Int (index + GEAR_SPOKES));
                }
                bool hasRim = attributes.Int (index + GEAR_HAS_RIM) ? true : false;
                double rimInsetRatio = attributes.Float (index + GEAR_RIM_INSET_RATIO);
                double wallInsetRatio = attributes.Float (index + GEAR_WALL_INSET_RATIO);
                double axialShaftInsetRatio = attributes.Float (index + GEAR_AXIAL_SHAFT_INSET_RATIO);
                double radialShaftInsetRatio = attributes.Float (index + GEAR_RADIAL_SHAFT_INSET_RATIO);
                double innerSpokeInsetRatio = attributes.Float (index + GEAR_INNER_SPOKE_INSET_RATIO);
                double outerSpokeInsetRatio = attributes.Float (index + GEAR_OUTER_SPOKE_INSET_RATIO);
                double spokeSweepRatio = attributes.Float (index + GEAR_SPOKE_SWEEP_RATIO);
                double spokeSwirlAngle = attributes.Float (index + GEAR_SPOKE_SWIRL_ANGLE);
                unsigned teethFacing = attributes.Int (index + GEAR_TEETH_FACING);
                double bevelAngle = attributes.Float (index + GEAR_BEVEL_ANGLE);
                double helicalAngle = attributes.Float (index + GEAR_HELICAL_ANGLE);
                bool doubleHelical = attributes.Int (index + GEAR_DOUBLE_HELICAL) ? true : false;
                double toothFaceRatio = attributes.Float (index + GEAR_TOOTH_FACE_RATIO);
                double toothTiltAngle = attributes.Float (index + GEAR_TOOTH_TILT_ANGLE);
                double toothGrowth = attributes.Float (index + GEAR_TOOTH_GROWTH);
                unsigned resolution = attributes.Int (index + GEAR_RESOLUTION);

                double max_radius = CalcMaxRadius (
                        toothSpacing, teeth, thickness,
                        teethFacing,
                        wallInsetRatio,
                        bevelAngle, toothGrowth);

                surface->Initialize (src_pkg,
                        coverage, toothSpacing, contactAngle, thickness, teeth,
                        shaft, spokes, hasRim, rimInsetRatio,
                        wallInsetRatio,
                        axialShaftInsetRatio, radialShaftInsetRatio,
                        innerSpokeInsetRatio, outerSpokeInsetRatio,
                        spokeSweepRatio, spokeSwirlAngle,
                        teethFacing,
                        bevelAngle, helicalAngle, doubleHelical,
                        toothFaceRatio, toothTiltAngle, toothGrowth,
                        resolution, max_radius);
        }
        else {
                return LXe_FAILED;
        }

        return LXe_OK;
}

/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 *
 * Our GearItem item type is a subtype of "locator".
 */
LXtTagInfoDesc	 CGearItemPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,	"locator"	},
        { LXsPKG_IS_MASK,	"."		},
        { LXsSRV_LOGSUBSYSTEM,	"gear-item"	},
        { 0 }
};

CGearItemPackage::CGearItemPackage ()
{
        gear_factory.AddInterface (new CLxIfc_PackageInstance<CGearItemInstance>);
        gear_factory.AddInterface (new CLxIfc_TableauSource<CGearItemInstance>);
        gear_factory.AddInterface (new CLxIfc_ViewItem3D<CGearItemInstance>);
        gear_factory.AddInterface (new CLxIfc_SurfaceItem<CGearItemInstance>);

        elt_factory.AddInterface (new CLxIfc_TableauSurface<CGearItemElement>);
        elt_factory.AddInterface (new CLxIfc_TableauInstance<CGearItemElement>);

        surf_factory.AddInterface (new CLxIfc_Surface<CGearItemSurface>);

        bin_factory.AddInterface (new CLxIfc_SurfaceBin<CGearItemBin>);
        bin_factory.AddInterface (new CLxIfc_StringTag<CGearItemBin>);
        bin_factory.AddInterface (new CLxIfc_TableauSurface<CGearItemBin>);

        my_type = LXiTYPE_NONE;
}

        LxResult
CGearItemPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel (CHANs_GEAR_COVERAGE, LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 1);
        ac.SetHint (hint_Coverage);

        ac.NewChannel (CHANs_GEAR_TOOTH_SPACING, LXsTYPE_DISTANCE);
        ac.SetDefault (0.16, 0);
        ac.SetHint (hint_ToothSpacing);

        ac.NewChannel (CHANs_GEAR_CONTACT_ANGLE, LXsTYPE_ANGLE);
        ac.SetDefault (25.0 * DEG2RAD, 1);
        ac.SetHint (hint_ContactAngle);

        ac.NewChannel (CHANs_GEAR_THICKNESS, LXsTYPE_DISTANCE);
        ac.SetDefault (0.16, 0);
        ac.SetHint (hint_Thickness);

        ac.NewChannel (CHANs_GEAR_TEETH, LXsTYPE_INTEGER);
        ac.SetDefault (32.0, 32);
        ac.SetHint (hint_Teeth);

        ac.NewChannel (CHANs_GEAR_SHAFT, LXsTYPE_DISTANCE);
        ac.SetDefault (0.1, 0);
        ac.SetHint (hint_shaft);

        ac.NewChannel (CHANs_GEAR_HAS_SPOKES, LXsTYPE_BOOLEAN);
        ac.SetDefault (1, 1);

        ac.NewChannel (CHANs_GEAR_SPOKES, LXsTYPE_INTEGER);
        ac.SetDefault (5.0, 5);
        ac.SetHint (hint_Spokes);

        ac.NewChannel (CHANs_GEAR_HAS_RIM, LXsTYPE_BOOLEAN);
        ac.SetDefault (0, 0);

        ac.NewChannel (CHANs_GEAR_RIM_INSET_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (0.5, 1);
        ac.SetHint (hint_RimInsetRatio);

        ac.NewChannel (CHANs_GEAR_WALL_INSET_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (0.85, 0);
        ac.SetHint (hint_WallInsetRatio);

        ac.NewChannel (CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (0.85, 0);
        ac.SetHint (hint_AxialShaftInsetRatio);

        ac.NewChannel (CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (0.25, 0);
        ac.SetHint (hint_RadialShaftInsetRatio);

        ac.NewChannel (CHANs_GEAR_INNER_SPOKE_INSET_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (0.7, 0);
        ac.SetHint (hint_SpokeInsetRatio);

        ac.NewChannel (CHANs_GEAR_OUTER_SPOKE_INSET_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (0.9, 0);
        ac.SetHint (hint_SpokeInsetRatio);

        ac.NewChannel (CHANs_GEAR_SPOKE_SWEEP_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (0.25, 0);
        ac.SetHint (hint_SpokeSweepRatio);

        ac.NewChannel (CHANs_GEAR_SPOKE_SWIRL_ANGLE, LXsTYPE_ANGLE);
        ac.SetDefault (0.0, 0);
        ac.SetHint (hint_SpokeSwirlAngle);

        ac.NewChannel (CHANs_GEAR_TEETH_FACING, LXsTYPE_INTEGER);
        ac.SetDefault (0.0, TEETH_FACING_OUTSIDE);
        ac.SetHint (hint_teethFacing);

        ac.NewChannel (CHANs_GEAR_BEVEL_ANGLE, LXsTYPE_ANGLE);
        ac.SetDefault (0.0 * DEG2RAD, 0);
        ac.SetHint (hint_BevelAngle);

        ac.NewChannel (CHANs_GEAR_HELICAL_ANGLE, LXsTYPE_ANGLE);
        ac.SetDefault (0.0 * DEG2RAD, 0);
        ac.SetHint (hint_HelicalAngle);

        ac.NewChannel (CHANs_GEAR_DOUBLE_HELICAL, LXsTYPE_BOOLEAN);
        ac.SetDefault (0, 0);

        ac.NewChannel (CHANs_GEAR_TOOTH_FACE_RATIO, LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 1);

        ac.NewChannel (CHANs_GEAR_TOOTH_TILT_ANGLE, LXsTYPE_ANGLE);
        ac.SetDefault (0.0 * DEG2RAD, 0);
        ac.SetHint (hint_ToothTiltAngle);

        ac.NewChannel (CHANs_GEAR_TOOTH_GROWTH, LXsTYPE_PERCENT);
        ac.SetDefault (1.0, 1);
        ac.SetHint (hint_ToothGrowth);

        ac.NewChannel (CHANs_GEAR_RESOLUTION, LXsTYPE_INTEGER);
        ac.SetDefault (8.0, 8);
        ac.SetHint (hint_Resolution);

        return LXe_OK;
}

        LxResult
CGearItemPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return (gear_factory.TestInterface (guid) ? LXe_TRUE : LXe_FALSE);
}

        LxResult
CGearItemPackage::pkg_Attach (
        void		       **ppvObj)
{
        CGearItemInstance	*gear = gear_factory.Alloc (ppvObj);

        gear->src_pkg = this;

        return LXe_OK;
}

/* 
 * ----------------------------------------------------------------
 * Channel UI interface.
 */

        LxResult
CGearItemPackage::cui_Enabled (
        const char	*channelName,
        ILxUnknownID	 msg,
        ILxUnknownID	 item,
        ILxUnknownID	 read)
{
        LxResult	result = LXe_OK;

        if ((strcmp (channelName, CHANs_GEAR_SPOKES) == 0) ||
            (strcmp (channelName, CHANs_GEAR_SPOKE_SWEEP_RATIO) == 0) ||
            (strcmp (channelName, CHANs_GEAR_INNER_SPOKE_INSET_RATIO) == 0) ||
            (strcmp (channelName, CHANs_GEAR_OUTER_SPOKE_INSET_RATIO) == 0) ||
            (strcmp (channelName, CHANs_GEAR_SPOKE_SWEEP_RATIO) == 0) ||
            (strcmp (channelName, CHANs_GEAR_SPOKE_SWIRL_ANGLE) == 0)){
                CLxUser_Item		 src (item);
                CLxUser_ChannelRead	 chan (read);

                if (chan.IValue (src, CHANs_GEAR_HAS_SPOKES) == 0) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (GEAR_ITEM_MSG_TABLE, GEAR_ITEM_MSG_SPOKE_OPTIONS_SPOKES_ENABLED);

                        result = LXe_CMD_DISABLED;
                }
                else if (chan.IValue (src, CHANs_GEAR_TEETH_FACING) == TEETH_FACING_INSIDE) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (GEAR_ITEM_MSG_TABLE, GEAR_ITEM_MSG_SPOKE_OPTIONS_TEETH_INSIDE);

                        result = LXe_CMD_DISABLED;
                }
        }
        else if (strcmp (channelName, CHANs_GEAR_RIM_INSET_RATIO) == 0) {
                CLxUser_Item		 src (item);
                CLxUser_ChannelRead	 chan (read);

                if ((chan.IValue (src, CHANs_GEAR_HAS_RIM) == 0) ||
                    (chan.IValue (src, CHANs_GEAR_TEETH_FACING) == TEETH_FACING_INSIDE)) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (GEAR_ITEM_MSG_TABLE, GEAR_ITEM_MSG_RIM_INSET_RIM_ENABLED);

                        result = LXe_CMD_DISABLED;
                }
        }
        else if ((strcmp (channelName, CHANs_GEAR_HAS_RIM) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_HAS_SPOKES) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_SHAFT) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO) == 0)) {
                CLxUser_Item		 src (item);
                CLxUser_ChannelRead	 chan (read);

                if (chan.IValue (src, CHANs_GEAR_TEETH_FACING) == TEETH_FACING_INSIDE) {
                        CLxUser_Message		 res (msg);

                        res.SetCode (LXe_CMD_DISABLED);
                        res.SetMsg  (GEAR_ITEM_MSG_TABLE, GEAR_ITEM_MSG_TEETH_FACING_OUTSIDE);

                        result = LXe_CMD_DISABLED;
                }
        }

        return result;
}

        LxResult
CGearItemPackage::cui_DependencyCount (
        const char	*channelName,
        unsigned	*count)
{
        if ((strcmp (channelName, CHANs_GEAR_SPOKES) == 0) ||
            (strcmp (channelName, CHANs_GEAR_RIM_INSET_RATIO) == 0) ||
             (strcmp (channelName, CHANs_GEAR_INNER_SPOKE_INSET_RATIO) == 0) ||
             (strcmp (channelName, CHANs_GEAR_OUTER_SPOKE_INSET_RATIO) == 0) ||
             (strcmp (channelName, CHANs_GEAR_SPOKE_SWEEP_RATIO) == 0) ||
             (strcmp (channelName, CHANs_GEAR_SPOKE_SWIRL_ANGLE) == 0)) {
                /*
                 * These channels depend upon both the corresponding checkbox
                 * (has spokes or has rim) and the inside/outside setting.
                 */
                count[0] = 2;
        }
        else if ((strcmp (channelName, CHANs_GEAR_HAS_RIM) == 0) ||
             (strcmp (channelName, CHANs_GEAR_HAS_SPOKES) == 0) ||
             (strcmp (channelName, CHANs_GEAR_SHAFT) == 0) ||
             (strcmp (channelName, CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO) == 0) ||
             (strcmp (channelName, CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO) == 0)) {
                // These channels depend on the inside/outside setting.
                count[0] = 1;
        }
        else {
                count[0] = 0;
        }

        return LXe_OK;
}

        LxResult
CGearItemPackage::cui_DependencyByIndex (
        const char	*channelName,
        unsigned	 index,
        LXtItemType	*depItemType,
        const char	**depChannelName)
{
        LxResult	result = LXe_OUTOFBOUNDS;

        if ((strcmp (channelName, CHANs_GEAR_SPOKES) == 0) ||
            (strcmp (channelName, CHANs_GEAR_INNER_SPOKE_INSET_RATIO) == 0) ||
            (strcmp (channelName, CHANs_GEAR_OUTER_SPOKE_INSET_RATIO) == 0) ||
            (strcmp (channelName, CHANs_GEAR_SPOKE_SWEEP_RATIO) == 0) ||
            (strcmp (channelName, CHANs_GEAR_SPOKE_SWIRL_ANGLE) == 0)) {
                depItemType[0] = MyType ();
                switch (index) {
                    case 0:
                        depChannelName[0] = CHANs_GEAR_HAS_SPOKES;
                        result = LXe_OK;
                        break;

                    case 1:
                        depChannelName[0] = CHANs_GEAR_TEETH_FACING;
                        result = LXe_OK;
                        break;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }
        else if (strcmp (channelName, CHANs_GEAR_RIM_INSET_RATIO) == 0) {
                depItemType[0] = MyType ();
                switch (index) {
                    case 0:
                        depChannelName[0] = CHANs_GEAR_HAS_RIM;
                        result = LXe_OK;
                        break;

                    case 1:
                        depChannelName[0] = CHANs_GEAR_TEETH_FACING;
                        result = LXe_OK;
                        break;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }
        else if ((strcmp (channelName, CHANs_GEAR_HAS_RIM) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_HAS_SPOKES) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_SHAFT) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_AXIAL_SHAFT_INSET_RATIO) == 0) ||
                 (strcmp (channelName, CHANs_GEAR_RADIAL_SHAFT_INSET_RATIO) == 0)) {
                depItemType[0] = MyType ();
                switch (index) {
                    case 0:
                        depChannelName[0] = CHANs_GEAR_TEETH_FACING;
                        result = LXe_OK;
                        break;

                    default:
                        result = LXe_OUTOFBOUNDS;
                        break;
                }
        }

        return result;
}

/*
 * ----------------------------------------------------------------
 * Utility to get the type code for this item type, as needed.
 */

        LXtItemType
CGearItemPackage::MyType ()
{
        if (my_type != LXiTYPE_NONE)
                return my_type;

        CLxUser_SceneService	 svc;

        my_type = svc.ItemType (SRVs_ITEMTYPE);
        return my_type;
}


/* 
 * ----------------------------------------------------------------
 * Server initialization.
 */

        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CGearItemPackage>;

        srv->AddInterface (new CLxIfc_Package<CGearItemPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc<CGearItemPackage>);
        srv->AddInterface (new CLxIfc_ChannelUI<CGearItemPackage>);

        thisModule.AddServer (SRVs_GEOMETRY_ITEM, srv);

        pF = new CFactories;
        listenerMap = new CGearTableauListenerMap;
}

        void
cleanup ()
{
        delete pF;
        delete listenerMap;
}

