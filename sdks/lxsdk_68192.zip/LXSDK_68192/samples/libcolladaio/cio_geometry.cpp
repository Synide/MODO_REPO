/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_geometry.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"
#include "cio_source.h"
#include "cio_math.h"

#include <string>
#include <math.h>

using namespace std;

namespace cio {

namespace {

        static bool
ElementHasInput (const Element &element, const string &inputSemantic)
{
        bool	foundInput(false);

        ElementXML *input = element.GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        /*
         * Look for an attribute with the given input semantic.
         */
        while (input && !foundInput) {
                if (element.GetAttribute (input, ATTRIBUTE_SEMANTIC) == inputSemantic) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        static bool
GetElementInputSourceIDbyIndex (
        const Element	&element,
        const string	&inputSemantic,
        unsigned	 sourceIndex,
        string		&sourceID,
        unsigned	&offsetIndex,
        unsigned	&setIndex)
{
        bool	found(false);

        ElementXML *input = element.GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        unsigned testIndex = 0;

        /*
         * Iterate over inputs with the given semantic.
         */
        setIndex = 0;
        bool	 haveFirstOffsetIndex = false;
        unsigned minOffsetIndex = 0;
        offsetIndex = 0;

        bool hasSetIndex = false;
        while (input) {
                if (element.GetAttribute (input, ATTRIBUTE_SEMANTIC) == inputSemantic) {
                        /*
                         * Find the minimum offset, regardless of whether
                         * or not a match to the sourceIndex is found.
                         */
                        unsigned testOffsetIndex = element.GetAttributeUnsigned (
                                input, ATTRIBUTE_OFFSET);
                        if (haveFirstOffsetIndex) {
                                minOffsetIndex = math::Min (testOffsetIndex, minOffsetIndex);
                        }
                        else {
                                minOffsetIndex = testOffsetIndex;
                                haveFirstOffsetIndex = true;
                        }

                        if (testIndex++ == sourceIndex) {
                                sourceID = StripURI_Ref (element.GetAttribute (
                                        input, ATTRIBUTE_SOURCE));
                                if (element.HasAttribute (input, ATTRIBUTE_SET)) {
                                        setIndex = element.GetAttributeUnsigned (
                                                input, ATTRIBUTE_SET);
                                        hasSetIndex = true;
                                }
                                offsetIndex = testOffsetIndex;
                                found = true;
                        }
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        /*
         * If the set index is not explicitly specified, we calculate it by
         * subtracting the minimum offset from the matched texcoord offset.
         */
        if (found && !hasSetIndex) {
                setIndex = offsetIndex - minOffsetIndex;
        }

        return found;
}

        static void
AddElementInputs (
        Element			&element,
        const string		&inputSemantic,
        const vector<string>	&sourceInputIDs,
        const vector<unsigned>	&setIndices,
        unsigned		&offset)
{
        vector<unsigned>::const_iterator indIter = setIndices.begin ();
        for (vector<string>::const_iterator iter = sourceInputIDs.begin ();
                iter != sourceInputIDs.end (); ++iter) {
                string sourceInputID = *iter;
                unsigned setIndex = *indIter;

                ElementXML *input = element.AddElement (ELEMENT_INPUT);
                element.SetAttribute (
                        input, ATTRIBUTE_SEMANTIC, inputSemantic);
                element.SetAttribute (
                        input,
                        ATTRIBUTE_SOURCE,
                        URI_Ref(sourceInputID));

                element.SetAttribute (input, ATTRIBUTE_OFFSET, offset + setIndex);

                /*
                 * [TODO] When the indices for two or more input sets are identical,
                 *        merge them into a single set, in which case the SET
                 *        attribute distinguishes between each logical set.
                 */
                element.SetAttribute (input, ATTRIBUTE_SET, setIndex);

                ++indIter;
        }

        offset += static_cast<unsigned>(setIndices.size ());
}

} // namespace

/*
 * ---------------------------------------------------------------------------
 * Vertices.
 */

VerticesElement::VerticesElement (
        MeshElement		&mesh,
        const std::string	&meshPositionSourceID)
        :
        Element(mesh.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                mesh.AddVertices (*this);
                SetID (VerticesID (mesh.GetGeometryID ()));

                /*
                 * Bind the source positions to the vertices.
                 */
                ElementXML *verticesInput =
                        AddElement (ELEMENT_INPUT);
                SetAttribute (
                        verticesInput,
                        ATTRIBUTE_SEMANTIC,
                        ATTRVALUE_POSITION_INPUT_SEMANTIC);
                SetAttribute (
                        verticesInput,
                        ATTRIBUTE_SOURCE,
                        URI_Ref (meshPositionSourceID));
        }
}

VerticesElement::VerticesElement (MeshElement &mesh)
        :
        Element(mesh.PV ())
{
}

VerticesElement::~VerticesElement ()
{
}

        bool
VerticesElement::HasPositionInput () const
{
        bool	foundInput(false);
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_POSITION_INPUT_SEMANTIC) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        string
VerticesElement::PositionInputSourceID () const
{
        bool	foundInput(false);
        string	sourceID;
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_POSITION_INPUT_SEMANTIC) {
                        sourceID = GetAttribute (input, ATTRIBUTE_SOURCE);
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return StripURI_Ref (sourceID);
}

        bool
VerticesElement::HasNormalInput () const
{
        bool	foundInput(false);
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_NORMAL) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        string
VerticesElement::NormalInputSourceID () const
{
        bool	foundInput(false);
        string	sourceID;
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_NORMAL) {
                        sourceID = GetAttribute (input, ATTRIBUTE_SOURCE);
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return StripURI_Ref (sourceID);
}

/*
 * ---------------------------------------------------------------------------
 * VertexMapInputHub
 *
 * A generic hub for vertex map inputs, that enables loaders to test for
 * and get inputs without duplicating code for each geometry container type.
 */

VertexMapInputHub::VertexMapInputHub (
        MeshElement		&geoMesh)
        :
        mesh(geoMesh)
{
}

VertexMapInputHub::~VertexMapInputHub ()
{
}

        void
VertexMapInputHub::LinkToElement (Element *geoElement)
{
        element = geoElement;
}

        unsigned
VertexMapInputHub::GetMaxInputOffset () const
{
        unsigned maxOffset = 0;

        ElementXML *input = element->GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input) {
                unsigned offset = element->GetAttributeUnsigned (
                        input, ATTRIBUTE_OFFSET);
                maxOffset = math::Max (maxOffset, offset);
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return maxOffset;
}

        bool
VertexMapInputHub::HasVertexInput () const
{
        bool	foundInput(false);

        ElementXML *input = element->GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (element->GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_VERTEX) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        string
VertexMapInputHub::GetVertexInputSourceID (unsigned &offset) const
{
        string	sourceID;

        ElementXML *input = element->GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input) {
                if (element->GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_VERTEX) {
                        sourceID = element->GetAttribute (input, ATTRIBUTE_SOURCE);
                        offset = element->GetAttributeUnsigned (input, ATTRIBUTE_OFFSET);
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return StripURI_Ref (sourceID);
}

        unsigned
VertexMapInputHub::GetVertexInputOffset () const
{
        unsigned offset = 0;
        ElementXML *input = element->GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input) {
                if (element->GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_VERTEX) {
                        offset = element->GetAttributeUnsigned (input, ATTRIBUTE_OFFSET);
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return offset;
}

        bool
VertexMapInputHub::HasNormalInput () const
{
        bool	foundInput(false);

        /*
         * Look for an attribute with the normal input semantic.
         */
        foundInput = ElementHasInput (*element, ATTRVALUE_NORMAL);

        /*
         * If the normals aren't store as an immediate input, check if there's
         * a normal input over in the vertices element.
         */
        if ((!foundInput) && HasVertexInput ()) {
                unsigned pointOffset;
                string meshVerticesID = GetVertexInputSourceID (pointOffset);
                VerticesElement	vertices(mesh);
                if (mesh.LinkVertices (meshVerticesID, vertices)) {
                        foundInput = vertices.HasNormalInput ();
                }
        }

        return foundInput;
}

        string
VertexMapInputHub::GetNormalInputSourceID (unsigned &offset) const
{
        bool	foundInput(false);
        string	sourceID;

        foundInput = ElementHasInput (*element, ATTRVALUE_NORMAL);
        if (foundInput) {
                ElementXML *input = element->GetElementHandle ().FirstChildElement (
                        ELEMENT_INPUT).Element ();
                while (input) {
                        if (element->GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_NORMAL) {
                                sourceID = element->GetAttribute (input, ATTRIBUTE_SOURCE);
                                offset = element->GetAttributeUnsigned (input, ATTRIBUTE_OFFSET);
                                break;
                        }
                        input = input->NextSiblingElement (ELEMENT_INPUT);
                }
        }
        else if (HasVertexInput ()) {
                /*
                 * In the case where the normal input is stored in the
                 * vertices element, it shares the vertex index offset.
                 */
                unsigned vertexOffset;
                string meshVerticesID = GetVertexInputSourceID (vertexOffset);
                VerticesElement	vertices(mesh);
                if (mesh.LinkVertices (meshVerticesID, vertices)) {
                        if (vertices.HasNormalInput ()) {
                                sourceID = vertices.NormalInputSourceID ();
                                offset = vertexOffset;
                        }
                }
        }

        return StripURI_Ref (sourceID);
}

        unsigned
VertexMapInputHub::GetNormalInputOffset () const
{
        bool		foundInput(false);
        unsigned	offset = 0;

        ElementXML *input = element->GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input) {
                if (element->GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_NORMAL) {
                        offset = element->GetAttributeUnsigned (
                                input, ATTRIBUTE_OFFSET);
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        if ((!foundInput) && HasVertexInput ()) {
                /*
                 * In the case where the normal input is stored in the
                 * vertices element, it shares the vertex index offset.
                 */
                unsigned vertexOffset;
                string meshVerticesID = GetVertexInputSourceID (vertexOffset);
                VerticesElement	vertices(mesh);
                if (mesh.LinkVertices (meshVerticesID, vertices)) {
                        if (vertices.HasNormalInput ()) {
                                offset = vertexOffset;
                        }
                }
        }

        return offset;
}

        bool
VertexMapInputHub::HasTexcoordInput () const
{
        /*
         * Look for an attribute with the texcoord input semantic.
         */
        return ElementHasInput (*element, ATTRVALUE_TEXCOORD);
}

        bool
VertexMapInputHub::GetTexcoordInputSourceIDbyIndex (
        unsigned		 sourceIndex,
        std::string		&sourceID,
        unsigned		&offsetIndex,
        unsigned		&setIndex) const
{
        return GetElementInputSourceIDbyIndex (
                *element, ATTRVALUE_TEXCOORD,
                sourceIndex, sourceID, offsetIndex, setIndex);
}

        bool
VertexMapInputHub::HasColorInput () const
{
        /*
         * Look for an attribute with the color input semantic.
         */
        return ElementHasInput (*element, ATTRVALUE_COLOR_INPUT_SEMANTIC);
}

        bool
VertexMapInputHub::GetColorInputSourceIDbyIndex (
        unsigned		 sourceIndex,
        std::string		&sourceID,
        unsigned		&offsetIndex,
        unsigned		&setIndex) const
{
        return GetElementInputSourceIDbyIndex (
                *element, ATTRVALUE_COLOR_INPUT_SEMANTIC,
                sourceIndex, sourceID, offsetIndex, setIndex);
}

        bool
VertexMapInputHub::HasWeightInput () const
{
        /*
         * Look for an attribute with the weight input semantic.
         */
        return ElementHasInput (*element, ATTRVALUE_WEIGHT_INPUT_SEMANTIC);
}

        bool
VertexMapInputHub::GetWeightInputSourceIDbyIndex (
        unsigned		 sourceIndex,
        std::string		&sourceID,
        unsigned		&offsetIndex,
        unsigned		&setIndex) const
{
        return GetElementInputSourceIDbyIndex (
                *element, ATTRVALUE_WEIGHT_INPUT_SEMANTIC,
                sourceIndex, sourceID, offsetIndex, setIndex);
}

        void
VertexMapInputHub::AddInputs (
        const string		&inputSemantic,
        const vector<string>	&sourceInputIDs,
        const vector<unsigned>	&setIndices,
        unsigned		&offset)
{
        AddElementInputs (*element, inputSemantic, sourceInputIDs, setIndices, offset);
}

/*
 * ---------------------------------------------------------------------------
 * Polygons.
 */

struct pv_PolygonsElement
{
        pv_PolygonsElement (MeshElement *activeMesh)
                :
                mesh(activeMesh)
        {
                Init ();
        }

        void		Init ()
        {
                count = 0;
                offset = 0;
                inputVertex = NULL;
                inputNormal = NULL;
                vertexCounts = NULL;
                inputIndices = NULL;
        }

        MeshElement	*mesh;
        unsigned	 count;
        unsigned	 offset;
        ElementXML	*inputVertex;
        ElementXML	*inputNormal;
        ElementXML	*vertexCounts;
        ElementXML	*inputIndices;
};

PolygonsElement::PolygonsElement (
        MeshElement	&mesh,
        unsigned	 polyCount)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_PolygonsElement(&mesh))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                mesh.AddPolygons (*this);
                SetAttribute (ATTRIBUTE_COUNT, polyCount);
        }

        LinkToElement (this);
}

PolygonsElement::PolygonsElement (
        MeshElement	&mesh)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_PolygonsElement(&mesh))
{
        LinkToElement (this);
}

PolygonsElement::~PolygonsElement ()
{
        delete pv;
}

        bool
PolygonsElement::LinkNextPolygons (PolygonsElement &polygons)
{
        bool linked = LinkNextSiblingElement (ELEMENT_POLYGONS, polygons);
        if (linked) {
                pv->Init ();
        }

        return linked;
}

        unsigned
PolygonsElement::GetCount () const
{
        return GetAttributeUnsigned (ATTRIBUTE_COUNT);
}

        string
PolygonsElement::GetGeometryID () const
{
        return pv->mesh->GetGeometryID ();
}

        string
PolygonsElement::GetMaterialName () const
{
        return GetAttribute (ATTRIBUTE_MATERIAL);
}

        void
PolygonsElement::SetMaterialName (
        const string	&name)
{
        /*
         * Bind the polygons to its material.
         */
        SetAttribute (ATTRIBUTE_MATERIAL,
                MaterialSymbolicID (ItemID (name)));
}

        void
PolygonsElement::AddVertexInput ()
{
        /*
         * Overwrite the previous vertex input if one is already present.
         */
        if (pv->inputVertex) {
                ClearElementValue (pv->inputVertex);
        }
        else {
                pv->inputVertex = AddElement (ELEMENT_INPUT);
        }
        SetAttribute (pv->inputVertex, ATTRIBUTE_SEMANTIC, ATTRVALUE_VERTEX);
        SetAttribute (pv->inputVertex, ATTRIBUTE_SOURCE,
                URI_Ref (VerticesID (pv->mesh->GetGeometryID ())));
        SetAttribute (pv->inputVertex, ATTRIBUTE_OFFSET, pv->offset++);
}

        void
PolygonsElement::AddNormalInput (const string &sourceNormalsID)
{
        /*
         * Overwrite the previous normal input if one is already present.
         */
        if (pv->inputNormal) {
                ClearElementValue (pv->inputNormal);
        }
        else {
                pv->inputNormal = AddElement (ELEMENT_INPUT);
        }

        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SEMANTIC,
                ATTRVALUE_NORMAL);
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SOURCE,
                URI_Ref(sourceNormalsID));
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_OFFSET,
                pv->offset++);
}

        void
PolygonsElement::AddTexcoordInput (
        const string	&sourceTexcoordsID,
        unsigned	 setIndex)
{
        /*
         * Texcoord inputs are always added, since there can be more than one.
         */
        ElementXML *inputTexcoord = AddElement (ELEMENT_INPUT);
        SetAttribute (
                inputTexcoord, ATTRIBUTE_SEMANTIC, ATTRVALUE_TEXCOORD);
        SetAttribute (
                inputTexcoord,
                ATTRIBUTE_SOURCE,
                URI_Ref(sourceTexcoordsID));

        SetAttribute (inputTexcoord, ATTRIBUTE_OFFSET, pv->offset + setIndex);

        /*
         * [TODO] When the indices for two or more UV sets are identical,
         *        merge them into a single set, in which case the SET
         *        attribute distinguishes between each logical set.
         */
        SetAttribute (inputTexcoord, ATTRIBUTE_SET, setIndex);
}

        void
PolygonsElement::AddColorInputs (
        const vector<string>	&sourceColorIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_COLOR_INPUT_SEMANTIC, sourceColorIDs, setIndices, pv->offset);
}

        void
PolygonsElement::AddWeightInputs (
        const vector<string>	&sourceWeightIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_WEIGHT_INPUT_SEMANTIC, sourceWeightIDs, setIndices, pv->offset);
}

/*
 * Check if there is a polygon with hole indices at
 * the given polygon index.
 */
        bool
PolygonsElement::HasHoleIndices (
        unsigned		 polyIndex,
        unsigned		&holeCount) const
{
        bool		found(false);

        holeCount = 0;
        ElementXML *polygonElem = GetElementHandle ().ChildElement (
                ELEMENT_P, ELEMENT_PH, polyIndex).Element ();
        if (polygonElem) {
                if (polygonElem->ValueStr () == string(ELEMENT_PH)) {
                        /*
                         * A ph element must have at least one outer "P" loop.
                         */
                        ElementXML *outerLoopElem =
                                HandleXML(polygonElem).FirstChildElement (
                                        ELEMENT_P).Element ();
                        if (outerLoopElem) {
                                /*
                                 * And at least one inner "H" loop.
                                 */
                                ElementXML *innerLoopElem =
                                        outerLoopElem->NextSiblingElement (ELEMENT_H);
                                while (innerLoopElem) {
                                        found = true;
                                        ++holeCount;
                                        innerLoopElem = innerLoopElem->NextSiblingElement (ELEMENT_H);
                                }
                        }
                }
        }

        return found;
}

/*
 * Quick accessor macros for test axis ix and iy.
 */
#define PX(v)		((v)[tax.ix])
#define PY(v)		((v)[tax.iy])

        static double
TR_Determ (
        const math::TestAxis	&tax,
        const math::Vector3	&v1,
        const math::Vector3	&v2,
        const math::Vector3	&v3)
{
        using namespace math;

        double		 x1, y1, a, b;
        Vector3		 p1, p2, p3;

        AxisTestMultiply (p1, tax, v1);
        AxisTestMultiply (p2, tax, v2);
        AxisTestMultiply (p3, tax, v3);

        x1 = PX (p1);
        y1 = PY (p1);
        a = (PX (p2) - x1) * (PY (p3) - y1);
        b = (PX (p3) - x1) * (PY (p2) - y1);

        return a - b;
}

        static void
VectorFromArray (
        const std::vector<float>	&vecArray,
        unsigned			 index,
        math::Vector3			&vec)
{
        for (unsigned d = 0; d < ND; ++d) {
                vec[d] = vecArray[index * 3 + d];
        }
}

/*
 * Flip a normal, generating a new index if the normal was previously flipped.
 *
 * [TODO] In the case where the normals and the points share indices, they need
 *	  to be broken out into separate indices!
 */
        static void
FlipNormal (
        std::vector<float>	&normals,
        std::set<unsigned>	&flippedNormals,
        unsigned		&normalIndex)
{
        unsigned axisIndex;
#if 1
        for (axisIndex = 0;
             axisIndex < 3; ++axisIndex) {
                normals.push_back (
                        -(normals[normalIndex * 3 + axisIndex]));
        }

        /*
         * Re-index to point at the new flipped normal.
         */
        normalIndex = static_cast<unsigned>(
                normals.size () / 3 - 1);
#else
        /*
         * The flippedNormals array contains the set of
         * previously flipped normals.
         */
        if (flippedNormals.find (normalIndex) !=
            flippedNormals.end ()) {
                for (axisIndex = 0;
                     axisIndex < 3; ++axisIndex) {
                        normals.push_back (
                                -(normals[normalIndex * 3 + axisIndex]));
                }

                /*
                 * Re-index to point at the new flipped normal.
                 */
                normalIndex = static_cast<unsigned>(
                        normals.size () / 3 - 1);
        }
        else {
                for (axisIndex = 0;
                     axisIndex < 3; ++axisIndex) {
                        normals[normalIndex * 3 + axisIndex] *= -1;
                }
        }
        flippedNormals.insert (normalIndex);
#endif
}

/*
 * Compute normal vector for a polygon.  Returns zero if there is no normal
 * or if the polygon is smaller than a triangle.  The normal is the same
 * as the normal for the triangle containing the first point.
 */
        static int
PolygonGetNormal (
        const std::vector<float>	&points,
        math::Vector3			 norm)
{
        math::Vector3		 d0, d1, dn;
        math::Vector3		 p0, p1, pn;

        VectorFromArray (points, 0, p0);
        VectorFromArray (points, 1, p1);
        VectorFromArray (points, static_cast<unsigned>(points.size () / 3) - 1, pn);

        VSUB3 (d0, p1, p0);
        VSUB3 (d1, pn, p0);
        VCROSS (dn, d0, d1);
        if (math::Normalize (dn)) {
                VCPY (norm, dn);
                return 1;
        } else {
                VCLR (norm);
                return 0;
        }
}

/*
 * Calculate polygon orientation.
 * Return either 0 or 1 for clockwise or counter_clockwise for the
 * orientation of the polygon in the plane determined by tax.
 */
        static int
PolygonOrientation (
        const std::vector<float>	&points,
        math::TestAxis			&tax)
{
        using namespace math;

        double			 area;
        unsigned		 i, count;
        math::Vector3		 v0, v1;

        /*
         * Do the wrap-around first.
         */
        math::Vector3		p0;
        VectorFromArray (points, 0, p0);
        AxisTestMultiply (v0, tax, p0);

        math::Vector3		p1;
        count = static_cast<unsigned>(points.size ()) / 3;
        VectorFromArray (points, static_cast<unsigned>(count - 1), p1);
        AxisTestMultiply (v1, tax, p1);
        area = PX (v1) * PY (v0) - PX (v0) * PY (v1);

        /*
         * Compute the area (times 2) of the polygon where sign gives
         * orientation.
         */
        for (i = 0; i < count - 1; i++) {
                math::Vector3		p1;
                VectorFromArray (points, static_cast<unsigned>(i + 1), p1);
                AxisTestMultiply (v1, tax, p1);

                area += PX (v0) * PY (v1) - PX (v1) * PY (v0);
                VCPY (v0, v1);
        }

        return (area >= 0.0);
}

/*
 * Return +1 if first vertex is convex, -1 for concave, 0 for undefined.
 */
        static int
PolygonFirstConvex (
        const std::vector<float>	&points)
{
        math::Vector3		 n;
        math::TestAxis		 tax;
        int			 i;

        if (!PolygonGetNormal (points, n))
                return 0;

        math::AxisTestSet (tax, math::AxisMaxExtent (n));

        i = n[tax.axis] < 0.0;

        return ((i ^ PolygonOrientation (points, tax)) ? +1 : -1);
}

/*
 * Returns the index of a good convex vertex, whose orientation matches
 * that of the original polygon.  If the original had a concave first
 * vertex, the new polygon should be flipped.
 */
        static bool
GoodVertexIndex (
        const std::vector<float>	&points,
        unsigned			 maxInputOffset,
        unsigned			 vertexInputOffset,
        const std::vector<unsigned>	&loopIndices,
        math::TestAxis			&tax,
        int				 orient,
        unsigned			&goodIndex)
{
        math::Vector3		 vp, vc, vn;
        double			 d, dmax;
        bool			 isGood;
        unsigned		 bestIndex;

        /*
         * Look for vertices that match orientation AND enclose the maximum area.
         * Max area is a combination of length and relative angle and
         * is a measure of how good the normal is.
         */
        dmax = 0.0;
        unsigned posInputIndex = 0;
        unsigned pointCount = static_cast<unsigned>(
                loopIndices.size () / (maxInputOffset + 1));
        for (unsigned vertexPolyIndex = 0;
             vertexPolyIndex < pointCount; ++vertexPolyIndex) {
                unsigned vertexLookup = posInputIndex + vertexInputOffset;
                unsigned vertexIndex = loopIndices.at (vertexLookup);

                /*
                 * Get previous, current, and next vertices.
                 */
                VectorFromArray (points, (vertexIndex + pointCount - 1) % pointCount, vp);
                VectorFromArray (points, vertexIndex, vc);
                VectorFromArray (points, (vertexIndex + 1) % pointCount, vn);

                d = TR_Determ (tax, vp, vc, vn);
                if (((d >= 0.0) == orient) && (fabs (d) > dmax)) {
                        dmax = fabs (d);
                        bestIndex = vertexPolyIndex;
                }
                posInputIndex += maxInputOffset + 1;
        }

        isGood = (dmax > 0.0);
        if (isGood) {
                goodIndex = bestIndex;
        }
        else {
                goodIndex = loopIndices.at(0);
        }

        return isGood;
}

/*
 * Calculate the distance between the points indexed by
 * indexPointA and indexPointB.
 */
        static double
PointDistance (
        std::vector<float>	&points,
        unsigned		 indexPointA,
        unsigned		 indexPointB)
{
        indexPointA *= 3;
        indexPointB *= 3;

        return sqrt (
                fabs (points[indexPointB + 0] - points[indexPointA + 0]) +
                fabs (points[indexPointB + 1] - points[indexPointA + 1]) +
                fabs (points[indexPointB + 2] - points[indexPointA + 2]));
}

        static double
ClosestPoints (
        std::vector<float>	&points,
        unsigned		 maxOffset,
        unsigned		 pointOffset,
        std::vector<unsigned>	 outerLoopIndices,
        std::vector<unsigned>	 innerLoopIndices,
        unsigned		&minInnerIndex,
        unsigned		&minOuterIndex)
{
        /*
         * Iterate over outer and inner loops to find
         * the two closest vertices that can be
         * connected.
         */
        bool firstDistance = true;
        double minDistance;
        unsigned outerVertexPolyCount = static_cast<unsigned>(
                outerLoopIndices.size () / (maxOffset + 1));
        unsigned outerPosInputIndex = 0;
        for (unsigned outerVertexPolyIndex = 0;
                outerVertexPolyIndex < outerVertexPolyCount; ++outerVertexPolyIndex) {
                unsigned outerVertexLookup = outerPosInputIndex + pointOffset;
                unsigned outerVertexIndex = outerLoopIndices.at (outerVertexLookup);

                /*
                 * Find the closest inner vertex.
                 */
                unsigned innerVertexPolyCount = static_cast<unsigned>(
                        innerLoopIndices.size () / (maxOffset + 1));
                unsigned innerPosInputIndex = 0;
                for (unsigned innerVertexPolyIndex = 0;
                        innerVertexPolyIndex < innerVertexPolyCount; ++innerVertexPolyIndex) {
                        unsigned innerVertexLookup = innerPosInputIndex + pointOffset;
                        unsigned innerVertexIndex = innerLoopIndices.at (innerVertexLookup);

                        /*
                         * Calculate distance between inner and outer points.
                         */
                        double distance = PointDistance (
                                points, outerVertexIndex, innerVertexIndex);
                        if (firstDistance) {
                                minDistance = firstDistance;
                                minInnerIndex = innerPosInputIndex;
                                minOuterIndex = outerPosInputIndex;
                                firstDistance = false;
                        }
                        else if (distance < minDistance) {
                                minDistance = distance;
                                minInnerIndex = innerPosInputIndex;
                                minOuterIndex = outerPosInputIndex;
                        }

                        innerPosInputIndex += maxOffset + 1;
                }

                outerPosInputIndex += maxOffset + 1;
        }

        return minDistance;
}

/*
 * Copy the subset of point coordinates indexed by loopIndices, from srcPoints
 * to dstPoints, skipping indices according to maxInputOffset (the number of
 * inputs per index set) and vertexInputOffset (the relative vertex input index
 * within each index set).
 */
        static void
CopyVertexPoints (
        const std::vector<float>	&srcPoints,
        std::vector<float>		&dstPoints,
        unsigned			 maxInputOffset,
        unsigned			 vertexInputOffset,
        const std::vector<unsigned>	&loopIndices)
{
        unsigned vertexPolyCount = static_cast<unsigned>(
                loopIndices.size () / (maxInputOffset + 1));
        unsigned posInputIndex = 0;
        for (unsigned vertexPolyIndex = 0;
                vertexPolyIndex < vertexPolyCount; ++vertexPolyIndex) {
                unsigned vertexLookup = posInputIndex + vertexInputOffset;
                unsigned vertexIndex = loopIndices.at (vertexLookup);

                /*
                 * The position array contains triplets of xyz coordinates.
                 */
                for (unsigned index = 0; index < 3; ++index) {
                        dstPoints.push_back (srcPoints[vertexIndex * 3 + index]);
                }

                posInputIndex += maxInputOffset + 1;
        }
}

/*
 * [TODO]
 * The polygons version of GetInputIndices is a bit more involved than the
 * versions for the other representations (polylist, triangles, lines),
 * since polygons elements can have holes, which require additional processing
 * to find the ideal edge position to connect the outer edge loops to the
 * inner edge loops for each hole.
 *
 * NOTE: To account for flipping normals, where position and normal indices
 *       are shared, the index array must be pre-split, by calling
 *       SplitPositionAndNormalIndices before GetInputIndices is called.
 */
        bool
PolygonsElement::GetInputIndices (
        unsigned		 index,
        std::vector<unsigned>	&inputIndices)
{
        bool		linked(false);
        ElementXML *inputIndicesElem = GetElementHandle ().ChildElement (
                ELEMENT_P, index).Element ();
        if (inputIndicesElem) {
                GetElementValue (inputIndicesElem, inputIndices);
                linked = true;
        }

        return linked;
}

/*
 * [TODO]
 * The polygons version of GetInputIndices is a bit more involved than the
 * versions for the other representations (polylist, triangles, lines),
 * since polygons elements can have holes, which require additional processing
 * to find the ideal edge position to connect the outer edge loops to the
 * inner edge loops for each hole.
 *
 * NOTE: To account for flipping normals, where position and normal indices
 *       are shared, the index array must be pre-split, by calling
 *       SplitPositionAndNormalIndices before GetInputIndices is called.
 */
        bool
PolygonsElement::GetInputIndices (
        unsigned		 index,
        std::vector<unsigned>	&inputIndices,
        std::vector<float>	&points,
        std::vector<float>	&normals)
{
        bool		linked(false);
        ElementXML *inputIndicesElem = GetElementHandle ().ChildElement (
                ELEMENT_P, ELEMENT_PH, index).Element ();
        /*
         * [TODO] It's problematic to fetch the original element, if they
         * were already split by a call to SplitPositionAndNormalIndices
         */
        if (inputIndicesElem && inputIndicesElem->ValueStr () == string(ELEMENT_P)) {
                GetElementValue (inputIndicesElem, inputIndices);
                linked = true;
        }
        else if (inputIndicesElem && inputIndicesElem->ValueStr () == string(ELEMENT_PH)) {
                /*
                 * A ph element must have at least one outer "P" loop.
                 */
                ElementXML *outerLoopElem = HandleXML(inputIndicesElem).FirstChildElement (
                        ELEMENT_P).Element ();
                if (outerLoopElem) {
                        /*
                         * Track which normals have been flipped, so we don't
                         * flip the same normal more than once.
                         */
                        std::set<unsigned> flippedNormals;

                        std::vector<unsigned> outerLoopIndices;
                        GetElementValue (outerLoopElem, outerLoopIndices);

                        /*
                         * And at least one inner "H" loop.
                         */
                        ElementXML *innerLoopElem =
                                HandleXML(inputIndicesElem).FirstChildElement (
                                        ELEMENT_H).Element ();
                        if (innerLoopElem) {
                                linked = true;

                                std::vector<unsigned> innerLoopIndices;
                                GetElementValue (innerLoopElem, innerLoopIndices);

                                unsigned minInnerIndex;
                                unsigned minOuterIndex;
                                unsigned maxInputOffset = GetMaxInputOffset ();
                                unsigned vertexInputOffset = GetVertexInputOffset ();
                                ClosestPoints (points,
                                        maxInputOffset,
                                        vertexInputOffset,
                                        outerLoopIndices, innerLoopIndices,
                                        minInnerIndex, minOuterIndex);

                                /*
                                 * Now that we have found the two closest
                                 * points with which we can connect the
                                 * outer loop to the inner loop, find
                                 * the best convex starting point.
                                 */
                                std::vector<float> outerPolyPoints;
                                CopyVertexPoints (points, outerPolyPoints,
                                        maxInputOffset, vertexInputOffset,
                                        outerLoopIndices);

                                math::Vector3 norm;
                                PolygonGetNormal (outerPolyPoints, norm);
                                math::TestAxis		 tax;
                                math::AxisTestSet (tax, math::AxisMaxExtent (norm));
                                int orient = PolygonOrientation (outerPolyPoints, tax);

                                /*
                                 * If the first vertex is not at a convex
                                 * location, we need to flip the normals of
                                 * the outer loop.
                                 */
                                bool flipOuterNormals =
                                        (PolygonFirstConvex (outerPolyPoints) == -1);

                                /*
                                 * Check for the best starting index,
                                 * avoiding a start at a concave position.
                                 *
                                 * Pass the full point array, so we can
                                 * generate a relative index.
                                 */
                                unsigned goodStartIndex;
                                bool good = GoodVertexIndex (
                                        points,
                                        maxInputOffset,
                                        vertexInputOffset,
                                        outerLoopIndices,
                                        tax, orient,
                                        goodStartIndex);

                                /*
                                 * Fall back to the best connector point if
                                 * there was no best convex vertex.
                                 */
                                if (!good) {
                                        goodStartIndex = minOuterIndex;
                                }

                                /* Push back the indices of the
                                 * outer and inner loops, using the new
                                 * starting positions for each loop.
                                 */
                                unsigned outerCount = static_cast<unsigned>(
                                        outerLoopIndices.size () / (maxInputOffset + 1));

                                /*
                                 * If we have normals, determine
                                 * the normal index offset.
                                 */
                                bool hasNormals = (normals.size () > 0);
                                unsigned normalInputOffset;
                                if (hasNormals) {
                                        normalInputOffset = GetNormalInputOffset ();
                                }
                                else {
                                        normalInputOffset = 0;
                                }

                                /*
                                 * Configure the winding direction.
                                 */
                                int outerStartIndex, outerEndIndex;
                                int outerDirection;
                                if (flipOuterNormals) {
                                        outerStartIndex = outerCount - 1;
                                        outerEndIndex = -1;
                                        outerDirection = -1;
#if 0
        void
SplitPositionAndNormalIndices (
        std::vector<unsigned>	&loopIndices,
        unsigned		&maxInputOffset,
        unsigned		&normalInputOffset)
{
        normalInputOffset = ++maxInputOffset;
}
                                        /*
                                         * When we need to flip normals, and
                                         * the normal input index offset is
                                         * equal to the position input offset,
                                         * we split the indices to allow us to
                                         * grow the normal list and reset the
                                         * normal indices independently of the
                                         * position indices.
                                         */
                                        if (normalInputOffset == vertexInputOffset) {
                                                unsigned scratchOffset = maxInputOffset;
                                                unsigned scratchInputOffset = normalInputOffset;
                                                SplitPositionAndNormalIndices (
                                                        outerLoopIndices,
                                                        scratchOffset,
                                                        scratchInputOffset);
                                                SplitPositionAndNormalIndices (
                                                        innerLoopIndices,
                                                        maxInputOffset,
                                                        normalInputOffset);
                                        }
#endif
                                }
                                else {
                                        outerStartIndex = 0;
                                        outerEndIndex = outerCount;
                                        outerDirection = 1;
                                }

                                int innerCount = static_cast<int>(
                                        innerLoopIndices.size () / (maxInputOffset + 1));

                                /*
                                 * If the first vertex was not convex,
                                 * we iterate in reverse order and flip
                                   the normals of the outer loop.
                                 */
                                for (int outerIndex = outerStartIndex;
                                     outerIndex != outerEndIndex; outerIndex += outerDirection) {
                                        /*
                                         * Calculate logical modulo index
                                         * without regard to maxInputOffset.
                                         */
                                        unsigned outerIndexMod =
                                                (outerIndex + goodStartIndex) % outerCount;
                                        for (unsigned outerOffset = 0; outerOffset <= maxInputOffset;
                                                ++outerOffset) {
                                                unsigned pOuterIndex =
                                                        outerIndexMod * (maxInputOffset + 1) + outerOffset;
                                                unsigned outerIndexValue =
                                                        outerLoopIndices[pOuterIndex];

                                                /*
                                                 * Check to make sure we
                                                 * aren't flipping the same
                                                 * normal more than once.
                                                 */
                                                if (hasNormals && flipOuterNormals &&
                                                    (outerOffset == normalInputOffset)) {
                                                        // [TODO] In the case where the normals and
                                                        //	  the points share indices, they need
                                                        //	  to be broken out into separate indices!
                                                        FlipNormal (normals, flippedNormals, outerIndexValue);
                                                }

                                                /*
                                                 * outerIndex value may have been
                                                 * re-indexed if a new normal was
                                                 * added for a previously visited
                                                 * normal index.
                                                 */
                                                inputIndices.push_back (
                                                        outerIndexValue);
                                        }

                                        /*
                                         * If we're at the best connector
                                         * point, take a detour for the
                                         * inner loop.
                                         */
                                        if (outerIndexMod == minOuterIndex / (maxInputOffset + 1)) {
                                                /*
                                                 * Push back the inner loop indices,
                                                 * in the opposite winding order of
                                                 * the outer loop.
                                                 *
                                                 * Includes an extra iteration to wrap back to
                                                 * the first index of the inner loop.
                                                 */
                                                int innerStartIndex, innerEndIndex;
                                                int innerDirection;
                                                if (flipOuterNormals) {
                                                        innerStartIndex = 0;
                                                        innerEndIndex = innerCount + 1;
                                                        innerDirection = 1;
                                                }
                                                else {
                                                        innerStartIndex = innerCount;
                                                        innerEndIndex = -1;
                                                        innerDirection = -1;
                                                }
                                                for (int innerIndex = innerStartIndex;
                                                     innerIndex != innerEndIndex;
                                                     innerIndex += innerDirection) {
                                                        /*
                                                         * Calculate logical modulo index
                                                         * without regard to maxInputOffset.
                                                         */
                                                        unsigned innerIndexMod =
                                                                (innerIndex + minInnerIndex /
                                                                (maxInputOffset + 1)) % innerCount;
                                                        for (unsigned innerOffset = 0;
                                                             innerOffset < maxInputOffset + 1;
                                                             ++innerOffset) {
                                                                unsigned pInnerIndex =
                                                                        innerIndexMod * (maxInputOffset + 1) + innerOffset;
                                                                unsigned innerIndexValue =
                                                                        innerLoopIndices[pInnerIndex];

                                                                /*
                                                                 * If we have normals, and we aren't
                                                                 * flipping the outer loop normals,
                                                                 * and we're not on the last iteration
                                                                 * that repeats the initial vertex of
                                                                 * the loop, and we're on the normal
                                                                 * input offset.
                                                                 */
                                                                if (hasNormals && (!flipOuterNormals) &&
                                                                    (innerIndex > 0) &&
                                                                    (innerOffset == normalInputOffset)) {
                                                                        // [TODO] In the case where the normals and
                                                                        //	  the points share indices, they need
                                                                        //	  to be broken out into separate indices!
                                                                        FlipNormal (normals, flippedNormals, innerIndexValue);
                                                                }
                                                                inputIndices.push_back (
                                                                        innerIndexValue);
                                                        }
                                                }

                                                /*
                                                 * Wrap back to the outer loop.
                                                 */
                                                for (unsigned outerOffset = 0; outerOffset < maxInputOffset + 1;
                                                        ++outerOffset) {
                                                        unsigned pOuterIndex =
                                                                outerIndexMod * (maxInputOffset + 1) + outerOffset;
                                                        inputIndices.push_back (
                                                                outerLoopIndices[pOuterIndex]);
                                                }
                                        }
                                }
                        }
                }
        }

        return linked;
}

/*
 * Add a vector of unsigned ints to a float array.
 */
        static void
AddUnsignedArrayValues(
        PolygonsElement		&polygons,
        ElementXML		*unsignedArray,
        vector<unsigned>	&values)
{
        string arrayText;
        for (vector<unsigned>::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += IntegerToString(*iter);
                     if (iter + 1 != values.end()) {
                        arrayText += string(ATTRVALUE_SPACE);
                }
        }
        polygons.SetElementValue (unsignedArray, arrayText);
}

        void
PolygonsElement::AddInputIndices (
        vector<unsigned>	&inputIndices)
{
        /*
         * Overwrite the previous vertex count if one is already present.
         */
        if (pv->inputIndices) {
                ClearElementValue (pv->inputIndices);
        }
        else {
                pv->inputIndices = AddElement (ELEMENT_P);
        }

        AddUnsignedArrayValues (*this, pv->inputIndices, inputIndices);
}

/*
 * ---------------------------------------------------------------------------
 * Polylist.
 */

struct pv_PolylistElement
{
        pv_PolylistElement (MeshElement *activeMesh)
                :
                mesh(activeMesh)
        {
                Init ();
        }

        void		Init ()
        {
                count = 0;
                offset = 0;
                inputVertex = NULL;
                inputNormal = NULL;
                vertexCounts = NULL;
                inputIndices = NULL;
        }

        MeshElement	*mesh;
        unsigned	 count;
        unsigned	 offset;
        ElementXML	*inputVertex;
        ElementXML	*inputNormal;
        ElementXML	*vertexCounts;
        ElementXML	*inputIndices;
};

PolylistElement::PolylistElement (
        MeshElement	&mesh,
        unsigned	 polyCount)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_PolylistElement(&mesh))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                mesh.AddPolylist (*this);
                SetAttribute (ATTRIBUTE_COUNT, polyCount);
        }

        LinkToElement (this);
}

PolylistElement::PolylistElement (
        MeshElement	&mesh)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_PolylistElement(&mesh))
{
        LinkToElement (this);
}

PolylistElement::~PolylistElement ()
{
        delete pv;
}

        bool
PolylistElement::LinkNextPolylist (PolylistElement &polylist)
{
        bool linked = LinkNextSiblingElement (ELEMENT_POLYLIST, polylist);
        if (linked) {
                pv->Init ();
        }

        return linked;
}

        unsigned
PolylistElement::GetCount () const
{
        return GetAttributeUnsigned (ATTRIBUTE_COUNT);
}

        string
PolylistElement::GetGeometryID () const
{
        return pv->mesh->GetGeometryID ();
}

        string
PolylistElement::GetMaterialName () const
{
        return GetAttribute (ATTRIBUTE_MATERIAL);
}

        void
PolylistElement::SetMaterialName (
        const string	&name)
{
        /*
         * Bind the polylist to its material.
         */
        SetAttribute (ATTRIBUTE_MATERIAL,
                MaterialSymbolicID (ItemID (name)));
}

        void
PolylistElement::AddVertexInput ()
{
        /*
         * Overwrite the previous vertex input if one is already present.
         */
        if (pv->inputVertex) {
                ClearElementValue (pv->inputVertex);
        }
        else {
                pv->inputVertex = AddElement (ELEMENT_INPUT);
        }
        SetAttribute (pv->inputVertex, ATTRIBUTE_SEMANTIC, ATTRVALUE_VERTEX);
        SetAttribute (pv->inputVertex, ATTRIBUTE_SOURCE,
                URI_Ref (VerticesID (pv->mesh->GetGeometryID ())));
        SetAttribute (pv->inputVertex, ATTRIBUTE_OFFSET, pv->offset++);
}

        void
PolylistElement::AddNormalInput (const string &sourceNormalsID)
{
        /*
         * Overwrite the previous normal input if one is already present.
         */
        if (pv->inputNormal) {
                ClearElementValue (pv->inputNormal);
        }
        else {
                pv->inputNormal = AddElement (ELEMENT_INPUT);
        }

        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SEMANTIC,
                ATTRVALUE_NORMAL);
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SOURCE,
                URI_Ref(sourceNormalsID));
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_OFFSET,
                pv->offset++);
}

        void
PolylistElement::AddTexcoordInputs (
        const vector<string>	&sourceTexcoordsIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_TEXCOORD, sourceTexcoordsIDs, setIndices, pv->offset);
}

        void
PolylistElement::AddColorInputs (
        const vector<string>	&sourceColorIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_COLOR_INPUT_SEMANTIC, sourceColorIDs, setIndices, pv->offset);
}

        void
PolylistElement::AddWeightInputs (
        const vector<string>	&sourceWeightIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_WEIGHT_INPUT_SEMANTIC, sourceWeightIDs, setIndices, pv->offset);
}

        bool
PolylistElement::GetVertexCounts (
        std::vector<unsigned>	&vertexCounts)
{
        bool	linked(false);
        if (!pv->vertexCounts) {
                pv->vertexCounts = GetElementHandle ().FirstChildElement (
                        ELEMENT_VCOUNT).Element ();
        }
        if (pv->vertexCounts) {
                GetElementValue (pv->vertexCounts, vertexCounts);

                /*
                 * The vertex counts array must have the same number
                 * of entries as indicated by the polylist count
                 * attribute, or the document is invalid.
                 */
                if (vertexCounts.size () == GetAttributeUnsigned (ATTRIBUTE_COUNT)) {
                        linked = true;
                }
        }

        return linked;
}

/*
 * Add a vector of unsigned ints to a float array.
 */
        static void
AddUnsignedArrayValues(
        PolylistElement		&polylist,
        ElementXML		*unsignedArray,
        vector<unsigned>	&values)
{
        string arrayText;
        for (vector<unsigned>::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += IntegerToString(*iter);
                     if (iter + 1 != values.end()) {
                        arrayText += string(ATTRVALUE_SPACE);
                }
        }
        polylist.SetElementValue (unsignedArray, arrayText);
}

        void
PolylistElement::AddVertexCounts (
        vector<unsigned>	&vertexCounts)
{
        /*
         * Overwrite the previous vertex count if one is already present.
         */
        if (pv->vertexCounts) {
                ClearElementValue (pv->vertexCounts);
        }
        else {
                pv->vertexCounts = AddElement (ELEMENT_VCOUNT);
        }

        AddUnsignedArrayValues (*this, pv->vertexCounts, vertexCounts);
}

/*
 * Copy the subset of point coordinates indexed by loopIndices, from srcPoints
 * to dstPoints, skipping indices according to maxInputOffset (the number of
 * inputs per index set) and vertexInputOffset (the relative vertex input index
 * within each index set), and iterating from the element at startIndex for
 * vertexPolyCount vertices.
 */
        void
CopyPolylistVertexPoints (
        const std::vector<float>	&srcPoints,
        std::vector<float>		&dstPoints,
        unsigned			 maxInputOffset,
        unsigned			 vertexInputOffset,
        unsigned			 startIndex,
        unsigned			 vertexPolyCount,
        const std::vector<unsigned>	&srcLoopIndices,
        std::vector<unsigned>		&polyLoopIndices)
{
        // unsigned count = vertexPolyCount * (maxInputOffset + 1);
        unsigned posInputIndex = startIndex;
        for (unsigned vertexPolyIndex = 0;
             vertexPolyIndex < vertexPolyCount; ++vertexPolyIndex) {
                unsigned vertexLookup = posInputIndex + vertexInputOffset;
                unsigned vertexIndex = srcLoopIndices.at (vertexLookup);

                /*
                 * The position array contains triplets of xyz coordinates.
                 */
                for (unsigned index = 0; index < 3; ++index) {
                        unsigned valueIndex = vertexIndex * 3 + index;
                        dstPoints.push_back (srcPoints[valueIndex]);
                }

                /*
                 * Copy the subset of indices associated with the
                 * current polygon.
                 */
                for (unsigned offsetIndex = 0; offsetIndex <= maxInputOffset;
                        ++offsetIndex) {
                        vertexLookup = posInputIndex + offsetIndex;
                        vertexIndex = srcLoopIndices.at (vertexLookup);
                        polyLoopIndices.push_back (vertexIndex);
                }

                posInputIndex += maxInputOffset + 1;
        }
        
}

        bool
PolylistElement::GetInputIndices (
        std::vector<unsigned>	&inputIndices)
{
        bool	linked(false);
        if (!pv->inputIndices) {
                pv->inputIndices = GetElementHandle ().FirstChildElement (
                        ELEMENT_P).Element ();
        }
        if (pv->inputIndices) {
                GetElementValue (pv->inputIndices, inputIndices);

                /*
                 * [TODO]
                 * The input indices array must have the same number
                 * of entries as indicated by the maximum input offset
                 * multiplied by the total number of polygon vertex counts,
                 * or the document is invalid.
                 */
        //	unsigned inputIndexCount = (GetMaxInputOffset () + 1) * vcountTally;
        //	if (inputIndices.size () == inputIndexCount) {
                        linked = true;
        //	}
        }

        return linked;
}

/*
 * [TODO]
 */
        bool
PolylistElement::GetInputIndices (
        std::vector<unsigned>	&inputIndices,
        std::vector<float>	&points,
        std::vector<float>	&normals,
        std::vector<float>	&weights)
{
        bool	linked(false);
        if (!pv->inputIndices) {
                pv->inputIndices = GetElementHandle ().FirstChildElement (
                        ELEMENT_P).Element ();
        }
        if (pv->inputIndices) {
                std::vector<unsigned>	allLoopIndices;
                std::vector<unsigned>	polyVertexCounts;
                GetElementValue (pv->inputIndices, allLoopIndices);
                GetVertexCounts (polyVertexCounts);

                unsigned maxInputOffset = GetMaxInputOffset ();
                unsigned vertexInputOffset = GetVertexInputOffset ();
                unsigned inputIndicesIndex = 0;

                /*
                 * Track which normals have been flipped, so we don't
                 * flip the same normal more than once.
                 */
                std::set<unsigned> flippedNormals;

                /*
                 * Iterate over each polygon in the polylist.
                 */
                for (vector<unsigned>::const_iterator iter = polyVertexCounts.begin ();
                        iter != polyVertexCounts.end (); ++iter) {
                        unsigned vertexPolyCount = *iter;

                        /*
                         * Find the best convex starting point.
                         */
                        std::vector<float> polyPoints;
                        std::vector<unsigned>	polyLoopIndices;
                        CopyPolylistVertexPoints (points, polyPoints,
                                maxInputOffset, vertexInputOffset,
                                inputIndicesIndex, vertexPolyCount,
                                allLoopIndices,
                                polyLoopIndices);

                        math::Vector3 norm;
                        PolygonGetNormal (polyPoints, norm);
                        math::TestAxis		 tax;
                        math::AxisTestSet (tax, math::AxisMaxExtent (norm));
                        int orient = PolygonOrientation (polyPoints, tax);

                        /*
                         * If the first vertex is not at a convex
                         * location, we need the flip the normals of
                         * the loop.
                         */
                        bool flipOuterNormals =
                                (PolygonFirstConvex (polyPoints) == -1);

                        /*
                         * Check for the best starting index,
                         * avoiding a start at a concave position.
                         */
                        unsigned goodStartIndex;
                        bool good = GoodVertexIndex (
                                points,
                                maxInputOffset,
                                vertexInputOffset,
                                polyLoopIndices,
                                tax, orient,
                                goodStartIndex);
                        if (good) {
                                if (flipOuterNormals) {
                                        /*
                                         * Shift poly points to start with
                                         * the good index.
                                         */
                                        std::vector<float> shiftedPoints;
                                        unsigned pointCount = static_cast<unsigned>(polyPoints.size () / 3);
                                        for (unsigned pointIndex = 0;
                                                pointIndex < pointCount;
                                                ++pointIndex) {
                                                unsigned shiftIndex =
                                                        (pointIndex + goodStartIndex) % pointCount;
                                                for (unsigned axisIndex = 0;
                                                        axisIndex < 3; ++axisIndex) {
                                                        unsigned srcIndex =
                                                                shiftIndex * 3 + axisIndex;
                                                        shiftedPoints.push_back (
                                                                polyPoints.at (srcIndex));
                                                }
                                        }

                                        /*
                                         * Re-evaluate shifted points.
                                         */
                                        PolygonGetNormal (shiftedPoints, norm);
                                        math::TestAxis		 tax;
                                        math::AxisTestSet (tax, math::AxisMaxExtent (norm));
                                        int orient = PolygonOrientation (shiftedPoints, tax);
                                        flipOuterNormals =
                                                (PolygonFirstConvex (shiftedPoints) == -1);
                                }
                        }
                        else {
                                /*
                                 * Fall back to the first point when there is
                                 * no best convex vertex.
                                 */
                                goodStartIndex = 0;
                        }

                        /*
                         * If we have normals, determine
                         * the normal index offset.
                         */
                        unsigned normalInputOffset;
                        bool hasNormals = (normals.size () > 0);
                        if (hasNormals) {
                                normalInputOffset = GetNormalInputOffset ();
                        }
                        else {
                                normalInputOffset = 0;
                        }

                        /*
                         * Configure the winding direction.
                         */
                        int startIndex, endIndex;
                        int direction;
                        int offsetStartIndex = static_cast<int>(goodStartIndex);
                        if (flipOuterNormals) {
                                startIndex = vertexPolyCount - 1;
                                offsetStartIndex += vertexPolyCount + 1;
                                endIndex = -1;
                                direction = -1;
                        }
                        else {
                                startIndex = 0;
                                endIndex = vertexPolyCount;
                                direction = 1;
                        }

                        /*
                         * If the first vertex was not convex,
                         * we iterate in reverse order and flip
                           the normals of the polygon loop.
                         */
                        for (int vertexPolyIndex = startIndex;
                             vertexPolyIndex != endIndex; vertexPolyIndex += direction) {
                                unsigned indexMod =
                                        (vertexPolyIndex + offsetStartIndex) % vertexPolyCount;
                                for (unsigned offsetIndex = 0;
                                     offsetIndex <= maxInputOffset; ++offsetIndex) {
                                        unsigned pOuterIndex =
                                                indexMod * (maxInputOffset + 1) + offsetIndex;
                                        unsigned indexValue =
                                                polyLoopIndices[pOuterIndex];

                                        /*
                                         * Check to make sure we
                                         * aren't flipping the same
                                         * normal more than once.
                                         */
                                        if (hasNormals && flipOuterNormals &&
                                            (offsetIndex == normalInputOffset)) {
                                                // [TODO] In the case where the normals and
                                                //	  the points share indices, they need
                                                //	  to be broken out into separate indices!
                                                FlipNormal (normals, flippedNormals, indexValue);
                                        }

                                        inputIndices.push_back (indexValue);

                                }
                                /*
                                 * Track the index for the next polygon.
                                 */
                                inputIndicesIndex += maxInputOffset + 1;
                        }
                }

                /*
                 * [TODO] Validation:
                 * The input indices array must have the same number
                 * of entries as indicated by the maximum input offset
                 * multiplied by the total number of polygon vertex counts,
                 * or the document is invalid.
                 */
        //	unsigned inputIndexCount = (GetMaxInputOffset () + 1) * vcountTally;
        //	if (inputIndices.size () == inputIndexCount) {
                        linked = true;
        //	}
        }

        return linked;
}

        void
PolylistElement::AddInputIndices (
        vector<unsigned>	&inputIndices)
{
        /*
         * Overwrite the previous vertex count if one is already present.
         */
        if (pv->inputIndices) {
                ClearElementValue (pv->inputIndices);
        }
        else {
                pv->inputIndices = AddElement (ELEMENT_P);
        }

        AddUnsignedArrayValues (*this, pv->inputIndices, inputIndices);
}

/*
 * ---------------------------------------------------------------------------
 * Triangles.
 */

struct pv_TrianglesElement
{
        pv_TrianglesElement (MeshElement *activeMesh)
                :
                mesh(activeMesh)
        {
                Init ();
        }

        void		 Init ()
        {
                count = 0;
                offset = 0;
                inputVertex = NULL;
                inputNormal = NULL;
                vertexCounts = NULL;
                inputIndices = NULL;
        }

        MeshElement	*mesh;
        unsigned	 count;
        unsigned	 offset;
        ElementXML	*inputVertex;
        ElementXML	*inputNormal;
        ElementXML	*vertexCounts;
        ElementXML	*inputIndices;
};

TrianglesElement::TrianglesElement (
        MeshElement	&mesh,
        unsigned	 polyCount)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_TrianglesElement(&mesh))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                mesh.AddTriangles (*this);
                SetAttribute (ATTRIBUTE_COUNT, polyCount);
        }
        
        LinkToElement (this);
}

TrianglesElement::TrianglesElement (
        MeshElement	&mesh)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_TrianglesElement(&mesh))
{
        LinkToElement (this);
}

TrianglesElement::~TrianglesElement ()
{
        delete pv;
}

        bool
TrianglesElement::LinkNextTriangles (TrianglesElement &triangles)
{
        bool linked = LinkNextSiblingElement (ELEMENT_TRIANGLES, triangles);
        if (linked) {
                pv->Init ();
        }

        return linked;
}

        string
TrianglesElement::GetMaterialName () const
{
        return GetAttribute (ATTRIBUTE_MATERIAL);
}

        string
TrianglesElement::GetGeometryID () const
{
        return pv->mesh->GetGeometryID ();
}

        void
TrianglesElement::SetMaterialName (
        const string	&name)
{
        /*
         * Bind the Triangles to its material.
         */
        SetAttribute (ATTRIBUTE_MATERIAL,
                MaterialSymbolicID (ItemID (name)));
}

        unsigned
TrianglesElement::GetCount () const
{
        return GetAttributeUnsigned (ATTRIBUTE_COUNT);
}

        void
TrianglesElement::AddVertexInput ()
{
        /*
         * Overwrite the previous vertex input if one is already present.
         */
        if (pv->inputVertex) {
                ClearElementValue (pv->inputVertex);
        }
        else {
                pv->inputVertex = AddElement (ELEMENT_INPUT);
        }
        SetAttribute (pv->inputVertex, ATTRIBUTE_SEMANTIC, ATTRVALUE_VERTEX);
        SetAttribute (pv->inputVertex, ATTRIBUTE_SOURCE,
                URI_Ref (VerticesID (pv->mesh->GetGeometryID ())));
        SetAttribute (pv->inputVertex, ATTRIBUTE_OFFSET, pv->offset++);
}

        void
TrianglesElement::AddNormalInput (const string &sourceNormalsID)
{
        /*
         * Overwrite the previous normal input if one is already present.
         */
        if (pv->inputNormal) {
                ClearElementValue (pv->inputNormal);
        }
        else {
                pv->inputNormal = AddElement (ELEMENT_INPUT);
        }

        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SEMANTIC,
                ATTRVALUE_NORMAL);
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SOURCE,
                URI_Ref(sourceNormalsID));
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_OFFSET,
                pv->offset++);
}

        void
TrianglesElement::AddTexcoordInputs (
        const vector<string>	&sourceTexcoordsIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_TEXCOORD, sourceTexcoordsIDs, setIndices, pv->offset);
}

        void
TrianglesElement::AddColorInputs (
        const vector<string>	&sourceColorIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_COLOR_INPUT_SEMANTIC, sourceColorIDs, setIndices, pv->offset);
}

        void
TrianglesElement::AddWeightInputs (
        const vector<string>	&sourceWeightIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_WEIGHT_INPUT_SEMANTIC, sourceWeightIDs, setIndices, pv->offset);
}

/*
 * Add a vector of unsigned ints to a float array.
 */
        static void
AddUnsignedArrayValues(
        TrianglesElement	&triangles,
        ElementXML		*unsignedArray,
        vector<unsigned>	&values)
{
        string arrayText;
        for (vector<unsigned>::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += IntegerToString(*iter);
                     if (iter + 1 != values.end()) {
                        arrayText += string(ATTRVALUE_SPACE);
                }
        }
        triangles.SetElementValue (unsignedArray, arrayText);
}

        bool
TrianglesElement::GetInputIndices (
        std::vector<unsigned>	&inputIndices)
{
        bool	linked(false);
        if (!pv->inputIndices) {
                pv->inputIndices = GetElementHandle ().FirstChildElement (
                        ELEMENT_P).Element ();
        }
        if (pv->inputIndices) {
                GetElementValue (pv->inputIndices, inputIndices);

                /*
                 * [TODO]
                 * The input indices array must have the same number
                 * of entries as indicated by the maximum input offset
                 * multiplied by the total number of polygon vertex counts,
                 * or the document is invalid.
                 */
        //	unsigned inputIndexCount = (GetMaxInputOffset () + 1) * vcountTally;
        //	if (inputIndices.size () == inputIndexCount) {
                        linked = true;
        //	}
        }

        return linked;
}

        void
TrianglesElement::AddInputIndices (
        vector<unsigned>	&inputIndices)
{
        /*
         * Overwrite the previous vertex count if one is already present.
         */
        if (pv->inputIndices) {
                ClearElementValue (pv->inputIndices);
        }
        else {
                pv->inputIndices = AddElement (ELEMENT_P);
        }

        AddUnsignedArrayValues (*this, pv->inputIndices, inputIndices);
}

/*
 * ---------------------------------------------------------------------------
 * Lines.
 */

struct pv_LinesElement
{
        pv_LinesElement (MeshElement *activeMesh)
                :
                mesh(activeMesh)
        {
                Init ();
        }

        void		 Init ()
        {
                count = 0;
                offset = 0;
                inputVertex = NULL;
                inputNormal = NULL;
                vertexCounts = NULL;
                inputIndices = NULL;
        }

        MeshElement	*mesh;
        unsigned	 count;
        unsigned	 offset;
        ElementXML	*inputVertex;
        ElementXML	*inputNormal;
        ElementXML	*vertexCounts;
        ElementXML	*inputIndices;
};

LinesElement::LinesElement (
        MeshElement	&mesh,
        unsigned	 polyCount)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_LinesElement(&mesh))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                mesh.AddLines (*this);
                SetAttribute (ATTRIBUTE_COUNT, polyCount);
        }

        LinkToElement (this);
}

LinesElement::LinesElement (
        MeshElement	&mesh)
        :
        Element(mesh.PV ()),
        VertexMapInputHub (mesh),
        pv(new pv_LinesElement(&mesh))
{
        LinkToElement (this);
}

LinesElement::~LinesElement ()
{
        delete pv;
}

        bool
LinesElement::LinkNextLines (LinesElement &lines)
{
        bool linked = LinkNextSiblingElement (ELEMENT_LINES, lines);
        if (linked) {
                pv->Init ();
        }

        return linked;
}

        string
LinesElement::GetGeometryID () const
{
        return pv->mesh->GetGeometryID ();
}

        string
LinesElement::GetMaterialName () const
{
        return GetAttribute (ATTRIBUTE_MATERIAL);
}

        void
LinesElement::SetMaterialName (
        const string	&name)
{
        /*
         * Bind the Lines to its material.
         */
        SetAttribute (ATTRIBUTE_MATERIAL,
                MaterialSymbolicID (ItemID (name)));
}

        unsigned
LinesElement::GetCount () const
{
        return GetAttributeUnsigned (ATTRIBUTE_COUNT);
}

        void
LinesElement::AddVertexInput ()
{
        /*
         * Overwrite the previous vertex input if one is already present.
         */
        if (pv->inputVertex) {
                ClearElementValue (pv->inputVertex);
        }
        else {
                pv->inputVertex = AddElement (ELEMENT_INPUT);
        }
        SetAttribute (pv->inputVertex, ATTRIBUTE_SEMANTIC, ATTRVALUE_VERTEX);
        SetAttribute (pv->inputVertex, ATTRIBUTE_SOURCE,
                URI_Ref (VerticesID (pv->mesh->GetGeometryID ())));
        SetAttribute (pv->inputVertex, ATTRIBUTE_OFFSET, pv->offset++);
}

        void
LinesElement::AddNormalInput (const string &sourceNormalsID)
{
        /*
         * Overwrite the previous normal input if one is already present.
         */
        if (pv->inputNormal) {
                ClearElementValue (pv->inputNormal);
        }
        else {
                pv->inputNormal = AddElement (ELEMENT_INPUT);
        }

        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SEMANTIC,
                ATTRVALUE_NORMAL);
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_SOURCE,
                URI_Ref(sourceNormalsID));
        SetAttribute (
                pv->inputNormal,
                ATTRIBUTE_OFFSET,
                pv->offset++);
}

        void
LinesElement::AddTexcoordInput (
        const string	&sourceTexcoordsID,
        unsigned	 setIndex)
{
        /*
         * Texcoord inputs are always added, since there can be more than one.
         */
        ElementXML *inputTexcoord = AddElement (ELEMENT_INPUT);
        SetAttribute (
                inputTexcoord, ATTRIBUTE_SEMANTIC, ATTRVALUE_TEXCOORD);
        SetAttribute (
                inputTexcoord,
                ATTRIBUTE_SOURCE,
                URI_Ref(sourceTexcoordsID));

        SetAttribute (inputTexcoord, ATTRIBUTE_OFFSET, pv->offset + setIndex);

        /*
         * [TODO] When the indices for two or more UV sets are identical,
         *        merge them into a single set and use the SET attribute
         *        to distinguish between each logical set.
         */
//	SetAttribute (inputTexcoord, ATTRIBUTE_SET, setIndex);
}

        void
LinesElement::AddColorInputs (
        const vector<string>	&sourceColorIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_COLOR_INPUT_SEMANTIC, sourceColorIDs, setIndices, pv->offset);
}

        void
LinesElement::AddWeightInputs (
        const vector<string>	&sourceWeightIDs,
        const vector<unsigned>	&setIndices)
{
        return AddInputs (
                ATTRVALUE_WEIGHT_INPUT_SEMANTIC, sourceWeightIDs, setIndices, pv->offset);
}

/*
 * Add a vector of unsigned ints to a float array.
 */
        static void
AddUnsignedArrayValues(
        LinesElement		&lines,
        ElementXML		*unsignedArray,
        vector<unsigned>	&values)
{
        string arrayText;
        for (vector<unsigned>::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += IntegerToString(*iter);
                     if (iter + 1 != values.end()) {
                        arrayText += string(ATTRVALUE_SPACE);
                }
        }
        lines.SetElementValue (unsignedArray, arrayText);
}

        bool
LinesElement::GetInputIndices (
        std::vector<unsigned>	&inputIndices)
{
        bool	linked(false);
        if (!pv->inputIndices) {
                pv->inputIndices = GetElementHandle ().FirstChildElement (
                        ELEMENT_P).Element ();
        }
        if (pv->inputIndices) {
                GetElementValue (pv->inputIndices, inputIndices);

                /*
                 * [TODO]
                 * The input indices array must have the same number
                 * of entries as indicated by the maximum input offset
                 * multiplied by the total number of polygon vertex counts,
                 * or the document is invalid.
                 */
        //	unsigned inputIndexCount = (GetMaxInputOffset () + 1) * vcountTally;
        //	if (inputIndices.size () == inputIndexCount) {
                        linked = true;
        //	}
        }

        return linked;
}

        void
LinesElement::AddInputIndices (
        vector<unsigned>	&inputIndices)
{
        /*
         * Overwrite the previous vertex count if one is already present.
         */
        if (pv->inputIndices) {
                ClearElementValue (pv->inputIndices);
        }
        else {
                pv->inputIndices = AddElement (ELEMENT_P);
        }

        AddUnsignedArrayValues (*this, pv->inputIndices, inputIndices);
}

/*
 * ---------------------------------------------------------------------------
 * Mesh Technique Profile modo 401.
 */

struct pv_MeshElement_modo401
{
        pv_MeshElement_modo401 ()
                :
                paramRender(NULL),
                paramRenderCurves(NULL),
                paramDissolve(NULL),
                paramCurveRadius(NULL),

                paramSubdivisionLevel(NULL),
                paramSplinePatchLevel(NULL),
                paramCurveRefinementAngle(NULL),
                paramLinearUVs(NULL)
        {
        }

        /*
         * Channelized parameters that can be targeted for animation.
         */
        ElementXML		*paramRender;
        ElementXML		*paramRenderCurves;
        ElementXML		*paramDissolve;
        ElementXML		*paramCurveRadius;

        /*
         * Non-channelized parameters that cannot be targetd for animation.
         */
        ElementXML		*paramSubdivisionLevel;
        ElementXML		*paramSplinePatchLevel;
        ElementXML		*paramCurveRefinementAngle;
        ElementXML		*paramLinearUVs;
};

MeshElement_modo401::MeshElement_modo401 (
         MeshElement &mesh)
        :
        Element(mesh.PV ()),
        pv(new pv_MeshElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                mesh.AddTechniqueProfile_modo401 (*this);
        }
}

MeshElement_modo401::~MeshElement_modo401 ()
{
        delete pv;
}

/*
 * Channelized parameters that can be targeted for animation.
 */

 	void
MeshElement_modo401::SetRender (const std::string &render)
{
        SetParamValue (&pv->paramRender,
                PARAM_MODO_LOCATOR_RENDER,
                PARAM_MODO_LOCATOR_RENDER_NAME,
                render);
}

 	void
MeshElement_modo401::SetRenderCurves (bool renderCurves)
{
        SetParamValue (&pv->paramRenderCurves,
                PARAM_MODO_MESH_RENDER_CURVES,
                PARAM_MODO_MESH_RENDER_CURVES_NAME,
                renderCurves);
}

        void
MeshElement_modo401::SetDissolve (double dissolve)
{
        SetParamValue (&pv->paramDissolve,
                PARAM_MODO_LOCATOR_DISSOLVE,
                PARAM_MODO_LOCATOR_DISSOLVE_NAME,
                dissolve);
}

        void
MeshElement_modo401::SetCurveRadius (double radius)
{
        SetParamValue (&pv->paramCurveRadius,
                PARAM_MODO_MESH_CURVE_RADIUS,
                PARAM_MODO_MESH_CURVE_RADIUS_NAME,
                radius);
}

/*
 * Non-channelized parameters that cannot be targetd for animation.
 */

        void
MeshElement_modo401::SetSubdivisionLevel (unsigned level)
{
        SetParamValue (&pv->paramSubdivisionLevel,
                PARAM_MODO_MESH_SUBDIVISION_LEVEL,
                PARAM_MODO_MESH_SUBDIVISION_LEVEL_NAME,
                level);
}

        void
MeshElement_modo401::SetSplinePatchLevel (unsigned level)
{
        SetParamValue (&pv->paramSplinePatchLevel,
                PARAM_MODO_MESH_SPLINE_PATCH_LEVEL,
                PARAM_MODO_MESH_SPLINE_PATCH_LEVEL_NAME,
                level);
}

        void
MeshElement_modo401::SetCurveRefinementAngle (double angle)
{
        SetParamValue (&pv->paramCurveRefinementAngle,
                PARAM_MODO_MESH_CURVE_REFINEMENT_ANGLE,
                PARAM_MODO_MESH_CURVE_REFINEMENT_ANGLE_NAME,
                angle);
}

 	void
MeshElement_modo401::SetLinearUVs (bool linearUVs)
{
        SetParamValue (&pv->paramLinearUVs,
                PARAM_MODO_MESH_LINEAR_UVS,
                PARAM_MODO_MESH_LINEAR_UVS_NAME,
                linearUVs);
}

/*
 * ---------------------------------------------------------------------------
 * Mesh.
 */

struct pv_MeshElement
{
        pv_MeshElement ()
                :
                extra(NULL),
                technique(NULL)
        {
        }

        string			geometryID;
        ElementXML		*extra;
        ElementXML		*technique;
};

MeshElement::MeshElement (
        GeometryElement		&geometry,
        const std::string	&name)
        :
        Element(geometry.PV ()),
        pv(new pv_MeshElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->geometryID = geometry.GetID ();

                geometry.AddMesh (*this);
        }
}

MeshElement::MeshElement (
        GeometryElement	&geometry)
        :
        Element(geometry.PV ()),
        pv(new pv_MeshElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                pv->geometryID = geometry.GetID ();
                geometry.LinkMesh (*this);
        }
}

MeshElement::~MeshElement ()
{
        delete pv;
}

        string
MeshElement::GetGeometryID () const
{
        return pv->geometryID;
}

        bool
MeshElement::HasSource () const
{
        return HasChildElement (ELEMENT_SOURCE);
}

        bool
MeshElement::LinkSource (
        const string		&sourceID,
        SourceElement		&source)
{
        return LinkFirstChildElement (ELEMENT_SOURCE, sourceID, source);
}

        bool
MeshElement::HasVertices () const
{
        return HasChildElement (ELEMENT_VERTICES);
}

        bool
MeshElement::LinkVertices (
        const std::string	&verticesID,
        VerticesElement	&vertices)
{
        return LinkFirstChildElement (ELEMENT_VERTICES, verticesID, vertices);
}

        bool
MeshElement::LinkFirstVertices (VerticesElement &vertices)
{
        return LinkFirstChildElement (ELEMENT_VERTICES, vertices);
}

        bool
MeshElement::HasPolygons () const
{
        return HasChildElement (ELEMENT_POLYGONS);
}

        bool
MeshElement::LinkFirstPolygons (PolygonsElement &polygons)
{
        return LinkFirstChildElement (ELEMENT_POLYGONS, polygons);
}

        bool
MeshElement::HasPolylist () const
{
        return HasChildElement (ELEMENT_POLYLIST);
}

        bool
MeshElement::LinkFirstPolylist (PolylistElement &polylist)
{
        return LinkFirstChildElement (ELEMENT_POLYLIST, polylist);
}

        bool
MeshElement::HasTriangles () const
{
        return HasChildElement (ELEMENT_TRIANGLES);
}

        bool
MeshElement::LinkFirstTriangles (TrianglesElement &triangles)
{
        return LinkFirstChildElement (ELEMENT_TRIANGLES, triangles);
}

        bool
MeshElement::HasLines () const
{
        return HasChildElement (ELEMENT_LINES);
}

        bool
MeshElement::LinkFirstLines (LinesElement &lines)
{
        return LinkFirstChildElement (ELEMENT_LINES, lines);
}

        void
MeshElement::AddSource (SourceElement &source)
{
        source.SetElement (AddElement (ELEMENT_SOURCE));
}

        void
MeshElement::AddVertices (VerticesElement &vertices)
{
        vertices.SetElement (AddElement (ELEMENT_VERTICES));
}

        void
MeshElement::AddPolygons (PolygonsElement &polygons)
{
        polygons.SetElement (AddElement (ELEMENT_POLYGONS));
}

        void
MeshElement::AddPolylist (PolylistElement &polylist)
{
        polylist.SetElement (AddElement (ELEMENT_POLYLIST));
}

        void
MeshElement::AddTriangles (TrianglesElement &triangles)
{
        triangles.SetElement (AddElement (ELEMENT_TRIANGLES));
}

        void
MeshElement::AddLines (LinesElement &lines)
{
        lines.SetElement (AddElement (ELEMENT_LINES));
}

        void
MeshElement::AddTechniqueProfile_modo401 (
        MeshElement_modo401 &modoMesh)
{
        if (pv->extra) {
                ClearElementValue (pv->extra);
        }
        else {
                pv->extra = AddElement (ELEMENT_EXTRA);
        }

        if (pv->technique) {
                ClearElementValue (pv->technique);
        }
        else {
                pv->technique = AddElement (pv->extra, ELEMENT_TECHNIQUE);
        }

        modoMesh.SetElement (pv->technique);
        SetAttribute (pv->technique, ATTRIBUTE_PROFILE, PROFILE_MODO401);
}

/*
 * ---------------------------------------------------------------------------
 * Geometry.
 */

GeometryElement::GeometryElement (
        GeometryLibraryElement	&library,
        const std::string	&id,
        const std::string	&name)
        :
        Element(library.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddGeometry (*this);

                string geometryID = GeometryID (ItemID (id));
                SetAttribute (ATTRIBUTE_ID, geometryID);
                SetAttribute (ATTRIBUTE_NAME, EscapeNCName (name));
        }
}

GeometryElement::GeometryElement (
        GeometryLibraryElement	&library)
        :
        Element(library.PV ())
{
}

GeometryElement::~GeometryElement ()
{
}

        bool
GeometryElement::HasMesh () const
{
        return HasChildElement (ELEMENT_MESH);
}

        bool
GeometryElement::LinkMesh (MeshElement &mesh)
{
        return LinkFirstChildElement (ELEMENT_MESH, mesh);
}

        void
GeometryElement::AddMesh (MeshElement &mesh)
{
         mesh.SetElement (AddElement (ELEMENT_MESH));
}

/*
 * ---------------------------------------------------------------------------
 * Geometry Library.
 */

GeometryLibraryElement::GeometryLibraryElement (COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddGeometryLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkGeometryLibrary (*this);
        }
}

GeometryLibraryElement::~GeometryLibraryElement ()
{
}

        bool
GeometryLibraryElement::HasGeometry () const
{
        return HasChildElement (ELEMENT_GEOMETRY);
}

        bool
GeometryLibraryElement::LinkGeometry (
        const string		&geometryID,
        GeometryElement		&geometry)
{
        return LinkFirstChildElement (ELEMENT_GEOMETRY, geometryID, geometry);
}

        void
GeometryLibraryElement::AddGeometry (GeometryElement &geometry)
{
        geometry.SetElement (AddElement (ELEMENT_GEOMETRY));
}

} // namespace cio

