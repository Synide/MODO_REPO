/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_shadernode.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"
#include "cio_bind.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Technique and Extra.
 */


ShaderElement_modo401::ShaderElement_modo401 (
        ExtraElement *extra)
        :
        Element(extra->PV ())
{
}

ShaderElement_modo401::~ShaderElement_modo401 ()
{
}

ExtraElement::ExtraElement (Element *element)
        :
        Element(element->PV ())
{
}

ExtraElement::~ExtraElement ()
{
}

        void
ExtraElement::AddTechnique (ShaderElement_modo401 *technique)
{
        ElementXML *techniqueElem = AddElement (ELEMENT_TECHNIQUE);

        technique->SetElement (techniqueElem);

        SetAttribute (techniqueElem, ATTRIBUTE_PROFILE, PROFILE_MODO401);
}

/*
 * ---------------------------------------------------------------------------
 * Shader Node.
 */

struct pv_ShaderNodeElement_modo401
        :
        public BoundElementParamValue
{
                                 pv_ShaderNodeElement_modo401 (
                                        const string	&itemName,
                                        ShaderLayerType	 layerType);

        void			 SetNode (Element *nodeIO);

        string			 name;
        ShaderLayerType		 shaderLayerType;

        Element		*node;

        ElementXML		*extra;
        ElementXML		*technique;

        ElementXML		*paramEnabled;
        ElementXML		*paramInverted;
        ElementXML		*paramBlendMode;
        ElementXML		*paramOpacity;
};

pv_ShaderNodeElement_modo401::pv_ShaderNodeElement_modo401 (
        const string	&itemName,
        ShaderLayerType	 layerType)
        :
        name(itemName),
        shaderLayerType(layerType),
        node(NULL),
        extra(NULL),
        paramEnabled(NULL),
        paramInverted(NULL),
        paramBlendMode(NULL),
        paramOpacity(NULL)
{
}

        void
pv_ShaderNodeElement_modo401::SetNode (Element *nodeIO)
{
        node = nodeIO;

        node->SetSID (ItemID (name));
        node->SetName (name);

        string	type;
        switch (shaderLayerType) {
                case SHADER_LAYER_ADVANCED_MATERIAL:
                        type = SHADER_LAYER_TYPE_ADVANCED_MATERIAL;
                        break;

                case SHADER_LAYER_POLY_CELLULAR:
                        type = SHADER_LAYER_TYPE_POLY_CELLULAR;
                        break;

                case SHADER_LAYER_POLY_CHECKER:
                        type = SHADER_LAYER_TYPE_POLY_CHECKER;
                        break;

                case SHADER_LAYER_POLY_CONSTANT:
                        type = SHADER_LAYER_TYPE_POLY_CONSTANT;
                        break;

                case SHADER_LAYER_POLY_DOTS:
                        type = SHADER_LAYER_TYPE_POLY_DOTS;
                        break;

                case SHADER_LAYER_ENVIRONMENT_MATERIAL:
                        type = SHADER_LAYER_TYPE_ENVIRONMENT_MATERIAL;
                        break;

                case SHADER_LAYER_FUR_MATERIAL:
                        type = SHADER_LAYER_TYPE_FUR_MATERIAL;
                        break;

                case SHADER_LAYER_POLY_GRADIENT:
                        type = SHADER_LAYER_TYPE_POLY_GRADIENT;
                        break;

                case SHADER_LAYER_POLY_GRID:
                        type = SHADER_LAYER_TYPE_POLY_GRID;
                        break;

                case SHADER_LAYER_POLY_GROUP:
                        type = SHADER_LAYER_TYPE_POLY_GROUP;
                        break;

                case SHADER_LAYER_POLY_IMAGE_MAP:
                        type = SHADER_LAYER_TYPE_POLY_IMAGEMAP;
                        break;

                case SHADER_LAYER_LIGHT_MATERIAL:
                        type = SHADER_LAYER_TYPE_LIGHT_MATERIAL;
                        break;

                case SHADER_LAYER_POLY_NOISE:
                        type = SHADER_LAYER_TYPE_POLY_NOISE;
                        break;

                case SHADER_LAYER_POLY_PROCESS:
                        type = SHADER_LAYER_TYPE_POLY_PROCESS;
                        break;

                case SHADER_LAYER_RENDER_OUTPUT:
                        type = SHADER_LAYER_TYPE_RENDER_OUTPUT;
                        break;

                case SHADER_LAYER_POLY_RIPPLES:
                        type = SHADER_LAYER_TYPE_POLY_RIPPLES;
                        break;

                case SHADER_LAYER_SHADER:
                        type = SHADER_LAYER_TYPE_SHADER;
                        break;

                case SHADER_LAYER_SURFACE_GENERATOR:
                        type = SHADER_LAYER_TYPE_SURFACE_GENERATOR;
                        break;

                case SHADER_LAYER_POLY_WEAVE:
                        type = SHADER_LAYER_TYPE_WEAVE;
                        break;

                case SHADER_LAYER_WEIGHT_MAP_TEXTURE:
                        type = SHADER_LAYER_TYPE_WEIGHT_MAP_TEXTURE;
                        break;

                case SHADER_LAYER_POLY_WOOD:
                        type = SHADER_LAYER_TYPE_WOOD;
                        break;
        }

        extra = node->AddElement (ELEMENT_EXTRA);
        if (!type.empty ()) {
                node->SetType (extra, type);
        }

        technique = node->AddElement (extra, ELEMENT_TECHNIQUE);
        node->SetAttribute (technique, ATTRIBUTE_PROFILE, PROFILE_MODO401);
}

ShaderNodeElement_modo401::ShaderNodeElement_modo401 (
        RenderElement_modo401	&render,
        const string				&name,
        ShaderLayerType				 layerType)
        :
        Element(render.PV ()),
        pv(new pv_ShaderNodeElement_modo401(name, layerType))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                render.AddShaderNode (this);
                pv->SetNode (this);
        }
}

ShaderNodeElement_modo401::ShaderNodeElement_modo401 (
        EnvironmentElement_modo401	&environment,
        const string					&name,
        ShaderLayerType					 layerType)
        :
        Element(environment.PV ()),
        pv(new pv_ShaderNodeElement_modo401(name, layerType))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                environment.AddShaderNode (this);
                pv->SetNode (this);
        }
}

ShaderNodeElement_modo401::ShaderNodeElement_modo401 (
        LightShaderNodeElement_modo401	&light,
        const string			&name,
        ShaderLayerType			 layerType)
        :
        Element(light.PV ()),
        pv(new pv_ShaderNodeElement_modo401(name, layerType))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                light.AddShaderNode (this);
                pv->SetNode (this);
        }
}

ShaderNodeElement_modo401::ShaderNodeElement_modo401 (
        ShaderNodeElement_modo401	&node,
        const string					&name,
        ShaderLayerType					 layerType)
        :
        Element(node.PV ()),
        pv(new pv_ShaderNodeElement_modo401(name, layerType))
{
        if (GetIOMode () == IO_MODE_SAVE) {
                node.AddShaderNode (this);
                pv->SetNode (this);
        }
}

ShaderNodeElement_modo401::~ShaderNodeElement_modo401 ()
{
        delete pv;
}

        const string
ShaderNodeElement_modo401::GetName () const
{
        return pv->name;
}

        ShaderLayerType
ShaderNodeElement_modo401::GetShaderLayerType () const
{
        return pv->shaderLayerType;
}

        void
ShaderNodeElement_modo401::SetEnabled (bool enabled)
{
}

        void
ShaderNodeElement_modo401::SetInverted (bool inverted)
{
}

        void
ShaderNodeElement_modo401::SetBlendMode (const string &mode)
{
}

        void
ShaderNodeElement_modo401::SetOpacity (double percent)
{
}

        void
ShaderNodeElement_modo401::AddExtra (
        ExtraElement *extra)
{
        ElementXML *extraElem = AddElement (ELEMENT_EXTRA);

        extra->SetElement (extraElem);
}

        void
ShaderNodeElement_modo401::AddShaderNode (
        ShaderNodeElement_modo401 *node)
{
        ElementXML *nodeElem = AddElement (ELEMENT_NODE);

        node->SetElement (nodeElem);
}

/*
 * ---------------------------------------------------------------------------
 * Effect Advanced Technique Profile modo 401.
 */

struct pv_AdvancedShaderNodeElement_modo401
{
        pv_AdvancedShaderNodeElement_modo401 ()
                :
                extra(NULL),

                paramDiffuseAmount(NULL),
                paramDiffuseColor(NULL),
                paramConserveEnergy(NULL)
        {
        }

        ElementXML		*extra;

        ElementXML		*paramDiffuseAmount;
        ElementXML		*paramDiffuseColor;

        ElementXML		*paramConserveEnergy;
};

AdvancedShaderNodeElement_modo401::AdvancedShaderNodeElement_modo401 (
        RenderElement_modo401	&render,
        const string				&itemName)
        :
        ShaderNodeElement_modo401(
                render, itemName, SHADER_LAYER_ADVANCED_MATERIAL),
        pv(new pv_AdvancedShaderNodeElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                render.AddShaderNode (this);
        }
}

AdvancedShaderNodeElement_modo401::~AdvancedShaderNodeElement_modo401 ()
{
        delete pv;
}

/*
 * BRDF channels.
 */

        void
AdvancedShaderNodeElement_modo401::SetDiffuseAmount (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetDiffuseColor (
        const ColorRGB &color)
{
}

        void
AdvancedShaderNodeElement_modo401::SetConserveEnergy (
        bool conserve)
{
}

        void
AdvancedShaderNodeElement_modo401::SetSpecularAmount (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetSpecularColor (
        const ColorRGB &color)
{
}

        void
AdvancedShaderNodeElement_modo401::SetSpecularFresnel (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetRoughness (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetAnisotropy (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetUVMap (
        const std::string &mapName)
{
}

        void
AdvancedShaderNodeElement_modo401::SetReflectionAmount (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetReflectionFresnel (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetReflectionColor (
        const ColorRGB &color)
{
}

        void
AdvancedShaderNodeElement_modo401::SetReflectionType (
        EffectReflectionType type)
{
}

        void
AdvancedShaderNodeElement_modo401::SetBlurryReflection (
        bool blurry)
{
}

        void
AdvancedShaderNodeElement_modo401::SetReflectionRays (
        unsigned count)
{
}

        void
AdvancedShaderNodeElement_modo401::SetClearcoatAmount (
        double percent)
{
}

/*
 * Surface Normal channels.
 */

        void
AdvancedShaderNodeElement_modo401::SetBumpStrength (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetDisplacementDistance (
        double distance)
{
}

        void
AdvancedShaderNodeElement_modo401::SetSmoothing (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetSmoothingAngle (
        double degrees)
{
}

        void
AdvancedShaderNodeElement_modo401::SetDoubleSided (
        bool isDoubleSided)
{
}

/*
 * Transparency channels.
 */

        void
AdvancedShaderNodeElement_modo401::SetTransparentAmount (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetTransparentColor (
        const ColorRGB &color)
{
}

        void
AdvancedShaderNodeElement_modo401::SetAbsorptionDistance (
        double distance)
{
}

        void
AdvancedShaderNodeElement_modo401::SetRefractiveIndex (
        double index)
{
}

        void
AdvancedShaderNodeElement_modo401::SetDispersion (
        double amount)
{
}

        void
AdvancedShaderNodeElement_modo401::SetRefractionRoughness (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetRefractionRays (
        unsigned count)
{
}

        void
AdvancedShaderNodeElement_modo401::SetDissolveAmount (
        double percent)
{
}

/*
 * Subsurface Scattering channels.
 */

        void
AdvancedShaderNodeElement_modo401::SetSubsurfaceAmount (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetSubsurfaceColor (
        const ColorRGB &color)
{
}

        void
AdvancedShaderNodeElement_modo401::SetScatteringDistance (
        double distance)
{
}

        void
AdvancedShaderNodeElement_modo401::SetFrontWeighting (
        double percent)
{
}

        void
AdvancedShaderNodeElement_modo401::SetSubsurfaceSamples (
        double count)
{
}

/*
 * Luminosity channels.
 */

        void
AdvancedShaderNodeElement_modo401::SetLuminousIntensity (
        double watts)
{
}

        void
AdvancedShaderNodeElement_modo401::SetLuminousColor (
        const ColorRGB &color)
{
}

/*
 * Ray Tracing channels.
 */
        void
AdvancedShaderNodeElement_modo401::SetExitColor (
        const ColorRGB &color)
{
}

/*
 * ---------------------------------------------------------------------------
 * Shader Node Poly Technique Profile modo 401.
 */

struct pv_PolyShaderNodeElement_modo401
{
        pv_PolyShaderNodeElement_modo401 ()
                :
                paramTextureEffect(NULL)
        {
        }

        ElementXML	*paramTextureEffect;
};

PolyShaderNodeElement_modo401::PolyShaderNodeElement_modo401 (
        RenderElement_modo401	&render,
        const string				&name,
        ShaderLayerType				 layerType)
        :
        ShaderNodeElement_modo401 (render, name, layerType),
        pv(new pv_PolyShaderNodeElement_modo401 ())
{
}

PolyShaderNodeElement_modo401::PolyShaderNodeElement_modo401 (
        EnvironmentElement_modo401	&environment,
        const string					&name,
        ShaderLayerType					 layerType)
        :
        ShaderNodeElement_modo401 (environment, name, layerType),
        pv(new pv_PolyShaderNodeElement_modo401 ())
{
}

PolyShaderNodeElement_modo401::PolyShaderNodeElement_modo401 (
        LightShaderNodeElement_modo401	&light,
        const string						&name,
        ShaderLayerType						 layerType)
        :
        ShaderNodeElement_modo401 (light, name, layerType),
        pv(new pv_PolyShaderNodeElement_modo401 ())
{
}

PolyShaderNodeElement_modo401::PolyShaderNodeElement_modo401 (
        ShaderNodeElement_modo401	&node,
        const string					&name,
        ShaderLayerType					 layerType)
        :
        ShaderNodeElement_modo401 (node, name, layerType),
        pv(new pv_PolyShaderNodeElement_modo401 ())
{
}

PolyShaderNodeElement_modo401::~PolyShaderNodeElement_modo401 ()
{
        delete pv;
}

/*
 * Different sets of texture effects are available, depending
 * on the parent shader node type for a given layer.
 */

        void
PolyShaderNodeElement_modo401::SetMaterialTextureEffect (
        MaterialTextureEffect effect)
{
}

        void
PolyShaderNodeElement_modo401::SetEnvironmentTextureEffect (
        EnvironmentTextureEffect effect)
{
}

        void
PolyShaderNodeElement_modo401::SetLightTextureEffect (
        LightTextureEffect effect)
{
}

/*
 * ---------------------------------------------------------------------------
 * Effect Constant Technique Profile modo 401.
 */

struct pv_ConstantShaderNodeElement_modo401
{
        pv_ConstantShaderNodeElement_modo401 ()
                :
                paramColor(NULL),
                paramAmount(NULL)
        {
        }

        ElementXML		*paramColor;
        ElementXML		*paramAmount;
};

ConstantShaderNodeElement_modo401::ConstantShaderNodeElement_modo401 (
        RenderElement_modo401	&render,
        const string				&itemName)
        :
        PolyShaderNodeElement_modo401(
                render, itemName, SHADER_LAYER_POLY_CONSTANT),
        pv(new pv_ConstantShaderNodeElement_modo401())
{
}

ConstantShaderNodeElement_modo401::~ConstantShaderNodeElement_modo401 ()
{
        delete pv;
}

        void
ConstantShaderNodeElement_modo401::SetColor (
        const ColorRGB &color)
{
}

        void
ConstantShaderNodeElement_modo401::SetAmount (
        double percent)
{
}

/*
 * ---------------------------------------------------------------------------
 * Render Node.
 */

struct pv_RenderElement_modo401
        :
        public BoundElementParamValue
{
        pv_RenderElement_modo401 ()
                :
                extra(NULL),
                extraElem(NULL),
                technique(NULL),
                paramFrameRangeFirst(NULL),
                paramFrameRangeLast(NULL),
                paramFrameRangeStep(NULL),
                paramResolutionUnit(NULL),
                paramFrameDPI(NULL),
                paramFramePixelAspectRatio(NULL),
                paramBucketWidth(NULL),
                paramBucketHeight(NULL),
                paramBucketOrder(NULL),
                paramBucketReverseOrder(NULL),
                paramBucketWriteToDisk(NULL),
                paramBucketSkipExisting(NULL),
                paramRenderRegion(NULL),
                paramRenderRegionLeft(NULL),
                paramRenderRegionRight(NULL),
                paramRenderRegionTop(NULL),
                paramRenderRegionBottom(NULL),
                paramAntialiasing(NULL),
                paramAntialiasingFilter(NULL),
                paramRefinementShadingRate(NULL),
                paramRefinementThreshold(NULL),
                paramRefineBucketBorders(NULL),
                paramRayTracingShadows(NULL),
                paramReflectionDepth(NULL),
                paramRefractionDepth(NULL),
                paramRayThreshold(NULL),
                paramAdaptiveSubdivision(NULL),
                paramSubdivisionRate(NULL),
                paramMicropolyDisplacement(NULL),
                paramDisplacementRate(NULL),
                paramDisplacementRatio(NULL),
                paramMinimumEdgeLength(NULL),
                paramSmoothPositions(NULL),
                paramAmbientIntensity(NULL),
                paramAmbientColor(NULL),
                paramEnableIndirectIllumination(NULL),
                paramIndirectIlluminationScope(NULL),
                paramIndirectRays(NULL),
                paramIndirectBounces(NULL),
                paramIndirectRange(NULL),
                paramSubsurfaceScattering(NULL),
                paramVolumetricsAffectIndirect(NULL),
                paramIrradianceCaching(NULL),
                paramIrradianceRays(NULL),
                paramIndirectSupersampling(NULL),
                paramIrradianceRate(NULL),
                paramIrradianceRatio(NULL),
                paramInterpolationValues(NULL),
                paramIrradianceGradients(NULL),
                paramWalkthroughMode(NULL),
                paramLoadIrradianceBeforeRender(NULL),
                paramLoadIrradianceFile(NULL),
                paramSaveIrradianceAfterRender(NULL),
                paramSaveIrradianceFile(NULL),
                paramEnableDirectCaustics(NULL),
                paramCausticsTotalPhotons(NULL),
                paramCausticsLocalPhotons(NULL),
                paramIndirectCaustics(NULL)
        {
        }

        virtual ~pv_RenderElement_modo401 ()
        {
                delete technique;
                delete extra;
        }

        ExtraElement				*extra;
        ElementXML				*extraElem;
        ShaderElement_modo401	*technique;

        ElementXML		*paramFrameRangeFirst;
        ElementXML		*paramFrameRangeLast;
        ElementXML		*paramFrameRangeStep;

        ElementXML		*paramResolutionUnit;

        ElementXML		*paramFrameDPI;
        ElementXML		*paramFramePixelAspectRatio;

        ElementXML		*paramBucketWidth;
        ElementXML		*paramBucketHeight;
        ElementXML		*paramBucketOrder;
        ElementXML		*paramBucketReverseOrder;
        ElementXML		*paramBucketWriteToDisk;
        ElementXML		*paramBucketSkipExisting;

        ElementXML		*paramRenderRegion;
        ElementXML		*paramRenderRegionLeft;
        ElementXML		*paramRenderRegionRight;
        ElementXML		*paramRenderRegionTop;
        ElementXML		*paramRenderRegionBottom;

        ElementXML		*paramAntialiasing;
        ElementXML		*paramAntialiasingFilter;
        ElementXML		*paramRefinementShadingRate;
        ElementXML		*paramRefinementThreshold;
        ElementXML		*paramRefineBucketBorders;
        ElementXML		*paramRenderDepthOfField;
        ElementXML		*paramRenderMotionBlur;
        ElementXML		*paramRenderStereoscopic;

        ElementXML		*paramRayTracingShadows;
        ElementXML		*paramReflectionDepth;
        ElementXML		*paramRefractionDepth;
        ElementXML		*paramRayThreshold;

        ElementXML		*paramAdaptiveSubdivision;
        ElementXML		*paramSubdivisionRate;
        ElementXML		*paramMicropolyDisplacement;
        ElementXML		*paramDisplacementRate;
        ElementXML		*paramDisplacementRatio;
        ElementXML		*paramMinimumEdgeLength;
        ElementXML		*paramSmoothPositions;

        ElementXML		*paramAmbientIntensity;
        ElementXML		*paramAmbientColor;

        ElementXML		*paramEnableIndirectIllumination;
        ElementXML		*paramIndirectIlluminationScope;
        ElementXML		*paramIndirectRays;
        ElementXML		*paramIndirectBounces;
        ElementXML		*paramIndirectRange;
        ElementXML		*paramSubsurfaceScattering;
        ElementXML		*paramVolumetricsAffectIndirect;

        ElementXML		*paramIrradianceCaching;
        ElementXML		*paramIrradianceRays;
        ElementXML		*paramIndirectSupersampling;
        ElementXML		*paramIrradianceRate;
        ElementXML		*paramIrradianceRatio;
        ElementXML		*paramInterpolationValues;
        ElementXML		*paramIrradianceGradients;
        ElementXML		*paramWalkthroughMode;
        ElementXML		*paramLoadIrradianceBeforeRender;
        ElementXML		*paramLoadIrradianceFile;
        ElementXML		*paramSaveIrradianceAfterRender;
        ElementXML		*paramSaveIrradianceFile;

        ElementXML		*paramEnableDirectCaustics;
        ElementXML		*paramCausticsTotalPhotons;
        ElementXML		*paramCausticsLocalPhotons;
        ElementXML		*paramIndirectCaustics;
};

RenderElement_modo401::RenderElement_modo401 (
        ShaderNodeLibraryElement_modo401 &library)
        :
        Element(library.PV ()),
        pv(new pv_RenderElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddRender (*this);

                pv->extra = new ExtraElement (this);
                pv->extraElem = AddElement (ELEMENT_EXTRA);
                pv->extra->SetElement (pv->extraElem);

                pv->technique = new ShaderElement_modo401 (
                        pv->extra);
                pv->extra->AddTechnique (pv->technique);

                pv->SetBoundElement (pv->technique, VIRTUAL_ELEMENT_RENDER);

                SetSID (SHADER_TREE_RENDER);
                SetName (SHADER_TREE_RENDER_NAME);
        }
}

RenderElement_modo401::~RenderElement_modo401 ()
{
        delete pv;
}

/*
 * Frame group.
 */

        void
RenderElement_modo401::SetFrameRangeFirst (unsigned first)
{
        pv->SetValue (&pv->paramFrameRangeFirst, PARAM_MODO_POLYRENDER_FRAME_RANGE_FIRST, first);
}

        void
RenderElement_modo401::SetFrameRangeLast (unsigned last)
{
        pv->SetValue (&pv->paramFrameRangeLast, PARAM_MODO_POLYRENDER_FRAME_RANGE_LAST, last);
}

        void
RenderElement_modo401::SetFrameRangeStep (unsigned step)
{
        pv->SetValue (&pv->paramFrameRangeStep, PARAM_MODO_POLYRENDER_FRAME_STEP, step);
}

        void
RenderElement_modo401::SetResolutionUnit (const string &unit)
{
        pv->SetValue (&pv->paramResolutionUnit,
                PARAM_MODO_POLYRENDER_RESOLUTION_UNIT, unit);
}

        void
RenderElement_modo401::SetFrameDPI (double dpi)
{
        pv->SetValue (&pv->paramFrameRangeStep, PARAM_MODO_POLYRENDER_FRAME_DPI, dpi);
}

        void
RenderElement_modo401::SetFramePixelAspectRatio (double ratio)
{
        pv->SetValue (&pv->paramFramePixelAspectRatio,
                PARAM_MODO_POLYRENDER_FRAME_PIXEL_ASPECT_RATIO, ratio);
}

/*
 * Buckets group.
 */

        void
RenderElement_modo401::SetBucketWidth (unsigned width)
{
        pv->SetValue (&pv->paramBucketWidth, PARAM_MODO_POLYRENDER_BUCKET_WIDTH, width);
}

        void
RenderElement_modo401::SetBucketHeight (unsigned height)
{
        pv->SetValue (&pv->paramBucketHeight, PARAM_MODO_POLYRENDER_BUCKET_HEIGHT, height);
}

        void
RenderElement_modo401::SetBucketOrder (const string &order)
{
        pv->SetValue (&pv->paramBucketOrder,
                PARAM_MODO_POLYRENDER_BUCKET_ORDER, order);
}

        void
RenderElement_modo401::SetBucketReverseOrder (bool reversed)
{
        pv->SetValue (&pv->paramBucketReverseOrder,
                PARAM_MODO_POLYRENDER_BUCKET_REVERSE_ORDER, reversed);
}

        void
RenderElement_modo401::SetBucketWriteToDisk (bool write)
{
        pv->SetValue (&pv->paramBucketReverseOrder,
                PARAM_MODO_POLYRENDER_BUCKET_WRITE_TO_DISK, write);
}

        void
RenderElement_modo401::SetBucketSkipExisting (bool skip)
{
        pv->SetValue (&pv->paramBucketReverseOrder,
                PARAM_MODO_POLYRENDER_BUCKET_SKIP_EXISTING, skip);
}

/* 
 * Region.
 */

        void
RenderElement_modo401::SetRenderRegion (bool useRegion)
{
        pv->SetValue (&pv->paramRenderRegion,
                PARAM_MODO_RENDER_REGION, useRegion);
}

        void
RenderElement_modo401::SetRenderRegionLeft (double left)
{
        pv->SetValue (&pv->paramRenderRegionLeft,
                PARAM_MODO_RENDER_REGION_LEFT, left);
}

        void
RenderElement_modo401::SetRenderRegionRight (double right)
{
        pv->SetValue (&pv->paramRenderRegionRight,
                PARAM_MODO_RENDER_REGION_RIGHT, right);
}

        void
RenderElement_modo401::SetRenderRegionTop (double top)
{
        pv->SetValue (&pv->paramRenderRegionTop,
                PARAM_MODO_RENDER_REGION_TOP, top);
}

        void
RenderElement_modo401::SetRenderRegionBottom (double bottom)
{
        pv->SetValue (&pv->paramRenderRegionBottom,
                PARAM_MODO_RENDER_REGION_BOTTOM, bottom);
}

/*
 * Antialiasing.
 */

        void
RenderElement_modo401::SetAntialiasing (const string &aa)
{
        pv->SetValue (&pv->paramAntialiasing,
                PARAM_MODO_POLYRENDER_ANTIALIASING, aa);
}

        void
RenderElement_modo401::SetAntialiasingFilter (const string &filter)
{
        pv->SetValue (&pv->paramAntialiasingFilter,
                PARAM_MODO_POLYRENDER_ANTIALIASING_FILTER, filter);
}

        void
RenderElement_modo401::SetRefinementShadingRate (double rate)
{
        pv->SetValue (&pv->paramRefinementShadingRate,
                PARAM_MODO_POLYRENDER_REFINEMENT_SHADING_RATE, rate);
}

        void
RenderElement_modo401::SetRefinementThreshold (double threshold)
{
        pv->SetValue (&pv->paramRefinementThreshold,
                PARAM_MODO_POLYRENDER_REFINEMENT_THRESHOLD, threshold);
}

        void
RenderElement_modo401::SetRefineBucketBorders (bool refine)
{
        pv->SetValue (&pv->paramRefineBucketBorders,
                PARAM_MODO_POLYRENDER_REFINE_BUCKET_BORDERS, refine);
}

/*
 * Ray Tracing.
 */

        void
RenderElement_modo401::SetRayTracingShadows (bool shadows)
{
        pv->SetValue (&pv->paramRayTracingShadows,
                PARAM_MODO_RENDER_RAY_TRACING_SHADOWS, shadows);
}

        void
RenderElement_modo401::SetReflectionDepth (unsigned depth)
{
        pv->SetValue (&pv->paramReflectionDepth,
                PARAM_MODO_RENDER_REFLECTION_DEPTH, depth);
}

        void
RenderElement_modo401::SetRefractionDepth (unsigned depth)
{
        pv->SetValue (&pv->paramRefractionDepth,
                PARAM_MODO_RENDER_REFRACTION_DEPTH, depth);
}

        void
RenderElement_modo401::SetRayThreshold (double threshold)
{
        pv->SetValue (&pv->paramRayThreshold,
                PARAM_MODO_RENDER_RAY_THRESHOLD, threshold);
}

/*
 * Geometry.
 */

        void
RenderElement_modo401::SetAdaptiveSubdivision (bool adaptiveSubd)
{
        pv->SetValue (&pv->paramAdaptiveSubdivision,
                PARAM_MODO_RENDER_ADAPTIVE_SUBDIVISION, adaptiveSubd);
}

        void
RenderElement_modo401::SetSubdivisionRate (double rate)
{
        pv->SetValue (&pv->paramSubdivisionRate,
                PARAM_MODO_RENDER_SUBDIVISION_RATE, rate);
}

        void
RenderElement_modo401::SetMicropolyDisplacement (bool micro)
{
        pv->SetValue (&pv->paramMicropolyDisplacement,
                PARAM_MODO_RENDER_MICROPOLY_DISPLACEMENT, micro);
}

        void
RenderElement_modo401::SetDisplacementRate (double rate)
{
        pv->SetValue (&pv->paramDisplacementRate,
                PARAM_MODO_RENDER_DISPLACEMENT_RATE, rate);
}

        void
RenderElement_modo401::SetDisplacementRatio (double ratio)
{
        pv->SetValue (&pv->paramDisplacementRatio,
                PARAM_MODO_RENDER_DISPLACEMENT_RATIO, ratio);
}

        void
RenderElement_modo401::SetMinimumEdgeLength (double length)
{
        pv->SetValue (&pv->paramMinimumEdgeLength,
                PARAM_MODO_RENDER_MINIMUM_EDGE_LENGTH, length);
}

        void
RenderElement_modo401::SetSmoothPositions (bool smooth)
{
        pv->SetValue (&pv->paramSmoothPositions,
                PARAM_MODO_RENDER_SMOOTH_POSITIONS, smooth);
}

/*
 * Ambient Light.
 */

        void
RenderElement_modo401::SetAmbientIntensity (double intensity)
{
        pv->SetValue (&pv->paramAmbientIntensity,
                PARAM_MODO_RENDER_AMBIENT_INTENSITY, intensity);
}

        void
RenderElement_modo401::SetAmbientColor (const ColorRGB &color)
{
        pv->SetValue (&pv->paramAmbientColor,
                PARAM_MODO_RENDER_AMBIENT_COLOR, color);
}

/*
 * Indirect Illumination.
 */

        void
RenderElement_modo401::SetEnableIndirectIllumination (bool enable)
{
        pv->SetValue (&pv->paramEnableIndirectIllumination,
                PARAM_MODO_RENDER_ENABLE_INDIRECT_ILLUMINATION, enable);
}

        void
RenderElement_modo401::SetIndirectIlluminationScope (
        const string &scope)
{
        pv->SetValue (&pv->paramIndirectIlluminationScope,
                PARAM_MODO_RENDER_INDIRECT_ILLUMINATION_SCOPE, scope);
}

        void
RenderElement_modo401::SetIndirectRays (unsigned rays)
{
        pv->SetValue (&pv->paramIndirectRays,
                PARAM_MODO_RENDER_INDIRECT_RAYS, rays);
}

        void
RenderElement_modo401::SetIndirectBounces (unsigned bounces)
{
        pv->SetValue (&pv->paramIndirectBounces,
                PARAM_MODO_RENDER_INDIRECT_BOUNCES, bounces);
}

        void
RenderElement_modo401::SetIndirectRange (double range)
{
        pv->SetValue (&pv->paramIndirectRange,
                PARAM_MODO_RENDER_INDIRECT_RANGE, range);
}

        void
RenderElement_modo401::SetSubsurfaceScattering (unsigned scattering)
{
        pv->SetValue (&pv->paramSubsurfaceScattering,
                PARAM_MODO_RENDER_SUBSURFACE_SCATTERING, scattering);
}

        void
RenderElement_modo401::SetVolumetricsAffectIndirect (bool affect)
{
        pv->SetValue (&pv->paramVolumetricsAffectIndirect,
                PARAM_MODO_RENDER_VOLUMETRICS_AFFECT_INDIRECT, affect);
}

/*
 * Irradiance Caching.
 */

        void
RenderElement_modo401::SetIrradianceCaching (bool caching)
{
        pv->SetValue (&pv->paramIrradianceCaching,
                PARAM_MODO_RENDER_ENABLE_IRRADIANCE_CACHING, caching);
}

        void
RenderElement_modo401::SetIrradianceRays (unsigned rays)
{
        pv->SetValue (&pv->paramIrradianceRays,
                PARAM_MODO_RENDER_IRRADIANCE_RAYS, rays);
}

        void
RenderElement_modo401::SetIndirectSupersampling (bool indirectSuper)
{
        pv->SetValue (&pv->paramIndirectSupersampling,
                PARAM_MODO_RENDER_INDIRECT_SUPERSAMPLING, indirectSuper);
}

        void
RenderElement_modo401::SetIrradianceRate (double rate)
{
        pv->SetValue (&pv->paramIrradianceRate,
                PARAM_MODO_RENDER_IRRADIANCE_RATE, rate);
}

        void
RenderElement_modo401::SetIrradianceRatio (double ratio)
{
        pv->SetValue (&pv->paramIrradianceRatio,
                PARAM_MODO_RENDER_IRRADIANCE_RATIO, ratio);
}

        void
RenderElement_modo401::SetInterpolationValues (
        unsigned values)
{
        pv->SetValue (&pv->paramInterpolationValues,
                PARAM_MODO_RENDER_INTERPOLATION_VALUES, values);
}

        void
RenderElement_modo401::SetIrradianceGradients (
        const std::string &gradients)
{
        pv->SetValue (&pv->paramIrradianceGradients,
                PARAM_MODO_RENDER_IRRADIANCE_GRADIENTS, gradients);
}

        void
RenderElement_modo401::SetWalkthroughMode (bool mode)
{
        pv->SetValue (&pv->paramWalkthroughMode,
                PARAM_MODO_RENDER_WALKTHROUGH_MODE, mode);
}

        void
RenderElement_modo401::SetLoadIrradianceBeforeRender (
        bool loadBefore)
{
        pv->SetValue (&pv->paramLoadIrradianceBeforeRender,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_BEFORE_RENDER, loadBefore);
}

        void
RenderElement_modo401::SetLoadIrradianceFile (
        const string file)
{
        pv->SetValue (&pv->paramLoadIrradianceFile,
                PARAM_MODO_RENDER_LOAD_IRRADIANCE_FILE, file);
}

        void
RenderElement_modo401::SetSaveIrradianceAfterRender (
        bool saveAfter)
{
        pv->SetValue (&pv->paramSaveIrradianceAfterRender,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_AFTER_RENDER, saveAfter);
}

        void
RenderElement_modo401::SetSaveIrradianceFile (
        const string file)
{
        pv->SetValue (&pv->paramSaveIrradianceFile,
                PARAM_MODO_RENDER_SAVE_IRRADIANCE_FILE, file);
}


/*
 * Caustics.
 */

        void
RenderElement_modo401::SetEnableDirectCaustics (bool enable)
{
        pv->SetValue (&pv->paramEnableDirectCaustics,
                PARAM_MODO_RENDER_ENABLE_DIRECT_CAUSTICS, enable);
}

        void
RenderElement_modo401::SetCausticsTotalPhotons (unsigned total)
{
        pv->SetValue (&pv->paramCausticsTotalPhotons,
                PARAM_MODO_RENDER_CAUSTICS_TOTAL_PHOTONS, total);
}

        void
RenderElement_modo401::SetCausticsLocalPhotons (unsigned local)
{
        pv->SetValue (&pv->paramCausticsLocalPhotons,
                PARAM_MODO_RENDER_CAUSTICS_LOCAL_PHOTONS, local);
}

        void
RenderElement_modo401::SetIndirectCaustics (
        const string &indirect)
{
        pv->SetValue (&pv->paramIndirectCaustics,
                PARAM_MODO_RENDER_INDIRECT_CAUSTICS, indirect);
}

/*
 * The node layer type must be SHADER_LAYER_ADVANCED_MATERIAL
 * or one of the SHADER_LAYER_POLY_foo types.
 */
        void
RenderElement_modo401::AddShaderNode (
        ShaderNodeElement_modo401 *node)
{
        ElementXML *nodeElem = AddElement (ELEMENT_NODE);

        node->SetElement (nodeElem);
}

/*
 * ---------------------------------------------------------------------------
 * Environment Node.
 */

struct pv_EnvironmentElement_modo401
        :
        public BoundElementParamValue
{
        pv_EnvironmentElement_modo401 ()
                :
                extra(NULL),
                extraElem(NULL),
                technique(NULL),
                paramIntensity(NULL),
                paramVisibleToCamera(NULL),
                paramVisibleToIndirectRays(NULL),
                paramVisibleToReflectionRays(NULL),
                paramVisibleToRefractionRays(NULL)
        {
        }

        virtual ~pv_EnvironmentElement_modo401 ()
        {
                delete technique;
                delete extra;
        }

        ExtraElement				*extra;
        ElementXML				*extraElem;
        ShaderElement_modo401	*technique;

        ElementXML		*paramIntensity;

        ElementXML		*paramVisibleToCamera;
        ElementXML		*paramVisibleToIndirectRays;
        ElementXML		*paramVisibleToReflectionRays;
        ElementXML		*paramVisibleToRefractionRays;
};

EnvironmentElement_modo401::EnvironmentElement_modo401 (
        ShaderNodeLibraryElement_modo401 &library)
        :
        Element(library.PV ()),
        pv(new pv_EnvironmentElement_modo401())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddEnvironment (*this);

                pv->extra = new ExtraElement (this);
                pv->extraElem = AddElement (ELEMENT_EXTRA);
                pv->extra->SetElement (pv->extraElem);

                pv->technique = new ShaderElement_modo401 (
                        pv->extra);
                pv->extra->AddTechnique (pv->technique);

                pv->SetBoundElement (pv->technique, VIRTUAL_ELEMENT_ENVIRONMENT);

                SetSID (SHADER_TREE_ENVIRONMENT);
                SetName (SHADER_TREE_ENVIRONMENT_NAME);
        }
}

EnvironmentElement_modo401::~EnvironmentElement_modo401 ()
{
        delete pv;
}

        void
EnvironmentElement_modo401::SetIntensity (
        double intensity)
{
        pv->SetValue (&pv->paramIntensity,
                PARAM_MODO_ENVIRONMENT_INTENSITY, intensity);
}

        void
EnvironmentElement_modo401::SetVisibleToCamera (
        bool visible)
{
        pv->SetValue (&pv->paramVisibleToCamera,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_CAMERA, visible);
}

        void
EnvironmentElement_modo401::SetVisibleToIndirectRays (
        bool visible)
{
        pv->SetValue (&pv->paramVisibleToIndirectRays,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_INDIRECT_RAYS, visible);
}

        void
EnvironmentElement_modo401::SetVisibleToReflectionRays (
        bool visible)
{
        pv->SetValue (&pv->paramVisibleToReflectionRays,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFLECTION_RAYS, visible);
}

        void
EnvironmentElement_modo401::SetVisibleToRefractionRays (
        bool visible)
{
        pv->SetValue (&pv->paramVisibleToRefractionRays,
                PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFRACTION_RAYS, visible);
}

        void
EnvironmentElement_modo401::AddShaderNode (
        ShaderNodeElement_modo401 *node)
{
        ElementXML *nodeElem = AddElement (ELEMENT_NODE);

        node->SetElement (nodeElem);
}

/*
 * ---------------------------------------------------------------------------
 * Shader Light Node.
 */

LightShaderNodeElement_modo401::LightShaderNodeElement_modo401 (
        ShaderNodeLibraryElement_modo401	&library,
        const string						&name)
        :
        Element(library.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                SetSID (ItemID (name));
                SetName (name);
        }
}

LightShaderNodeElement_modo401::~LightShaderNodeElement_modo401 ()
{
}

        void
LightShaderNodeElement_modo401::AddShaderNode (
        ShaderNodeElement_modo401 *node)
{
        ElementXML *nodeElem = AddElement (ELEMENT_NODE);

        node->SetElement (nodeElem);
}

/*
 * ---------------------------------------------------------------------------
 * Shader Node Library.
 */

ShaderNodeLibraryElement_modo401::ShaderNodeLibraryElement_modo401 (
        COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddShaderNodeLibraryTechniqueProfile_modo401 (*this);

                SetID (SHADER_TREE);
                SetName (SHADER_TREE_NAME);
        }
}

ShaderNodeLibraryElement_modo401::~ShaderNodeLibraryElement_modo401 ()
{
}

        void
ShaderNodeLibraryElement_modo401::AddRender (
        RenderElement_modo401 &render)
{
        render.SetElement (AddElement (ELEMENT_NODE));
}

        void
ShaderNodeLibraryElement_modo401::AddEnvironment (
        EnvironmentElement_modo401 &environment)
{
        environment.SetElement (AddElement (ELEMENT_NODE));
}

        void
ShaderNodeLibraryElement_modo401::AddLight (
        LightShaderNodeElement_modo401 &light)
{
        light.SetElement (AddElement (ELEMENT_NODE));
}

} // namespace cio

