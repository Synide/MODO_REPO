/*
 * Plug-in value textures: 3D procedural checker
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * 3d procedural checkerboard
 *
 *----------------------------------------------------------------------------*/
class Checker3dTexture : public CLxImpl_ValueTexture
{
    public:
        Checker3dTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[7];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector	primaryColor;
                LXtFVector	secondaryColor;
                float           scaleFactor;
        };
};

LXtTagInfoDesc	 Checker3dTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterChecker3dTexture (void)
{
        RegisterTexture<Checker3dTexture>   ("Checker3D.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
Checker3dTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
Checker3dTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        static LXtTextValueHint hint_intMin2[] = {
                2,                  "&min",         // integer min 1
                -1,                 NULL
                };

        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("primaryColor",      LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.9, 0.1, 0.1);
        ac.SetDefaultVec (color);

        ac.NewChannel ("secondaryColor",    LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefault (0.1, 0);

        ac.NewChannel ("scaleFactor",       LXsTYPE_FLOAT);
        ac.SetDefault (10.0, 1);
        ac.SetHint    (hint_intMin2);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
Checker3dTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "primaryColor.R");
        idx[index++] = ev.AddChan (item, "primaryColor.G");
        idx[index++] = ev.AddChan (item, "primaryColor.B");
        idx[index++] = ev.AddChan (item, "secondaryColor.R");
        idx[index++] = ev.AddChan (item, "secondaryColor.G");
        idx[index++] = ev.AddChan (item, "secondaryColor.B");
        idx[index++] = ev.AddChan (item, "scaleFactor");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
Checker3dTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->primaryColor[0]     = at.Float (idx[index++]);
        rd->primaryColor[1]     = at.Float (idx[index++]);
        rd->primaryColor[2]     = at.Float (idx[index++]);

        rd->secondaryColor[0]   = at.Float (idx[index++]);
        rd->secondaryColor[1]   = at.Float (idx[index++]);
        rd->secondaryColor[2]   = at.Float (idx[index++]);

        rd->scaleFactor         = at.Float (idx[index++]);

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
Checker3dTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
        LXpTextureInput*    tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
        RendData*           rd = (RendData *) data;
        LXtFVector          pos, intPos, fracPos, absPos;

        LXx_VCPY (pos, tInp->tPos);

        // Separate coordinates into integer and fractional parts
        intPos[0] = (float)(int)pos[0];   fracPos[0] = pos[0] - intPos[0];
        intPos[1] = (float)(int)pos[1];   fracPos[1] = pos[1] - intPos[1];
        intPos[2] = (float)(int)pos[2];   fracPos[2] = pos[2] - intPos[2];

        // Adjust negative values
        if (fracPos[0] < 0.f)
            {
            intPos[0]--;
            fracPos[0] = 1.0f + fracPos[0];
            }
         if (fracPos[1] < 0.f)
            {
            intPos[1]--;
            fracPos[1] = 1.0f + fracPos[1];
            }
        if (fracPos[2] < 0.f)
            {
            intPos[2]--;
            fracPos[2] = 1.0f + fracPos[2];
            }

        // Clamp near-integer coordinates to the nearest integer
        if (fracPos[0] < EPSILON)
            pos[0] = intPos[0];
        else if (1.-fracPos[0] < EPSILON)
            pos[0] = intPos[0] + 1.0f;

        if (fracPos[1] < EPSILON)
            pos[1] = intPos[1];
        else if (1.-fracPos[1] < EPSILON)
            pos[1] = intPos[1] + 1.0f;

        if (fracPos[2] < EPSILON)
            pos[2] = intPos[2];
        else if (1.-fracPos[2] < EPSILON)
            pos[2] = intPos[2] + 1.0f;

        // Take absolute value
        absPos[0] = (float)fabs (pos[0]);
        absPos[1] = (float)fabs (pos[1]);
        absPos[2] = (float)fabs (pos[2]);

        // Remember needed sign information
        int     sign = (pos[0] < 0.f) ^ (pos[1] < 0.f) ^ (pos[2] < 0.f);

        // Figure out which square is at this position
        int     square = ((int)(absPos[0] * rd->scaleFactor) % 2) ^
                         ((int)(absPos[1] * rd->scaleFactor) % 2) ^
                         ((int)(absPos[2] * rd->scaleFactor) % 2);


        tOut->direct   = 1;             // result should NOT be blended
        tOut->alpha[0] = 1.0;           // texture is opaque

        if (LXi_TFX_COLOR == tInp->context)         // Choose color -- primary or secondary
            if (square ^ sign)
                LXx_VCPY (tOut->color[0], rd->primaryColor);
            else
                LXx_VCPY (tOut->color[0], rd->secondaryColor);
        else
            tOut->value[0] = square ^ sign ? 1.0 : -1.0;
}

