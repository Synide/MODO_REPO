/*
 * Plug-in value textures: procedural black/white noise
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Black/white Noise texture (no args)
 *
 *----------------------------------------------------------------------------*/
class BwNoiseTexture : public CLxImpl_ValueTexture
{
    public:
        BwNoiseTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA
};

LXtTagInfoDesc	 BwNoiseTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterBwNoiseTexture (void)
{
        RegisterTexture<BwNoiseTexture>     ("BwNoise.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
BwNoiseTexture::vtx_Cleanup (
        void			*data)
{
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BwNoiseTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BwNoiseTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BwNoiseTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
BwNoiseTexture::vtx_Evaluate (
        ILxUnknownID            vector,
        LXpTextureOutput        *tOut,
        void                    *data)
{
    LXpTextureInput*    tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);

    tOut->direct   = 1;             // result should NOT be blended
    tOut->alpha[0] = 1.0;           // texture is opaque

    static float const      s_internalScale = 50.0f;
    LXtVector               pos;

    LXx_VSCL3 (pos, tInp->tPos, s_internalScale);

    NoiseUtils  noiseUtils;
    double*     dnoise = noiseUtils.noise3 (pos);
    double      noise = fabs (dnoise[0]);

    if (LXi_TFX_COLOR == tInp->context)
        LXx_VSET (tOut->color[0], noise);
    else
        tOut->value[0] = noise;
}

