/*
 * Copyright (c) 2009 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.

 */

/*
 * This file contains the constructors and initializers for the public data
 * types, and the methods of the LxoCopy class for copying data from an LXO/LXP
 * to an LXO file.
 */

#include "lxoChunks.hpp"
#include "lxoCopy.hpp"

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Constructor for LXO file copy, where caller already has a writer
 *
 *----------------------------------------------------------------------------*/
LxoCopy::LxoCopy (char const* lxoName, LxoWriteData* writer) : LxoReader (lxoName)
{
    m_ourWriter = false;
    m_writer    = writer;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Constructor for LXO file copy, where we create the writer for the new file
 *
 *----------------------------------------------------------------------------*/
LxoCopy::LxoCopy (char const* lxoName, char const* lxoCopyName) : LxoReader (lxoName)
{
    LxoWriter*  writer = new LxoWriter (lxoCopyName, NULL, 0);
    m_ourWriter = true;
    m_writer    = writer;

    if (! writer->IsLxoValid ())
        {
        delete writer;
        m_writer = NULL;
        return;
        }

    LxoFileChunk (m_writer).Write ();   // since we're creating the file, we create the header
    return;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Only destroy the writer if we created it ourselves
 *
 *----------------------------------------------------------------------------*/
LxoCopy::~LxoCopy ()
{
    if (m_ourWriter && m_writer)
        delete m_writer;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Process the chunk based on the action specified: Process, Copy or Ignore.
 * We override this method to add the Copy option.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoCopy::ProcessChunk (LXChunkUsage action)
{
    if (LXChunk_Process == action)
        return ReadChunk ();

    if (LXChunk_Copy == action)
        return CopyChunk ();

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Process the chunk based on the action specified: Process, Copy or Ignore.
 * We override this method to add the Copy option.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoCopy::ProcessItemSubChunk (LXChunkUsage action)
{
    if (LXChunk_Process == action)
        return ReadItemChunkData ();

    if (LXChunk_Copy == action)
        return CopySubChunk ();

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 * Copy the item header.  Sub chunks can still be processed/ignored.
 *----------------------------------------------------------------------------*/
        LxResult
LxoCopy::ProcessItem (char* itemType, char* name, LxULong refId)
{
    m_writer->BeginChunk ('ITEM');
    return m_writer->WriteItemHeader (itemType, name, refId);
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 * close the current item chunk
 *----------------------------------------------------------------------------*/
        LxResult
LxoCopy::ProcessItemEnd ()
{
    return m_writer->EndChunk ();
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * If ChunkUsage returns LXChunk_Process for the channel names chunk, then
 * we must take the channel names from the input file and copy them to
 * the output file; but we must also add the list of channels to
 * the writer class for use in writing LxoChannelValueSubChunk.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoCopy::ProcessChannelNames (LxULong count, LXtStringVec chans)
{
    return LxoChannelNamesChunk (m_writer).Write (chans, count);
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Provide the ability to copy a chunk after examining the header.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoCopy::CopyChunk ()
{
    /*
     * Special case: when copying the channel names from one file to another,
     * the writer NEEDS to know about the channels, for use when chunks of
     * type LxoChannelValueSubChunk are written.  Calling ReadChunk here
     * will call ProcessChannelNames, which is also defined in this class
     * to copy the channel names into the writer as they are written.
     */
    if ('CHNM' == m_chunkId)
        return ReadChunk ();

    m_writer->BeginChunk (m_chunkId);

    LxULong     count = m_unreadChunkBytes;
    LxByte*     bytes = (LxByte*) _alloca (count);

    if (NULL == bytes)
        return LXe_OUTOFMEMORY;

    ReturnOnError       (ReadBytes  (bytes, count));
    WriterReturnOnError (WriteBytes (bytes, count));

    m_unreadChunkBytes = 0;

    m_writer->EndChunk ();

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * Provide the ability to copy a sub-chunk after examining the header.
 *
 *----------------------------------------------------------------------------*/
        LxResult
LxoCopy::CopySubChunk ()
{
    m_writer->BeginSubChunk (m_subChunkId);

    LxULong     count = m_unreadSubChunkBytes;
    LxByte*     bytes = (LxByte*) _alloca (count);

    if (NULL == bytes)
        return LXe_OUTOFMEMORY;

    ReturnOnError (ReadBytes  (bytes, count));
    WriterReturnOnError (WriteBytes (bytes, count));

    m_unreadSubChunkBytes = 0;

    m_writer->EndSubChunk ();

    return LXe_OK;
}

