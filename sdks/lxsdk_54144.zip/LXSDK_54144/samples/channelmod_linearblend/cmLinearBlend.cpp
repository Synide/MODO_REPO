/*
 * Plug-in linear blend channel modifier.
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cmLinearBlend.h"

#include <lx_plugin.hpp>

#include <string>

// Linear Blend Instance

        LxResult
CLinearBlendInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        log.Info ("Initialize");
        
        m_item.set (item);
        
        return LXe_OK;
}

        void
CLinearBlendInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

        LxResult
CLinearBlendInstance::pins_SynthName (
        char			*buf,
        unsigned		 len)
{
        std::string name ("Linear Blend");
        size_t count = name.size () + 1;
        if (count > len) {
                count = len;
        }
        memcpy (buf, &name[0], count);

        return LXe_OK;
}

        LxResult
CLinearBlendInstance::cmod_Allocate (
        ILxUnknownID		 cmod,		// ILxChannelModifierID
        ILxUnknownID		 eval,		// ILxEvaluationID
        ILxUnknownID		 item,
        void		       **ppvData)
{
        CLxLoc_ChannelModifier	 chanMod (cmod);
        CLxUser_Item		 modItem (item);
        unsigned int		 chanIdx;
        
//	log.Info ("cmod_Allocate Method");
        
        // Lookup the index of the 'inputA' channel and add as an input.
        modItem.ChannelLookup ("inputA", &chanIdx);
        chanMod.AddInput (item, chanIdx);

        // Lookup the index of the 'inputB' channel and add as an input.
        modItem.ChannelLookup ("inputB", &chanIdx);
        chanMod.AddInput (item, chanIdx);

        // Lookup the index of the 'blend' channel and add as an input.
        modItem.ChannelLookup ("blend", &chanIdx);
        chanMod.AddInput (item, chanIdx);
                
        // Lookup the index of the 'output' channel and add it as an output.
        modItem.ChannelLookup ("output", &chanIdx);
        chanMod.AddOutput (item, chanIdx);
                
        return LXe_OK;
}

        void
CLinearBlendInstance::cmod_Cleanup (
        void			*data)
{

}

        unsigned int
CLinearBlendInstance::cmod_Flags (
        ILxUnknownID		 item,
        unsigned int		 index)
{
        CLxUser_Item		 modItem (item);
        unsigned int		 chanIdx;
        
//	log.Info ("cmod_Flags Method");
        
        if (LXx_OK (modItem.ChannelLookup ("inputA", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_INPUT;
        }
        
        if (LXx_OK (modItem.ChannelLookup ("inputB", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_INPUT;
        }

        if (LXx_OK (modItem.ChannelLookup ("output", &chanIdx))) {
                if (index == chanIdx)
                        return LXfCHMOD_OUTPUT;
        }
        
        return 0;
}

        LxResult
CLinearBlendInstance::cmod_Evaluate (
        ILxUnknownID		 cmod,		// ILxChannelModifierID
        ILxUnknownID		 attr,		// ILxAttributesID
        void			*data)		
{
        CLxLoc_ChannelModifier	 chanMod (cmod);
        double			 dValA, dValB, dVal, blend;
        
//	log.Info ("cmod_Evaluate Method");
        
        chanMod.ReadInputFloat (attr, 0, &dValA);
        chanMod.ReadInputFloat (attr, 1, &dValB);
        
        // Read the blend value and clamp between zero and one.
        chanMod.ReadInputFloat (attr, 2, &blend);
        if (blend < 0.0)
                blend = 0.0;
        else if (blend > 1.0)
                blend = 1.0;
        
        dVal = dValA + blend * (dValB - dValA);
        
        chanMod.WriteOutputFloat (attr, 0, dVal);
        
        return LXe_OK;
}

// Package class

LXtTagInfoDesc	 CLinearBlendPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,	"chanModify"	},
        { LXsPKG_IS_MASK,	"."		},
        { LXsSRV_LOGSUBSYSTEM,	"cmLinearBlend"	},
        { 0 }
};

// Constructor

CLinearBlendPackage::CLinearBlendPackage ()
{
        chanmod_factory.AddInterface (new CLxIfc_PackageInstance<CLinearBlendInstance>);
        chanmod_factory.AddInterface (new CLxIfc_ChannelModItem<CLinearBlendInstance>);
}

static LXtTextValueHint hint_Blend[] = {
        0,			"%min",		// float min 0.0
        10000,			"%max",		// float max 1.0
        -1,			NULL
        };

        LxResult
CLinearBlendPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        
        ac.NewChannel ("inputA", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("inputB", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);
        
        ac.NewChannel ("blend", LXsTYPE_PERCENT);
        ac.SetDefault (0.0, 0);
        ac.SetHint (hint_Blend);
                
        ac.NewChannel ("output", LXsTYPE_FLOAT);
        ac.SetDefault (0.0, 0);

        return LXe_OK;
}

        LxResult
CLinearBlendPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return (chanmod_factory.TestInterface (guid) ? LXe_TRUE : LXe_FALSE);
}

        LxResult
CLinearBlendPackage::pkg_Attach (
        void		       **ppvObj)
{
        CLinearBlendInstance	*chanmod = chanmod_factory.Alloc (ppvObj);

        chanmod->src_pkg  = this;
        chanmod->inst_ifc = (ILxUnknownID) ppvObj[0];

        return LXe_OK;
}

        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CLinearBlendPackage>;
        srv->AddInterface (new CLxIfc_Package          <CLinearBlendPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc       <CLinearBlendPackage>);
        thisModule.AddServer ("cmLinearBlend", srv);
}

