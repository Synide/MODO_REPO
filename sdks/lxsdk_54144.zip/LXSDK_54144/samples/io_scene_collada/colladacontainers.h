/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef COLLADACONTAINERS_H
#define COLLADACONTAINERS_H

/*
 * Bring in LXtPointID.
 */
#include <lx_mesh.hpp>	

#include <map>
#include <set>
#include <string>

#include "../libcolladaio/cio_asset.h"

/*
 * Asset tags.
 */

#define LXi_TAG_AUTHOR		LXxID4('A','u','t','h')
#define LXi_TAG_COPYRIGHT	LXxID4('C','o','p','y')
#define LXi_TAG_KEYWORDS	LXxID4('K','e','y','w')
#define LXi_TAG_REVISION	LXxID4('R','e','v','i')
#define LXi_TAG_SUBJECT		LXxID4('S','u','b','j')
#define LXi_TAG_TITLE		LXxID4('T','i','t','l')

struct Asset
{
        std::string			 author;
        std::string			 copyright;

        std::string			 keywords;
        std::string			 revision;
        std::string			 subject;
        std::string			 title;

        cio::AssetElement::UpAxis	 upAxis;
};

/*
 * A map of points.
 */
typedef std::map<LXtPointID, unsigned> PointMap;

/*
 * A set of material tags.
 */
typedef std::set<std::string> MaterialSet;

/*
 * A set of image map file names.
 */
typedef std::set<std::string> ImageMapFileSet;

/*
 * A set of materials and their associated texcoord map names,
 * each stored as a standard pair.
 *
 * A material can be associated with more than one texcoord map.
 */
typedef std::set< std::pair<std::string, std::string> > PolyTagTexCoord;

/*
 * Normal vectors provide a "less-than"
 * operator for use with std::map.
 */
class Normal
{
    public:
        double		vec[3];

                bool
        operator< (const Normal &x) const
        {
                double	 d;

                if (d = vec[0] - x.vec[0]) return (d > 0.0f);
                if (d = vec[1] - x.vec[1]) return (d > 0.0f);
                if (d = vec[2] - x.vec[2]) return (d > 0.0f);
                return false;
        }
};

/*
 * A map of normals.
 */
typedef std::map<Normal, unsigned> NormalMap;

/*
 * Texture coordinates provide a "less-than"
 * operator for use with std::map.
 */
class Texcoord
{
    public:
        double		vec[2];

                bool
        operator< (const Texcoord &x) const
        {
                double	 d;

                if (d = vec[0] - x.vec[0]) return (d > 0.0);
                if (d = vec[1] - x.vec[1]) return (d > 0.0);
                return false;
        }
};

/*
 * A map of texture coordinates.
 */
typedef std::map<Texcoord, unsigned> TexcoordMap;

/*
 * Color vectors provide a "less-than"
 * operator for use with std::map.
 */
class ColorRGB
{
    public:
        double		vec[3];

                bool
        operator< (const ColorRGB &x) const
        {
                double	 d;

                if (d = vec[0] - x.vec[0]) return (d > 0.0f);
                if (d = vec[1] - x.vec[1]) return (d > 0.0f);
                if (d = vec[2] - x.vec[2]) return (d > 0.0f);
                return false;
        }
};

class ColorRGBA
{
    public:
        double		vec[4];

                bool
        operator< (const ColorRGBA &x) const
        {
                double	 d;

                if (d = vec[0] - x.vec[0]) return (d > 0.0f);
                if (d = vec[1] - x.vec[1]) return (d > 0.0f);
                if (d = vec[2] - x.vec[2]) return (d > 0.0f);
                if (d = vec[3] - x.vec[3]) return (d > 0.0f);
                return false;
        }
};

/*
 * A map of colors.
 */
typedef std::map<ColorRGB, unsigned> ColorRGBMap;
typedef std::map<ColorRGBA, unsigned> ColorRGBAMap;

/*
 * A map of weight values.
 */
typedef std::map<float, unsigned> WeightMap;

/*
 * A map of item IDs and their item indices.
 */
typedef std::map<std::string, unsigned> NodeIDIndexMap;

/*
 * A map of item indices and their item IDs.
 */
typedef std::map<unsigned, std::string> IndexNodeIDMap;

/*
 * A map of weight map indices and their values.
 */
typedef std::map<unsigned, float> IndexFloatMap;

#endif	// COLLADACONTAINERS_H

