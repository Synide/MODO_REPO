/*
 * LX preview module
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_preview_H
#define LX_preview_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxPreviewService ** ILxPreviewServiceID;
typedef struct vt_ILxPreview ** ILxPreviewID;
typedef struct vt_ILxPreviewNotifier ** ILxPreviewNotifierID;
#include <lxrender.h>



typedef struct vt_ILxPreviewService {
        ILxUnknown       iunk;
                LXxMETHOD (   LxResult,
        CreatePreview) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD (     LxResult,
        GetMeshPreview) (
                LXtObjectID               self,
                LXtObjectID               item,
                int                       width,
                int                       height,
                void                    **ppvObj);
} ILxPreviewService;
typedef struct vt_ILxPreview {
        ILxUnknown       iunk;
                LXxMETHOD (     LxResult,
        Start) (
                LXtObjectID               self);
                LXxMETHOD (     LxResult,
        Stop) (
                LXtObjectID               self);
                LXxMETHOD (     LxResult,
        Pause) (
                LXtObjectID               self);
                LXxMETHOD (     LxResult,
        Reset) (
                LXtObjectID               self);
                LXxMETHOD (     LxResult,
        SetRes) (
                LXtObjectID               self,
                int                       width,
                int                       height);
                LXxMETHOD (     LxResult,
        SetRenderTime) (
                LXtObjectID               self,
                double                    time );
                LXxMETHOD (     LxResult,
        SetQuality) (
                LXtObjectID               self,
                int                       quality,
                int                       samples);
                LXxMETHOD ( LxResult,
        SetMotionBlur) (
                LXtObjectID               self,
                int                       enable);
                LXxMETHOD (     LxResult,
        SetRenderAllOutputs) (
                LXtObjectID               self,
                int                       enable);
                LXxMETHOD (     LxResult,
        SetUseAllThreads) (
                LXtObjectID               self,
                int                       enable);
                LXxMETHOD (     LxResult,
        SetStereo) (
                LXtObjectID               self,
                int                       enable,
                int                       eye);
                LXxMETHOD (     LxResult,
        SetNotifier) (
                LXtObjectID             self,
                LXtObjectID             notifier);
                LXxMETHOD (     LxResult,
        SetAlpha) (
                LXtObjectID             self,
                int                     enable );
          LXxMETHOD (   LxResult,
        UseCameraOverride) (
                LXtObjectID             self,
                int                     useCameraOverride);
          LXxMETHOD (   LxResult,
        SetCameraOverrideTransform) (
                LXtObjectID             self,
                const LXtMatrix4 transform);
          LXxMETHOD (   LxResult,
        SetCameraOverrideFocalLength) (
                LXtObjectID     self,
                float           focalLength);
          LXxMETHOD (   LxResult,
        SetCameraOverrideApertureX) (
                LXtObjectID     self,
                float           apertureX);
          LXxMETHOD (   LxResult,
        SetCameraOverrideApertureY) (
                LXtObjectID     self,
                float           apertureY);
          LXxMETHOD (   LxResult,
        SetCameraOverrideProjectionType) (
                LXtObjectID     self,
                int             projectionType);
                LXxMETHOD (     int,
        GetResWidth) (
                LXtObjectID               self );
                LXxMETHOD (     int,
        GetResHeight) (
                LXtObjectID               self );
                LXxMETHOD (     double,
        GetCurrentTime) (
                LXtObjectID               self );
                LXxMETHOD (     LxResult,
        IsComplete) (
                LXtObjectID               self);
                LXxMETHOD (     LxResult,
        GetBuffer) (
                LXtObjectID               self,
                void                    **ppvObj);
} ILxPreview;
typedef struct vt_ILxPreviewNotifier {
        ILxUnknown       iunk;
                LXxMETHOD (     LxResult,
        Notify) (
                LXtObjectID                      self,
                const LXtRenderOutputProcess    *rndrProcess,
                LXtObjectID                      image,
                int                              completed );
} ILxPreviewNotifier;

#define LXu_PREVIEWSERVICE       "0491f901-6eee-48e4-a4d0-b2e6d10624b6"
#define LXa_PREVIEWSERVICE       "previewservice"
// [local]  ILxPreviewService
// [python] ILxPreviewService:CreatePreview     obj Preview
#define LXu_PREVIEW             "6817942a-375d-485f-b927-af93d1391d73"
#define LXa_PREVIEW             "preview"
// [local] ILxPreview
// [const] ILxPreview:Start
// [const] ILxPreview:Stop
// [const] ILxPreview:Pause
// [const] ILxPreview:Reset
// [const] ILxPreview:SetRes
// [const] ILxPreview:SetQuality
// [const] ILxPreview:SetRenderAllOutputs
// [const] ILxPreview:SetStereo
// [const] ILxPreview:IsComplete
// [const] ILxPreview:GetBuffer

// [python] ILxPreview:IsComplete               bool
// [python] ILxPreview:GetBuffer                obj Image
#define LXiPREVIEW_DRAFT_QUALITY                0
#define LXiPREVIEW_FINAL_QUALITY                1
#define LXiPREVIEW_EXTENDED_QUALITY             2
#define LXu_PREVIEWNOTIFIER             "352039c2-8b70-46db-9a83-1e05fd887fc0"
#define LXa_PREVIEWNOTIFIER             "previewnotifier"
// [local] ILxPreviewNotifier
// [export] ILxPreviewNotifier ntf

 #ifdef __cplusplus
  }
 #endif
#endif

