/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_BIND_H
#define CIO_BIND_H

#include "cio_strings.h"
#include "cio_element.h"

namespace cio {

typedef enum en_ParamType
{
        PARAM_TYPE_BOOL,
        PARAM_TYPE_INT,
        PARAM_TYPE_FLOAT,
        PARAM_TYPE_COLOR,
        PARAM_TYPE_NAME
} ParamType;

/*
 * ---------------------------------------------------------------------------
 * Element Param.
 */
class ElementParam
{
        friend class ElementParamBind;

    public:
                                 ElementParam ();
                                 ElementParam (
                                        const std::string	&parentName,
                                        const std::string	&elemName,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        ParamType		&paramType);
        virtual			~ElementParam ();

        /*
         * Return the unique parent element name.
         */
        std::string		 GetParentElementName () const;

        /*
         * Return the element name.
         */
        std::string		 GetElementName () const;

        /*
         * Return the scoped ID for the parameter.
         */
        std::string		 GetParamSID () const;

        /*
         * Return the human-readable name for the parameter.
         */
        std::string		 GetParamName () const;

        /*
         * Return the underlying data type used to store the parameter.
         */
        ParamType		 GetParamType () const;

        /*
         * Comparison operator for sorting.
         */
                bool
        operator< (const ElementParam &other) const
        {
                bool	otherLessThan;
                if (parentElementName != other.parentElementName) {
                        otherLessThan = (parentElementName > other.parentElementName);
                }
                else if (elementName != other.elementName) {
                        otherLessThan = (elementName > other.elementName);
                }
                else if (paramUniqueSID != other.paramUniqueSID) {
                        otherLessThan = (elementName > other.elementName);
                }
                else {
                        otherLessThan = false;
                }

                return otherLessThan;
        }

    protected:
        /*
         * Set the unique parent element name.
         */
        void			 SetParentElementName (
                                        const std::string &name);

        /*
         * Set the element name.
         */
        void			 SetElementName (
                                        const std::string &name);

        /*
         * Set the scoped ID for the parameter.
         */
        void			 SetParamSID (
                                        const std::string &sid);

        /*
         * Set the human-readable name for the parameter.
         */
        void			 SetParamName (
                                        const std::string &name);

        /*
         * Set the underlying data type used to store the parameter.
         */
        void			 SetParamType (ParamType type);

    private:
        std::string		 parentElementName;
        std::string		 elementName;
        std::string		 paramUniqueSID;
        std::string		 paramFriendlyName;
        ParamType		 paramVarType;
};

/*
 * ---------------------------------------------------------------------------
 * Element Param Bind.
 */
class ElementParamBind
{
    public:
                                 ElementParamBind ();
        virtual			~ElementParamBind();

        /*
         * Add an element param binding.
         */
        void			 AddElementParam (
                                        const ElementParam	&elementParam);

        /*
         * Find an element param by its parent element name and its param SID. 
         */
        bool			 FindElementParam (
                                        const std::string	&parentElementName,
                                        const std::string	&paramSID,
                                        ElementParam		&param);

        /*
         * Visit all elements and their parameters for the given parent
         * and element name.
         */
        void			 VisitElementParams (
                                        const std::string		&parentElementName,
                                        const std::string		&elementName,
                                        class ElementParamVisitor	*visitor);

        /*
         * Return the item ID for an item of a given library element name.
         */
        std::string		 GetItemID (
                                        const std::string	&libraryElementName,
                                        const std::string	&itemName);

    private:
        struct pv_ElementParamBind	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Element Param visitor.
 */

class ElementParamVisitor
{
        friend class ElementParamBind;

    public:
                                 ElementParamVisitor ();
        virtual			~ElementParamVisitor ();

        /*
         * Process an item channel. Optional override.
         */
        virtual void		 ProcessElementParam (
                                        const ElementParam	&elementParam) = 0;
};

/*
 * ---------------------------------------------------------------------------
 * Bound Element Param Value.
 */

struct BoundElementParamValue
{
                                 BoundElementParamValue ();

        void			 SetBoundElement (
                                        Element			*boundElem,
                                        const std::string	&name);

        void			 SetValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        bool			 value);

        void			 SetValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        double			 value);

        void			 SetValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        unsigned		 value);

        void			 SetValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        const std::string	&value);

        void			 SetValue (
                                        ElementXML		**paramElement,
                                        const std::string	&paramSID,
                                        const Element::ColorRGB	&value);

    private:
        class Element		*boundElement;
        std::string		 elementName;
};

} // namespace cio

#endif // CIO_BIND_H

