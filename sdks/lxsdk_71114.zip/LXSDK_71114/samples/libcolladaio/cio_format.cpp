/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_format.h"

namespace cio {

/*
 * -------------------------------------------------------------------
 * Fixed Attribute amd Element Values.
 * DO NOT MODIFY ANY VALUES BELOW THIS LINE!
 */

const char* VALUE_SCENE_IO_INTERNAL_NAME	= "COLLADA_141";
const char* VALUE_SCENE_IO_USER_NAME		= "COLLADA 1.4.1";

/*
 * The Digital Asset Exchange file extension.
 */
const char* VALUE_COLLADA_DOS_PATTERN		= "*.dae";
const char* VALUE_COLLADA_FILE_EXTENSION	= "dae";

/*
 * XML Header
 */
const char* ATTRVALUE_XMLVERSION		= "1.0";
const char* ATTRVALUE_XMLENCODING		= "utf-8";

/*
 * COLLADA element attribute values
 */
const char* ATTRVALUE_COLLADASCHEMAURL		= "http://www.collada.org/2005/11/COLLADASchema";
const char* ATTRVALUE_COLLADAVERSION		= "1.4.1";

/*
 * Untitled scene file name.
 */
const char* ATTRVALUE_DEFAULTSCENEFILENAME	= "Untitled";

/*
 * Default scene identifier.
 */
const char* ATTRVALUE_DEFAULTSCENEID		= "DefaultScene";
const char* ATTRVALUE_DEFAULTSCENEURL		= "#DefaultScene";

/*
 * Prefixes and Suffixes.
 */
const char* ATTRVALUE_ARRAYSUFFIX		= "-array";
const char* ATTRVALUE_CAMERAPREFIX		= "Camera";
const char* ATTRVALUE_CONTROLLERPREFIX		= "Controller";
const char* ATTRVALUE_CONTROLLERSUFFIX		= "Controller";
const char* ATTRVALUE_EFFECTPREFIX		= "Effect";
const char* ATTRVALUE_GEOMETRYPREFIX		= "Geometry";
const char* ATTRVALUE_IMAGEPREFIX		= "Image";
const char* ATTRVALUE_JOINTSUFFIX		= "Joints";
const char* ATTRVALUE_LIGHTPREFIX		= "Light";
const char* ATTRVALUE_MATERIALPREFIX		= "Material";
const char* ATTRVALUE_MATERIALSYMBOLPREFIX	= "Material";
const char* ATTRVALUE_NODESUFFIX		= "Node";
const char* ATTRVALUE_SAMPLERSUFFIX		= "-sampler";
const char* ATTRVALUE_SURFACESUFFIX		= "-surface";
const char* ATTRVALUE_UVSUFFIX			= "-UV";
const char* ATTRVALUE_VERTICESSUFFIX		= "-vertices";

const char* ATTRVALUE_BUMPMAP			= "-bumpMap";
const char* ATTRVALUE_DIFFUSECOLORMAP		= "-diffuseColorMap";
const char* ATTRVALUE_EMISSIONMAP		= "-emissionMap";
const char* ATTRVALUE_REFLECTIONMAP		= "-reflectionMap";
const char* ATTRVALUE_SPECULARMAP		= "-specularMap";
const char* ATTRVALUE_TRANSPARENCYMAP		= "-transparencyMap";

/*
 * Common delimiters and formatting.
 */
const char* ATTRVALUE_DASHSEPARATORSYMBOL	= "-";
const char* ATTRVALUE_DOTSEPARATORSYMBOL	= ".";
const char* ATTRVALUE_PATHSEPARATORSYMBOL	= "/";
const char* ATTRVALUE_URLSYMBOL			= "#";
const char* ATTRVALUE_SEPARATORSYMBOL		= "_";
const char* ATTRVALUE_SPACE			= " ";
const char* ATTRVALUE_FLOATARRAYTABSTOP		= "\n\t\t\t\t\t\t";
const char* ATTRVALUE_FLOATARRAYOUTERTABSTOP	= "\n\t\t\t\t\t";
const char* ATTRVALUE_MATRIXTABSTOP		= "\n\t\t\t\t";

/*
 * Preset attribute values.
 */
const char* ATTRVALUE_2D			= "2D";
const char* ATTRVALUE_A				= "A";
const char* ATTRVALUE_A_ONE			= "A_ONE";
const char* ATTRVALUE_AMBIENT			= "AMBIENT";
const char* ATTRVALUE_ANGLE			= "ANGLE";
const char* ATTRVALUE_B				= "B";
const char* ATTRVALUE_BOOL			= "bool";
const char* ATTRVALUE_COLOR			= "color";
const char* ATTRVALUE_COLORSETPREFIX		= "Color";
const char* ATTRVALUE_COMMON			= "common";
const char* ATTRVALUE_DIFFUSE			= "DIFFUSE";
const char* ATTRVALUE_FLOAT			= "float";
const char* ATTRVALUE_FLOAT4X4			= "float4x4";
const char* ATTRVALUE_G				= "G";
const char* ATTRVALUE_INT			= "int";
const char* ATTRVALUE_JOINT			= "JOINT";
const char* ATTRVALUE_MATRIX_SID		= "transform";
const char* ATTRVALUE_NAME			= "Name";
const char* ATTRVALUE_NODE			= "NODE";
const char* ATTRVALUE_NORMAL			= "NORMAL";
const char* ATTRVALUE_R				= "R";
const char* ATTRVALUE_RGB_ZERO			= "RGB_ZERO";
const char* ATTRVALUE_ROTATE			= "rotate";
const char* ATTRVALUE_ROTATEX			= "rotateX";
const char* ATTRVALUE_ROTATEY			= "rotateY";
const char* ATTRVALUE_ROTATEZ			= "rotateZ";
const char* ATTRVALUE_S				= "S";
const char* ATTRVALUE_SCALE			= "scale";
const char* ATTRVALUE_SHININESS			= "SHININESS";
const char* ATTRVALUE_SLOPE			= "slope";
const char* ATTRVALUE_SPECULAR			= "SPECULAR";
const char* ATTRVALUE_T				= "T";
const char* ATTRVALUE_TEXCOORD			= "TEXCOORD";
const char* ATTRVALUE_TEXCOORDSET0		= "TEX0";
const char* ATTRVALUE_TEXCOORDSET1		= "TEX1";
const char* ATTRVALUE_TEXCOORDSETPREFIX		= "TEX";
const char* ATTRVALUE_TIME			= "TIME";
const char* ATTRVALUE_TRANSLATE			= "translate";
const char* ATTRVALUE_VERTEX			= "VERTEX";
const char* ATTRVALUE_WEIGHT			= "weight";
const char* ATTRVALUE_WEIGHTSETPREFIX		= "Weight";
const char* ATTRVALUE_X				= "X";
const char* ATTRVALUE_Y				= "Y";
const char* ATTRVALUE_Z				= "Z";

/*
 * Preset attribute source name values.
 */
const char* ATTRVALUE_BROKEN_OUTPUTS_SOURCE_NAME		= "broken_outputs";
const char* ATTRVALUE_BROKEN_OUTPUT_TIMES_SOURCE_NAME		= "broken_output_times";
const char* ATTRVALUE_BROKEN_SLOPES_SOURCE_NAME			= "broken_slopes";
const char* ATTRVALUE_BROKEN_WEIGHTS_SOURCE_NAME		= "broken_weights";
const char* ATTRVALUE_INPUT_SOURCE_NAME				= "input";
const char* ATTRVALUE_INTANGENTS_SOURCE_NAME			= "intangents";
const char* ATTRVALUE_IN_TANGENT_OUTPUT_SOURCE_NAME		= "in_tangent_output";
const char* ATTRVALUE_IN_TANGENT_SLOPEWEIGHTS_SOURCE_NAME	= "in_tangent_slopeweights";
const char* ATTRVALUE_INTERPOLATIONS_SOURCE_NAME		= "interpolations";
const char* ATTRVALUE_JOINTS_SOURCE_NAME			= "joints";
const char* ATTRVALUE_MATRICES_SOURCE_NAME			= "matrices";
const char* ATTRVALUE_NORMALS_SOURCE_NAME			= "normals";
const char* ATTRVALUE_OUTPUT_SOURCE_NAME			= "output";
const char* ATTRVALUE_OUTTANGENTS_SOURCE_NAME			= "outtangents";
const char* ATTRVALUE_OUT_TANGENT_OUTPUT_SOURCE_NAME		= "out_tangent_output";
const char* ATTRVALUE_OUTTANGENT_SLOPEWEIGHTS_SOURCE_NAME	= "out_tangent_slopeweights";
const char* ATTRVALUE_POSITIONS_SOURCE_NAME			= "positions";
const char* ATTRVALUE_WEIGHTS_SOURCE_NAME			= "weights";

/*
 * Semantic identifiers for source inputs.
 */
const char* ATTRVALUE_BROKEN_OUTPUTS_INPUT_SEMANTIC		= "BROKEN_OUTPUTS";	// modo501
const char* ATTRVALUE_BROKEN_OUTPUT_TIMES_INPUT_SEMANTIC	= "BROKEN_OUTPUT_TIMES";// modo501
const char* ATTRVALUE_BROKEN_SLOPES_INPUT_SEMANTIC		= "BROKEN_SLOPES";	// modo501
const char* ATTRVALUE_BROKEN_WEIGHTS_INPUT_SEMANTIC		= "BROKEN_WEIGHTS";	// modo501
const char* ATTRVALUE_COLOR_INPUT_SEMANTIC			= "COLOR";
const char* ATTRVALUE_TIME_INPUT_SEMANTIC			= "INPUT";
const char* ATTRVALUE_IN_TANGENT_INPUT_SEMANTIC			= "IN_TANGENT";
const char* ATTRVALUE_IN_TANGENT_OUTPUT_INPUT_SEMANTIC		= "IN_TANGENT_OUTPUT";		// modo501
const char* ATTRVALUE_IN_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC	= "IN_TANGENT_SLOPEWEIGHT";	// modo501
const char* ATTRVALUE_INTERPOLATION_INPUT_SEMANTIC		= "INTERPOLATION";
const char* ATTRVALUE_INV_BIND_MATRIX_SEMANTIC			= "INV_BIND_MATRIX";
const char* ATTRVALUE_JOINT_INPUT_SEMANTIC			= "JOINT";
const char* ATTRVALUE_OUTPUT_INPUT_SEMANTIC			= "OUTPUT";
const char* ATTRVALUE_OUT_TANGENT_INPUT_SEMANTIC		= "OUT_TANGENT";
const char* ATTRVALUE_OUT_TANGENT_OUTPUT_INPUT_SEMANTIC		= "OUT_TANGENT_OUTPUT";		// modo501
const char* ATTRVALUE_OUT_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC	= "OUT_TANGENT_SLOPEWEIGHT";	// modo501
const char* ATTRVALUE_POSITION_INPUT_SEMANTIC			= "POSITION";
const char* ATTRVALUE_WEIGHT_INPUT_SEMANTIC			= "WEIGHT";

/*
 * Other preset values.
 */
const char* VALUE_BEZIER			= "BEZIER";
const char* VALUE_LINEAR			= "LINEAR";
const char* VALUE_LINEARMIPMAPLINEAR		= "LINEAR_MIPMAP_LINEAR";
const char* VALUE_STEP				= "STEP";

const char* VALUE_ROTATE_X_AXIS			= "1 0 0 ";
const char* VALUE_ROTATE_Y_AXIS			= "0 1 0 ";
const char* VALUE_ROTATE_Z_AXIS			= "0 0 1 ";

} // namespace cio

