/*
 * LX vpapi module
 *
 * Copyright (c) 2008-2014 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_vpapi_H
#define LX_vpapi_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxView3D ** ILxView3DID;
typedef struct vt_ILxView3DportService ** ILxView3DportServiceID;
#include <lxvalue.h>
#include <lxvector.h>
#include <lxtool.h>
#include <lxvp.h>
#include <lxhandles.h>



typedef struct vt_ILxView3D {
        ILxUnknown       iunk;
                LXxMETHOD(  LXtID4,
        Space) (
                LXtObjectID              self);


                LXxMETHOD(  int,
        Axis) (
                LXtObjectID              self,
                int                     *cam,
                LXtVector                axis);

                LXxMETHOD(  LxResult,
        Bounds) (
                LXtObjectID              self,
                int                     *x,
                int                     *y,
                int                     *w,
                int                     *h);
                LXxMETHOD(  int,
        Style) (
                LXtObjectID              self,
                int                      option);
                LXxMETHOD(  double,
        PixelSize) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        Center) (
                LXtObjectID              self,
                LXtVector                center);

                LXxMETHOD(  double,
        EyeVector) (
                LXtObjectID              self,
                LXtVector                pos,
                LXtVector                dir);

                LXxMETHOD(  LxResult,
        Matrix) (
                LXtObjectID              self,
                LXtMatrix                mat,
                int                      inverse);

                LXxMETHOD(  LxResult,
        Angles) (
                LXtObjectID              self,
                LXtVector                hpb);

                LXxMETHOD(  int,
        WorkPlane) (
                LXtObjectID              self,
                LXtVector                center);

                LXxMETHOD(  LxResult,
        To3D) (
                LXtObjectID              self,
                float                    x,
                float                    y,
                LXtVector                pos,
                int                      flags);

                LXxMETHOD(  LxResult,
        To3DHit) (
                LXtObjectID              self,
                float                    x,
                float                    y,
                LXtVector                pos,
                LXtVector                nrm);

                LXxMETHOD(  LxResult,
        Backdrop) (
                LXtObjectID              self,
                void                   **item);

                LXxMETHOD(  const char*,
        BackdropName) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        BackdropPlace) (
                LXtObjectID              self,
                double                  *cx,
                double                  *cy,
                double                  *w,
                double                  *h);

                LXxMETHOD(  int,
        BackdropAspect) (
                LXtObjectID              self,
                double                  *asp);

                LXxMETHOD(  int,
        BackdropOrient) (
                LXtObjectID              self,
                double                  *ang);

                LXxMETHOD(  int,
        BackdropLook) (
                LXtObjectID              self,
                double                  *brit,
                double                  *cont,
                double                  *trns);

                LXxMETHOD(  int,
        BackdropRender) (
                LXtObjectID              self,
                int                     *resolution,
                int                     *blend);

                LXxMETHOD(  int,
        HitElement) (
                LXtObjectID              self,
                LXtID4                   type,
                float                    x,
                float                    y,
                void                   **list);
                LXxMETHOD(  double,
        GridSize) (
                LXtObjectID              self);
} ILxView3D;
typedef struct vt_ILxView3DportService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD(  int,
        Count) (
                LXtObjectID              self);

                LXxMETHOD(  int,
        Current) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        View) (
                LXtObjectID              self,
                int                      index,
                void                   **ppvObj);

                LXxMETHOD(  int,
        Mouse) (
                LXtObjectID              self,
                int                     *x,
                int                     *y);

} ILxView3DportService;

#define LXu_VIEW3D              "02DBFE75-C1AB-4E23-A4C9-90508C7CD7C3"
#define LXa_VIEW3D              "viewport3d"
// [local] ILxView3D
// [export] ILxView3D
#define LXi_VPSPACE_MODEL               LXxID4('M','O','3','D')
#define LXi_VPSPACE_TEXTURE             LXxID4('U','V','2','D')
#define LXi_VPSPACE_WORLD               LXxID4('W','O','3','D')
#define LXi_VPSPACE_PREVIEW             LXxID4('P','R','E','V')
#define LXi_VPSPACE_MODEL2D             LXxID4('M','O','2','D')
#define LXi_VPSPACE_GRAPH               LXxID4('V','P','G','E')
#define LXi_VPSPACE_SCHEMATIC           LXxID4('S','C','H','M')
#define LXi_VP_AXIS_X            0
#define LXi_VP_AXIS_Y            1
#define LXi_VP_AXIS_Z            2
#define LXi_VP_AXIS_PERSP       -1
#define LXi_VP_AXIS_UV           LXi_VP_AXIS_Z

#define LXi_VP_CAM_LEFT         0
#define LXi_VP_CAM_RIGHT        1
#define LXi_VP_CAM_TOP          2
#define LXi_VP_CAM_BOTTOM       3
#define LXi_VP_CAM_FRONT        4
#define LXi_VP_CAM_BACK         5
#define LXi_VP_CAM_PERSP        6
enum {
        LXi_VPSTYLE_SHADE,
        LXi_VPSTYLE_WIRE,
        LXi_VPSTYLE_VCOLOR,
        LXi_VPSTYLE_SMOOTH,
        LXi_VPSTYLE_BACK,
        LXi_VPSTYLE_VERTS,
        LXi_VPSTYLE_CAGES,
        LXi_VPSTYLE_GUIDES,
        LXi_VPSTYLE_GRID,
        LXi_VPSTYLE_WPLANE,
        LXi_VPSTYLE_IMAGE,
        LXi_VPSTYLE_SELECT,
        LXi_VPSTYLE_SELNORM,
        LXi_VPSTYLE_SELFILL,
        LXi_VPSTYLE_SELBORD,
        LXi_VPSTYLE_SELROLL,
        LXi_VPSTYLE_OVERLAY,
        LXi_VPSTYLE_NULL,
};

        #define LXi_VPOPT_OFF                   0
        #define LXi_VPOPT_ON                    1

        #define LXi_VPOPT_SHADE_WIRE            0
        #define LXi_VPOPT_SHADE_SKCH            1
        #define LXi_VPOPT_SHADE_VCLR            2
        #define LXi_VPOPT_SHADE_SHAD            3
        #define LXi_VPOPT_SHADE_TEXT            4
        #define LXi_VPOPT_SHADE_REFL            5
        #define LXi_VPOPT_SHADE_PRG1            6
        #define LXi_VPOPT_SHADE_PRG2            7

        #define LXi_VPOPT_WIRE_NONE             0
        #define LXi_VPOPT_WIRE_COLR             1
        #define LXi_VPOPT_WIRE_UNIF             2

        #define LXi_VPOPT_VCLR_SEL              0
        #define LXi_VPOPT_VCLR_WGT              1
        #define LXi_VPOPT_VCLR_RGB              2

        #define LXi_VPOPT_BACK_WIRE             0
        #define LXi_VPOPT_BACK_FLAT             1
        #define LXi_VPOPT_BACK_ACTV             2
#define LXi_VPTO3D_SNAP         1
#define LXi_VPTO3D_WORK         2
#define LXi_VPHIT_VERT          LXxID4('V','E','R','T')
#define LXi_VPHIT_EDGE          LXxID4('E','D','G','E')
#define LXi_VPHIT_POLY          LXxID4('P','O','L','Y')
#define LXi_VPHIT_ITEM          LXxID4('I','T','E','M')
#define LXu_VIEW3DPORTSERVICE   "D84FF812-E4E9-41DC-B82F-B550ACF2E40A"
#define LXa_VIEW3DPORTSERVICE   "view3dservice"

 #ifdef __cplusplus
  }
 #endif
#endif

