/*
* RenderCache writer
*
* Copyright (c) 2008-2018 The Foundry Group LLC
* 
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"),
* to deal in the Software without restriction, including without limitation
* the rights to use, copy, modify, merge, publish, distribute, sublicense,
* and/or sell copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.   Except as contained
* in this notice, the name(s) of the above copyright holders shall not be
* used in advertising or otherwise to promote the sale, use or other dealings
* in this Software without prior written authorization.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
*
* Simple ASCII writer for MODO render cache
*
*/

#include "mrcwriter.h"


//=============================================================================
//=============================================================================
MrcWriter::MrcWriter ()
        : m_depth (0)
{
}

//=============================================================================
//=============================================================================
MrcWriter::~MrcWriter ()
{
        Close();
}

//=============================================================================
//=============================================================================
bool MrcWriter::Open (const char* filename)
{
        m_depth = 0;
        m_out.open (filename, std::ios_base::out);

        return m_out.is_open();
}

//=============================================================================
//=============================================================================
void MrcWriter::Close ()
{
        m_out.close ();
        m_depth = 0;
}

//=============================================================================
//=============================================================================
MrcWriter& MrcWriter::BlockBegin (const char* blockName)
{
        Ident();
        m_out << blockName << std::endl;
        Ident();
        m_out << '{' << std::endl;
        ++m_depth;

        return *this;
}

//=============================================================================
//=============================================================================
MrcWriter& MrcWriter::WriteParam (const char* name, const char* s)
{
        Ident ();
        m_out << name << " : " << "\"" << s << "\"" << std::endl;

        return *this;
}

//=============================================================================
//=============================================================================
MrcWriter& MrcWriter::WriteParam (const char* name, const std::string& s)
{
        Ident ();
        m_out << name << " : " << "\"" << s << "\"" << std::endl;

        return *this;
}

//=============================================================================
//=============================================================================
MrcWriter& MrcWriter::BlockEnd ()
{
        --m_depth;

        // TODO: report error
        if (m_depth < 0)
                m_depth = 0;

        Ident ();
        m_out << '}' << std::endl;

        return *this;
}

//=============================================================================
//=============================================================================
MrcWriter& MrcWriter::Separator ()
{
        m_out << std::endl;

        return *this;
}

//=============================================================================
//=============================================================================
void MrcWriter::Ident ()
{
        for (int c = 0; c < m_depth; ++c)
                m_out << "    ";
}


//=============================================================================
//=============================================================================
MrcWriter::BlockScope::BlockScope (MrcWriter& writer)
        : m_writer(writer)
{
}

//=============================================================================
//=============================================================================
MrcWriter::BlockScope::~BlockScope ()
{
        m_writer.BlockEnd ();
}

