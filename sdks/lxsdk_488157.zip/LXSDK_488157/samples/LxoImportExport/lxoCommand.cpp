/*
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * Build command stream for modo operations/rendering
 */

#include <fcntl.h>
#include <io.h>
#include <direct.h>
#include <process.h>
#include <signal.h>
#include <assert.h>
#include <sys/stat.h>

#include <lxio.h>
#include "lxoChunks.hpp"
#include "lxoCommand.hpp"

#pragma comment(lib, "ws2_32")

enum 
    {
    MSG_BUFFER_SIZE     = 4096,

    SOCKET_DefaultPort  = 12356,
    SOCKET_DefaultIP    = 0,        // local host
    };

static const char       SOCKET_DefaultPipe[] = "\\\\.\\pipe\\modoCommandPipe";

#define STRING_MODO_ARGS_DEBUG          " -debug -dboff:ckpt -dbon:enableTelnetLogging -dbon:enableConsoleLogging -dbon:consoleToDebugLog -dblog:c:/dblog.txt "
#define STRING_MODO_ARGS_PIPE           " -telnet:pipe@%s "
#define STRING_MODO_ARGS_TELNET         " -telnet:raw@%d "
#define STRING_MODO_ARGS_IrrCacheFile   " arg0 -dbon:icpf"

#define MODO_CHAR_PROMPT                '>'
#define MODO_CHAR_SUCCESS               '+'
#define MODO_CHAR_ERROR                 '-'
#define MODO_CHAR_QUERY                 ':'
#define MODO_CHAR_COMMENT               '#'
#define MODO_CHAR_LOG                   '!'
#define MODO_CHAR_SYSTEM                '@'

/*------------------------------- Luxology LLC --------------------------- 08/09
 * Instantiate the static members of the class
 *----------------------------------------------------------------------------*/
#define CMD_DEFAULT_POLYRENDERID        "polyRender001"
#define CMD_SELECT_POLYSUBITEM          "select.subItem %s"
#define CMD_SELECT_POLYNONE             "textureLayer;locator;render;environment;mediaClip"
#define CMD_SELECT_POLYALL              "textureLayer;txtrLocator;render;environment;light;camera;mediaClip"
#define CMD_PREF_SELECT_RENDER          "pref.select render set\n"
#define CMD_PREF_VALUE                  "pref.value"

char const  LxoCommand::CmdSetGeomCache_I64[]       = CMD_PREF_SELECT_RENDER CMD_PREF_VALUE " render.cacheSize %I64u\n";
char const  LxoCommand::CmdSetThreadsAuto_I[]       = CMD_PREF_SELECT_RENDER CMD_PREF_VALUE " render.autoThreads %d\n";
char const  LxoCommand::CmdSetThreads_I[]           = CMD_PREF_SELECT_RENDER CMD_PREF_VALUE " render.numThreads %d\n";

char const  LxoCommand::CmdSelectRenderSub_S[]      = CMD_SELECT_POLYSUBITEM " set " CMD_SELECT_POLYALL  "\n";
char const  LxoCommand::CmdSelectNone_SS[]          = CMD_SELECT_POLYSUBITEM " set " CMD_SELECT_POLYNONE "\n" CMD_SELECT_POLYSUBITEM " remove " CMD_SELECT_POLYNONE "\n";

char const  LxoCommand::CmdSetChannelValue_SSS[]    = "select.channel {%s:%s} set\nchannel.value %s\n";

char const  LxoCommand::CmdAddPlugin_S[]            = "plugin.add \"%s\"\n";
char const  LxoCommand::CmdSceneOpen_S[]            = "!scene.closeAll\nscene.open \"%s\"\n";
char const  LxoCommand::CmdItemChannel_SS[]         = "item.channel %s \"%s\"\n";
char const  LxoCommand::CmdResolution_II[]          = "render.res 0 %d\nrender.res 1 %d\n";
char const  LxoCommand::CmdRenderToFile_SSS[]       = "render \"%s\" \"%s\"%s\n";
char const  LxoCommand::CmdRenderOutAlpha[]         = "shader.create renderOutput\nshader.setEffect shade.alpha\nitem.name \"" LXs_OUTPUT_NAME_ALPHA "\"\n";
char const  LxoCommand::CmdCalcIrradiance[]         = "render options:4\n";
char const  LxoCommand::CmdBucketDir_S[]            = "pref.value render.bucketDir \"%s\"\n";
char const  LxoCommand::CmdSubitemCamera_S[]        = "select.subItem {%s} set mesh;camera\n";

char const  LxoCommand::CmdQuitOnDisconnect_I[]     = "telnet.quitOnDisconnect %d\n";
char const  LxoCommand::CmdExitModo[]               = "!scene.closeAll\napp.quit\n";
char const  LxoCommand::CmdMacroHeader[]            = "#LXMacro#\n";
char const  LxoCommand::CmdExecuteMacro[]           = "@%s\n";

char const  LxoCommand::ArgIrradianceSaveEnable[]   = "irrSEnable";
char const  LxoCommand::ArgIrradianceLoadEnable[]   = "irrLEnable";
char const  LxoCommand::ArgIrradianceSaveName[]     = "polyRender$irrSName";
char const  LxoCommand::ArgIrradianceLoadName[]     = "polyRender$irrLName";
char const  LxoCommand::ArgBucketWrite[]            = "bktWrite";

bool            LxoManager::m_abortFound    = false;
LxoListener*    LxoManager::m_listener      = NULL;

/*------------------------------- Luxology LLC --------------------------- 08/09
 * Initialize command structures
 *----------------------------------------------------------------------------*/
LxoCommand::LxoCommand (const char* outputFile, const char* outputType, const char* polyRenderId)
    {
    m_macroHeaderPresent    = false;

    SetPolyRenderId (polyRenderId ? polyRenderId : CMD_DEFAULT_POLYRENDERID);
    SetOutputFile (outputFile, outputType);
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * Set target output file & type. If type NULL, leave unchanged.
 *----------------------------------------------------------------------------*/
    void
LxoCommand::SetOutputFile (const char* outputFile, const char* outputType)
    {
    strcpy (m_outputFile, outputFile);
    if (outputType)
        strcpy (m_outputType, outputType);
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * write current command list to file for debugging and reuse
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoCommand::WriteCommandsToFile (char const* fileName)
    {
    FILE*   fp = fopen (fileName, "w");
    if (NULL == fp)
        return LXe_IO_ERROR;

    if (! m_macroHeaderPresent)
        fwrite (CmdMacroHeader, 1, sizeof CmdMacroHeader - 1, fp);      // for static strings, strlen == sizeof-1

    fwrite (m_cmdList.c_str (), 1, m_cmdList.size (), fp);
    fclose (fp);

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Read command list from file 
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoCommand::ReadCommandsFromFile (char const* fileName)
    {
    m_cmdList.clear ();
    m_macroHeaderPresent = false;

    struct _stati64     fileInfo;

    if (-1 == _stati64 (fileName, &fileInfo))
        return LXe_IO_ERROR;

    LxULong     fileSize = (LxULong)fileInfo.st_size;
    char*       fileBuffer = (char*)alloca (fileSize + 1);

    if (NULL == fileBuffer)
        return LXe_OUTOFMEMORY;

    int     fHandle = _open (fileName, _O_RDONLY);
    if (-1 == fHandle)
        return LXe_IO_ERROR;

    // try to read all the bytes from the file, translating LF/CR's to \n's
    LxULong     bytesRead = _read (fHandle, fileBuffer, fileSize);
    _close (fHandle);

    if (bytesRead <= 0)
        return LXe_IO_ERROR;

    m_macroHeaderPresent = (0 == strncmp (fileBuffer, CmdMacroHeader, sizeof CmdMacroHeader - 1));

    fileBuffer[bytesRead] = '\0';       // null terminate the buffer that was actually read
    m_cmdList.append (fileBuffer);

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Send commands to modo process
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoCommand::WriteCommandsToModo (LxoManager* mgr)
    {
    char    tempFile[LXMax_FileLength];;

    if (0 == GetTempFileName (mgr->GetWorkDir (), "LXM", 0, tempFile))
        return LXe_IO_ERROR;

    // write the command buffer to a macro file, then queue a command to execute the macro
    WriteCommandsToFile (tempFile);
    mgr->AddTempFile (tempFile);

    char    strBuffer[MSG_BUFFER_SIZE];
    int     bytesToWrite = sprintf (strBuffer, CmdExecuteMacro, tempFile);

    if (LXe_OK != mgr->WriteToModo (strBuffer, bytesToWrite))
        return LXe_IO_ERROR;

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * send "Exit" command to modo
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoCommand::ExitModo (LxoManager* mgr)
    {
    DWORD       bytesToWrite = sizeof CmdExitModo - 1;          // for static strings, strlen == sizeof-1

    if (LXe_OK != mgr->WriteToModo (CmdExitModo, bytesToWrite))
        return LXe_IO_ERROR;

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Send a generic command, with a combination of args.
 *
 *----------------------------------------------------------------------------*/
    void
LxoCommand::AddCommand (char const *cmdFormatStr)
    {
    m_cmdList.append (cmdFormatStr);
    }

    void
LxoCommand::AddCommand (char const *cmdFormatStr, char const *arg)
    {
    char    strBuffer[MSG_BUFFER_SIZE];

    sprintf (strBuffer, cmdFormatStr, arg);
    m_cmdList.append (strBuffer);
    }

    void
LxoCommand::AddCommand (char const *cmdFormatStr, char const *arg1, char const *arg2)
    {
    char    strBuffer[MSG_BUFFER_SIZE];

    sprintf (strBuffer, cmdFormatStr, arg1, arg2);
    m_cmdList.append (strBuffer);
    }

    void
LxoCommand::AddCommand (char const *cmdFormatStr, char const *arg1, char const *arg2, char const *arg3)
    {
    char    strBuffer[MSG_BUFFER_SIZE];

    sprintf (strBuffer, cmdFormatStr, arg1, arg2, arg3);
    m_cmdList.append (strBuffer);
    }

    void
LxoCommand::AddCommand (char const *cmdFormatStr, __int64 arg)
    {
    char    strBuffer[MSG_BUFFER_SIZE];

    sprintf (strBuffer, cmdFormatStr, arg);
    m_cmdList.append (strBuffer);
    }

    void
LxoCommand::AddCommand (char const *cmdFormatStr, int arg)
    {
    char    strBuffer[MSG_BUFFER_SIZE];

    sprintf (strBuffer, cmdFormatStr, arg);
    m_cmdList.append (strBuffer);
    }

    void
LxoCommand::AddCommand (char const *cmdFormatStr, int arg1, int arg2)
    {
    char    strBuffer[MSG_BUFFER_SIZE];

    sprintf (strBuffer, cmdFormatStr, arg1, arg2);
    m_cmdList.append (strBuffer);
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Send a command to select a channel and set its value by string, bool or float
 *
 *----------------------------------------------------------------------------*/
    void
LxoCommand::SetChannelValue (char const *channel, char const *subChannel, char const *valueString)
    {
    AddCommand (CmdSetChannelValue_SSS, channel, subChannel, valueString);
    }

    void
LxoCommand::SetChannelValue (char const *channel, char const *subChannel, bool value)
    {
    SetChannelValue (channel, subChannel, value ? "1" : "0");
    }

    void
LxoCommand::SetChannelValue (char const *channel, char const *subChannel, int value)
    {
    char    valStr[50];

    sprintf (valStr, "%d", value);
    SetChannelValue (channel, subChannel, valStr);
    }

    void
LxoCommand::SetChannelValue (char const *channel, char const *subChannel, double value)
    {
    char    valStr[50];

    sprintf (valStr, "%f", value);
    SetChannelValue (channel, subChannel, valStr);
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Send command to or set up for save or load of an irradiance file
 *
 *----------------------------------------------------------------------------*/
    void
LxoCommand::IrradianceFileIO (const char* filePath, int ioMode)
    {
    SetChannelValue (m_polyRenderID, LXIrradianceCacheSave == ioMode ? ArgIrradianceSaveEnable : ArgIrradianceLoadEnable, true);
    AddCommand (CmdSelectRenderSub_S, m_polyRenderID);
    AddCommand (CmdItemChannel_SS, LXIrradianceCacheSave == ioMode ? ArgIrradianceSaveName : ArgIrradianceLoadName, filePath);
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Send commands to update the irradiance cache and save to file.  Alternate
 * bucket dir is used since this is often used for tiled images, where the
 * irrdiance cache is bigger than any individual tile.
 *
 *----------------------------------------------------------------------------*/
    void
LxoCommand::UpdateIrradianceFile (const char* filePath, const char* altBucketDir)
    {
    IrradianceFileSave (filePath);                                  // define the file to save the irradiance cache into
    SetBucketDir (altBucketDir);                                    // set up & enable the alternate bucket directory
    AddCommand (CmdCalcIrradiance);                                 // compute any additional irradiance cache data
    SetBucketDir (NULL);                                            // disable the bucket writes
    IrradianceSaveDisable ();                                       // prevent additional writes to irradiance cache file
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * Send commands to set global rendering preferences
 *----------------------------------------------------------------------------*/
    void
LxoCommand::SetGlobalPrefs (LxGlobalRenderPrefs& prefs)
    {
    AddCommand (CmdQuitOnDisconnect_I, prefs.m_quitOnError);
    AddCommand (CmdSetGeomCache_I64, (__int64)prefs.m_geomCacheMb * (1024L * 1024L));

    AddCommand (CmdSetThreadsAuto_I, LXThreads_UseDefault == prefs.m_nThreads);

    if (LXThreads_UseDefault != prefs.m_nThreads)
        AddCommand (CmdSetThreads_I, prefs.m_nThreads);

    if (prefs.m_pluginFile && prefs.m_pluginFile[0])
        AddCommand (CmdAddPlugin_S, prefs.m_pluginFile);
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * set folder for writing bucket files & enable writes, of disable if NULL
 *----------------------------------------------------------------------------*/
    void
LxoCommand::SetBucketDir (const char* bucketDir)
    {
    if (bucketDir)
        AddCommand (CmdBucketDir_S, bucketDir);

    SetChannelValue (m_polyRenderID, "bktWrite", NULL != bucketDir);
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * set folder for writing bucket files and then start the rendering.
 *----------------------------------------------------------------------------*/
    void
LxoCommand::RenderToFile (const char* bucketDir, bool retainCache)
    {
    SetBucketDir (bucketDir);           // set up & enable the bucket directory

    AddCommand (CmdRenderToFile_SSS, m_outputFile, m_outputType, retainCache ? " options:8" : "");
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Send a command to upadte the camera parameters, and optionally the
 * view range (for tiled renderings).
 *
 *----------------------------------------------------------------------------*/
    void
LxoCommand::SetCamera (LXtCamera& camera, LxRange* range)
    {
    m_cmdList.reserve (m_cmdList.size () + 2048);           // save some performance and reserve he space first

    AddCommand (CmdSubitemCamera_S,     LXs_DEFAULT_CAMERA_NAME);

    SetChannelValue (LXs_DEFAULT_CAMERA_TRANS,  "pos.X",     camera.position[0]);
    SetChannelValue (LXs_DEFAULT_CAMERA_TRANS,  "pos.Y",     camera.position[1]);
    SetChannelValue (LXs_DEFAULT_CAMERA_TRANS,  "pos.Z",     camera.position[2]);

    SetChannelValue (LXs_DEFAULT_CAMERA_ROT,    "rot.X",     camera.rotation[0] * s_radsToDegrees);
    SetChannelValue (LXs_DEFAULT_CAMERA_ROT,    "rot.Y",     camera.rotation[1] * s_radsToDegrees);
    SetChannelValue (LXs_DEFAULT_CAMERA_ROT,    "rot.Z",     camera.rotation[2] * s_radsToDegrees);

    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "apertureX", camera.filmWidth);
    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "apertureY", camera.filmHeight);
    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "offsetX",   camera.offset[0]);
    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "offsetY",   camera.offset[1]);

    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "projType",  camera.projectMode);
    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "focalLen",  camera.focalLength);
    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "focusDist", camera.focalDistance);
    SetChannelValue (LXs_DEFAULT_CAMERA_NAME,   "fStop",     camera.fstop);

    if (range)
        {
        SetChannelValue (m_polyRenderID, "region", true);
        SetChannelValue (m_polyRenderID, "regX0", range->min[0]);
        SetChannelValue (m_polyRenderID, "regX1", range->min[1]);
        SetChannelValue (m_polyRenderID, "regY0", range->max[0]);
        SetChannelValue (m_polyRenderID, "regY1", range->max[1]);
        }
    }

/*------------------------------- Luxology LLC --------------------------- 09/09
 * initialize a listener
 *----------------------------------------------------------------------------*/
LxoListener::LxoListener ()
    {
    m_abortFound = false;

    // create a semaphore with 1 lock, with default security
    m_result = NULL == (m_isListening = CreateSemaphore (NULL, 1, 1, NULL)) ? LXe_FAILED : LXe_OK;
    }

LxoListener::~LxoListener ()
    {
    if (m_isListening)
        CloseHandle (m_isListening);
    }

/*------------------------------- Luxology LLC --------------------------- 09/09
 * create a listener thread
 *----------------------------------------------------------------------------*/
    LxResult
LxoListener::WaitForTask (bool lockForNext)
    {
    if (NULL == m_isListening)      // semaphore creation failed
        return LXe_FAILED;

    if (LXe_OK != m_result)         // handle asynnchronous errors
        return m_result;

    // wait for the semaphore to be released, and lock it by decrementing the count by 1

    while (WAIT_OBJECT_0 != WaitForSingleObject (m_isListening, 1000))
        if (m_abortFound)
            return LXe_ABORT;

    if (! lockForNext && 0 == ReleaseSemaphore (m_isListening, 1, NULL))     // release the semaphore just locked
        return LXe_FAILED;

    return m_result;
    }

/*------------------------------- Luxology LLC --------------------------- 09/09
 * create a listener thread
 *----------------------------------------------------------------------------*/
    LxResult
LxoListener::BeginListening (LxoManager* mgr)
    {
    m_mgr = mgr;

    // if there's a job running, wait for it to finish, and lock the semaphore for the next run
    if (LXe_OK != (m_result = WaitForTask (true)))
        return m_result;

    // spawn a thread using a STATIC function (required for AfxBeginThread), but pass
    // 'this' into the threaded function so it can call the virtual 'Listen' method.

    return m_result = NULL == CreateThread (NULL, 0, (LPTHREAD_START_ROUTINE)ListenerThread, this, 0, NULL) ? LXe_FAILED : LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 09/09
 *
 * Call the actual 'Listen' method of the calling class.  The Listen method
 * may be overriden for custom actions.
 *
 *----------------------------------------------------------------------------*/
    LxULong
LxoListener::ListenerThread (void* listenerP)
    {
    LxoListener*    thisListenerP = (LxoListener*)listenerP;

    return thisListenerP->Listen ();
    }

/*------------------------------- Luxology LLC --------------------------- 09/09
 * Monitor the progress of the job
 *----------------------------------------------------------------------------*/
    LxResult
LxoListener::Listen ()
    {
    m_result = m_cmdsToWaitFor > 0 ? m_mgr->WaitForResult (m_cmdsToWaitFor) : m_mgr->WaitForModoToExit ();

    if (0 == ReleaseSemaphore (m_isListening, 1, NULL))     // release one iteration of the semaphore
        return LXe_FAILED;

    return m_result;
    }

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * close connection
 *
 *----------------------------------------------------------------------------*/
LxoPreviewer::~LxoPreviewer ()
{
    closesocket (m_socket);
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Setup and open the connection
 *
 *----------------------------------------------------------------------------*/
LxoPreviewer::LxoPreviewer (char const* pipe, int ipAddr, int port)
{
    pipe && pipe[0] ? PipePreviewer (pipe) : SocketPreviewer (ipAddr, port);
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Setup and open the socket
 *
 *----------------------------------------------------------------------------*/
    void
LxoPreviewer::SocketPreviewer (int ipAddr, int port)
{
    SOCKADDR_IN         addr;

    addr.sin_family      = AF_INET;
    addr.sin_port        = htons (port);
    addr.sin_addr.s_addr = ipAddr;

    m_pipeH = INVALID_HANDLE_VALUE;

    if (LXe_OK == (m_status = InitSocket (addr)))
        return;

    char    buffer[512];

    if (PREVIEWERROR_Failed == m_status)
        sprintf (buffer, "Network error (WSAGetLastError() returned %d)\n", m_status = WSAGetLastError ());
    else
        strcpy (buffer, "Network protocol failure\n");

    OutputDebugString (buffer);
    fprintf (stderr, buffer);
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Setup and open the connection
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::InitSocket (SOCKADDR_IN& addr)
{
    if (-1 == (m_socket = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP)))
        return PREVIEWERROR_Failed;

    if (SOCKET_ERROR == connect (m_socket, (SOCKADDR *)&addr, sizeof addr))
        return PREVIEWERROR_Failed;

    // Set & verify the protocol
    return SetProtocol ();
}

/*------------------------------- Luxology LLC --------------------------- 7/10
 *
 * Setup and open the connection using a named pipe
 *
 *----------------------------------------------------------------------------*/
    void
LxoPreviewer::PipePreviewer (char const* pipe)
{
    if (LXe_OK == (m_status = InitPipe (pipe)))
        return;

    char    errBuf[1024];
    char    buffer[2048];

    if (PREVIEWERROR_Failed == m_status)
        {
        FormatMessage (FORMAT_MESSAGE_FROM_SYSTEM, NULL, m_status = GetLastError (), 0, errBuf, 1024, NULL );
        sprintf (buffer, "Network error (%d) : %s\n", m_status, errBuf);
        }
    else
        strcpy (buffer, "Network protocol failure\n");

    OutputDebugString (buffer);
    fprintf (stderr, buffer);
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Setup and open the connection
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::InitPipe (char const* pipe)
{
    m_pipeH = CreateFile (pipe, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);

    if (m_pipeH == INVALID_HANDLE_VALUE)
        return PREVIEWERROR_Failed;

    // The pipe connected; change to message-read mode. 
    DWORD               dwMode = PIPE_READMODE_MESSAGE; 

    if (0 == SetNamedPipeHandleState (m_pipeH, &dwMode, NULL, NULL)) 
        return PREVIEWERROR_Failed;

    // Set & verify the protocol
    return SetProtocol ();
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Setup and open the connection
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetProtocol ()
{
    int                 response;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_PROTOCOL)
            || LXe_OK != SendByte (0)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_PROTOCOL_SET != response)
        return PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Send data in a loop until the buffer is empty.
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SendData (char const* data, int len)
{
    if (INVALID_HANDLE_VALUE != m_pipeH)
        {
        DWORD       bytesWritten;

        if (0 == WriteFile (m_pipeH, data, len, &bytesWritten, NULL) || len != bytesWritten)
            return m_status = PREVIEWERROR_Failed;

        return LXe_OK;
        }

    while (len > 0)
        {
        int     bytesWritten = send (m_socket, data, len, 0);

        if (SOCKET_ERROR == bytesWritten)
            return m_status = PREVIEWERROR_Failed;

        data += bytesWritten;
        len  -= bytesWritten;
        }

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Receive data in a loop until the buffer is full.
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::RecvData (char *data, int len)
{
    DWORD       bytesRead;


    while (len > 0)
        {
        if (INVALID_HANDLE_VALUE != m_pipeH)
            {
            if (0 == ReadFile (m_pipeH, data, len, &bytesRead, NULL))
                return m_status = PREVIEWERROR_Failed;
            }
        else
            {
            if (SOCKET_ERROR == (bytesRead = recv (m_socket, data, len, 0)))    // Error
                return m_status = PREVIEWERROR_Failed;
            }

        if (0 == bytesRead)                     // Socket gracefully closed
            return m_status = PREVIEWERROR_ConnectionClosed;

        data += bytesRead;
        len  -= bytesRead;
        }

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Set the preview resolution
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetResolution (int x, int y)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_RES)
            || LXe_OK != SendInt (x)
            || LXe_OK != SendInt (y)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_RES_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Set the preview format
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetFormat (int format)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_FORMAT)
            || LXe_OK != SendInt (format)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_FORMAT_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 6/10
 *
 * Set the maximum number of preview samples
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetSamples (int samples)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_SAMPLES)
            || LXe_OK != SendInt (samples)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_SAMPLES_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 8/10
 *
 * Set the preview quality to draft, with number of samples & quality fraction
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetQualityDraft (int samples, float draftFraction)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_DRAFT)
            || LXe_OK != SendInt (samples)
            || LXe_OK != SendFloat (draftFraction)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_DRAFT_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 8/10
 *
 * Set the preview quality to final
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetQualityFinal ()
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_FINAL)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_FINAL_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 8/10
 *
 * Set the preview quality to extended, with number of samples
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetQualityExtended (int samples)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_EXTENDED)
            || LXe_OK != SendInt (samples)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_EXTENDED_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 7/10
 *
 * Set the stereo mode to generate a frame for monocular, or right or left eye
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetStereo (bool enabled, bool rightEye)
{
    int                 response;
    int                 mode = enabled ? (rightEye ? 2 : 1) : 0;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_STEREO)
            || LXe_OK != SendInt (mode)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_STEREO_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 10/10
 *
 * Set the effect to be rendered in the preview
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetEffect (char const *effect)
{
    if (NULL == effect || '\0' == effect[0])
        effect = "---";     // setting an invalid effect will revert to the default "(Shading)"

    int                 response;
    int                 bytes = strlen (effect);

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_EFFECT)
            || LXe_OK != SendInt (bytes)
            || LXe_OK != SendData (effect, bytes)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_EFFECT_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 10/10
 *
 * Set the mouse position to concentrate preview
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetMousePos (int x, int y)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_MOUSEPOS)
            || LXe_OK != SendInt (x)
            || LXe_OK != SendInt (y)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_MOUSEPOS_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 10/10
 *
 * Set the camera position, direction & zoom
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::SetCamera (LXtFVector pos, LXtFVector dir, float zoom, bool final)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SET_CAMERA)
            || LXe_OK != SendFloats (pos, 3)
            || LXe_OK != SendFloats (dir, 3)
            || LXe_OK != SendFloat (zoom)
            || LXe_OK != SendInt (final)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_CAMERA_SET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 9/10
 *
 * Get the id (sent by preview.setId) of the last completed preview
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::GetPreviewId (int* idP)
{
    int                 response;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_GET_ID)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_ID_GET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    // read the preview ID, only valid after a 'done', zero otherwise
    if (LXe_OK != RecvInt (idP))
        return m_status;                                // write or read error

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 4/16
 *
 * Get the preview progress -- fraction complete. [0.0 - 1.0]
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::GetPreviewProgress (double* fracComplete)
{
    int                 response;
    int                 iFracComplete;

    if (-1 == m_socket)
        return m_status;

    // Set & verify the protocol
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_GET_PROGRESS)
            || LXe_OK != RecvInt (&response))
        return m_status;

    if (LXiPREVIEWMSG_ACK_PROGRESS_GET != response)
        return m_status = PREVIEWERROR_ProtocolFailure;

    // read the fraction complete in integer form, range is 0 - 10,000
    if (LXe_OK != RecvInt (&iFracComplete))
        return m_status;                                // write or read error

    *fracComplete = iFracComplete * 0.0001;

    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 11/09
 *
 * Generate a preview frame
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoPreviewer::GetFrame (int* responseP, int* widthP, int* heightP, LxByte** imgBufferP)
{
    if (LXe_OK != SendInt (LXiPREVIEWMSG_REQ_SEND_FULL_FRAME) ||
        LXe_OK != RecvInt (responseP))
        return m_status;                                // write or read error

    if (LXiPREVIEWMSG_PREVIEW_UNAVAILABLE & *responseP)
        return LXe_OK;                                  // No image ready yet; but that's ok, caller can try again

    bool    floatFormat = false;

    if (LXiPREVIEWMSG_ACK_SEND_FULL_FRAME_RGBAFP == *responseP)
        floatFormat = true;

    else if (LXiPREVIEWMSG_ACK_SEND_FULL_FRAME_RGB24 != *responseP)
        return PREVIEWERROR_ProtocolFailure;            // Unexpected message/error

    // Frame ready; read the width and height
    if (LXe_OK != RecvInt (widthP) || LXe_OK != RecvInt (heightP))
        return m_status;                                // write or read error

    int         rowInBytes  = *widthP * (floatFormat ? 4 * sizeof(float): 3);       // bytes per input row
    int         inBytes     = *heightP * rowInBytes;
    char*       tempBuffer;

    if (NULL == (tempBuffer = (char*) malloc (inBytes)))        // Allocate the temp BGR image buffer for reading
        return LXe_OUTOFMEMORY;

    if (LXe_OK != RecvData (tempBuffer, inBytes))               // Read the BGR data into the temp buffer
        {
        free (tempBuffer);
        return m_status;                                        // write or read error
        }

    int         rowOutBytes = ((3 * *widthP + 3) / 4) * 4;      // longword alligned bytes per output row
    int         outBytes    = *heightP * rowOutBytes;

    if (NULL == (*imgBufferP = (LxByte*) malloc (outBytes)))    // Allocate a longword alligned RGB buffer for windows
        {
        free (tempBuffer);
        return LXe_OUTOFMEMORY;
        }

    // copy the buffer read to the user buffer, longword aligning each row,
    // and swapping the red/blue bytes from BGR to RGB

    LxByte*     inPixP      = (LxByte*)tempBuffer;
    float*      inFPixP     = (float*)tempBuffer;
    LxByte*     outPixP     = *imgBufferP;
    int         padBytes    = rowOutBytes - *widthP * 3;        // any extra padding bytes

    for (int row = 0; row < *heightP; ++row)
        {
        if (floatFormat)
            {
            for (int col = 0; col < *widthP; ++col, inFPixP += 4, outPixP += 3)
                {
                outPixP[0] = inFPixP[2] >= 1.0 ? 255 : (byte)(255 * inFPixP[2]);
                outPixP[1] = inFPixP[1] >= 1.0 ? 255 : (byte)(255 * inFPixP[1]);
                outPixP[2] = inFPixP[0] >= 1.0 ? 255 : (byte)(255 * inFPixP[0]);

#if DEBUG_ALPHA
                if (inFPixP[3] == 0.0)
                    outPixP[2] += (255 - outPixP[2]) / 2;
#endif
                }
            }
        else
            {
            for (int col = 0; col < *widthP; ++col, inPixP += 3, outPixP += 3)
                {
                outPixP[0] = inPixP[2];
                outPixP[1] = inPixP[1];
                outPixP[2] = inPixP[0];
                }
            }

        for (int extra = 0; extra < padBytes; ++extra)      // pad remainder of row with 0's
            *outPixP++ = 0;
        }

    free (tempBuffer);
    return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 08/09
 * methods to init & clear the command process manager
 *----------------------------------------------------------------------------*/
LxoManager::LxoManager (bool isPersistent, char const* luxDirectory, char const* subDirectory, LxoListener* listener, LxModoRunMode runMode)
    {
    m_abortFound        = false;
    m_loggingEnabled    = true;
    m_listener          = listener;
    m_isPersistent      = isPersistent;
    m_useNetPipe        = 0 != (runMode & LxRunModo_NetPipe);
    m_useTelnet         = 0 != (runMode & LxRunModo_Telnet);
    m_runHeadless       = 0 != (runMode & LxRunModo_Headless);
    m_pipeToModo        = INVALID_HANDLE_VALUE;
    m_modoProcessHandle = INVALID_HANDLE_VALUE;

    m_modoSocket        = INVALID_SOCKET;
    m_socketPort        = SOCKET_DefaultPort;
    m_socketIpAddr      = inet_addr ("127.0.0.1");      // address of localhost
    strcpy (m_socketPipe, SOCKET_DefaultPipe);

    m_firstPromptFound  = false;
    m_dataInAltBuffer   = false;
    m_statusBuffer[0]   = '\0';
    m_statusBufferP     = m_statusBuffer;

    if (NULL == luxDirectory)
        {
        char        tempPath[LXMax_FileLength] = "";

        GetEnvironmentVariable ("TEMP", tempPath, sizeof tempPath);
        sprintf (m_workDir, "%s\\Luxology\\", tempPath);
        }
    else
        strcpy (m_workDir, luxDirectory);

    if (subDirectory)
        strcat (m_workDir, subDirectory);

    sprintf (m_bucketDir,    "%sBuckets\\",     m_workDir);
    sprintf (m_irrBucketDir, "%sIrrBuckets\\",  m_workDir);

    _mkdir (m_workDir);
    _mkdir (m_bucketDir);
    _mkdir (m_irrBucketDir);

    signal(SIGINT,   HandleAbort);
    signal(SIGBREAK, HandleAbort);
    }

LxoManager::~LxoManager ()
    {
    WaitForModoToExit (true);   // send exit command (if not yet sent) and wait for completion
    TerminateModo ();           // clean up connections to process

    if (m_useTelnet)
        WSACleanup ();

    size_t      nCmdFiles = m_tempCmdFiles.size ();
    if (0 >= nCmdFiles)
        return;

    for (size_t i = 0; i < nCmdFiles; ++i)
        _unlink (m_tempCmdFiles[i].c_str());
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * Close handle and mark as released
 *----------------------------------------------------------------------------*/
    void
LxoManager::DropHandle (HANDLE &handle)
    {
    if (INVALID_HANDLE_VALUE != handle)
        {
        CloseHandle (handle);
        handle = INVALID_HANDLE_VALUE;
        }
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * Terminate the render process & cleanup
 *----------------------------------------------------------------------------*/
    void
LxoManager::TerminateModo ()
    {
    if (INVALID_HANDLE_VALUE != m_modoProcessHandle)
        TerminateProcess (m_modoProcessHandle, 1);

    DropHandle (m_pipeToModo);

    // cancel timer

    DropHandle (m_modoProcessHandle);

    // clean up files
    }

/*------------------------------- Luxology LLC --------------------------- 09/09
 * write commands to modo through pipe or socket
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::WriteToModo (char const *buffer, DWORD bytesToWrite)
    {
    if (m_listener && LXe_OK != m_listener->m_result)       // handle asynnchronous errors
        return m_listener->m_result;

    DWORD           charsWritten;
    char const*     sendBuf = buffer;

    if (m_useTelnet || m_useNetPipe)
        {
        // for net commands, we need to replace the newline characters with NULLs.
        // Note that the NULL terminator is NOT counted in the write count
        char*       buf = (char*)alloca (bytesToWrite + 1), *oP = buf;

        for (char const* cP = buffer; '\0' != (*oP = *cP); ++cP, ++oP)
            if ('\n' == *oP)
                *oP = '\0';

        sendBuf = buf;
        }

    if (m_useTelnet)
        {
        /* it's possible that the buffer may fill up preventing all bytes to be written.
         * As a general rule, we will only be writing single commands to run a macro,
         * so the buffer should never really fill up.
         *
         * If however, we are runing asynchronously, then we need to wait for all bytes to
         * be written.  Since there is a listener thread reading the output socket, modo
         * won't block.  For now, we'll assume that the caller wants us to wait.
         */

        while (true)
            {
            if (SOCKET_ERROR != (charsWritten = send (m_modoSocket, sendBuf, bytesToWrite, 0)))
                {
                if (charsWritten == bytesToWrite)
                    return LXe_OK;

                bytesToWrite -= charsWritten;
                sendBuf      += charsWritten;

                continue;           // try to send the remaining bytes
                }

            if (m_abortFound)
                return LXe_ABORT;

            if (WSAEWOULDBLOCK != WSAGetLastError ())
                return LXe_IO_ERROR;
            }
        }

    else if (0 == WriteFile (m_pipeToModo, sendBuf, bytesToWrite, &charsWritten, NULL) || bytesToWrite != charsWritten)
        return LXe_IO_ERROR;

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * 
 * Extract a string token from a result buffer.
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::ExtractResultToken (LxCmdResult& tokenType, char*& tokenString, bool allowPipeRead)
    {
    tokenString = m_statusBufferP;          // token string will always be start of buffer

    if ('\0' == *m_statusBufferP)
        {
        if (m_abortFound || ! allowPipeRead)
            {
            tokenType = LxCmdResult_Empty;
            return LXe_OK;
            }

        DWORD       charsRead;

        if (m_useTelnet)
            {
            if (SOCKET_ERROR == (charsRead = recv (m_modoSocket, tokenString = m_statusBufferP = m_statusBuffer, sizeof m_statusBuffer - 1, 0)))
                return LXe_IO_ERROR;
            }

        else if (0 == ReadFile (m_pipeFromModo, tokenString = m_statusBufferP = m_statusBuffer, sizeof m_statusBuffer - 1, &charsRead, NULL))
            return LXe_IO_ERROR;

        m_statusBuffer[charsRead] = '\0';     // so we know we've reached the end of the buffer
        if (0 == charsRead)
            {
            tokenType = LxCmdResult_Empty;
            return LXe_OK;
            }
        }

    switch (tokenString[0])
        {
        case MODO_CHAR_PROMPT:                          // command prompt
            tokenType = LxCmdResult_Prompt;
            m_statusBufferP += m_useTelnet ? 3 : 2;     // skip past the prompt & space, and the NULL for telnet, for next search
            return LXe_OK;

        case MODO_CHAR_SYSTEM:                          // system command
            tokenType = LxCmdResult_System;
            break;

        case MODO_CHAR_LOG:                             // log message
            tokenType = LxCmdResult_Log;
            break;

        case MODO_CHAR_QUERY:                           // result of query
            tokenType = LxCmdResult_Query;
            break;

        case MODO_CHAR_SUCCESS:                         // Successful result
            tokenType = LxCmdResult_Success;
            break;

        case MODO_CHAR_ERROR:                           // Error result
            tokenType = LxCmdResult_Error;
            break;

        default:                                        // arbitrary message
            tokenType = LxCmdResult_Message;
            break;
        }

    char*   eol = strchr (m_statusBufferP, m_useTelnet || m_useNetPipe ? '\0' : '\n');

    if (NULL == eol && NULL == (eol = strchr (m_statusBufferP, '\xFF')))
        {
        int     charsLeft = sizeof m_statusBuffer - (m_statusBufferP - m_statusBuffer);
        strncpy (m_altBuffer, m_statusBufferP, charsLeft);

        m_altBuffer[charsLeft]  = '\0';
        *m_statusBufferP        = '\0';          // so we read the next buffer
        m_dataInAltBuffer       = true;
        m_altTokenType          = tokenType;
        tokenType               = LxCmdResult_Partial;

        return LXe_OK;
        }

    m_statusBufferP = eol + 1;                  // point next search after '\n'

    if (eol > tokenString && '\r' == eol[-1])   // check to see if string ended with '\r\n'
        --eol;                                  // if so, token ends before '\r'
    else if ('\r' == eol[1])                    // otherwise check if string ends with '\n\r'
        ++m_statusBufferP;                      // point next search after '\n\r'

    *eol = '\0';                                // replace newline with NULL to terminate the string

    if (m_dataInAltBuffer)
        {
        strcat (m_altBuffer, tokenString);
        tokenString         = m_altBuffer;
        tokenType           = m_altTokenType;
        m_dataInAltBuffer   = false;
        }

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * skip past the two initial prompts; the original, plus the one from our init command
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::ReadInitialPrompts ()
    {
    if (m_firstPromptFound)
        return LXe_OK;

    LxCmdResult     tokenType;
    char*           tokenString;
    int             nPrompts = 2;

    while (LXe_OK == ExtractResultToken (tokenType, tokenString))
        if (LxCmdResult_Prompt == tokenType && --nPrompts <= 0)
            break;

    m_firstPromptFound = true;
    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * Create a modo process (or attach to an existing one) and connect to pipe
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::StartModoConnection ()
    {
    // if there are active pipe & process handles, make sure the preocess is still alive
    if (INVALID_HANDLE_VALUE != m_modoProcessHandle
            && (INVALID_HANDLE_VALUE != m_pipeToModo || INVALID_SOCKET != m_modoSocket))
        {
        DWORD       exitCode = -1;

        GetExitCodeProcess (m_modoProcessHandle, &exitCode);    // see if the process is still alive
        if (STILL_ACTIVE == exitCode)
            return LXe_OK;
        }

    // if we get here, there is no active modo process
    if (INVALID_HANDLE_VALUE != m_modoProcessHandle)
        TerminateModo ();                                       // clean up last known process handle

    SECURITY_ATTRIBUTES     securityAttr;
    securityAttr.nLength                = sizeof (securityAttr);
    securityAttr.bInheritHandle         = true;
    securityAttr.lpSecurityDescriptor   = NULL;

    bool        inheritHandles  = ! m_useTelnet && ! m_useNetPipe;
    HANDLE      modoStdIn       = INVALID_HANDLE_VALUE;      // the end of the pipe that modo will read from
    HANDLE      modoStdOut      = INVALID_HANDLE_VALUE;      // the end of the pipe that modo will write to

    PROCESS_INFORMATION     processInfo;    memset (&processInfo, 0, sizeof processInfo);
    STARTUPINFO             startupInfo;    memset (&startupInfo, 0, sizeof startupInfo);

    startupInfo.cb = sizeof startupInfo;

    if (m_useTelnet)
        {
        WSADATA         wsaData;

        if (0 != WSAStartup (MAKEWORD (2, 2), &wsaData)                                             // Startup Winsock
                || INVALID_SOCKET == (m_modoSocket = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP)))   // create the socket
            return LXe_IO_ERROR;
        }
    else if (! m_useNetPipe)
        {
        // create the pipes and ensure that our ends are not inherited

        if (0 == CreatePipe (&modoStdIn,      &m_pipeToModo, &securityAttr, 0) ||
            0 == CreatePipe (&m_pipeFromModo, &modoStdOut,   &securityAttr, 0) ||
            0 == SetHandleInformation (m_pipeToModo,   HANDLE_FLAG_INHERIT, 0)   ||       // ensure that our ends are not inherited
            0 == SetHandleInformation (m_pipeFromModo, HANDLE_FLAG_INHERIT, 0))
                return LXe_IO_ERROR;

        startupInfo.dwFlags     = STARTF_USESTDHANDLES;

        startupInfo.hStdInput   = modoStdIn;
        startupInfo.hStdOutput  = modoStdOut;
        startupInfo.hStdError   = modoStdOut;
        }

    char    modoArgs[1024], telnetStr[512] = "";
    int     processFlags    = BELOW_NORMAL_PRIORITY_CLASS | CREATE_NO_WINDOW;
    bool    wantIlluminance = false;//NULL != m_listener && m_listener->GetDisplayIlluminance ();

    if (m_useTelnet)
        sprintf (telnetStr, STRING_MODO_ARGS_TELNET, m_socketPort);
    else if (m_useNetPipe)
        sprintf (telnetStr, STRING_MODO_ARGS_PIPE, m_socketPipe);

    sprintf (modoArgs, "%s%s", telnetStr, wantIlluminance ? STRING_MODO_ARGS_IrrCacheFile : "");

    int     status = CreateProcess (m_appFile, modoArgs, NULL, NULL, inheritHandles, processFlags, NULL, NULL, &startupInfo, &processInfo);

    CloseHandle (processInfo.hThread);
    CloseHandle (modoStdIn);
    CloseHandle (modoStdOut);

    if (0 == status)
        return LXe_NOTAVAILABLE;

    m_modoProcessHandle = processInfo.hProcess;

    if (m_useTelnet)        // wait for process to be created, then connect to the sockets
        {
        SOCKADDR_IN         addr;

        addr.sin_family      = AF_INET;                 // Set up the socket port & address
        addr.sin_port        = htons (m_socketPort);    
        addr.sin_addr.s_addr = m_socketIpAddr;

        // try to connect to the socket; try a few times to give modo a chance to start up
        int     tries = 0;

        while (SOCKET_ERROR == connect (m_modoSocket, (SOCKADDR*)&addr, sizeof addr))
            if (++tries > 60)
                {
                closesocket (m_modoSocket);
                m_modoSocket = INVALID_SOCKET;
                return LXe_IO_ERROR;
                }
        }
    else if (m_useNetPipe)        // wait for process to be created, then connect to the pipe
        {
        char            cmdPipe[PIPE_MaxNameLen];
        char            outPipe[PIPE_MaxNameLen];

        sprintf (cmdPipe, "%s.cmd", m_socketPipe);
        sprintf (outPipe, "%s.out", m_socketPipe);

        // try to connect to the socket; try a few times to give modo a chance to start up
        int     tries = 0;

        while (INVALID_HANDLE_VALUE == (m_pipeToModo = CreateFile (cmdPipe, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL)))
            {
            if (++tries > 240)
                return LXe_IO_ERROR;
            Sleep (250);                 // pause for 1/4 sec (in millisecs)
            }

        if (INVALID_HANDLE_VALUE == (m_pipeFromModo = CreateFile (outPipe, GENERIC_READ | GENERIC_WRITE,  0, NULL, OPEN_EXISTING, 0, NULL)))
            {
            CloseHandle (m_pipeToModo);
            return LXe_IO_ERROR;
            }

        // The pipe connected; change to message-read mode.
        DWORD               dwMode = PIPE_READMODE_MESSAGE;

        if (0 == SetNamedPipeHandleState (m_pipeFromModo, &dwMode, NULL, NULL))
            {
            CloseHandle (m_pipeToModo);
            CloseHandle (m_pipeFromModo);
            return LXe_IO_ERROR;
            }
        }

    // write any initialization command - must be at least one

    static char const   CmdConsoleLogging[] = "log.toConsole true\n";
    int                 bytesToWrite = sizeof CmdConsoleLogging - 1;      // for static strings, strlen == sizeof-1

    if (LXe_OK != WriteToModo (CmdConsoleLogging, bytesToWrite))
        return LXe_IO_ERROR;

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * set up location of modo_cl.exe
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::SetModoPath (char const *path, char const *pathVar)
    {
    if (path)
        strcpy (m_appFile, path);

    else if (pathVar)
        {
        char        tempPath[LXMax_FileLength] = "";

        GetEnvironmentVariable (pathVar, tempPath, sizeof tempPath);
        strcpy (m_appFile, tempPath);
        }

    if ('\0' == m_appFile[0])
        return LXe_INVALIDARG;

    struct _stati64     fileInfo;
    if (-1 == _stati64 (m_appFile, &fileInfo))
        return LXe_NOTFOUND;

    return LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * set up location of modo_cl.exe
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::WaitForModoToExit (bool sendExitCommand)
    {
    if (INVALID_HANDLE_VALUE == m_modoProcessHandle)
        return LXe_OK;          // already gone; assume normal exit?

    LxResult        result;
    LxoCommand      tempCmd;

    // if a listener is running, makes sure last job is completed so we don't exit before we read the status.
    // if we need to send an exit, do so.

    if ((m_listener         && LXe_OK != (result = m_listener->WaitForTask (true))) ||
        (sendExitCommand    && LXe_OK != (result = tempCmd.ExitModo (this))))
        {
        TerminateModo ();
        return result;
        }

    while (WAIT_OBJECT_0 != WaitForSingleObject (m_modoProcessHandle, 1000))
        {
        if (m_abortFound)
            {
            TerminateModo ();
            return LXe_ABORT;
            }

        LxCmdResult     tokenType;
        char*           tokenString;

        // read any strings out of the buffer, in case modo has a full output pipe (debug mode)
        while (LXe_OK == ExtractResultToken (tokenType, tokenString) && LxCmdResult_Empty != tokenType)
            true;
        }

    DWORD   exitCode;
    GetExitCodeProcess (m_modoProcessHandle, &exitCode);
    return exitCode ? LXe_FAILED : LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * wait for result, but stop if modo exited unexpectedly
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::WaitForResult (const char* fileToWaitFor)
    {
    struct _stati64     fileInfo;
    char                fileDir[LXMax_FileLength];

    /*
     *  extract the directory from the filename
     */
    strcpy (fileDir, fileToWaitFor);

    char*       lastSlash       = strrchr (fileDir, '/');
    char*       lastBackSlash   = strrchr (fileDir, '\\');

    if (lastSlash > lastBackSlash)
        *lastSlash = '\0';
    else if (lastBackSlash)
        *lastBackSlash = '\0';
    else
        _getcwd (fileDir, LXMax_FileLength);

    bool        modoQuit = false;
    HANDLE      resultHandle = FindFirstChangeNotification (fileDir, FALSE, FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE);

    // loop until user abort, file exists, or modo quits
    while (! m_abortFound
                && -1 == _stati64 (fileToWaitFor, &fileInfo)
                &&  false == (modoQuit = (WAIT_OBJECT_0 == WaitForSingleObject (m_modoProcessHandle, 0))))
        WaitForSingleObject (resultHandle, 1000);

    CloseHandle (resultHandle);

    if (modoQuit)
        {
        TerminateModo ();       // close handles & clean up
        return LXe_FAILED;
        }

    return m_abortFound ? LXe_ABORT : LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 * wait for result, but stop if modo exited unexpectedly
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::WaitForResult (int nCommands)
    {
    if (LXe_OK != ReadInitialPrompts ())
        return LXe_FAILED;

    LxCmdResult     tokenType;
    char*           tokenString;
    bool            modoQuit, errorsFound = false, lastTokenWasSuccess = false;

    while (! m_abortFound &&  false == (modoQuit = (WAIT_OBJECT_0 == WaitForSingleObject (m_modoProcessHandle, 0))))
        {
        // process all tokens until we reach the desired number of prompts.
        // success or failure of any command is determined by the last token before the prompt.

        // I believe a CTRL-C will abort a hanging pipe read...

        while (LXe_OK == ExtractResultToken (tokenType, tokenString) && LxCmdResult_Empty != tokenType)
            {
            switch (tokenType)
                {
                case LxCmdResult_Prompt:        // we should get 1 prompt for every command executed
                    if (! lastTokenWasSuccess)
                        errorsFound = true, lastTokenWasSuccess = false;

                    if (--nCommands == 0)
                        return errorsFound ? LXe_WARNING : LXe_OK;
                    break;

                case LxCmdResult_Success:       // ignore the 'ok' string
                    lastTokenWasSuccess = true;
                    break;

                case LxCmdResult_Error:
                    lastTokenWasSuccess = false;    // fall through

                case LxCmdResult_System:
                case LxCmdResult_Log:
                case LxCmdResult_Query:
                case LxCmdResult_Message:
                default:
                    if (m_loggingEnabled)
                        m_cmdLog.append (tokenString), m_cmdLog.append ("\n");
                    break;

                case LxCmdResult_Partial:           // do nothing yet
                    break;
                }
            }
        }

    if (modoQuit)
        {
        TerminateModo ();       // close handles & clean up
        return LXe_FAILED;
        }

    return m_abortFound ? LXe_ABORT : LXe_OK;
    }

/*------------------------------- Luxology LLC --------------------------- 08/09
 *
 * Run a set of commands.  There are a few possible combinations of actions
 * that can be performed after sending the commands to modo:
 *
 * If manager is persistent:
 *      return if asynchronous (listener operating or not synchronous)
 *      wait for completion otherwise
 *
 * If manager is not persistent (after sending the exit command):
 *      return if asynchronous (listener operating or not synchronous)
 *      wait for modo exit
 *
 *----------------------------------------------------------------------------*/
    LxResult
LxoManager::Run (LxoCommand& cmd, bool synchronous)
    {
    if (NULL == m_listener)     // if listener is running, let IT clear the log
        m_cmdLog.clear ();

    else if (LXe_OK != m_listener->m_result)       // handle asynnchronous errors
        return m_listener->m_result;

    LxResult    result = StartModoConnection ();
    if (LXe_OK != result)
        return result;

    cmd.WriteCommandsToModo (this);

    /*
     *  always send an exit command if not persistent
     */
    if (! m_isPersistent && LXe_OK != (result = cmd.ExitModo (this)))
        return result;

    if (m_listener)     // if there's a listener active, just return and let listener wait for results
        {
        char        outputFile[LXMax_FileLength];

        sprintf (outputFile, "%s.%s", cmd.GetOutputFile (), cmd.GetOutputType ());
        m_listener->SetOutputFile (outputFile);
        m_listener->m_cmdsToWaitFor = 1;

        if (LXe_OK != (result = m_listener->BeginListening (this)))
            TerminateModo ();

        return result;
        }

    if (! synchronous)  // caller does not want us to wait for the result
        return result;

    // if persistent, wait for the result, otherwise wait for modo to exit (cmd already sent)
    return m_isPersistent ? WaitForResult (1) : WaitForModoToExit ();
    }

