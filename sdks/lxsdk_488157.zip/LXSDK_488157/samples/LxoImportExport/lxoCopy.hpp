/*
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * ----------------------------------------------------------------
 * Class to copy LXO files
 *
 */

#pragma once
#include "lxoReader.hpp"
#include "lxoWriter.hpp"

/*------------------------------- Luxology LLC --------------------------- 06/09
 *
 * This class can be used to read material presets from an LXP file. This
 * class ignores all chunks except ITEM & ENVL.  As with the LxoReader
 * class, the default methods only read the data into memory, but these
 * can be overridden to enable custom processing of the data.
 *
 *----------------------------------------------------------------------------*/
class LxoCopy : public LxoReader {
        bool                m_ourWriter;            // true if we created the writer
        LxResult            m_result;

    public:
        LxoWriteData*       m_writer;               // writer class to use to actually write the chunk

        LxoCopy (char const* lxoName, LxoWriteData* writer);
        LxoCopy (char const* lxoName, char const* lxoCopyName);
        ~LxoCopy ();

        virtual LXChunkUsage    ChunkUsage () { return LXChunk_Copy; };     // Default: copy the current chunk without processing
        virtual LxResult        ProcessChunk (LXChunkUsage action);         // Add Copy as an chunk processing option
        virtual LxResult        ProcessItemSubChunk (LXChunkUsage action);  // Add Copy as an item processing option

        virtual LxResult        CopyChunk ();                               // copy chunk without processing
        virtual LxResult        CopySubChunk ();                            // copy sub-chunk without processing

        // by default, these will copy the item headers & close the item, while 
        // still allowing subchunks to be processed
        virtual LxResult        ProcessItem (char* itemType, char* name, LxULong refId);
        virtual LxResult        ProcessItemEnd ();

        // copy channels from input file to LxoWriter class and output file
        virtual LxResult        ProcessChannelNames (LxULong count, LXtStringVec chans);
};

