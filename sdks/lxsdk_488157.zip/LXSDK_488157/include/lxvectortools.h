/*
 * LX vectortools module
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_vectortools_H
#define LX_vectortools_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxVectorCanvas ** ILxVectorCanvasID;
typedef struct vt_ILxVectorShape ** ILxVectorShapeID;
typedef struct vt_ILxVectorPath ** ILxVectorPathID;
typedef struct vt_ILxVectorListener ** ILxVectorListenerID;
#include <lxcom.h>

typedef void *   LXtVectorKnotID;

// [python] type LXtVectorKnotID        id

typedef struct vt_ILxVectorCanvas {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        GetItem) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        BeginEditBatch) (
                LXtObjectID               self);

                LXxMETHOD( LxResult,
        EndEditBatch) (
                LXtObjectID               self);
} ILxVectorCanvas;
typedef struct vt_ILxVectorShape {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        ShapeCount) (
                LXtObjectID               self,
                unsigned int             *count);
                LXxMETHOD( LxResult,
        ShapeByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Parent) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        PathCount) (
                LXtObjectID               self,
                unsigned int             *count);
                LXxMETHOD( LxResult,
        PathByIndex) (
                LXtObjectID               self,
                unsigned int              index,
                void                    **ppvObj);
                LXxMETHOD( LxResult,
        Transform) (
                LXtObjectID               self,
                const LXtMatrix           matrix);
} ILxVectorShape;
typedef struct vt_ILxVectorPath {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        IsPathClosed) (
                LXtObjectID               self);

                LXxMETHOD( LxResult,
        SetPathClosed) (
                LXtObjectID               self,
                LxResult                  closed);
                LXxMETHOD( LxResult,
        KnotCount) (
                LXtObjectID               self,
                unsigned int             *count);
                LXxMETHOD( LxResult,
        SelectKnotByIndex) (
                LXtObjectID               self,
                unsigned int              index);
                LXxMETHOD( LxResult,
        SelectKnot) (
                LXtObjectID               self,
                LXtVectorKnotID           knot);
                LXxMETHOD( LxResult,
        KnotEnumerate) (
                LXtObjectID               self,
                LXtObjectID               visitor);
                LXxMETHOD( LXtVectorKnotID,
        ID) (
                LXtObjectID               self);
                LXxMETHOD( LxResult,
        Pos) (
                LXtObjectID               self,
                double                   *x,
                double                   *y);
} ILxVectorPath;
typedef struct vt_ILxVectorListener {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Destroy) (
                LXtObjectID               self);
                LXxMETHOD( LxResult,
        ShapeAdd) (
                LXtObjectID               self,
                LXtObjectID               shape);
                LXxMETHOD( LxResult,
        ShapeRemove) (
                LXtObjectID               self,
                LXtObjectID               shape);
                LXxMETHOD( LxResult,
        ShapeStyle) (
                LXtObjectID               self,
                LXtObjectID               shape,
                const char               *name);
                LXxMETHOD( LxResult,
        PathAdd) (
                LXtObjectID               self,
                LXtObjectID               shape,
                LXtObjectID               path);
                LXxMETHOD( LxResult,
        PathRemove) (
                LXtObjectID               self,
                LXtObjectID               shape,
                LXtObjectID               path);
                LXxMETHOD( LxResult,
        KnotPosition) (
                LXtObjectID               self,
                LXtObjectID               shape,
                LXtObjectID               path);
} ILxVectorListener;

#define LXu_VECTORCANVAS                "7A7915F0-E496-40D3-BD22-733D73885652"
#define LXa_VECTORCANVAS                "vectorcanvas"
// [local] ILxVectorCanvas
// [export] ILxVectorCanvas              canvas
// [python] ILxVectorCanvas:GetItem      obj Item
#define LXsPKG_CANVAS_CHANNEL   "vectorCanvas.channel"
#define LXu_VECTORSHAPE                 "2B56643A-9697-42F4-99F9-04F96038D45E"
#define LXa_VECTORSHAPE                 "vectorshape"
// [local] ILxVectorShape
// [export] ILxVectorShape               shape
// [python] ILxVectorShape:ShapeByIndex  obj VectorShape
// [python] ILxVectorShape:Parent        obj VectorShape
// [python] ILxVectorShape:PathByIndex   obj VectorPath
#define LXu_VECTORPATH                  "13C5B133-4AE3-4934-B748-E2B1D3904874"
#define LXa_VECTORPATH                  "vectorpath"
// [local] ILxVectorPath
// [export] ILxVectorPath                path
// [python] ILxVectorPath:IsPathClosed   bool
#define LXu_VECTORLISTENER              "90310E7B-85DB-4E5D-839B-25562FF50713"
#define LXa_VECTORLISTENER              "vectorlistener"
// [local] ILxVectorListener
// [export] ILxVectorListener            vtl

 #ifdef __cplusplus
  }
 #endif
#endif

