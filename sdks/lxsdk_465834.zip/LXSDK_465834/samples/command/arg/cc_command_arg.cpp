/*
 * MODO SDK SAMPLE
 *
 * Command server
 * ==============
 *
 *	Copyright (c) 2008-2017 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 *
 * This implements a Command server with one computed popup argument.
 *
 * CLASSES USED:
 *
 *		CLxCommand
 *		CLxMeta_Command
 *
 * TESTING:
 *
 * Execute the command "psam.command.arg" from the command history.
 * A dialog will open with the arguments
 */
#include <lxu_command.hpp>
#include <lxu_format.hpp>
#include <lx_log.hpp>
#include <string>

using namespace lx_err;


#define SRVNAME_COMMAND		"csam.command.arg"


        namespace CommandArg {

/*
 * ----------------------------------------------------------------
 * The command defines a single arg with value hints.
 */
class CCommand :
                public CLxCommand
{
    public:
        int			 arg_encoded;

        /*
         * setup_args() is called on initialization to define the arguments
         * using a CLxAttributeDesc object.
         *
         * We add our one int argument, and add the customization object.
         */
                void
        setup_args (
                CLxAttributeDesc	&desc)			LXx_OVERRIDE
        {
                static LXtTextValueHint	 arg_hints[] = {
                        -1,	"down",
                         0,	"unchanged",
                         1,	"up",
                         0,	0
                };

                CCommand		*cmd = 0;

                desc.add ("encodedInt", LXsTYPE_INTEGER);
                desc.struct_offset (&cmd->arg_encoded);
                desc.set_hint (arg_hints);
        }

        /*
         * execute() is called to perform the operation of the command.
         *
         * We read the arguments (setting arg_pop), and dump to debug output.
         */
                void
        execute ()						LXx_OVERRIDE
        {
                cmd_read_args (this);

                CLxUser_LogService lS;
                lS.DebugOut (LXi_DBLOG_NORMAL, SRVNAME_COMMAND " got %d\n", arg_encoded);
        }
};


/*
 * ----------------------------------------------------------------
 * Metaclass
 *
 * The command name is passed to the metaclass constructor.
 */
static CLxMeta_Command<CCommand>			cmd_meta (SRVNAME_COMMAND);


/*
 * ----------------------------------------------------------------
 * Root metaclass
 *
 *	(root)
 *	  |
 *	  +---	command
 *
 * We'll make this a UI command since it doesn't alter any scene state.
 */
static class CRoot : public CLxMetaRoot
{
        bool pre_init ()					LXx_OVERRIDE
        {
                cmd_meta.set_type_UI ();
                add (&cmd_meta);
                return false;
        }
} root_meta;

        };	// end namespace


