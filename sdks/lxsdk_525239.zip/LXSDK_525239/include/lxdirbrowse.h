/*
 * LX dirbrowse module
 *
 * Copyright (c) 2008-2018 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_dirbrowse_H
#define LX_dirbrowse_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxDirCacheService ** ILxDirCacheServiceID;
typedef struct vt_ILxDirCacheEntry ** ILxDirCacheEntryID;
typedef struct vt_ILxDirEntryThumbAsync ** ILxDirEntryThumbAsyncID;
typedef struct vt_ILxMergedDirCacheEntry ** ILxMergedDirCacheEntryID;
typedef struct vt_ILxDirCacheFileMetrics ** ILxDirCacheFileMetricsID;
typedef struct vt_ILxDirCacheSynthetic ** ILxDirCacheSyntheticID;
typedef struct vt_ILxDirCacheSyntheticEntry ** ILxDirCacheSyntheticEntryID;
typedef struct vt_ILxBasePathAddDest ** ILxBasePathAddDestID;
typedef struct vt_ILxDirCacheManualOrderDest ** ILxDirCacheManualOrderDestID;
typedef struct vt_ILxDirCacheGridPosDest ** ILxDirCacheGridPosDestID;
typedef struct vt_ILxFileSysDest ** ILxFileSysDestID;
typedef struct vt_ILxMergedFileSysDest ** ILxMergedFileSysDestID;
typedef struct vt_ILxDirBrowserBasePathEntryDest ** ILxDirBrowserBasePathEntryDestID;
#include <lxserver.h>
#include <lxvalue.h>



typedef struct vt_ILxDirCacheService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD(  LxResult,
        RootCount) (
                LXtObjectID               self,
                int                      *count);

                LXxMETHOD(  LxResult,
        RootByIndex) (
                LXtObjectID               self,
                int                       index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        RootLock) (
                LXtObjectID               self);

                LXxMETHOD(  LxResult,
        RootUnlock) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        Lookup) (
                LXtObjectID               self,
                const char               *path,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        CachedThumbnailAsyncCancel) (
                LXtObjectID               self,
                const char               *ident);
                LXxMETHOD(  LxResult,
        SetPosOnDrop) (
                LXtObjectID               self,
                const char               *path,
                LXtObjectID               dest);
                LXxMETHOD(  LxResult,
        AttributesChanged) (
                LXtObjectID               self,
                LXtObjectID               dirCacheEntry,
                int                       which,
                const char               *attribute);
                LXxMETHOD(  LxResult,
        ScanForChanges) (
                LXtObjectID               self,
                const char               *path);
                LXxMETHOD(  LxResult,
        AddClient) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        RemoveClient) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        ParseName) (
                LXtObjectID              self,
                const char              *filename,
                char                    *baseName,
                int                      baseNameLen,
                char                    *path,
                int                      pathLen);
                LXxMETHOD(  LxResult,
        PathCompose) (
                LXtObjectID              self,
                char                    *filename,
                int                      filenameLen,
                const char              *baseName,
                const char              *path);
                LXxMETHOD(  LxResult,
        IsChildOfPath) (
                LXtObjectID              self,
                const char              *possibleChild,
                const char              *parentToTestAgainsts,
                int                      orIsSame);
                LXxMETHOD(  LxResult,
        ToLocalAlias) (
                LXtObjectID              self,
                char                    *path,
                char                    *buf,
                int                      len);
                LXxMETHOD(  LxResult,
        ArePathsEqual) (
                LXtObjectID              self,
                const char              *path1,
                const char              *path2);
                LXxMETHOD(  LxResult,
        CanBeRenamed) (
                LXtObjectID              self,
                const char              *path);
                LXxMETHOD(  LxResult,
        MakeDirHierarchy) (
                LXtObjectID              self,
                const char              *path,
                int                      skipLastPart);
                LXxMETHOD(  LxResult,
        MakeUniqueIn) (
                LXtObjectID              self,
                LXtObjectID              object,
                const char              *filename,
                char                    *buf,
                int                      len);
} ILxDirCacheService;
typedef struct vt_ILxDirCacheEntry {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Type) (
                LXtObjectID               self,
                int                      *type);
                LXxMETHOD(  LxResult,
        DirList) (
                LXtObjectID               self,
                int                       listMode,
                void                    **ppvObj,
                int                       asCopy);
                LXxMETHOD(  unsigned int,
        DirCount) (
                LXtObjectID               self,
                int                       listMode);
                LXxMETHOD(  LxResult,
        Path) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);

                LXxMETHOD(  LxResult,
        Name) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);

                LXxMETHOD(  LxResult,
        Extension) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        Size) (
                LXtObjectID               self,
                double                   *size);
                LXxMETHOD(  LxResult,
        ModTime) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        Parent) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ReferenceSource) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ReferencedList) (
                LXtObjectID               self,
                void                    **ppvObj,
                int                       asCopy);
                LXxMETHOD(  unsigned int,
        ReferencedCount) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        WasRecognized) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        Metadata) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        UserMarkup) (
                LXtObjectID               self,
                void                    **ppvObj,
                int                       asWritable);

                LXxMETHOD(  LxResult,
        SharedMarkup) (
                LXtObjectID               self,
                void                    **ppvObj,
                int                       asWritable);
                LXxMETHOD(  LxResult,
        CommitUserMarkup) (
                LXtObjectID               self,
                LXtObjectID               userMarkup);

                LXxMETHOD(  LxResult,
        CommitSharedMarkup) (
                LXtObjectID               self,
                LXtObjectID               sharedMarkup);
                LXxMETHOD(  LxResult,
        Label) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);

                LXxMETHOD(  LxResult,
        Desc) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);

                LXxMETHOD(  LxResult,
        ToolTip) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        Thumbnail) (
                LXtObjectID               self,
                int                       w,
                int                       h,
                unsigned int             *idealW,
                unsigned int             *idealH,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        CachedThumbnail) (
                LXtObjectID               self,
                int                       size,
                unsigned int             *idealW,
                unsigned int             *idealH,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        CachedThumbnailCustom) (
                LXtObjectID               self,
                int                       w,
                int                       h,
                unsigned int             *idealW,
                unsigned int             *idealH,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        CachedThumbnailAsync) (
                LXtObjectID               self,
                int                       size,
                unsigned int             *idealW,
                unsigned int             *idealH,
                void                    **ppvObj,
                LXtObjectID               asyncHandler);

                LXxMETHOD(  LxResult,
        CachedThumbnailCustomAsync) (
                LXtObjectID               self,
                int                       w,
                int                       h,
                unsigned int             *idealW,
                unsigned int             *idealH,
                void                    **ppvObj,
                LXtObjectID               asyncHandler);
                LXxMETHOD(  LxResult,
        ChildManualOrderLookup) (
                LXtObjectID              self,
                const char              *childPath,
                unsigned int            *pos);
                LXxMETHOD(  LxResult,
        ChildManualOrderSet) (
                LXtObjectID              self,
                const char              *childPath,
                unsigned int             pos);
                LXxMETHOD(  LxResult,
        ChildGridPositionLookup) (
                LXtObjectID              self,
                const char              *childPath,
                unsigned int            *x,
                unsigned int            *y);
                LXxMETHOD(  LxResult,
        ChildGridPositionSet) (
                LXtObjectID              self,
                const char              *childPath,
                unsigned int             x,
                unsigned int             y);
                LXxMETHOD(  LxResult,
        GridExtents) (
                LXtObjectID              self,
                unsigned int            *bottom,
                unsigned int            *right );
                LXxMETHOD(  LxResult,
        GridSetExtents) (
                LXtObjectID              self,
                unsigned int             bottom,
                unsigned int             right );
                LXxMETHOD(  LxResult,
        GridInsert) (
                LXtObjectID              self,
                int                      doRows,
                unsigned int             x,
                unsigned int             y,
                unsigned int             count );
                LXxMETHOD(  LxResult,
        GridRemove) (
                LXtObjectID              self,
                int                      doRows,
                unsigned int             x,
                unsigned int             y,
                unsigned int             count,
                int                      force );
                LXxMETHOD(  LxResult,
        GridIsEmpty) (
                LXtObjectID              self,
                int                      doRows,
                unsigned int             x,
                unsigned int             y);
                LXxMETHOD(  LxResult,
        GridIsEmptyCell) (
                LXtObjectID               self,
                unsigned int              x,
                unsigned int              y,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Username) (
                LXtObjectID              self,
                char                    *buf,
                int                      len);
} ILxDirCacheEntry;
typedef struct vt_ILxDirEntryThumbAsync {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Ready) (
                LXtObjectID               self,
                LXtObjectID               dirCacheEntry,
                unsigned int              idealW,
                unsigned int              idealH,
                LXtObjectID               image);

                LXxMETHOD(  LxResult,
        Failed) (
                LXtObjectID               self,
                LXtObjectID               dirCacheEntry);
                LXxMETHOD(  LxResult,
        Ident) (
                LXtObjectID               self,
                const char              **ident);
} ILxDirEntryThumbAsync;
typedef struct vt_ILxMergedDirCacheEntry {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Path) (
                LXtObjectID              self,
                char                    *buf,
                int                      len);
                LXxMETHOD(  LxResult,
        EntryCount) (
                LXtObjectID               self,
                int                      *count);

                LXxMETHOD(  LxResult,
        EntryByIndex) (
                LXtObjectID               self,
                int                       index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        UserPath) (
                LXtObjectID              self,
                char                    *buf,
                int                      len);
                LXxMETHOD(  LxResult,
        Parent) (
                LXtObjectID               self,
                void                    **ppvObj);
} ILxMergedDirCacheEntry;
typedef struct vt_ILxDirCacheFileMetrics {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Metadata) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Markup) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Flags) (
                LXtObjectID               self,
                int                      *flags);
} ILxDirCacheFileMetrics;
typedef struct vt_ILxDirCacheSynthetic {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Lookup) (
                LXtObjectID               self,
                const char               *path,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Root) (
                LXtObjectID               self,
                void                    **ppvObj);
} ILxDirCacheSynthetic;
typedef struct vt_ILxDirCacheSyntheticEntry {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Path) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        Name) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);

                LXxMETHOD(  LxResult,
        DirUsername) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        FileExtension) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
                LXxMETHOD(  LxResult,
        IsFile) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        DirBuild) (
                LXtObjectID               self);
                LXxMETHOD(  unsigned int,
        DirCount) (
                LXtObjectID               self,
                int                       listMode);

                LXxMETHOD( LxResult,
        DirByIndex) (
                LXtObjectID               self,
                int                       listMode,
                unsigned int              index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ModTime) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
                LXxMETHOD(  double,
        Size) (
                LXtObjectID               self);
} ILxDirCacheSyntheticEntry;
typedef struct vt_ILxBasePathAddDest {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        AddBasePath) (
                LXtObjectID               self,
                const char               *setName,
                const char               *path);
} ILxBasePathAddDest;
typedef struct vt_ILxDirCacheManualOrderDest {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        BetweenPaths) (
                LXtObjectID               self,
                void                    **ppvObj,
                const char              **nameBefore,
                const char              **nameAfter,
                int                       asPaths);
} ILxDirCacheManualOrderDest;
typedef struct vt_ILxDirCacheGridPosDest {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        GridPos) (
                LXtObjectID               self,
                void                    **ppvObj,
                unsigned int             *x,
                unsigned int             *y);
} ILxDirCacheGridPosDest;
typedef struct vt_ILxFileSysDest {
        ILxUnknown       iunk;
                LXxMETHOD( LxResult,
        Path) (
                LXtObjectID               self,
                const char              **path);
                LXxMETHOD( LxResult,
        IsDir) (
                LXtObjectID               self);
                LXxMETHOD( LxResult,
        AsDir) (
                LXtObjectID               self,
                const char              **dir);
} ILxFileSysDest;
typedef struct vt_ILxMergedFileSysDest {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        MergedEntry) (
                LXtObjectID               self,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        EntryCount) (
                LXtObjectID               self,
                unsigned int             *count);
                LXxMETHOD(  LxResult,
        EntryByIndex) (
                LXtObjectID               self,
                int                       index,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        Path) (
                LXtObjectID               self,
                char                     *buf,
                int                       len);
} ILxMergedFileSysDest;
typedef struct vt_ILxDirBrowserBasePathEntryDest {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        SetPath) (
                LXtObjectID               self,
                const char              **path);
                LXxMETHOD(  LxResult,
        OrdinalBefore) (
                LXtObjectID               self,
                const char              **ordinal);
                LXxMETHOD(  LxResult,
        OrdinalAfter) (
                LXtObjectID               self,
                const char              **ordinal);
} ILxDirBrowserBasePathEntryDest;

#define LXu_DIRCACHESERVICE             "b61119fa-4cd9-4067-ba48-ba83ad1fa544"
#define LXa_DIRCACHESERVICE             "dircacheservice"
// [python] ILxDirCacheService:RootByIndex      obj DirCacheEntry
// [python] ILxDirCacheService:Lookup           obj DirCacheEntry
#define LXiDCEMARKUP_UPDATED_USER       1
#define LXiDCEMARKUP_UPDATED_SHARED     2
#define LXiDCEMARKUP_UPDATED_BOTH       (LXiDCEMARKUP_UPDATED_USER | LXiDCEMARKUP_UPDATED_SHARED)
#define LXu_DIRCACHEENTRY               "1013a289-aa27-416a-b273-666732ce3d88"
#define LXa_DIRCACHEENTRY               "dircacheentry"
// [local]  ILxDirCacheEntry
// [python] ILxDirCacheEntry:CachedThumbnail            obj Image
// [python] ILxDirCacheEntry:CachedThumbnailAsync       obj Image
// [python] ILxDirCacheEntry:CachedThumbnailCustom      obj Image
// [python] ILxDirCacheEntry:CachedThumbnailCustomAsync obj Image
// [python] ILxDirCacheEntry:DirList                    obj Array
// [python] ILxDirCacheEntry:GridIsEmptyCell            obj DirCacheEntry
// [python] ILxDirCacheEntry:Metadata                   obj Attributes
// [python] ILxDirCacheEntry:Parent                     obj DirCacheEntry
// [python] ILxDirCacheEntry:ReferenceSource            obj DirCacheEntry
// [python] ILxDirCacheEntry:ReferencedList             obj Array
// [python] ILxDirCacheEntry:SharedMarkup               obj Unknown
// [python] ILxDirCacheEntry:Thumbnail                  obj Image
// [python] ILxDirCacheEntry:UserMarkup                 obj Unknown
// [python] ILxDirCacheEntry:GridIsEmpty                bool
// [python] ILxDirCacheEntry:GridIsEmptyCell            bool
#define LXvDCETYPE_INVALID              0x00000000

// Masks
#define LXmDCETYPE_FILEDIR              0x0000000F
#define LXmDCETYPE_FLAGS                0x000000F0
#define LXmDCETYPE_SYNTH                0x00000F00
#define LXmDCETYPE_SPECIAL              0x0000F000

// Bits
#define LXfDCETYPE_FILE                 0x00000001                              // File
#define LXfDCETYPE_DIR                  0x00000002                              // Directory

#define LXfDCETYPE_READONLY             0x00000010                              // Read-only, and cannot be deleted, renamed or otherwise modified
#define LXfDCETYPE_DIR_AS_FILE          0x00000020                              // Directory that is treated as a file.  It will show up as a file in the browser, but exists as a directory for access purposes (ie: it can't be opened for read/write like a file)

#define LXfDCETYPE_SYNTHETIC            0x00000100                              // Synthetic entry that does not exist on disk
#define LXfDCETYPE_REFERENCE            0x00000200                              // Synthetic entry that references another entry, which may itself be synthetic.  References do not point to other references
#define LXfDCETYPE_FILTERED             0x00000400                              // A synthetic directory whose contents is defined by its filter

// Macros
#define LXxDCETYPE_IS_FILE(t)           ((t) & LXfDCETYPE_FILE)                                                                 // File flag is set
#define LXxDCETYPE_IS_DIR(t)            ((t) & LXfDCETYPE_DIR)                                                                  // Dir flag is set

#define LXfDCETYPE_EXISTS(t)            (LXxDCETYPE_IS_FILE(t) || LXxDCETYPE_IS_DIR(t))
#define LXxDCETYPE_IS_DIR_AS_FILE(t)    (((t) & LXfDCETYPE_DIR) && ((t) & LXfDCETYPE_DIR_AS_FILE))

#define LXxDCETYPE_AS_FILE(t)           (LXxDCETYPE_IS_FILE(t) || (LXxDCETYPE_IS_DIR(t) && LXxDCETYPE_IS_DIR_AS_FILE(t)))       // Treat the path as a file
#define LXxDCETYPE_AS_DIR(t)            (LXxDCETYPE_IS_DIR(t)  && !LXxDCETYPE_IS_DIR_AS_FILE(t))                                // Treat the path as a dir

#define LXxDCETYPE_IS_READONLY(t)       ((t) & LXfDCETYPE_READONLY)
#define LXxDCETYPE_IS_READWRITE(t)      (!((t) & LXfDCETYPE_READONLY))

#define LXxDCETYPE_IS_REAL(t)           (((t) & LXmDCETYPE_SYNTH) == 0)         // AKA "not synthetic" (also not a reference)
#define LXxDCETYPE_IS_SYNTHETIC(t)       ((t) & LXfDCETYPE_SYNTHETIC)
#define LXxDCETYPE_IS_REFERENCE(t)       ((t) & LXfDCETYPE_REFERENCE)
#define LXxDCETYPE_IS_FILTERED(t)       (((t) & LXfDCETYPE_FILTERED) && DBCExTYPE_IS_DIR(t))
#define LXxDIRCACHE_IS_SYNTHETIC_PATH(p)        ((((p) != NULL) && ((p)[0] != '[')) ? 0 : 1)
#define LXxDIRCACHE_IS_MERGED_PATH(p)   ((((p) != NULL) && ((p)[0] != '#')) ? 0 : 1)
#define LXvDCELIST_DIRS                 0x1
#define LXvDCELIST_FILES                0x2
#define LXvDCELIST_BOTH                 (LXvDCELIST_DIRS | LXvDCELIST_FILES)
#define LXiDCE_THUMBSIZE_IDEAL_ONLY     0
#define LXiDCE_THUMBSIZE_FULL           0xFFFFFFFF
#define LXiDCE_CACHEDTHUMBSIZE_32       0
#define LXiDCE_CACHEDTHUMBSIZE_64       1
#define LXiDCE_CACHEDTHUMBSIZE_128      2
#define LXiDCE_CACHEDTHUMBSIZE_256      3
#define LXiDCE_CACHEDTHUMBSIZE_512      4

#define LXiDCE_CAHCEDTHUMBSIZE_COUNT    5
#define LXu_DIRENTRYTHUMBASYNC          "0a3c97de-37b8-44b2-a52b-b1b91c77e597"
#define LXa_DIRENTRYTHUMBASYNC          "direntrythumbasync"
// [local] ILxDirEntryThumbAsync
// [export] ILxDirEntryThumbAsync detasync
#define LXiDCE_MANUALORDER_FIRST        0xFFFFFFFF
#define LXiDCE_MANUALORDER_LAST         0xFFFFFFFE
#define LXiDCEGRID_NONE         0xFFFFFFFF
#define LXu_MERGEDDIRCACHEENTRY         "38986948-6e89-4208-a734-411d28ab4815"
#define LXa_MERGEDDIRCACHEENTRY         "mergeddircacheentry"
// [local]  ILxMergedDirCacheEntry
// [python] ILxMergedDirCacheEntry:EntryByIndex         obj DirCacheEntry
// [python] ILxMergedDirCacheEntry:Parent               obj DirCacheEntry
#define LXu_DIRCACHEFILEMETRICS         "2c00a80c-ac90-401c-8cb8-abfdf3ba26dd"
#define LXa_DIRCACHEFILEMETRICS         "dircachefilemetrics"
// [local]  ILxDirCacheFileMetrics
// [export] ILxDirCacheFileMetrics dcfilemetrics
// [python] ILxDirCacheFileMetrics:Metadata     obj Attributes
// [python] ILxDirCacheFileMetrics:Markup       obj Attributes
#define LXiDCFM_DYNAMIC_THUMBNAILS              0x00000001
#define LXu_DIRCACHESYNTHETIC           "d269abf7-7bd3-4982-a6bd-cb46fcebe1e3"
#define LXa_DIRCACHESYNTHETIC           "dircachesynthetic"
// [local] ILxDirCacheSynthetic
// [export] ILxDirCacheSynthetic dcsyn
// [python] ILxDirCacheSynthetic:Lookup         obj DirCacheSyntheticEntry
// [python] ILxDirCacheSynthetic:Root           obj DirCacheSyntheticEntry
#define LXsDCSYNTH_BACKING                      "dirCacheSynthetic.backing"

#define LXsDCSYNTH_BACKING_MEMORY               "memory"
#define LXsDCSYNTH_BACKING_NETWORK_SINGLE       "network.single"
#define LXsDCSYNTH_BACKING_NETWORK_MULTIPLE     "network.multiple"
#define LXsDCSYNTH_BACKING_FILE_SINGLE          "file.single"
#define LXsDCSYNTH_BACKING_FILE_MULTIPLE        "file.multiple"
#define LXu_DIRCACHESYNTHETICENTRY      "c85d528d-50aa-4974-bbf0-6122b4e00d5b"
#define LXa_DIRCACHESYNTHETICENTRY      "dircachesyntheticentry"
// [local]  ILxDirCacheSyntheticEntry
// [export] ILxDirCacheSyntheticEntry dcsyne
// [python] ILxDirCacheSyntheticEntry:DirByIndex        obj DirCacheSyntheticEntry
// [python] ILxDirCacheSyntheticEntry:IsFile            bool
#define LXu_BASEPATHADDDEST             "1710a8c1-a493-4e65-a190-009effc4a134"
#define LXa_BASEPATHADDDEST             "basepathadddest"
//[local]  ILxBasePathAddDest
#define LXu_DIRCACHEMANUALORDERDEST     "fb69c873-9f95-4ba1-ba1f-1235307e3c88"
#define LXa_DIRCACHEMANUALORDERDEST     "dircachemanualorderdest"
//[local]  ILxDirCacheManualOrderDest
//[python] ILxDirCacheManualOrderDest:BetweenPaths      obj DirCacheEntry
#define LXu_DIRCACHEGRIDPOSDEST         "09a9db0d-131f-40ed-910a-8916a636dc36"
#define LXa_DIRCACHEGRIDPOSDEST         "dircachegridposdest"
//[local]  ILxDirCacheGridPosDest
//[python] ILxDirCacheGridPosDest:GridPos       obj DirCacheEntry
#define LXu_FILESYSDEST         "79d4f661-3249-4455-bfb9-486120c18f24"
#define LXa_FILESYSDEST         "fileSystemDestination"
//[local]  ILxFileSysDest
//[python] ILxFileSysDest:IsDir         bool
#define LXu_MERGEDFILESYSDEST           "a58450c6-5789-4072-84eb-92154d632dc2"
#define LXa_MERGEDFILESYSDEST           "mergedFileSystemDestination"
//[local]  ILxMergedFileSysDest
// [local]  ILxMergedDirCacheEntry
// [python] ILxMergedDirCacheEntry:MergedEntry          obj DirCacheEntry
// [python] ILxMergedDirCacheEntry:EntryByIndex         obj DirCacheEntry
// [python] ILxMergedDirCacheEntry:Parent               obj DirCacheEntry
#define LXsDROPSOURCE_BASEPATHENTRIES           "basePathEntries"

#define LXu_DIRBROWSERBASEPATHENTRYDEST         "56a0f290-9aca-4e44-b036-b2bbb7be28d2"
#define LXa_DIRBROWSERBASEPATHENTRYDEST         "dirBrowserBasePathEntryDest"
//[local]  ILxDirBrowserBasePathEntryDest

 #ifdef __cplusplus
  }
 #endif
#endif

