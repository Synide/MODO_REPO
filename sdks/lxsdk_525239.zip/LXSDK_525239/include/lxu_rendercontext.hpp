/*
* Plug-in SDK Header: C++ Services
*
* Copyright (c) 2008-2018 The Foundry Group LLC
* 
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"),
* to deal in the Software without restriction, including without limitation
* the rights to use, copy, modify, merge, publish, distribute, sublicense,
* and/or sell copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.   Except as contained
* in this notice, the name(s) of the above copyright holders shall not be
* used in advertising or otherwise to promote the sale, use or other dealings
* in this Software without prior written authorization.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
*
* Helper classes for implementing a custom renderer.
*/
#ifndef LX_RENDER_CONTEXT_HPP
#define LX_RENDER_CONTEXT_HPP

#include <lxidef.h>
#include <lxlocator.h>
#include <lxtableau.h>		// LXpXXX
#include <lximage.h>		// LXtImageFloat
#include <lxu_math.hpp>
#include <lx_item.hpp>
#include <lx_action.hpp>
#include <lx_shdr.hpp>
#include <lx_rendercache.hpp>

#include <vector>

namespace lx
{
        typedef std::vector< ILxUnknownID >	UnknownArray;
        typedef std::vector< float >		FloatVector;
        typedef std::vector< unsigned >		UIntVector;
}

//-----------------------------------------------------------------------------
/**
 * NOTE: directional light in MODO can be simple directional light or physical
 * sun light depending on the channel value.
 */
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Common types
//-----------------------------------------------------------------------------
extern CLxItemType	citRender;

extern CLxItemType	citLocator;
extern CLxItemType	citTransform;
extern CLxItemType	citGroupLocator;

extern CLxItemType	citCamera;
extern CLxItemType	citTextureLoc;

extern CLxItemType	citEnvironment;
extern CLxItemType	citEnvMaterial;

extern CLxItemType	citLightMaterial;
extern CLxItemType	citLight;
extern CLxItemType	citSunLight;
extern CLxItemType	citPointLight;
extern CLxItemType	citSpotLight;
extern CLxItemType	citAreaLight;
extern CLxItemType	citMeshLight;

extern CLxItemType	citMask;
extern CLxItemType	citTextureLayer;
extern CLxItemType	citAdvancedMaterial;
extern CLxItemType	citDefaultShader;
extern CLxItemType	citRenderOutput;
extern CLxItemType	citImageMap;
extern CLxItemType	citConstant;
extern CLxItemType	citShaderFolder;

extern CLxItemType	citVideoClip;
extern CLxItemType	citVideoStill;
extern CLxItemType	citVideoSequence;
extern CLxItemType	citImageLayer;


class CLxRenderSettings;
class CLxCamera;
class CLxLayerStack;
class CLxTextureLayer;
class CLxAdvMaterial;
class CLxLight;
class CLxSunLight;
class CLxPointLight;
class CLxSpotLight;
class CLxAreaLight;
class CLxEnvironment;

namespace lx
{
        class SceneListener;
}

class CLxRenderContextEvent;
class CLxRenderContextListener;

//-----------------------------------------------------------------------------
/**
 * CLxRenderContext is used to obtain rendering data (camera, lights, etc.)
 * One init
 */
//-----------------------------------------------------------------------------
class CLxRenderContext
{
public:

        CLxRenderContext();

        ~CLxRenderContext();

        /// Initialize the render context from currently selected scene and selected time
        LxResult	Init (
                                CLxRenderContextListener* listener = nullptr,
                                unsigned rcacheFlags = LXfRENDERCACHE_FULL | LXfRENDERCACHE_TRACK_CURRENT_SCENE);

        /// Get scene from render context
        LxResult	Scene (CLxUser_Scene& scene);

        /// Return channelRead object
        LxResult	Channels (CLxUser_ChannelRead& chans);

        LxResult	ChanInt (CLxUser_Item& item, const char* channel, int& value);

        LxResult	ChanFlt (CLxUser_Item& item, const char* channel, float& value);

        LxResult	ChanDbl (CLxUser_Item& item, const char* channel, double& value);

        LxResult	ChanRGB (CLxUser_Item& item, const char* channel, LXtColorRGB& value);

        LxResult	ChanRGBA (CLxUser_Item& item, const char* channel, LXtColorRGBA& value);

        LxResult	ChanStr (CLxUser_Item& item, const char* channel, const char*& value);

        /// Return render cache instance
        LxResult	RenderCache (CLxUser_RenderCache& rcache);

        /// Return number of items of given type
        int		NItems (LXtItemType type);

        /// Get items of given type
        LxResult	GetItem (CLxUser_Item& item, int index, LXtItemType type);

        /// Get all items of given type
        LxResult	GetItems(lx::UnknownArray& array, LXtItemType type);

        /// Get current render camera
        LxResult	RenderCamera (CLxCamera& cam);

        /// Get render settings
        LxResult	RenderSettings (CLxRenderSettings& settings);

        /// Get top-most material for GeoCacheSurface
        LxResult	Material (CLxUser_GeoCacheSurface& srf, CLxAdvMaterial& mat);

        /// Get layer stack for scene item (mesh, surface, etc.)
        LxResult	LayerStack (CLxUser_Item& item, CLxLayerStack& stack);

        /// Get layer stack for GeoCacheSurface
        LxResult	LayerStack (CLxUser_GeoCacheSurface& srf, CLxLayerStack& stack);

private:

        friend class lx::SceneListener;

        void		SetEvent (const CLxRenderContextEvent& event);

        CLxUser_Scene			_scene;
        CLxUser_ChannelRead		_chanTime;
        double				_time;

        CLxRenderContextListener*	_listener;
        CLxUser_RenderCache		_rcache;
};

//-----------------------------------------------------------------------------
/// Base class for handling CLxRenderContext events
//-----------------------------------------------------------------------------
class CLxRenderContextListener
{
public:

        virtual void rctx_HandleEvent (const CLxRenderContextEvent& event) = 0;
};


//-----------------------------------------------------------------------------
/// Render context event types
//-----------------------------------------------------------------------------
enum CLxRenderContextEventType
{
        LXi_RCTX_EVT_NONE = -1,

        LXi_RCTX_EVT_SCENE_CREATE,
        LXi_RCTX_EVT_SCENE_DESTROY,
        LXi_RCTX_EVT_SCENE_CLEAR,
        LXi_RCTX_EVT_SCENE_CURRENT,

        LXi_RCTX_EVT_SCENE_ITEM_ADD,
        LXi_RCTX_EVT_SCENE_ITEM_REMOVE,
        LXi_RCTX_EVT_SCENE_ITEM_UPDATE,

        LXi_RCTX_EVT_SCENE_TIME_CHANGE,

        LXi_RCTX_EVT_RCACHE_DESTROY,
        LXi_RCTX_EVT_RCACHE_CLEAR,
        LXi_RCTX_EVT_RCACHE_UPDATE_BEGIN,
        LXi_RCTX_EVT_RCACHE_UPDATE_END,
        LXi_RCTX_EVT_RCACHE_SURF_ADD,
        LXi_RCTX_EVT_RCACHE_SURF_REMOVE,
        LXi_RCTX_EVT_RCACHE_SURF_GEO_UPDATE,
        LXi_RCTX_EVT_RCACHE_SURF_XFM_UPDATE,
        LXi_RCTX_EVT_RCACHE_SURF_SHD_UPDATE,

        LXi_RCTX_EVT_COUNT
};

//-----------------------------------------------------------------------------
/// Base class for all render context events
//-----------------------------------------------------------------------------
class CLxRenderContextEvent
{
public:

        CLxRenderContextEvent (CLxRenderContextEventType type, ILxUnknownID obj)
                : _obj (obj)
                , _time (-1.0)
                , _type (type)
        {
        }

        CLxRenderContextEvent (CLxRenderContextEventType type, ILxUnknownID obj, double time)
                : _obj (obj)
                , _time (time)
                , _type (type)
        {
        }

        CLxRenderContextEventType Type () const
        {
                return _type;
        }

        ILxUnknownID	Object () const
        {
                return _obj;
        }

        double Time () const
        {
                return _time;
        }

private:

        ILxUnknownID			_obj;
        double				_time;
        CLxRenderContextEventType	_type;
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxLayerStack
{
public:

        /// Default constructor creates empty layer stack
        CLxLayerStack ();

        LxResult Init (CLxUser_GeoCacheSurface& srf, CLxRenderContext& ctx);

        /// Initialize the layer stack from item (mesh, surface, etc...) and scene channels
        LxResult Init (CLxUser_Item& item, CLxRenderContext& ctx);

        /// Return number of items of given type, by default return number of all items
        int NItems (LXtItemType type = LXiTYPE_ANY) const;

        /// Return item at index (depending on type)
        LxResult GetItem (CLxUser_Item& item, int index, LXtItemType type = LXiTYPE_ANY) const;

        /// Return all items with given type
        LxResult GetItems (lx::UnknownArray& itemArray, LXtItemType type = LXiTYPE_ANY) const;

        /// Return number of masks
        int NMasks () const;

        /// Get mask at given index
                LxResult
        GetMask (
                CLxUser_Item&			mask,
                int				index) const;

        /// Get mask at given index and all the child items by types
                LxResult 
        GetMask (
                CLxUser_Item&			mask,
                int				index,
                LXtItemType			types[],
                lx::UnknownArray*		typeArrays[],
                unsigned			nTypes) const;

        /// Get mask at given index and all the child items
                LxResult 
        GetMask (
                CLxUser_Item&			mask,
                int				index,
                lx::UnknownArray&		children) const;

        /// Get image with given effect. If effect is not set returns first image found.
        LxResult GetImage (CLxUser_Item& image, const char* fxName = NULL) const;

        /// Print stack items to log
        void Print ();

private:

        void AddChildren (CLxUser_Item& item);

        bool IsEnabled (CLxUser_Item& item) const;

        mutable CLxUser_ChannelRead	_chans;
        std::vector< ILxUnknownID >	_items;
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxRenderSettings
{
public:

        unsigned	renderType;
        unsigned	aa;
        unsigned	aaFilter;
        float		aaImpMin;
        float		coarseRate;
        float		fineRate;
        float		fineThresh;
        unsigned	bktRefine;
        unsigned	aRefine;
        unsigned	mergeRad;
        unsigned	field;
        unsigned	bucketX;
        unsigned	bucketY;
        unsigned	bktOrder;
        unsigned	bktReverse;
        unsigned	bktWrite;
        unsigned	bktSkip;
        unsigned	frmPasses;
        unsigned	bakeDir;
        float		progConv;		//!< [percent] Progressive render convergence
        float		progTime;		//!< [float] Progressive render maximum render time (in minutes)

        unsigned	outputMasking;	
        
        LXtColorRGB	ambColor;
        float		ambRad;
        unsigned	globEnable;		//!< [boolean]
        unsigned	globScope;		//!< [integer]
        unsigned	globLimit;		//!< [integer]
        unsigned	globRays;		//!< [integer]
        float		globRange;		//!< [distance]
        unsigned	globSubs;		//!< [integer]
        unsigned	globVols;		//!< [boolean]
        unsigned	globBump;		//!< [boolean]
        unsigned	globSuper;		//!< [boolean]
        unsigned	globReject;		//!< [boolean]
        unsigned	globCaus;		//!< [integer]

        unsigned	irrCache;		//!< [integer]
        unsigned	irrUsage;
        unsigned	irrDirect2;
        unsigned	irrRays;
        unsigned	irrRays2;
        unsigned	irrRate;
        unsigned	irrRatio;
        unsigned	irrSmooth;
        unsigned	irrRetrace;
        unsigned	irrVals;
        unsigned	irrGrads;
        unsigned	irrSample;
        unsigned	irrData;
        unsigned	irrStart;
        unsigned	irrEnd;
        unsigned	irrWalk;
        unsigned	irrLEnable;
        unsigned	irrSEnable;
        const char*	irssLName;
        const char*	irssSName;

        unsigned	radCache;
        unsigned	envSample;
        unsigned	envRays;
        unsigned	envMIS;

        unsigned	causEnable;
        float		causMult;
        unsigned	causTotal;
        unsigned	causLocal;
        unsigned	causWalk;

        unsigned	rayShadow;
        unsigned	reflDepth;
        unsigned	refrDepth;
        float		rayThresh;
        unsigned	unbiased;
        float		rayClamp;
        float		rayOffset;
        unsigned	reflSmps;
        unsigned	refrSmps;
        unsigned	specSmps;
        unsigned	subsSmps;
        unsigned	animNoise;
        unsigned	noiseSeed;
        unsigned	rayAccel;
        unsigned	batchSize;
        unsigned	impBoost;
        unsigned	directSmps;
        unsigned	directMIS;
        unsigned	multiGeo;
        unsigned	mergeFur;
        unsigned	subdAdapt;
        float		subdRate;
        unsigned	dispEnable;
        float		dispRate;
        float		dispRatio;
        float		dispJitter;
        float		edgeMin;
        unsigned	dispSmooth;
        unsigned	dispBump;
        unsigned	camera;

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
/**
 * Every light has a light material
 */
//-----------------------------------------------------------------------------
class CLxLightMaterial
{
public:
        ILxUnknownID		item;

        LXtColorRGB		color;		//!< [color]   Light color
        float			diffuse;	//!< [percent] Diffuse percent
        float			specular;	//!< [percent] Specular percent
        float			caustics;	//!< [percent] Cuastics percent
        float			subsurface;	//!< [percent] Subsurface percent
        LXtColorRGB		shadCol;	//!< [color]   Shadowing color
        LXtColorRGB		scatCol;	//!< [color]   Volumetric scattering color
        float			scatter;	//!< [percent] Volumetric scattering percent
        float			density;	//!< [percent] Volumetric density percent
        float			attenuate;	//!< [percent] Volumetric light attenuation percent
        float			shift;		//!< [percent] Volumetric light shift percent

        CLxLightMaterial ();

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxLight
{
public:

        CLxLightMaterial	material;

        ILxUnknownID		item;

        LXtMatrix		xfrm;		//!< Rotation matrix in world space
        LXtVector		wpos;		//!< Translation in world space

        float			radiance;	//!< [light] The radiance of the light which modulates the color.
        int			fallType;	//!< [integer] Falloff type for light intensity.  The default is inverse distance squared. LXsICVAL_LIGHT_FALLTYPE_XXX (NONE, INVDIST, INVDIST2)
        float			range;		//!< [gradient:distance->percent] Gradient falloff for light intensity (radiance). Total intensity is modulated by this percentage as a function of distance.
        int			shadType;	//!< [integer] Shadow type LXiICVAL_LIGHT_SHADTYPE_XXX (NONE, RAY, MAP, PORTAL)
        int			shadRes;	//!< [integer] Shadow map (depth buffer) resolution
        float			shadSpot;	//!< [float] Shadow spot size, used for shadow map filtering.
        int			samples;	//!< [integer] Number of samples for distributed lights.
        float			importance;	//!< [percentage] Multiplier to increase or decrease importance used for light sample allocation.
        int			visCam;		//!< [boolean] true if the light should create luminous geometry visible to the camera reflections, or refractions.
        int			visRefl;	//!< [boolean] true if the light should create luminous geometry visible to the reflections or refractions.
        int			visRefr;	//!< [boolean] true if the light should create luminous geometry visible to the refractions.
        float			target;		//!< [distance]
//	int			linkEnable;	//!< [boolean]
//	int			linkMode;	//!< [integer]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);

        LXtItemType Type () const
        {
                if (item)
                {
                        CLxUser_Item	itm (item);

                        return itm.Type ();
                }
                
                return LXiTYPE_NONE;
        }
};

//-----------------------------------------------------------------------------
/** NOTE that LXSunLight is by default simple directional light unless sunPos 
 * channel is set to true.
 */
//-----------------------------------------------------------------------------
class CLxSunLight : public CLxLight
{
public:
        
        float			spread;		//!< [angle]
        float			mapSize;	//!< [distance]
        
        // Below are physical sun channels
        int			sunPos;		//!< [boolean] Enable physical sun positioning based on date/time/gps, if false the light is directional light
        float			lon;		//!< [angle] // Lux HQ: 122 18'5.4" W Long. = 122.3015 deg = 2.134563855 radians
        float			lat;		//!< [angle] // Lux HQ: 37 33' 30.87" N Lat. = 37.532 deg = 0.655057 radians
        int			day;		//!< [date]  day-of-year 6/21 longest day, use GetDate() to get day, month and year
        float			time;		//!< [timeofday] time of day 
        float			azimuth;	//!< [angle] // computed results
        float			elevation;	//!< [angle]
        float			haze;		//!< [float] turbidity
        int			clamp;		//!< [integer] disable full physical intensity
        float			north;		//!< [angle] offset of north direction
        float			timeZone;	//!< [float] // SF timezone (offset from GMT, WEST NEGATIVE)
        float			height;		//!< [distance]
        float			radius;		//!< [distance]
        int			thinning;	//!< [boolean]
        int			summerTime;	//!< [boolean]
        float			gamma;		//!< [float]	gamma
        int			useWorldXfrm;	//!< [boolean]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);

        // Given the date (obtained from CLxSunLight::day), it returns day of the year
        static int GetDate (const int date);
};


//-----------------------------------------------------------------------------
// To keep things consistent with SDK the DirectionalLight is same as SunLight
//-----------------------------------------------------------------------------
typedef CLxSunLight CLxDirectionaLight;

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxPointLight : public CLxLight
{
public:

        float			radius;		//!< [distance]
        float			vrad;		//!< [distance]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxSpotLight : public CLxLight
{
public:

        float			radius;		//!< [distance]
        float			cone;		//!< [angle]
        float			edge;		//!< [angle]
        int			outside;	//!< [boolean]
        float			height;		//!< [distance]
        float			base;		//!< [distance]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxAreaLight : public CLxLight
{
public:

        int			shape;		//!< [integer] One of the LXi_AREALIGHT_SHAPE_XXX
        float			width;		//!< [distance]
        float			height;		//!< [distance]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxMeshLight : public CLxLight
{
public:

        struct Geo
        {
                lx::FloatVector*	vPos;
                lx::FloatVector*	vNrm;
                lx::UIntVector*	tris;

                unsigned	nTris, nVrts;

                Geo ()
                        : vPos (NULL)
                        , vNrm (NULL)
                        , tris (NULL)
                        , nTris (0)
                        , nVrts (0)
                {
                }

                Geo (lx::FloatVector* pos, lx::FloatVector* nrm, lx::UIntVector* tri)
                        : vPos (pos)
                        , vNrm (nrm)
                        , tris (tri)
                        , nTris (0)
                        , nVrts (0)
                {
                }
        };

        ILxUnknownID		meshItem;	//!< [object] CLxUser_Item

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);

        // NOTE: CLxUser_Surface requires to be initialied in the main thread, otherwise we can get the empty geometry.
        //       Just call this method in the main thread durint light scan and then it's safe to  call GetGeo() later
        //       in the render thread(s).
        LxResult PrepareGeo (CLxUser_ChannelRead& chan);

        LxResult GetGeo (CLxUser_ChannelRead& chan, Geo& geo);
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxCamera
{
public:

        ILxUnknownID		item;

        LXtFVector              eyePos;
        LXtMatrix               xfrm, invXfrm;
        float                   focalLength;
        int                     dof;
        float                   focusDist, fStop;
        float                   irisRot, irisBias, distort;
        float                   ioDist, convDist;
        float                   blurLength, blurOffset;
        float                   apertureX, apertureY;
        float                   offsetX, offsetY;
        float                   squeeze;
        float                   target;
        float                   clipDist;
        int                     clipping;
        int                     filmFit;
        int                     projType;						//!< LXiICVAL_CAMERA_PROJTYPE_XXX
        int                     irisBlades;
        int                     useMask;
        float                   overscan;

        unsigned int            width;
        unsigned int            height;
        float                   pixelAspect;
        float                   dpi;
//      float                   samples;
//      float                   rate;
        float                   regX0, regX1, regY0, regY1;

        // Defeault constructor
        CLxCamera ();

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
/** TextureLayer data
 * - enable: Allows you to temporarily enable/disable a layer without losing stored values
 * - invert: This setting inverts any RGB color values specified in the environment material
 * - blendMode: Affects blending between material layers allowing you to stack several layers for different effects.
 * - opacity: At 100% (1.0) a layer is completely opaque, values below 100% change the transparency of the current
 *      material layer allowing other lower layers to become visible, ramping toward completely transparent at 0% essentially disabling the layer.
 *      If only one environment material is present, modifying the opacity fades the brightness of the background and affects how much it contributes to global illumination.
 */
//-----------------------------------------------------------------------------
class CLxTextureLayer
{
public:

        int			enable;		//!< [boolean]
        float			opacity;	//!< [percent]
        int			blend;		//!< [integer]	LXi_TEXLAYER_BLEND_XXX
        int			invert;		//!< [boolean]
        const char*		effect;		//!< [string]
        
        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);

};

//-----------------------------------------------------------------------------
/// AdvancedMaterial
//-----------------------------------------------------------------------------
class CLxAdvMaterial : public CLxTextureLayer
{
public:

        ILxUnknownID		item;

        LXtColorRGB		diffCol;		//!< [color]
        float			diffAmt;		//!< [percent]
        LXtColorRGB		specCol;		//!< [color]
        float			specAmt;		//!< [percent]
        LXtColorRGB		reflCol;		//!< [color]
        float			reflAmt;		//!< [percent]
        LXtColorRGB		tranCol;		//!< [color]
        float			tranAmt;		//!< [percent]
        LXtColorRGB		subsCol;		//!< [color]
        float			subsAmt;		//!< [percent]
        LXtColorRGB		lumiCol;		//!< [color]
        float			radiance;		//!< [percent]
        LXtColorRGB		exitCol;		//!< [color]
        float			coatAmt;		//!< [percent]
        float			dissAmt;		//!< [percent]
        float			diffRough;		//!< [percent]
        float			rough;			//!< [percent]
        float			coatRough;		//!< [percent]
        float			coatBump;		//!< [percent]
        float			aniso;			//!< [percent]
        float			specFres;		//!< [percent]
        float			reflFres;		//!< [percent]
        float			refIndex;		//!< [float]
        float			disperse;		//!< [float]
        float			tranRough;		//!< [percent]
        float			tranDist;		//!< [distance]
        float			subsDist;		//!< [distance]
        float			subsDepth;		//!< [distance]
        float			subsPhase;		//!< [percent]
        float			bump;			//!< [percent]
        float			bumpAmp;		//!< [distance]
        float			displace;		//!< [distance]
        float			smooth;			//!< [percent]
        float			smAngle;		//!< [angle]
        float			rndWidth;		//!< [distance]
        float			rndAngle;		//!< [angle]
        LXtColorRGB		clipCol;		//!< [color]
        float			clipValue;		//!< [percent]
        float			importance;		//!< [percent]
        LXtColorRGB		scatterCol;		//!< [color]
        float			scatterAmt;		//!< [percent]
        LXtColorRGB		absorbCol;		//!< [color]
        float			absorbAmt;		//!< [percent]
        float			density;		//!< [percent]
        float			redShift;		//!< [percent]
        LXtColorRGB		luminousCol;		//!< [color]
        float			luminousAmt;		//!< [percent]
        float			sheen;			//!< [percent], default is 0.0, min is 0.0
        float			sheenTint;		//!< [percent], default is 0.0, min is 0.0
        float			specTint;		//!< [percent], default is 0.0, min is 0.0
        float			flatness;		//!< [percent], default is 0.0, min is 0.0
        float			metallic;		//!< [percent], default is 0.0, [0.0 - 1.0]


        float			bumpVal;		//!< [percent]
        float			dispVal;		//!< [percent]
        float			stenVal;		//!< [percent]

        int			dblSided;		//!< [boolean]
        int			brdfType;		//!< [integer] LXi_BRDFTYPE_XXX
        int			useRefIdx;		//!< [boolean]
        int			reflSpec;		//!< [boolean]
        int			reflType;		//!< [integer] LXi_REFLTYPE_XXX
        int			reflBlur;		//!< [boolean]
        int			reflRays;		//!< [integer]
        int			tranRays;		//!< [integer]
        int			subsSmps;		//!< [integer]
        int			sameSurf;		//!< [boolean]
        int			rndSame;		//!< [boolean]
        int			clearBump;		//!< [boolean]
        int			clipMatte;		//!< [boolean]
        int			clipEnable;		//!< [boolean]
        int			radInter;		//!< [boolean]

//	CPDxCUST ("uvMap", "string"), CPDxSTORE (NULL),

        CLxAdvMaterial ();

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);	
};

//-----------------------------------------------------------------------------
/// DefaultShader
//-----------------------------------------------------------------------------
class CLxDefaultShader : public CLxTextureLayer
{
public:

        float		shadeRate;	//!< [fpixel]  CPDxIHINT(shadeRateHint)
        float		dirMult;	//!< [percent] 
        float		indMult;	//!< [percent] 
        float		indSat;		//!< [percent] 
        float		indSatOut;	//!< [percent] 
        int		indType;	//!< [integer] CPDxIHINT(indTypeHint)
        int		fogType;	//!< [integer] CPDxIHINT(fogTypeHint)
        int		fogEnv;		//!< [boolean] 
        LXtColorRGB	fogColor;	//!< [color]	
        float		fogStart;	//!< [distance]
        float		fogEnd;		//!< [distance]
        float		fogDensity;	//!< [percent] 
        int		alphaType;	//!< [integer] CPDxIHINT(alphaTypeHint)
        float		alphaVal;	//!< [percent] 
        int		lightLink;	//!< [integer]
        int		shadCast;	//!< [boolean] 
        int		shadRecv;	//!< [boolean] 
        int		visCam;		//!< [boolean] 
        int		visInd;		//!< [boolean] 
        int		visRefl;	//!< [boolean] 
        int		visRefr;	//!< [boolean] 
        int		visOccl;	//!< [boolean] 
        int		quaEnable;	//!< [boolean] 
        int		visEnable;	//!< [boolean] 
        int		lgtEnable;	//!< [boolean] 
        int		fogEnable;	//!< [boolean] 
        int		shdEnable;	//!< [boolean] 

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxImageMap : public CLxTextureLayer
{
public:

        ILxUnknownID		item;
        ILxUnknownID		txtrLocItem;
        ILxUnknownID		clipItem;

        int			aa;         //!< [boolean]
        float			aaVal;      //!< [percent]
        int			pixBlend;   //!< [integer]	LXi_IMAGEMAP_PIXBLEND_XXX
        float			minSpot;    //!< [float]
        float			min;	    //!< [percent]
        float			max;        //!< [percent]
        float			sourceLow;  //!< [float]
        float			sourceHigh; //!< [float]
        int			redInv;     //!< [boolean]
        int			greenInv;   //!< [boolean]
        int			blueInv;    //!< [boolean]
        float			gamma;      //!< [float]
        int			swizzling;  //!< [boolean]
        int			alpha;      //!< [integer]	IMAGEMAP_SWIZZLING_RGB, IMAGEMAP_SWIZZLING_RGBA, IMAGEMAP_SWIZZLING_ALPHA_ONLY
        int			rgba;       //!< [integer]	IMAGEMAP_SWIZZLING_RGB, IMAGEMAP_SWIZZLING_RGBA, IMAGEMAP_SWIZZLING_ALPHA_ONLY, IMAGEMAP_SWIZZLING_RED_ONLY, IMAGEMAP_SWIZZLING_GREEN_ONLY, IMAGEMAP_SWIZZLING_BLUE_ONLY

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

//-----------------------------------------------------------------------------
// Mask
//-----------------------------------------------------------------------------
class CLxMaterialGroup : public CLxTextureLayer
{
public:

        ILxUnknownID		item;

        const char*	ptag;
        const char*	ptyp;
        int		submask;
        int		surfType;
        int		addLayer;
        int		instApply;

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);

        // Returns items that this material group should be applied to
        LxResult Items (lx::UnknownArray& items);
};

//-----------------------------------------------------------------------------
/** EnvironmentMaterial data
 * type: Environment Type - Specifies colors and gradients that appear in the background LXi_ENVMATERIAL_ENVTYPE_XXX
 *       4 Color Gradient: This easy to use gradient allows you to set 4 color values which are used to simulate the sky and ground.
 *                         The Zenith color is the color that is directly overhead and this ramps into the Sky color which starts 
 *                         at the horizon and ramps upward. 
 *                         The Nadir color is directly below the camera and ramps upwards into the Ground color which terminates 
 *                         at the horizon when it meets the Sky color. 
 *                         There is a soft blend between the Zenith and Sky colors and a soft blend between Ground and Nadir. 
 *                         The boundary between Ground and Sky is hard edged to give the illusion of a distant horizon. 
 *                         When using a 4 Color Gradient, the Sky and Ground Exponents are used to compress or expand the gradation 
 *                         between Zenith and Sky and the Nadir and Ground.
 *                         Higher values push the gradient transition closer to the horizon, while lower values spread the gradient 
 *                         further across the available spectrum.
 *
 *       2 Color Gradient: This option reduces the colors to Zenith and Nadir and creates a soft ramp between the two.
 *
 *       Constant: Uses only the Zenith color for the entire background.
 *
 *       CIE Overcast Sky: This option provides two user defined color values; Zenith and Nadir. The Nadir color is used in without 
 *                         any ramp effect for everything below the horizon. 
 *                         The Zenith color starts directly above the camera and then has a slight ramp to a somewhat darker color. 
 *                         By definition the CIE overcast sky is three times brighter at the Zenith than it is at the horizon, so 
 *                         the Zenith color is reduced in brightness by that amount by the time it reaches the horizon. 
 *                         When this setting is applied with global illumination, you can re-create the traditional overcast render 
 *                         look popular in images that want to show off an untextured model's surface detailing.
 *
 *       Physically-based Daylight: This option works in tandem with global illumination to create renders lit by an incredibly 
 *                                  realistic daylight simulation.Especially useful for architectural exterior and interior renders 
 *                                  or in any scene that needs nice outdoor lighting. 
 *                                  
 *
 * Physically-based Daylight (LXi_ENVMATERIAL_ENVTYPE_PHYSICAL)
 * When Physically-based Daylight is selected as the Environment Type, a few additional options become available, allowing you to 
   fine-tune the look of the lighting simulation. 
 * Global illumination needs to be enabled in order for the Physically-based Daylight function to work.
 *    sunLight: Sun Light
 *              This setting allows you to set a distant light that are considered the sun in the rendered images. 
 *
 *    dics: Solar Disc Size
 *          A small disk is added to the rendered image, representing the actual sun, above the horizon. It also appears 
 *          in reflections, refractions and so on. The default value of 100% is correct to the scale of what you see in 
 *          the real world, however, you can change the size depending on your particular scene needs using this setting.
 *
 *    haze: Haze Amount
 *          In the real world, as the sun nears the horizon, light has to pass through a greater amount of atmosphere to 
 *          reach our eyes, additionally, moisture, dust and pollutants in the air further affect the light. The further the 
 *          light has to pass through these particles, the more shorter wavelengths of light are absorbed, tending the light 
 *          toward warmer hues. Increasing the Haze setting in Modo pushes the horizon colors toward oranges and yellows 
 *          for midday lighting scenarios and deeper reds (sunsets) in evening times. Time of day can be controlled in the 
 *          distant light's Physical Sun settings.
 *
 *    normalize: Clamp Sky Brightness
 *           The Physically-based Daylight function is a highly accurate lighting simulation generating 
 *           light intensities outside of normal render display settings. 
 *           The Clamp Sky Brightness toggle limits the overall brightness of the sky, producing pleasing results 
 *           more easily. When disabled, you might think your scene is completely 'blown out' and overexposed, but 
 *           actually, since Modo renders in full floating point accuracy, you can bring back all that detail 
 *           using a combination of white level, gamma and tone mapping.
 *
 *    clamppedGamma: Sky Gamma
 *          Adjusting gamma is the ability to adjust the overall contrast of a target in a non-linear fashion. 
 *          The Sky Gamma option allows you to adjust the values of the procedurally generated Physically-based Sky lightening 
 *          or darkening it for artistic refinement.
 *
 *    albedoCol: Ground Albedo
 *          This option represents the color of any light reflected from the ground upwards in the overall environmental 
 *          light simulation. You can specify an appropriate scene-specific color using the RGB color navigator. 
 *          The Albedo is color only, having no brightness in the calculation, so RGB values between 0-1 (1-255) are the 
 *          most appropriate.
 *
 *    inscatter: Disc In-Scatter
 *          Mixes in light that has been deflected or scattered out of the direct path from the sun, then gets scattered
 *          back in. This results in a reddish cast around the edge of the solar disc (known as limb-darkening), and 
 *          producing a reddening toward the bottom at low elevations (near sunrise or sunset). This is increasingly 
 *          more noticeable at higher haze levels. A setting of 100% shows the physically correct result attenuating 
 *          toward 0%, which disables the effect, making the solar disc appear as it did in previous versions.
 *
 * The Environment Fog option produces a simulated (non-volumetric) fog effect by applying the environment color to 
 * relevant materials with increased intensity as the geometry is further from the camera. This is also a great option
 * to fade objects into a background, increasing the apparent depth (and scale) of a scene. Fog can also be specified 
 * in the Shader item with similar options. The Environment Fog option differs in that it always uses the the environment 
 * color, whereas for the Shader Fog, any color can be specified.
 *    fogType: Fog Type
 *             Allows you to choose from the different fog types:
 *             None: Disables Environment Fog from rendering.
 *
 *             Linear: When selected, fog renders in the scene based on the Start and End distances, where there is no 
 *                     fog up to the starting distance, then surfaces attenuate toward a solid environment color and 
 *                     maximum fog density at the end distance.
 *
 *             Exponential: When selected, fog renders starting at the camera's position, increasing in strength the 
 *                          further a surface is from the camera. Based on exponential values, the strength increases 
 *                          non-linearly and is directly influenced by the Fog Density setting (so for very large scenes,
 *                          you should use a very small value).
 *
 *             Underwater: This option is basically the same as the Exponential function, except that the fog has a 
 *                         tendency to absorb the environment color more readily, producing an environment colored cast. 
 *                         It also reduces color saturation with distance. The example above is a late afternoon environment, 
 *                         so the reds of the setting sun influence the fog color. For a true underwater look, set the 
 *                         environment to a 2 or 4 color gradient with a blueish or teal color, or apply Shader Fog and 
 *                         define the Fog color independent of the environment.
 *
 *             Layered: Produces a ground fog-like effect where the fog density increases with both depth and height.
 *
 *   fogStart/fogEnd:Fog Start/End Distance
 *                   When the Fog type is set to Linear, you can specify specific starting and ending distances for the fog effect.
 *
 *   fogDensity: Fog Density
 *               This percentage value determines how thick the fog is just in front of the camera. 
 *               The default value of 10% indicates that geometry just in front of the camera has a 10% blend of the fog color. 
 *               The density of the fog increases as it recedes further from the camera.
 *
 *    fogFalloff: Altitude Falloff
 *               This option determines the maximum height of the fog when using the Layered Fog option. 
 *               Fog attenuates from the Base Altitude, fading from maximum density at the base to fully transparent at the 
 *               defined Altitude Falloff value.
 *
 *    fogHeight: Base Altitude
 *               Defines the bottom of the layered fog. Anything below has fog applied up to the maximum density 
 *               (based on distance from camera), and above this value fully attenuates up to the Altitude Falloff.
 */
//-----------------------------------------------------------------------------
class CLxEnvMaterial : public CLxTextureLayer
{
public:

        ILxUnknownID		item;

        int			type;		//!< [integer] LXi_ENVMATERIAL_ENVTYPE_XXX
        LXtColorRGB		zenColor;	//!< [color]
        LXtColorRGB		skyColor;	//!< [color]
        LXtColorRGB		gndColor;	//!< [color]
        LXtColorRGB		nadColor;	//!< [color]
        float			skyExp;		//!< [float]
        float			gndExp;		//!< [float]

        // Physically-based Daylight
        ILxUnknownID		sunLight;	//!< sunLight item connected to this environment material
        float			disc;		//!< [percent]
        float			haze;		//!< [float]
        int			normalize;	//!< [boolean]
        float			clampedGamma;	//!< [float]
        LXtColorRGB		albedoCol;	//!< [color] Ground albedo
        LXtColorRGB		discCol;	//!< [color]
        float			inscatter;	//!< [percent]

        // Environment fog
        int			fogType;	//!< [integer]
        float			fogStart;	//!< [distance]
        float			fogEnd;		//!< [distance]
        float			fogDensity;	//!< [percent]
        float			fogHeight;	//!< [distance]
        float			fogFalloff;	//!< [percent]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};


//-----------------------------------------------------------------------------
/**
 * Environment data
 *    radiance: Acts as a multiplier, providing you with a convenient way to 
 *              control and modify the overall brightness of the Environment. 
 *              This setting has the greatest effect when global illumination 
 *              is enabled, controlling to what degree the overall environment 
 *              contributes to the lighting of the scene.
 *
 *    visCam: Visible to Camera - Toggles whether or not the selected Environment 
 *            is visible to the camera when rendered. This setting is independent 
 *            to the others, even when not visible to the camera, it can still 
 *            contribute to the lighting of the scene providing you with the 
 *            ability to specify alternate images or textures for the background 
 *            in an additional environment item.
 *
 *    visInd: Visible to Indirect Rays - Toggles whether or not the Environment 
 *            contributes lighting to global illumination. 
 *            This setting only affects scenes that have Global Illumination enabled.
 *
 *    visRefl: Visible to Reflection Rays - Toggles whether or not environments 
 *             have an effect on any reflective surfaces within a scene.
 *             
 *    visRef: Visible to Refraction Rays - Toggles whether or not environments 
 *            have an effect on any refractive surfaces within a scene.
 */
//-----------------------------------------------------------------------------
class CLxEnvironment
{
public:

        ILxUnknownID		item;

        float			radiance;	//!< [radiance in W/srm2] 	
        int			visCam;		//!< [boolean]
        int			visInd;		//!< [boolean]
        int			visRefl;	//!< [boolean]
        int			visRefr;	//!< [boolean]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
};

class CLxUser_Image;

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxVideoClip
{
public:

        ILxUnknownID		item;

        LXtObjectID		imageStack;		//!< [object]
        int			interlace;		//!< [integer]
        int			alphaMode;		//!< [boolean]
        float			fps;			//!< [float]
        int			udim;			//!< [integer]
        const char*		colorspace;		//!< [string]
        int			enable;			//!< [boolean]
        float			opacity;		//!< [percent]
        int			blend;			//!< [integer]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);

        LxResult GetImage (CLxUser_Image& image, LXtImageMetrics* metrics);

        virtual ~CLxVideoClip(); // CLxVideoClip is a base class
        
protected:
        virtual void zero_members(); // since you can't memset a class instance with a vtable
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxVideoStill : public CLxVideoClip
{
public:

        const char*		filename;		//!< [filepath]
        const char*		format;			//!< [string]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
        
protected:
        void zero_members() override;
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxVideoSequence : public CLxVideoClip
{
public:

        const char*	pattern;			//!< [string]
        int		firstFrame;			//!< [integer]
        int		lastFrame;			//!< [integer]
        int		startFrame;			//!< [integer]
        int		endBehavior;			//!< [integer]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
        
protected:
        void zero_members() override;
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxImageLayer : public CLxVideoClip
{
public:

        const char*	filename;			//!< [filepath]
        int		layer;				//!< [integer]
        const char*	type;				//!< [string]

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);
        
protected:
        void zero_members() override;
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class CLxTextureLoc
{
public:
        ILxUnknownID	item;

        int		projType;		//<! [integer]	LXi_TEXTURE_PROJ_MODE_XXX (lxshade.h)
        int		projAxis;		//!< [axis]	LXi_TEXTURE_PROJ_DIR_XXX (lxshade.h)
        int		tileU;			//!< [integer]	LXiTILE_XXX (lxvector.h)
        float		wrapU;			//!< [float]
        int		tileV;			//!< [integer]	LXiTILE_XXX (lxvector.h)
        float		wrapV;			//!< [float]
        int		world;			//!< [boolean]
        int		fallType;		//!< [integer]	LXi_TEXTURE_FALLOFF_XXX (lxtxtr.hpp)
        float		falloff;		//!< [float]
        const char*	uvMap;			//!< [string]
        LXtObjectID	stack;			//!< [object]
        float		m00;			//!< [float]
        float		m01;			//!< [float]
        float		m02;			//!< [float]
        float		m10;			//!< [float]
        float		m11;			//!< [float]
        float		m12;			//!< [float]
        float		m20;			//!< [float]
        float		m21;			//!< [float]
        float		m22;			//!< [float]
        int		worldXfrm;		//!< [boolean]
        int		legacyRotation;		//!< [boolean]
        float		psize;			//!< [float]
        float		bias;			//!< [percent]
        float		gain;			//!< [percent]
        float		sizeRandom;		//!< [percent]
        int		rotation;		//!< [angle]
        int		rotRandom;		//!< [angle]
        int		localProjection;	//!< [boolean]
        int		localNormal;		//!< [boolean]
        float		textureOffsetAmplitude;	//!< [float]
        int		uvRotation;		//!< [angle]
        int		useUDIM;		//!< [boolean]
        int		legacyUVRotation;	//!< [boolean]
        int		tngtType;		//!< [integer]	LXiTANGENT_DPDU_XXX (lxvector.h)
        int		randoffset;		//!< [integer]	LXi_TEXTURE_RNDOFFSET_XXX (lxtxtr.h)
        int		useOcclusion;		//!< [boolean]
        const char*	vectorMap;		//!< [string]
        float		overscan;		//!< [percent]

        LXtMatrix4	uvMat;			//!< Matrix from m00 : m22 members, applied in UV space
        LXtMatrix4	uvRotMat;		//!< Matrix for UV rotation, applied in UV space
        LXtMatrix4	xformMat;		//!< Transformation matrix if worldXform is set than this is in world space, otherwise it's same as local xform matrix

        LxResult Init (CLxUser_Item& item, CLxUser_ChannelRead& chan);

        ~CLxTextureLoc();
};

// Utility functions
namespace lx
{
        extern bool GetEnvironmentForEnvMaterial (CLxUser_Item& envMat, CLxUser_Item& env);
}

#endif

