/*
 * LX tree module
 *
 * Copyright (c) 2008-2019 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_tree_H
#define LX_tree_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxTree ** ILxTreeID;
typedef struct vt_ILxTreeListener ** ILxTreeListenerID;
typedef struct vt_ILxTreeListener1 ** ILxTreeListener1ID;




typedef struct vt_ILxTree {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        Spawn) (
                LXtObjectID               self,
                unsigned                  mode,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ToParent) (
                LXtObjectID      self);

                LXxMETHOD(  LxResult,
        ToChild) (
                LXtObjectID      self);

                LXxMETHOD(  LxResult,
        ToRoot) (
                LXtObjectID      self);
                LXxMETHOD(  LxResult,
        IsRoot) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        ChildIsLeaf) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        Count) (
                LXtObjectID              self,
                unsigned                *count);
                LXxMETHOD(  LxResult,
        Current) (
                LXtObjectID              self,
                unsigned                *index);

                LXxMETHOD(  LxResult,
        SetCurrent) (
                LXtObjectID              self,
                unsigned                 index);
                LXxMETHOD( LxResult,
        ItemState) (
                LXtObjectID              self,
                const char              *guid,
                int                     *state);

                LXxMETHOD( LxResult,
        SetItemState) (
                LXtObjectID              self,
                const char              *guid,
                int                      state);
} ILxTree;
typedef struct vt_ILxTreeListener {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        NewAttributes) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        NewShape) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        NewSpaceForThumbnails) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        ClearCachedThumbnail) (
                LXtObjectID              self,
                const char              *ident);

                LXxMETHOD(  LxResult,
        ClearAllCachedThumbnails) (
                LXtObjectID              self);
                LXxMETHOD(  LxResult,
        NewShowDescriptionText) (
                LXtObjectID              self);
} ILxTreeListener;
typedef struct vt_ILxTreeListener1 {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        NewAttributes) (
                LXtObjectID              self);

                LXxMETHOD(  LxResult,
        NewShape) (
                LXtObjectID              self);
} ILxTreeListener1;

#define LXiTREE_CLONE    0
#define LXiTREE_PARENT   1
#define LXiTREE_CHILD    2
#define LXiTREE_ROOT     3
#define LXfTREEITEM_ATTRIB                       0x00000001
#define LXfTREEITEM_EXPANDED                     0x00000002
#define LXfTREEITEM_ATTREXP                      0x00000004

#define LXfTREEITEM_HIDDEN                       0x00000008

#define LXfTREEITEM_FILTERED                     0x00000040
#define LXfTREEITEM_FILTER_SKIP                  0x00000080
#define LXfTREEITEM_FILTER_EXPANDED              0x00000100
#define LXfTREEITEM_FILTER_ATTREXP               0x00000200
#define LXfTREEITEM_FILTER_EXPANDED_BY_USER      0x00000400
#define LXfTREEITEM_FILTER_ATTREXP_BY_USER       0x00000800

#define LXfTREEITEM_CLIENT                       0xFF000000                                                                                     // Reserved for client use

#define LXfTREEITEM_EXPFLAGS                     (LXfTREEITEM_EXPANDED | LXfTREEITEM_ATTREXP)                                                   // Expansion flags
#define LXfTREEITEM_FILTER_EXPFLAGS              (LXfTREEITEM_FILTER_EXPANDED | LXfTREEITEM_FILTER_ATTREXP)                                     // Expanded due to filtering
#define LXfTREEITEM_FILTER_EXPFLAGS_BY_USER      (LXfTREEITEM_FILTER_EXPANDED_BY_USER | LXfTREEITEM_FILTER_ATTREXP_BY_USER)                     // Expanded by user during filtering
#define LXfTREEITEM_FILTER_FLAGS                 (LXfTREEITEM_FILTER_EXPFLAGS | LXfTREEITEM_FILTER_EXPFLAGS_BY_USER | LXfTREEITEM_FILTERED)     // All flags used for filtering
#define LXfTREEITEM_SETFLAGS                     (LXfTREEITEM_EXPFLAGS | LXfTREEITEM_FILTER_FLAGS)                                              // All flags that may be passed to SETFLAGS
#define LXmTREEITEM_ROWCOLOR_MASK                0x001F0000             // The bits used for a colors
#define LXfTREEITEM_ROWCOLOR_NONE                0x00000000             // No color
#define LXfTREEITEM_ROWCOLOR_RED                 0x00010000
#define LXfTREEITEM_ROWCOLOR_MAGENTA             0x00020000
#define LXfTREEITEM_ROWCOLOR_PINK                0x00030000
#define LXfTREEITEM_ROWCOLOR_BROWN               0x00040000
#define LXfTREEITEM_ROWCOLOR_ORANGE              0x00050000
#define LXfTREEITEM_ROWCOLOR_YELLOW              0x00060000
#define LXfTREEITEM_ROWCOLOR_GREEN               0x00070000
#define LXfTREEITEM_ROWCOLOR_LIGHT_GREEN         0x00080000
#define LXfTREEITEM_ROWCOLOR_CYAN                0x00090000
#define LXfTREEITEM_ROWCOLOR_BLUE                0x000A0000
#define LXfTREEITEM_ROWCOLOR_LIGHT_BLUE          0x000B0000
#define LXfTREEITEM_ROWCOLOR_ULTRAMARINE         0x000C0000
#define LXfTREEITEM_ROWCOLOR_PURPLE              0x000D0000
#define LXfTREEITEM_ROWCOLOR_LIGHT_PURPLE        0x000E0000
#define LXfTREEITEM_ROWCOLOR_DARK_GREY           0x000F0000
#define LXfTREEITEM_ROWCOLOR_GREY                0x00100000
#define LXfTREEITEM_ROWCOLOR_WHITE               0x00110000
#define LXu_TREE                "E61F3BA6-B9E8-41B8-8A61-3F78CBC79E98"
#define LXa_TREE                "tree"
// [export] ILxTree tree
// [local]  ILxTree
// [python] ILxTree:Spawn       obj Tree
// [python] ILxTree:IsRoot      bool
// [python] ILxTree:ChildIsLeaf bool
#define LXu_TREELISTENER        "200fe1a6-c764-42f7-917f-044a0f58e007"
// [export] ILxTreeListener tlis
// [local]  ILxTreeListener
#define LXu_TREELISTENER1       "EB38EE07-0E35-455F-A570-F4AF313494FD"
// [export] ILxTreeListener1 tlis
// [local]  ILxTreeListener1

 #ifdef __cplusplus
  }
 #endif
#endif

