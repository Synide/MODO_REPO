/*
 * MORPH.CPP	Morph Mesh Influence
 *
 *	Copyright (c) 2008-2019 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_deform.hpp>
#include <lx_plugin.hpp>
#include <lxu_deform.hpp>
#include <lxu_package.hpp>
#include <lxu_modifier.hpp>
#include <lxu_math.hpp>
#include <lxidef.h>
#include <string>
#include <math.h>

#include "morphcontainer.hpp"

        namespace Influence_Morph {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		LXsITYPE_MORPHDEFORM
#define SRVNAME_MODIFIER		LXsITYPE_MORPHDEFORM
#define SPWNAME_INSTANCE		"morph.inst"

static CLxItemType		 cit_mesh	(LXsITYPE_MESH);
static CLxItemType		 cit_instance	(LXsITYPE_MESHINST);
static CLxItemType		 cit_morphCont	(LXsITYPE_MORPHCONTAINER);

typedef Influence_MorphContainer::CMeshList MorphContFunc;

/*
 * The package has a set of standard channels with default values. These
 * are setup at the start using the AddChannel interface.
 */
#define Cs_MESHINF		LXsICHAN_MORPHDEFORM_MESHINF
#define Cs_ENABLE		LXsICHAN_MORPHDEFORM_ENABLE
#define Cs_MAPNAME		LXsICHAN_MORPHDEFORM_MAPNAME
#define Cs_STRENGTH		LXsICHAN_MORPHDEFORM_STRENGTH
#define Cs_USELOCAL		LXsICHAN_MORPHDEFORM_USELOCAL

/*
 * Template method for getting an array of keys from a map.
 */
        template <class K, class V>
        void
KeyVector (
        const std::map<K,V>	&map,
        std::vector<K>		&keyList)
{
 #ifndef _MSWIN
        typename	// Really, clang? You need a hint?
 #endif
        std::map<K,V>::const_iterator it;

        keyList.clear ();
        for (it = map.begin (); it != map.end (); it++)
                keyList.push_back (it->first);
}


/*
 * The deformer object is actually broken into two classes. The subclass
 * is the deformer mappings object, which computes the relationships between this
 * deformer item and all the ones it depends on. This is used directly by the item
 * instance to report related meshes and target items.
 */
class CDeformerMappings
{
    public:
        CLxUser_DeformerService	 d_S;

        /*
         * FlowSource defines a sub-influence that targets a mesh, given by the
         * influence item and the partition index. Called flow because it allows
         * us to chain influences together to affect each other.
         */
        class FlowSource {
            public:
                CLxUser_Item		src_def;	// deformer item
                unsigned		src_index;	// deformer index (0 for this)
                unsigned		mesh_index;	// index for the mesh in the mesh sequence
                unsigned		part_index;	// partition index for the mesh

                        bool
                operator== (
                        const FlowSource	&rhs) const
                {
                        return (src_def == rhs.src_def) && (part_index == rhs.part_index);
                }
        };

        typedef std::vector<CLxUser_Item>		ItemList;
        typedef std::vector<CLxUser_Item>::iterator	ItemList_Itr;
        typedef std::vector<FlowSource>			FlowList;
        typedef std::vector<FlowSource>::iterator	FlowList_Itr;
        typedef std::map<CLxUser_Item,FlowList>		FlowMap;

        /*
         * Item relationships. This item, the meshes it deforms, and the
         * sub-influences that provide the content and weights of the meshes.
         */
        CLxUser_Item		 m_item;	// this item
        FlowMap			 flow_map;	// list of FlowSources by target mesh item
        ItemList		 mesh_items;	// list of mesh items (partition order)
        ItemList		 def_items;	// flow deformer items (0 = this)
        FlowList		 item_flow;	// FlowSources providing items
        bool			 has_items;	// true if we have items

        /*
         * Helper class to build the list of deformers. First time we encounter it
         * we add it to the end of the list and remember the index.
         */
        class DeformerTable {
            public:
                ItemList			&def_items;
                std::map<CLxUser_Item,int>	 def_2_idx;
                int				 cur_index;

                DeformerTable (ItemList &list) : def_items (list), cur_index (0) {}

                        int
                Index (
                        CLxUser_Item		&def)
                {
                        if (def_2_idx.find (def) == def_2_idx.end ()) {
                                def_items.push_back (def);
                                def_2_idx[def] = cur_index ++;
                        }

                        return def_2_idx[def];
                }
        };

        /*
         * Initialization reads the item relations and builds the flow_map table. It
         * finds target meshes and all the deformer items (including this one) that
         * affect it. This also extracts the list of mesh items for easier use in
         * the deformer item instance, and builds the deformer list with this
         * item at index zero.
         */
                void
        Init (
                ILxUnknownID		 itemObj)
        {
                CLxUser_Item		 target, mesh;
                CLxUser_ItemGraph	 graph;
                CLxUser_DeformerService	 dSrv;
                CLxUser_MeshInfluence	 mi;
                CLxUser_ItemInfluence	 iif;
                FlowSource		 fsrc;
                DeformerTable		 src (def_items);
                unsigned		 i, n, ii, nn, midx;

                m_item.set (itemObj);
                has_items = false;

                graph.from (m_item, LXsGRAPH_DEFORMERS);
                n = graph.Forward (m_item);
                src.Index (m_item);
                midx = 0;

                for (i = n; i > 0; i--) {
                        graph.Forward (m_item, i - 1, target);

                        if (target.IsA (cit_mesh) || target.IsA (cit_instance)) {
                                fsrc.src_def.set (m_item);
                                fsrc.src_index  = src.Index (fsrc.src_def);
                                fsrc.mesh_index = ~0;	// never used
                                fsrc.part_index = midx++;
                                flow_map[target].push_back (fsrc);
                                continue;
                        }

                        if (mi.set (target)) {
                                fsrc.src_def.set (target);
                                fsrc.src_index = src.Index (fsrc.src_def);

                                nn = mi.MeshCount ();
                                for (ii = 0; ii < nn; ii++) {
                                        mi.GetMesh (ii, mesh);
                                        fsrc.mesh_index = ii;
                                        fsrc.part_index = mi.PartitionIndex (ii);
                                        flow_map[mesh].push_back (fsrc);
                                }

                        } else if (InfluenceChannel (target) >= 0) {
                                fsrc.src_def.set (target);
                                fsrc.src_index = src.Index (fsrc.src_def);

                                d_S.MeshCount (target, &nn);
                                for (ii = 0; ii < nn; ii++) {
                                        d_S.GetMesh (target, ii, mesh);
                                        fsrc.mesh_index = ii;
                                        fsrc.part_index = ii;
                                        flow_map[mesh].push_back (fsrc);
                                }
                        }

                        if (iif.set (target) && iif.HasItems () == LXe_TRUE) {
                                fsrc.src_def.set (target);
                                fsrc.src_index  = src.Index (fsrc.src_def);
                                fsrc.mesh_index = ~0;	// never used
                                fsrc.part_index = 0;
                                item_flow.push_back (fsrc);
                                has_items = true;
                        }
                }

                KeyVector (flow_map, mesh_items);
        }

                int
        InfluenceChannel (
                CLxUser_Item		&item)
        {
                unsigned		 chan;

                if (LXx_OK (d_S.DeformerChannel (item, &chan)))
                        return chan;

                if (item.IsA (cit_morphCont))
                        return item.ChannelIndex (LXsICHAN_MORPHDEFORM_MESHINF);

                return -1;
        }

        /*
         * For the purpose of testing whether the modifier node is still valid
         * we just have to test the equivalence of the flow map(s).
         */
                bool
        IsSame (
                const CDeformerMappings	 &that) const
        {
                return	(m_item    == that.m_item  )
                   &&	(flow_map  == that.flow_map)
                   &&	(item_flow == that.item_flow);
        }

        /*
         * Evaluation state for a modifier. EvalAlloc() is called from the
         * deformer cached in the modifier node, which adds channels for reading.
         */
        unsigned			 attr_index;	// base attribute index

        /*
         * Constructors, with one that takes an item for quick initialization.
         */
        unsigned			 use_count;

        CDeformerMappings () : use_count (1) {}
        CDeformerMappings (
                ILxUnknownID		 item)
                : use_count (1)
        {
                Init (item);
        }

                CDeformerMappings *
        AddRef ()
        {
                use_count ++;
                return this;
        }

                static void
        Release (
                CDeformerMappings	*dp)
        {
                if (-- dp->use_count == 0)
                        delete dp;
        }
};

/*
 * -------------------------------------------------------
 *
 * The instance implements the interfaces for the influence item. Since most
 * of the work is done by the deformer, the instance really just has to describe
 * the deformer in high-level terms.
 */
class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_MeshInfluence,
                public CLxImpl_ItemInfluence,
                public CLxImpl_WeightMapDeformerItem
{
public:
        static std::set<CInstance *>		 all_inst;

                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CInstance>;
                srv->AddInterface (new CLxIfc_PackageInstance		<CInstance>);
                srv->AddInterface (new CLxIfc_MeshInfluence		<CInstance>);
                srv->AddInterface (new CLxIfc_ItemInfluence		<CInstance>);
                srv->AddInterface (new CLxIfc_WeightMapDeformerItem	<CInstance>);
                lx::AddSpawner (SPWNAME_INSTANCE, srv);
        }

        CLxUser_Item		 m_item;

        /*
         * Remember ourselves.
         */
                LxResult
        pins_Initialize (
                ILxUnknownID		 item,
                ILxUnknownID		 super)
                                LXx_OVERRIDE
        {
                m_item.set (item);
                cur_item = 0;
                all_inst.insert (this);
                return LXe_OK;
        }

                void
        pins_Cleanup (void)
                                LXx_OVERRIDE
        {
                all_inst.erase (this);
                m_item.clear ();
        }

        /*
         * Try to provide a name that describes the target deformation as much
         * as possible.
         */
        CLxUser_DeformerService	 def_S;
        CLxUser_SceneService	 scene_S;
        CLxUser_ChannelUIService chan_S;
        CLxUser_MessageService	 msg_S;
        CLxUser_ValueService	 val_S;

                LxResult
        pins_SynthName (
                char			*buf,
                unsigned		 len)
                                LXx_OVERRIDE
        {
                CLxUser_ChannelRead	 chan;
                CLxUser_Message		 msg;
                CLxUser_Value		 strVal;
                CLxUser_Item		 def;
                //const char		*sptr;
                std::string		 key, name, abbrev;
                //int			 type;
                bool			 isLoc/*, hasName*/;

                if (!def_S.GetDeformerDeformationItem (m_item, def, isLoc))
                        return LXe_NOTIMPL;

                msg_S.NewMessage (msg);
                msg.SetMsg (SRVNAME_ITEMTYPE, key.c_str ());
                msg.SetArg (1, abbrev.c_str ());

                return msg_S.MessageText (msg, buf, len);
        }

        /*
         * The MeshInfluence and ItemInfluence interfaces list the target items
         * using a cached mappings object. This has to be rebuilt anytime the
         * state changes, which is managed by the package.
         */
        CDeformerMappings		*def_map;

        CInstance ()
        {
                def_map = 0;
        }

        ~CInstance ()
        {
                InvalidateMappings ();
        }

                void
        ValidateMappings ()
        {
                InvalidateMappings ();
                if (!def_map)
                        def_map = new CDeformerMappings (m_item);
        }

                void
        InvalidateMappings ()
        {
                if (def_map) {
                        CDeformerMappings::Release (def_map);
                        def_map = 0;
                }
        }

                static void
        InvalidateAll ()
        {
                std::set<CInstance *>::iterator	 cit;

                for (cit = all_inst.begin (); cit != all_inst.end (); cit++)
                        (*cit)->InvalidateMappings ();
        }

                unsigned
        minf_MeshCount ()
                                LXx_OVERRIDE
        {
                ValidateMappings ();
                return def_map -> mesh_items.size ();
        }

                LxResult
        minf_MeshByIndex (
                unsigned		 index,
                void		       **ppvObj)
                                LXx_OVERRIDE
        {
                ValidateMappings ();
                return def_map -> mesh_items[index].get (ppvObj);
        }

                unsigned
        minf_PartitionIndex (
                unsigned		 index)
                                LXx_OVERRIDE
        {
                return index + (iinf_HasItems () == LXe_TRUE ? 1 : 0);
        }

        /*
         * Listing items is done by enumeration.
         */
                LxResult
        iinf_HasItems ()
                                LXx_OVERRIDE
        {
                ValidateMappings ();
                return def_map -> has_items ? LXe_TRUE : LXe_FALSE;
        }

        class CSrcItemsEnumVisitor
                        : public CLxImpl_AbstractVisitor
        {
            public:
                CLxUser_ItemInfluence	 ii;
                std::set<CLxUser_Item>	 items;

                        LxResult
                Evaluate ()
                {
                        CLxUser_Item	 item;

                        if (ii.CurItem (item))
                                items.insert (item);

                        return LXe_OK;
                }
        };

        const CLxUser_Item		*cur_item;

                LxResult
        iinf_Enumerate (
                ILxUnknownID		 visitor)
                                LXx_OVERRIDE
        {
                CSrcItemsEnumVisitor	 vis;
                CDeformerMappings::FlowList_Itr		 iflow;

                ValidateMappings ();

                for (iflow = def_map->item_flow.begin (); iflow != def_map->item_flow.end (); iflow ++) {
                        vis.ii.set (def_map->def_items[iflow->src_index]);
                        vis.ii.Enum (&vis);
                }

                std::set<CLxUser_Item>::iterator	 iit;
                CLxUser_Visitor		 other (visitor);
                LxResult		 rc = LXe_OK;

                for (iit = vis.items.begin (); iit != vis.items.end (); iit ++) {
                        cur_item = &(*iit);
                        rc = other.Evaluate ();
                        if (rc != LXe_OK)
                                break;
                }

                cur_item = 0;
                return rc;
        }

                LxResult
        iinf_GetItem (
                void		       **ppvObj)
                                LXx_OVERRIDE
        {
                if (cur_item)
                        return cur_item->get (ppvObj);
                else
                        return LXe_OUTOFBOUNDS;
        }
};

std::set<CInstance *>		 CInstance::all_inst;	// Weird, weird, weird...

/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CPackage :
                public CLxDefaultPackage,
                public CLxImpl_ChannelUI
{
    public:
        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 inst_spawn;

        CPackage () : inst_spawn (SPWNAME_INSTANCE) {}

        LxResult	 pkg_SetupChannels (ILxUnknownID addChan)		LXx_OVERRIDE;

                LxResult
        pkg_TestInterface (
                const LXtGUID		*guid)
                                LXx_OVERRIDE
        {
                return inst_spawn.TestInterfaceRC (guid);
        }

                LxResult
        pkg_Attach (
                void		       **ppvObj)
                                LXx_OVERRIDE
        {
                inst_spawn.Alloc (ppvObj);
                return LXe_OK;
        }
};

/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */

LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,		LXsITYPE_LOCATOR	},
        { LXsPKG_DEFORMER_CHANNEL,	Cs_MESHINF		},
        { LXsPKG_DEFORMER_FLAGS,	"+WX"			},	// no weight, no xfrm
        { LXsPKG_DEFORMER_CREATECMD,	"morphDeform.create"	},
        { 0 }
};

        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (Cs_MESHINF,	LXsTYPE_OBJREF);
        ac.SetInternal ();

        ac.NewChannel  (Cs_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);

        ac.NewChannel  (Cs_MAPNAME,	LXsTYPE_VERTMAPNAME);

        ac.NewChannel  (Cs_STRENGTH,	LXsTYPE_PERCENT);
        ac.SetDefault  (1.0, 0);

        ac.NewChannel  (Cs_USELOCAL,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 0);

        return LXe_OK;
}


/* 
 * Mesh Influence for a morph is dead simple. The CChanState holds values of
 * the channels and handles getting them from the evaluation state. It also
 * serves as the modifier cache so we can compare previous values.
 */
class CChanState :
                public CLxObject
{
    public:
        std::string		 name;
        double			 factor;
        LXtMatrix		 xfrm;
        bool			 enabled, local;

                void
        Attach (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
        {
                eval.AddChan (item, Cs_ENABLE);
                eval.AddChan (item, Cs_MAPNAME);
                eval.AddChan (item, Cs_STRENGTH);
                eval.AddChan (item, Cs_USELOCAL);
                eval.AddChan (item, LXsICHAN_XFRMCORE_WORLDMATRIX);
        }

                void
        Read (
                CLxUser_Attributes	&attr,
                unsigned		 index)
        {
                CLxUser_Matrix		 m4;

                enabled = attr.Bool (index++);
                if (enabled) {
                        attr.String (index++, name);
                        factor = attr.Float (index++);
                        local  = attr.Bool  (index++);
                        if (local) {
                                attr.ObjectRO (index++, m4);
                                m4.Get3 (xfrm);
                        }
                }
        }

                LxResult
        Compare (
                CChanState		&that)
        {
                if (enabled != that.enabled || name.compare (that.name))
                        return LXeEVAL_DIFFERENT;

                return LXeDEFORM_NEWOFFSET;
        }
};

class CInfluence :
                public CLxMeshInfluence
{
    public:
        std::vector<LXtMeshMapID>	 cont_maps;
        CLxUser_Item			 item;
        LXtMeshMapID			 map_id;
        CChanState			 cur;
        bool				 is_abs;
        bool				 has_cnt;

                CInfluence () : map_id (0) {}

                bool
        ReadContainersMap (
                CLxUser_Mesh		&mesh)
        {
                // Check morph influence links
                CLxUser_ItemGraph	 graph;
                CLxUser_MeshMap		 map;
                CLxUser_Item		 othr;
                std::string		 name;
                int			 i, count;

                cont_maps.clear ();

                graph.from (item, LXsGRAPH_DEFORMERS);
                count = graph.Forward (item);
                for (i = count-1; i >= 0; i--) {	// Reversed!
                        // if linked item is a morph container
                        graph.Forward (item, i, othr);
                        if (!othr.IsA (cit_morphCont))
                                continue;

                        MorphContFunc::MapName (othr, name);
                        map.fromMesh (mesh);
                        if (map.SelectByName (LXi_VMAP_MORPH, name.c_str ()) != LXe_OK || !map.test ())
                                continue;

                        cont_maps.push_back (map.ID ());
                }

                return cont_maps.size () > 0;
        }

                bool
        SelectMap (
                CLxUser_Mesh		&mesh,
                CLxUser_MeshMap		&map)		LXx_OVERRIDE
        {
                is_abs = false;
                has_cnt = ReadContainersMap (mesh);
                if (has_cnt)
                        return false;

                map.SelectByName (LXi_VMAP_MORPH, cur.name.c_str ());
                map_id = map.ID ();
                if (map_id)
                        return true;

                map.SelectByName (LXi_VMAP_SPOT, cur.name.c_str ());
                map_id = map.ID ();
                is_abs = true;

                return true;
        }

                void
        Offset (
                CLxUser_Point		&point,
                float			 weight,
                LXtFVector		 offset)	LXx_OVERRIDE
        {
                LXtFVector		 offF, posF;
                
                // Morph Container Mode: get correct map_id
                if (has_cnt) {
                        unsigned	 i, n = cont_maps.size ();
                        for (i = 0; i<n; i++) {
                                if (!cont_maps[i])
                                        continue;
                                if (point.MapValue (cont_maps[i], offF) == LXe_OK)
                                        break;
                        }

                        // No map found: exit with a 0 vector.
                        if (i==n) {
                                LXx_VSET3 (offset, 0., 0., 0.);
                                return;
                        }

                } else
                        point.MapValue (map_id, offF);

                if (is_abs) {
                        point.Pos (posF);
                        LXx_VSUB (offF, posF);
                }

                if (cur.local) {
                        LXtFVector	 tmp;

                        lx::MatrixMultiply (tmp, cur.xfrm, offF);
                        LXx_VSCL3 (offset, tmp, cur.factor * weight);
                } else
                        LXx_VSCL3 (offset, offF, cur.factor * weight);
        }
};

/*
 * The modifier operates on all items of this type, and sets the mesh influence
 * channel to an object allocated using the input parameters for the modifier.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        CLxUser_Item	 item;
        unsigned	 index;

                bool
        Test (ILxUnknownID)
                { return false; }

                CLxObject *
        Cache ()
        {
                return new CChanState;
        }

                LxResult
        EvalCache (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr,
                CLxObject		*cacheRaw,
                bool			 prev)
        {
                CChanState		*cache = dynamic_cast<CChanState *> (cacheRaw);
                CInfluence		*infl;
                CLxUser_ValueReference	 ref;
                ILxUnknownID		 obj;
                LxResult		 rc;

                infl = new CInfluence;
                infl->item = item;
                infl->Spawn ((void **) &obj);
                attr.ObjectRW (index, ref);
                ref.SetObject (obj);
                lx::UnkRelease (obj);

                infl->cur.Read (attr, index + 1);
                if (prev)
                        rc = cache->Compare (infl->cur);
                else
                        rc = LXe_OK;

                *cache = infl->cur;
                return rc;
        }
};

class CModifier :
                public CLxItemModifierServer
{
    public:
                const char *
        ItemType ()
        {
                return SRVNAME_ITEMTYPE;
        }

                CLxItemModifierElement *
        Alloc (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
        {
                CModifierElement	*elt;
                CChanState		 tmp;

                elt = new CModifierElement;
                elt->item = item;
                elt->index = eval.AddChan (item, Cs_MESHINF, LXfECHAN_WRITE);

                tmp.Attach (eval, item);

                return elt;
        }

                const char*
        GraphNames () LXx_OVERRIDE
                { return LXsGRAPH_DEFORMERS; }
};



/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackage>;
        srv->AddInterface (new CLxIfc_Package		<CPackage>);
        srv->AddInterface (new CLxIfc_ChannelUI		<CPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc	<CPackage>);
        lx::AddServer (SRVNAME_ITEMTYPE, srv);

        CInstance::initialize ();

        CLxExport_ItemModifierServer<CModifier> (SRVNAME_MODIFIER);
}

        };	// END namespace



