/*
* MODO SDK SAMPLE
*
* sceneRenderTrace server
* =======================
*
*	Copyright (c) 2008-2019 The Foundry Group LLC
*	
*	Permission is hereby granted, free of charge, to any person obtaining a
*	copy of this software and associated documentation files (the "Software"),
*	to deal in the Software without restriction, including without limitation
*	the rights to use, copy, modify, merge, publish, distribute, sublicense,
*	and/or sell copies of the Software, and to permit persons to whom the
*	Software is furnished to do so, subject to the following conditions:
*	
*	The above copyright notice and this permission notice shall be included in
*	all copies or substantial portions of the Software.   Except as contained
*	in this notice, the name(s) of the above copyright holders shall not be
*	used in advertising or otherwise to promote the sale, use or other dealings
*	in this Software without prior written authorization.
*	
*	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*	DEALINGS IN THE SOFTWARE.
*
* This implements a plugin that displays a text-based trace of
* events and data that a renderer could use.
*
* CLASSES USED:
*
*		CLxImpl_ExternalRender
*		CLxRenderContextListener
*
* TESTING:
*
* Load the plugin.
* Use PView viewport settings to select the renderer to perform the trace.
* View Event Log while manipulating items.
*/
#include "cc_srt_rendercontrol.hpp"
#include "cc_srt_rendercontexteventhandler.hpp"
#include "cc_srt_log.hpp"

#include <lxlog.h> // for LXsSRV_LOGSUBSYSTEM

#include <sstream>

namespace SceneRenderTrace
{
        LXtTagInfoDesc	RenderControl::descInfo[] =
        {
                { LXsSRV_USERNAME, SCENERENDERTRACE_SUBSYSTEM },
                { LXsSRV_LOGSUBSYSTEM,	SCENERENDERTRACE_SUBSYSTEM },
                { 0 }
        };

        LxResult RenderControl::rend_Start()
        {
                MAKE_LOGGER("Start rendering");

                // defer render context initialisation until after the renderer has been started
                // this is to avoid conflicts of spawning servers using tag scans when the plugin loads
                // (move the following line to the constructor to see the error when loading the plugin).
                m_renderContext.Init(this, LXfRENDERCACHE_FULL | LXfRENDERCACHE_TRACK_CURRENT_SCENE);
                LOG_INFO("RenderContext initialized");

                return LXe_OK;
        }

        LxResult RenderControl::rend_Stop()
        {
                MAKE_LOGGER("Stop rendering");
                return LXe_OK;
        }

        LxResult RenderControl::rend_Pause()
        {
                MAKE_LOGGER("Pause rendering");
                return LXe_OK;
        }

        LxResult RenderControl::rend_Reset()
        {
                MAKE_LOGGER("Reset rendering");
                return LXe_OK;
        }

        LxResult RenderControl::rend_SetNotifier(ILxUnknownID notifier)
        {
                MAKE_LOGGER("Notifier set");
                return LXe_OK;
        }

        LxResult RenderControl::rend_SetBufferQueue(ILxUnknownID bufferQueue)
        {
                MAKE_LOGGER("Buffer queue set");
                return LXe_OK;
        }

        LxResult RenderControl::rend_SelectedPixelAt(const int x, const int y)
        {
                MAKE_LOGGER("Selected a pixel at");
                std::stringstream message;
                message << "(" << x << ", " << y << ")";
                LOG_INFO(message.str());
                return LXe_OK;
        }

        void RenderControl::rctx_HandleEvent(const CLxRenderContextEvent& event)
        {
                switch (event.Type())
                {
                case LXi_RCTX_EVT_NONE:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_NONE");
                        LOG_ERROR("Should never happen");
                }
                break;

                case LXi_RCTX_EVT_SCENE_CREATE:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_CREATE");
                }
                break;

                case LXi_RCTX_EVT_SCENE_DESTROY:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_DESTROY");
                }
                break;

                case LXi_RCTX_EVT_SCENE_CLEAR:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_CLEAR");
                }
                break;

                case LXi_RCTX_EVT_SCENE_CURRENT:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_CURRENT");
                }
                break;

                case LXi_RCTX_EVT_SCENE_ITEM_ADD:
                        sceneItemAdded(event);
                        break;

                case LXi_RCTX_EVT_SCENE_ITEM_REMOVE:
                        sceneItemRemoved(event);
                        break;

                case LXi_RCTX_EVT_SCENE_ITEM_UPDATE:
                        sceneItemUpdate(event, &m_renderContext);
                        break;

                case LXi_RCTX_EVT_SCENE_TIME_CHANGE:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_TIME_CHANGE");
                }
                break;

                case LXi_RCTX_EVT_RCACHE_DESTROY:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_DESTROY");
                }
                break;

                case LXi_RCTX_EVT_RCACHE_CLEAR:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_CLEAR");
                }
                break;

                case LXi_RCTX_EVT_RCACHE_UPDATE_BEGIN:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_UPDATE_BEGIN");
                }
                break;

                case LXi_RCTX_EVT_RCACHE_UPDATE_END:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_UPDATE_END");
                }
                break;

                case LXi_RCTX_EVT_RCACHE_SURF_ADD:
                        renderCacheSurfaceAdd(event);
                        break;

                case LXi_RCTX_EVT_RCACHE_SURF_REMOVE:
                        renderCacheSurfaceRemove(event);
                        break;

                case LXi_RCTX_EVT_RCACHE_SURF_GEO_UPDATE:
                        renderCacheSurfaceGeometryUpdate(event);
                        break;

                case LXi_RCTX_EVT_RCACHE_SURF_XFM_UPDATE:
                        renderCacheSurfaceTransformUpdate(event);
                        break;

                case LXi_RCTX_EVT_RCACHE_SURF_SHD_UPDATE:
                        renderCacheSurfaceShaderUpdate(event, &m_renderContext);
                        break;

                case LXi_RCTX_EVT_COUNT:
                {
                        MAKE_LOGGER("Event: LXi_RCTX_EVT_COUNT");
                        LOG_ERROR("Should never happen");
                }
                break;

                default:
                {
                        MAKE_LOGGER("Event: Unknown");
                        LOG_ERROR_EX("Code is " << event.Type() << std::endl);
                }
                }
        }

} // namespace SceneRenderTrace

