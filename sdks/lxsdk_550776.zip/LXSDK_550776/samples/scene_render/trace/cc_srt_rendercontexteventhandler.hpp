/*
* MODO SDK SAMPLE
*
* sceneRenderTrace server
* =======================
*
*	Copyright (c) 2008-2019 The Foundry Group LLC
*	
*	Permission is hereby granted, free of charge, to any person obtaining a
*	copy of this software and associated documentation files (the "Software"),
*	to deal in the Software without restriction, including without limitation
*	the rights to use, copy, modify, merge, publish, distribute, sublicense,
*	and/or sell copies of the Software, and to permit persons to whom the
*	Software is furnished to do so, subject to the following conditions:
*	
*	The above copyright notice and this permission notice shall be included in
*	all copies or substantial portions of the Software.   Except as contained
*	in this notice, the name(s) of the above copyright holders shall not be
*	used in advertising or otherwise to promote the sale, use or other dealings
*	in this Software without prior written authorization.
*	
*	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*	DEALINGS IN THE SOFTWARE.
*
* This implements a plugin that displays a text-based trace of
* events and data that a renderer could use.
*
* CLASSES USED:
*
*		CLxImpl_ExternalRender
*		CLxRenderContextListener
*
* TESTING:
*
* Load the plugin.
* Use PView viewport settings to select the renderer to perform the trace.
* View Event Log while manipulating items.
*/
#ifndef CC_SRT_RENDERCONTEXTEVENTHANDLER_HPP
#define CC_SRT_RENDERCONTEXTEVENTHANDLER_HPP

#include <lxu_rendercontext.hpp>

namespace SceneRenderTrace
{
        // cannot pass context as a const reference due to lack of const-member functions for accessors
        extern void sceneItemAdded(const CLxRenderContextEvent& event);
        extern void sceneItemRemoved(const CLxRenderContextEvent& event);
        extern void sceneItemUpdate(const CLxRenderContextEvent& event, CLxRenderContext *context);

        extern void renderCacheSurfaceAdd(const CLxRenderContextEvent& event);
        extern void renderCacheSurfaceRemove(const CLxRenderContextEvent& event);
        extern void renderCacheSurfaceGeometryUpdate(const CLxRenderContextEvent& event);
        extern void renderCacheSurfaceTransformUpdate(const CLxRenderContextEvent& event);
        extern void renderCacheSurfaceShaderUpdate(const CLxRenderContextEvent& event, CLxRenderContext *context);

} // namespace SceneRenderTrace

#endif // CC_SRT_RENDERCONTEXTEVENTHANDLER_HPP

