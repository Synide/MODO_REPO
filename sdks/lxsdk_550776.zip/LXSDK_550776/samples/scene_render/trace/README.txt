# Copyright (c) 2008-2019 The Foundry Group LLC
# 
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.   Except as contained
# in this notice, the name(s) of the above copyright holders shall not be
# used in advertising or otherwise to promote the sale, use or other dealings
# in this Software without prior written authorization.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

Overview
========
This sample plugin displays a trace of the rendering events as the current scene is edited. The trace appears in the Event Log.

Build
=====
This sample requires at least a C++11 compliant compiler and linker.
The project files provided for this sample are separate from those for the remainder of the samples due to different requirements.

Windows
-------
A VisualStudio 2015 project is included in <sdkroot>/samples/VisualC/scene_render/trace, but which is not included in the solution file for the SDK samples.
This sample is dependent upon the common library, which is currently a VisualStudio 2010 project.
Please load the common library project into VisualStudio 2015 to upgrade, build, and then build this project.

Linux/MacOS
-----------
A standalone MakeFile is provided in <sdkroot>/samples/Makefiles/scene_render/trace.
Simply run make in that directory.

Run
===
* Run Modo
* Load the .lx file for this plugin using the System->Add Plug-in... menu.
* Reopen Modo (PView currently needs a restart in order to find this plugin). You may need to close and reopen Modo one more time after this.
* Open a PView viewport, and go to the settings (the cog) for the viewport, and select SceneRenderTrace as the Renderer.
* Open the Event Log.
* Start the PView renderer (if it was paused initially).
* Add items, modify items, delete items in the scene. Watch the event log for the subsystem 'SceneRenderTrace'.
* Optional: Save the event log for the subsystem 'SceneRenderTrace'.

