/*
* MODO SDK SAMPLE
*
* sceneRenderTrace server
* =======================
*
*	Copyright (c) 2008-2019 The Foundry Group LLC
*	
*	Permission is hereby granted, free of charge, to any person obtaining a
*	copy of this software and associated documentation files (the "Software"),
*	to deal in the Software without restriction, including without limitation
*	the rights to use, copy, modify, merge, publish, distribute, sublicense,
*	and/or sell copies of the Software, and to permit persons to whom the
*	Software is furnished to do so, subject to the following conditions:
*	
*	The above copyright notice and this permission notice shall be included in
*	all copies or substantial portions of the Software.   Except as contained
*	in this notice, the name(s) of the above copyright holders shall not be
*	used in advertising or otherwise to promote the sale, use or other dealings
*	in this Software without prior written authorization.
*	
*	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
*	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
*	DEALINGS IN THE SOFTWARE.
*
* This implements a plugin that displays a text-based trace of
* events and data that a renderer could use.
*
* CLASSES USED:
*
*		CLxImpl_ExternalRender
*		CLxRenderContextListener
*
* TESTING:
*
* Load the plugin.
* Use PView viewport settings to select the renderer to perform the trace.
* View Event Log while manipulating items.
*/
#include "cc_srt_rendercontexteventhandler.hpp"
#include "cc_srt_rendercontrol.hpp"
#include "cc_srt_log.hpp"

#include <sstream>
#include <cassert>
#include <algorithm>

// comment this to use the old mechanism for extracting shader tree layers, which was limited in what it provided
#define USE_NEW_LAYERSTACK_QUERY

namespace
{

std::string getColor(const LXtColorRGB &color)
{
        std::stringstream message;
        message << "(" << color[0] << ", " << color[1] << ", " << color[2] << ")";
        return message.str();
}

template <class T>
std::string getVector2(const T &vector)
{
        std::stringstream message;
        message << "[" << vector[0] << ", " << vector[1] << "]";
        return message.str();
}

template <class T>
std::string getVector3(const T &vector)
{
        std::stringstream message;
        message << "[" << vector[0] << ", " << vector[1] << ", " << vector[2] << "]";
        return message.str();
}

template <class T>
std::string getMatrix3(const T &matrix)
{
        std::stringstream message;
        message << "[[" << matrix[0][0] << ", " << matrix[0][1] << ", " << matrix[0][2] << "]";
        message << "[" << matrix[1][0] << ", " << matrix[1][1] << ", " << matrix[1][2] << "]";
        message << "[" << matrix[2][0] << ", " << matrix[2][1] << ", " << matrix[2][2] << "]]";
        return message.str();
}

// would pass item by const reference, but some methods are not const methods
std::string getItemNames(CLxUser_Item item)
{
        std::stringstream message;
        // internal identifier (most stable, used for looking up items)
        message << "Ident(" << item.IdentPtr() << ") ";
        // name set by the user
        {
                const char *name = nullptr;
                item.Name(&name); // this function always returns LXe_OK even if null is returned
                if (nullptr != name)
                {
                        message << "Name(" << name << ") ";
                }
                else
                {
                        message << "Name() ";
                }
        }
        // name displayed in UI (not stable, and can change)
        {
                std::string uniqueName;
                item.GetUniqueName(uniqueName);
                message << "UniqueName(" << uniqueName << ")";
        }
        return message.str();
}

// would pass item by const reference, but some methods are not const methods
std::string getItemType(CLxUser_Item item)
{
        std::stringstream message;

        LXtItemType type = item.Type();
        CLxUser_SceneService sceneService;
        const char *typeName = nullptr;
        sceneService.ItemTypeName(type, &typeName);
        message << "Type(" << typeName << ")";

        return message.str();
}

// this is O(n^m), since it's walking the filtered shader tree for the surface for M (render item + group masks)
#ifdef USE_NEW_LAYERSTACK_QUERY
void internalGetImmediateChildOfShaderTreeItem(const std::vector<CLxUser_Item> &shadeLayers, CLxRenderContext *context, CLxUser_ChannelRead *channelReader, const CLxUser_Item &scopeItem, const int depth, std::stringstream &message)
#else
void internalGetImmediateChildOfShaderTreeItem(const CLxLayerStack &shadeLayers, CLxRenderContext *context, CLxUser_ChannelRead *channelReader, const CLxUser_Item &scopeItem, const int depth, std::stringstream &message)
#endif
{
        const std::string parentIndent = std::string(depth, '.');
        message << parentIndent << getItemNames(scopeItem) << " " << getItemType(scopeItem) << std::endl;
#ifdef USE_NEW_LAYERSTACK_QUERY
        const int numItems = static_cast<int>(shadeLayers.size());
#else
        const int numItems = shadeLayers.NItems(LXiTYPE_ANY);
#endif
        // note that the items appear in REVERSE order to what you see in the Modo ShaderTree UI
        for (int i = 0; i < numItems; ++i)
        {
                CLxUser_Item item;
#ifdef USE_NEW_LAYERSTACK_QUERY
                item = shadeLayers[i];
#else
                shadeLayers.GetItem(item, i);
#endif

                CLxUser_Item parentItem;
                item.GetParent(parentItem);
                if (parentItem != scopeItem)
                {
                        continue;
                }

                if (item.IsA(citMask))
                {
                        internalGetImmediateChildOfShaderTreeItem(shadeLayers, context, channelReader, item, depth + 1, message);
                }
                else
                {
                        const std::string indentPlusOne = std::string(depth + 1, '.');
                        message << indentPlusOne << getItemNames(item) << " " << getItemType(item);
                        if (!item.IsA(citTextureLayer))
                        {
                                message << std::endl;
                                continue;
                        }
                        // a texture layer means an advanced material, mask, shader, image map, or environment material, or output!
                        CLxTextureLayer textureLayer;
                        textureLayer.Init(item, *channelReader);

                        if (textureLayer.enable)
                        {
                                message << " Enabled";
                        }
                        else
                        {
                                message << " Disabled";
                        }

                        if (textureLayer.invert)
                        {
                                message << " Inverted";
                        }

                        message << " Opacity(" << textureLayer.opacity << ") Blend(";
                        switch (textureLayer.blend)
                        {
                        case LXi_TEXLAYER_BLEND_NORMAL:
                                message << "Normal";
                                break;
                        case LXi_TEXLAYER_BLEND_ADD:
                                message << "Add";
                                break;
                        case LXi_TEXLAYER_BLEND_SUB:
                                message << "Subtract";
                                break;
                        case LXi_TEXLAYER_BLEND_DIFF:
                                message << "Differemce";
                                break;
                        case LXi_TEXLAYER_BLEND_NORMALMULT:
                                message << "NormalMultiple";
                                break;
                        case LXi_TEXLAYER_BLEND_DIV:
                                message << "Divide";
                                break;
                        case LXi_TEXLAYER_BLEND_MULTIPLY:
                                message << "Multiply";
                                break;
                        case LXi_TEXLAYER_BLEND_SCREEN:
                                message << "Screen";
                                break;
                        case LXi_TEXLAYER_BLEND_OVERLAY:
                                message << "Overlay";
                                break;
                        case LXi_TEXLAYER_BLEND_SOFTLIGHT:
                                message << "Softlight";
                                break;
                        case LXi_TEXLAYER_BLEND_HARDLIGHT:
                                message << "Hardlight";
                                break;
                        case LXi_TEXLAYER_BLEND_DARKEN:
                                message << "Darken";
                                break;
                        case LXi_TEXLAYER_BLEND_LIGHTEN:
                                message << "Lighten";
                                break;
                        case LXi_TEXLAYER_BLEND_COLORDODGE:
                                message << "ColorDodge";
                                break;
                        case LXi_TEXLAYER_BLEND_COLORBURN:
                                message << "ColorBurn";
                                break;
                        default:
                                message << "Unknown - " << textureLayer.blend;
                        }
                        message << ")";
                        if (nullptr != textureLayer.effect && 0 != strcmp(textureLayer.effect, ""))
                        {
                                message << " Effect(" << textureLayer.effect << ")";
                        }
                        message << std::endl;
                        if (!item.IsA(citAdvancedMaterial))
                        {
                                continue;
                        }
                        CLxAdvMaterial material;
                        material.Init(item, *channelReader);
                        const std::string indentPlusTwo = indentPlusOne + '-';
                        message << indentPlusTwo << "FXchannel(" << LXs_FX_DIFFCOLOR << "): " << getColor(material.diffCol) << std::endl;
                        message << indentPlusTwo << "FXchannel(" << LXs_FX_DIFFAMOUNT << "): " << material.diffAmt << std::endl;
                        message << indentPlusTwo << "FXchannel(" << LXs_FX_SPECCOLOR << "): " << getColor(material.specCol) << std::endl;
                        message << indentPlusTwo << "FXchannel(" << LXs_FX_SPECAMOUNT << "): " << material.specAmt << std::endl;
                        message << indentPlusTwo << "..." << std::endl;
                }
        }
}

// cannot pass channelReader as a const reference
#ifdef USE_NEW_LAYERSTACK_QUERY
std::string getShaderTreeForSurface(const std::vector<CLxUser_Item> &shadeLayers, CLxRenderContext *context, CLxUser_ChannelRead *channelReader)
#else
std::string getShaderTreeForSurface(const CLxLayerStack &shadeLayers, CLxRenderContext *context, CLxUser_ChannelRead *channelReader)
#endif
{
        std::stringstream message;

        message << "Shading tree for surface:" << std::endl;

        // get the render item
        CLxUser_Item	renderItem;
        context->GetItem(renderItem, 0, citRender);

        internalGetImmediateChildOfShaderTreeItem(shadeLayers, context, channelReader, renderItem, 0, message);

        return message.str();
}

std::string getSurfaceGeometricDetails(CLxUser_GeoCacheSurface surface)
{
#define SURF_GEO_ERROR(_expression) message << "***ERROR***: " << _expression

        std::stringstream message;
        message << "Geometry details" << std::endl;

        surface.LoadSegments();

        int numSegments;
        surface.SegmentCount(&numSegments);

        int numPolygons;
        surface.PolygonCount(&numPolygons);

        int numVertices;
        surface.VertexCount(&numVertices);

        message << numSegments << " segments; " << numPolygons << " polygons; " << numVertices << " vertices" << std::endl;

        LXtBBox boundingBox;
        surface.GetBBox(&boundingBox);

        message << "Bounding box: " << getVector3(boundingBox.min) << " " << getVector3(boundingBox.max) << std::endl;

        const int maxSegments = std::min(numSegments, 1);
        for (int segIndex = 0; segIndex < maxSegments; ++segIndex)
        {
                CLxUser_GeoCacheSegment		segment;
                surface.GetSegment(segIndex, segment);

                int	numVerticesPerPolygon;
                segment.VertsPerPoly(&numVerticesPerPolygon);

                int	numSegmentVertices;
                segment.VertexCount(&numSegmentVertices);

                message << "Segment " << segIndex << ": " << numVerticesPerPolygon << " vertices per polygon; " << numSegmentVertices << " vertices in this segment" << std::endl;

                const int maxSegmentVertices = std::min(numSegmentVertices, 3);

                // get positions
                std::unique_ptr<LXtFVector[]> positions(new LXtFVector[numSegmentVertices]);
                memset(positions.get(), 0, sizeof(LXtFVector) * numSegmentVertices);
                if (LXx_FAIL(segment.GetVertexFeature(LXiRENDERCACHE_GEOVERT_OPOS, positions.get(), numSegmentVertices, 0)))
                {
                        SURF_GEO_ERROR("Failed to get positions for segment " << segIndex << std::endl);
                }

                message << "Positions:" << std::endl;
                for (int i = 0; i < maxSegmentVertices; ++i)
                {
                        message << i << ": " << getVector3(positions[i]) << std::endl;
                }
                message << "..." << std::endl;

                // get normals
                std::unique_ptr<LXtFVector[]> normals(new LXtFVector[numSegmentVertices]);
                memset(normals.get(), 0, sizeof(LXtFVector) * numSegmentVertices);
                if (LXx_FAIL(segment.GetVertexFeature(LXiRENDERCACHE_GEOVERT_ONRM, normals.get(), numSegmentVertices, 0)))
                {
                        SURF_GEO_ERROR("Failed to get normals for segment " << segIndex << std::endl);
                }

                message << "Normals:" << std::endl;
                for (int i = 0; i < maxSegmentVertices; ++i)
                {
                        message << i << ": " << getVector3(normals[i]) << std::endl;
                }
                message << "..." << std::endl;

                // get UVs if they exist
                {
                        int segmentHasUVs = 0;
                        segment.VertexFeatureCount(LXiRENDERCACHE_GEOVERT_UV, &segmentHasUVs);

                        if (segmentHasUVs > 0)
                        {
                                std::unique_ptr<LXtFVector2[]> uvs(new LXtFVector2[numSegmentVertices]);
                                memset(uvs.get(), 0, sizeof(LXtFVector2) * numSegmentVertices);
                                if (LXx_FAIL(segment.GetVertexFeature(LXiRENDERCACHE_GEOVERT_UV, uvs.get(), numSegmentVertices, 0)))
                                {
                                        SURF_GEO_ERROR("Failed to get UVs for segment " << segIndex << std::endl);
                                }

                                message << "UVs:" << std::endl;
                                for (int i = 0; i < maxSegmentVertices; ++i)
                                {
                                        message << i << ": " << getVector2(uvs[i]) << std::endl;
                                }
                                message << "..." << std::endl;
                        }
                }

                int	numSegmentPolygons;
                segment.PolygonCount(&numSegmentPolygons);

                // triangle indices
                const int numIndices = numSegmentPolygons * numVerticesPerPolygon;
                std::unique_ptr<int[]> indices(new int[numIndices]);
                memset(indices.get(), 0, sizeof(int) * numIndices);
                if (LXx_FAIL(segment.GetPolygonVertexInds(indices.get(), numIndices, 0)))
                {
                        SURF_GEO_ERROR("Failed to get indices for segment " << segIndex << std::endl);
                }

                const int maxSegmentIndices = std::min(numIndices, 3);
                message << "Indices:" << std::endl;
                for (int i = 0; i < maxSegmentIndices; ++i)
                {
                        message << i << ": " << indices[i] << std::endl;
                }
                message << "..." << std::endl;
        }

        surface.UnloadSegments();

        return message.str();
#undef SURF_GEO_ERROR
}

} // anonymous namespace

namespace SceneRenderTrace
{

void sceneItemAdded(const CLxRenderContextEvent& event)
{
        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_ITEM_ADD");

        CLxUser_Item	sceneItem(event.Object());
        if (!sceneItem.test())
        {
                LOG_ERROR("Unable to get scene item");
                return;
        }
        LOG_INFO_EX(getItemNames(sceneItem) << " " << getItemType(sceneItem) << std::endl);
}

void sceneItemRemoved(const CLxRenderContextEvent& event)
{
        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_ITEM_REMOVE");

        CLxUser_Item	sceneItem(event.Object());
        if (!sceneItem.test())
        {
                LOG_ERROR("Unable to get scene item");
                return;
        }
        LOG_INFO_EX(getItemNames(sceneItem) << " " << getItemType(sceneItem) << std::endl);
}

void sceneItemUpdate(const CLxRenderContextEvent& event, CLxRenderContext *context)
{
        MAKE_LOGGER("Event: LXi_RCTX_EVT_SCENE_ITEM_UPDATE");

        CLxUser_Item	sceneItem(event.Object());
        if (!sceneItem.test())
        {
                LOG_ERROR("Unable to get scene item");
                return;
        }
        LOG_INFO_EX(getItemNames(sceneItem) << " " << getItemType(sceneItem) << std::endl);

        // cannot query anything here about CLxUser_GeoCacheSurface as this event does not
        // come through the RenderCache

#ifdef USE_NEW_LAYERSTACK_QUERY
#else
        // specifically for meshes, if it's been updated, check its shader tree layers
        // this could be made more specific, by detecting new scene items added, and noting
        // if they are shader tree related items
        if (sceneItem.IsA(CLxItemType(LXsITYPE_MESH)))
        {
                CLxUser_ChannelRead channelReader;
                context->Channels(channelReader);

                // Note: this code is almost identical to renderCacheSurfaceShaderUpdate
                CLxLayerStack shaderLayers;
                if (LXx_FAIL(context->LayerStack(sceneItem, shaderLayers)))
                {
                        LOG_ERROR("Failed to obtain layer stack for surface");
                }

                LOG_INFO(getShaderTreeForSurface(shaderLayers, context, &channelReader));
        }
#endif
}

void renderCacheSurfaceAdd(const CLxRenderContextEvent& event)
{
        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_SURF_ADD");

        CLxUser_GeoCacheSurface	surface(event.Object());
        if (!surface.test())
        {
                LOG_ERROR("Unable to get surface");
                return;
        }
        CLxUser_Item sourceItem;
        surface.GetSourceItem(sourceItem);
        if (!sourceItem.test())
        {
                LOG_ERROR("Got surface, but couldn't get source item");
                return;
        }

        LOG_INFO_EX(getItemNames(sourceItem) << " " << getItemType(sourceItem) << std::endl);

        if (surface.IsInstanced())
        {
                LOG_INFO("Is instanced");
                CLxUser_GeoCacheSurface sourceSurface;
                surface.GetSourceSurface(sourceSurface);
                LOG_INFO_EX(getSurfaceGeometricDetails(sourceSurface));
        }
        else
        {
                LOG_INFO("Is NOT instanced");
                LOG_INFO_EX(getSurfaceGeometricDetails(surface));
        }
}

void renderCacheSurfaceRemove(const CLxRenderContextEvent& event)
{
        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_SURF_REMOVE");

        // this is informational only - the object no longer exists
        // see LXi_RCTX_EVT_SCENE_ITEM_REMOVE for a hook for identifying what was removed
        // earlier in the event chain
}

void renderCacheSurfaceGeometryUpdate(const CLxRenderContextEvent& event)
{
        // Note: almost a duplicate of renderCacheSurfaceAdd
        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_SURF_GEO_UPDATE");
        CLxUser_GeoCacheSurface	surface(event.Object());
        if (!surface.test())
        {
                LOG_ERROR("Unable to get surface");
                return;
        }
        CLxUser_Item sourceItem;
        surface.GetSourceItem(sourceItem);
        if (!sourceItem.test())
        {
                LOG_ERROR("Got surface, but couldn't get source item");
                return;
        }

        LOG_INFO_EX(getItemNames(sourceItem) << " " << getItemType(sourceItem) << std::endl);

        if (surface.IsInstanced())
        {
                LOG_INFO("Is instanced");
                CLxUser_GeoCacheSurface sourceSurface;
                surface.GetSourceSurface(sourceSurface);
                LOG_INFO_EX(getSurfaceGeometricDetails(sourceSurface));
        }
        else
        {
                LOG_INFO("Is NOT instanced");
                LOG_INFO_EX(getSurfaceGeometricDetails(surface));
        }
}

void renderCacheSurfaceTransformUpdate(const CLxRenderContextEvent& event)
{
        MAKE_LOGGER("LXi_RCTX_EVT_RCACHE_SURF_XFM_UPDATE");
        CLxUser_GeoCacheSurface	surface(event.Object());
        if (!surface.test())
        {
                LOG_ERROR("Unable to get surface");
                return;
        }

        CLxUser_Item sourceItem;
        surface.GetSourceItem(sourceItem);
        if (!sourceItem.test())
        {
                LOG_ERROR("Got surface, but couldn't get source item");
                return;
        }

        LOG_INFO_EX(getItemNames(sourceItem) << " " << getItemType(sourceItem) << std::endl);

        LXtVector	position;
        LXtMatrix	rotation;
        LXtVector	scale;
        surface.GetXfrm(position, rotation, scale, 0);
        LOG_INFO_EX("Position(" << getVector3(position) << ")" << std::endl);
        LOG_INFO_EX("Rotation(" << getMatrix3(rotation) << ")" << std::endl);
        LOG_INFO_EX("Scale(" << getVector3(scale) << ")" << std::endl);
}

void renderCacheSurfaceShaderUpdate(const CLxRenderContextEvent& event, CLxRenderContext *context)
{
        MAKE_LOGGER("Event: LXi_RCTX_EVT_RCACHE_SURF_SHD_UPDATE");
        CLxUser_GeoCacheSurface	surface(event.Object());
        if (!surface.test())
        {
                LOG_ERROR("Unable to get surface");
                return;
        }
        CLxUser_Item sourceItem;
        surface.GetSourceItem(sourceItem);
        if (!sourceItem.test())
        {
                LOG_ERROR("Got surface, but couldn't get source item");
                return;
        }

        LOG_INFO_EX(getItemNames(sourceItem) << " " << getItemType(sourceItem) << std::endl);

        CLxUser_ChannelRead channelReader;
        context->Channels(channelReader);

#ifdef USE_NEW_LAYERSTACK_QUERY
        auto shaderLayerCount = 0u;
        if (LXx_FAIL(surface.ShaderLayerCount(&shaderLayerCount)))
        {
                LOG_ERROR("Cannot get the number of shader layers on this surface");
        }
        std::vector<CLxUser_Item> shaderLayers;
        shaderLayers.reserve(shaderLayerCount);
        for (auto j = 0u; j < shaderLayerCount; ++j)
        {
                CLxUser_Item shaderLayerItem;
                if (LXx_FAIL(surface.GetShaderLayer(j, shaderLayerItem)))
                {
                        LOG_ERROR("Cannot get shader layer item");
                }

                shaderLayers.push_back(shaderLayerItem);
        }
#else
        CLxLayerStack shaderLayers;
        if (LXx_FAIL(context->LayerStack(surface, shaderLayers)))
        {
                LOG_ERROR("Failed to obtain layer stack for surface");
        }
#endif

        LOG_INFO(getShaderTreeForSurface(shaderLayers, context, &channelReader));
}

} // namespace SceneRenderTrace

