/*
 * LX uiimage module
 *
 * Copyright (c) 2008-2017 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef LX_uiimage_H
#define LX_uiimage_H
 #ifdef __cplusplus
  extern "C" {
 #endif


typedef struct vt_ILxUIImageGrouper ** ILxUIImageGrouperID;
typedef struct vt_ILxUIImageService ** ILxUIImageServiceID;
typedef struct vt_ILxUIImageGroup ** ILxUIImageGroupID;
#include <lxserver.h>
#include <lxvalue.h>
#ifdef long
 #undef long
  #include <time.h>
 #define long   longs_are_evil
#else
  #include <time.h>
#endif



typedef struct vt_ILxUIImageGrouper {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        UserName) (
                LXtObjectID      self,
                const char      *path,
                char            *buffer,
                int              len );
                LXxMETHOD(  LxResult,
        Paths) (
                LXtObjectID      self,
                const char      *path,
                ILxValueArrayID  array );
} ILxUIImageGrouper;
typedef struct vt_ILxUIImageService {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        ScriptQuery) (
                LXtObjectID              self,
                void                   **ppvObj);
                LXxMETHOD(  LxResult,
        RegisterType) (
                LXtObjectID              self,
                LXtID4                   type,
                const char              *name,
                ILxUIImageGrouperID      grouper,
                int                      flags);
                LXxMETHOD(  int,
        TypeCount) (
                LXtObjectID              self );
                LXxMETHOD(  LxResult,
        TypeByIndex) (
                LXtObjectID              self,
                int                      i,
                LXtID4                  *type);
                LXxMETHOD(  LxResult,
        TypeNameByIndex) (
                LXtObjectID               self,
                int                       i,
                const char              **name);
                LXxMETHOD(  LxResult,
        TypeUserNameByIndex) (
                LXtObjectID               self,
                int                       i,
                const char              **username);
                LXxMETHOD(  LxResult,
        TypeFlagsByIndex) (
                LXtObjectID              self,
                int                      i,
                int                     *flags);
                LXxMETHOD(  LxResult,
        TypeLookup) (
                LXtObjectID               self,
                const char               *name,
                LXtID4                    type,
                int                      *index);
                LXxMETHOD(  LxResult,
        TypeSelected) (
                LXtObjectID               self,
                const char               *name,
                LXtID4                    type,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        TypeSetSelected) (
                LXtObjectID               self,
                const char               *name,
                LXtID4                    type,
                const char               *path);
                LXxMETHOD(  int,
        GroupCount) (
                LXtObjectID               self,
                LXtID4                    type );
                LXxMETHOD(  int,
        GroupByIndex) (
                LXtObjectID               self,
                LXtID4                    type,
                int                       i,
                void                    **ppvObj );
                LXxMETHOD(  LxResult,
        GroupLookup) (
                LXtObjectID               self,
                LXtID4                    type,
                const char               *path,
                void                    **ppvObj );
                LXxMETHOD(  LxResult,
        GroupAdd) (
                LXtObjectID               self,
                LXtID4                    type,
                const char               *path,
                int                       loadImages,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        GroupRemove) (
                LXtObjectID               self,
                LXtID4                    type,
                ILxUIImageGroupID         group);
                LXxMETHOD(  LxResult,
        GroupClearAll) (
                LXtObjectID               self,
                LXtID4                    type);
                LXxMETHOD(  LxResult,
        GroupLoad) (
                LXtObjectID               self,
                LXtID4                    type,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        GetCachedImage) (
                LXtObjectID               self,
                const char               *path,
                int                       mode,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        FlushCachedImage) (
                LXtObjectID               self,
                const char               *path,
                int                       mode);
                LXxMETHOD(  LxResult,
        GetEmbedablePath) (
                LXtObjectID               self,
                const char               *path,
                int                       mode,
                const char              **embed);
} ILxUIImageService;
typedef struct vt_ILxUIImageGroup {
        ILxUnknown       iunk;
                LXxMETHOD(  LxResult,
        UserName) (
                LXtObjectID               self,
                const char              **username);
                LXxMETHOD(  LxResult,
        ClientType) (
                LXtObjectID               self,
                LXtID4                   *type);
                LXxMETHOD(  LxResult,
        ImageCount) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        ImagePathByIndex) (
                LXtObjectID               self,
                int                       i,
                char                     *buffer,
                int                       len);
                LXxMETHOD(  LxResult,
        ImageMetricsByIndex) (
                LXtObjectID               self,
                int                       i,
                int                      *w,
                int                      *h,
                int                      *depth);
                LXxMETHOD(  LxResult,
        ImageByIndex) (
                LXtObjectID               self,
                int                       i,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        ImageLookup) (
                LXtObjectID               self,
                const char               *path,
                void                    **ppvObj);
                LXxMETHOD(  LxResult,
        DoAllImagesExist) (
                LXtObjectID               self);
                LXxMETHOD(  LxResult,
        FirstExistingImagePath) (
                LXtObjectID               self,
                char                     *buffer,
                int                       len);
                LXxMETHOD(  LxResult,
        FirstExistingImageIndex) (
                LXtObjectID               self,
                int                      *index);
                LXxMETHOD(  LxResult,
        LastUsed) (
                LXtObjectID               self,
                time_t                   *lastUsed,
                int                      *ms);
} ILxUIImageGroup;

#define LXu_UIIMAGEGROUPER              "B69F3583-F3C7-4059-BF8D-84CB61F34260"
#define LXa_UIIMAGEGROUPER              "uiimagegrouper"
#define LXu_UIIMAGESERVICE              "ECB8DE30-E0B1-4cda-8571-580ABEA1AC4D"
#define LXa_UIIMAGESERVICE              "uiimageservice"

#define LXe_UIIMAGE_INCOMPLETE_GROUP    LXxGOODCODE( LXeSYS_UIIMAGE,   1)       // Warning
#define LXe_UIIMAGE_ALREADY_EXISTS      LXxFAILCODE( LXeSYS_UIIMAGE,   1)
#define LXe_UIIMAGE_LOAD_FAILED         LXxFAILCODE( LXeSYS_UIIMAGE,   2)
#define LXfUIIMAGE_ALLOW_NONE           0x01
#define LXfUIIMAGE_COLOR_CORRECT        0x02
#define LXu_UIIMAGEGROUP                "B1B2816C-B1FC-4b66-9A01-D4969D37ED3C"
#define LXa_UIIMAGEGROUP                "uiimagegroup"
// Base images
#define LXiUIIMG_CACHED_MAIN            0
#define LXiUIIMG_CACHED_THUMB           1
#define LXiUIIMG_CACHED_FACE            2
#define LXiUIIMG_CACHED_ICON_SMALL      3
#define LXiUIIMG_CACHED_ICON_LARGE      4

#define LXiUIIMG_CACHED_BASE_COUNT      5
#define LXiUIIMG_CACHED_MOD_SCALAR      4               // Used with BASE_COUNT to figure out how many cache slots we need

// Flags to modify behavior
#define LXfUIIMG_CACHED_CORRECTED       0x10            // Color corrected (vs. uncorrected)
#define LXfUIIMG_CACHED_SQUARE          0x20            // Square aspect (vs. original aspect)

// Masks
#define LXmUIIMG_CACHED_BASE            0x0F
#define LXmUIIMG_CACHED_MOD             0xF0
#define LXfUIIMG_FLUSH_MAIN             0x01
#define LXfUIIMG_FLUSH_THUMB            0x02
#define LXfUIIMG_FLUSH_FACE             0x04
#define LXfUIIMG_FLUSH_ICON_SMALL       0x08
#define LXfUIIMG_FLUSH_ICON_LARGE       0x10
#define LXiUIIMG_FLUSH_ALL      (LXfUIIMG_FLUSH_MAIN | LXfUIIMG_FLUSH_THUMB | LXfUIIMG_FLUSH_FACE | LXfUIIMG_FLUSH_ICON_SMALL | LXfUIIMG_FLUSH_ICON_LARGE)
#define LXiUIIMG_NONE   ((void *)-1)

 #ifdef __cplusplus
  }
 #endif
#endif

