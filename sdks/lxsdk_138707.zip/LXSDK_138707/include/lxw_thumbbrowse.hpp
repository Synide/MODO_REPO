/*
 * C++ wrapper for lxthumbbrowse.h
 *
 *	Copyright (c) 2008-2017 The Foundry Group LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 *
 */
#ifndef LXW_THUMBBROWSE_HPP
#define LXW_THUMBBROWSE_HPP

#include <lxthumbbrowse.h>
#include <lx_wrap.hpp>
#include <string>

namespace lx {
    static const LXtGUID guid_DTBDropPreview = {0x7ccfca70,0x79d5,0x42ed,0xa5,0xbf,0x5d,0xfd,0x5b,0xc3,0x26,0x2b};
    static const LXtGUID guid_DTBGroupSortOverride = {0x0da992be,0x74c8,0x4c25,0xa4,0x02,0xc6,0x92,0x16,0xe5,0x2d,0xfb};
};

class CLxLoc_DTBDropPreview : public CLxLocalize<ILxDTBDropPreviewID>
{
public:
  void _init() {m_loc=0;}
  CLxLoc_DTBDropPreview() {_init();}
  CLxLoc_DTBDropPreview(ILxUnknownID obj) {_init();set(obj);}
  CLxLoc_DTBDropPreview(const CLxLoc_DTBDropPreview &other) {_init();set(other.m_loc);}
  const LXtGUID * guid() const {return &lx::guid_DTBDropPreview;}
    LxResult
  MarkNone (void)
  {
    return m_loc[0]->MarkNone (m_loc);
  }
    LxResult
  MarkGridPos (const char *path, unsigned int x, unsigned int y)
  {
    return m_loc[0]->MarkGridPos (m_loc,path,x,y);
  }
    LxResult
  MarkEntry (const char *path)
  {
    return m_loc[0]->MarkEntry (m_loc,path);
  }
    LxResult
  MarkBetween (const char *path, int markBefore)
  {
    return m_loc[0]->MarkBetween (m_loc,path,markBefore);
  }
    LxResult
  MarkAnywhere (const char *path)
  {
    return m_loc[0]->MarkAnywhere (m_loc,path);
  }
};

class CLxImpl_DTBGroupSortOverride {
  public:
    virtual ~CLxImpl_DTBGroupSortOverride() {}
    virtual LxResult
      gso_SetArguments (const char *args)
        { return LXe_NOTIMPL; }
    virtual int
      gso_Sort (const char *string1, const char *string2)
        = 0;
};
#define LXxD_DTBGroupSortOverride_SetArguments LxResult gso_SetArguments (const char *args)
#define LXxO_DTBGroupSortOverride_SetArguments LXxD_DTBGroupSortOverride_SetArguments LXx_OVERRIDE
#define LXxD_DTBGroupSortOverride_Sort int gso_Sort (const char *string1, const char *string2)
#define LXxO_DTBGroupSortOverride_Sort LXxD_DTBGroupSortOverride_Sort LXx_OVERRIDE
template <class T>
class CLxIfc_DTBGroupSortOverride : public CLxInterface
{
    static LxResult
  SetArguments (LXtObjectID wcom, const char *args)
  {
    LXCWxINST (CLxImpl_DTBGroupSortOverride, loc);
    try {
      return loc->gso_SetArguments (args);
    } catch (LxResult rc) { return rc; }
  }
    static int
  Sort (LXtObjectID wcom, const char *string1, const char *string2)
  {
    LXCWxINST (CLxImpl_DTBGroupSortOverride, loc);
    return loc->gso_Sort (string1,string2);
  }
  ILxDTBGroupSortOverride vt;
public:
  CLxIfc_DTBGroupSortOverride ()
  {
    vt.SetArguments = SetArguments;
    vt.Sort = Sort;
    vTable = &vt.iunk;
    iid = &lx::guid_DTBGroupSortOverride;
  }
};
class CLxLoc_DTBGroupSortOverride : public CLxLocalize<ILxDTBGroupSortOverrideID>
{
public:
  void _init() {m_loc=0;}
  CLxLoc_DTBGroupSortOverride() {_init();}
  CLxLoc_DTBGroupSortOverride(ILxUnknownID obj) {_init();set(obj);}
  CLxLoc_DTBGroupSortOverride(const CLxLoc_DTBGroupSortOverride &other) {_init();set(other.m_loc);}
  const LXtGUID * guid() const {return &lx::guid_DTBGroupSortOverride;}
    LxResult
  SetArguments (const char *args)
  {
    return m_loc[0]->SetArguments (m_loc,args);
  }
    int
  Sort (const char *string1, const char *string2)
  {
    return m_loc[0]->Sort (m_loc,string1,string2);
  }
};

#endif

