/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_NODE_H
#define CIO_NODE_H

#include "cio_element.h"
#include "cio_math.h"
#include "cio_strings.h"

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Library instances.
 */

class NodeElement;

class InstanceCameraElement : public Element
{
    public:
                                 InstanceCameraElement (
                                         NodeElement		&node);
        virtual			~InstanceCameraElement ();
};

class InstanceControllerElement;
class InstanceGeometryElement;

class InstanceMaterialElement : public Element
{
    public:
                                 InstanceMaterialElement (
                                         InstanceControllerElement &controller);
                                 InstanceMaterialElement (
                                         InstanceGeometryElement &geometry);
        virtual			~InstanceMaterialElement ();

        bool			 LinkNextInstanceMaterial (
                                        InstanceMaterialElement &instanceMaterial);

        std::string		 GetSymbol () const;
        std::string		 GetTarget () const;

        bool			 HasBind () const;
        std::string		 GetBindSemantic () const;
        std::string		 GetBindTarget () const;

        bool			 HasBindVertexInput () const;
        std::string		 GetBVISemantic () const;
        std::string		 GetBVIInputSemantic () const;
        unsigned		 GetBVIInputSet () const;
};

class InstanceControllerElement : public Element
{
        friend class InstanceMaterialElement;

    public:
                                 InstanceControllerElement (
                                         NodeElement		&node);
        virtual			~InstanceControllerElement ();

        bool			 HasInstanceMaterial () const;
        bool			 LinkFirstInstanceMaterial (
                                        InstanceMaterialElement &instanceMaterial);
};

class InstanceGeometryElement : public Element
{
        friend class InstanceMaterialElement;

    public:
                                 InstanceGeometryElement (
                                         NodeElement		&node);
        virtual			~InstanceGeometryElement ();

        bool			 HasInstanceMaterial () const;
        bool			 LinkFirstInstanceMaterial (
                                        InstanceMaterialElement &instanceMaterial);
};

class InstanceLightElement : public Element
{
    public:
                                 InstanceLightElement (
                                         NodeElement		&node);
        virtual			~InstanceLightElement ();
};

class InstanceNodeElement : public Element
{
public:
                                 InstanceNodeElement (
                                        NodeElement		&node);
        virtual			~InstanceNodeElement ();
};

/*
 * ---------------------------------------------------------------------------
 * Transform.
 *
 * A switched element type that represents any of the possible
 * transform element types.
 */

/*
 * Transforms can be layered in any combination of the
 * following transformation types.
 */
typedef enum en_TransformType
{
        TRANSFORM_TYPE_UNKNOWN,
        TRANSFORM_TYPE_LOOKAT,
        TRANSFORM_TYPE_MATRIX,
        TRANSFORM_TYPE_ROTATE,
        TRANSFORM_TYPE_SCALE,
        TRANSFORM_TYPE_SKEW,
        TRANSFORM_TYPE_TRANSLATE
} TransformType;

typedef std::vector<TransformType>	TransformTypeArray;

/*
 * Primary or arbitrary (mixed) transform axis.
 */
typedef enum en_RotateAxis
{
        ROTATE_AXIS_X,
        ROTATE_AXIS_Y,
        ROTATE_AXIS_Z,
        ROTATE_AXIS_MULTI = 10,
        ROTATE_AXIS_ARBITRARY,
        ROTATE_AXIS_NONE
} RotateAxis;

typedef std::vector<RotateAxis>		RotateAxisArray;

class TransformElement : public Element
{
        friend class NodeElement;

    public:
                                 TransformElement (
                                        NodeElement		&node,
                                        bool			 collapsible = true);
        virtual			~TransformElement ();

        TransformType		 GetTransformType () const;

        bool			 GetLookAt (
                                        math::Vector3	&eyePosition,
                                        math::Vector3	&interestPosition,
                                        math::Vector3	&upVector) const;

        bool			 GetMatrix (
                                        math::Matrix4	&value) const;

        bool			 GetScale (
                                        math::Vector3	&scale) const;

        RotateAxis		 GetRotateAxis () const;
        math::RotationOrder	 GetRotationOrder () const;
        bool			 GetRotateAngles (
                                        math::Vector3	&rotateAngles) const;
        bool			 GetRotate (
                                        math::Vector4	&rotate) const;
        bool			 GetRotateAxisSIDs (StringArray	&sids) const;

        typedef double           DoubleVectorSkew[7];

        bool			 GetTranslate (
                                        math::Vector3	&translate) const;

        bool			 GetSkew (
                                        DoubleVectorSkew &skew) const;

        bool			 LinkPreviousTransform (
                                        TransformElement &transform);

    protected:
        bool			 LinkChildElem (ElementXML *childElem);

    private:
        struct pv_TransformElement *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Node.
 */

class NodeElement_modo401;
class NodeLibraryElement;
class VisualSceneElement;

class NodeElement : public Element
{
        friend class InstanceCameraElement;
        friend class InstanceControllerElement;
        friend class InstanceGeometryElement;
        friend class InstanceLightElement;
        friend class InstanceMaterialElement;
        friend class InstanceNodeElement;

        friend class NodeElement_modo401;
        friend class TransformElement;

    public:
                                 NodeElement (
                                        NodeLibraryElement	&library);
                                 NodeElement (
                                        VisualSceneElement	&visualScene,
                                        const std::string	&name);
                                 NodeElement (
                                        VisualSceneElement	&visualScene,
                                        const std::string	&id,
                                        const std::string	&name);
                                 NodeElement (
                                        VisualSceneElement	&visualScene,
                                        const std::string	&id,
                                        const std::string	&name,
                                        const std::string	&type);
                                 NodeElement (
                                        VisualSceneElement	&visualScene);
                                 NodeElement (
                                        NodeElement		&node,
                                        const std::string	&name);
                                 NodeElement (
                                        NodeElement		&node,
                                        const std::string	&id,
                                        const std::string	&name);
                                 NodeElement (
                                        NodeElement		&node,
                                        const std::string	&id,
                                        const std::string	&name,
                                        const std::string	&type);
                                 NodeElement (
                                        NodeElement		&node);
        virtual			~NodeElement ();

        /*
         * Per-item asset tagging.
         */
        bool			 HasAsset () const;

        /*
         * Transformations.
         */
        bool			 HasTransform () const;

        bool			 HasLookAt () const;
        bool			 HasMatrix () const;
        bool			 HasRotate () const;
        bool			 HasScale () const;
        bool			 HasTranslate () const;
        bool			 HasSkew () const;

        bool			 LinkFirstTransform (
                                        TransformElement &transform);
        bool			 LinkLastTransform (
                                        TransformElement &transform);

        /*
         * Library instances.
         */
        bool			 HasInstanceCamera () const;
        bool			 LinkFirstInstanceCamera (
                                        InstanceCameraElement &instance);

        bool			 HasInstanceController () const;
        bool			 LinkFirstInstanceController (
                                        InstanceControllerElement &instance);
        bool			 LinkNextInstanceController (
                                        InstanceControllerElement &instance);

        bool			 HasInstanceGeometry () const;
        bool			 LinkFirstInstanceGeometry (
                                        InstanceGeometryElement &instance);
        bool			 LinkNextInstanceGeometry (
                                        InstanceGeometryElement &instance);

        bool			 HasInstanceLight () const;
        bool			 LinkFirstInstanceLight (
                                        InstanceLightElement &instance);

        bool			 HasInstanceNode () const;
        bool			 LinkFirstInstanceNode (
                                        InstanceNodeElement &instance);

        /*
         * Sub nodes.
         */
        bool			 HasSubNode () const;
        bool			 LinkFirstSubNode (NodeElement &node);
        bool			 LinkNextNode (NodeElement &node);

        /*
         * Technique profiles.
         */
        bool			 LinkTechniqueProfile_modo401 (
                                        NodeElement_modo401 &node);

    protected:
        void			 AddNode (NodeElement &node);
        void			 AddInstanceLight (
                                        InstanceLightElement &instanceLight);
};

/*
 * ---------------------------------------------------------------------------
 * Node Technique Profile modo 401.
 */
class NodeElement_modo401 : public Element
{
    public:
                                 NodeElement_modo401 (
                                        NodeElement &node);
        virtual			~NodeElement_modo401 ();

        /*
         * Common channelized locator parameters that can be
         * targeted for animation.
         *
         * [TODO] Remove these from the modo 401 light element,
         *        and update the extensions docs on collada.org.
         */

        bool			 GetRender (std::string &render);
        void			 SetRender (const std::string &render);

        bool			 GetDisplayVisible (std::string &render);
        void			 SetDisplayVisible (const std::string &render);

        bool			 GetDisplaySize (double &size);
        void			 SetDisplaySize (double size);

        bool			 GetDissolve (double &dissolve);
 	void			 SetDissolve (double dissolve);

        /*
         * Transform pivots and their inverses appear as successive
         * param elements with SIDs and semantic attributes indicating
         * the transform sub-type for each entry.
         */
        bool			 GetTransformLink (
                                        const std::string	&sourceTransformID,
                                        std::string		&transformType,
                                        std::string		&linkedTransformID);

    private:
        struct pv_NodeElement_modo401 *pv;
};

/*
 * ---------------------------------------------------------------------------
 * Node Library.
 */

class COLLADAElement;

class NodeLibraryElement : public Element
{
        friend class NodeElement;

    public:
                                 NodeLibraryElement (
                                        COLLADAElement &collada);
        virtual			~NodeLibraryElement ();

        bool			 HasNode () const;
        bool			 LinkNode (
                                        const std::string &nodeID,
                                        NodeElement &node);

    protected:
        void			 AddNode (NodeElement &node);
};

} // namespace cio

#endif // CIO_NODE_H

