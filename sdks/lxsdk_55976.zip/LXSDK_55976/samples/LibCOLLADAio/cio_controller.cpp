/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_controller.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"
#include "cio_source.h"
#include "cio_math.h"

#include <string>
#include <math.h>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Vertex Weights.
 */

struct pv_VertexWeightsElement
{
        pv_VertexWeightsElement ()
                :
                offset(0)
        {
        }

        string			 skinID;
        unsigned		 offset;
};

VertexWeightsElement::VertexWeightsElement (
        SkinElement		&skin,
        vector<unsigned>	&vertexWeightCounts,
        vector<unsigned>	&jointWeightIndices)
        :
        Element(skin.PV ()),
        pv(new pv_VertexWeightsElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->skinID = skin.GetControllerID ();

                skin.AddVertexWeights (*this);
        }

        AddJointInput ();
        AddWeightInput ();
        AddVertexWeightCounts (vertexWeightCounts);
        AddVertexWeightIndices (jointWeightIndices);
}

VertexWeightsElement::~VertexWeightsElement ()
{
}

        bool
VertexWeightsElement::HasJointInput () const
{
        bool	foundInput(false);
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_JOINT_INPUT_SEMANTIC) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        bool
VertexWeightsElement::HasWeightInput () const
{
        bool	foundInput(false);
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_WEIGHT_INPUT_SEMANTIC) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        bool
VertexWeightsElement::GetVertexWeightCounts (
        vector<unsigned>	&vertexCounts)
{
        bool	linked(false);

        ElementXML *vCountArray = GetElementHandle ().FirstChildElement (
                ELEMENT_VCOUNT).Element ();
        if (vCountArray != NULL) {
                GetElementValue (vCountArray, vertexCounts);
                linked = true;
        }

        return linked;
}

        bool
VertexWeightsElement::GetVertexWeightIndices (
        vector<unsigned>	&inputIndices)
{
        bool	linked(false);

        ElementXML *vArray = GetElementHandle ().FirstChildElement (
                ELEMENT_V).Element ();
        if (vArray != NULL) {
                GetElementValue (vArray, inputIndices);
                linked = true;
        }

        return linked;
}

        void
VertexWeightsElement::AddJointInput ()
{
        ElementXML *input = AddElement (ELEMENT_INPUT);
        if (input != NULL) {
                input->SetAttribute (
                        ATTRIBUTE_SEMANTIC, ATTRVALUE_JOINT_INPUT_SEMANTIC);
                input->SetAttribute (ATTRIBUTE_OFFSET, pv->offset++);

                string jointSourceID = pv->skinID +
                        string(ATTRVALUE_DASHSEPARATORSYMBOL) +
                        string (ATTRVALUE_JOINTS_SOURCE_NAME);
                input->SetAttribute (
                        ATTRIBUTE_SOURCE,
                        URI_Ref (jointSourceID));
        }
}

        void
VertexWeightsElement::AddWeightInput ()
{
        ElementXML *input = AddElement (ELEMENT_INPUT);
        if (input != NULL) {
                input->SetAttribute (
                        ATTRIBUTE_SEMANTIC, ATTRVALUE_WEIGHT_INPUT_SEMANTIC);
                input->SetAttribute (ATTRIBUTE_OFFSET, pv->offset++);
                string weightsID = pv->skinID +
                        string(ATTRVALUE_DASHSEPARATORSYMBOL) +
                        string (ATTRVALUE_WEIGHTS_SOURCE_NAME);
                input->SetAttribute (
                        ATTRIBUTE_SOURCE,
                        URI_Ref (weightsID));
        }
}

/*
 * Add a vector of unsigned ints to a float array.
 */
        static void
AddUnsignedArrayValues(
        VertexWeightsElement	&vertexWeights,
        ElementXML		*unsignedArray,
        vector<unsigned>	&values)
{
        string arrayText;
        for (vector<unsigned>::const_iterator iter = values.begin ();
             iter != values.end (); ++iter) {
                arrayText += IntegerToString(*iter);
                     if (iter + 1 != values.end()) {
                        arrayText += string(ATTRVALUE_SPACE);
                }
        }
        vertexWeights.SetElementValue (unsignedArray, arrayText);
}

        void
VertexWeightsElement::AddVertexWeightCounts (
        vector<unsigned>	&vertexCounts)
{
        unsigned count = static_cast<unsigned>(vertexCounts.size ());
        SetAttribute (ATTRIBUTE_COUNT, count);

        ElementXML *vCountArray = AddElement (ELEMENT_VCOUNT);
        AddUnsignedArrayValues (*this, vCountArray, vertexCounts);
}


        void
VertexWeightsElement::AddVertexWeightIndices (
        vector<unsigned>	&inputIndices)
{
        ElementXML *vArray = AddElement (ELEMENT_V);
        AddUnsignedArrayValues (*this, vArray, inputIndices);
}

 /*
 * ---------------------------------------------------------------------------
 * Joints.
 */

struct pv_JointsElement
{
        pv_JointsElement ()
        {
        }

        string			skinID;
};

JointsElement::JointsElement (
        SkinElement		&skin)
        :
        Element(skin.PV ()),
        pv(new pv_JointsElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->skinID = skin.GetControllerID ();

                skin.AddJoints (*this);

                AddJointInput ();
                AddInvBindMatrixInput ();
        }
}

JointsElement::~JointsElement ()
{
}

        bool
JointsElement::HasJointInput () const
{
        bool	foundInput(false);
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_JOINT_INPUT_SEMANTIC) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        bool
JointsElement::HasInvBindMatrixInput () const
{
        bool	foundInput(false);
        ElementXML *input = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (input && !foundInput) {
                if (GetAttribute (input, ATTRIBUTE_SEMANTIC) == ATTRVALUE_INV_BIND_MATRIX_SEMANTIC) {
                        foundInput = true;
                        break;
                }
                input = input->NextSiblingElement (ELEMENT_INPUT);
        }

        return foundInput;
}

        void
JointsElement::AddJointInput ()
{
        ElementXML *input = AddElement (ELEMENT_INPUT);
        if (input != NULL) {
                input->SetAttribute (
                        ATTRIBUTE_SEMANTIC, ATTRVALUE_JOINT_INPUT_SEMANTIC);
                string jointSourceID = pv->skinID +
                        string(ATTRVALUE_DASHSEPARATORSYMBOL) +
                        string (ATTRVALUE_JOINTS_SOURCE_NAME);
                input->SetAttribute (
                        ATTRIBUTE_SOURCE,
                        URI_Ref (jointSourceID));
        }
}

        void
JointsElement::AddInvBindMatrixInput ()
{
        ElementXML *input = AddElement (ELEMENT_INPUT);
        if (input != NULL) {
                input->SetAttribute (
                        ATTRIBUTE_SEMANTIC, ATTRVALUE_INV_BIND_MATRIX_SEMANTIC);
                string invBindMatrixID = pv->skinID +
                        string(ATTRVALUE_DASHSEPARATORSYMBOL) +
                        string (ATTRVALUE_MATRICES_SOURCE_NAME);
                input->SetAttribute (
                        ATTRIBUTE_SOURCE,
                        URI_Ref (invBindMatrixID));
        }
}

/*
 * ---------------------------------------------------------------------------
 * Skin.
 */

struct pv_SkinElement
{
        pv_SkinElement ()
        {
        }

        string			controllerID;
};

SkinElement::SkinElement (
         ControllerElement	&controller,
         const string		&name)
        :
        Element(controller.PV ()),
        pv(new pv_SkinElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->controllerID = controller.GetID ();

                controller.AddSkin (*this);
        }
}

SkinElement::SkinElement (
         ControllerElement	&controller)
        :
        Element(controller.PV ()),
        pv(new pv_SkinElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                pv->controllerID = controller.GetID ();
                controller.LinkSkin (*this);
        }
}

SkinElement::~SkinElement ()
{
}

        string
SkinElement::GetControllerID () const
{
        return pv->controllerID;
}

        string
SkinElement::GetSourceMeshURI () const
{
        return GetAttribute (ATTRIBUTE_SOURCE);
}

        void
SkinElement::SetSourceMeshURI (
        const string	&sourceMeshURI)
{
        SetAttribute (ATTRIBUTE_SOURCE, sourceMeshURI);
}

        bool
SkinElement::LinkBindShapeMatrix (
        math::Matrix4		&matrix)
{
        bool	linked(false);

        ElementXML *bindShapeMatrixArray = GetElementHandle ().FirstChildElement (
                ELEMENT_BIND_SHAPE_MATRIX).Element ();
        if (bindShapeMatrixArray != NULL) {
                
                linked = GetElementValue (bindShapeMatrixArray, matrix);
        }

        return linked;
}

        void
SkinElement::AddBindShapeMatrix (
        const math::Matrix4	&matrix)
{
        ElementXML *bindShapeMatrixArray = AddElement (ELEMENT_BIND_SHAPE_MATRIX);

        SetElementValue (bindShapeMatrixArray, matrix);
}

        bool
SkinElement::HasSource () const
{
        return HasChildElement (ELEMENT_SOURCE);
}

        bool
SkinElement::LinkSource (
        const string		&sourceID,
        SourceElement		&source)
{
        return LinkFirstChildElement (ELEMENT_SOURCE, sourceID, source);
}

        void
SkinElement::AddSource (SourceElement &source)
{
        source.SetElement (AddElement (ELEMENT_SOURCE));
}

        void
SkinElement::AddJoints (
        JointsElement		&joints)
{
        joints.SetElement (AddElement (ELEMENT_JOINTS));
}

        void
SkinElement::AddVertexWeights (
        VertexWeightsElement	&vertexWeights)
{
        vertexWeights.SetElement (AddElement (ELEMENT_VERTEX_WEIGHTS));
}

/*
 * ---------------------------------------------------------------------------
 * Controller.
 */

ControllerElement::ControllerElement (
        ControllerLibraryElement	&library,
        const std::string		&id,
        const std::string		&name)
        :
        Element(library.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddController (*this);

                string controllerID = ControllerID (ItemID (id));
                SetAttribute (ATTRIBUTE_ID, controllerID);
                SetAttribute (ATTRIBUTE_NAME, EscapeNCName (name));
        }
}

ControllerElement::ControllerElement (
        ControllerLibraryElement	&library)
        :
        Element(library.PV ())
{
}

ControllerElement::~ControllerElement ()
{
}

        bool
ControllerElement::HasSkin () const
{
        return HasChildElement (ELEMENT_SKIN);
}

        bool
ControllerElement::LinkSkin (SkinElement &skin)
{
        return LinkFirstChildElement (ELEMENT_SKIN, skin);
}

        void
ControllerElement::AddSkin (SkinElement &skin)
{
         skin.SetElement (AddElement (ELEMENT_SKIN));
}

/*
 * ---------------------------------------------------------------------------
 * Controller Library.
 */

ControllerLibraryElement::ControllerLibraryElement (COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddControllerLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkControllerLibrary (*this);
        }
}

ControllerLibraryElement::~ControllerLibraryElement ()
{
}

        bool
ControllerLibraryElement::HasController () const
{
        return HasChildElement (ELEMENT_CONTROLLER);
}

        bool
ControllerLibraryElement::LinkController (
        const string		&controllerID,
        ControllerElement	&controller)
{
        return LinkFirstChildElement (ELEMENT_CONTROLLER, controllerID, controller);
}

        void
ControllerLibraryElement::AddController (ControllerElement &controller)
{
        controller.SetElement (AddElement (ELEMENT_CONTROLLER));
}

} // namespace cio

