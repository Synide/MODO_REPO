/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef CIO_PROFILES_H
#define CIO_PROFILES_H

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * The custom modo profile techniques are used for elements that go beyond,
 * or provide an alternative representation for, the common techniques.
 */
extern const char* PROFILE_MODO401;
extern const char* PROFILE_MODO501;

/*
 * ---------------------------------------------------------------------------
 * Additional third-party profiles.
 */

/*
 * Autodesk 3ds Max.
 */
extern const char* PROFILE_3DS_MAX;

/*
 * Feeling Software COLLADA.
 */
extern const char* PROFILE_FCOLLADA;

/*
 * Google Earth (Sketchup).
 */
extern const char* PROFILE_GOOGLE_EARTH;

/*
 * Autodesk Maya.
 */
extern const char* PROFILE_MAYA;

/*
 * Okino Computer Graphics.
 */
extern const char* PROFILE_OKINO;

/*
 * Autodesk Softimage.
 */
extern const char* PROFILE_XSI;

/*
 * ---------------------------------------------------------------------------
 * Third-party profile elements.
 */

/*
 * 3ds Max profile elements.
 */
extern const char* ELEMENT_FRAME_RATE;

/*
 * FCOLLADA and Maya profile elements.
 */
extern const char* ELEMENT_END_TIME;
extern const char* ELEMENT_START_TIME;

/*
 * Google Earth (SketchUp) elements.
 */
extern const char* ELEMENT_DOUBLE_SIDED;

/*
 * Okino profile elements.
 */
extern const char* ELEMENT_SCENE_BOUNDING_MAX;
extern const char* ELEMENT_SCENE_BOUNDING_MIN;

/*
 * XSI profile elements.
 */
extern const char* ELEMENT_SI_AMBIENCE;
extern const char* ELEMENT_SI_ANGLE;
extern const char* ELEMENT_SI_COORDINATESYSTEM;
extern const char* ELEMENT_SI_SCENE;
extern const char* ELEMENT_SI_VISIBILITY;
extern const char* ELEMENT_XSI_LIMIT;
extern const char* ELEMENT_XSI_PARAM;
extern const char* ELEMENT_XSI_TRANSFORM;

/*
 * ---------------------------------------------------------------------------
 * "Pure virtual" modo 401 profile elements.
 *
 * These elements not instantiated, but are instead used to provide
 * context for their associated profile techniques.
 */
extern const char* VIRTUAL_ELEMENT_AREA_LIGHT;
extern const char* VIRTUAL_ELEMENT_CYLINDER_LIGHT;
extern const char* VIRTUAL_ELEMENT_DOME_LIGHT;
extern const char* VIRTUAL_ELEMENT_PHOTOMETRIC_LIGHT;
extern const char* VIRTUAL_ELEMENT_SUN_LIGHT;

extern const char* VIRTUAL_ELEMENT_RENDER;
extern const char* VIRTUAL_ELEMENT_ENVIRONMENT;
extern const char* VIRTUAL_ELEMENT_ENVIRONMENT_MATERIAL;

/*
 * ---------------------------------------------------------------------------
 * Attribute and element values.
 */

/*
 * XSI param SIDs.
 */
extern const char* ATTRVALUE_XSI_SID_FRAMERATE;
extern const char* ATTRVALUE_XSI_SID_START;
extern const char* ATTRVALUE_XSI_SID_END;
extern const char* ATTRVALUE_XSI_SID_TIMING;

extern const char* ATTRVALUE_XSI_SID_RED;
extern const char* ATTRVALUE_XSI_SID_GREEN;
extern const char* ATTRVALUE_XSI_SID_BLUE;

/*
 * XSI Timing values.
 */
extern const char* VALUE_XSI_TIMING_FRAMES;
extern const char* VALUE_XSI_TIMING_SECONDS;

/*
 * modo and Maya Infinity Behaviors.
 */
extern const char* VALUE_INFINITY_BEHAVIOR_CONSTANT;
extern const char* VALUE_INFINITY_BEHAVIOR_STOP;
extern const char* VALUE_INFINITY_BEHAVIOR_LINEAR;
extern const char* VALUE_INFINITY_BEHAVIOR_CYCLE;
extern const char* VALUE_INFINITY_BEHAVIOR_REPEAT;
extern const char* VALUE_INFINITY_BEHAVIOR_OSCILLATE;
extern const char* VALUE_INFINITY_BEHAVIOR_OFFSET_REPEAT;
extern const char* VALUE_INFINITY_BEHAVIOR_RESET;

/*
 * modo 401 technique profile render items.
 */
extern const char* SHADER_TREE;
extern const char* SHADER_TREE_NAME;

extern const char* SHADER_TREE_RENDER;
extern const char* SHADER_TREE_RENDER_NAME;

extern const char* SHADER_TREE_ENVIRONMENT;
extern const char* SHADER_TREE_ENVIRONMENT_NAME;

extern const char* SHADER_TREE_LIGHT;

/*
 * modo 401 technique profile effect types.
 */
extern const char* SHADER_LAYER_TYPE_ADVANCED_MATERIAL;
extern const char* SHADER_LAYER_TYPE_POLY_CELLULAR;
extern const char* SHADER_LAYER_TYPE_POLY_CHECKER;
extern const char* SHADER_LAYER_TYPE_POLY_CONSTANT;
extern const char* SHADER_LAYER_TYPE_POLY_DOTS;
extern const char* SHADER_LAYER_TYPE_ENVIRONMENT_MATERIAL;
extern const char* SHADER_LAYER_TYPE_FUR_MATERIAL;
extern const char* SHADER_LAYER_TYPE_POLY_GRADIENT;
extern const char* SHADER_LAYER_TYPE_POLY_GRID;
extern const char* SHADER_LAYER_TYPE_POLY_GROUP;
extern const char* SHADER_LAYER_TYPE_POLY_IMAGEMAP;
extern const char* SHADER_LAYER_TYPE_LIGHT_MATERIAL;
extern const char* SHADER_LAYER_TYPE_POLY_NOISE;
extern const char* SHADER_LAYER_TYPE_POLY_PROCESS;
extern const char* SHADER_LAYER_TYPE_RENDER_OUTPUT;
extern const char* SHADER_LAYER_TYPE_POLY_RIPPLES;
extern const char* SHADER_LAYER_TYPE_SHADER;
extern const char* SHADER_LAYER_TYPE_SURFACE_GENERATOR;
extern const char* SHADER_LAYER_TYPE_WEAVE;
extern const char* SHADER_LAYER_TYPE_WEIGHT_MAP_TEXTURE;
extern const char* SHADER_LAYER_TYPE_WOOD;

/*
 * modo 401 technique profile area light shapes.
 */
extern const char* PARAMVALUE_MODO_AREALIGHT_SHAPE_ELLIPSE;
extern const char* PARAMVALUE_MODO_AREALIGHT_SHAPE_RECTANGLE;

/*
 * modo 401 technique profile shader layer blend modes.
 */
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_ADD;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_COLORBURN;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_COLORDODGE;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_DARKEN;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_DIFFERENCE;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_DIVIDE;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_HARDLIGHT;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_LIGHTEN;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_MULTIPLY;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_NORMAL;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_NORMALMULT;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_OVERLAY;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_SCREEN;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_SOFTLIGHT;
extern const char* PARAMVALUE_MODO_SHADER_LAYER_BLEND_SUBTRACT;

/*
 * modo 401 technique profile visual scene values.
 */
extern const char* PARAMVALUE_MODO_SCENE_UPAXIS_X;
extern const char* PARAMVALUE_MODO_SCENE_UPAXIS_Y;
extern const char* PARAMVALUE_MODO_SCENE_UPAXIS_Z;

extern const char* PARAMVALUE_MODO_SCENE_TIME_SYSTEM_SECONDS;
extern const char* PARAMVALUE_MODO_SCENE_TIME_SYSTEM_FRAMES;
extern const char* PARAMVALUE_MODO_SCENE_TIME_SYSTEM_SMPTE;
extern const char* PARAMVALUE_MODO_SCENE_TIME_SYSTEM_FILMCODE;

/*
 * modo 401 technique profile camera optics projection types.
 */
extern const char* PARAMVALUE_MODO_PROJECTION_TYPE_PERSPECTIVE;
extern const char* PARAMVALUE_MODO_PROJECTION_TYPE_ORTHOGRAPHIC;
extern const char* PARAMVALUE_MODO_PROJECTION_TYPE_SPHERICAL;

/*
 * modo 401 technique profile camera imager film fit types.
 */
extern const char* PARAMVALUE_MODO_FILM_FIT_FILL;
extern const char* PARAMVALUE_MODO_FILM_FIT_HORIZONTAL;
extern const char* PARAMVALUE_MODO_FILM_FIT_VERTICAL;
extern const char* PARAMVALUE_MODO_FILM_FIT_OVERSCAN;

/*
 * modo 401 technique profile light types.
 */
extern const char* PARAMVALUE_MODO_LIGHT_TYPE_AREA_LIGHT;
extern const char* PARAMVALUE_MODO_LIGHT_TYPE_CYLINDER_LIGHT;
extern const char* PARAMVALUE_MODO_LIGHT_TYPE_DOME_LIGHT;
extern const char* PARAMVALUE_MODO_LIGHT_TYPE_PHOTO_LIGHT;
extern const char* PARAMVALUE_MODO_LIGHT_TYPE_POINT_LIGHT;
extern const char* PARAMVALUE_MODO_LIGHT_TYPE_SPOT_LIGHT;
extern const char* PARAMVALUE_MODO_LIGHT_TYPE_SUN_LIGHT;

/*
 * modo 401 techique profile light shadow types.
 */
extern const char* PARAMVALUE_MODO_LIGHT_SHADTYPE_NONE;
extern const char* PARAMVALUE_MODO_LIGHT_SHADTYPE_RAYTRACE;
extern const char* PARAMVALUE_MODO_LIGHT_SHADTYPE_SHADOWMAP;

/*
 * modo 401 technique profile render values.
 */
extern const char* PARAMVALUE_MODO_POLYRENDER_RESOLUTION_UNIT_PIXELS;
extern const char* PARAMVALUE_MODO_POLYRENDER_RESOLUTION_UNIT_INCHES;

extern const char* PARAMVALUE_MODO_BUCKET_ORDER_COLUMNS;
extern const char* PARAMVALUE_MODO_BUCKET_ORDER_HILBERT;
extern const char* PARAMVALUE_MODO_BUCKET_ORDER_RANDOM;
extern const char* PARAMVALUE_MODO_BUCKET_ORDER_ROWS;
extern const char* PARAMVALUE_MODO_BUCKET_ORDER_SPIRAL;

extern const char* PARAMVALUE_MODO_RENDER_AA_S1;
extern const char* PARAMVALUE_MODO_RENDER_AA_S16;
extern const char* PARAMVALUE_MODO_RENDER_AA_S2;
extern const char* PARAMVALUE_MODO_RENDER_AA_S32;
extern const char* PARAMVALUE_MODO_RENDER_AA_S4;
extern const char* PARAMVALUE_MODO_RENDER_AA_S64;
extern const char* PARAMVALUE_MODO_RENDER_AA_S8;

extern const char* PARAMVALUE_MODO_RENDER_AA_FILTER_BOX;
extern const char* PARAMVALUE_MODO_RENDER_AA_FILTER_GAUSSIAN;
extern const char* PARAMVALUE_MODO_RENDER_AA_FILTER_TRIANGLE;

extern const char* PARAMVALUE_MODO_RENDER_IRRADIANCEGRADIENTS_BOTH;
extern const char* PARAMVALUE_MODO_RENDER_IRRADIANCEGRADIENTS_NONE;
extern const char* PARAMVALUE_MODO_RENDER_IRRADIANCEGRADIENTS_ROTATION;
extern const char* PARAMVALUE_MODO_RENDER_IRRADIANCEGRADIENTS_TRANSLATION;

extern const char* PARAMVALUE_MODO_RENDER_INDIRECTILLUMINATIONSCOPE_ALL;
extern const char* PARAMVALUE_MODO_RENDER_INDIRECTILLUMINATIONSCOPE_ENVIRONMENT;
extern const char* PARAMVALUE_MODO_RENDER_INDIRECTILLUMINATIONSCOPE_GEOMETRY;
extern const char* PARAMVALUE_MODO_RENDER_INDIRECTILLUMINATIONSCOPE_VOLUMETRICS;

extern const char* PARAMVALUE_MODO_RENDER_INDIRECTCAUSTICS_BOTH;
extern const char* PARAMVALUE_MODO_RENDER_INDIRECTCAUSTICS_NONE;
extern const char* PARAMVALUE_MODO_RENDER_INDIRECTCAUSTICS_REFLECTION;
extern const char* PARAMVALUE_MODO_RENDER_INDIRECTCAUSTICS_REFRACTION;

/*
 * modo 401 technique profile parameters.
 *
 * See also the ItemTypeChannelRegistrar class for the bindings
 * between these parameters and the modo item types and channels.
 */
extern const char* PARAM_MODO_AREALIGHT_HEIGHT;
extern const char* PARAM_MODO_AREALIGHT_HEIGHT_NAME;
extern const char* PARAM_MODO_AREALIGHT_SHAPE;
extern const char* PARAM_MODO_AREALIGHT_SHAPE_NAME;
extern const char* PARAM_MODO_AREALIGHT_WIDTH;
extern const char* PARAM_MODO_AREALIGHT_WIDTH_NAME;

extern const char* PARAM_MODO_CAMERA_APERTURE_HEIGHT;
extern const char* PARAM_MODO_CAMERA_APERTURE_HEIGHT_NAME;
extern const char* PARAM_MODO_CAMERA_APERTURE_WIDTH;
extern const char* PARAM_MODO_CAMERA_APERTURE_WIDTH_NAME;
extern const char* PARAM_MODO_CAMERA_BLUR_LENGTH;
extern const char* PARAM_MODO_CAMERA_BLUR_LENGTH_NAME;
extern const char* PARAM_MODO_CAMERA_BLUR_OFFSET;
extern const char* PARAM_MODO_CAMERA_BLUR_OFFSET_NAME;
extern const char* PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE;
extern const char* PARAM_MODO_CAMERA_CONVERGENCE_DISTANCE_NAME;
extern const char* PARAM_MODO_CAMERA_FILM_FIT;
extern const char* PARAM_MODO_CAMERA_FILM_FIT_NAME;
extern const char* PARAM_MODO_CAMERA_FOCAL_LENGTH;
extern const char* PARAM_MODO_CAMERA_FOCAL_LENGTH_NAME;
extern const char* PARAM_MODO_CAMERA_FOCUS_DISTANCE;
extern const char* PARAM_MODO_CAMERA_FOCUS_DISTANCE_NAME;
extern const char* PARAM_MODO_CAMERA_F_STOP;
extern const char* PARAM_MODO_CAMERA_F_STOP_NAME;
extern const char* PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE;
extern const char* PARAM_MODO_CAMERA_INTEROCULAR_DISTANCE_NAME;
extern const char* PARAM_MODO_CAMERA_LENS_DISTORTION;
extern const char* PARAM_MODO_CAMERA_LENS_DISTORTION_NAME;
extern const char* PARAM_MODO_CAMERA_LENS_SQUEEZE;
extern const char* PARAM_MODO_CAMERA_LENS_SQUEEZE_NAME;
extern const char* PARAM_MODO_CAMERA_OFFSET_X;
extern const char* PARAM_MODO_CAMERA_OFFSET_X_NAME;
extern const char* PARAM_MODO_CAMERA_OFFSET_Y;
extern const char* PARAM_MODO_CAMERA_OFFSET_Y_NAME;
extern const char* PARAM_MODO_CAMERA_PROJECTION;
extern const char* PARAM_MODO_CAMERA_PROJECTION_NAME;
extern const char* PARAM_MODO_CAMERA_TARGET_DISTANCE;
extern const char* PARAM_MODO_CAMERA_TARGET_DISTANCE_NAME;

extern const char* PARAM_MODO_CYLINDERLIGHT_LENGTH;
extern const char* PARAM_MODO_CYLINDERLIGHT_LENGTH_NAME;
extern const char* PARAM_MODO_CYLINDERLIGHT_RADIUS;
extern const char* PARAM_MODO_CYLINDERLIGHT_RADIUS_NAME;

extern const char* PARAM_MODO_DOMELIGHT_RADIUS;
extern const char* PARAM_MODO_DOMELIGHT_RADIUS_NAME;

extern const char* PARAM_MODO_ENVIRONMENT_INTENSITY;
extern const char* PARAM_MODO_ENVIRONMENT_INTENSITY_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_CLAMP_SKY_BRIGHTNESS;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_CLAMP_SKY_BRIGHTNESS_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_COLOR;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_COLOR_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_EXPONENT;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_GROUND_EXPONENT_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_NADIR_COLOR;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_NADIR_COLOR_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_COLOR;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_COLOR_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_EXPONENT;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_SKY_EXPONENT_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_SOLAR_DISC_SIZE;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_SOLAR_DISC_SIZE_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_TYPE;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_TYPE_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_ZENITH_COLOR;
extern const char* PARAM_MODO_ENVIRONMENT_MATERIAL_ZENITH_COLOR_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_CAMERA;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_CAMERA_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_INDIRECT_RAYS;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_INDIRECT_RAYS_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFLECTION_RAYS;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFLECTION_RAYS_NAME;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFRACTION_RAYS;
extern const char* PARAM_MODO_ENVIRONMENT_VISIBLE_TO_REFRACTION_RAYS_NAME;

extern const char* PARAM_MODO_LIGHT_TYPE;
extern const char* PARAM_MODO_LIGHT_TYPE_NAME;
extern const char* PARAM_MODO_LIGHT_RADIANCE;
extern const char* PARAM_MODO_LIGHT_RADIANCE_NAME;
extern const char* PARAM_MODO_LIGHT_SAMPLES;
extern const char* PARAM_MODO_LIGHT_SAMPLES_NAME;
extern const char* PARAM_MODO_LIGHT_SHADOW_RESOLUTION;
extern const char* PARAM_MODO_LIGHT_SHADOW_RESOLUTION_NAME;
extern const char* PARAM_MODO_LIGHT_SHADOW_TYPE;
extern const char* PARAM_MODO_LIGHT_SHADOW_TYPE_NAME;
extern const char* PARAM_MODO_LIGHT_SIMPLE_SHADING;
extern const char* PARAM_MODO_LIGHT_SIMPLE_SHADING_NAME;

extern const char* PARAM_MODO_LOCATOR_DISPLAY_SIZE;
extern const char* PARAM_MODO_LOCATOR_DISPLAY_SIZE_NAME;
extern const char* PARAM_MODO_LOCATOR_DISPLAY_VISIBLE;
extern const char* PARAM_MODO_LOCATOR_DISPLAY_VISIBLE_NAME;
extern const char* PARAM_MODO_LOCATOR_DISSOLVE;
extern const char* PARAM_MODO_LOCATOR_DISSOLVE_NAME;
extern const char* PARAM_MODO_LOCATOR_RENDER;
extern const char* PARAM_MODO_LOCATOR_RENDER_NAME;

extern const char* PARAM_MODO_MESH_CURVE_RADIUS;
extern const char* PARAM_MODO_MESH_CURVE_RADIUS_NAME;
extern const char* PARAM_MODO_MESH_CURVE_REFINEMENT_ANGLE;
extern const char* PARAM_MODO_MESH_CURVE_REFINEMENT_ANGLE_NAME;
extern const char* PARAM_MODO_MESH_LINEAR_UVS;
extern const char* PARAM_MODO_MESH_LINEAR_UVS_NAME;
extern const char* PARAM_MODO_MESH_RENDER_CURVES;
extern const char* PARAM_MODO_MESH_RENDER_CURVES_NAME;
extern const char* PARAM_MODO_MESH_SPLINE_PATCH_LEVEL;
extern const char* PARAM_MODO_MESH_SPLINE_PATCH_LEVEL_NAME;
extern const char* PARAM_MODO_MESH_SUBDIVISION_LEVEL;
extern const char* PARAM_MODO_MESH_SUBDIVISION_LEVEL_NAME;

/*
 * The XML NCName value type has a very restrictive character set (letters,
 * digits, and the underscore), and it does not provide a mechanism for
 * escape sequences to reconstruct filtered characters, so we include the
 * un-fitered name as a param in the modo 401 technique profile data.
 */
extern const char* PARAM_MODO_NAME;
extern const char* PARAM_MODO_NAME_NAME;

extern const char* PARAM_MODO_PHOTOMETRICLIGHT_CONE_ANGLE;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_CONE_ANGLE_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_HEIGHT;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_HEIGHT_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_OUTSIDE;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_OUTSIDE_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_SOFT_EDGE_ANGLE;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_SOFT_EDGE_ANGLE_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_V_DISSOLVE;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_V_DISSOLVE_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_VOLUMETRICS;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_VOLUMETRICS_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_V_RAD;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_V_RAD_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_V_SAMPLES;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_V_SAMPLES_NAME;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_WIDTH;
extern const char* PARAM_MODO_PHOTOMETRICLIGHT_WIDTH_NAME;

extern const char* PARAM_MODO_POINTLIGHT_RADIUS;
extern const char* PARAM_MODO_POINTLIGHT_RADIUS_NAME;
extern const char* PARAM_MODO_POINTLIGHT_V_DISSOLVE;
extern const char* PARAM_MODO_POINTLIGHT_V_DISSOLVE_NAME;
extern const char* PARAM_MODO_POINTLIGHT_VOLUMETRICS;
extern const char* PARAM_MODO_POINTLIGHT_VOLUMETRICS_NAME;
extern const char* PARAM_MODO_POINTLIGHT_V_RAD;
extern const char* PARAM_MODO_POINTLIGHT_V_RAD_NAME;
extern const char* PARAM_MODO_POINTLIGHT_V_SAMPLES;
extern const char* PARAM_MODO_POINTLIGHT_V_SAMPLES_NAME;

extern const char* PARAM_MODO_POLYRENDER_ANTIALIASING;
extern const char* PARAM_MODO_POLYRENDER_ANTIALIASING_NAME;
extern const char* PARAM_MODO_POLYRENDER_ANTIALIASING_FILTER;
extern const char* PARAM_MODO_POLYRENDER_ANTIALIASING_FILTER_NAME;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_HEIGHT;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_HEIGHT_NAME;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_ORDER;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_ORDER_NAME;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_REVERSE_ORDER;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_REVERSE_ORDER_NAME;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_SKIP_EXISTING;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_SKIP_EXISTING_NAME;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_WIDTH;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_WIDTH_NAME;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_WRITE_TO_DISK;
extern const char* PARAM_MODO_POLYRENDER_BUCKET_WRITE_TO_DISK_NAME;
extern const char* PARAM_MODO_POLYRENDER_DEPTH_OF_FIELD;
extern const char* PARAM_MODO_POLYRENDER_DEPTH_OF_FIELD_NAME;
extern const char* PARAM_MODO_POLYRENDER_FRAME_DPI;
extern const char* PARAM_MODO_POLYRENDER_FRAME_DPI_NAME;
extern const char* PARAM_MODO_POLYRENDER_FRAME_HEIGHT;
extern const char* PARAM_MODO_POLYRENDER_FRAME_HEIGHT_NAME;
extern const char* PARAM_MODO_POLYRENDER_FRAME_PIXEL_ASPECT_RATIO;
extern const char* PARAM_MODO_POLYRENDER_FRAME_PIXEL_ASPECT_RATIO_NAME;
extern const char* PARAM_MODO_POLYRENDER_FRAME_RANGE_FIRST;
extern const char* PARAM_MODO_POLYRENDER_FRAME_RANGE_FIRST_NAME;
extern const char* PARAM_MODO_POLYRENDER_FRAME_RANGE_LAST;
extern const char* PARAM_MODO_POLYRENDER_FRAME_RANGE_LAST_NAME;
extern const char* PARAM_MODO_POLYRENDER_FRAME_STEP;
extern const char* PARAM_MODO_POLYRENDER_FRAME_STEP_NAME;
extern const char* PARAM_MODO_POLYRENDER_FRAME_WIDTH;
extern const char* PARAM_MODO_POLYRENDER_FRAME_WIDTH_NAME;
extern const char* PARAM_MODO_POLYRENDER_MOTION_BLUR;
extern const char* PARAM_MODO_POLYRENDER_MOTION_BLUR_NAME;
extern const char* PARAM_MODO_POLYRENDER_REFINE_BUCKET_BORDERS;
extern const char* PARAM_MODO_POLYRENDER_REFINE_BUCKET_BORDERS_NAME;
extern const char* PARAM_MODO_POLYRENDER_REFINEMENT_SHADING_RATE;
extern const char* PARAM_MODO_POLYRENDER_REFINEMENT_SHADING_RATE_NAME;
extern const char* PARAM_MODO_POLYRENDER_REFINEMENT_THRESHOLD;
extern const char* PARAM_MODO_POLYRENDER_REFINEMENT_THRESHOLD_NAME;
extern const char* PARAM_MODO_POLYRENDER_RESOLUTION_UNIT;
extern const char* PARAM_MODO_POLYRENDER_RESOLUTION_UNIT_NAME;
extern const char* PARAM_MODO_POLYRENDER_STEREOSCOPIC;
extern const char* PARAM_MODO_POLYRENDER_STEREOSCOPIC_NAME;

extern const char* PARAM_MODO_RENDER_ADAPTIVE_SUBDIVISION;
extern const char* PARAM_MODO_RENDER_ADAPTIVE_SUBDIVISION_NAME;
extern const char* PARAM_MODO_RENDER_AMBIENT_COLOR;
extern const char* PARAM_MODO_RENDER_AMBIENT_COLOR_NAME;
extern const char* PARAM_MODO_RENDER_AMBIENT_INTENSITY;
extern const char* PARAM_MODO_RENDER_AMBIENT_INTENSITY_NAME;
extern const char* PARAM_MODO_RENDER_CAUSTICS_LOCAL_PHOTONS;
extern const char* PARAM_MODO_RENDER_CAUSTICS_LOCAL_PHOTONS_NAME;
extern const char* PARAM_MODO_RENDER_CAUSTICS_TOTAL_PHOTONS;
extern const char* PARAM_MODO_RENDER_CAUSTICS_TOTAL_PHOTONS_NAME;
extern const char* PARAM_MODO_RENDER_DISPLACEMENT_RATE;
extern const char* PARAM_MODO_RENDER_DISPLACEMENT_RATE_NAME;
extern const char* PARAM_MODO_RENDER_DISPLACEMENT_RATIO;
extern const char* PARAM_MODO_RENDER_DISPLACEMENT_RATIO_NAME;
extern const char* PARAM_MODO_RENDER_ENABLE_DIRECT_CAUSTICS;
extern const char* PARAM_MODO_RENDER_ENABLE_DIRECT_CAUSTICS_NAME;
extern const char* PARAM_MODO_RENDER_ENABLE_INDIRECT_ILLUMINATION;
extern const char* PARAM_MODO_RENDER_ENABLE_INDIRECT_ILLUMINATION_NAME;
extern const char* PARAM_MODO_RENDER_ENABLE_IRRADIANCE_CACHING;
extern const char* PARAM_MODO_RENDER_ENABLE_IRRADIANCE_CACHING_NAME;
extern const char* PARAM_MODO_RENDER_INDIRECT_BOUNCES;
extern const char* PARAM_MODO_RENDER_INDIRECT_BOUNCES_NAME;
extern const char* PARAM_MODO_RENDER_INDIRECT_CAUSTICS;
extern const char* PARAM_MODO_RENDER_INDIRECT_CAUSTICS_NAME;
extern const char* PARAM_MODO_RENDER_INDIRECT_ILLUMINATION_SCOPE;
extern const char* PARAM_MODO_RENDER_INDIRECT_ILLUMINATION_SCOPE_NAME;
extern const char* PARAM_MODO_RENDER_INDIRECT_RANGE;
extern const char* PARAM_MODO_RENDER_INDIRECT_RANGE_NAME;
extern const char* PARAM_MODO_RENDER_INDIRECT_RAYS;
extern const char* PARAM_MODO_RENDER_INDIRECT_RAYS_NAME;
extern const char* PARAM_MODO_RENDER_INDIRECT_SUPERSAMPLING;
extern const char* PARAM_MODO_RENDER_INDIRECT_SUPERSAMPLING_NAME;
extern const char* PARAM_MODO_RENDER_INTERPOLATION_VALUES;
extern const char* PARAM_MODO_RENDER_INTERPOLATION_VALUES_NAME;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_GRADIENTS;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_GRADIENTS_NAME;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_RATE;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_RATE_NAME;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_RATIO;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_RATIO_NAME;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_RAYS;
extern const char* PARAM_MODO_RENDER_IRRADIANCE_RAYS_NAME;
extern const char* PARAM_MODO_RENDER_LOAD_IRRADIANCE_BEFORE_RENDER;
extern const char* PARAM_MODO_RENDER_LOAD_IRRADIANCE_BEFORE_RENDER_NAME;
extern const char* PARAM_MODO_RENDER_LOAD_IRRADIANCE_FILE;
extern const char* PARAM_MODO_RENDER_LOAD_IRRADIANCE_FILE_NAME;
extern const char* PARAM_MODO_RENDER_MICROPOLY_DISPLACEMENT;
extern const char* PARAM_MODO_RENDER_MICROPOLY_DISPLACEMENT_NAME;
extern const char* PARAM_MODO_RENDER_MINIMUM_EDGE_LENGTH;
extern const char* PARAM_MODO_RENDER_MINIMUM_EDGE_LENGTH_NAME;
extern const char* PARAM_MODO_RENDER_RAY_THRESHOLD;
extern const char* PARAM_MODO_RENDER_RAY_THRESHOLD_NAME;
extern const char* PARAM_MODO_RENDER_RAY_TRACING_SHADOWS;
extern const char* PARAM_MODO_RENDER_RAY_TRACING_SHADOWS_NAME;
extern const char* PARAM_MODO_RENDER_REFLECTION_DEPTH;
extern const char* PARAM_MODO_RENDER_REFLECTION_DEPTH_NAME;
extern const char* PARAM_MODO_RENDER_REFRACTION_DEPTH;
extern const char* PARAM_MODO_RENDER_REFRACTION_DEPTH_NAME;
extern const char* PARAM_MODO_RENDER_REGION;
extern const char* PARAM_MODO_RENDER_REGION_NAME;
extern const char* PARAM_MODO_RENDER_REGION_BOTTOM;
extern const char* PARAM_MODO_RENDER_REGION_BOTTOM_NAME;
extern const char* PARAM_MODO_RENDER_REGION_LEFT;
extern const char* PARAM_MODO_RENDER_REGION_LEFT_NAME;
extern const char* PARAM_MODO_RENDER_REGION_RIGHT;
extern const char* PARAM_MODO_RENDER_REGION_RIGHT_NAME;
extern const char* PARAM_MODO_RENDER_REGION_TOP;
extern const char* PARAM_MODO_RENDER_REGION_TOP_NAME;
extern const char* PARAM_MODO_RENDER_SAVE_IRRADIANCE_AFTER_RENDER;
extern const char* PARAM_MODO_RENDER_SAVE_IRRADIANCE_AFTER_RENDER_NAME;
extern const char* PARAM_MODO_RENDER_SAVE_IRRADIANCE_FILE;
extern const char* PARAM_MODO_RENDER_SAVE_IRRADIANCE_FILE_NAME;
extern const char* PARAM_MODO_RENDER_SMOOTH_POSITIONS;
extern const char* PARAM_MODO_RENDER_SMOOTH_POSITIONS_NAME;
extern const char* PARAM_MODO_RENDER_SUBDIVISION_RATE;
extern const char* PARAM_MODO_RENDER_SUBDIVISION_RATE_NAME;
extern const char* PARAM_MODO_RENDER_SUBSURFACE_SCATTERING;
extern const char* PARAM_MODO_RENDER_SUBSURFACE_SCATTERING_NAME;
extern const char* PARAM_MODO_RENDER_VOLUMETRICS_AFFECT_INDIRECT;
extern const char* PARAM_MODO_RENDER_VOLUMETRICS_AFFECT_INDIRECT_NAME;
extern const char* PARAM_MODO_RENDER_WALKTHROUGH_MODE;
extern const char* PARAM_MODO_RENDER_WALKTHROUGH_MODE_NAME;

extern const char* PARAM_MODO_SCENE_CURRENT_START_TIME;
extern const char* PARAM_MODO_SCENE_CURRENT_START_TIME_NAME;
extern const char* PARAM_MODO_SCENE_CURRENT_END_TIME;
extern const char* PARAM_MODO_SCENE_CURRENT_END_TIME_NAME;
extern const char* PARAM_MODO_SCENE_DEFAULT_DRAW_SIZE;
extern const char* PARAM_MODO_SCENE_DEFAULT_DRAW_SIZE_NAME;
extern const char* PARAM_MODO_SCENE_FPS;
extern const char* PARAM_MODO_SCENE_FPS_NAME;
extern const char* PARAM_MODO_SCENE_START_TIME;
extern const char* PARAM_MODO_SCENE_START_TIME_NAME;
extern const char* PARAM_MODO_SCENE_END_TIME;
extern const char* PARAM_MODO_SCENE_END_TIME_NAME;
extern const char* PARAM_MODO_SCENE_TIME;
extern const char* PARAM_MODO_SCENE_TIME_NAME;
extern const char* PARAM_MODO_SCENE_TIME_SYSTEM;
extern const char* PARAM_MODO_SCENE_TIME_SYSTEM_NAME;
extern const char* PARAM_MODO_SCENE_UP_AXIS;
extern const char* PARAM_MODO_SCENE_UP_AXIS_NAME;

extern const char* PARAM_MODO_SHADER_NODE_ENABLED;
extern const char* PARAM_MODO_SHADER_NODE_ENABLED_NAME;
extern const char* PARAM_MODO_SHADER_NODE_INVERTED;
extern const char* PARAM_MODO_SHADER_NODE_INVERTED_NAME;
extern const char* PARAM_MODO_SHADER_NODE_BLEND_MODE;
extern const char* PARAM_MODO_SHADER_NODE_BLEND_MODE_NAME;
extern const char* PARAM_MODO_SHADER_NODE_OPACITY;
extern const char* PARAM_MODO_SHADER_NODE_OPACITY_NAME;

extern const char* PARAM_MODO_SPOTLIGHT_CONE_ANGLE;
extern const char* PARAM_MODO_SPOTLIGHT_CONE_ANGLE_NAME;
extern const char* PARAM_MODO_SPOTLIGHT_OUTSIDE;
extern const char* PARAM_MODO_SPOTLIGHT_OUTSIDE_NAME;
extern const char* PARAM_MODO_SPOTLIGHT_RADIUS;
extern const char* PARAM_MODO_SPOTLIGHT_RADIUS_NAME;
extern const char* PARAM_MODO_SPOTLIGHT_SOFT_EDGE_ANGLE;
extern const char* PARAM_MODO_SPOTLIGHT_SOFT_EDGE_ANGLE_NAME;
extern const char* PARAM_MODO_SPOTLIGHT_V_DISSOLVE;
extern const char* PARAM_MODO_SPOTLIGHT_V_DISSOLVE_NAME;
extern const char* PARAM_MODO_SPOTLIGHT_VOLUMETRICS;
extern const char* PARAM_MODO_SPOTLIGHT_VOLUMETRICS_NAME;
extern const char* PARAM_MODO_SPOTLIGHT_V_SAMPLES;
extern const char* PARAM_MODO_SPOTLIGHT_V_SAMPLES_NAME;

extern const char* PARAM_MODO_SUNLIGHT_AZIMUTH;
extern const char* PARAM_MODO_SUNLIGHT_AZIMUTH_NAME;
extern const char* PARAM_MODO_SUNLIGHT_CLAMP_INTENSITY;
extern const char* PARAM_MODO_SUNLIGHT_CLAMP_INTENSITY_NAME;
extern const char* PARAM_MODO_SUNLIGHT_DAY;
extern const char* PARAM_MODO_SUNLIGHT_DAY_NAME;
extern const char* PARAM_MODO_SUNLIGHT_ELEVATION;
extern const char* PARAM_MODO_SUNLIGHT_ELEVATION_NAME;
extern const char* PARAM_MODO_SUNLIGHT_HAZE;
extern const char* PARAM_MODO_SUNLIGHT_HAZE_NAME;
extern const char* PARAM_MODO_SUNLIGHT_HEIGHT;
extern const char* PARAM_MODO_SUNLIGHT_HEIGHT_NAME;
extern const char* PARAM_MODO_SUNLIGHT_LATITUDE;
extern const char* PARAM_MODO_SUNLIGHT_LATITUDE_NAME;
extern const char* PARAM_MODO_SUNLIGHT_LONGITUDE;
extern const char* PARAM_MODO_SUNLIGHT_LONGITUDE_NAME;
extern const char* PARAM_MODO_SUNLIGHT_MAP_SIZE;
extern const char* PARAM_MODO_SUNLIGHT_MAP_SIZE_NAME;
extern const char* PARAM_MODO_SUNLIGHT_NORTH;
extern const char* PARAM_MODO_SUNLIGHT_NORTH_NAME;
extern const char* PARAM_MODO_SUNLIGHT_POSITION;
extern const char* PARAM_MODO_SUNLIGHT_POSITION_NAME;
extern const char* PARAM_MODO_SUNLIGHT_RADIUS;
extern const char* PARAM_MODO_SUNLIGHT_RADIUS_NAME;
extern const char* PARAM_MODO_SUNLIGHT_SPREAD;
extern const char* PARAM_MODO_SUNLIGHT_SPREAD_NAME;
extern const char* PARAM_MODO_SUNLIGHT_TIME;
extern const char* PARAM_MODO_SUNLIGHT_TIME_NAME;
extern const char* PARAM_MODO_SUNLIGHT_TIME_ZONE;
extern const char* PARAM_MODO_SUNLIGHT_TIME_ZONE_NAME;
extern const char* PARAM_MODO_SUNLIGHT_V_DISSOLVE;
extern const char* PARAM_MODO_SUNLIGHT_V_DISSOLVE_NAME;
extern const char* PARAM_MODO_SUNLIGHT_VOLUMETRICS;
extern const char* PARAM_MODO_SUNLIGHT_VOLUMETRICS_NAME;
extern const char* PARAM_MODO_SUNLIGHT_V_SAMPLES;
extern const char* PARAM_MODO_SUNLIGHT_V_SAMPLES_NAME;

extern const char* PARAM_MODO_TARGET_ENABLE;
extern const char* PARAM_MODO_TARGET_ENABLE_NAME;
extern const char* PARAM_MODO_TARGET_NODE_ID;
extern const char* PARAM_MODO_TARGET_NODE_ID_NAME;
extern const char* PARAM_MODO_TARGET_ROLL;
extern const char* PARAM_MODO_TARGET_ROLL_NAME;
extern const char* PARAM_MODO_TARGET_SET_FOCUS;
extern const char* PARAM_MODO_TARGET_SET_FOCUS_NAME;

} // namespace cio

#endif // CIO_PROFILES_H

