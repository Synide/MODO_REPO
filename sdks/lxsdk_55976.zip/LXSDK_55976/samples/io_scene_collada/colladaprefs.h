/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef COLLADAPREFS_H
#define COLLADAPREFS_H

#include "../libcolladaio/cio_element.h"
#include "../libcolladaio/cio_strings.h"

#include <string>

/*
 * ---------------------------------------------------------------------------
 * COLLADA Preferences.
 */
class COLLADAprefs
{
    public:
                                 COLLADAprefs ();
        virtual			~COLLADAprefs ();

        /*
         * Export.
         */
        void			 GetExportComments (
                                        cio::StringArray &comments) const;

        bool			 UseAbsolutePath () const;
        bool			 MergeReferenceItems () const;

        int			 GetUnitSystem () const;
        int			 GetDefaultUnit () const;
        float			 GetMetersPerGameUnit () const;

        int			 GetUpAxis () const;

        bool			 SaveHiddenItems () const;
        bool			 SaveCameras () const;
        bool			 SaveLights () const;
        bool			 SaveLocators () const;
        bool			 SaveTrianglesAsTriangles () const;

        bool			 BakeMatrices () const;
        bool			 SaveVertexNormals () const;
        bool			 SaveUVTextureCoordinates () const;
        bool			 SaveVertexColors () const;
        bool			 SaveWeights () const;

        bool			 SaveAnimation () const;

        bool			 SampleAnimation () const;
        int			 SampleStartFrame () const;
        int			 SampleEndFrame () const;

        double			 GetZNear () const;
        double			 GetZFar () const;

        bool			 SaveModoProfile () const;
        bool			 SaveMayaProfile () const;
        bool			 SaveMax3DProfile () const;
        bool			 SaveOkinoProfile () const;
        bool			 SaveXSIProfile () const;

        bool			 FormattedArrays () const;

        /*
         * Import.
         */
        bool			 ImportUnits () const;
        bool			 ImportUpAxis () const;

        /*
         * Animation.
         */
        double			 GetFPS () const;
        double			 GetTimeRangeStart () const;
        double			 GetTimeRangeEnd () const;
};

#endif // COLLADAPREFS_H

