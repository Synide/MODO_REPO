/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "colladavisitor.h"
#include "colladasaver.h"

#include "../libcolladaio/cio_light.h"
#include "../libcolladaio/cio_shadernode.h"

#include <lxidef.h>

using namespace std;
using namespace cio;

/*
 * ---------------------------------------------------------------------------
 * MCItemTypeChannelVisitor
 */

struct pv_MCItemTypeChannelVisitor
{
                                 pv_MCItemTypeChannelVisitor ();
        virtual			~pv_MCItemTypeChannelVisitor ();

        bool			 SaveModoProfile () const;

        COLLADASceneSaver	*saver;
        AnimationLibraryElement	*animationLibrary;
        LightLibraryElement	*lightLibrary;

        ShaderNodeLibraryElement_modo401	*shaderNodeLibrary;

        RenderElement_modo401		*render;
        EnvironmentElement_modo401	*environment;
};

pv_MCItemTypeChannelVisitor::pv_MCItemTypeChannelVisitor ()
        :
        saver(NULL),
        animationLibrary(NULL),
        lightLibrary(NULL),
        shaderNodeLibrary(NULL),
        render(NULL)
{
}

pv_MCItemTypeChannelVisitor::~pv_MCItemTypeChannelVisitor ()
{
}

        bool
pv_MCItemTypeChannelVisitor::SaveModoProfile () const
{
        return saver->GetPrefs().SaveModoProfile ();
}

MCItemTypeChannelVisitor::MCItemTypeChannelVisitor ()
        :
        ItemTypeChannelVisitor (),
        pv(new pv_MCItemTypeChannelVisitor())
{
}

MCItemTypeChannelVisitor::~MCItemTypeChannelVisitor ()
{
        delete pv;
}

        void
MCItemTypeChannelVisitor::SetSceneSaver (
        COLLADASceneSaver	*sceneSaver)
{
        pv->saver = sceneSaver;
}

        void
MCItemTypeChannelVisitor::SetAnimationLibrary (
        AnimationLibraryElement	*library)
{
        pv->animationLibrary = library;
}

        void
MCItemTypeChannelVisitor::SetLightLibrary (
        LightLibraryElement	*library)
{
        pv->lightLibrary = library;
}

        void
MCItemTypeChannelVisitor::SetShaderNodeLibrary (
        ShaderNodeLibraryElement_modo401 *library)
{
        pv->shaderNodeLibrary = library;
}

        void
MCItemTypeChannelVisitor::SetRender (
        RenderElement_modo401 *render)
{
        pv->render = render;
}

        void
MCItemTypeChannelVisitor::SetEnvironment (
        EnvironmentElement_modo401 *environment)
{
        pv->environment = environment;
}

        void
MCItemTypeChannelVisitor::StartItemScan (
        const string &itemTypeName)
{
        if (pv->saver) {
                pv->saver->StartScan (itemTypeName.c_str ());
        }
}

        bool
MCItemTypeChannelVisitor::NextItem ()
{
        bool	foundNextItem(false);

        if (pv->saver) {
                foundNextItem = pv->saver->NextItem ();
        }

        return foundNextItem;
}

        bool
MCItemTypeChannelVisitor::WantItem () const
{
        return pv->saver->ItemVisibleForSave ();
}

        bool
MCItemTypeChannelVisitor::WantChannel (
        const string		&itemTypeName,
        const string		&channel,
        ParamType		 paramType)
{
        bool	wantChannel(false);

        if ((GetVisitTask () == VISIT_TASK_FIND_ITEM_TYPES_AND_ACTIVE_CHANNELS) ||
            (GetVisitTask () == VISIT_TASK_BUILD_ANIMATION_LIBRARY)) {
                if (pv->saver && pv->saver->SaveAnimation ()) {
                        CLxLoc_Envelope	envelope;
                        string	channelName(channel);
                        if (paramType == PARAM_TYPE_COLOR) {
                                const char* CHANNEL_R = ".R";
                                channelName += string(CHANNEL_R);
                        }
                        wantChannel = pv->saver->ChanEnvelope (
                                channelName.c_str (), envelope);
                }
        }
        else {
                wantChannel = true;
        }

        return wantChannel;
}

/*
 * Process an item of a given type.
 */
        void
MCItemTypeChannelVisitor::ProcessItem (
        const string	&itemTypeName)
{
        string	itemName (pv->saver->ItemName ());

        if (pv->saver->ReallySaving () &&
            GetVisitTask () == VISIT_TASK_BUILD_LIGHT_LIBRARY) {
                if (pv->saver->ItemVisibleForSave ()) {
                        if (itemTypeName == string(LXsITYPE_POINTLIGHT)) {
                                PointLightElement pointLight(
                                        *(pv->lightLibrary),
                                        pv->saver->ItemIdentity (),
                                        pv->saver->ItemName ());
                                AddPointLightCommon (pointLight);
                                if (pv->SaveModoProfile ()) {
                                        AddPointLightProfile (pointLight);
                                }
                        }
                        else if ((itemTypeName == string(LXsITYPE_SPOTLIGHT) ||
                                 (itemTypeName == string(LXsITYPE_PHOTOMETRYLIGHT)))) {
                                SpotlightElement spotLight(
                                        *(pv->lightLibrary),
                                        pv->saver->ItemIdentity (),
                                        pv->saver->ItemName ());
                                AddSpotLightCommon (spotLight);
                                if (pv->SaveModoProfile ()) {
                                        if (itemTypeName == string(LXsITYPE_SPOTLIGHT)) {
                                                AddSpotLightProfile (spotLight);
                                        }
                                        else if (itemTypeName == string(LXsITYPE_PHOTOMETRYLIGHT)) {
                                                AddPhotometricLightProfile (spotLight);
                                        }
                                }
                        }
                        else if (itemTypeName == string(LXsITYPE_SUNLIGHT)) {
                                DirectionalLightElement sunLight(
                                        *(pv->lightLibrary),
                                        pv->saver->ItemIdentity (),
                                        pv->saver->ItemName ());
                                /*
                                 * Iterate over the light's sub-items, looking for
                                 * light materials. For the the common sunlight, we
                                 * use the color of the first light material found.
                                 */
                                CLxUser_Item selectedItem;
                                if (pv->saver->GetItem (selectedItem)) {
                                        unsigned subItemCount;
                                        LxResult result = selectedItem.SubCount (&subItemCount);
                                        if (LXx_OK (result) && subItemCount) {
                                                for (unsigned subItemIndex = 0;
                                                     subItemIndex < subItemCount; ++subItemIndex) {
                                                        LXtObjectID              subItemID;
                                                        result = selectedItem.SubByIndex (
                                                                subItemIndex, (void **)&subItemID);
                                                        if (LXx_FAIL (result)) {
                                                                continue;
                                                        }

                                                        if (pv->saver->SetItem (
                                                                static_cast<ILxUnknownID>(subItemID)) &&
                                                            pv->saver->ItemIsA (LXsITYPE_LIGHTMATERIAL)) {
                                                                /*
                                                                 * Grab the color and break
                                                                 * out of the sub-item loop.
                                                                 */
                                                                AddSunLightCommon (sunLight);
                                                                break;
                                                        }
                                                }
                                        }

                                        /*
                                         * Restore the selected item for
                                         * the current item scan by type.
                                         */
                                        pv->saver->SetItem (selectedItem);
                                }
                                if (pv->SaveModoProfile ()) {
                                        AddSunLightProfile (sunLight);
                                }
                        }
                        else if (pv->SaveModoProfile ()) {
                                PointLightElement pointLight(
                                        *(pv->lightLibrary),
                                        pv->saver->ItemIdentity (),
                                        pv->saver->ItemName ());
                                AddPointLightCommon (pointLight);

                                if (itemTypeName == string(LXsITYPE_AREALIGHT)) {
                                        AddAreaLightProfile (pointLight);
                                }
                                else if (itemTypeName == string(LXsITYPE_CYLINDERLIGHT)) {
                                        AddCylinderLightProfile (pointLight);
                                }
                                else if (itemTypeName == string(LXsITYPE_DOMELIGHT)) {
                                        AddDomeLightProfile (pointLight);
                                }
                        }
                }
        }
        else if (pv->saver->ReallySaving () &&
                 GetVisitTask () == VISIT_TASK_BUILD_SHADER_NODE_LIBRARY) {
                if (itemTypeName == string(LXsITYPE_POLYRENDER)) {
                        SetRenderChannels ();
                }
                else if (itemTypeName == string(LXsITYPE_ENVIRONMENT)) {
                        SetEnvironmentChannels ();
                }
                else if (itemTypeName == string(LXsITYPE_ENVMATERIAL)) {
                        SetEnvironmentMaterialChannels ();
                }
        }
}

/*
 * Process an item channel. Optional override.
 */
        void
MCItemTypeChannelVisitor::ProcessItemTypeChannel (
        const ItemTypeChannel	&itemTypeChannel)
{
        if (pv->saver->ReallySaving () &&
            GetVisitTask () == VISIT_TASK_BUILD_ANIMATION_LIBRARY) {
                CLxLoc_Item item;
                if (pv->saver->GetItem (item)) {
                        LxResult result = pv->saver->AddAnimationParam (
                                *(pv->animationLibrary), item,
                                itemTypeChannel.Channel (),
                                itemTypeChannel.GetParamSID (),
                                itemTypeChannel.GetParamName (),
                                itemTypeChannel.GetParamType ());
                }
        }
}

        void
MCItemTypeChannelVisitor::AddPointLightCommon (
        PointLightElement	&light)
{
        /*
         * [TODO] Fetch the actual color once we're ready to export materials.
         */
        Element::ColorRGB color = {1.0, 1.0, 1.0};
        light.SetColor (color);

        light.SetQuadraticAttenuation (1.0);
}

        void
MCItemTypeChannelVisitor::AddSpotLightCommon (
        SpotlightElement	&light)
{
        /*
         * [TODO] Fetch the actual color once we're ready to export materials.
         */
        Element::ColorRGB color = {1.0, 1.0, 1.0};
        light.SetColor (color);

        light.SetQuadraticAttenuation (1.0);

        light.SetFalloffAngle (45.0);
}

        void
MCItemTypeChannelVisitor::AddSunLightCommon (
        DirectionalLightElement &light)
{
        /*
         * Fetch the simple light color for the common technique.
         * (We save the full light color description in the modo profile.)
         */
        LXtVector lightColor;
        pv->saver->ChanColor (
                LXsICHAN_LIGHTMATERIAL_LIGHTCOL, lightColor);
        Element::ColorRGB color = {
                lightColor[0], lightColor[1], lightColor[2]};
        light.SetColor (color);
}

        void
MCItemTypeChannelVisitor::AddAreaLightProfile (
        PointLightElement		&light)
{
        AreaLightElement_modo401 areaLight(light);

        AddLightCommon_modo401 (areaLight);

        /*
         * Targeting.
         */
        string targetID;
        if (pv->saver->GetTargetNodeID (targetID)) {
                areaLight.SetTargetNodeID (targetID);
                areaLight.SetTargetEnable (pv->saver->ChanBool (LXsICHAN_TARGET_ENABLE));
                areaLight.SetTargetRoll (pv->saver->ChanFloat (LXsICHAN_TARGET_TARGETROLL));
        }

        areaLight.SetWidth (pv->saver->ChanFloat (LXsICHAN_AREALIGHT_WIDTH));
        areaLight.SetHeight (pv->saver->ChanFloat (LXsICHAN_AREALIGHT_HEIGHT));

        string areaShape = GetTextHintEncodedChannelValue (
                *pv->saver, LXsICHAN_AREALIGHT_SHAPE);
        areaLight.SetShape (areaShape);
}

        void
MCItemTypeChannelVisitor::AddCylinderLightProfile (
        PointLightElement		&light)
{
        CylinderLightElement_modo401 cylinderLight(light);

        AddLightCommon_modo401 (cylinderLight);

        /*
         * Targeting.
         */
        string targetID;
        if (pv->saver->GetTargetNodeID (targetID)) {
                cylinderLight.SetTargetNodeID (targetID);
                cylinderLight.SetTargetEnable (pv->saver->ChanBool (LXsICHAN_TARGET_ENABLE));
                cylinderLight.SetTargetRoll (pv->saver->ChanFloat (LXsICHAN_TARGET_TARGETROLL));
        }

        cylinderLight.SetLength (pv->saver->ChanFloat (LXsICHAN_CYLINDERLIGHT_LENGTH));
        cylinderLight.SetRadius (pv->saver->ChanFloat (LXsICHAN_CYLINDERLIGHT_RADIUS));
}

        void
MCItemTypeChannelVisitor::AddDomeLightProfile (
        PointLightElement		&light)
{
        DomeLightElement_modo401 domeLight(light);

        AddLightCommon_modo401 (domeLight);

        domeLight.SetRadius (pv->saver->ChanFloat (LXsICHAN_DOMELIGHT_RADIUS));
}

        void
MCItemTypeChannelVisitor::AddPhotometricLightProfile (
        SpotlightElement	&light)
{
        PhotometricLightElement_modo401 photoLight(light);

        AddLightCommon_modo401 (photoLight);

        /*
         * Targeting.
         */
        string targetID;
        if (pv->saver->GetTargetNodeID (targetID)) {
                photoLight.SetTargetNodeID (targetID);
                photoLight.SetTargetEnable (pv->saver->ChanBool (LXsICHAN_TARGET_ENABLE));
                photoLight.SetTargetRoll (pv->saver->ChanFloat (LXsICHAN_TARGET_TARGETROLL));
        }

        photoLight.SetConeAngle (pv->saver->ChanFloat (LXsICHAN_PHOTOMETRYLIGHT_CONE));
        photoLight.SetSoftEdgeAngle (pv->saver->ChanFloat (LXsICHAN_PHOTOMETRYLIGHT_EDGE));

        photoLight.SetWidth (pv->saver->ChanFloat (LXsICHAN_PHOTOMETRYLIGHT_WIDTH));
        photoLight.SetHeight (pv->saver->ChanFloat (LXsICHAN_PHOTOMETRYLIGHT_HEIGHT));

        photoLight.SetOutside (pv->saver->ChanBool (LXsICHAN_PHOTOMETRYLIGHT_OUTSIDE));

        photoLight.SetVolumetrics (pv->saver->ChanBool (LXsICHAN_PHOTOMETRYLIGHT_VOLUMETRICS));
        photoLight.SetVolumetricDissolve (pv->saver->ChanFloat (LXsICHAN_PHOTOMETRYLIGHT_VDISSOLVE));
        photoLight.SetVolumetricSamples (pv->saver->ChanInt (LXsICHAN_PHOTOMETRYLIGHT_VSAMPLES));
        photoLight.SetVolumetricRadius (pv->saver->ChanFloat (LXsICHAN_PHOTOMETRYLIGHT_VRAD));
}

        void
MCItemTypeChannelVisitor::AddPointLightProfile (
        PointLightElement	&light)
{
        PointLightElement_modo401 pointLight(light);

        AddLightCommon_modo401 (pointLight);

        pointLight.SetRadius (pv->saver->ChanFloat (LXsICHAN_POINTLIGHT_RADIUS));

        pointLight.SetVolumetrics (pv->saver->ChanBool (LXsICHAN_POINTLIGHT_VOLUMETRICS));
        pointLight.SetVolumetricDissolve (pv->saver->ChanFloat (LXsICHAN_POINTLIGHT_VDISSOLVE));
        pointLight.SetVolumetricSamples (pv->saver->ChanInt (LXsICHAN_POINTLIGHT_VSAMPLES));
        pointLight.SetVolumetricRadius (pv->saver->ChanFloat (LXsICHAN_POINTLIGHT_VRAD));
}

        void
MCItemTypeChannelVisitor::AddSpotLightProfile (
        SpotlightElement	&light)
{
        SpotlightElement_modo401 spotLight(light);

        AddLightCommon_modo401 (spotLight);

        /*
         * Targeting.
         */
        string targetID;
        if (pv->saver->GetTargetNodeID (targetID)) {
                spotLight.SetTargetNodeID (targetID);
                spotLight.SetTargetEnable (pv->saver->ChanBool (LXsICHAN_TARGET_ENABLE));
                spotLight.SetTargetRoll (pv->saver->ChanFloat (LXsICHAN_TARGET_TARGETROLL));
        }

        spotLight.SetConeAngle (pv->saver->ChanFloat (LXsICHAN_SPOTLIGHT_CONE));
        spotLight.SetSoftEdgeAngle (pv->saver->ChanFloat (LXsICHAN_SPOTLIGHT_EDGE));

        spotLight.SetOutside (pv->saver->ChanBool (LXsICHAN_SPOTLIGHT_OUTSIDE));

        spotLight.SetVolumetrics (pv->saver->ChanBool (LXsICHAN_SPOTLIGHT_VOLUMETRICS));
        spotLight.SetVolumetricDissolve (pv->saver->ChanFloat (LXsICHAN_SPOTLIGHT_VDISSOLVE));
        spotLight.SetVolumetricSamples (pv->saver->ChanInt (LXsICHAN_SPOTLIGHT_VSAMPLES));
}

        void
MCItemTypeChannelVisitor::AddSunLightProfile (
        DirectionalLightElement &light)
{
        SunlightElement_modo401 sunLight(light);

        AddLightCommon_modo401 (sunLight);

        /*
         * Targeting.
         */
        string targetID;
        if (pv->saver->GetTargetNodeID (targetID)) {
                sunLight.SetTargetNodeID (targetID);
                sunLight.SetTargetEnable (pv->saver->ChanBool (LXsICHAN_TARGET_ENABLE));
                sunLight.SetTargetRoll (pv->saver->ChanFloat (LXsICHAN_TARGET_TARGETROLL));
        }

        sunLight.SetAzimuth (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_AZIMUTH));
        sunLight.SetClampIntensity (pv->saver->ChanBool (LXsICHAN_SUNLIGHT_CLAMP));

        sunLight.SetDay (static_cast<unsigned>(
                pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_DAY)));

        sunLight.SetElevation (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_ELEVATION));
        sunLight.SetHaze (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_HAZE));
        sunLight.SetHeight (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_HEIGHT));
        sunLight.SetLatitude (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_LAT));
        sunLight.SetLongitude (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_LON));
        sunLight.SetMapSize (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_MAPSIZE));
        sunLight.SetNorth (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_NORTH));
        sunLight.SetRadius (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_RADIUS));
        sunLight.SetSpread (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_SPREAD));

        sunLight.SetSunPosition (pv->saver->ChanBool (LXsICHAN_SUNLIGHT_SUNPOS));

        sunLight.SetTime (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_TIME));
        sunLight.SetTimeZone (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_TIMEZONE));

        sunLight.SetVolumetrics (pv->saver->ChanBool (LXsICHAN_SUNLIGHT_VOLUMETRICS));
        sunLight.SetVolumetricDissolve (pv->saver->ChanFloat (LXsICHAN_SUNLIGHT_VDISSOLVE));
        sunLight.SetVolumetricSamples (pv->saver->ChanInt (LXsICHAN_SUNLIGHT_VSAMPLES));
}

        void
MCItemTypeChannelVisitor::AddLightCommon_modo401 (
        LightElement_modo401	&light)
{
        /*
         * Locator settings.
         */
        string render = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_LOCATOR_RENDER);
        light.SetRender (render);

        string displayVisible = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_LOCATOR_VISIBLE);
        light.SetDisplayVisible (displayVisible);

        light.SetDisplaySize (pv->saver->ChanFloat (LXsICHAN_LOCATOR_SIZE));
        light.SetDissolve (pv->saver->ChanFloat (LXsICHAN_LOCATOR_DISSOLVE));

        /*
         * Common light settings, used for all light sub-types.
         */
        light.SetRadiance (pv->saver->ChanFloat (LXsICHAN_LIGHT_RADIANCE));
        light.SetSamples (pv->saver->ChanInt (LXsICHAN_LIGHT_SAMPLES));

        string shadowType = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_LIGHT_SHADTYPE);
        light.SetShadowType (shadowType);

        light.SetShadowResolution (pv->saver->ChanInt (LXsICHAN_LIGHT_SHADRES));
        light.SetSimpleShading (pv->saver->ChanBool (LXsICHAN_LIGHT_FAST));
}

        void
MCItemTypeChannelVisitor::SetRenderChannels ()
{
        /*
         * Frame group.
         */
        pv->render->SetFrameRangeFirst (
                pv->saver->ChanInt (LXsICHAN_POLYRENDER_FIRST));

        pv->render->SetFrameRangeLast (
                pv->saver->ChanInt (LXsICHAN_POLYRENDER_LAST));

        pv->render->SetFrameRangeStep (
                pv->saver->ChanInt (LXsICHAN_POLYRENDER_STEP));

        /*
         * Resolution Unit.
         */
        string unit = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_POLYRENDER_RESUNIT);
        pv->render->SetResolutionUnit (unit);

        pv->render->SetFrameDPI (pv->saver->ChanFloat (LXsICHAN_POLYRENDER_DPI));

        pv->render->SetFramePixelAspectRatio (
                pv->saver->ChanFloat (LXsICHAN_POLYRENDER_PASPECT));

        /*
         * Buckets group.
         */
        pv->render->SetBucketWidth (pv->saver->ChanInt (LXsICHAN_POLYRENDER_BUCKETX));
        pv->render->SetBucketHeight (pv->saver->ChanInt (LXsICHAN_POLYRENDER_BUCKETY));

        /*
         * Bucket order.
         */
        string order = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_POLYRENDER_BKTORDER);
        pv->render->SetBucketOrder (order);

        pv->render->SetBucketReverseOrder (
                pv->saver->ChanBool (LXsICHAN_POLYRENDER_BKTREVERSE));

        pv->render->SetBucketWriteToDisk (
                pv->saver->ChanBool (LXsICHAN_POLYRENDER_BKTWRITE));

        pv->render->SetBucketSkipExisting (
                pv->saver->ChanBool (LXsICHAN_POLYRENDER_BKTSKIP));

        /*
         * Region.
         */
        pv->render->SetRenderRegion (pv->saver->ChanBool (LXsICHAN_POLYRENDER_REGION));

        pv->render->SetRenderRegionLeft (pv->saver->ChanFloat (LXsICHAN_POLYRENDER_REGX0));
        pv->render->SetRenderRegionRight (pv->saver->ChanFloat (LXsICHAN_POLYRENDER_REGX1));
        pv->render->SetRenderRegionTop (pv->saver->ChanFloat (LXsICHAN_POLYRENDER_REGY0));
        pv->render->SetRenderRegionBottom (pv->saver->ChanFloat (LXsICHAN_POLYRENDER_REGY1));

        /*
         * Antialiasing.
         */
        string aa = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_POLYRENDER_AA);
        pv->render->SetAntialiasing (aa);

        /*
         * Antialiasing filter.
         */
        string aaFilter = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_POLYRENDER_AAFILTER);
        pv->render->SetAntialiasingFilter (aaFilter);

        pv->render->SetRefinementShadingRate (
                pv->saver->ChanFloat (LXsICHAN_POLYRENDER_FINERATE));

        pv->render->SetRefinementThreshold (
                pv->saver->ChanFloat (LXsICHAN_POLYRENDER_FINETHRESH));

        pv->render->SetRefineBucketBorders (
                pv->saver->ChanBool (LXsICHAN_POLYRENDER_BKTREFINE));

        pv->render->SetRenderDepthOfField (
                pv->saver->ChanBool (LXsICHAN_POLYRENDER_DOF));

        pv->render->SetRenderMotionBlur (
                pv->saver->ChanBool (LXsICHAN_POLYRENDER_MBLUR));

        pv->render->SetRenderStereoscopic (
                pv->saver->ChanBool (LXsICHAN_POLYRENDER_STEREO));

        /*
         * Ray Tracing.
         */
        pv->render->SetRayTracingShadows (pv->saver->ChanBool (LXsICHAN_RENDER_RAYSHADOW));
        pv->render->SetReflectionDepth (pv->saver->ChanInt (LXsICHAN_RENDER_REFLDEPTH));
        pv->render->SetRefractionDepth (pv->saver->ChanInt (LXsICHAN_RENDER_REFRDEPTH));
        pv->render->SetRayThreshold (pv->saver->ChanFloat (LXsICHAN_RENDER_RAYTHRESH));

        /*
         * Geometry.
         */
        pv->render->SetAdaptiveSubdivision (pv->saver->ChanBool (LXsICHAN_RENDER_SUBDADAPT));
        pv->render->SetSubdivisionRate (pv->saver->ChanFloat (LXsICHAN_RENDER_SUBDRATE));
        pv->render->SetMicropolyDisplacement (pv->saver->ChanBool (LXsICHAN_RENDER_DISPENABLE));
        pv->render->SetDisplacementRate (pv->saver->ChanFloat (LXsICHAN_RENDER_DISPRATE));
        pv->render->SetDisplacementRatio (pv->saver->ChanFloat (LXsICHAN_RENDER_DISPRATIO));
        pv->render->SetMinimumEdgeLength (pv->saver->ChanFloat (LXsICHAN_RENDER_EDGEMIN));
        pv->render->SetSmoothPositions (pv->saver->ChanBool (LXsICHAN_RENDER_DISPSMOOTH));

        /*
         * Ambient Light.
         */
        pv->render->SetAmbientIntensity (pv->saver->ChanFloat (LXsICHAN_RENDER_AMBRAD));

        LXtVector	color;
        pv->saver->ChanColor (LXsICHAN_RENDER_AMBCOLOR, color);
        pv->render->SetAmbientColor (color);

        /*
         * Indirect Illumination.
         */
        pv->render->SetEnableIndirectIllumination (pv->saver->ChanBool (LXsICHAN_RENDER_GLOBENABLE));

        pv->render->SetIndirectIlluminationScope (
                GetTextHintEncodedChannelValue (
                        *(pv->saver), LXsICHAN_RENDER_GLOBSCOPE));

        pv->render->SetIndirectRays (pv->saver->ChanInt (LXsICHAN_RENDER_GLOBRAYS));
        pv->render->SetIndirectBounces (pv->saver->ChanInt (LXsICHAN_RENDER_GLOBLIMIT));
        pv->render->SetIndirectRange (pv->saver->ChanFloat (LXsICHAN_RENDER_GLOBRANGE));
        pv->render->SetSubsurfaceScattering (pv->saver->ChanInt (LXsICHAN_RENDER_GLOBSUBS));
        pv->render->SetVolumetricsAffectIndirect (pv->saver->ChanBool (LXsICHAN_RENDER_GLOBVOLS));

        /*
         * Irradiance Caching.
         */
        pv->render->SetIrradianceCaching (pv->saver->ChanBool (LXsICHAN_RENDER_IRRCACHE));
        pv->render->SetIrradianceRays (pv->saver->ChanInt (LXsICHAN_RENDER_IRRRAYS));
        pv->render->SetIndirectSupersampling (pv->saver->ChanBool (LXsICHAN_RENDER_GLOBSUPER));
        pv->render->SetIrradianceRate (pv->saver->ChanFloat (LXsICHAN_RENDER_IRRRATE));
        pv->render->SetIrradianceRatio (pv->saver->ChanFloat (LXsICHAN_RENDER_IRRRATIO));
        pv->render->SetInterpolationValues (pv->saver->ChanInt (LXsICHAN_RENDER_IRRVALS));

        /*
         * Irradiance Gradients.
         */
        string gradients = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_RENDER_IRRGRADS);
        pv->render->SetIrradianceGradients (gradients);

        pv->render->SetWalkthroughMode (
                pv->saver->ChanBool (LXsICHAN_RENDER_IRRWALK));
        pv->render->SetLoadIrradianceBeforeRender (
                pv->saver->ChanBool (LXsICHAN_RENDER_IRRLENABLE));
        pv->render->SetLoadIrradianceFile (
                pv->saver->ChanString (LXsICHAN_RENDER_IRRLNAME));
        pv->render->SetSaveIrradianceAfterRender (
                pv->saver->ChanBool (LXsICHAN_RENDER_IRRSENABLE));
        pv->render->SetSaveIrradianceFile (
                pv->saver->ChanString (LXsICHAN_RENDER_IRRSNAME));

        /*
         * Caustics.
         */
        pv->render->SetEnableDirectCaustics (
                pv->saver->ChanBool (LXsICHAN_RENDER_CAUSENABLE));
        pv->render->SetCausticsTotalPhotons (
                pv->saver->ChanInt (LXsICHAN_RENDER_CAUSTOTAL));
        pv->render->SetCausticsLocalPhotons (
                pv->saver->ChanInt (LXsICHAN_RENDER_CAUSLOCAL));

        /*
         * Indirect Caustics.
         */
        string indCaustics = GetTextHintEncodedChannelValue (
                *(pv->saver), LXsICHAN_RENDER_GLOBCAUS);
        pv->render->SetIndirectCaustics (indCaustics);
}

        void
MCItemTypeChannelVisitor::SetEnvironmentChannels ()
{
        pv->environment->SetIntensity (
                pv->saver->ChanFloat (LXsICHAN_ENVIRONMENT_RADIANCE));

        pv->environment->SetVisibleToCamera (
                pv->saver->ChanBool (LXsICHAN_ENVIRONMENT_VISCAM));

        pv->environment->SetVisibleToIndirectRays (
                pv->saver->ChanBool (LXsICHAN_ENVIRONMENT_VISIND));

        pv->environment->SetVisibleToReflectionRays (
                pv->saver->ChanBool (LXsICHAN_ENVIRONMENT_VISREFL));

        pv->environment->SetVisibleToRefractionRays (
                pv->saver->ChanBool (LXsICHAN_ENVIRONMENT_VISREFR));
}

        void
MCItemTypeChannelVisitor::SetEnvironmentMaterialChannels ()
{
}

