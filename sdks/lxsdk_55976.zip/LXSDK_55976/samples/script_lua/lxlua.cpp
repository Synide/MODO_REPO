/*
 * Plug-in Lua script interpreter.
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <lx_wrap.hpp>
#include <lxaction.h>
#include <lxscripts.h>
#include <lxcommand.h>
#include <lx_command.hpp>
#include <lxstddialog.h>
#include <lx_log.hpp>
#include <lx_value.hpp>

extern "C" {

#include "../liblua/lua.h"
#include "../liblua/lauxlib.h"
#include "../liblua/lualib.h"

}

#include "lxlua.h"

CLxUser_LogService		*logSrv;
CLxUser_CommandService		*cmdSrv;
CLxUser_ValueService		*valueSrv;

extern "C" {

ILxScriptSysServiceID		 scriptSrv;			/* Script system service; common to all instances                */
ILxStdDialogServiceID		 dlgSrv;			/* Standard dialog service; common to all instances              */
IntrInstance			 intrStack[ MAX_STACK ];	/* Interpreter stack; allows scripts to execute other scripts    */
int				 intrTop        = -1;		/* The current script being executed as an index into interStack */
IntrInstance			*intrCur        = NULL;		/* The same as &intrStack[ intrTop ], or NULL if intrTop is -1   */

}

        static void
LogStringEntry (
        const char		*s,
        LxResult		 code,
        int			 persist,
        CLxLoc_LogEntry		&entry)
{
        if (logSrv->NewEntry (code, s, entry)) {
                intrCur->log.AddEntry (entry);
        }
}

/*
 * Add a string to a parent log, possibly returning a log entry for sub-entries
 */
        static void
AddLogStringEntry (
        CLxLoc_LogEntry		&parent,
        const char		*s,
        LxResult		 code,
        int			 persist,
        CLxLoc_LogEntry		&entry)
{
        if (logSrv->NewEntry (code, s, entry)) {
                parent.AddEntry (entry);
        }
}

/*
 * Adding a log entry to a parent, for clients with no need for the entry.
 */
        void
AddLogString (
        CLxLoc_LogEntry		&parent,
        const char		*s,
        LxResult		 code,
        int			 persist)
{
        CLxLoc_LogEntry		 entry;

        AddLogStringEntry (parent, s, code, persist, entry);
}

/*
 * Logging for clients with no need for the entry.
 */
        void
LogString (
        const char		*s,
        LxResult		 code,
        int			 persist)
{
        CLxLoc_LogEntry		 entry;

        LogStringEntry (s, code, persist, entry);
}

        static void
OutputTraceInfo(
        const char *c,
        CLxLoc_LogEntry		&entry)
{
        char	 buf[ 2048 ] = "\03(f:FONT_ITALIC)lxtrace:\03(f:FONT_DEFAULT)  ";
        size_t	 i;
        int	 j;

        if( intrCur->tracing ) {

                if( c == NULL )
                        c = "nil";

                for ( i=strlen(buf), j=0;
                    (i < 2047) && (c[j] != '\0'); i++, j++ )
                        buf[i] = c[j];

                LogStringEntry( buf, LXe_INFO, 1, entry);
        }
}


/* lxout:  Output a string to the log */
        int
l_lxout(lua_State *L)
{
        const char		*c = lua_tostring(L, 1);
        
        if(c)
                LogString( c, LXe_INFO, 0 );
        else
                LogString( "nil", LXe_INFO, 0 );

        return 0;
}

/* Internal function to perform queries and executions */
#define LXEVALMODEf_QUERY	1						// Query only; fail if no query is marked
#define LXEVALMODEf_EXECUTE	2						// Execute only; fail if a query is marked
#define LXEVALMODEf_EITHER	(LXEVALMODEf_QUERY | LXEVALMODEf_EXECUTE) 	// Query or execute, whatever works

        LxResult
lxeval(lua_State *L, int mode)
{
        CLxUser_Command		 command;
        CLxLoc_LogEntry		 entry;
        int			 i, x, type, queryArgIndex;
        int			 iVal;
        double			 fVal, fScalar = 1.0;
        char			 sVal[2048];
        const char		*typeName;
        LxResult		 rc;
        const LXtTextValueHint	*hints     = NULL;
        unsigned		 execFlags = intrCur->execFlags;
        const char		*c         = lua_tostring(L, 1);
        bool			 isOK;

        OutputTraceInfo( c, entry );

        /* Spawn the command and get the query argument */
        isOK = cmdSrv->NewCommandFromString (command, c, execFlags, queryArgIndex);
        if( !isOK ) {
                intrCur->rc = LXe_FAILED;

                if( intrCur->tracing )
                        AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lxq/lx/lxeval failed: error spawning command/parsing arguments\03(f:FONT_DEFAULT)", LXe_FAILED, 0 );

                return LXe_FAILED;
        }

 	if( (mode == LXEVALMODEf_EXECUTE) ||					// Execute only flag; execute if there's a query or not
            ((queryArgIndex == -1) && (mode & LXEVALMODEf_EXECUTE)) ) {		// No query arg; execute if the execute flag is set (in case of "either" mode)
                /* Execute */
                if( !(mode & LXEVALMODEf_EXECUTE) ) {
                        if( intrCur->tracing )
                                AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lx failed: unprocessed query argument (i.e., \'?\') specified in command string\03(f:FONT_DEFAULT)", LXe_FAILED, 0 );

                        return LXe_FAILED;
                }

                intrCur->rc = cmdSrv->ExecuteSpecial( execFlags, command, queryArgIndex );
                lua_pushnumber(L, LXx_OK( intrCur->rc ) ? 1 : 0 );

                return LXe_OK;
        }

        /* See if we're allowed to query */
        if( !(mode & LXEVALMODEf_QUERY) ) {
                if( intrCur->tracing )
                        AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lxq/lxeval failed: no query (i.e., \'?\') marked in command string\03(f:FONT_DEFAULT)", LXe_FAILED, 0 );

                return LXe_CMD_NO_QUERY_MARKED;
        }

        /* Create the value array and query the command */
        CLxUser_ValueArray	 qval;

        CLxUser_Attributes attr;
        if (attr.set(command)) {
                /* Get the type */
                type = attr.Type (queryArgIndex);
                if (type != -1) {
                        /* Get the type name */
                        rc = attr.TypeName (queryArgIndex, &typeName);

                        if (LXx_OK (rc)) {
                                /* Create a value array */
                                ILxUnknownID		 oqval;
                                rc = cmdSrv->CreateQueryObject( typeName, (void **)&oqval );
                                if (LXx_OK (rc)) {
                                        /* Query */
                                        qval.set (oqval);
                                        if( qval.set (oqval) )
                                                rc = command.Query (queryArgIndex, qval);
                                }
                        }
                }
                else {
                        rc = LXe_FAILED;
                }
        }

        if( LXx_FAIL (rc) ) {
                if( intrCur->tracing )
                        AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lxq/lxeval failed: error querying command\03(f:FONT_DEFAULT)", LXe_FAILED, 0 );

                return rc;
        }

        /* Return the values in the value array to the script */
        i = qval.Count();

        if(0 == i) {
                /* Nothing is on the stack; return nil */
                lua_pushnil( L );
                return LXe_OK;
        }

        if( attr != NULL )
                hints = attr.Hints( queryArgIndex );

        lua_newtable(L);

        if( intrCur->queryAnglesAsDegrees ) {
                /* Special case:  convert angles to degrees, if applicable */
                if( strcmp( typeName, "angle" ) == 0 )
                        fScalar = 57.295780490442968321226628812406;	// 180 / 3.1415926;
        }

        for(x = 0 ; x < i ; x++)
        {
                lua_pushnumber(L, x+1);		// The key, which is just the index of the value

                if(type == LXi_TYPE_INTEGER) 
                {
                        bool asNumber = 1;

                        qval.GetInt (x, &iVal);
                        if( hints != NULL ) {
                                LxResult	encodeResult = valueSrv->TextHintEncode( iVal, hints, sVal, 2048 );
                                if( encodeResult != LXe_OK_NO_CHOICES ) {
                                        lua_pushlstring(L, sVal, strlen(sVal));
                                        asNumber = 0;

                                        if( intrCur->tracing ) {
                                                char buf[ 64 ];
                                                sprintf( buf, "\03(f:FONT_ITALIC)lxtrace, lxq, %d:\03(f:FONT_DEFAULT)  %s", x+1, sVal );
                                                AddLogString( entry, buf, LXe_INFO, 0 );
                                        }
                                }
                        }

                        if( asNumber ) {
                                lua_pushnumber(L, iVal);

                                if( intrCur->tracing ) {
                                        char buf[ 64 ];
                                        sprintf( buf, "\03(f:FONT_ITALIC)lxtrace, lxq, %d:\03(f:FONT_DEFAULT)  %d", x+1, iVal );
                                        AddLogString( entry, buf, LXe_INFO, 0 );
                                }
                        }
                }
                else if(type == LXi_TYPE_FLOAT) 
                {
                        qval.GetFloat (x, &fVal);
                        fVal *= fScalar;
                        lua_pushnumber(L, fVal);

                        if( intrCur->tracing ) {
                                char buf[ 64 ];
                                sprintf( buf, "\03(f:FONT_ITALIC)lxtrace, lxq, %d:\03(f:FONT_DEFAULT)  %g", x+1, fVal );
                                AddLogString( entry, buf, LXe_INFO, 0 );
                        }
                }
                else if(type == LXi_TYPE_STRING)
                {
                        qval.GetString (x, sVal, 2048);
                        lua_pushlstring(L, sVal, strlen(sVal));

                        if( intrCur->tracing ) {
                                char buf[ 2048 ];
                                sprintf( buf, "\03(f:FONT_ITALIC)lxtrace, lxq, %d:\03(f:FONT_DEFAULT)  %s", x+1, sVal );
                                AddLogString( entry, buf, LXe_INFO, 0 );
                        }
                }
                else
                {
                        /* Object; convert to a string and return */
                        char		 buffer[2048];

                        LXtObjectID		 value;
                        if( LXx_FAIL( (qval.GetValue (x, (void **) &value) ))) {
                                lua_pushnil( L );
                                continue;
                        }

                        /*
                         * Check if we have a string converter.
                         */
                        CLxUser_StringConversion	stringer;
                        stringer.set (value);
                        if (!stringer.test ()) {
                                lua_pushnil( L );
                                continue;
                        }

                        if( LXx_FAIL( stringer.Encode ( buffer, 2048 ) ) ) {
                                lua_pushnil( L );
                                continue;
                        }

                        lua_pushlstring(L, buffer, strlen(buffer));

                        if( intrCur->tracing ) {
                                char buf[ 2100 ];
                                sprintf( buf, "\03(f:FONT_ITALIC)lxtrace, lxq, %d:\03(f:FONT_DEFAULT)  %s", x+1, buffer );
                                AddLogString( entry, buf, LXe_INFO, 0 );
                        }
                }

                lua_settable(L, -3);
        }

        return 1;
}

        int
l_lxeval(lua_State *L)
{
        if( LXx_FAIL( lxeval( L, LXEVALMODEf_EITHER ) ) )
                return 0;

        return 1;
}

        int
l_lx(lua_State *L)
{
        if( LXx_FAIL( lxeval( L, LXEVALMODEf_EXECUTE ) ) )
                return 0;

        return 1;
}  

// At some point in the future, lxq() needs to use the raw string conversion feature to ensure that
//  the values that are queried are the same kinds of values that get passed to commands.
        int
l_lxq(lua_State *L)
{
        if( LXx_FAIL( lxeval( L, LXEVALMODEf_QUERY ) ) )
                return 0;

        return 1;
}

/*
 * lxqt():
 *  Query a toggle command's toggle argument.  Returns the query state
 *   on success (1 or 0), or 0 on failure.
 */
        int
l_lxqt(lua_State *L)
{
        CLxUser_Command		 command;
        CLxLoc_LogEntry		 entry;
        int			 state;
        unsigned		 execFlags = intrCur->execFlags;
        const char		*c         = lua_tostring(L, 1);
        bool			 isOK;

        OutputTraceInfo( c, entry );

        /* Spawn the command */
        int queryArgIndex;
        isOK = cmdSrv->NewCommandFromString( command, c, execFlags, queryArgIndex );
        if( !isOK ) {
                intrCur->rc = LXe_FAILED;

                if( intrCur->tracing )
                        AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lxqt failed: error spawning command/parsing arguments\03(f:FONT_DEFAULT)", LXe_FAILED, 0 );

                lua_pushnumber( L, 0 );
                return 1;
        }

        /* Query the toggle argument */
        intrCur->rc = cmdSrv->GetToggleArgState( command, &state, NULL );

        if( intrCur->tracing ) {
                if( LXx_OK( intrCur->rc ) ) {
                        if( state ) {
                                AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lxqt, toggled state is true (1)\03(f:FONT_DEFAULT)", LXe_INFO, 0 );
                                lua_pushnumber( L, 1 );
                        } else {
                                AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lxqt, toggled state is false (0)\03(f:FONT_DEFAULT)", LXe_INFO, 0 );
                                lua_pushnumber( L, 0 );
                        }
                } else {
                        AddLogString( entry, "\03(f:FONT_ITALIC)lxtrace, lxqt failed: error querying the command\03(f:FONT_DEFAULT)", LXe_FAILED, 0 );
                        lua_pushnumber( L, 0 );
                }
        }

        return 1;
}


/* 
 * lxok():
 *  Return true if the last command executed/queried successfully.
 */
        int
l_lxok(lua_State *L)
{
        lua_pushboolean(L, LXx_OK( intrCur->rc ) ? 1 : 0);
        return 1;
}

/* 
 * lxres():
 *  Return the LxResult code of the last command executed or quieried.
 */
        int
l_lxres(lua_State *L)
{
        lua_pushnumber(L, intrCur->rc);
        return 1;
}

/*
 * lxtrace():
 * When activated, lx() and lxq() data is output to the event log.  If no args
 *  are passed in, this returns if tracing is active or not.
 */
        int
l_lxtrace(lua_State *L)
{
        /* See if there's at least one argument */
        const char	*c = lua_tostring(L, 1);

        if( c != NULL ) {
                intrCur->tracing = atoi( c );	// For some reason, lua_toboolean() is always returning 1, so we'll just do this
                if( intrCur->tracing )
                        LogString( "\03(f:FONT_ITALIC)lxtrace: Enabled\03(f:FONT_DEFAULT)", LXe_INFO, 0 );
                else
                        LogString( "\03(f:FONT_ITALIC)lxtrace: Disabled\03(f:FONT_DEFAULT)", LXe_INFO, 0 );
        }

        lua_pushnumber(L, intrCur->tracing);
        return 1;
}

/* 
 * lxoption():
 *  Get the state of an option.
 */
        int
l_lxoption(lua_State *L)
{
        const char		*tag = lua_tostring(L, 1);

        if( strcmp( tag, "queryAnglesAs" ) == 0 ) {
                /* Query Angles As.  Returns "degrees" or "radians" */
                const char	*state = intrCur->queryAnglesAsDegrees ? "degrees" : "radians";
                lua_pushlstring(L, state, strlen(state));

                return 1;
        }

        /* Unknown tag */
        return 0;
}

/* 
 * lxsetOption():
 *  Get the state of an option.
 */
        int
l_lxsetOption(lua_State *L)
{
        const char		*tag   = lua_tostring(L, 1);
        const char		*value = lua_tostring(L, 2);

        if( strcmp( tag, "queryAnglesAs" ) == 0 ) {
                /* Query Angles As.  Returns "degrees" or "radians" */
                if( strcmp( tag, "queryAnglesAs" ) == 0 ) {
                        /* Query Angles As.  Supports "degrees" or "radians" */
                        if( strcmp( value, "degrees" ) == 0 ) {
                                intrCur->queryAnglesAsDegrees = 1;

                        } else if( strcmp( value, "radians" ) == 0 ) {
                                intrCur->queryAnglesAsDegrees = 0;

                        } else {
                                lua_pushboolean(L, 0);
                                return 0;
                        }

                        lua_pushboolean(L, 1);
                }

                return 1;
        }

        /* Unknown tag */
        lua_pushboolean(L, 0);
        return 0;
}

/*
 * lxmonInit() : Initialize the progress bar.
 *  Initialize the progress bar with n total steps.  Returns 0 on error.
 */
        int
l_lxmonInit(lua_State *L)
{
        int		 count;
        LxResult	 rc;

        /* See if there's at least one argument */
        if( lua_tostring(L, 1) == NULL ) {
                lua_pushboolean(L, 0);
                return 1;
        }

        /* Make sure there's at least one step */
        count = (int)lua_tonumber(L, 1);
        if( count < 1 ) {
                lua_pushboolean(L, 0);
                return 1;
        }

        /* Get the monitor */
        if( intrCur->monitor == NULL ) {
                if( intrCur->askedForMonitor ) {
                        lua_pushboolean(L, 0);
                        return 1;
                }

                if( LXx_FAIL( dlgSrv[0]->MonitorAllocate( dlgSrv, "Progress", (void **)&intrCur->monitor ) ) || (intrCur->monitor == NULL) ) {
                        lua_pushboolean(L, 0);
                        return 1;
                }

                intrCur->askedForMonitor = 1;
        }

        /* Initialize the monitor */
        rc = intrCur->monitor[0]->Initialize( intrCur->monitor, count );
        if( LXx_OK( rc ) )
                lua_pushboolean(L, 1);
        else
                lua_pushboolean(L, 0);

        return 1;
}

/*
 * lxmonStep() : Step the progress bar.
 *  Increment the progress bar by n steps, or 1 step if no steps
 *   are provided.  This always returns true unless the user
 *   aborts, in which case it returns false.
 */
        int
l_lxmonStep(lua_State *L)
{
        int		 steps;
        LxResult	 rc;

        if( intrCur->monitor == NULL ) {
                lua_pushboolean(L, 1);
                return 1;
        }

        /* See if there are any arguments */
        if( lua_tostring(L, 1) == NULL )
                steps = 1;
        else
                steps = (int)lua_tonumber(L, 1);

        /* Make sure there's at least one step */
        if( steps < 1 ) {
                lua_pushboolean(L, 1);
                return 1;
        }

        /* Increment the monitor and check for a user abort */
        rc = intrCur->monitor[0]->Increment( intrCur->monitor, steps );
        if( LXx_OK( rc ) )
                lua_pushboolean(L, 1);
        else
                lua_pushboolean(L, 0);

        return 1;
}

