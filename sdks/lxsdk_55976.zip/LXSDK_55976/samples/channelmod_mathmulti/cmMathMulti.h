/*
 * Plug-in channel modifiers for various math operations.
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef CMMATHMULTI_H
#define CMMATHMULTI_H

#include <lx_item.hpp>
#include <lx_package.hpp>
#include <lx_value.hpp>
#include <lxlog.h>
#include <lxu_log.hpp>
#include <lx_chanmod.hpp>

#include <iostream>

class CMathMultiLog : public CLxLuxologyLogMessage
{
    public:
        CMathMultiLog () : CLxLuxologyLogMessage ("cmMathMulti") { }

        const char *	 GetFormat  () { return "Math Multiple Object"; }
};


class CMathMultiPackage;

class CMathMultiInstance
        :
        public CLxImpl_PackageInstance,
        public CLxImpl_ChannelModItem
{
        CMathMultiLog		 log;
        
    public:
        CMathMultiPackage	*src_pkg;
        CLxUser_Item		 m_item;
        ILxUnknownID		 inst_ifc;

        LxResult		 pins_Initialize (ILxUnknownID item, ILxUnknownID super);
        void			 pins_Cleanup (void);
        LxResult		 pins_SynthName (char *buf, unsigned len);

        unsigned int		 cmod_Flags (ILxUnknownID item, unsigned int index);
        LxResult		 cmod_Allocate (
                                        ILxUnknownID cmod,
                                        ILxUnknownID eval,
                                        ILxUnknownID item,
                                        void **ppvData);
        void			 cmod_Cleanup (void *data);
        LxResult		 cmod_Evaluate (ILxUnknownID cmod, ILxUnknownID attr, void *data);
};

class CMathMultiPackage : public CLxImpl_Package
{
    public:
        static LXtTagInfoDesc		 descInfo[];
        CLxPolymorph<CMathMultiInstance> chanmod_factory;
        
        CMathMultiPackage ();

        LxResult		pkg_SetupChannels (ILxUnknownID addChan);
        LxResult		pkg_TestInterface (const LXtGUID *guid);
        LxResult		pkg_Attach (void **ppvObj);
};

#endif // CMMATHMULTI_H

