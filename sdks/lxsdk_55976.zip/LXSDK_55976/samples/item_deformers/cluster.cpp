/*
 * CLUSTER.CPP		Vertex Cluster Mesh Influence
 *
 *	Copyright (c) 2008-2012 Luxology LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_item.hpp>
#include <lx_package.hpp>
#include <lx_plugin.hpp>
#include <lx_action.hpp>
#include <lx_visitor.hpp>
#include <lx_value.hpp>
#include <lx_message.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxidef.h>
#include <string>
#include <vector>
#include <math.h>

#include "cluster.h"

        namespace Influence_Cluster {	// disambiguate everything with a namespace

/*
 * A vertex cluster is actually called a "vertex influence".
 */
#define SRVNAME_ITEMTYPE_LOC		LXsITYPE_VERTEXINFLUENCE
#define SRVNAME_MODIFIER_LOC		LXsITYPE_VERTEXINFLUENCE
#define SRVNAME_ITEMTYPE_NL		LXsITYPE_VERTEXINFLUENCENL
#define SRVNAME_MODIFIER_NL		LXsITYPE_VERTEXINFLUENCENL
#define SPNNAME_INSTANCE		"cluster.inst"

/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */

class CPackage;

class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_WeightMapDeformerItem
{
    public:
        CPackage	*src_pkg;
        CLxUser_Item	 m_item;

        LxResult	 pins_Initialize (ILxUnknownID item, ILxUnknownID super) LXx_OVERRIDE;
        void		 pins_Cleanup (void)					LXx_OVERRIDE;
        LxResult	 pins_SynthName (char *buf, unsigned len)		LXx_OVERRIDE;

        LxResult	 wmd_GetMapName (ILxUnknownID cr, char *, unsigned)	LXx_OVERRIDE;
        LxResult	 wmd_GetColor (ILxUnknownID cr, LXtVector col)		LXx_OVERRIDE;
};

class CPackage :
                public CLxImpl_Package,
                public CLxImpl_SceneItemListener
{
    public:
        CLxSpawner<CInstance>	 spawn;
        LXtItemType		 type_1, type_2;

        CPackage () : spawn (SPNNAME_INSTANCE)
        {
                CLxUser_SceneService	 srv;

                type_1 = srv.ItemType (LXsITYPE_VERTEXINFLUENCE);
                type_2 = srv.ItemType (LXsITYPE_VERTEXINFLUENCENL);
        }

        LxResult		pkg_TestInterface (const LXtGUID *guid)		LXx_OVERRIDE;
        LxResult		pkg_Attach (void **ppvObj)			LXx_OVERRIDE;
        LxResult		pkg_SetupChannels (ILxUnknownID addChan)	LXx_OVERRIDE;

        void			sil_ChannelValue (const char *, ILxUnknownID, unsigned)	LXx_OVERRIDE;
};

class CPackageLoc :
                public CPackage
{
    public:
        static LXtTagInfoDesc	 descInfo[];
};

class CPackageNonLoc :
                public CPackage
{
    public:
        static LXtTagInfoDesc	 descInfo[];
};


/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 *
 * We have two packages, the locator and non-locator versions of the
 * vertex cluster.
 */
LXtTagInfoDesc	 CPackageLoc::descInfo[] = {
        { LXsPKG_SUPERTYPE,		LXsITYPE_LOCATOR	},
        { LXsPKG_DEFORMER_CHANNEL,	LXsICHAN_VERTEXINFLUENCE_MESHINF	},
        { LXsPKG_DEFORMER_FLAGS,	"+O"			},	// no offset
        { LXsPKG_DEFORMER_CREATECMD,	CREATECMD_LOC		},
        { 0 }
};

LXtTagInfoDesc	 CPackageNonLoc::descInfo[] = {
        { LXsPKG_SUPERTYPE,		"."			},
        { LXsPKG_DEFORMER_CHANNEL,	LXsICHAN_VERTEXINFLUENCE_MESHINF	},
        { LXsPKG_DEFORMER_FLAGS,	"+O"			},	// no offset
        { LXsPKG_DEFORMER_CREATECMD,	CREATECMD_NL		},
        { 0 }
};


/*
 * The package has a set of standard channels with default values. These
 * are setup at the start using the AddChannel interface.
 */
static LXtTextValueHint hint_Type[] = {
        CTYPE_ALL,		"all",
        CTYPE_WEIGHT,		"mapWeight",
        CTYPE_PICK,		"mapPick",
        CTYPE_MATERIAL,		"ptagMaterial",
        CTYPE_PART,		"ptagPart",
        CTYPE_PSELSET,		"ptagPick",
        -1,			"=vertex-cluster-type",
        -1,			 0
};

        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (LXsICHAN_VERTEXINFLUENCE_MESHINF,	LXsTYPE_OBJREF);
        ac.SetInternal ();

        ac.NewChannel  (LXsICHAN_VERTEXINFLUENCE_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);

        ac.NewChannel  (LXsICHAN_VERTEXINFLUENCE_TYPE,	LXsTYPE_INTEGER);
        ac.SetDefault  (0.0, 0);
        ac.SetHint     (hint_Type);

        ac.NewChannel  (LXsICHAN_VERTEXINFLUENCE_NAME,	LXsTYPE_STRING);

        return LXe_OK;
}

/*
 * TestInterface() is required so that nexus knows what interfaces instance
 * of this package support. Necessary to prevent query loops.
 */
        LxResult
CPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return spawn.TestInterfaceRC (guid);
}

/*
 * Attach is called to create a new instance of this item. The returned
 * object implements a specific item of this type in the scene.
 */
        LxResult
CPackage::pkg_Attach (
        void		       **ppvObj)
{
        CInstance		*inst = spawn.Alloc (ppvObj);

        inst->src_pkg = this;
        return LXe_OK;
}

/*
 * Watch for changes to one of our own and invalidate the synth name.
 */
        void
CPackage::sil_ChannelValue (
        const char		*action,
        ILxUnknownID		 itemObj,
        unsigned		 channel)
{
        CLxUser_Item		 item (itemObj);

        if (item.IsA (type_1) || item.IsA (type_2))
                item.InvalidateName ();
}


/*
 * ----------------------------------------------------------------
 * Item Instance
 *
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events. This instance is currently the same for both locator and
 * non-locator item types, because it does basically nothing.
 */
        LxResult
CInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        m_item.set (item);
        return LXe_OK;
}

        void
CInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

        LxResult
CInstance::pins_SynthName (
        char			*buf,
        unsigned		 len)
{
        CLxUser_Scene		 scene;
        CLxUser_ChannelRead	 chan;
        CLxUser_ValueService	 vsrv;
        CLxUser_MessageService	 msrv;
        CLxUser_Message		 msg;
        CLxUser_Value		 strVal;
        std::string		 type, name;
        int			 typeCode;

        scene.from (m_item);
        scene.GetChannels (chan, LXs_ACTIONLAYER_EDIT);

        typeCode = chan.IValue (m_item, LXsICHAN_VERTEXINFLUENCE_TYPE);
        vsrv.EncodeHint (typeCode, hint_Type, type);

        if (chan.Object (m_item, LXsICHAN_VERTEXINFLUENCE_NAME, strVal))
                strVal.String (name);
        else
                name = "";

        msrv.NewMessage (msg);
        msg.SetMsg (LXsITYPE_VERTEXINFLUENCE, type.c_str ());
        if (typeCode != CTYPE_ALL) {
                if (name.length ())
                        msg.SetArg (1, name.c_str ());
                else
                        msg.SetArg (1, "unset");
        }

        msrv.GetText (msg, name);
        return lx::StringOut (name, buf, len);
}

        LxResult
CInstance::wmd_GetMapName (
        ILxUnknownID		 cr,
        char			*buf,
        unsigned		 len)
{
        CLxUser_ChannelRead	 chan (cr);
        CLxUser_Value		 strVal;
        std::string		 str;

        if (  chan.IValue (m_item, LXsICHAN_VERTEXINFLUENCE_TYPE) == CTYPE_WEIGHT
          &&  chan.Object (m_item, LXsICHAN_VERTEXINFLUENCE_NAME, strVal))
        {
                strVal.String (str);
                return lx::StringOut (str, buf, len);
        }

        return LXe_NOTFOUND;
}

        LxResult
CInstance::wmd_GetColor (
        ILxUnknownID		 cr,
        LXtVector		 col)
{
        return LXe_NOTIMPL;
}


/* 
 * Mesh Influence for a cluster can select points by map and by marking.
 *
 * Computing tag-based clusters is done in two passes. First we clear the mark
 * on all vertices. Then we traverse the polygons and mark the vertices of any that
 * have the right tag.
 */
class CMarkingVisitor :
                public CLxImpl_AbstractVisitor
{
    public:
        CLxUser_Point		*pnt;
        CLxUser_Polygon		 pol;
        CLxUser_StringTag	 tag;
        LXtMarkMode		 mask;
        LXtID4			 type;
        const char		*name;
        bool			 clear;

                LxResult
        Evaluate ()
        {
                if (clear) {
                        pol.SetMarks (mask);
                        return LXe_OK;
                }

                const char *val = tag.Value (type);
                if (val && !strcmp (val, name)) {
                        unsigned	n, i;

                        pol.VertexCount (&n);
                        for (i = 0; i < n; i++) {
                                pnt->SelectPolygonVertex (pol.ID (), i);
                                pnt->SetMarks (mask);
                        }
                }

                return LXe_OK;
        }
};

/* 
 * Cluster Mesh Influence is unusual in that it has no offset. It simply defines
 * sets of points, perhaps with weights.
 */
class CInfluence :
                public CLxMeshInfluence
{
    public:
        bool			 c_enabled;
        int			 c_type;
        std::string		 c_name;

        LXtMeshMapID		 map_id;

                bool
        HasOffset ()						LXx_OVERRIDE
        {
                return false;
        }

                bool
        HasWeight ()						LXx_OVERRIDE
        {
                return (c_type == CTYPE_WEIGHT);
        }

                bool
        IsEnabled ()						LXx_OVERRIDE
        {
                return c_enabled;
        }

                bool
        SelectMap (
                CLxUser_Mesh		&mesh,
                CLxUser_MeshMap		&map)			LXx_OVERRIDE
        {
                if (c_type == CTYPE_WEIGHT)
                        map.SelectByName (LXi_VMAP_WEIGHT, c_name.c_str ());
                else if (c_type == CTYPE_PICK)
                        map.SelectByName (LXi_VMAP_PICK,   c_name.c_str ());
                else
                        return false;

                map_id = map.ID ();
                return true;
        }

                LXtMarkMode
        MarkMode (
                CLxUser_Mesh		&mesh,
                CLxUser_Point		&point)			LXx_OVERRIDE
        {
                if (c_type == CTYPE_ALL)
                        return LXiMARK_ANY;

                CLxUser_MeshService	 mS;
                CMarkingVisitor		 vis;

                vis.pnt = &point;
                vis.pol.fromMesh (mesh);
                vis.tag.set (vis.pol);
                vis.name = c_name.c_str ();
                if (c_type == CTYPE_MATERIAL)
                        vis.type = LXi_PTAG_MATR;
                else if (c_type == CTYPE_PART)
                        vis.type = LXi_PTAG_PART;
                else
                        vis.type = LXi_PTAG_PICK;	// note: logic wrong for this case

                vis.clear = true;
                vis.mask  = mS.ClearMode ("user1");
                vis.pnt->Enum (&vis);

                vis.clear = false;
                vis.mask  = mS.SetMode   ("user1");
                vis.pol.Enum (&vis);

                return vis.mask;
        }

                double
        Weight (
                CLxUser_Point		&point)			LXx_OVERRIDE
        {
                if (c_type != CTYPE_WEIGHT)
                        return 1.0;

                float			 wt;

                point.MapValue (map_id, &wt);
                return wt;
        }
};


/*
 * The modifier operates on all items of this type, and sets the mesh influence
 * channel to an object allocated using the input parameters for the modifier.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        unsigned	 index;

        void		 Eval (CLxUser_Evaluation &, CLxUser_Attributes &)		LXx_OVERRIDE;
};

class CModifier :
                public CLxItemModifierServer
{
    public:
        CLxItemModifierElement *	 Alloc (CLxUser_Evaluation &, ILxUnknownID)	LXx_OVERRIDE;
};

        CLxItemModifierElement *
CModifier::Alloc (
        CLxUser_Evaluation	&eval,
        ILxUnknownID		 item)
{
        CModifierElement	*elt;

        elt = new CModifierElement;
        elt->index = 
         eval.AddChan (item, LXsICHAN_VERTEXINFLUENCE_MESHINF, LXfECHAN_WRITE);
         eval.AddChan (item, LXsICHAN_VERTEXINFLUENCE_ENABLE);
         eval.AddChan (item, LXsICHAN_VERTEXINFLUENCE_TYPE);
         eval.AddChan (item, LXsICHAN_VERTEXINFLUENCE_NAME);

        return elt;
}

        void
CModifierElement::Eval (
        CLxUser_Evaluation	&eval,
        CLxUser_Attributes	&attr)
{
        CLxUser_ValueReference	 ref;
        CInfluence		*infl;
        ILxUnknownID		 obj;

        infl = new CInfluence;
        infl->Spawn ((void **) &obj);

        infl->c_enabled = attr.Bool (index + 1);
        if (infl->c_enabled) {
                infl->c_type = attr.Int (index + 2);
                attr.String (index + 3, infl->c_name);
        }

        attr.ObjectRW (index, ref);
        ref.SetObject (obj);
        lx::UnkRelease (obj);
}


/*
 * Variants for the locator and non-locator item types, otherwise functionally
 * identical.
 */
class CModifierLoc : public CModifier
{
    public:
                const char *
        ItemType ()
        {
                return SRVNAME_ITEMTYPE_LOC;
        }
};

class CModifierNonLoc : public CModifier
{
    public:
                const char *
        ItemType ()
        {
                return SRVNAME_ITEMTYPE_NL;
        }
};




/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackageLoc>;
        srv->AddInterface (new CLxIfc_Package          <CPackageLoc>);
        srv->AddInterface (new CLxIfc_SceneItemListener<CPackageLoc>);
        srv->AddInterface (new CLxIfc_StaticDesc       <CPackageLoc>);
        thisModule.AddServer (SRVNAME_ITEMTYPE_LOC, srv);

        srv = new CLxPolymorph<CPackageNonLoc>;
        srv->AddInterface (new CLxIfc_Package          <CPackageNonLoc>);
        srv->AddInterface (new CLxIfc_SceneItemListener<CPackageNonLoc>);
        srv->AddInterface (new CLxIfc_StaticDesc       <CPackageNonLoc>);
        thisModule.AddServer (SRVNAME_ITEMTYPE_NL, srv);

        srv = new CLxPolymorph<CInstance>;
        srv->AddInterface (new CLxIfc_PackageInstance      <CInstance>);
        srv->AddInterface (new CLxIfc_WeightMapDeformerItem<CInstance>);
        lx::AddSpawner (SPNNAME_INSTANCE, srv);

        CLxExport_ItemModifierServer<CModifierLoc>    (SRVNAME_MODIFIER_LOC);
        CLxExport_ItemModifierServer<CModifierNonLoc> (SRVNAME_MODIFIER_NL);
}

        };	// END namespace


