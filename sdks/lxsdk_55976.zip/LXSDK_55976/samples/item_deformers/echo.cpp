/*
 * ECHO.CPP		Echo Deformer
 *
 *	Copyright (c) 2008-2012 Luxology LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_item.hpp>
#include <lx_package.hpp>
#include <lx_plugin.hpp>
#include <lx_action.hpp>
#include <lx_visitor.hpp>
#include <lx_value.hpp>
#include <lx_message.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxidef.h>
#include <string>
#include <map>
#include <math.h>

#include "cluster.h"

        namespace Influence_Echo {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		"deformer.echo"
#define SRVNAME_MODIFIER		"deformer.echo"
#define SPNNAME_INSTANCE		"echo.inst"
#define SPNNAME_DEFORMER		"echo.deformer"

/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class CPackage;

class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_MeshInfluence,
                public CLxImpl_ItemInfluence
{
    public:
        CPackage		*src_pkg;
        CLxUser_Item		 m_item;
        CLxUser_ItemInfluence	 ii_enum;

        LxResult	 pins_Initialize (ILxUnknownID item, ILxUnknownID super) LXx_OVERRIDE;
        void		 pins_Cleanup (void)					LXx_OVERRIDE;
        LxResult	 pins_SynthName (char *buf, unsigned len)		LXx_OVERRIDE;

        unsigned	 minf_MeshCount (void)					LXx_OVERRIDE;
        LxResult	 minf_MeshByIndex (unsigned index, void **ppvObj)	LXx_OVERRIDE;
        unsigned	 minf_PartitionIndex (unsigned index)			LXx_OVERRIDE;

        LxResult	 iinf_HasItems (void)					LXx_OVERRIDE;
        LxResult	 iinf_Enumerate (ILxUnknownID visitor)			LXx_OVERRIDE;
        LxResult	 iinf_GetItem (void **ppvObj)				LXx_OVERRIDE;

        static ILxUnknownID
                         GetSource (CLxUser_Item &, CLxUser_MeshInfluence &, CLxUser_ItemInfluence &);
};

class CPackage :
                public CLxImpl_Package,
                public CLxImpl_SceneItemListener
{
    public:
        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 spawn;
        LXtItemType		 my_type;

        CPackage () : spawn (SPNNAME_INSTANCE)
        {
                CLxUser_SceneService	 srv;

                my_type = srv.ItemType (SRVNAME_ITEMTYPE);
        }

        LxResult	pkg_TestInterface (const LXtGUID *guid)		LXx_OVERRIDE;
        LxResult	pkg_Attach (void **ppvObj)			LXx_OVERRIDE;
        LxResult	pkg_SetupChannels (ILxUnknownID addChan)	LXx_OVERRIDE;

        void		sil_LinkAdd (const char *graph, ILxUnknownID itemFrom, ILxUnknownID itemTo)	LXx_OVERRIDE;
        void		sil_LinkRemAfter (const char *graph, ILxUnknownID itemFrom, ILxUnknownID itemTo)	LXx_OVERRIDE;
        void		sil_LinkSet (const char *graph, ILxUnknownID itemFrom, ILxUnknownID itemTo)	LXx_OVERRIDE;
        void		sil_ItemName (ILxUnknownID item)	LXx_OVERRIDE;

        void		UpdateName (const char *graph, ILxUnknownID item);
};


/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
#define CHANs_MESHINF		"meshInf"
#define CHANs_ENABLE		"enable"

LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,		LXsITYPE_LOCATOR	},
        { LXsPKG_DEFORMER_CHANNEL,	CHANs_MESHINF		},
        { LXsPKG_DEFORMER_FLAGS,	"+O"			},	// no offset
        { 0 }
};

        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (CHANs_MESHINF,	LXsTYPE_OBJREF);
        ac.SetInternal ();

        ac.NewChannel  (CHANs_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);

        return LXe_OK;
}

/*
 * TestInterface() is required so that nexus knows what interfaces instance
 * of this package support. Necessary to prevent query loops.
 */
        LxResult
CPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return spawn.TestInterfaceRC (guid);
}

/*
 * Attach is called to create a new instance of this item. The returned
 * object implements a specific item of this type in the scene.
 */
        LxResult
CPackage::pkg_Attach (
        void		       **ppvObj)
{
        CInstance		*inst = spawn.Alloc (ppvObj);

        inst->src_pkg = this;
        return LXe_OK;
}

/*
 * Watch for changes to one of our own and invalidate the synth name.
 */
        void
CPackage::UpdateName (
        const char		*graph,
        ILxUnknownID		 itemObj)
{
        if (strcmp (graph, LXsGRAPH_DEFORMERS))
                return;

        CLxUser_Item		 item (itemObj);

        if (item.IsA (my_type))
                item.InvalidateName ();
}

        void
CPackage::sil_LinkAdd (
        const char		*graph,
        ILxUnknownID		 itemFrom,
        ILxUnknownID		 itemTo)
{
        UpdateName (graph, itemFrom);
}

        void
CPackage::sil_LinkRemAfter (
        const char		*graph,
        ILxUnknownID		 itemFrom,
        ILxUnknownID		 itemTo)
{
        UpdateName (graph, itemFrom);
}

        void
CPackage::sil_LinkSet (
        const char		*graph,
        ILxUnknownID		 itemFrom,
        ILxUnknownID		 itemTo)
{
        UpdateName (graph, itemFrom);
}

        void
CPackage::sil_ItemName (
        ILxUnknownID		 itemObj)
{
        CLxUser_Item		 item (itemObj);
        CLxUser_Scene		 scene;
        CLxUser_ItemGraph	 graph;
        CLxUser_Item		 ref;
        unsigned		 i, n;

        scene.from (item);
        scene.GetGraph (LXsGRAPH_DEFORMERS, graph);
        n = graph.Reverse (item);
        for (i = 0; i < n; i++) {
                graph.Reverse (item, i, ref);
                if (ref.IsA (my_type))
                        ref.InvalidateName ();
        }
}


/*
 * ----------------------------------------------------------------
 * Item Instance
 *
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene.
 */
        LxResult
CInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        m_item.set (item);
        return LXe_OK;
}

        void
CInstance::pins_Cleanup (void)
{
        m_item.clear ();
}

/*
 * Given an item, this utility function finds the mesh/item influence item that
 * is the reference for the echo deformation. We basically follow the now
 * heavily overloaded "deformers" graph forward.
 */
        ILxUnknownID
CInstance::GetSource (
        CLxUser_Item		&item,
        CLxUser_MeshInfluence	&mi,
        CLxUser_ItemInfluence	&ii)
{
        CLxUser_ItemGraph	 graph;
        CLxUser_Item		 ref;
        unsigned		 i, n;

        graph.from (item, LXsGRAPH_DEFORMERS);
        n = graph.Forward (item);
        for (i = 0; i < n; i++) {
                graph.Forward (item, i, ref);
                mi.set (ref);
                ii.set (ref);
                if (mi.test () || ii.test ())
                        return ref;
        }

        return 0;
}

/*
 * For items that have a reference item, the synthetic name includes the
 * name of the reference item.
 */
        LxResult
CInstance::pins_SynthName (
        char			*buf,
        unsigned		 len)
{
        CLxUser_MeshInfluence	 mi;
        CLxUser_ItemInfluence	 ii;
        ILxUnknownID		 unk;

        unk = GetSource (m_item, mi, ii);
        if (!unk)
                return LXe_NOTIMPL;

        CLxUser_Item		 iref (unk);
        CLxUser_MessageService	 msrv;
        CLxUser_Message		 msg;
        const char		*name;
        std::string		 text;

        msrv.NewMessage (msg);
        msg.SetMsg (SRVNAME_ITEMTYPE, "name");

        iref.UniqueName (&name);
        msg.SetArg (1, name);

        msrv.GetText (msg, text);
        return lx::StringOut (text, buf, len);
}

/*
 * The mesh influence interface for this instance just echoes the one from the
 * reference item. It might be nice to cache the interface, except that we'd
 * have to release it when the reference is destroyed.
 */
        unsigned
CInstance::minf_MeshCount ()
{
        CLxUser_MeshInfluence	 mi;
        CLxUser_ItemInfluence	 ii;

        GetSource (m_item, mi, ii);
        if (mi.test ())
                return mi.MeshCount ();
        else
                return 0;
}

        LxResult
CInstance::minf_MeshByIndex (
        unsigned		 index,
        void		       **ppvObj)
{
        CLxUser_MeshInfluence	 mi;
        CLxUser_ItemInfluence	 ii;

        GetSource (m_item, mi, ii);
        if (mi.test ())
                return mi.MeshByIndex (index, ppvObj);
        else
                return LXe_OUTOFBOUNDS;
}

        unsigned
CInstance::minf_PartitionIndex (
        unsigned		 index)
{
        CLxUser_MeshInfluence	 mi;
        CLxUser_ItemInfluence	 ii;

        GetSource (m_item, mi, ii);
        if (mi.test ())
                return mi.PartitionIndex (index);
        else
                return ~0;
}

        LxResult
CInstance::iinf_HasItems ()
{
        CLxUser_MeshInfluence	 mi;
        CLxUser_ItemInfluence	 ii;

        GetSource (m_item, mi, ii);
        if (ii.test ())
                return ii.HasItems ();
        else
                return LXe_FALSE;
}

        LxResult
CInstance::iinf_Enumerate (
        ILxUnknownID		 visitor)
{
        CLxUser_MeshInfluence	 mi;
        LxResult		 rc;

        GetSource (m_item, mi, ii_enum);
        if (!ii_enum.test ())
                return LXe_OK;

        rc = ii_enum.Enumerate (visitor);
        ii_enum.clear ();
        return rc;
}

        LxResult
CInstance::iinf_GetItem (
        void		       **ppvObj)
{
        return ii_enum.GetItem (ppvObj);
}


/*
 * The deformer acts mostly as a pass-through for the weights of the reference
 * item.
 */
class CDeformer :
                public CLxImpl_Deformer,
                public CLxImpl_MeshInfluence,
                public CLxImpl_ItemInfluence
{
    public:
        void		 Init (CLxUser_Deformer &prox);

        LxResult	 minf_SetMesh (unsigned index, ILxUnknownID mesh, ILxUnknownID item)	LXx_OVERRIDE;
        LxResult	 minf_SetTransform (unsigned index, LXtMatrix4 xfrm)	LXx_OVERRIDE;
        LxResult	 minf_MeshChange (unsigned index, LxResult change)	LXx_OVERRIDE;

        LxResult	 iinf_AllowTransform (unsigned index, unsigned *flags)	LXx_OVERRIDE;

        unsigned	 dinf_Flags (void)	LXx_OVERRIDE;
        LXtDeformElt	 dinf_Element (void)	LXx_OVERRIDE;
        unsigned	 dinf_PartitionCount (void)	LXx_OVERRIDE;
        LxResult	 dinf_EnumeratePartition (ILxUnknownID visitor, unsigned part)	LXx_OVERRIDE;
        LxResult	 dinf_SetElement (LXtDeformElt elt, unsigned part)	LXx_OVERRIDE;
        double		 dinf_Weight (LXtVector pos)	LXx_OVERRIDE;

        CLxUser_MeshInfluence	 prox_mi;
        CLxUser_ItemInfluence	 prox_ii;
        CLxUser_Deformer	 prox_di;
};

        void
CDeformer::Init (
        CLxUser_Deformer	&prox)
{
        prox_mi.set (prox);
        prox_ii.set (prox);
        prox_di.set (prox);
}

        LxResult
CDeformer::minf_SetMesh (
        unsigned		 index,
        ILxUnknownID		 mesh,
        ILxUnknownID		 item)
{
        return prox_mi.SetMesh (index, mesh, item);
}

        LxResult
CDeformer::minf_SetTransform (
        unsigned		 index,
        LXtMatrix4		 xfrm)
{
        return prox_mi.SetTransform (index, xfrm);
}

        LxResult
CDeformer::minf_MeshChange (
        unsigned		 index,
        LxResult		 change)
{
        return prox_mi.MeshChange (index, change);
}

        LxResult
CDeformer::iinf_AllowTransform (
        unsigned		 index,
        unsigned		*flags)
{
        return prox_ii.AllowTransform (index, flags);
}

        unsigned
CDeformer::dinf_Flags ()
{
        return prox_di.Flags ();
}

        unsigned
CDeformer::dinf_PartitionCount ()
{
        return prox_di.PartitionCount ();
}

        LxResult
CDeformer::dinf_EnumeratePartition (
        ILxUnknownID		 visitor,
        unsigned		 index)
{
        return prox_di.EnumeratePartition (visitor, index);
}

        LXtDeformElt
CDeformer::dinf_Element ()
{
        return prox_di.Element ();
}

        LxResult
CDeformer::dinf_SetElement (
        LXtDeformElt		 elt,
        unsigned		 index)
{
        return prox_di.SetElement (elt, index);
}

        double
CDeformer::dinf_Weight (
        LXtVector		 pos)
{
        return prox_di.Weight (pos);
}


/*
 * The modifier operates on all items of this type, and sets the deformer
 * channel to an allocated object. If there is a good reference item with
 * proxy deformer channel we read that object and init the deformer for
 * action.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        CLxSpawner<CDeformer>	 d_spawn;
        CLxUser_Item		 m_item;
        const char		*ref_id;
        unsigned		 index_0;
        bool			 has_def;

        CModifierElement (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
                        : d_spawn (SPNNAME_DEFORMER)
        {
                m_item.set (item);
                ref_id  = RefID ();
                index_0 = eval.AddChan (item, CHANs_MESHINF, LXfECHAN_WRITE);
                has_def = false;

                if (!ref_id)
                        return;

                CLxUser_Scene	 scene;
                CLxUser_Item	 ref;

                scene.from (m_item);
                scene.GetItem (ref_id, ref);
                if (ref.test ()) {
                        int chan = ref.ChannelIndex ("meshInf");
                        if (chan >= 0) {
                                eval.AddChan (ref, chan, LXfECHAN_READ);
                                has_def = true;
                        }
                }
        }

                const char *
        RefID ()
        {
                CLxUser_MeshInfluence	 mi;
                CLxUser_ItemInfluence	 ii;
                CLxUser_Item		 ref;
                ILxUnknownID		 uref;
                const char		*id;

                uref = CInstance::GetSource (m_item, mi, ii);
                if (!uref)
                        return 0;

                ref.set (uref);
                ref.Ident (&id);
                return id;
        }

                bool
        Test (
                ILxUnknownID		 item)
                                                LXx_OVERRIDE
        {
                return (ref_id == RefID ());
        }

                void
        Eval (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr)
                                                LXx_OVERRIDE
        {
                CDeformer		*defr;
                CLxUser_ValueReference	 ref;
                ILxUnknownID		 obj;

                defr = d_spawn.Alloc (obj);

                attr.ObjectRW (index_0, ref);
                ref.SetObject (obj);
                lx::UnkRelease (obj);

                if (!has_def)
                        return;

                CLxUser_Scene		 scene;
                CLxUser_Item		 iref;
                CLxUser_Deformer	 prox;

                scene.from (m_item);
                scene.GetItem (ref_id, iref);
                attr.ObjectRO (index_0 + 1, ref);
                ref.Get (prox);

                defr->Init (prox);
        }
};

class CModifier :
                public CLxItemModifierServer
{
    public:
                const char *
        ItemType ()
                                                LXx_OVERRIDE
        {
                return SRVNAME_ITEMTYPE;
        }

                const char *
        GraphNames ()
        {
                return LXsGRAPH_DEFORMERS;
        }

                CLxItemModifierElement *
        Alloc (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
                                                LXx_OVERRIDE
        {
                return new CModifierElement (eval, item);
        }
};


/*
 * Export package server to define a new item type. Also create and destroy
 * the factories so they can persist while their objects are in use.
 */
        void
initialize ()
{
        CLxGenericPolymorph		*srv;

        srv = new CLxPolymorph<CPackage>;
        srv->AddInterface (new CLxIfc_Package          <CPackage>);
        srv->AddInterface (new CLxIfc_SceneItemListener<CPackage>);
        srv->AddInterface (new CLxIfc_StaticDesc       <CPackage>);
        lx::AddServer (SRVNAME_ITEMTYPE, srv);

        srv = new CLxPolymorph<CInstance>;
        srv->AddInterface (new CLxIfc_PackageInstance<CInstance>);
        srv->AddInterface (new CLxIfc_MeshInfluence  <CInstance>);
        srv->AddInterface (new CLxIfc_ItemInfluence  <CInstance>);
        lx::AddSpawner (SPNNAME_INSTANCE, srv);

        srv = new CLxPolymorph<CDeformer>;
        srv->AddInterface (new CLxIfc_Deformer     <CDeformer>);
        srv->AddInterface (new CLxIfc_MeshInfluence<CDeformer>);
        srv->AddInterface (new CLxIfc_ItemInfluence<CDeformer>);
        lx::AddSpawner (SPNNAME_DEFORMER, srv);

        CLxExport_ItemModifierServer<CModifier> (SRVNAME_MODIFIER);
}

        };	// END namespace


