/*
 * Plug-in value textures: procedural bricks
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

enum 
    {
    BOND_Running       = 0,     // Running bond (the default)
    BOND_Stack,                 // Stack bond
    BOND_ThirdRunning,          // One-third Running bond
    BOND_Flemish,               // Flemish bond
    BOND_Common,                // Common bond
    BOND_Dutch,                 // Dutch bond (a.k.a. English Cross bond)
    BOND_English,               // English bond

    BOND_Count,                 // number of indices

    HEADERS_Regular     = 0,
    HEADERS_Flemish     = 1,
    };

static LXtTextValueHint hint_bondType[] = {
        BOND_Running,           "RunningBond",
        BOND_Stack,             "StackBond",
        BOND_ThirdRunning,      "OneThirdRunningBond",
        BOND_Flemish,           "FlemishBond",
        BOND_Common,            "CommonBond",
        BOND_Dutch,             "DutchBond",
        BOND_English,           "EnglishBond",
        -1,                     NULL
        };

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Brick texture
 *
 *----------------------------------------------------------------------------*/
class BrickTexture : public CLxImpl_ValueTexture, public CLxImpl_ChannelUI
{
    public:
        BrickTexture () { my_type = LXiTYPE_NONE; }

        COMMON_VIRTUAL_FUNCS_AND_DATA

        bool            HasDependency (const char* channelName);

        LxResult        cui_Enabled           (const char* channelName, ILxUnknownID msg, ILxUnknownID item, ILxUnknownID read);
        LxResult	cui_DependencyCount   (const char* channelName, unsigned* count);
        LxResult	cui_DependencyByIndex (const char* channelName, unsigned index, LXtItemType* depItemType, const char** depChannelName);

        unsigned                idx[15];     // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector      brickColor;
                LXtFVector      mortarColor;
                int             flemishHeaders;
                long            bondId;
                long            patternId;
                long            headerInterval;
                float           mortarWidth;
                float           brightnessVariation;
                float           horizontalVariation;
                float           noisiness;
                float           aspectRatio;

                // derived values:
                float           mortarHeight;
                float           mortarWidthVariation;
        };
};

LXtTagInfoDesc	 BrickTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterBrickTexture (void)
{
        RegisterTextureWithUI<BrickTexture>       ("Brick.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
BrickTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BrickTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("brickColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.5, 0.1, 0.1);
        ac.SetDefaultVec (color);

        ac.NewChannel ("mortarColor",           LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        ac.SetDefault (0.9, 0);

        ac.NewChannel ("flemishHeaders",        LXsTYPE_BOOLEAN);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("bondId",                LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 0);                 // index 0 : BOND_Running
        ac.SetHint    (hint_bondType);
        ac.NewChannel ("patternId",             LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 1);
        ac.SetHint    (hint_intPos);
        ac.NewChannel ("headerInterval",        LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 6);
        ac.SetHint    (hint_intPos);

        ac.NewChannel ("mortarWidth",           LXsTYPE_PERCENT);
        ac.SetDefault (0.05, 0);
        ac.SetHint    (hint_floatZeroToOne);
        ac.NewChannel ("brightnessVariation",   LXsTYPE_PERCENT);
        ac.SetDefault (0.4, 0);
        ac.SetHint    (hint_floatMinZero);
        ac.NewChannel ("horizontalVariation",   LXsTYPE_PERCENT);
        ac.SetDefault (0.33, 0);
        ac.SetHint    (hint_floatMinZero);
        ac.NewChannel ("noisiness",             LXsTYPE_PERCENT);
        ac.SetDefault (0.3, 0);
        ac.SetHint    (hint_floatMinZero);
        ac.NewChannel ("aspectRatio",           LXsTYPE_FLOAT);
        ac.SetDefault (2.0, 0);
        ac.SetHint    (hint_floatPos);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BrickTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "brickColor.R");
        idx[index++] = ev.AddChan (item, "brickColor.G");
        idx[index++] = ev.AddChan (item, "brickColor.B");
        idx[index++] = ev.AddChan (item, "mortarColor.R");
        idx[index++] = ev.AddChan (item, "mortarColor.G");
        idx[index++] = ev.AddChan (item, "mortarColor.B");
        idx[index++] = ev.AddChan (item, "flemishHeaders");
        idx[index++] = ev.AddChan (item, "bondId");
        idx[index++] = ev.AddChan (item, "patternId");
        idx[index++] = ev.AddChan (item, "headerInterval");
        idx[index++] = ev.AddChan (item, "mortarWidth");
        idx[index++] = ev.AddChan (item, "brightnessVariation");
        idx[index++] = ev.AddChan (item, "horizontalVariation");
        idx[index++] = ev.AddChan (item, "noisiness");
        idx[index++] = ev.AddChan (item, "aspectRatio");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BrickTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->brickColor[0]       = at.Float (idx[index++]);
        rd->brickColor[1]       = at.Float (idx[index++]);
        rd->brickColor[2]       = at.Float (idx[index++]);

        rd->mortarColor[0]      = at.Float (idx[index++]);
        rd->mortarColor[1]      = at.Float (idx[index++]);
        rd->mortarColor[2]      = at.Float (idx[index++]);

        rd->flemishHeaders      = at.Int   (idx[index++]);
        int     bondIndex       = at.Int   (idx[index++]);
        rd->patternId           = at.Int   (idx[index++]);
        rd->headerInterval      = at.Int   (idx[index++]);

        rd->mortarWidth         = at.Float (idx[index++]);
        rd->brightnessVariation = at.Float (idx[index++]);
        rd->horizontalVariation = at.Float (idx[index++]);
        rd->noisiness           = at.Float (idx[index++]);
        rd->aspectRatio         = at.Float (idx[index++]);

        // set up local values (if any)
        rd->mortarHeight            = rd->mortarWidth * rd->aspectRatio;
        rd->mortarWidthVariation    = rd->mortarWidth * rd->horizontalVariation;
        rd->bondId                  = bondIndex >= 0 && bondIndex < BOND_Count ? hint_bondType[bondIndex].value : BOND_Running;

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 1/10
 *
 * Determine if channel has dependency
 *
 *----------------------------------------------------------------------------*/
        bool
BrickTexture::HasDependency (const char* channelName)
{
        return 0 == strcmp (channelName, "flemishHeaders") || 0 == strcmp (channelName, "headerInterval");
}

/*------------------------------- Luxology LLC --------------------------- 1/10
 *
 * Test if a given channel is enabled. We're going to disable all read-only
 * channels extracted from the Clouds files.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BrickTexture::cui_Enabled (
        const char		*channelName,
        ILxUnknownID		 msg,
        ILxUnknownID		 item,
        ILxUnknownID		 read)
{
        if (! HasDependency (channelName))
            return LXe_OK;

        CLxUser_Item		 src (item);
        CLxUser_ChannelRead	 chan (read);

        // enable items only if bondId is Common Bond
        int     bondIndex = chan.IValue (src, "bondId");
        return bondIndex >= 0 && bondIndex < BOND_Count && BOND_Common == hint_bondType[bondIndex].value ? LXe_OK : LXe_CMD_DISABLED;
}

/*------------------------------- Luxology LLC --------------------------- 1/10
 *
 * Dependency count of the channels that affect a given target channel.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BrickTexture::cui_DependencyCount (const char* channelName, unsigned* count)
{
        count[0] = HasDependency (channelName) ? 1 : 0;

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 1/10
 *
 * Dependency indices of the channels that affect a given target channel.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BrickTexture::cui_DependencyByIndex (
        const char		*channelName,
        unsigned		 index,
        LXtItemType		*depItemType,
        const char	       **depChannelName)
{
        if (! HasDependency (channelName))
                return LXe_OUTOFBOUNDS;

        if (LXiTYPE_NONE == my_type)
            {
            CLxUser_SceneService     svc;
            my_type = svc.ItemType ("val.Brick.BSI");
            }

        // some items enabled based on bondId
        depItemType[0]      = my_type;
        depChannelName[0]   = "bondId";
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
BrickTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
        typedef struct
                {
                float   offset;
                int     bricksPerRow;
                float   *arrayP;
                } BondData;

        static float defaultBondArray[5] =
            {0.250f, 0.500f, 0.750f, 1.000f, 1.250f};

        static float flemishBondArray[7] =
            {0.250f, 0.375f, 0.625f, 0.750f, 1.000f, 1.125f, 1.375f};

        static float englishBondArray[10] =
            {0.125f, 0.250f, 0.375f, 0.500f, 0.625f, 0.750f, 0.875f, 1.000f, 1.125f, 1.250f};

        static float dutchBondArray[14] =
            {0.250f, 0.375f, 0.625f, 0.875f, 1.125f, 1.250f, 1.500f, 1.750f, 1.875f, 2.125f,
             2.375f, 2.625f, 2.750f, 3.000f};

        static float headerArray[10] =
            {0.125f, 0.250f, 0.375f, 0.500f, 0.625f, 0.750f, 0.875f, 1.000f, 1.125f, 1.250f};

        static float flemishHeaderArray[7] =
            {0.125f, 0.250f, 0.500f, 0.625f, 0.875f, 1.000f, 1.250f};

        static BondData bondData[] = {
            { 0.1250f,  4, defaultBondArray },      // BOND_Running
            { 0.0000f,  4, defaultBondArray },      // BOND_Stack
            { 0.1667f,  4, defaultBondArray },      // BOND_ThirdRunning
            { 0.1875f,  6, flemishBondArray },      // BOND_Flemish
            { 0.1250f,  4, defaultBondArray },      // BOND_Common
            { 0.0000f, 13, dutchBondArray },        // Alt Even rows of BOND_Dutch
            { 0.1875f,  8, englishBondArray }       // Odd rows of BOND_English
            };

        static BondData headerData[] = {
            { 0.1875f,  8, headerArray },           // Regular Headers
            { 0.1875f,  5, flemishHeaderArray }     // Flemish Headers
            };

        static float const      s_scaleRand = 1.0f / (float)0xffffffff;

        LXpTextureInput*    tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
        RendData*           rd = (RendData *) data;

        tOut->direct   = 1;             // result should NOT be blended
        tOut->alpha[0] = 1.0;           // texture is opaque

        BondData*           bondP;
        LXtFVector2         pos, intPos, brickPos, intBrickPos, fracBrickPos;
        int                 bricksPerRow    = 4;
        int                 bricksPerColumn = (int)(bricksPerRow * rd->aspectRatio);
        bool                header          = false;

        if (bricksPerColumn == 0)
            bricksPerColumn = 1;

        // Use 2-D (u,v) coordinate to compute texture for brick

        pos[0]          = (float)tInp->uvw[0];
        pos[1]          = (float)tInp->uvw[1];
        brickPos[1]     = pos[1] * bricksPerColumn;

        // Separate coordinates into integer and fractional parts
        intPos[0]       = (float)floor (pos[0]);
        intPos[1]       = (float)floor (pos[1]);
        intBrickPos[1]  = (float)floor (brickPos[1]);

        // Figure out which brick is at this position
        fracBrickPos[0]     = pos[0]      - intPos[0];
        fracBrickPos[1]     = brickPos[1] - intBrickPos[1];

        int     brickRow    = (int)intPos[1] * bricksPerColumn + (int)intBrickPos[1] % bricksPerColumn;

        /* Select bond pattern and odd row offset */
        switch (rd->bondId)
            {
            case BOND_Running:
            case BOND_Flemish:
            case BOND_ThirdRunning:
            case BOND_Stack:
                bondP = &bondData[rd->bondId];
                break;

            case BOND_Common:
                if (1 == brickRow % rd->headerInterval)
                    {
                    header = true;
                    bondP = rd->flemishHeaders ? &headerData[HEADERS_Flemish] : &headerData[HEADERS_Regular];
                    }
                else
                    bondP = &bondData[BOND_Common];
                break;

            case BOND_Dutch:
                if (brickRow & 1)
                    bondP = &bondData[BOND_English];

                else if (1 & (brickRow >> 1))
                    {
                    bondP = &bondData[BOND_Dutch];
                    if ((bondP->offset = (float)((int)intPos[0] % 3)) > 0.0f)
                        header = true;
                    }
                else
                    bondP = &bondData[BOND_Running];
                break;

            case BOND_English:
                bondP = brickRow & 1 ? &bondData[BOND_English] : &bondData[BOND_Running];
                break;
            }

        float*      bondArray   = bondP->arrayP;
        bricksPerRow            = bondP->bricksPerRow;

        if (header || brickRow & 1)
            fracBrickPos[0] += bondP->offset;       // Offset odd rows

        /* Find the brick column */
        int         brickColumn = 0;
        float       previous    = 0.0f;

        while (bondArray[brickColumn] < fracBrickPos[0])
            previous = bondArray[brickColumn++];

        float       uWidth      = bondArray[brickColumn] - previous;
        brickColumn            += (int)intPos[0] * bricksPerRow;

        fracBrickPos[0]         = (fracBrickPos[0] - previous) / uWidth;

        /* Get two random unsigned long values (for adding some variation to the pattern) */
        unsigned    r1          = brickRow;
        unsigned    r2          = brickColumn;
        NoiseUtils  noiseUtils;

        noiseUtils.psdes (r1, r2);

        /* Vary the horizontal position of each brick */
        float       offset      = rd->mortarWidthVariation * (float)r2 * s_scaleRand;
        fracBrickPos[0] -= offset;

        if (fracBrickPos[0] < 0.0f)
            {
            /* If the offset moved back into a different brick, we need to recompute */
            r1                  = brickRow;
            r2                  = brickColumn - 1;
            noiseUtils.psdes (r1, r2);
            offset              = rd->mortarWidthVariation * (float)r2 * s_scaleRand;
            fracBrickPos[0]    += 1.0f - offset;
            }

        /* Compute a 3-D black and white noise value */
        LXtVector           pos3d;

        LXx_VSCL3 (pos3d, tInp->tPos, 1000.0);

        double*     dnoise = noiseUtils.noise3 (pos3d);
        double      noise  = rd->noisiness * dnoise[2];
        float       uScale = rd->mortarWidth * (1.0f / (bricksPerRow * uWidth));

        /* Color the pixel differently depending on whether it's on the brick or the mortar */
        if (fracBrickPos[0] < uScale || fracBrickPos[1] > 1.0 - rd->mortarHeight)
            {
            /* Place a mortar border around each brick */

            if (LXi_TFX_COLOR == tInp->context)
                {
                noise *= 0.5f;                  /* add in some 3-D black and white noise */

                tOut->color[0][0] = noise + rd->mortarColor[0];
                tOut->color[0][1] = noise + rd->mortarColor[1];
                tOut->color[0][2] = noise + rd->mortarColor[2];
                }
            else
                {
                double      depth = fracBrickPos[0] < uScale ? uScale - fracBrickPos[0] : fracBrickPos[1] - (1.0 - rd->mortarHeight);

                tOut->value[0] = -sqrt (depth) - 0.1 * noise;
                }
            }
        else
            {
            if (LXi_TFX_COLOR == tInp->context)
                {
                /* Vary the brightness and add in some 3-D black and white noise */
                float   brightness = 1.0f - rd->brightnessVariation * 0.5f + rd->brightnessVariation * (float)r1 * s_scaleRand;

                tOut->color[0][0] = noise + brightness * rd->brickColor[0];
                tOut->color[0][1] = noise + brightness * rd->brickColor[1];
                tOut->color[0][2] = noise + brightness * rd->brickColor[2];
                }
            else
                tOut->value[0] = rd->mortarWidth + 0.1 * noise;
            }
}

