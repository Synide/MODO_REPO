/*
 * Plug-in value textures: procedural boards
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 *
 *   Portions Copyright (c) 2000-2010 by Bentley Systems, Inc.
 */

#include "bentleyTextures.hpp"

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * 2d procedural boards, with 3d wood
 *
 *----------------------------------------------------------------------------*/
class BoardsTexture : public CLxImpl_ValueTexture
{
    public:
        BoardsTexture () {}

        COMMON_VIRTUAL_FUNCS_AND_DATA

        unsigned                idx[13];    // indices to each data channel in RendData

        class RendData {
            public:
                LXtFVector	baseColor;
                LXtFVector	ringColor;
                long            patternId;
                long            boardsPerColumn;
                long            boardsPerRow;
                float           crackWidth;
                float           brightnessVariation;
                float           horizontalVariation;
                float           grainScale;

                // derived values:
                float           invGrainScale;
                float           crackWidthVariation;
                float           crackWidthEdgeNear;
                float           crackWidthEdgeFar;
        };

    private:
        void    WoodGrain (LXtVector color, LXtFVector pos, RendData* rd);
};

LXtTagInfoDesc	 BoardsTexture::descInfo[] = {
        { LXsSRV_LOGSUBSYSTEM,	"proc-texture"	},
        { 0 }
};

/*------------------------------- Luxology LLC --------------------------- 01/10
 *
 * local function to register plug-in class using template.
 *
 *----------------------------------------------------------------------------*/
        void
RegisterBoardsTexture (void)
{
        RegisterTexture<BoardsTexture>      ("Boards.BSI");
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * clean up render data
 *
 *----------------------------------------------------------------------------*/
        void
BoardsTexture::vtx_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Setup channels for the item type.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BoardsTexture::vtx_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
        LXtVector                color;

        ac.NewChannel ("baseColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.67, 0.38, 0.16);
        ac.SetDefaultVec (color);

        ac.NewChannel ("ringColor",             LXsTYPE_COLOR1);
        ac.SetVector  (LXsCHANVEC_RGB);
        LXx_V3SET (color, 0.44, 0.23, 0.09);
        ac.SetDefaultVec (color);

        ac.NewChannel ("patternId",             LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 1);
        ac.SetHint    (hint_intPos);
        ac.NewChannel ("boardsPerColumn",       LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 16);
        ac.SetHint    (hint_intPos);
        ac.NewChannel ("boardsPerRow",          LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 2);
        ac.SetHint    (hint_intPos);

        ac.NewChannel ("crackWidth",            LXsTYPE_PERCENT);
        ac.SetDefault (0.02, 0);
        ac.SetHint    (hint_floatZeroToOne);
        ac.NewChannel ("brightnessVariation",   LXsTYPE_PERCENT);
        ac.SetDefault (0.4, 0);
        ac.SetHint    (hint_floatMinZero);
        ac.NewChannel ("horizontalVariation",   LXsTYPE_PERCENT);
        ac.SetDefault (0.33, 0);
        ac.SetHint    (hint_floatMinZero);
        ac.NewChannel ("grainScale",            LXsTYPE_FLOAT);
        ac.SetDefault (1.0, 0);
        ac.SetHint    (hint_floatPos);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Attach to channel evaluations. This gets the indicies for the channels in attributes.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BoardsTexture::vtx_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);
        int                      index = 0;

        idx[index++] = ev.AddChan (item, "baseColor.R");
        idx[index++] = ev.AddChan (item, "baseColor.G");
        idx[index++] = ev.AddChan (item, "baseColor.B");
        idx[index++] = ev.AddChan (item, "ringColor.R");
        idx[index++] = ev.AddChan (item, "ringColor.G");
        idx[index++] = ev.AddChan (item, "ringColor.B");
        idx[index++] = ev.AddChan (item, "patternId");
        idx[index++] = ev.AddChan (item, "boardsPerColumn");
        idx[index++] = ev.AddChan (item, "boardsPerRow");
        idx[index++] = ev.AddChan (item, "crackWidth");
        idx[index++] = ev.AddChan (item, "brightnessVariation");
        idx[index++] = ev.AddChan (item, "horizontalVariation");
        idx[index++] = ev.AddChan (item, "grainScale");

        tin_offset = pkt_service.GetOffset (LXsCATEGORY_SAMPLE, LXsP_TEXTURE_INPUT);

        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Read channel values which may have changed.
 *
 *----------------------------------------------------------------------------*/
        LxResult
BoardsTexture::vtx_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	at (attr);
        RendData*               rd = new RendData;
        int                     index = 0;

        rd->baseColor[0]        = at.Float (idx[index++]);
        rd->baseColor[1]        = at.Float (idx[index++]);
        rd->baseColor[2]        = at.Float (idx[index++]);

        rd->ringColor[0]        = at.Float (idx[index++]);
        rd->ringColor[1]        = at.Float (idx[index++]);
        rd->ringColor[2]        = at.Float (idx[index++]);

        rd->patternId           = at.Int   (idx[index++]);
        rd->boardsPerColumn     = at.Int   (idx[index++]);
        rd->boardsPerRow        = at.Int   (idx[index++]);

        rd->crackWidth          = at.Float (idx[index++]);
        rd->brightnessVariation = at.Float (idx[index++]);
        rd->horizontalVariation = at.Float (idx[index++]);
        rd->grainScale          = at.Float (idx[index++]);

        // set up local values

        rd->invGrainScale       = 0.0f == rd->grainScale ? 1.0f : 1.0f / rd->grainScale;
        rd->crackWidthVariation = rd->crackWidth * rd->horizontalVariation;
        rd->crackWidthEdgeNear  = rd->crackWidth * 0.5f;
        rd->crackWidthEdgeFar   = 1.0f - rd->crackWidth;

        ppvData[0] = rd;
        return LXe_OK;
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate wood texture without noise (algorithm from book by Alan Watt)
 *
 *----------------------------------------------------------------------------*/
        void
BoardsTexture::WoodGrain (
        LXtVector       color,
        LXtFVector      pos,
        RendData*       rd)
{
    static double const     s_yScale = 1.0 / 150.0;

    // Make some concentric cylinders
    double      radius = sqrt (pos[0]*pos[0] + pos[2]*pos[2]);

    // Apply a sinusoidal perturbation, and a "small" twist
    double      angle = 0.0 == pos[2] ? HALFPI : atan2 (pos[0], pos[2]);

    radius += 2.0 * sin (20.0 * angle + pos[1] * s_yScale);

    // Make grain 2/3 light and 1/3 dark
    int         grain = (int)(radius + 0.5) % 60;

    if (grain < 40)
        LXx_VCPY (color, rd->baseColor);
    else
        LXx_VCPY (color, rd->ringColor);
}

/*------------------------------- Luxology LLC --------------------------- 12/09
 *
 * Evaluate the color at a spot.
 *
 *----------------------------------------------------------------------------*/
        void
BoardsTexture::vtx_Evaluate (
        ILxUnknownID            vector, 
        LXpTextureOutput	*tOut,
        void			*data)
{
        LXpTextureInput*    tInp = (LXpTextureInput*) pkt_service.FastPacket (vector, tin_offset);
        RendData*           rd = (RendData *) data;
        LXtFVector2         pos, intPos, fracPos, boardPos, fracBoardPos;
        int                 boardColumn, boardRow;

        static float const      s_scaleRand = 1.0f / (float)0xffffffff;

        tOut->direct   = 1;             // result should NOT be blended
        tOut->alpha[0] = 1.0;           // texture is opaque

        // get absolute value of texture coords
        pos[0] = (float)fabs (tInp->uvw[0]);    pos[1] = (float)fabs (tInp->uvw[1]);

        // Separate coordinates into integer and fractional parts
        intPos[0] = (float)(int)pos[0];   fracPos[0] = pos[0] - intPos[0];
        intPos[1] = (float)(int)pos[1];   fracPos[1] = pos[1] - intPos[1];

        // Figure out which board is at this position
        boardPos[1]         = pos[1] * rd->boardsPerColumn;
        fracBoardPos[1]     = boardPos[1] - (int)boardPos[1];

        boardColumn         = (int)boardPos[1] % rd->boardsPerColumn;
        boardPos[0]         = pos[0] * rd->boardsPerRow;

        if (boardColumn & 1)            // odd column?
            boardPos[0] += 0.5f;        // Offset odd rows by half a board width

        fracBoardPos[0]     = boardPos[0] - (int)boardPos[0];
        boardRow            = (int)boardPos[0] % rd->boardsPerRow;

        unsigned    board   = rd->boardsPerRow * boardColumn + boardRow;
        unsigned    r2      = board;
        unsigned    r1      = rd->patternId >= 0 ? rd->patternId : - rd->patternId;
        NoiseUtils  noiseUtils;

        // Get two random unsigned long values (for adding some variation to the pattern)
        noiseUtils.psdes (r1, r2);

        // Vary the horizontal position of each board
        float   offset      = rd->crackWidthVariation * (float)r2 * s_scaleRand;
        fracBoardPos[0]    -= offset;

        if (fracBoardPos[0] < 0.0f)
            {
            // If the offset moved back into a different board, we need to recompute
            r2                  = --board;
            r1                  = rd->patternId >= 0 ? rd->patternId : - rd->patternId;
            noiseUtils.psdes (r1, r2);
            offset              = rd->crackWidthVariation * (float)r2 * s_scaleRand;
            fracBoardPos[0]    += 1.0f - offset;
            }

        // Color the pixel differently depending on whether it's on the board or the crack
        if (fracBoardPos[0] < rd->crackWidthEdgeNear || fracBoardPos[1] > rd->crackWidthEdgeFar)
            {
            /* Place a crack border around each board */
            if (LXi_TFX_COLOR == tInp->context)
                LXx_VSET (tOut->color[0], 0.0f);
            else
                tOut->value[0] = -1.0;

            return;
            }

        if (LXi_TFX_SCALAR == tInp->context)
            {
            tOut->value[0] = 1.0;
            return;
            }

        LXtFVector2         randomPos;
        LXtFVector          pos3d;

        // Compute a wood value for the board
        randomPos[0] = (float)r1 * s_scaleRand + boardPos[0] * 0.1f;
        randomPos[1] = (float)r2 * s_scaleRand + boardPos[1] * 0.1f;

        pos3d[0] = 1.0f + 0.966f * randomPos[0] - 0.259f * randomPos[1];     // 15 degree slant
        pos3d[1] = 1.0f + 0.259f * randomPos[0] + 0.966f * randomPos[1];
        pos3d[2] = 4.0f;

        // Apply scale factors to the position
        static float const      s_internalScale = 125000.0f;
        float                   scale = s_internalScale * rd->invGrainScale;
        LXx_VSCL (pos3d, scale);

        WoodGrain (tOut->color[0], pos3d, rd);

        // Vary the brightness
        float   brightness = 1.0f - rd->brightnessVariation * 0.5f + rd->brightnessVariation * (float)r1 * s_scaleRand;
        LXx_VSCL (tOut->color[0], brightness);
}

