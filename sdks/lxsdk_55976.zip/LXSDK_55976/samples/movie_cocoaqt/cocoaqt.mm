/*
 * Plug-in Cocoa QuickTime saver for movies.
 *
 * Copyright (c) 2008-2012 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include <lx_image.hpp>
#include <stdlib.h>
#include <QTKit/QTKit.h>
#include <Cocoa/Cocoa.h>
#include <QuickTime/QuickTime.h>

using namespace lx;

class CCocoaQuickTimeMovie : public CLxImpl_Movie
{
    public:
        LxResult		 mov_BeginMovie (const char*,int, int, int);
        LxResult		 mov_SetFramerate (int);
        LxResult		 mov_AddImage (ILxUnknownID);
        LxResult		 mov_EndMovie (void);

        static LXtTagInfoDesc	 descInfo[];

        int			 frameRate;
        NSString		*nsStringPath;
        QTMovie			*mMovie;
        NSDictionary		*myDict;
};

        LxResult
CCocoaQuickTimeMovie::mov_BeginMovie (
        const char              *fname,
        int                      w,
        int                      h,
        int                      flags)
{
        /*
         * Set up a dictionary with the codec attributes to be used when
         * creating our movie. For now, we always use "mp4v" for MPEG4.
         */
        myDict = [NSDictionary dictionaryWithObjectsAndKeys:@"mp4v",
                  QTAddImageCodecType,
                  [NSNumber numberWithLong:codecHighQuality],
                  QTAddImageCodecQuality,
                  nil];

        nsStringPath = [NSString stringWithUTF8String: fname];
        [nsStringPath retain];
        
        if (!nsStringPath)
                return LXe_FAILED;

        /*
         * If we made it this far, we already have permission to overwrite
         * an existing file.
         */
 	if ([[NSFileManager defaultManager] fileExistsAtPath: nsStringPath]) {
                if ([[NSFileManager defaultManager] removeFileAtPath:nsStringPath handler:nil]) {
                        NSLog(@"existing file - removed successfully");
                }
                else {
                        // We can't continue with the previous file.
                        return LXe_FAILED;
                }
        }

        // Create a QTMovie with a writable data reference.
        NSError *error = nil;
        mMovie = [[QTMovie alloc] initToWritableFile:nsStringPath error:&error];

        // Mark the movie as editable.
        [mMovie setAttribute:[NSNumber numberWithBool:YES] forKey:QTMovieEditableAttribute];
        
        // Keep it around until we are done with it.
        [mMovie retain];

        return LXe_OK;
}	

        LxResult
CCocoaQuickTimeMovie::mov_SetFramerate (
        int			 frate)
{
        frameRate = frate;

        return LXe_OK;
}	

        static NSImage *
cgImageToNSImage (
        CGImageRef	 image)
{
        NSRect		 imageRect = NSMakeRect(0.0, 0.0, 0.0, 0.0);
        CGContextRef	 imageContext = nil;
        NSImage		*newImage = nil;
        
        // Get the image dimensions.
        imageRect.size.height = CGImageGetHeight(image);
        imageRect.size.width = CGImageGetWidth(image);
        
        // Create a new image to receive the Quartz image data.
        newImage = [[NSImage alloc] initWithSize:imageRect.size];
        [newImage lockFocus];
        
        // Get the Quartz context and draw.
        imageContext = (CGContextRef)[[NSGraphicsContext currentContext]
                                      graphicsPort];
        CGContextDrawImage(imageContext, *(CGRect*)&imageRect, image);
        [newImage unlockFocus];
        
        return newImage;
}

        LxResult
CCocoaQuickTimeMovie::mov_AddImage (
        ILxUnknownID		 img)
{
        CLxUser_Image		 image (img);

        // Set up our dimensions.
        unsigned int	 iw, ih;
        image.Size (&iw, &ih);
        unsigned int rowBytes = (iw * 3 + 3) & ~3;

        // Create the line and frame buffers.
        LXtImageByte		*line, *lineBuffer, *frameBuffer, *frameLine;
        lineBuffer = (LXtImageByte *) malloc (rowBytes);
        frameBuffer = (LXtImageByte *)malloc (ih * rowBytes);
        if (frameBuffer) {
                // Copy the scanlines into a raw frame buffer.
                frameLine = frameBuffer;
                for (unsigned y = 0; y < ih; ++y) {
                        line = (LXtImageByte *) image.GetLine (
                                y, LXiIMP_RGB24, lineBuffer);
                        memcpy (frameLine, line, rowBytes);
                        frameLine += rowBytes;
                }

                // Construct a CGImage from the raw frame buffer.
                CGDataProviderRef	 dataProvider;
                CGImageRef		 cgImageRef;
                CGColorSpaceRef		 colorSpace;

                dataProvider = CGDataProviderCreateWithData (
                        NULL, frameBuffer, ih * rowBytes, NULL);
                colorSpace = CGColorSpaceCreateDeviceRGB ();
                cgImageRef = CGImageCreate (iw, ih, 8, 24, rowBytes, colorSpace, 
                        kCGImageAlphaNone, dataProvider, NULL, 1, kCGRenderingIntentDefault);
                
                CGColorSpaceRelease (colorSpace);
                CGDataProviderRelease (dataProvider);
                
                // Convert the CGImage to an NSImage.
                NSImage *anImage = cgImageToNSImage (cgImageRef);

                // Free both the CGImage and the raw image buffer.
                CGImageRelease (cgImageRef);
                free (frameBuffer);

                // Calculate the duration of the image during the movie.
                long long timeValue = 1;
                long timeScale      = frameRate;
                QTTime duration     = QTMakeTime(timeValue, timeScale);

                // Add the NSImage for the specified duration to the QTMovie.
                [mMovie addImage:anImage 
                        forDuration:duration
                        withAttributes:myDict];
                
                // Free our image object.
                [anImage release];
        }
        free (lineBuffer);

        return LXe_OK;
}

        LxResult
CCocoaQuickTimeMovie::mov_EndMovie (void)
{
        BOOL success = [mMovie updateMovieFile];

        [nsStringPath release];
        [mMovie release];

        return LXe_OK;
}

LXtTagInfoDesc	 CCocoaQuickTimeMovie::descInfo[] = {
        { LXsLOD_CLASSLIST,	LXa_MOVIE         },
        { LXsLOD_DOSPATTERN,	"*.mov"           },
        { LXsSAV_DOSTYPE,	"mov"             },
        { LXsSRV_USERNAME,	"Quicktime Movie" },
        { 0 }
};


/*
 * ----------------------------------------------------------------
 * Exporting Servers
 */
        void
initialize ()
{
        LXx_ADD_SERVER (Movie, CCocoaQuickTimeMovie, "quicktime");
}


