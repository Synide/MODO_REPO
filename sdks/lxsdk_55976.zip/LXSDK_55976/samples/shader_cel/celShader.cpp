/*
 * Plug-in component shader: cel shader
 *
 *   Copyright (c) 2008-2012 Luxology LLC
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"),
 *   to deal in the Software without restriction, including without limitation
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.   Except as contained
 *   in this notice, the name(s) of the above copyright holders shall not be
 *   used in advertising or otherwise to promote the sale, use or other dealings
 *   in this Software without prior written authorization.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 */

#include <lx_shade.hpp>
#include <lx_vector.hpp>
#include <lx_package.hpp>
#include <lx_action.hpp>
#include <lx_value.hpp>
#include <lx_log.hpp>
#include <lx_channelui.hpp>
#include <lx_item.hpp>
#include <lxcommand.h>
#include <lxidef.h>
#include <lx_raycast.hpp>
#include <lx_shdr.hpp>

#include <math.h>
#include <string>

/*
 * Cel material & shader
 * The cel shader is implemented as a custom material. Custom materials have the ability to set material attributes 
 * and to contribute to shading after the base shader has been evaluated
 */
class CelMaterial : public CLxImpl_CustomMaterial
{
    public:
        CelMaterial () {}

        static LXtTagInfoDesc	descInfo[];

        int			cmt_Flags () LXx_OVERRIDE;
        LxResult		cmt_SetupChannels (ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		cmt_LinkChannels  (ILxUnknownID eval, ILxUnknownID item) LXx_OVERRIDE;
        LxResult		cmt_ReadChannels  (ILxUnknownID attr, void **ppvData) LXx_OVERRIDE;
        void			cmt_MaterialEvaluate      (
                                        ILxUnknownID		 vector,
                                        void			*data) LXx_OVERRIDE;
        void			cmt_ShaderEvaluate      (
                                        ILxUnknownID		 vector,
                                        ILxUnknownID		 rayObj,
                                        LXpShadeComponents	*sCmp,
                                        LXpShadeOutput		*sOut,
                                        void			*data) LXx_OVERRIDE;
        void			cmt_Cleanup       (void *data) LXx_OVERRIDE;

        LxResult		cmt_SetOpaque       (int *opaque) LXx_OVERRIDE;
                
        LXtItemType		MyType ();
        
  	LXtItemType		my_type; 	
        
        unsigned                idx[6];     // indices to each data channel in RendData
        
        class RendData {
                public:
                        int	      	diffBands;
                        int	      	specBands;
                        int	      	reflBands;
                        float		diffLevel, specLevel, reflLevel;
        };
};

#define SRVs_CEL_MATR			"celShader"
#define SRVs_CEL_MATR_ITEMTYPE		"material." SRVs_CEL_MATR

LXtTagInfoDesc	 CelMaterial::descInfo[] = {
        { LXsSRV_USERNAME,	"Cel Material" },
        { LXsSRV_LOGSUBSYSTEM,	"comp-shader"	},
        { 0 }
};

/*
 * clean up render data
 */
        void
CelMaterial::cmt_Cleanup (
        void			*data)
{
        RendData*       rd = (RendData*)data;

        delete rd;
}

/*
 * Setup channels for the item type.
 */
        int
CelMaterial::cmt_Flags ()
{
        return 0;
}
        
        LxResult
CelMaterial::cmt_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);
     
        ac.NewChannel ("diffBands",            LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 3);

        ac.NewChannel ("specBands",            LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("reflBands",            LXsTYPE_INTEGER);
        ac.SetDefault (0.0, 0);

        ac.NewChannel ("diffLevel",        LXsTYPE_PERCENT);
        ac.SetDefault (0.50, 0);

        ac.NewChannel ("specLevel",        LXsTYPE_PERCENT);
        ac.SetDefault (0.50, 0);

        ac.NewChannel ("reflLevel",        LXsTYPE_PERCENT);
        ac.SetDefault (0.50, 0);

        return LXe_OK;
}

/*
 * Attach to channel evaluations.
 * This gets the indices for the channels in attributes.
 */
        LxResult
CelMaterial::cmt_LinkChannels (
        ILxUnknownID		 eval,
        ILxUnknownID		 item)
{
        CLxUser_Evaluation	 ev (eval);

        int			 i = 0;

        idx[i++] = ev.AddChan (item, "diffBands");		
        idx[i++] = ev.AddChan (item, "specBands");
        idx[i++] = ev.AddChan (item, "reflBands");
        idx[i++] = ev.AddChan (item, "diffLevel");
        idx[i++] = ev.AddChan (item, "specLevel");
        idx[i++] = ev.AddChan (item, "reflLevel");

        return LXe_OK;
}

/*
 * Read channel values which may have changed.
 */
        LxResult
CelMaterial::cmt_ReadChannels (
        ILxUnknownID		 attr,
        void		       **ppvData)
{
        CLxUser_Attributes	 at (attr);
        RendData*                rd = new RendData;

        int			 i = 0;
   
        rd->diffBands           = at.Int (idx[i++]);		
        rd->specBands           = at.Int (idx[i++]);
        rd->reflBands           = at.Int (idx[i++]);
        rd->diffLevel           = at.Float (idx[i++]);
        rd->specLevel           = at.Float (idx[i++]);
        rd->reflLevel           = at.Float (idx[i++]);
        
        ppvData[0] = rd;
        return LXe_OK;
}

        static double
FVectorNormalize (
        LXtFVector		v) 
{
        float		m, p;
        m = LXx_VDOT (v, v);
        if(m<=0)
                return -1;
        m = sqrt (m);
        p = 1.0 / m;
        LXx_VSCL (v, p);
        return m;
}

        static void
FVectorQuantize (
        LXtFVector		vec,
        int			bnd,
        float			level) 
{
        float			vec0[3], len;
        int			i;
        
        LXx_VCPY (vec0, vec);
        len = FVectorNormalize (vec0);
        
        for (i=0;i<3;i++)
                vec[i] = vec0[i]*(floor(len*(bnd-1)) + level)/(float)bnd;	
}

/*
 * Since the cel shader is modifying the results of another shader,
 * it cannot be opaque.
 */

        LxResult
CelMaterial::cmt_SetOpaque (
        int			*opaque)
{
        *opaque = 0;

        return LXe_OK;
}

/*
 * Set custom material values at a spot
 */
        void
CelMaterial::cmt_MaterialEvaluate (
        ILxUnknownID            vector,
        void			*data)
{
        RendData*       	 rd = (RendData*)data;
}

/*
 * Evaluate the color at a spot.
 */
        void
CelMaterial::cmt_ShaderEvaluate (
        ILxUnknownID            vector,
        ILxUnknownID		rayObj,
        LXpShadeComponents     *sCmp,
        LXpShadeOutput         *sOut,
        void                    *data)
{
        RendData		*rd   = (RendData *) data;

        /*
         * Quantize each component with the bands and level settings
         */
                
        if (rd->diffBands) 
                FVectorQuantize (sCmp->diff, rd->diffBands, rd->diffLevel);
        if (rd->specBands) 
                FVectorQuantize (sCmp->spec, rd->specBands, rd->specLevel);
        if (rd->reflBands) 
                FVectorQuantize (sCmp->refl, rd->reflBands, rd->reflLevel);

        // Update final output color		
        for (int i = 0; i < 3; i++) 
                sOut->color[i] = sCmp->diff[i] + sCmp->spec[i] + sCmp->refl[i] + sCmp->tran[i] + sCmp->subs[i] + sCmp->lumi[i];
}

/*
 * Utility to get the type code for this item type, as needed.
 */
        LXtItemType
CelMaterial::MyType ()
{
        if (my_type != LXiTYPE_NONE)
                return my_type;

        CLxUser_SceneService	 svc;

        my_type = svc.ItemType (SRVs_CEL_MATR_ITEMTYPE);
        return my_type;
}

        void
initialize ()
{
    CLxGenericPolymorph*    srv1 = new CLxPolymorph<CelMaterial>;

    srv1->AddInterface (new CLxIfc_CustomMaterial<CelMaterial>);
    srv1->AddInterface (new CLxIfc_StaticDesc<CelMaterial>);
    lx::AddServer (SRVs_CEL_MATR, srv1);
}

