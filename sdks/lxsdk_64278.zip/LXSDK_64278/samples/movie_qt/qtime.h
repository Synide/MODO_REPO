/*
 * Plug-in QuickTime saver for movies.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef QTMOVIE
#define QTMOVIE

#include <lxresult.h>
#include <lxmedia.h>

typedef struct st_QTMovie	*QTMovieID;

#define QTf_NONE		 0

/*
 * @return LXe_NOTAVAILABLE QuickTime is not installed (only on non-Mac platforms)
 *         LXe_OK QuickTime is available
 */
        extern LxResult
QTInitialize ();

        extern void
QTTerminate ();

/*
 * Movies are created with the following function.  It creates the movie file
 * and opens it for writing.  It take the FULL path to the new movie file and
 * a flags field as its arguements.  X and Y specify the size of the movie.
 * For now, all movies will be 30fps.  Pass QTf_NONE for flags.  All movies
 * are highest quality mp4 for now.
 */
        extern QTMovieID
QTMovieCreate (
        const char		*fname,
        int			 w,
        int			 h,
        int			 flags);
        
/*
 * The default framerate of 15 fps can be overridden with following call
 */
        extern void
QTMovieSetFramerate (
        QTMovieID		 qtMovie,
        int			 frate);

/*
 * We store frames a single line at a time.  As such, we must first "begin" the
 * frame.  Then we repeatedly add single horizontal lines and finally close the 
 * frame when we're done with it.
 */
        extern void
QTMovieBeginFrame (
        QTMovieID		 qtMovie);
        
/*
 * The caller passes in a buffer big enough to hold a line of the image (3 bytes per
 * pixel) along with the index of the row (0 is top of image, image->h - 1 is bottom)
 */	
        
        extern void
QTMovieAddLineToFrame (
        QTMovieID		 qtMovie,
        unsigned char		*rowBytes,
        int			 row);
        
        extern int
QTMovieEndFrame (
        QTMovieID		 qtMovie);

/* 
 * After all images have been added to the movie, the following function closes
 * it and flattens the movie.
 */
        extern void
QTMovieClose (
        QTMovieID		 qtMovie);

/*
 * Add audio track as option. This must be called before MovieClose.
 */
        extern void
QTMovieAddAudio (
        QTMovieID		 qtMovie,
        ILxAudioID		 audio);
        
#endif /* QTMOVIE */

