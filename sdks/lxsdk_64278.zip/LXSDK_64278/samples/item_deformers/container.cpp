/*
 * CONTAINER.CPP	Container Influence
 *
 *	Copyright (c) 2008-2013 Luxology LLC
 *	
 *	Permission is hereby granted, free of charge, to any person obtaining a
 *	copy of this software and associated documentation files (the "Software"),
 *	to deal in the Software without restriction, including without limitation
 *	the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *	and/or sell copies of the Software, and to permit persons to whom the
 *	Software is furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in
 *	all copies or substantial portions of the Software.   Except as contained
 *	in this notice, the name(s) of the above copyright holders shall not be
 *	used in advertising or otherwise to promote the sale, use or other dealings
 *	in this Software without prior written authorization.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *	DEALINGS IN THE SOFTWARE.
 */
#include <lx_deform.hpp>
#include <lx_package.hpp>
#include <lx_plugin.hpp>
#include <lx_layer.hpp>
#include <lx_vmodel.hpp>
#include <lx_listener.hpp>
#include <lx_thread.hpp>
#include <lx_undo.hpp>
#include <lx_io.hpp>
#include <lxu_deform.hpp>
#include <lxu_modifier.hpp>
#include <lxu_command.hpp>
#include <lxu_select.hpp>
#include <lxu_math.hpp>
#include <lxidef.h>
#include <vector>
#include <map>
#include <math.h>


        namespace Influence_Container {	// disambiguate everything with a namespace

#define SRVNAME_ITEMTYPE		LXsITYPE_WEIGHTCONTAINER
#define SRVNAME_MODIFIER		LXsITYPE_WEIGHTCONTAINER
#define SPWNAME_INSTANCE		"cont.inst"
#define SPWNAME_DEFORMER		"cont.deform"
#define SRVNAME_VALUE			"wcWeightMap"
#define EXONAME_VALUE			"+" SRVNAME_VALUE
#define CMDNAME_ELEMENTS		"weightCont.elements"
#define CMDNAME_CREATE			"weightCont.create"
#define CMDNAME_CLEAR			"weightCont.clear"
#define CMDNAME_ITEMWEIGHT		"weightCont.itemWeight"

#define Cs_MESHINF		LXsICHAN_WEIGHTCONTAINER_INFLUENCE
#define Cs_WEIGHTMAP		LXsICHAN_WEIGHTCONTAINER_WEIGHTMAP
#define Cs_ENABLE		LXsICHAN_WEIGHTCONTAINER_ENABLE

static CLxItemType		mesh_itemtype (LXsITYPE_MESH);
static CLxItemType		container_itemtype (SRVNAME_ITEMTYPE);
static CLxItemType		locator_itemtype (LXsITYPE_LOCATOR);


/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
typedef std::vector<std::string>::iterator	 MeshList_Itr;

class CMeshList :
                public std::vector<std::string>
{
    public:
        CLxUser_Item		 m_item;
        CLxUser_Scene		 m_scene;

        void		Build   (ILxUnknownID);
        void		ByIndex (unsigned, CLxUser_Item &);
        bool		Compare (CMeshList &);

        static void	MapName (CLxUser_Item &item, std::string &name)
        {
                LXtObjectID		 obj;
                const char		*id;

                while (LXx_OK (item.Reference (&obj)))
                        item.take (obj);

                item.Ident (&id);
                name = id;
                name = LXsVMAP_ITEMPREFIX + name;
        }

        static bool	HasPoints (CLxUser_Item &item);
};

class CPackage;

class CInstance :
                public CLxImpl_PackageInstance,
                public CLxImpl_MeshInfluence,
                public CLxImpl_ItemInfluence,
                public CLxImpl_WeightMapDeformerItem,
                public CLxImpl_ViewItem3D,
                public CLxImpl_SceneItemListener
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CInstance>;
                srv->AddInterface (new CLxIfc_PackageInstance      <CInstance>);
                srv->AddInterface (new CLxIfc_MeshInfluence        <CInstance>);
                srv->AddInterface (new CLxIfc_ItemInfluence        <CInstance>);
                srv->AddInterface (new CLxIfc_WeightMapDeformerItem<CInstance>);
                srv->AddInterface (new CLxIfc_ViewItem3D           <CInstance>);
                srv->AddInterface (new CLxIfc_SceneItemListener    <CInstance>);
                lx::AddSpawner (SPWNAME_INSTANCE, srv);
        }

        ILxUnknownID	 self_obj;
        CLxUser_Item	 m_item;
        CMeshList	 mesh_list;
        const char	*enum_id;
        bool		 is_alive;

        LxResult	 pins_Initialize (ILxUnknownID item, ILxUnknownID super)	LXx_OVERRIDE;
        LxResult	 pins_Newborn (ILxUnknownID original)			LXx_OVERRIDE;
        void		 pins_Cleanup (void)					LXx_OVERRIDE;

        unsigned	 minf_MeshCount (void)					LXx_OVERRIDE;
        LxResult	 minf_MeshByIndex (unsigned index, void **ppvObj)	LXx_OVERRIDE;
        unsigned	 minf_PartitionIndex (unsigned index)			LXx_OVERRIDE;

        LxResult	 iinf_HasItems (void)					LXx_OVERRIDE;
        LxResult	 iinf_Enumerate (ILxUnknownID visitor)			LXx_OVERRIDE;
        LxResult	 iinf_GetItem (void **ppvObj)				LXx_OVERRIDE;

        void		 sil_ItemRemove (ILxUnknownID)				LXx_OVERRIDE;
        void		 sil_ItemAdd (ILxUnknownID)				LXx_OVERRIDE;

        LxResult	 wmd_GetMapName (ILxUnknownID cr, char *, unsigned)	LXx_OVERRIDE;

        LxResult	 vitm_Draw (
                                ILxUnknownID	 itemChanRead,
                                ILxUnknownID	 viewStrokeDraw,
                                int		 selectionFlags,
                                LXtVector	 itemColor)			LXx_OVERRIDE;
};

class CPackage :
                public CLxImpl_Package
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CPackage>;
                srv->AddInterface (new CLxIfc_Package   <CPackage>);
                srv->AddInterface (new CLxIfc_StaticDesc<CPackage>);
                lx::AddServer (SRVNAME_ITEMTYPE, srv);
        }

        static LXtTagInfoDesc	 descInfo[];
        CLxSpawner<CInstance>	 inst_spawn;

        CPackage () : inst_spawn (SPWNAME_INSTANCE) {}

        LxResult	 pkg_SetupChannels (ILxUnknownID addChan)	LXx_OVERRIDE;
        LxResult	 pkg_TestInterface (const LXtGUID *guid)	LXx_OVERRIDE;
        LxResult	 pkg_Attach (void **ppvObj)			LXx_OVERRIDE;
        LxResult	 pkg_PostLoad (ILxUnknownID sceneObj)		LXx_OVERRIDE;
};


/*
 * ----------------------------------------------------------------
 * Mesh List
 */

/*
 * Build the list of meshes. Scan meshes linked by deformer craph and
 * include any that have a weight map with the same name as this item's
 * ident plus a prefix.
 */
        void
CMeshList::Build (
        ILxUnknownID		 unk)
{
        CLxUser_ChannelRead	 read;
        CLxUser_ItemGraph	 graph;
        CLxUser_Item		 meshItem;
        CLxUser_Mesh		 mesh;
        CLxUser_MeshMap		 map;
        std::string		 name;
        const char		*id;
        unsigned		 i, n;

        clear ();

        m_item.set (unk);
        m_scene.from (m_item);
        m_scene.GetChannels (read, LXs_ACTIONLAYER_EDIT);

        graph.from (m_scene, LXsGRAPH_DEFORMERS);
        MapName (m_item, name);

        n = graph.Forward (m_item);
        for (i = 0; i < n; i++) {
                graph.Forward (m_item, i, meshItem);
                if (!meshItem.IsA (mesh_itemtype))
                        continue;

                read.Object (meshItem, LXsICHAN_MESH_MESH, mesh);
                map.fromMesh (mesh);
                if (map.SelectByName (LXi_VMAP_WEIGHT, name.c_str()) == LXe_OK) {
                        meshItem.Ident (&id);
                        push_back (id);
                }
        }
}

        bool
CMeshList::Compare (
        CMeshList		&that)
{
        MeshList_Itr		 mli1, mli2;

        mli1 = begin ();
        mli2 = that.begin ();

        while (mli1 != end () && mli2 != that.end ()) {
                if (mli1->compare (*mli2))
                        return false;

                mli1++;
                mli2++;
        }

        return (mli1 == end () && mli2 == that.end ());
}

        void
CMeshList::ByIndex (
        unsigned		 index,
        CLxUser_Item		&item)
{
        m_scene.GetItem (at (index) . c_str (), item);
}

        bool
CMeshList::HasPoints (
        CLxUser_Item		&item)
{
        CMeshList		 list;

        list.Build (item);
        return !list.empty ();
}


/*
 * ----------------------------------------------------------------
 * Value Class
 *
 * We need to store some instance data, which we'll do in a custom value.
 * This is a server with a Value interface as primary, and a StreamIO
 * interface for saving and loading from the LXO file.
 */

class CMapValue :
                public std::map<std::string,float>,
                public CLxImpl_Value,
                public CLxImpl_StreamIO
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CMapValue>;
                srv->AddInterface (new CLxIfc_Value   <CMapValue>);
                srv->AddInterface (new CLxIfc_StreamIO<CMapValue>);
                lx::AddServer (SRVNAME_VALUE, srv);
        }

        typedef std::map<std::string,float>::iterator	 Itr;
        class Elt {
            public:
                LXtDeformElt	 itemElt;
                float		 weight;
        };
        typedef std::map<LXtDeformElt,Elt>		 ItemList;
        typedef std::map<LXtDeformElt,Elt>::iterator	 ItemList_Itr;

        /*
         * Required "Value" interfaces.
         */
                unsigned
        val_Type ()
        {
                return LXi_TYPE_OBJECT;
        }

                LxResult
        val_Copy (
                ILxUnknownID		 from)
        {
                CMapValue		*vp;

                lx::CastServer (SRVNAME_VALUE, from, vp);
                *this = *vp;
                return LXe_OK;
        }

        /*
         * File I/O. Data is written as string/value pairs. Reading reads a string
         * and then a value. If the string read returns false we know we've hit the end.
         */
                LxResult
        io_Write (
                ILxUnknownID		 stream)
        {
                CLxUser_BlockWrite	 write (stream);
                Itr			 it;

                for (it = begin (); it != end (); it++) {
                        write.Write (it->first);
                        write.Write (it->second);
                }

                return LXe_OK;
        }

                LxResult
        io_Read (
                ILxUnknownID		 stream)
        {
                CLxUser_BlockRead	 read (stream);
                std::string		 buf;
                float			 weight;

                while (1) {
                        if (!read.Read (buf, false))
                                break;

                        read.Read (&weight);

                        (*this)[buf] = weight;
                }
                return LXe_OK;
        }

        /*
         * Update on import has to try to translate the iten idents stored in the
         * value to the new ones assigned to the imported items. Since I don't know
         * how much we can safely manipulate the map, we create a tmp map with the
         * new assignments and copy that when done.
         */
                void
        UpdateImport (
                CLxUser_Scene		&scene)
        {
                CLxUser_Item			other;
                std::map<std::string,float>	tmp;
                Itr				it;

                for (it = begin (); it != end (); it++) {
                        if (scene.GetImportedItem (it->first.c_str(), other))
                                tmp[other.IdentPtr ()] = it->second;
                        else
                                tmp[it->first] = it->second;
                }

                clear ();
                for (it = tmp.begin (); it != tmp.end (); it++)
                        (*this) [it->first] = it->second;
        }

        /*
         * This static function gets a value from an item. We just look up the
         * weight map channel and cast to C++. For editing we get channel values
         * from the setup action.
         */
                static CMapValue *
        FromItem (
                CLxUser_Item		&item,
                bool			 write = false)
        {
                CLxUser_Value		 val;

                if (!item.IsA (container_itemtype))
                        return 0;

                if (write) {
                        CLxUser_ChannelWrite	 edit;

                        edit.setupFrom (item);
                        edit.Object (item, Cs_WEIGHTMAP, val);
                } else {
                        CLxUser_ChannelRead	 read;

                        read.from (item);
                        read.Object (item, Cs_WEIGHTMAP, val);
                        if (!val.test ())
                                return 0;
                }

                CMapValue		*vp;

                lx::CastServer (SRVNAME_VALUE, val, vp);
                return vp;
        }

        /*
         * Test if a given item has any mapped items.
         */
                static bool
        HasItems (
                CLxUser_Item		&item)
        {
                CMapValue		*map;

                map = CMapValue::FromItem (item);
                return (map && !map->empty ());
        }

        /*
         * Given a specific item for context, this gets the list of items and
         * their weights. We sort based on DeformElt pointer for fast lookup.
         */
                void
        GetList (
                CLxUser_Item		&item,
                ItemList		&list)
        {
                CLxUser_DeformerService	 dS;
                CLxUser_Scene		 scene (item);
                CLxUser_Item		 loc;
                Elt			 elt;
                Itr			 it;

                for (it = begin (); it != end (); it++) {
                        scene.GetItem (it->first.c_str (), loc);
                        if (loc.test ()) {
                                elt.itemElt = dS.ItemToDeformElt (loc);
                                elt.weight  = it->second;
                                list[elt.itemElt] = elt;
                        }
                }
        }

        /*
         * This can also get the list in straight item format.
         */
                void
        GetList (
                CLxUser_Item		   &item,
                CLxItemSelection::ItemList &list)
        {
                CLxUser_Scene		 scene (item);
                CLxUser_Item		 loc;
                Itr			 it;

                for (it = begin (); it != end (); it++) {
                        scene.GetItem (it->first.c_str (), loc);
                        if (loc.test ())
                                list.push_back (loc);
                }
        }

        /*
         * Test an item for membership in the map.
         */
                bool
        TestItem (
                CLxUser_Item		&item)
        {
                std::string		 str (item.IdentPtr ());

                return (find (str) != end ());
        }
};

class CMapValueUndo :
                public CLxImpl_Undo
{
    public:
        typedef enum en_mode {
                ADD,
                REMOVE,
                VALUE
        }		 Mode;

        CMapValue	*map_ptr;
        CLxUser_Scene	 s_scene;
        std::string	 ident_str;
        float		 f_weight;
        Mode		 act_mode;

        /*
         * Anything that changes this value has to invaldate any cached state
         * that depends on it. Specifically the modifier and the target list.
         */
                static void
        Invalidate (
                CLxUser_Scene		&scene)
        {
                CLxUser_DeformerService	 dsrv;

                scene.EvalModInvalidate (SRVNAME_MODIFIER);
                dsrv.InvalidateTargets (scene);
        }

                void
        undo_Forward ()		LXx_OVERRIDE
        {
                if (act_mode == ADD) {
                        (*map_ptr)[ident_str] = f_weight;
                        act_mode = REMOVE;

                } else if (act_mode == REMOVE) {
                        map_ptr->erase (ident_str);
                        act_mode = ADD;

                } else {
                        float t = (*map_ptr)[ident_str];
                        (*map_ptr)[ident_str] = f_weight;
                        f_weight = t;
                }

                Invalidate (s_scene);
        }

                void
        undo_Reverse ()		LXx_OVERRIDE
        {
                undo_Forward ();
        }

                static 	void
        Apply (
                CMapValue		*map,
                CLxUser_Item		&item,
                Mode			 mode,
                float			 weight = -1.0)
        {
                CLxSpawnerCreate<CMapValueUndo> sp ("mapValueUndoObject");

                if (sp.created)
                        sp.AddInterface (new CLxIfc_Undo<CMapValueUndo>);

                CLxUser_UndoService	 svc;
                CMapValueUndo		*undo;
                ILxUnknownID		 obj;

                undo = sp.spawn->Alloc (obj);
                undo->s_scene.from (item);
                undo->map_ptr   = map;
                undo->ident_str = item.IdentPtr ();
                undo->act_mode  = mode;

                if (mode == REMOVE)
                        undo->f_weight = (*map)[undo->ident_str];
                else
                        undo->f_weight = weight;

                svc.Apply (obj);
        }
};


/*
 * ----------------------------------------------------------------
 * Package Class
 *
 * Packages implement item types, or simple item extensions. They are
 * like the metatype object for the item type. They define the common
 * set of channels for the item type and spawn new instances.
 */
LXtTagInfoDesc	 CPackage::descInfo[] = {
        { LXsPKG_SUPERTYPE,		LXsITYPE_LOCATOR	},
        { 0 }
};

        LxResult
CPackage::pkg_SetupChannels (
        ILxUnknownID		 addChan)
{
        CLxUser_AddChannel	 ac (addChan);

        ac.NewChannel  (Cs_MESHINF,	LXsTYPE_OBJREF);
        ac.SetInternal ();

        ac.NewChannel  (Cs_WEIGHTMAP,	EXONAME_VALUE);
        ac.SetStorage  (EXONAME_VALUE);
        ac.SetInternal ();

        ac.NewChannel  (Cs_ENABLE,	LXsTYPE_BOOLEAN);
        ac.SetDefault  (0.0, 1);

        return LXe_OK;
}

/*
 * TestInterface() is required so that nexus knows what interfaces instance
 * of this package support. Necessary to prevent query loops.
 */
        LxResult
CPackage::pkg_TestInterface (
        const LXtGUID		*guid)
{
        return inst_spawn.TestInterfaceRC (guid);
}

/*
 * Attach is called to create a new instance of this item. The returned
 * object implements a specific item of this type in the scene.
 */
        LxResult
CPackage::pkg_Attach (
        void		       **ppvObj)
{
        CInstance		*inst = inst_spawn.Alloc (ppvObj);

        inst->self_obj = (ILxUnknownID) ppvObj[0];
        return LXe_OK;
}

        LxResult
CPackage::pkg_PostLoad (
        ILxUnknownID		 sceneObj)
{
        CLxUser_Scene		 scene (sceneObj);
        CLxUser_Item		 wc;
        CMapValue		*map;
        unsigned		 i, n;

        n = scene.NItems (container_itemtype);
        for (i = 0; i < n; i++) {
                scene.GetItem (container_itemtype, i, wc);
                if (wc.WasLoaded (LXfITEMLOAD_IMPORT) != LXe_TRUE)
                        continue;

                map = CMapValue::FromItem (wc);
                map->UpdateImport (scene);
        }

        return LXe_OK;
}


/*
 * The instance is the implementation of the item, and there will be one
 * allocated for each item in the scene. It can respond to a set of
 * events.
 */
        LxResult
CInstance::pins_Initialize (
        ILxUnknownID		 item,
        ILxUnknownID		 super)
{
        m_item.set (item);
        is_alive = true;

        CLxUser_Scene		 scene (m_item);
        CLxUser_ListenerPort	 port (scene);

        port.AddListener (self_obj);
        return LXe_OK;
}

        LxResult
CInstance::pins_Newborn (
        ILxUnknownID		 original)
{
        CMapValue::FromItem (m_item, true);
        return LXe_OK;
}

        void
CInstance::pins_Cleanup (void)
{
        CLxUser_Scene		 scene (m_item);
        CLxUser_ListenerPort	 port (scene);

        port.RemoveListener (self_obj);
        m_item.clear ();
}

        unsigned
CInstance::minf_MeshCount ()
{
        mesh_list.Build (m_item);
        return mesh_list.size ();
}

        LxResult
CInstance::minf_MeshByIndex (
        unsigned		 index,
        void		       **ppvObj)
{
        CLxUser_Item		 item;

        mesh_list.ByIndex (index, item);
        return item.get (ppvObj);
}

        unsigned
CInstance::minf_PartitionIndex (
        unsigned		 index)
{
        return index + (iinf_HasItems () == LXe_TRUE ? 1 : 0);
}


        LxResult
CInstance::iinf_HasItems ()
{
        return CMapValue::HasItems (m_item) ? LXe_TRUE : LXe_FALSE;
}

        LxResult
CInstance::iinf_Enumerate (
        ILxUnknownID		 visitor)
{
        CMapValue		*map = CMapValue::FromItem (m_item);

        if (!map)
                return LXe_OK;

        CMapValue::Itr		 mit;
        CLxUser_Visitor		 vis (visitor);
        LxResult		 rc;

        for (mit = map->begin (); mit != map->end (); mit ++) {
                enum_id = mit->first.c_str ();
                rc = vis.Evaluate ();
                if (rc != LXe_OK)
                        return rc;
        }
        return LXe_OK;
}

        LxResult
CInstance::iinf_GetItem (
        void		       **ppvObj)
{
        CLxUser_Scene		 scene (m_item);
        CLxUser_Item		 item;

        scene.GetItem (enum_id, item);
        return item.get (ppvObj);
}

/*
 * Tracking lifecycle turns out to be a bit tricky. We attach our scene item
 * listener for as long as we keep track of the item object. If we see a
 * destroy event for this item we mark it dead, preventing any attempt to read
 * the action. If this is a different item being deleted we check to see if
 * it's part of the data for this item and remove it.
 */
        void
CInstance::sil_ItemRemove (
        ILxUnknownID		 itemObj)
{
        CLxUser_Item		 item (itemObj);

        if (item == m_item)
                is_alive = false;

        if (!is_alive)
                return;

        CMapValue		*map = CMapValue::FromItem (m_item);

        if (!map)
                return;

        std::string		 id (item.IdentPtr ());

        if (map->find (id) == map->end ())
                return;

        CLxUser_UndoService	 undoSvc;

        if (undoSvc.State () != LXiUNDO_ACTIVE)
                return;

        map = CMapValue::FromItem (m_item, true);
        CMapValueUndo::Apply (map, item, CMapValueUndo::REMOVE);
}

/*
 * Item add checks for a dead item being re-added (on undo) and reanimates it.
 */
        void
CInstance::sil_ItemAdd (
        ILxUnknownID		 itemObj)
{
        CLxUser_Item		 item (itemObj);

        if (item == m_item)
                is_alive = true;
}


        LxResult
CInstance::wmd_GetMapName (
        ILxUnknownID		 cr,
        char			*buf,
        unsigned		 len)
{
        std::string		 str;

        CMeshList::MapName (m_item, str);
        return lx::StringOut (str, buf, len);
}

        LxResult
CInstance::vitm_Draw (
        ILxUnknownID		 itemChanRead,
        ILxUnknownID		 viewStrokeDraw,
        int			 selectionFlags,
        LXtVector		 itemColor)
{
        return LXe_OK;
}


/*
 * The influence controls the deformation.
 */
class CDeformer :
                public CLxImpl_Deformer,
                public CLxImpl_MeshInfluence,
                public CLxImpl_ItemInfluence
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CDeformer>;
                srv->AddInterface (new CLxIfc_Deformer     <CDeformer>);
                srv->AddInterface (new CLxIfc_MeshInfluence<CDeformer>);
                srv->AddInterface (new CLxIfc_ItemInfluence<CDeformer>);
                lx::AddSpawner (SPWNAME_DEFORMER, srv);
        }

        class Partition {
            public:
                CLxUser_Mesh	 mesh;
                int		 unused;
        };
        CLxUser_ThreadMutex	 mux_point;

                         CDeformer ();
                        ~CDeformer ();

        void		 Init (CLxUser_Item &item, CLxUser_Value &map, int);

        LxResult	 minf_SetMesh (unsigned index, ILxUnknownID mesh, ILxUnknownID item)	LXx_OVERRIDE;
        LxResult	 minf_SetTransform (unsigned index, LXtMatrix4 xfrm)	LXx_OVERRIDE;
        LxResult	 minf_MeshChange (unsigned index, LxResult change)	LXx_OVERRIDE;

        LxResult	 iinf_AllowTransform (unsigned index, unsigned *flags)	LXx_OVERRIDE;

        unsigned	 dinf_Flags (void)					LXx_OVERRIDE;
        unsigned	 dinf_PartitionCount (void)				LXx_OVERRIDE;
        LxResult	 dinf_EnumeratePartition (ILxUnknownID visitor, unsigned part)	LXx_OVERRIDE;
        LXtDeformElt	 dinf_Element (unsigned *)				LXx_OVERRIDE;
        LxResult	 dinf_SetPartition (unsigned part)			LXx_OVERRIDE;
        float		 dinf_Weight (LXtDeformElt elt, const LXtFVector pos)	LXx_OVERRIDE;
        LxResult	 dinf_WeightRun (unsigned segment, const LXtDeformElt *elt, const float **pos, float *weight, unsigned num)	LXx_OVERRIDE;

        CMapValue::ItemList	 l_items;
        std::string		 s_ident;
        Partition		*l_parts;
        int			 n_parts;
        int			 np_items;	// 0 or 1
        unsigned		 ii_flags;

        CLxUser_Point		 cur_point;
        CLxUser_MeshMap		 cur_weight;
        LXtMeshMapID		 cur_wtID;
        int			 cur_part;
        bool			 cur_isItem;
        CMapValue::ItemList_Itr	 cur_iitr;
};

CDeformer::CDeformer ()
{
        CLxUser_ThreadService	 tS;

        tS.NewCritSec (mux_point);
}

        void
CDeformer::Init (
        CLxUser_Item		&item,
        CLxUser_Value		&map,
        int			 num)
{
        CMapValue		*mp;

        if (map.test ()) {
                lx::CastServer (SRVNAME_VALUE, map, mp);
                mp->GetList (item, l_items);
                np_items = (l_items.empty () ? 0 : 1);
        } else {
                l_items.clear ();
                np_items = 0;
        }

        CMeshList::MapName (item, s_ident);
        n_parts = num;
        l_parts = new Partition [num];

        cur_part = -1;
        ii_flags = ~0;
}

CDeformer::~CDeformer ()
{
        delete[] l_parts;
}

        LxResult
CDeformer::minf_SetMesh (
        unsigned		 index,
        ILxUnknownID		 mesh,
        ILxUnknownID		 item)
{
        if (index >= n_parts)
                return LXe_OUTOFBOUNDS;

        cur_part = -1;
        l_parts[index].mesh.set (mesh);
        return LXe_OK;
}

        LxResult
CDeformer::minf_SetTransform (
        unsigned		 index,
        LXtMatrix4		 xfrm)
{
        if (index >= n_parts)
                return LXe_OUTOFBOUNDS;

        cur_part = -1;
        return LXe_OK;
}

        LxResult
CDeformer::minf_MeshChange (
        unsigned		 index,
        LxResult		 change)
{
        // ignored: no cached state
        return LXe_OK;
}

        LxResult
CDeformer::iinf_AllowTransform (
        unsigned		 index,
        unsigned		*flags)
{
        flags[0] = ii_flags;
        return LXe_OK;
}

        unsigned
CDeformer::dinf_Flags ()
{
        return LXfDEFORMER_NO_OFFSET;
}

        unsigned
CDeformer::dinf_PartitionCount ()
{
        return np_items + n_parts;
}

        LxResult
CDeformer::dinf_SetPartition (
        unsigned		 part)
{
        if (part == cur_part)
                return LXe_OK;

        cur_part = part;
        if (np_items) {
                if (part == 0) {
                        cur_isItem = true;
                        return LXe_OK;
                }

                part--;
        }

        cur_isItem = false;
        cur_point .fromMesh (l_parts[part].mesh);
        cur_weight.fromMesh (l_parts[part].mesh);
        cur_weight.SelectByName (LXi_VMAP_WEIGHT, s_ident.c_str ());
        cur_wtID = cur_weight.ID ();

        return LXe_OK;
}

        LxResult
CDeformer::dinf_EnumeratePartition (
        ILxUnknownID		 visitor,
        unsigned		 part)
{
        dinf_SetPartition (part);

        if (cur_isItem) {
                CLxUser_Visitor	 vis (visitor);
                LxResult	 rc;

                for (cur_iitr = l_items.begin (); cur_iitr != l_items.end (); cur_iitr++) {
                        rc = vis.Evaluate ();
                        if (rc != LXe_OK)
                                return rc;
                }

                return LXe_OK;

        } else {
                if (!cur_wtID)
                        return LXe_OK;

                return cur_weight.EnumerateContinuous (visitor, cur_point);
        }
}

        LXtDeformElt
CDeformer::dinf_Element (
        unsigned		*segment)
{
        segment[0] = 0;
        if (cur_isItem)
                return cur_iitr->second.itemElt;
        else
                return cur_point.ID ();
}

        float
CDeformer::dinf_Weight (
        LXtDeformElt		 elt,
        const LXtFVector	 pos)
{
        if (cur_isItem) {
                CMapValue::ItemList_Itr	 iitr;

                iitr = l_items.find (elt);
                if (iitr == l_items.end ())
                        return 0.0;

                return iitr->second.weight;

        } else {
                float			 w;

                mux_point.Enter ();
                cur_point.Select ((LXtPointID) elt);
                cur_point.MapValue (cur_wtID, &w);
                mux_point.Leave ();
                return w;
        }
}

        LxResult
CDeformer::dinf_WeightRun (
        unsigned		 segment,
        const LXtDeformElt	*elt,
        const float	       **pos,
        float			*weight,
        unsigned		 num)
{
        unsigned		 i;

        if (cur_isItem) {
                CMapValue::ItemList_Itr	 iitr;

                for (i = 0; i < num; i++) {
                        iitr = l_items.find (elt[i]);
                        if (iitr == l_items.end ())
                                weight[i] = 0.0;
                        else
                                weight[i] = iitr->second.weight;
                }

        } else {
                CLxUser_Point		 pt;

                cur_point.duplicate (pt);

                for (i = 0; i < num; i++) {
                        pt.Select ((LXtPointID) elt[i]);
                        pt.MapValue (cur_wtID, &weight[i]);
                }
        }

        return LXe_OK;
}



/*
 * The modifier operates on all items of this type, and sets the mesh influence
 * channel to an object allocated using the input parameters for the modifier.
 * When created we store the list of affected meshes and acess the deformer
 * channel for read/write. If the mesh list changes we ditch this modifier elt
 * and get a new one. Evaluation simply spawns the appropriate object.
 */
class CModifierElement :
                public CLxItemModifierElement
{
    public:
        CLxSpawner<CDeformer>	 spawn;
        CMeshList		 mlist;
        unsigned		 index;

        CModifierElement (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
                        : spawn (SPWNAME_DEFORMER)
        {
                mlist.Build (item);
                index =
                 eval.AddChan (item, Cs_MESHINF,   LXfECHAN_WRITE);
                 eval.AddChan (item, Cs_WEIGHTMAP, LXfECHAN_READ);

                #define AIDx_DEFREF	 (index + 0)
                #define AIDx_WEIGHTMAP	 (index + 1)
        }

                bool
        Test (
                ILxUnknownID		 item)
                                                LXx_OVERRIDE
        {
                CMeshList		 tmp;

                tmp.Build (item);
                return tmp.Compare (mlist);
        }

                void
        Eval (
                CLxUser_Evaluation	&eval,
                CLxUser_Attributes	&attr)
                                                LXx_OVERRIDE
        {
                CDeformer		*infl;
                CLxUser_ValueReference	 ref;
                CLxUser_Value		 map;
                ILxUnknownID		 obj;

                infl = spawn.Alloc (obj);

                attr.ObjectRW (AIDx_DEFREF, ref);
                ref.SetObject (obj);
                lx::UnkRelease (obj);

                attr.ObjectRO (AIDx_WEIGHTMAP, map);
                infl->Init (mlist.m_item, map, mlist.size ());
        }
};

class CModifier :
                public CLxItemModifierServer
{
    public:
                const char *
        ItemType ()
                                                LXx_OVERRIDE
        {
                return SRVNAME_ITEMTYPE;
        }

                const char *
        GraphNames ()
                                                LXx_OVERRIDE
        {
                return LXsGRAPH_DEFORMERS;
        }

                CLxItemModifierElement *
        Alloc (
                CLxUser_Evaluation	&eval,
                ILxUnknownID		 item)
                                                LXx_OVERRIDE
        {
                return new CModifierElement (eval, item);
        }
};



/*
 * --------------------------------------------------------------
 * Set Vertices command, derived from basic command. This uses the selected
 * vertices and creates entries in the weight container's vertex map for them.
 * The initial weight can optionally be specified. It can also remove vertices.
 */
class CSelectLocNotContainer :
                public CLxItemSelection
{
    public:
                bool
        Include (
                CLxUser_Item		&item)
        {
                return item.IsA (locator_itemtype) && !item.IsA (container_itemtype);
        }
};

class CCmdSetVerts :
                public CLxBasicCommand
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CCmdSetVerts>;
                srv->AddInterface (new CLxIfc_Command     <CCmdSetVerts>);
                srv->AddInterface (new CLxIfc_Attributes  <CCmdSetVerts>);
                srv->AddInterface (new CLxIfc_AttributesUI<CCmdSetVerts>);
                lx::AddServer (CMDNAME_ELEMENTS, srv);
        }

        CLxItemSelectionType		 sel_cont;
        CSelectLocNotContainer		 sel_loc;
        CLxVertexSelection		 sel_vert;

                        CCmdSetVerts();

        int		basic_CmdFlags	() LXx_OVERRIDE;
        void		basic_Notifiers	() LXx_OVERRIDE;
        bool		basic_Enable	(CLxUser_Message &msg) LXx_OVERRIDE;
        bool		basic_IconName	(std::string &str) LXx_OVERRIDE;

        void		cmd_Execute	(unsigned int flags) LXx_OVERRIDE;

        void		Vertices (bool);
        void		Items    (bool);
        void		Suffix   (std::string &str);
};

#define ADDVsARG_ADDMODE	 "add"
#define ADDVsARG_ITEMS		 "items"
#define ADDVsARG_WEIGHT		 "weight"

#define ADDViARG_ADDMODE	 0
#define ADDViARG_ITEMS		 1
#define ADDViARG_WEIGHT		 2

CCmdSetVerts::CCmdSetVerts ()
                : sel_cont (SRVNAME_ITEMTYPE)
{
        dyna_Add       (ADDVsARG_ADDMODE, LXsTYPE_BOOLEAN);

        dyna_Add       (ADDVsARG_ITEMS,   LXsTYPE_BOOLEAN);
        basic_SetFlags (ADDViARG_ITEMS,   LXfCMDARG_OPTIONAL);

        dyna_Add       (ADDVsARG_WEIGHT,  LXsTYPE_FLOAT);
        basic_SetFlags (ADDViARG_WEIGHT,  LXfCMDARG_OPTIONAL);
}

        int
CCmdSetVerts::basic_CmdFlags ()
{
        return LXfCMD_MODEL | LXfCMD_UNDO;
}

        void
CCmdSetVerts::basic_Notifiers ()
{
        basic_AddNotify (LXsNOTIFIER_SELECT,	"item +d");
                                                // DISABLE on item selection

        basic_AddNotify (LXsNOTIFIER_SELECT,	"vertex exist+d");
                                                // DISABLE on vertex selection existance

        basic_AddNotify (LXsNOTIFIER_SELECT,	"edge exist+d");
                                                // DISABLE on edge selection existance

        basic_AddNotify (LXsNOTIFIER_SELECT,	"polygon exist+d");
                                                // DISABLE on polygon selection existance

        basic_AddNotify (LXsNOTIFIER_GRAPHS,	LXsGRAPH_DEFORMERS " +d");
                                                // DISABLE on deform graph

        basic_AddNotify (LXsNOTIFIER_CHANNEL,	"+d " Cs_WEIGHTMAP " " SRVNAME_ITEMTYPE);
                                                // DISABLE on map channel
}

        bool
CCmdSetVerts::basic_Enable (
        CLxUser_Message		&msg)
{
        CLxUser_Item		 cont, loc;
        bool			 isItem, isAdd;

        isAdd  = dyna_Bool (ADDViARG_ADDMODE);
        isItem = dyna_Bool (ADDViARG_ITEMS, false);

        for (sel_cont.LoopInit (); sel_cont.LoopNext (cont); ) {
                if (isItem) {
                        if (!sel_loc.GetFirst (loc))
                                continue;

                        if (isAdd)
                                return true;

                        if (!isAdd && CMapValue::HasItems (cont))
                                return true;
                } else {
                        if (!sel_vert.AnyIndirect ())
                                continue;

                        if (isAdd)
                                return true;

                        if (!isAdd && CMeshList::HasPoints (cont))
                                return true;
                }
        }

        std::string		 key = "disable";

        Suffix (key);
        msg.SetMsg (CMDNAME_ELEMENTS, key.c_str ());
        return false;
}

        void
CCmdSetVerts::Suffix (
        std::string		&str)
{
        if (dyna_Bool (ADDViARG_ADDMODE))
                str += ".add";
        else
                str += ".rem";

        if (dyna_Bool (ADDViARG_ITEMS, false))
                str += "I";
        else
                str += "P";
}

        bool
CCmdSetVerts::basic_IconName (
        std::string		&str)
{
        str = CMDNAME_ELEMENTS;
        Suffix (str);
        return true;
}

/*
 * This visitor returns INFO if its Evaluate() gets called at all.
 */
class CFindAnyVisitor :
                public CLxImpl_AbstractVisitor
{
    public:
                LxResult
        Evaluate ()
        {
                return LXe_INFO;
        }
};

/*
 * Combination visitor and layer enumerator, this class serves to process 
 * containers and active meshes.
 */
class CSetVertexVisitor :
                public CLxImpl_AbstractVisitor
{
    public:
        CLxUser_Mesh		 e_mesh;
        CLxUser_Point		 e_vert;
        std::string		 con_id;
        LXtMeshMapID		 map_id;
        float			 map_val;
        bool			 is_add;

        /*
         * For each vertex we first try to access the map. If we're adding we
         * may have to create it, but if we're deleting and it doesn't exist we
         * can skip this whole mesh. It should be possible to pass null for the
         * map value, but we'll pass a dummy one-element array just to be safe.
         */
                LxResult
        Evaluate ()
        {
                if (!map_id) {
                        CLxUser_MeshMap		 mmap;

                        mmap.fromMeshObj (e_mesh);
                        if (mmap.SelectByName (LXi_VMAP_WEIGHT, con_id.c_str()) != LXe_NOTFOUND)
                                map_id = mmap.ID ();
                        else if (is_add)
                                mmap.New (LXi_VMAP_WEIGHT, con_id.c_str(), &map_id);
                        else
                                return LXe_FALSE;
                }

                if (is_add)
                        e_vert.SetMapValue (map_id, &map_val);
                else
                        e_vert.ClearMapValue (map_id);

                return LXe_OK;
        }

        CLxUser_LayerScan	 layer_scan;
        LXtMarkMode		 mode_select;
        CLxUser_ItemGraph	 deform_graph;

        /*
         * Start the scan of active meshes, marking verts based on selection.
         */
                bool
        StartScan ()
        {
                CLxUser_LayerService	 lsrv;
                CLxUser_MeshService	 sMesh;

                mode_select = sMesh.SetMode (LXsMARK_SELECT);
                return lsrv.BeginScan (LXf_LAYERSCAN_EDIT_VERTS, layer_scan);
        }

        /*
         * If we're adding points to the current mesh from the container, add a
         * link from the container to the mesh in the deformers graph, only if
         * there isn't one already.
         */
                void
        AddLink (
                CLxUser_Item		&cont,
                CLxUser_Item		&imesh)
        {
                CLxUser_Item		 fwd;
                unsigned		 i, n;

                n = deform_graph.Forward (cont);
                for (i = 0; i < n; i++) {
                        deform_graph.Forward (cont, i, fwd);
                        if (fwd == imesh)
                                return;
                }

                deform_graph.AddLink (cont, imesh);
        }

        /*
         * If we're removing points from the current mesh we're going to delete
         * the link to this mesh item if the map is empty.
         */
                void
        RemLink (
                CLxUser_Item		&cont,
                CLxUser_Item		&imesh)
        {
                CLxUser_MeshMap		 map;
                CFindAnyVisitor		 vis;

                map.fromMesh (e_mesh);
                map.Select (map_id);
                if (map.EnumContents (&vis, e_vert) == LXe_OK)
                        deform_graph.DeleteLink (cont, imesh);
        }

        /*
         * Apply the selected vertices to the given container item.
         */
                void
        ApplyContainer (
                CLxUser_Item		&cont)
        {
                CLxUser_Scene		 scene;
                CLxUser_Item		 imesh;
                unsigned		 i, n;

                CMeshList::MapName (cont, con_id);

                scene.from (cont);
                deform_graph.from (scene, LXsGRAPH_DEFORMERS);

                n = layer_scan.NumLayers ();
                for (i = 0; i < n; i++) {
                        layer_scan.EditMeshByIndex (i, e_mesh);
                        e_vert.fromMeshObj (e_mesh);

                        map_id = NULL;
                        e_vert.Enum (this, mode_select);
                        if (!map_id)
                                continue;

                        layer_scan.SetMeshChange (i, LXf_MESHEDIT_MAP_OTHER);
                        layer_scan.ItemByIndex (i, imesh);
                        if (is_add)
                                AddLink (cont, imesh);
                        else
                                RemLink (cont, imesh);
                }

                CMapValueUndo::Invalidate (scene);
        }

                void
        EndScan ()
        {
                layer_scan.Apply ();
        }
};

/*
 * The command performs mesh edits by scanning active layers. For each combination
 * of selected weight container and layer, we enumerate the vertices. 
 */
        void
CCmdSetVerts::Vertices (
        bool			 isAdd)
{
        CSetVertexVisitor	 vis;
        CLxUser_Item		 cont;

        vis.is_add  = isAdd;
        vis.map_val = dyna_Float (ADDViARG_WEIGHT, 1.0);
        vis.StartScan ();

        for (sel_cont.LoopInit (); sel_cont.LoopNext (cont); )
                vis.ApplyContainer (cont);

        vis.EndScan ();
}


/*
 * Add/rem items. We scan through the container items and process them all the same.
 * The inner loop is locators so we have to skip our own type.
 */
        void
CCmdSetVerts::Items (
        bool			 isAdd)
{
        CLxUser_Item		 cont, loc;
        CMapValue		*map;
        double			 wt0;

        wt0 = dyna_Float (ADDViARG_WEIGHT, 1.0);

        for (sel_cont.LoopInit (); sel_cont.LoopNext (cont); ) {
                map = CMapValue::FromItem (cont, true);

                for (sel_loc.LoopInit (); sel_loc.LoopNext (loc); )
                        CMapValueUndo::Apply (map, loc,
                                (isAdd ? CMapValueUndo::ADD : CMapValueUndo::REMOVE), wt0);
        }
}

/*
 * Main execution switches on the weighting element type.
 */
        void
CCmdSetVerts::cmd_Execute (
        unsigned		 flags)
{
        bool			 isAdd = dyna_Bool (ADDViARG_ADDMODE);

        if (dyna_Bool (ADDViARG_ITEMS, false))
                Items (isAdd);
        else
                Vertices (isAdd);
}



/*
 * Create command. Create the container and fire the add weights command if
 * possible.
 */
class CCmdCreate
                : public CLxBasicCommand
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CCmdCreate>;
                srv->AddInterface (new CLxIfc_Command     <CCmdCreate>);
                srv->AddInterface (new CLxIfc_Attributes  <CCmdCreate>);
                srv->AddInterface (new CLxIfc_AttributesUI<CCmdCreate>);
                lx::AddServer (CMDNAME_CREATE, srv);
        }

        CLxSceneSelection		 scene_sel;
        CLxItemSelection		 item_sel;

                int
        basic_CmdFlags ()
                                LXx_OVERRIDE
        {
                return LXfCMD_MODEL | LXfCMD_UNDO;
        }

                void
        cmd_Execute (
                unsigned int		 flags)
                                LXx_OVERRIDE
        {
                CLxUser_Scene		 scene;
                CLxUser_Item		 item;
                CLxUser_CommandService	 cmd;
                std::string		 name;

                if (!scene_sel.Get (scene))
                        throw (LXe_NOTFOUND);

                if (!scene.NewItem (container_itemtype, item))
                        throw (LXe_FAILED);

                CLxVertexSelection	 sel_vert;

                if (sel_vert.AnyIndirect ()) {
                        CSetVertexVisitor	 vis;

                        vis.is_add  = true;
                        vis.map_val = 1.0;
                        vis.StartScan ();
                        vis.ApplyContainer (item);
                        vis.EndScan ();
                }

                item_sel.Clear ();
                item_sel.Select (item);
        }
};



/*
 * Clear command. Remove all points and items from selected containers.
 */
class CCmdClear
                : public CLxBasicCommand
{
    public:
                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CCmdClear>;
                srv->AddInterface (new CLxIfc_Command     <CCmdClear>);
                srv->AddInterface (new CLxIfc_Attributes  <CCmdClear>);
                srv->AddInterface (new CLxIfc_AttributesUI<CCmdClear>);
                lx::AddServer (CMDNAME_CLEAR, srv);
        }

        CLxItemSelectionType		 container_sel;
        CLxUser_CommandService		 cmd_S;

        CCmdClear () : container_sel (SRVNAME_ITEMTYPE) {}

                int
        basic_CmdFlags ()
                                LXx_OVERRIDE
        {
                return LXfCMD_MODEL | LXfCMD_UNDO;
        }

                bool
        basic_Enable (
                CLxUser_Message		&msg)
        {
                CLxUser_Item		 item;

                for (container_sel.LoopInit (); container_sel.LoopNext (item); ) {
                        if (CMeshList::HasPoints (item))
                                return true;

                        if (CMapValue::HasItems (item))
                                return true;
                }

                msg.SetMsg (CMDNAME_CLEAR, "disable");
                return false;
        }

                bool
        basic_Notifier (
                int			 index,
                std::string		&name,
                std::string		&args)
        {
                if (index == 0) {
                        name = LXsNOTIFIER_SELECT;
                        args = "item +d";		// DISABLE on item selection
                } else
                        return false;

                return true;
        }

                void
        Clear (
                CLxUser_Item		&wc,
                unsigned int		 flags)
        {
                CLxUser_ItemGraph	 graph;
                CLxUser_Item		 fwd;
                unsigned		 i, n;

                graph.from (wc, LXsGRAPH_DEFORMERS);

                n = graph.Forward (wc);
                for (i = n; i > 0; i--) {
                        graph.Forward (wc, i - 1, fwd);
                        graph.DeleteLink (wc, fwd);
                }

                CMapValue *map = CMapValue::FromItem (wc, true);
                if (map) {
                        CLxItemSelection::ItemList	 sub;
                        CLxItemSelection::ItemList_Itr	 sit;

                        map->GetList (wc, sub);
                        for (sit = sub.begin (); sit != sub.end (); sit++)
                                CMapValueUndo::Apply (map, *sit, CMapValueUndo::REMOVE);
                }

                std::string		 str;

                flags &= ~(LXfCMD_ALERT_SHOWERR | LXfCMD_EXEC_GETARGS);
                CMeshList::MapName (wc, str);
                str = "select.vertexMap " + str + " wght replace";
                cmd_S.ExecuteArgString (flags, LXiCTAG_NULL, str.c_str ());
                cmd_S.ExecuteArgString (flags, LXiCTAG_NULL, "vertMap.delete wght");
        }

                void
        cmd_Execute (
                unsigned int		 flags)
                                LXx_OVERRIDE
        {
                CLxItemSelection::ItemList	 sel;
                CLxItemSelection::ItemList_Itr	 sit;

                container_sel.GetList (sel);

                for (sit = sel.begin (); sit != sel.end (); sit++)
                        Clear (*sit, flags);
        }
};



/*
 * Item weight command. Read and set the item weight.
 */
class CCmdItemWeight
                : public CLxBasicCommand
{
    public:
        #define IWTsARG_WEIGHT	"weight"
        #define IWTiARG_WEIGHT	 0

                static void
        initialize ()
        {
                CLxGenericPolymorph		*srv;

                srv = new CLxPolymorph<CCmdItemWeight>;
                srv->AddInterface (new CLxIfc_Command     <CCmdItemWeight>);
                srv->AddInterface (new CLxIfc_Attributes  <CCmdItemWeight>);
                srv->AddInterface (new CLxIfc_AttributesUI<CCmdItemWeight>);
                lx::AddServer (CMDNAME_ITEMWEIGHT, srv);
        }

        CLxItemSelectionType		 locator_sel, container_sel;
        CLxUser_CommandService		 cmd_S;
        CMapValue			*enum_map;
        CLxUser_Item			 enum_loc;

        CCmdItemWeight ()
                : locator_sel   (LXsITYPE_LOCATOR)
                , container_sel (SRVNAME_ITEMTYPE)
        {
                dyna_Add       (IWTsARG_WEIGHT, LXsTYPE_PERCENT);
                basic_SetFlags (IWTiARG_WEIGHT, LXfCMDARG_QUERY);
        }

                int
        basic_CmdFlags ()
                                LXx_OVERRIDE
        {
                return LXfCMD_MODEL | LXfCMD_UNDO;
        }

                LxResult
        Enumerate (
                CLxImpl_AbstractVisitor	*vis,
                bool			 write = false)
        {
                CLxItemSelection::ItemList	 sel,  loc;
                CLxItemSelection::ItemList_Itr	 sit, lit;
                LxResult			 rc;

                container_sel.GetList (sel);
                locator_sel  .GetList (loc);

                for (sit = sel.begin (); sit != sel.end (); sit++) {
                        enum_map = CMapValue::FromItem (*sit, write);
                        if (!enum_map || enum_map->empty ())
                                continue;

                        for (lit = loc.begin (); lit != loc.end (); lit++)
                                if (enum_map->TestItem (*lit)) {
                                        enum_loc = *lit;
                                        rc = vis->Evaluate ();
                                        if (rc != LXe_OK)
                                                return rc;
                                }
                }

                return LXe_OK;
        }

                bool
        basic_Enable (
                CLxUser_Message		&msg)
        {
                CFindAnyVisitor		 any;

                if (Enumerate (&any) == LXe_INFO)
                        return true;

                msg.SetMsg (CMDNAME_ITEMWEIGHT, "disable");
                return false;
        }

                bool
        basic_Notifier (
                int			 index,
                std::string		&name,
                std::string		&args)
        {
                if (index == 0) {
                        name = LXsNOTIFIER_SELECT;
                        args = "item +d";		// DISABLE on item selection
                } else
                        return false;

                return true;
        }

        class CApplyVisitor :
                        public CLxImpl_AbstractVisitor
        {
            public:
                CCmdItemWeight		*cmd;
                double			 weight;

                        LxResult
                Evaluate ()
                {
                        CMapValueUndo::Apply (cmd->enum_map, cmd->enum_loc, CMapValueUndo::VALUE, weight);
                        return LXe_OK;
                }
        };

                void
        cmd_Execute (
                unsigned int		 flags)
                                LXx_OVERRIDE
        {
                CApplyVisitor		 vis;

                vis.cmd = this;
                attr_GetFlt (IWTiARG_WEIGHT, &vis.weight);

                Enumerate (&vis, true);
        }

        class CQueryVisitor :
                        public CLxImpl_AbstractVisitor
        {
            public:
                CCmdItemWeight		*cmd;
                CLxUser_ValueArray	 va;

                        LxResult
                Evaluate ()
                {
                        std::string	 str (cmd->enum_loc.IdentPtr ());

                        va.AddFloat ((*cmd->enum_map) [str]);
                        return LXe_OK;
                }
        };

                LxResult
        cmd_Query (
                unsigned int		 index,
                ILxUnknownID		 vaQuery)
        {
                CQueryVisitor		 vis;

                vis.cmd = this;
                vis.va.set (vaQuery);

                Enumerate (&vis);
                return LXe_OK;
        }
};



/*
 * Initialize all the object types, spawned and served.
 */
        void
initialize ()
{
        CMapValue::initialize ();
        CPackage ::initialize ();
        CInstance::initialize ();
        CDeformer::initialize ();

        CCmdSetVerts  ::initialize ();
        CCmdCreate    ::initialize ();
        CCmdClear     ::initialize ();
        CCmdItemWeight::initialize ();

        CLxExport_ItemModifierServer<CModifier> (SRVNAME_MODIFIER);
}

        };	// END namespace



