/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_animation.h"
#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_bind.h"
#include "cio_strings.h"
#include "cio_technique.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Animation Channel.
 */

AnimationChannelElement::AnimationChannelElement (
        AnimationElement		&animation,
        const AnimationSamplerElement	&sampler,
        const string			&itemID,
        const string			&targetLibraryElementName,
        const string			&transformID,
        const string			&componentName,
        const string			&axisName,
        bool				 appendAxisToTargetTransformName)
        :
        Element(animation.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                animation.AddAnimationChannel (*this);

                SetAttribute (ATTRIBUTE_SOURCE, URI_Ref (sampler.GetID ()));
                string target;
                if (targetLibraryElementName == string(ELEMENT_NODE)) {
                        target = GetElementParamBind()->GetItemID (
                                targetLibraryElementName, itemID);
                }
                else {
                        target = NodeID (GetElementParamBind()->GetItemID (
                                targetLibraryElementName, itemID));
                }
                target += string(ATTRVALUE_PATHSEPARATORSYMBOL) +
                        TransformID (transformID);
                if (appendAxisToTargetTransformName) {
                        target += axisName;
                }
                target += string(ATTRVALUE_DOTSEPARATORSYMBOL) + componentName;
                SetAttribute (ATTRIBUTE_TARGET, target);
        }
}

AnimationChannelElement::AnimationChannelElement (
        AnimationElement		&animation,
        const AnimationSamplerElement	&sampler,
        const string			&itemID,
        const string			&targetLibraryElementName,
        const string			&paramSID)
        :
        Element(animation.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                animation.AddAnimationChannel (*this);

                SetAttribute (ATTRIBUTE_SOURCE, URI_Ref (sampler.GetID ()));
                string target =
                        GetElementParamBind()->GetItemID (
                                targetLibraryElementName, itemID) +
                        string(ATTRVALUE_PATHSEPARATORSYMBOL) +
                        paramSID;
                SetAttribute (ATTRIBUTE_TARGET, target);
        }
}

AnimationChannelElement::AnimationChannelElement (
        AnimationElement		&animation,
        const AnimationSamplerElement	&sampler,
        const string			&itemID,
        const string			&targetLibraryElementName)
        :
        Element(animation.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                animation.AddAnimationChannel (*this);

                SetAttribute (ATTRIBUTE_SOURCE, URI_Ref (sampler.GetID ()));
                string target;
                if (targetLibraryElementName == string(ELEMENT_NODE)) {
                        target = GetElementParamBind()->GetItemID (
                                targetLibraryElementName, itemID);
                }
                else {
                        target = NodeID (GetElementParamBind()->GetItemID (
                                targetLibraryElementName, itemID));
                }
                target += string(ATTRVALUE_PATHSEPARATORSYMBOL) +
                        string(ATTRVALUE_MATRIX_SID);
                SetAttribute (ATTRIBUTE_TARGET, target);
        }
}

AnimationChannelElement::AnimationChannelElement (
        AnimationElement		&animation)
        :
        Element(animation.PV ())
{
        if (GetIOMode () == IO_MODE_LOAD) {
        }
}

AnimationChannelElement::~AnimationChannelElement ()
{
}

        string
AnimationChannelElement::GetSamplerURI () const
{
        return GetAttribute (ATTRIBUTE_SOURCE);
}

        string
AnimationChannelElement::GetTarget () const
{
        return GetAttribute (ATTRIBUTE_TARGET);
}

        string
AnimationChannelElement::GetTargetNodeID () const
{
        string nodeID = GetTarget ();

        /*
         * Extract the node name to the left of the path separator.                                                         
         */
        return nodeID;
}

        string
AnimationChannelElement::GetTargetParamName () const
{
        string paramName = GetTarget ();

        /*
         * Extract the param name to the right of the path separator.
         */
        return paramName;
}

        bool
AnimationChannelElement::LinkNextChannel (AnimationChannelElement &channel)
{
        return LinkNextSiblingElement (ELEMENT_CHANNEL, channel);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Inputs.
 */

struct pv_AnimationSamplerInputElement
{
        pv_AnimationSamplerInputElement ()
        {
        }

        string		sourceID;
};

AnimationSamplerInputElement::AnimationSamplerInputElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        Element(sampler.PV ()),
        pv(new pv_AnimationSamplerInputElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                sampler.AddAnimationSamplerInput (*this);
                pv->sourceID = source.GetID ();
        }
}

AnimationSamplerInputElement::AnimationSamplerInputElement (
        AnimationSamplerElement	&sampler)
        :
        Element(sampler.PV ()),
        pv(new pv_AnimationSamplerInputElement())
{
}

AnimationSamplerInputElement::~AnimationSamplerInputElement ()
{
        delete pv;
}

        void
AnimationSamplerInputElement::InitializeSemantic ()
{
        SetAttribute (ATTRIBUTE_SEMANTIC, GetSemantic ());
        SetAttribute (ATTRIBUTE_SOURCE, URI_Ref (pv->sourceID));
}

        string
AnimationSamplerInputElement::GetSemantic () const
{
        /*
         * On scene load, we fetch the stored semantic attribute value.
         *
         * On scene save, GetSemantic is overridden by the sample type-
         * specific input, which returns the corresponding semantic value.
         */
        return GetAttribute (ATTRIBUTE_SEMANTIC);
}

        string
AnimationSamplerInputElement::GetSourceURI () const
{
        return GetAttribute (ATTRIBUTE_SOURCE);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Time.
 */

AnimationSamplerInputTimeElement::AnimationSamplerInputTimeElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputTimeElement::~AnimationSamplerInputTimeElement ()
{
}

        string
AnimationSamplerInputTimeElement::GetSemantic () const
{
        return string(ATTRVALUE_TIME_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Output (keyframe values).
 */

AnimationSamplerInputOutputElement::AnimationSamplerInputOutputElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputOutputElement::~AnimationSamplerInputOutputElement ()
{
}

        string
AnimationSamplerInputOutputElement::GetSemantic () const
{
        return string(ATTRVALUE_OUTPUT_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Interpolation (keyframe type).
 */

AnimationSamplerInputInterpolationElement::AnimationSamplerInputInterpolationElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputInterpolationElement::~AnimationSamplerInputInterpolationElement ()
{
}

        string
AnimationSamplerInputInterpolationElement::GetSemantic () const
{
        return string(ATTRVALUE_INTERPOLATION_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for in-tangent (in the common X, Y curve form)
 */

AnimationSamplerInputInTangentElement::AnimationSamplerInputInTangentElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputInTangentElement::~AnimationSamplerInputInTangentElement ()
{
}

        string
AnimationSamplerInputInTangentElement::GetSemantic () const
{
        return string(ATTRVALUE_IN_TANGENT_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for in-tangent output.
 *
 * Used for envelopes that contain one or more keyframes that are broken by value.
 */

AnimationSamplerInputInTangentOutputElement::AnimationSamplerInputInTangentOutputElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputInTangentOutputElement::~AnimationSamplerInputInTangentOutputElement ()
{
}

        string
AnimationSamplerInputInTangentOutputElement::GetSemantic () const
{
        return string(ATTRVALUE_IN_TANGENT_OUTPUT_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for In-Tangent Slope and Weight.
 *
 * Alternative form for describing the envelope shape by direct slope and
 * weight values, instead of by the common cartesian X, Y tangent form.
 */

AnimationSamplerInputInTangentSlopeWeightElement::AnimationSamplerInputInTangentSlopeWeightElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputInTangentSlopeWeightElement::~AnimationSamplerInputInTangentSlopeWeightElement ()
{
}

        string
AnimationSamplerInputInTangentSlopeWeightElement::GetSemantic () const
{
        return string(ATTRVALUE_IN_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for out-tangent (in the common X, Y curve form)
 */

AnimationSamplerInputOutTangentElement::AnimationSamplerInputOutTangentElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputOutTangentElement::~AnimationSamplerInputOutTangentElement ()
{
}

        string
AnimationSamplerInputOutTangentElement::GetSemantic () const
{
        return string(ATTRVALUE_OUT_TANGENT_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for out-tangent output.
 *
 * Used for envelopes that contain one or more keyframes that are broken by value.
 */

AnimationSamplerInputOutTangentOutputElement::AnimationSamplerInputOutTangentOutputElement (
        AnimationSamplerElement	&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputOutTangentOutputElement::~AnimationSamplerInputOutTangentOutputElement ()
{
}

        string
AnimationSamplerInputOutTangentOutputElement::GetSemantic () const
{
        return string(ATTRVALUE_OUT_TANGENT_OUTPUT_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Out-Tangent Slope and Weight.
 *
 * Alternative form for describing the envelope shape by direct slope and
 * weight values, instead of by the common cartesian X, Y tangent form.
 */

AnimationSamplerInputOutTangentSlopeWeightElement::AnimationSamplerInputOutTangentSlopeWeightElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputOutTangentSlopeWeightElement::~AnimationSamplerInputOutTangentSlopeWeightElement ()
{
}

        string
AnimationSamplerInputOutTangentSlopeWeightElement::GetSemantic () const
{
        return string(ATTRVALUE_OUT_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Broken Output flags.
 *
 * For each input time, indicates whether or not the output at that
 * time is broken into separate in- and out-tangent output values.
 */

AnimationSamplerInputBrokenOutputElement::AnimationSamplerInputBrokenOutputElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputBrokenOutputElement::~AnimationSamplerInputBrokenOutputElement ()
{
}

        string
AnimationSamplerInputBrokenOutputElement::GetSemantic () const
{
        return string(ATTRVALUE_BROKEN_OUTPUTS_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Broken Output Times.
 *
 * Specifies the times at which there are broken outputs, where the output
 * value is broken into separate in- and out-tangent values.
 */

AnimationSamplerInputBrokenOutputTimeElement::AnimationSamplerInputBrokenOutputTimeElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputBrokenOutputTimeElement::~AnimationSamplerInputBrokenOutputTimeElement ()
{
}

        string
AnimationSamplerInputBrokenOutputTimeElement::GetSemantic () const
{
        return string(ATTRVALUE_BROKEN_OUTPUT_TIMES_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Broken Slope flags.
 *
 * For each input time, indicates whether or not the slope
 * at that time has broken in- and out-tangent values.
 */

AnimationSamplerInputBrokenSlopeElement::AnimationSamplerInputBrokenSlopeElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputBrokenSlopeElement::~AnimationSamplerInputBrokenSlopeElement ()
{
}

        string
AnimationSamplerInputBrokenSlopeElement::GetSemantic () const
{
        return string(ATTRVALUE_BROKEN_SLOPES_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler Input for Broken Weight flags.
 *
 * For each input time, indicates whether or not the weight
 * at that time has broken in- and out-tangent values.
 */

AnimationSamplerInputBrokenWeightElement::AnimationSamplerInputBrokenWeightElement (
        AnimationSamplerElement		&sampler,
        const AnimationSourceElement	&source)
        :
        AnimationSamplerInputElement(sampler, source)
{
}

AnimationSamplerInputBrokenWeightElement::~AnimationSamplerInputBrokenWeightElement ()
{
}

        string
AnimationSamplerInputBrokenWeightElement::GetSemantic () const
{
        return string(ATTRVALUE_BROKEN_WEIGHTS_INPUT_SEMANTIC);
}

/*
 * ---------------------------------------------------------------------------
 * Animation Sampler.
 */

struct pv_AnimationSamplerElement
{
        pv_AnimationSamplerElement ()
        {
        }
};

AnimationSamplerElement::AnimationSamplerElement (
        AnimationElement	&animation)
        :
        Element(animation.PV ()),
        pv(new pv_AnimationSamplerElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                animation.AddAnimationSampler (*this);

                SetID (animation.GetID () + string(ATTRVALUE_SAMPLERSUFFIX));
        }
}

AnimationSamplerElement::~AnimationSamplerElement ()
{
        delete pv;
}

        bool
AnimationSamplerElement::HasInput () const
{
        return HasChildElement (ELEMENT_INPUT);
}

        bool
AnimationSamplerElement::LinkInput (
        const string			&semantic,
        AnimationSamplerInputElement	&input)
{
        /*
         * Iterate over the this sampler's input elements, looking for
         * a matching semantic attribute value.
         */
        bool	linked(false);
        ElementXML *childElem = GetElementHandle ().FirstChildElement (
                ELEMENT_INPUT).Element ();
        while (childElem) {
                if (GetAttribute (childElem, ATTRIBUTE_SEMANTIC) == semantic) {
                        input.SetElement (childElem);
                        linked = true;
                        break;
                }
                childElem = childElem->NextSiblingElement (ELEMENT_INPUT);
        }

        return linked;

}


        void
AnimationSamplerElement::AddAnimationSamplerInput (
        AnimationSamplerInputElement &input)
{
        input.SetElement (AddElement (ELEMENT_INPUT));
}

/*
 * ---------------------------------------------------------------------------
 * Animation Source.
 */

AnimationSourceElement::AnimationSourceElement (
        AnimationElement	&animation,
        const string		&arrayTypeName)
        :
        SourceElement(animation, arrayTypeName)
{
}

AnimationSourceElement::AnimationSourceElement (
        AnimationElement	&animation)
        :
        SourceElement(animation)
{
}

AnimationSourceElement::~AnimationSourceElement ()
{
}

        bool
AnimationSourceElement::HasArray (
        ArrayType		&type,
        unsigned		&count)
{
        bool	found(false);

        Element	valueArray(*this);
        if (HasChildElement (ELEMENT_FLOAT_ARRAY)) {
                type = ARRAY_TYPE_FLOAT;
        }
        else if (HasChildElement (ELEMENT_INT_ARRAY)) {
                type = ARRAY_TYPE_INT;
        }
        else if (HasChildElement (ELEMENT_BOOL_ARRAY)) {
                type = ARRAY_TYPE_BOOL;
        }
        else if (HasChildElement (ELEMENT_NAME_ARRAY)) {
                ElementXML *techCommElem = GetElementHandle ().FirstChildElement (
                        ELEMENT_TECHNIQUE_COMMON).Element ();
                bool foundInterpOverride(false);
                if (techCommElem) {
                        ElementXML *accessorElem = GetElementHandle ().FirstChildElement (
                                ELEMENT_ACCESSOR).Element ();
                        if (accessorElem) {
                                ElementXML *paramElem = GetElementHandle ().FirstChildElement (
                                        ELEMENT_PARAM).Element ();
                                if (paramElem) {
                                        string paramName = GetAttribute (paramElem, ATTRIBUTE_NAME);
                                        if (paramName == string(ATTRVALUE_INTERPOLATION_INPUT_SEMANTIC)) {
                                                type = ARRAY_TYPE_INTERPOLATION;
                                        }
                                }
                        }
                }
                if (!foundInterpOverride) {
                        type = ARRAY_TYPE_NAME;
                }
        }

        return found;
}

        void
AnimationSourceElement::AddInputArray (
        const FloatArray	&arrayValues)
{
        AddFloatArray (string(ATTRVALUE_TIME), arrayValues);
}

        string
InfinityBehaviorToModoValue (AnimationSourceElement::InfinityBehavior behavior)
{
        string behaviorText;
        switch (behavior) {
                case AnimationSourceElement::INFINITY_BEHAVIOR_STOP:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_STOP;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_LINEAR:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_LINEAR;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_REPEAT:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_REPEAT;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_OSCILLATE:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_OSCILLATE;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_OFFSET_REPEAT:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_OFFSET_REPEAT;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_RESET:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_RESET;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_CONSTANT:
                default:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_CONSTANT;
                        break;
        }

        return behaviorText;
}

        string
InfinityBehaviorToMayaValue (AnimationSourceElement::InfinityBehavior behavior)
{
        string behaviorText;
        switch (behavior) {
                case AnimationSourceElement::INFINITY_BEHAVIOR_LINEAR:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_LINEAR;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_REPEAT:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_CYCLE;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_OSCILLATE:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_OSCILLATE;
                        break;

                case AnimationSourceElement::INFINITY_BEHAVIOR_CONSTANT:
                default:
                        behaviorText = VALUE_INFINITY_BEHAVIOR_CONSTANT;
                        break;
        }

        return behaviorText;
}

        void
AnimationSourceElement::AddInputArray (
        const FloatArray	&arrayValues,
        bool			 saveModoProfile,
        bool			 saveMayaProfile,
        InfinityBehavior	 preInfinityBehavior,
        InfinityBehavior	 postInfinityBehavior)
{
        AddInputArray (arrayValues);

        if (saveModoProfile) {
                ElementXML *technique = AddElement (ELEMENT_TECHNIQUE);
                SetAttribute (technique, ATTRIBUTE_PROFILE, PROFILE_MODO401);

                ElementXML *preInfinity = AddElement (technique, ELEMENT_PRE_INFINITY);
                SetElementValue (preInfinity, InfinityBehaviorToModoValue (preInfinityBehavior));

                ElementXML *postInfinity = AddElement (technique, ELEMENT_POST_INFINITY);
                SetElementValue (postInfinity, InfinityBehaviorToModoValue (postInfinityBehavior));
        }

        if (saveMayaProfile) {
                ElementXML *technique = AddElement (ELEMENT_TECHNIQUE);
                SetAttribute (technique, ATTRIBUTE_PROFILE, PROFILE_MAYA);

                ElementXML *preInfinity = AddElement (technique, ELEMENT_PRE_INFINITY);
                SetElementValue (preInfinity, InfinityBehaviorToMayaValue (preInfinityBehavior));

                ElementXML *postInfinity = AddElement (technique, ELEMENT_POST_INFINITY);
                SetElementValue (postInfinity, InfinityBehaviorToMayaValue (postInfinityBehavior));
        }
}

        void
AnimationSourceElement::AddOutputArray (
        const string		&componentName,
        const FloatArray	&arrayValues)
{
        AddFloatArray (componentName, arrayValues);
}

        void
AnimationSourceElement::AddOutputArray (
        const string			&componentName,
        const math::Matrix4Array	&arrayValues)
{
        AddMatrixArray (componentName, arrayValues);
}

        void
AnimationSourceElement::AddTangentArray (
        const FloatArray	&arrayValuesA,
        const FloatArray	&arrayValuesB)
{
        AddFloatPairArray (
                string(ATTRVALUE_X), string(ATTRVALUE_Y),
                arrayValuesA, arrayValuesB);
}

        bool
AnimationSourceElement::LinkInterpArray (
        InterpArray		&arrayValues)
{
        bool	linked(false);

        ElementXML *interpArray = GetElementHandle ().FirstChildElement (
                ELEMENT_NAME_ARRAY).Element ();
        if (interpArray) {
                unsigned count = GetAttributeUnsigned (interpArray, ATTRIBUTE_COUNT);
                GetElementValue (interpArray, arrayValues);

                /*
                 * The count attribute must match the actual number of values
                 * for the document to be valid.
                 */
                if (arrayValues.size () == count) {
                        linked = true;
                }
        }

        return linked;
}

        void
AnimationSourceElement::AddInterpArray (
        const InterpArray	&arrayValues)
{
        ElementXML *interpArray = AddElement (ELEMENT_NAME_ARRAY);
        string interpArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (interpArray, interpArrayID);
        SetAttribute (interpArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size ());
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (interpArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, 1);

        ElementXML* param = AddElement (accessor, ELEMENT_PARAM);
        SetName (param, ATTRVALUE_INTERPOLATION_INPUT_SEMANTIC);
        SetType (param, ATTRVALUE_NAME);

        SetElementValue (interpArray, arrayValues);
}

        void
AnimationSourceElement::AddSlopeWeightArray (
        const FloatArray	&arrayValuesSlopes,
        const FloatArray	&arrayValuesWeights)
{
        AddFloatPairArray (
                string(ATTRVALUE_SLOPE), string(ATTRVALUE_WEIGHT),
                arrayValuesSlopes, arrayValuesWeights);
}

/*
 * ---------------------------------------------------------------------------
 * AnimationContainer
 */

AnimationContainerElement::AnimationContainerElement (pv_Element	*parentpv)
        :
        Element(parentpv)
{
}

AnimationContainerElement::~AnimationContainerElement ()
{
}

bool
AnimationContainerElement::HasChildAnimation () const
{
        return HasChildElement (ELEMENT_ANIMATION);
}

bool
AnimationContainerElement::LinkFirstChildAnimation (AnimationElement &animation)
{
        return LinkFirstChildElement (ELEMENT_ANIMATION, animation);
}

bool
AnimationContainerElement::LinkAnimation (
        const string		&animationID,
        AnimationElement	&animation)
{
        return LinkFirstChildElement (ELEMENT_ANIMATION, animationID, animation);
}

/*
 * ---------------------------------------------------------------------------
 * Animation.
 */

struct pv_AnimationElement
{
        pv_AnimationElement ()
                :
                // common inputs
                sourceInput(NULL),
                sourceOutput(NULL),
                sourceInterp(NULL),
                sourceInTan(NULL),
                sourceOutTan(NULL),

                // extended modo 501 inputs
                sourceBrokenValues(NULL),
                sourceBrokenValueTimes(NULL),
                sourceBrokenInTanValues(NULL),
                sourceBrokenOutTanValues(NULL),

                sourceInTanSlopeWeights(NULL),
                sourceOutTanSlopeWeights(NULL),
                sourceBrokenSlopes(NULL),
                sourceBrokenWeights(NULL),

                sampler(NULL)
        {
        }

        virtual ~pv_AnimationElement ()
        {
                // common inputs
                delete sourceInput;
                delete sourceOutput;
                delete sourceInterp;
                delete sourceInTan;
                delete sourceOutTan;

                // extended modo 501 inputs
                delete sourceBrokenValues;
                delete sourceBrokenValueTimes;
                delete sourceBrokenInTanValues;
                delete sourceBrokenOutTanValues;

                delete sourceInTanSlopeWeights;
                delete sourceOutTanSlopeWeights;
                delete sourceBrokenSlopes;
                delete sourceBrokenWeights;

                delete sampler;
        }

        /*
         * Common profile sampler source inputs.
         */
        AnimationSourceElement	*sourceInput;
        AnimationSourceElement	*sourceOutput;
        AnimationSourceElement	*sourceInterp;
        AnimationSourceElement	*sourceInTan;
        AnimationSourceElement	*sourceOutTan;

        /*
         * Extended modo 501 profile sampler source inputs.
         */
        AnimationSourceElement	*sourceBrokenValues;		// for each input time
        AnimationSourceElement	*sourceBrokenValueTimes;
        AnimationSourceElement	*sourceBrokenInTanValues;	// only broken values
        AnimationSourceElement	*sourceBrokenOutTanValues;

        /*
         * In- and out-tan slopes and weights, and broken slope
         * and weight flags are stored for each input time.
         */
        AnimationSourceElement	*sourceInTanSlopeWeights;
        AnimationSourceElement	*sourceOutTanSlopeWeights;
        AnimationSourceElement	*sourceBrokenSlopes;
        AnimationSourceElement	*sourceBrokenWeights;

        /*
         * The sampler provides access to the source inputs.
         */
        AnimationSamplerElement	*sampler;
};

AnimationElement::AnimationElement (
        AnimationLibraryElement		&library,
        const string			&animationID,
        const string			&componentName,
        const Envelope	 		&envelope,
        bool				 saveMayaProfile)
        :
        AnimationContainerElement(library.PV ()),
        pv(new pv_AnimationElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddAnimation (*this);

                SetID (animationID);

                /*
                 * Add the input source.
                 */
                pv->sourceInput = new AnimationSourceElement(
                        *this, string(ATTRVALUE_INPUT_SOURCE_NAME));
                if (saveMayaProfile) {
                        pv->sourceInput->AddInputArray (
                                envelope.times,
                                false /* saveModoProfile */,
                                saveMayaProfile,
                                envelope.preInfinityBehavior,
                                envelope.postInfinityBehavior);
                }
                else {
                        pv->sourceInput->AddInputArray (envelope.times);
                }

                /*
                 * Add the output source.
                 */
                pv->sourceOutput = new AnimationSourceElement(
                        *this, string(ATTRVALUE_OUTPUT_SOURCE_NAME));
                pv->sourceOutput->AddOutputArray (componentName, envelope.outputs);

                if (!envelope.inTanControlX.empty ()) {
                        /*
                         * Add the intangents source.
                         */
                        pv->sourceInTan = new AnimationSourceElement(
                                *this, string(ATTRVALUE_INTANGENTS_SOURCE_NAME));
                        pv->sourceInTan->AddTangentArray (
                                envelope.inTanControlX, envelope.inTanControlY);

                        /*
                         * Add the outtangents source.
                         */
                        pv->sourceOutTan = new AnimationSourceElement(
                                *this, string(ATTRVALUE_OUTTANGENTS_SOURCE_NAME));
                        pv->sourceOutTan->AddTangentArray (
                                envelope.outTanControlX, envelope.outTanControlY);
                }

                /*
                 * Add the interpolation source.
                 */
                pv->sourceInterp = new AnimationSourceElement(
                        *this, string(ATTRVALUE_INTERPOLATIONS_SOURCE_NAME));
                pv->sourceInterp->AddInterpArray (envelope.interpolations);

                /*
                 * Add the sampler.
                 */
                pv->sampler = new AnimationSamplerElement(*this);

                AnimationSamplerInputTimeElement		samplerInputTime(
                        *(pv->sampler), *(pv->sourceInput));
                samplerInputTime.InitializeSemantic ();

                AnimationSamplerInputOutputElement		samplerInputOutput(
                        *(pv->sampler), *(pv->sourceOutput));
                samplerInputOutput.InitializeSemantic ();

                AnimationSamplerInputInterpolationElement	samplerInputInterpolation(
                        *(pv->sampler), *(pv->sourceInterp));
                samplerInputInterpolation.InitializeSemantic ();

                if (!envelope.inTanControlX.empty ()) {
                        AnimationSamplerInputInTangentElement	samplerInputInTangent(
                                *(pv->sampler), *(pv->sourceInTan));
                        samplerInputInTangent.InitializeSemantic ();

                        AnimationSamplerInputOutTangentElement	samplerInputOutTangent(
                                *(pv->sampler), *(pv->sourceOutTan));
                        samplerInputOutTangent.InitializeSemantic ();
                }
        }
}

AnimationElement::AnimationElement (
        AnimationLibraryElement		&library,
        const string			&animationID,
        const string			&componentName,
        const Envelope	 		&envelope,
        const Envelope_modo501		&modoEnvelope,
        bool				 saveMayaProfile)
        :
        AnimationContainerElement(library.PV ()),
        pv(new pv_AnimationElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddAnimation (*this);

                SetID (animationID);

                /*
                 * Add the input source.
                 */
                pv->sourceInput = new AnimationSourceElement(
                        *this, string(ATTRVALUE_INPUT_SOURCE_NAME));
                pv->sourceInput->AddInputArray (
                                envelope.times,
                                true /* saveModoProfile */,
                                saveMayaProfile,
                                envelope.preInfinityBehavior,
                                envelope.postInfinityBehavior);

                /*
                 * Add the output source.
                 */
                pv->sourceOutput = new AnimationSourceElement(
                        *this, string(ATTRVALUE_OUTPUT_SOURCE_NAME));
                pv->sourceOutput->AddOutputArray (componentName, envelope.outputs);

                if (!envelope.inTanControlX.empty ()) {
                        /*
                         * Add the intangents source.
                         */
                        pv->sourceInTan = new AnimationSourceElement(
                                *this, string(ATTRVALUE_INTANGENTS_SOURCE_NAME));
                        pv->sourceInTan->AddTangentArray (
                                envelope.inTanControlX, envelope.inTanControlY);

                        /*
                         * Add the outtangents source.
                         */
                        pv->sourceOutTan = new AnimationSourceElement(
                                *this, string(ATTRVALUE_OUTTANGENTS_SOURCE_NAME));
                        pv->sourceOutTan->AddTangentArray (
                                envelope.outTanControlX, envelope.outTanControlY);
                }

                /*
                 * Add the interpolation source.
                 */
                pv->sourceInterp = new AnimationSourceElement(
                        *this, string(ATTRVALUE_INTERPOLATIONS_SOURCE_NAME));
                pv->sourceInterp->AddInterpArray (envelope.interpolations);

                /*
                 * Add the extended modo 501 inputs.
                 */
                if (!modoEnvelope.inWeights.empty ()) {
                        pv->sourceInTanSlopeWeights = new AnimationSourceElement(
                                *this, string(ATTRVALUE_IN_TANGENT_SLOPEWEIGHTS_SOURCE_NAME));
                        pv->sourceInTanSlopeWeights->AddSlopeWeightArray (
                                modoEnvelope.inSlopes, modoEnvelope.inWeights);

                        pv->sourceOutTanSlopeWeights = new AnimationSourceElement(
                                *this, string(ATTRVALUE_OUTTANGENT_SLOPEWEIGHTS_SOURCE_NAME));
                        pv->sourceOutTanSlopeWeights->AddSlopeWeightArray (
                                modoEnvelope.outSlopes, modoEnvelope.outWeights);
                }

                if ((!modoEnvelope.brokenValues.empty ()) && (!modoEnvelope.brokenValueTimes.empty ())) {
                        pv->sourceBrokenValues = new AnimationSourceElement(
                                *this, string(ATTRVALUE_BROKEN_OUTPUTS_SOURCE_NAME));
                        pv->sourceBrokenValues->AddBoolArray (
                                string(ATTRVALUE_BROKEN_OUTPUTS_INPUT_SEMANTIC), modoEnvelope.brokenValues);

                        pv->sourceBrokenValueTimes = new AnimationSourceElement(
                                *this, string(ATTRVALUE_BROKEN_OUTPUT_TIMES_SOURCE_NAME));
                        pv->sourceBrokenValueTimes->AddFloatArray (
                                string(ATTRVALUE_BROKEN_OUTPUT_TIMES_INPUT_SEMANTIC), modoEnvelope.brokenValueTimes);

                        pv->sourceBrokenInTanValues = new AnimationSourceElement(
                                *this, string(ATTRVALUE_IN_TANGENT_OUTPUT_SOURCE_NAME));
                        pv->sourceBrokenInTanValues->AddFloatArray (
                                string(ATTRVALUE_IN_TANGENT_OUTPUT_INPUT_SEMANTIC), modoEnvelope.brokenInTanValues);

                        pv->sourceBrokenOutTanValues = new AnimationSourceElement(
                                *this, string(ATTRVALUE_OUT_TANGENT_OUTPUT_SOURCE_NAME));
                        pv->sourceBrokenOutTanValues->AddFloatArray (
                                string(ATTRVALUE_OUT_TANGENT_OUTPUT_INPUT_SEMANTIC), modoEnvelope.brokenOutTanValues);
                }

                if (!modoEnvelope.brokenSlopes.empty ()) {
                        pv->sourceBrokenSlopes = new AnimationSourceElement(
                                *this, string(ATTRVALUE_BROKEN_SLOPES_SOURCE_NAME));
                        pv->sourceBrokenSlopes->AddBoolArray (
                                string(ATTRVALUE_BROKEN_SLOPES_INPUT_SEMANTIC), modoEnvelope.brokenSlopes);
                }

                if (!modoEnvelope.brokenWeights.empty ()) {
                        pv->sourceBrokenWeights = new AnimationSourceElement(
                                *this, string(ATTRVALUE_BROKEN_WEIGHTS_SOURCE_NAME));
                        pv->sourceBrokenWeights->AddBoolArray (
                                string(ATTRVALUE_BROKEN_WEIGHTS_INPUT_SEMANTIC), modoEnvelope.brokenWeights);
                }

                /*
                 * Add the sampler.
                 */
                pv->sampler = new AnimationSamplerElement(*this);

                AnimationSamplerInputTimeElement		samplerInputTime(
                        *(pv->sampler), *(pv->sourceInput));
                samplerInputTime.InitializeSemantic ();

                AnimationSamplerInputOutputElement		samplerInputOutput(
                        *(pv->sampler), *(pv->sourceOutput));
                samplerInputOutput.InitializeSemantic ();

                AnimationSamplerInputInterpolationElement	samplerInputInterpolation(
                        *(pv->sampler), *(pv->sourceInterp));
                samplerInputInterpolation.InitializeSemantic ();

                if (!envelope.inTanControlX.empty ()) {
                        AnimationSamplerInputInTangentElement	samplerInputInTangent(
                                *(pv->sampler), *(pv->sourceInTan));
                        samplerInputInTangent.InitializeSemantic ();

                        AnimationSamplerInputOutTangentElement	samplerInputOutTangent(
                                *(pv->sampler), *(pv->sourceOutTan));
                        samplerInputOutTangent.InitializeSemantic ();

                        /*
                         * In- and out-tangent slopes and weights.
                         */
                        AnimationSamplerInputInTangentSlopeWeightElement	samplerInTanSlopeWeight(
                                *(pv->sampler), *(pv->sourceInTanSlopeWeights));
                        samplerInTanSlopeWeight.InitializeSemantic ();

                        AnimationSamplerInputOutTangentSlopeWeightElement	samplerOutTanSlopeWeight(
                                *(pv->sampler), *(pv->sourceOutTanSlopeWeights));
                        samplerOutTanSlopeWeight.InitializeSemantic ();

                        /*
                         * Broken in- and out-tangent output values.
                         */
                        if (!modoEnvelope.brokenInTanValues.empty ()) {
                                AnimationSamplerInputInTangentOutputElement	samplerInputInTangentOutput(
                                        *(pv->sampler), *(pv->sourceBrokenInTanValues));
                                samplerInputInTangentOutput.InitializeSemantic ();
                        }

                        if (!modoEnvelope.brokenOutTanValues.empty ()) {
                                AnimationSamplerInputOutTangentOutputElement	samplerInputOutTangentOutput(
                                        *(pv->sampler), *(pv->sourceBrokenOutTanValues));
                                samplerInputOutTangentOutput.InitializeSemantic ();
                        }
                }

                /*
                 * Broken output value flags and times.
                 */
                if ((!modoEnvelope.brokenValues.empty ()) && (!modoEnvelope.brokenValueTimes.empty ())) {
                        AnimationSamplerInputBrokenOutputElement	samplerBrokenOutputs(
                                *(pv->sampler), *(pv->sourceBrokenValues));
                        samplerBrokenOutputs.InitializeSemantic ();

                        AnimationSamplerInputBrokenOutputTimeElement	samplerBrokenOutputTimes(
                                *(pv->sampler), *(pv->sourceBrokenValueTimes));
                        samplerBrokenOutputTimes.InitializeSemantic ();
                }

                /*
                 * Broken slope flags.
                 */
                if (!modoEnvelope.brokenSlopes.empty ()) {
                        AnimationSamplerInputBrokenSlopeElement		samplerBrokenSlopes(
                                *(pv->sampler), *(pv->sourceBrokenSlopes));
                        samplerBrokenSlopes.InitializeSemantic ();
                }

                /*
                 * Broken weight flags.
                 */
                if (!modoEnvelope.brokenWeights.empty ()) {
                        AnimationSamplerInputBrokenWeightElement	samplerBrokenWeights(
                                *(pv->sampler), *(pv->sourceBrokenWeights));
                        samplerBrokenWeights.InitializeSemantic ();
                }
        }
}

/*
 * Constructor for matrix-based envelopes with linear sampling.
 */
AnimationElement::AnimationElement (
        AnimationLibraryElement		&library,
        const string			&animationID,
        const MatrixEnvelope		&envelope)
        :
        AnimationContainerElement(library.PV ()),
        pv(new pv_AnimationElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                library.AddAnimation (*this);

                SetID (animationID);

                /*
                 * Add the input source.
                 */
                pv->sourceInput = new AnimationSourceElement(
                        *this, string(ATTRVALUE_INPUT_SOURCE_NAME));
                pv->sourceInput->AddInputArray (envelope.times);

                /*
                 * Add the output source.
                 */
                pv->sourceOutput = new AnimationSourceElement(
                        *this, string(ATTRVALUE_OUTPUT_SOURCE_NAME));
                pv->sourceOutput->AddOutputArray (ATTRVALUE_MATRIX_SID, envelope.outputs);

                /*
                 * Add the interpolation source.
                 */
                pv->sourceInterp = new AnimationSourceElement(
                        *this, string(ATTRVALUE_INTERPOLATIONS_SOURCE_NAME));
                InterpArray	 	 interpolations;
                for (unsigned keyframeIndex = 0;
                        keyframeIndex < envelope.times.size ();
                        ++keyframeIndex) {
                        interpolations.push_back (INTERPOLATION_LINEAR);
                }
                pv->sourceInterp->AddInterpArray (interpolations);

                /*
                 * The matrix form of the constructor does
                 * not have in and out tangents.
                 */

                /*
                 * Add the sampler.
                 */
                pv->sampler = new AnimationSamplerElement(*this);

                AnimationSamplerInputTimeElement		samplerInputTime(
                        *(pv->sampler), *(pv->sourceInput));
                samplerInputTime.InitializeSemantic ();

                AnimationSamplerInputOutputElement		samplerInputOutput(
                        *(pv->sampler), *(pv->sourceOutput));
                samplerInputOutput.InitializeSemantic ();

                AnimationSamplerInputInterpolationElement	samplerInputInterpolation(
                        *(pv->sampler), *(pv->sourceInterp));
                samplerInputInterpolation.InitializeSemantic ();
        }
}

AnimationElement::AnimationElement(AnimationContainerElement &parent):
        AnimationContainerElement(parent.PV ()),
        pv(new pv_AnimationElement())
{
}

AnimationElement::~AnimationElement ()
{
        delete pv;
}

        bool
AnimationElement::LinkNextAnimation (AnimationElement &animation)
{
        return LinkNextSiblingElement (ELEMENT_ANIMATION, animation);
}

/*
 * @return If this animation element has a child channel element.
 */
        bool
AnimationElement::HasChannel () const
{
        return HasChildElement (ELEMENT_CHANNEL);
}

        bool
AnimationElement::LinkFirstChannel (AnimationChannelElement &channel)
{
        return LinkFirstChildElement (ELEMENT_CHANNEL, channel);
}

        bool
AnimationElement::HasSampler () const
{
        return HasChildElement (ELEMENT_SAMPLER);
}

        bool
AnimationElement::LinkSampler (
        const string			&samplerID,
        AnimationSamplerElement		&sampler)
{
        return LinkFirstChildElement (ELEMENT_SAMPLER, samplerID, sampler);
}

        bool
AnimationElement::LinkSource (
        const string			&sourceID,
        AnimationSourceElement		&source)
{
        return LinkFirstChildElement (ELEMENT_SOURCE, sourceID, source);
}

        void
AnimationElement::AddAnimationChannel (AnimationChannelElement &channel)
{
        channel.SetElement (AddElement (ELEMENT_CHANNEL));
}

        void
AnimationElement::AddAnimationSampler (AnimationSamplerElement &sampler)
{
        sampler.SetElement (AddElement (ELEMENT_SAMPLER));
}

        const AnimationSamplerElement*
AnimationElement::GetSampler () const
{
        return pv->sampler;
}

        void
AnimationElement::AddSource (SourceElement	*source)
{
        source->SetElement (AddElement (ELEMENT_SOURCE));
}

        void
AnimationElement::AddSource (
        AnimationSourceElement		*source,
        Semantic			 semantic)
{
        AddSource (source);

        if (semantic == SEMANTIC_INPUT) {
                pv->sourceInput = source;
        }
        else if (semantic == SEMANTIC_OUTPUT) {
                pv->sourceOutput = source;
        }
        else if (semantic == SEMANTIC_INTERPOLATION) {
                pv->sourceInterp = source;
        }
        else if (semantic == SEMANTIC_IN_TANGENT) {
                pv->sourceInTan = source;
        }
        else if (semantic == SEMANTIC_OUT_TANGENT) {
                pv->sourceOutTan = source;
        }
}

/*
 * ---------------------------------------------------------------------------
 * Animation Param.
 */

ParamAnimationElement::ParamAnimationElement (
        AnimationLibraryElement	&library,
        const string		&itemName,
        const string		&targetLibraryElementName,
        const string		&paramSID,
        const string		&paramName,
        const Envelope	 	&envelope,
        bool			 saveMayaProfile)
        :
        AnimationElement(
                library,
                TargetChannelParamID (
                        library.GetElementParamBind ()->GetItemID (
                                targetLibraryElementName, itemName),
                        paramSID),
                string(),
                envelope,
                saveMayaProfile)
{
        /*
         * Add the channel element to target a particular node ID.
         */
        AnimationChannelElement channel(
                *this, *(GetSampler ()),
                itemName, targetLibraryElementName, paramSID);
}

ParamAnimationElement::ParamAnimationElement (
        AnimationLibraryElement		&library,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&paramSID,
        const string			&paramName,
        const Envelope	 		&envelope,
        const Envelope_modo501		&modoEnvelope,
        bool				 saveMayaProfile)
        :
        AnimationElement(
                library,
                TargetChannelParamID (
                        library.GetElementParamBind ()->GetItemID (
                                targetLibraryElementName, itemName),
                        paramSID),
                string(),
                envelope,
                modoEnvelope,
                saveMayaProfile)
{
        /*
         * Add the channel element to target a particular node ID.
         */
        AnimationChannelElement channel(
                *this, *(GetSampler ()),
                itemName, targetLibraryElementName, paramSID);
}

ParamAnimationElement::~ParamAnimationElement ()
{
}

/*
 * ---------------------------------------------------------------------------
 * Animation Transform.
 */

TransformAnimationElement::TransformAnimationElement (
        AnimationLibraryElement	&library,
        const string		&itemName,
        const string		&targetLibraryElementName,
        const string		&transformName,
        const string		&axisName,
        const string		&componentName,
        bool			 appendAxisToTargetTransformName,
        const Envelope	 	&envelope,
        bool			 saveMayaProfile)
        :
        AnimationElement(
                library,
                NodeChannelTransformID (
                        library.GetElementParamBind ()->GetItemID (targetLibraryElementName, itemName),
                        TransformID (transformName),
                        appendAxisToTargetTransformName ? axisName : string(),
                        componentName),
                componentName,
                envelope,
                saveMayaProfile)
{
        /*
         * Add the channel element to target a particular node ID.
         */
        AnimationChannelElement channel(
                *this, *(GetSampler ()),
                itemName, targetLibraryElementName,
                transformName, componentName, axisName,
                appendAxisToTargetTransformName);
}

TransformAnimationElement::TransformAnimationElement (
        AnimationLibraryElement		&library,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const MatrixEnvelope	 	&envelope)
        :
        AnimationElement(
                library,
                NodeChannelTransformID (
                        (targetLibraryElementName == string(ELEMENT_NODE)) ?
                                library.GetElementParamBind ()->GetItemID (
                                        targetLibraryElementName, itemName) :
                                NodeID (library.GetElementParamBind ()->GetItemID (
                                        targetLibraryElementName, itemName)),
                        ATTRVALUE_MATRIX_SID),
                envelope)
{
        /*
         * Add the channel element to target a particular node ID.
         */
        AnimationChannelElement channel(
                *this, *(GetSampler ()),
                itemName, targetLibraryElementName);
}



TransformAnimationElement::TransformAnimationElement (
        AnimationLibraryElement		&library,
        const string			&itemName,
        const string			&targetLibraryElementName,
        const string			&transformName,
        const string			&axisName,
        const string			&componentName,
        bool				 appendAxisToTargetTransformName,
        const Envelope			&envelope,
        const Envelope_modo501		&modoEnvelope,
        bool				 saveMayaProfile)
        :
        AnimationElement(
                library,
                NodeChannelTransformID (
                        library.GetElementParamBind ()->GetItemID (targetLibraryElementName, itemName),
                        TransformID (transformName),
                        appendAxisToTargetTransformName ? axisName : string(),
                        componentName),
                componentName,
                envelope,
                modoEnvelope,
                saveMayaProfile)
{
        /*
         * Add the channel element to target a particular node ID.
         */
        AnimationChannelElement channel(
                *this, *(GetSampler ()),
                itemName, targetLibraryElementName,
                transformName, componentName, axisName,
                appendAxisToTargetTransformName);
}

TransformAnimationElement::~TransformAnimationElement ()
{
}

/*
 * ---------------------------------------------------------------------------
 * Animation Library.
 */

AnimationLibraryElement::AnimationLibraryElement (COLLADAElement &collada)
        :
        AnimationContainerElement(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddAnimationLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkAnimationLibrary (*this);
        }
}

AnimationLibraryElement::~AnimationLibraryElement ()
{
}

        void
AnimationLibraryElement::AddAnimation (AnimationElement &animation)
{
        animation.SetElement (AddElement (ELEMENT_ANIMATION));
}

} // namespace cio

