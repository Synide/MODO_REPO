/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_source.h"
#include "cio_animation.h"
#include "cio_controller.h"
#include "cio_geometry.h"
#include "cio_strings.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_technique.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Source.
 */

SourceElement::SourceElement (
        AnimationElement	&animation,
        const string		&arrayTypeName)
        :
        Element(animation.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                animation.AddSource (this);

                SetID (animation.GetID () +
                       string(ATTRVALUE_DASHSEPARATORSYMBOL) +
                       arrayTypeName);
        }
}

SourceElement::SourceElement (
        AnimationElement	&animation)
        :
        Element(animation.PV ())
{
}

SourceElement::SourceElement (
        MeshElement		&mesh,
        const string		&arrayTypeName)
        :
        Element(mesh.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                mesh.AddSource (*this);

                SetID (mesh.GetGeometryID () +
                       string(ATTRVALUE_DASHSEPARATORSYMBOL) +
                       arrayTypeName);

                SetName (arrayTypeName);
        }
}

SourceElement::SourceElement (
        SkinElement		&skin,
        const string		&arrayTypeName)
        :
        Element(skin.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                skin.AddSource (*this);

                SetID (skin.GetControllerID () +
                       string(ATTRVALUE_DASHSEPARATORSYMBOL) +
                       arrayTypeName);

                SetName (arrayTypeName);
        }
}

SourceElement::SourceElement (
        MeshElement		&mesh)
        :
        Element(mesh.PV ())
{
}

SourceElement::~SourceElement ()
{
}

        unsigned
SourceElement::GetCount () const
{
        unsigned count(0);

        ElementXML *technique = GetElementHandle ().FirstChildElement (
                ELEMENT_TECHNIQUE_COMMON).Element ();
        if (technique) {
                ElementXML *accessor = technique->FirstChildElement (
                        ELEMENT_ACCESSOR);
                if (accessor) {
                        count = GetAttributeUnsigned (accessor, ATTRIBUTE_COUNT);
                }
        }

        return count;
}

        unsigned
SourceElement::GetStride () const
{
        unsigned count(1);

        ElementXML *technique = GetElementHandle ().FirstChildElement (
                ELEMENT_TECHNIQUE_COMMON).Element ();
        if (technique) {
                ElementXML *accessor = technique->FirstChildElement (
                        ELEMENT_ACCESSOR);
                if (accessor) {
                        count = GetAttributeUnsigned (accessor, ATTRIBUTE_STRIDE);
                }
        }

        return count;
}

        bool
SourceElement::LinkBoolArray (
        BoolArray		&arrayValues)
{
        bool	linked(false);

        ElementXML *boolArray = GetElementHandle ().FirstChildElement (
                ELEMENT_BOOL_ARRAY).Element ();
        if (boolArray) {
                unsigned count = GetAttributeUnsigned (boolArray, ATTRIBUTE_COUNT);
                GetElementValue (boolArray, arrayValues);

                /*
                 * The count attribute must match the actual number of values
                 * for the document to be valid.
                 */
                if (arrayValues.size () == count) {
                        linked = true;
                }
        }

        return linked;
}

        void
SourceElement::AddBoolArray (
        const string		&paramName,
        const BoolArray		&arrayValues)
{
        ElementXML *boolArray = AddElement (ELEMENT_BOOL_ARRAY);
        string boolArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (boolArray, boolArrayID);
        SetAttribute (boolArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size ());
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (boolArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, 1);

        ElementXML* param = AddElement (accessor, ELEMENT_PARAM);
        if (!paramName.empty ()) {
                SetName (param, paramName);
        }
        SetType (param, ATTRVALUE_BOOL);

        SetElementValue (boolArray, arrayValues);
}

        void
SourceElement::AddNameArray (
        const string		&paramName,
        const StringArray	&arrayValues)
{
        ElementXML *nameArray = AddElement (ELEMENT_NAME_ARRAY);
        string nameArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (nameArray, nameArrayID);
        SetAttribute (nameArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size ());
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (nameArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, 1);

        ElementXML* param = AddElement (accessor, ELEMENT_PARAM);
        if (!paramName.empty ()) {
                SetName (param, paramName);
        }
        SetType (param, ATTRVALUE_NAME);

        SetElementValue (nameArray, arrayValues);
}

        bool
SourceElement::LinkUnsignedArray (
        UnsignedArray		&arrayValues)
{
        bool	linked(false);

        ElementXML *unsignedArray = GetElementHandle ().FirstChildElement (
                ELEMENT_INT_ARRAY).Element ();
        if (unsignedArray) {
                unsigned count = GetAttributeUnsigned (unsignedArray, ATTRIBUTE_COUNT);
                GetElementValue (unsignedArray, arrayValues);

                /*
                 * The count attribute must match the actual number of values
                 * for the document to be valid.
                 */
                if (arrayValues.size () == count) {
                        linked = true;
                }
        }

        return linked;
}

        void
SourceElement::AddUnsignedArray (
        const string		&paramName,
        const UnsignedArray	&arrayValues)
{
        ElementXML *intArray = AddElement (ELEMENT_INT_ARRAY);
        string intArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (intArray, intArrayID);
        SetAttribute (intArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size ());
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (intArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, 1);

        ElementXML* param = AddElement (accessor, ELEMENT_PARAM);
        if (!paramName.empty ()) {
                SetName (param, paramName);
        }
        SetType (param, ATTRVALUE_INT);

        SetElementValue (intArray, arrayValues);
}

        bool
SourceElement::LinkFloatArray (
        FloatArray		&arrayValues)
{
        bool	linked(false);

        ElementXML *floatArray = GetElementHandle ().FirstChildElement (
                ELEMENT_FLOAT_ARRAY).Element ();
        if (floatArray) {
                unsigned count = GetAttributeUnsigned (floatArray, ATTRIBUTE_COUNT);
                GetElementValue (floatArray, arrayValues);

                /*
                 * The count attribute must match the actual number of values
                 * for the document to be valid.
                 */
                if (arrayValues.size () == count) {
                        linked = true;
                }
        }

        return linked;
}

        void
SourceElement::AddFloatArray (
        const string		&paramName,
        const FloatArray	&arrayValues)
{
        ElementXML *floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
        string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (floatArray, floatArrayID);
        SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML *techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size ());
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, 1);

        ElementXML* param = AddElement (accessor, ELEMENT_PARAM);
        if (!paramName.empty ()) {
                SetName (param, paramName);
        }
        SetType (param, ATTRVALUE_FLOAT);

        SetElementValue (floatArray, arrayValues);
}

        bool
SourceElement::LinkDoubleArray (
        DoubleArray		&arrayValues)
{
        bool	linked(false);

        ElementXML *floatArray = GetElementHandle ().FirstChildElement (
                ELEMENT_FLOAT_ARRAY).Element ();
        if (floatArray) {
                unsigned count = GetAttributeUnsigned (floatArray, ATTRIBUTE_COUNT);
                GetElementValue (floatArray, arrayValues);

                /*
                 * The count attribute must match the actual number of values
                 * for the document to be valid.
                 */
                if (arrayValues.size () == count) {
                        linked = true;
                }
        }

        return linked;
}

        void
SourceElement::AddDoubleArray (
        const string		&paramName,
        const DoubleArray	&arrayValues)
{
        ElementXML *floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
        string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (floatArray, floatArrayID);
        SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size ());
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, 1);

        ElementXML* param = AddElement (accessor, ELEMENT_PARAM);
        if (!paramName.empty ()) {
                SetName (param, paramName);
        }
        SetType (param, ATTRVALUE_FLOAT);

        SetElementValue (floatArray, arrayValues);
}

        bool
SourceElement::LinkFloatPairArray (
        FloatArray		&arrayValuesA,
        FloatArray		&arrayValuesB)
{
        bool	linked(false);

        ElementXML *floatArray = GetElementHandle ().FirstChildElement (
                ELEMENT_FLOAT_ARRAY).Element ();
        if (floatArray) {
                unsigned count = GetAttributeUnsigned (floatArray, ATTRIBUTE_COUNT);
                GetElementValue (floatArray, arrayValuesA, arrayValuesB);

                /*
                 * The count attribute must match the actual number of values
                 * for the document to be valid.
                 */
                if ((arrayValuesA.size () == count / 2) &&
                    (arrayValuesA.size () == arrayValuesB.size ())) {
                        linked = true;
                }
        }

        return linked;
}

        void
SourceElement::AddFloatPairArray (
        const string		&paramNameA,
        const string		&paramNameB,
        const FloatArray	&arrayValuesA,
        const FloatArray	&arrayValuesB)
{
        /*
         * Avoid corruption by verifying that array sizes match.
         */
        if (arrayValuesA.size () == arrayValuesB.size ()) {
                const unsigned stride = 2;

                ElementXML *floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
                string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
                SetID (floatArray, floatArrayID);
                SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValuesA.size () * stride);

                ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
                ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
                SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValuesA.size ());
                SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
                SetAttribute (accessor, ATTRIBUTE_STRIDE, stride);

                ElementXML* paramA = AddElement (accessor, ELEMENT_PARAM);
                SetName (paramA, paramNameA);
                SetType (paramA, ATTRVALUE_FLOAT);

                ElementXML* paramB = AddElement (accessor, ELEMENT_PARAM);
                SetName (paramB, paramNameB);
                SetType (paramB, ATTRVALUE_FLOAT);

                SetElementValue (floatArray, arrayValuesA, arrayValuesB);
        }
}

        void
SourceElement::AddFloatPairArrayPacked (
        const string		&paramNameA,
        const string		&paramNameB,
        const FloatArray	&arrayValues)
{
        const unsigned stride = 2;

        ElementXML *floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
        string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (floatArray, floatArrayID);
        SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size () / stride);
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, stride);

        ElementXML* paramA = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramA, paramNameA);
        SetType (paramA, ATTRVALUE_FLOAT);

        ElementXML* paramB = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramB, paramNameB);
        SetType (paramB, ATTRVALUE_FLOAT);

        SetElementValue (floatArray, arrayValues, stride);
}

        void
SourceElement::AddFloatTripleArrayPacked (
        const std::string	&paramNameA,
        const std::string	&paramNameB,
        const std::string	&paramNameC,
        const FloatArray	&arrayValues)
{
        const unsigned stride = 3;

        ElementXML	*floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
        string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (floatArray, floatArrayID);
        SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML	*accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size () / stride);
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, stride);

        ElementXML* paramA = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramA, paramNameA);
        SetType (paramA, ATTRVALUE_FLOAT);

        ElementXML* paramB = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramB, paramNameB);
        SetType (paramB, ATTRVALUE_FLOAT);

        ElementXML* paramC = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramC, paramNameC);
        SetType (paramC, ATTRVALUE_FLOAT);

        SetElementValue (floatArray, arrayValues, stride);
}

        void
SourceElement::AddFloatQuadArrayPacked (
        const std::string	&paramNameA,
        const std::string	&paramNameB,
        const std::string	&paramNameC,
        const std::string	&paramNameD,
        const FloatArray	&arrayValues)
{
        const unsigned stride = 4;

        ElementXML	*floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
        string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (floatArray, floatArrayID);
        SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValues.size ());

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML	*accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size () / stride);
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, stride);

        ElementXML* paramA = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramA, paramNameA);
        SetType (paramA, ATTRVALUE_FLOAT);

        ElementXML* paramB = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramB, paramNameB);
        SetType (paramB, ATTRVALUE_FLOAT);

        ElementXML* paramC = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramC, paramNameC);
        SetType (paramC, ATTRVALUE_FLOAT);

        ElementXML* paramD = AddElement (accessor, ELEMENT_PARAM);
        SetName (paramD, paramNameD);
        SetType (paramD, ATTRVALUE_FLOAT);

        SetElementValue (floatArray, arrayValues, stride);
}

        void
SourceElement::AddFloatTripleArrayPlanar (
        const std::string	&paramNameA,
        const std::string	&paramNameB,
        const std::string	&paramNameC,
        const FloatArray	&arrayValuesA,
        const FloatArray	&arrayValuesB,
        const FloatArray	&arrayValuesC)
{
        /*
         * Avoid corruption by verifying that array sizes match.
         */
        if ((arrayValuesA.size () == arrayValuesB.size ()) &&
            (arrayValuesA.size () == arrayValuesC.size ())) {
                const unsigned stride = 3;

                ElementXML *floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
                string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
                SetID (floatArray, floatArrayID);
                SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValuesA.size () * stride);

                ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
                ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
                SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValuesA.size ());
                SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
                SetAttribute (accessor, ATTRIBUTE_STRIDE, stride);

                ElementXML* paramA = AddElement (accessor, ELEMENT_PARAM);
                SetName (paramA, paramNameA);
                SetType (paramA, ATTRVALUE_FLOAT);

                ElementXML* paramB = AddElement (accessor, ELEMENT_PARAM);
                SetName (paramB, paramNameB);
                SetType (paramB, ATTRVALUE_FLOAT);

                ElementXML* paramC = AddElement (accessor, ELEMENT_PARAM);
                SetName (paramC, paramNameC);
                SetType (paramC, ATTRVALUE_FLOAT);

                SetElementValue (floatArray, arrayValuesA, arrayValuesB, arrayValuesC);
        }
}

        bool
SourceElement::LinkMatrixArray (
        math::Matrix4Array	&arrayValues)
{
        bool	linked(false);

        ElementXML *floatArray = GetElementHandle ().FirstChildElement (
                ELEMENT_FLOAT_ARRAY).Element ();
        if (floatArray) {
                unsigned count = GetAttributeUnsigned (floatArray, ATTRIBUTE_COUNT);
                GetElementValue (floatArray, arrayValues);

                /*
                 * The count attribute must match the actual number of values
                 * for the document to be valid.
                 */
                if (arrayValues.size () == count / 16) {
                        linked = true;
                }
        }

        return linked;
}

        void
SourceElement::AddMatrixArray (
        const string			&paramName,
        const math::Matrix4Array	&arrayValues)
{
        ElementXML *floatArray = AddElement (ELEMENT_FLOAT_ARRAY);
        string floatArrayID = GetID() + string(ATTRVALUE_ARRAYSUFFIX);
        SetID (floatArray, floatArrayID);
        SetAttribute (floatArray, ATTRIBUTE_COUNT, arrayValues.size () * 16);

        ElementXML	*techniqueCommon = AddElement (ELEMENT_TECHNIQUE_COMMON);
        ElementXML *accessor = AddElement (techniqueCommon, ELEMENT_ACCESSOR);
        SetAttribute (accessor, ATTRIBUTE_COUNT, arrayValues.size ());
        SetAttribute (accessor, ATTRIBUTE_SOURCE, URI_Ref (floatArrayID));
        SetAttribute (accessor, ATTRIBUTE_STRIDE, 16);

        ElementXML* param = AddElement (accessor, ELEMENT_PARAM);
        if (!paramName.empty ()) {
                SetName (param, paramName);
        }
        SetType (param, ATTRVALUE_FLOAT4X4);

        SetElementValue (floatArray, arrayValues);
}

        void
SourceElement::AddTechniqueProfile_modo401 (
        TechniqueProfileElement &techniqueProfile)
{
        techniqueProfile.SetElement (AddElement (ELEMENT_TECHNIQUE));
}

} // namespace cio

