/*
 * Plug-in orb item type.
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * A plug-in item type that creates a procedural orb, that can be varied
 * in various ways (coverage, radius, etc.), with adaptive sampling.
 */
#ifndef ORBITEM_H
#define ORBITEM_H

#include <lxlog.h>
#include <lx_action.hpp>
#include <lx_item.hpp>
#include <lx_package.hpp>
#include <lx_tableau.hpp>
#include <lx_vertex.hpp>
#include <lx_value.hpp>
#include <lxu_geometry.hpp>
#include <lxu_log.hpp>
#include <lx_select.hpp>
#include <lx_surface.hpp>
#include <lx_vmodel.hpp>

class COrbLog : public CLxLuxologyLogMessage
{
    public:
        COrbLog () : CLxLuxologyLogMessage ("orb-item") { }

        const char *	 GetFormat  () { return "Orb Object"; }
};

/*
 * Class Declarations
 *
 * These have to come before their implementions because they reference each
 * other. Descriptions are attached to the implementations.
 */
class COrbPackage;

/*
 * ---------------------------------------------------------------------------
 * A gear part for rendering.
 */
class COrbPart
{
    public:
        /*
         * Tableau Surface implementation.
         */
        LxResult	Bound (LXtTableauBox bbox);
        unsigned	FeatureCount (LXtID4 type);
        LxResult	FeatureByIndex (
                                LXtID4		 type,
                                unsigned int	 index,
                                const char	**name);
        LxResult	SetVertex (ILxUnknownID vdesc);
        LxResult	Sample (
                                const LXtTableauBox	 bbox,
                                float			 scale,
                                ILxUnknownID		 trisoup);

        /*
         * Part configuration.
         */
        void		SetPart (unsigned part);

        /*
         * Part. See the GearPart enum.
         */
        unsigned		 m_part;
        unsigned		 hasUVs;
        CLxUser_TableauVertex	 vrt_desc;

        /*
         * Indices for vertex feature subscripts.
         */
        enum
        {
                FEATURE_POSITION,
                FEATURE_OBJECT_POSITION,
                FEATURE_NORMAL,
                FEATURE_VELOCITY,
                BASE_FEATURE_COUNT
        };

        enum
        {
                FEATURE_UV	= BASE_FEATURE_COUNT,
                FEATURE_DPDU,
                TOTAL_FEATURE_COUNT
        };

        int			 f_pos[TOTAL_FEATURE_COUNT];

        LxResult	InitializePart (
                                CLxUser_Item		&m_item,
                                CLxUser_ChannelRead	&chanRead);

        LxResult	InitializePart (
                                double		coverage,
                                double		radius);

        /*
         * Construction channels.
         */
        double			 latitude_coverage;
        double			 longitude_coverage;

        float			 m_radius;

    private:
        LxResult	 SampleOrbPartShell (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID);

        LxResult	 SampleOrbPartCore (
                                CLxUser_TriangleSoup	&soup,
                                unsigned		&segmentID);
};

class COrbElement :
        public CLxImpl_TableauSurface,
        public CLxImpl_TableauInstance,
        public COrbPart
{
        COrbLog		 orb_log;

    public:
        CLxUser_TableauVertex	 vrt_desc;
        float			 m_radius;
        int			 m_resolution;
        int			 f_pos[4];
        LXtVector		 m_offset;
        LXtMatrix		 m_xfrm;

        LxResult	 tsrf_Bound (LXtTableauBox bbox) LXx_OVERRIDE;
        unsigned	 tsrf_FeatureCount (LXtID4 type) LXx_OVERRIDE;
        LxResult	 tsrf_FeatureByIndex (
                                LXtID4		 type,
                                unsigned int	 index,
                                const char	**name) LXx_OVERRIDE;
        LxResult	 tsrf_SetVertex (ILxUnknownID vdesc) LXx_OVERRIDE;
        LxResult	 tsrf_Sample (
                                const LXtTableauBox bbox,
                                float scale,
                                ILxUnknownID trisoup) LXx_OVERRIDE;

        LxResult	 tins_Properties (
                                ILxUnknownID	 vecstack) LXx_OVERRIDE;

        LxResult	 tins_GetTransform (
                                unsigned	 endPoint,
                                LXtVector	 offset,
                                LXtMatrix	 xfrm) LXx_OVERRIDE;
};

class COrbPackage;

class COrbItemSurface :
        public CLxImpl_Surface
{
        /*
         * The parts of the gear (side and endcaps)
         */
        COrbPackage	*src_pkg;

    public:
        LxResult	 surf_GetBBox (LXtBBox *bbox) LXx_OVERRIDE;

        LxResult	 surf_FrontBBox (
                                const LXtVector	 pos,
                                const LXtVector	 dir,
                                LXtBBox		*bbox) LXx_OVERRIDE;

        LxResult	 surf_RayCast (
                                const LXtRayInfo *ray,
                                LXtRayHit *hit) LXx_OVERRIDE;

        LxResult	 surf_BinCount (unsigned int *count) LXx_OVERRIDE;

        LxResult	 surf_BinByIndex (
                                unsigned int	 index,
                                void		**ppvObj) LXx_OVERRIDE;

        LxResult	 surf_TagCount (
                                LXtID4		 type,
                                unsigned int	*count) LXx_OVERRIDE;

        LxResult	 surf_TagByIndex (
                                LXtID4		 type,
                                unsigned int	 index,
                                const char	**stag) LXx_OVERRIDE;

        LxResult	 Initialize (
                                COrbPackage		*pkg,
                                CLxUser_Item		&m_item,
                                CLxUser_ChannelRead	&chanRead);

        LxResult	 Initialize (
                                COrbPackage		*pkg,
                                double			 radius);
};

class COrbInstance :
        public CLxImpl_PackageInstance,
        public CLxImpl_StringTag,
        public CLxImpl_TableauSource,
        public CLxImpl_ViewItem3D
{
        COrbLog		 	orb_log;

    public:
        COrbPackage	*src_pkg;
        CLxUser_Item	 m_item;
        ILxUnknownID	 inst_ifc;

        LxResult	 pins_Initialize (
                                ILxUnknownID	 item,
                                ILxUnknownID	 super) LXx_OVERRIDE;
        void		 pins_Cleanup (void) LXx_OVERRIDE;
        LxResult	 pins_SynthName (char *buf, unsigned len) LXx_OVERRIDE;
        unsigned	 pins_DupType (void) LXx_OVERRIDE;
        LxResult	 pins_TestParent (ILxUnknownID item) LXx_OVERRIDE;
        LxResult	 pins_Newborn (ILxUnknownID original) LXx_OVERRIDE;
        LxResult	 pins_Loading (void) LXx_OVERRIDE;
        LxResult	 pins_AfterLoad (void) LXx_OVERRIDE;
        void		 pins_Doomed (void) LXx_OVERRIDE;

        LxResult	 stag_Get (LXtID4 type, const char **tag) LXx_OVERRIDE;

        LxResult	 tsrc_Elements (ILxUnknownID tblx) LXx_OVERRIDE;
        LxResult	 tsrc_PreviewUpdate (
                                int	 chanIndex,
                                int	*update) LXx_OVERRIDE;

        LxResult	 vitm_Draw (
                                ILxUnknownID	 itemChanRead,
                                ILxUnknownID	 viewStrokeDraw,
                                int		 selectionFlags,
                                LXtVector	 itemColor) LXx_OVERRIDE;

        LxResult	 vitm_HandleCount (
                                int		*count) LXx_OVERRIDE;

        LxResult	 vitm_HandleMotion (
                                int		 handleIndex,
                                int		*motionType,
                                double		*min,
                                double		*max,
                                LXtVector	 plane,
                                LXtVector	 offset) LXx_OVERRIDE;

        LxResult	 vitm_HandleChannel (
                                int		 handleIndex,
                                int		*chanIndex) LXx_OVERRIDE;

        LxResult	 vitm_HandleValueToPosition (
                                int		 handleIndex,
                                double		*chanValue,
                                LXtVector	 position) LXx_OVERRIDE;

        LxResult	 vitm_HandlePositionToValue (
                                int		 handleIndex,
                                LXtVector	 position,
                                double		*chanValue) LXx_OVERRIDE;
};

class COrbPackage :
        public CLxImpl_Package,
        public CLxImpl_SelectionListener
{
    public:
        static LXtTagInfoDesc		 descInfo[];
        CLxPolymorph<COrbInstance>	 orb_factory;
        CLxPolymorph<COrbElement>	 elt_factory;

        COrbPackage ();

        LxResult		pkg_SetupChannels (
                                        ILxUnknownID addChan) LXx_OVERRIDE;
        LxResult		pkg_TestInterface (const LXtGUID *guid) LXx_OVERRIDE;
        LxResult		pkg_Attach (void **ppvObj) LXx_OVERRIDE;

        void			selevent_Add     (
                                        LXtID4		 type,
                                        unsigned int	 subtType) LXx_OVERRIDE;
        void			selevent_Current (LXtID4 type) LXx_OVERRIDE;
};

#endif // ORBITEM_H

