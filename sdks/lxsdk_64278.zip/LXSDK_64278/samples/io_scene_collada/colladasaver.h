/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2013 Luxology LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef COLLADASAVER_H
#define COLLADASAVER_H

#include "colladaconfig.h"
#include "colladaserver.h"
#include "colladavisitor.h"

#include "colladacontainers.h"
#include "colladaprefs.h"

#include "../libcolladaio/cio_element.h"
#include "../libcolladaio/cio_format.h"
#include "../libcolladaio/cio_asset.h"
#include "../libcolladaio/cio_camera.h"
#include "../libcolladaio/cio_effect.h"
#include "../libcolladaio/cio_light.h"
#include "../libcolladaio/cio_geometry.h"
#include "../libcolladaio/cio_controller.h"
#include "../libcolladaio/cio_visualscene.h"
#include "../libcolladaio/cio_source.h"
#include "../libcolladaio/cio_animation.h"

#include <lxu_scene.hpp>
#include <lx_deform.hpp>
#include <lxu_log.hpp>
#include <lxlog.h>

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <set>

/*
 * Return the value of an enumerated integer channel as a symbolic string.
 */
#if defined(MODO_501)
        std::string
GetTextHintEncodedChannelValue (
        const CLxSceneSaver	&saver,
        const std::string	&channelName);
#else
        std::string
GetTextHintEncodedChannelValue (
        CLxSceneSaver		&saver,
        const std::string	&channelName);
#endif

/*
 * ----------------------------------------------------------------
 * COLLADA Scene Saver
 *
 * A custom scene saver.
 *
 * Derives from CLxLineFormat for the file name.
 */

class COLLADASceneSaver
        :
        public CLxSceneSaver,
        public CLxLineFormat
{
        friend class MCItemTypeChannelVisitor;
        friend struct pv_MCItemTypeChannelVisitor;

        COLLADALogMessage	 log;
        LxResult		 LogError (
                                        LxResult		result,
                                        const std::string	&msg);

    protected:
        const COLLADAprefs&	 GetPrefs () const;

    private:
        COLLADAprefs		 prefs;
        cio::Element		 io;

        /*
         * Asset adders.
         */
        LxResult		 AddAsset (cio::COLLADAElement &collada);
        LxResult		 AddAssetContributor (cio::AssetElement &asset);
        LxResult		 AddAssetCreatedDateTime (cio::AssetElement &asset);
        LxResult		 AddAssetModifiedDateTime (cio::AssetElement &asset);
        LxResult		 AddAssetUnit (cio::AssetElement& asset);
        LxResult		 AddAssetUpAxis (cio::AssetElement& asset);

        /*
         * Scene traversal.
         */
        bool			 isRegistered;
        ItemTypeChannelBind	 itemTypeChannels;
        MCItemTypeChannelVisitor itemTypeChannelVisitor;

        void			 RegisterTypesAndChannels ();
        bool			 FindItemsAndChannelEnvelopes ();

        bool			 FindItemTypes ();
        bool			 FindEffectMaterialItem ();
        bool			 FindTransformableItems ();
        bool			 FindCameraItems ();

        bool			 FindMeshItems ();

        bool			 ShouldExportLayeredTransforms () const;

#if defined(MODO_501)
        bool			 ItemVisibleForSave () const;
        bool			 ItemVisible () const;
#else
        bool			 ItemVisibleForSave ();
        bool			 ItemVisible ();
#endif

        bool			 FindControllableItems ();

        bool			 FindGroupDeformer (
                                        CLxUser_Item		&meshItem,
                                        CLxUser_GroupDeformer	&groupDeformer,
                                        unsigned		&groupDeformerMeshIndex);

    protected:
        /*
         * Animations.
         */
        bool			 SaveAnimation () const
        {
                return saveAnimation;
        }

    private:
        bool			 saveAnimation;

        bool			 haveAtLeastOneAnimation;

        LxResult		 AddAnimationLibrary (cio::COLLADAElement &collada);

        LxResult		 AddTransformAnimations (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Item			&item,
                                        const std::string		&targetLibraryElementName);

        LxResult		 AddLayeredTransformAnimations (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Item			&item,
                                        const std::string		&targetLibraryElementName);

        LxResult		 AddMatrixTransformAnimations (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Item			&item,
                                        const std::string		&targetLibraryElementName);

        LxResult		 GetItemKeyframeTimes (
                                        CLxUser_Item			&item,
                                        cio::Element::FloatSet		&times);

        LxResult		 GetScaleKeyframeTimes (
                                        cio::Element::FloatSet		&times);

        LxResult		 GetRotateKeyframeTimes (
                                        cio::Element::FloatSet		&times);

        LxResult		 GetTranslateKeyframeTimes (
                                        cio::Element::FloatSet		&times);

        LxResult		 GetChannelKeyframeTimes (
                                        const std::string		&channelName,
                                        cio::Element::FloatSet		&times);

        LxResult		 AddMatrixTransformAnimationsAtTimes (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Item			&item,
                                        const std::string		&targetLibraryElementName,
                                        const cio::Element::FloatSet	&times);

        LxResult		 BuildMatrixEnvelope (
                                        CLxUser_Item				&item,
                                        const cio::Element::FloatSet		&times,
                                        cio::AnimationElement::MatrixEnvelope	&envelope);

        LxResult		 GetScaleKeyframeValueAtTime (
                                        double				 time,
                                        cio::math::Vector3		&value);

        LxResult		 GetRotateKeyframeValueAtTime (
                                        double				 time,
                                        cio::math::Vector3		&value);

        LxResult		 GetTranslateKeyframeValueAtTime (
                                        double				 time,
                                        cio::math::Vector3		&value);

        LxResult		 GetEnvelopeKeyframeValueAtTime (
                                        double				 time,
                                        std::vector<std::string>	 channels,
                                        cio::math::Vector3			&value);

        LxResult		 AddAnimationTranslateEnvelopes (
                                        cio::AnimationLibraryElement	&library,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName);

        LxResult		 AddAnimationRotateEnvelopes (
                                        cio::AnimationLibraryElement	&library,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName);

        LxResult		 AddAnimationScaleEnvelopes (
                                        cio::AnimationLibraryElement	&library,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName);

        LxResult		 AddAnimationTranslateEnvelope (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Envelope		&envelope,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName,
                                        const std::string		&axisName);

        LxResult		 AddAnimationRotateEnvelope (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Envelope		&envelope,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName,
                                        const std::string		&axisName);

        LxResult		 AddAnimationScaleEnvelope (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Envelope		&envelope,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName,
                                        const std::string		&axisName);

        LxResult		 AddAnimationTransformEnvelope (
                                        cio::AnimationLibraryElement	&library,
                                        CLxUser_Envelope		&envelope,
                                        const std::string		&itemName,
                                        const std::string		&targetLibraryElementName,
                                        const std::string		&transformName,
                                        const std::string		&axisName,
                                        const std::string		&componentName,
                                        double				 valueScale = 1.0,
                                        bool				 appendAxisToTargetTransformName = false);

        LxResult		 AddAnimationParam (
                                        cio::AnimationLibraryElement	&library,
                                        CLxLoc_Item			&item,
                                        const std::string		&channel,
                                        const std::string		&paramSID,
                                        const std::string		&paramName,
                                        cio::ParamType			 paramType);

        double			 GetFrameRate ();

        double			 GetStartTime ();
        double			 GetEndTime ();

        double			 GetCurrentStartTime ();
        double			 GetCurrentEndTime ();
        double			 GetTime ();

        double			 GetDefaultDrawSize ();

        std::string		 GetTimeSystem ();
        int			 GetUpAxis ();

        std::string		 GetAuthor ();
        std::string		 GetCopyright ();
        std::string		 GetKeywords ();
        std::string		 GetRevision ();
        std::string		 GetSubject ();
        std::string		 GetTitle ();

        std::string		 GetTag (LXtID4 tagID);

        bool			 GetKeyFrames (
                                        cio::ParamType				 paramType,
                                        CLxUser_Envelope			&envelope,
                                        cio::AnimationElement::Envelope		&animationEnvelope,
                                        cio::AnimationElement::Envelope_modo501	&modoEnvelope,
                                        double					 valueScale = 1.0);

        void			 GetSampledKeyFrames (
                                        cio::ParamType				 paramType,
                                        CLxUser_Envelope			&envelope,
                                        cio::AnimationElement::Envelope		&animationEnvelope,
                                        double					 valueScale = 1.0);

        /*
         * Cameras.
         */
        bool			 haveAtLeastOneCamera;
        bool			 haveAtLeastOneCameraAnimation;

        LxResult		 AddCameraLibrary (cio::COLLADAElement &collada);

        LxResult		 AddCameraOptics (cio::CameraElement &camera);
        LxResult		 AddCameraOpticsTechniqueCommon (
                                        cio::OpticsElement &optics);
        LxResult		 AddCameraOpticsTechniqueProfile_modo401 (
                                        cio::OpticsElement &optics);

        LxResult		 AddCameraImager (cio::CameraElement &camera);

        /*
         * Lights.
         */
        bool			 haveAtLeastOneLightAnimation;

        LxResult		 AddLightLibrary (cio::COLLADAElement &collada);

        /*
         * Targets.
         */
        bool			 GetTargetNodeID (std::string &nodeID);

        /*
         * Material traversal and output.
         */

        bool			 haveAtLeastOneEffect;
        bool			 haveAtLeastOneImage;
        bool			 haveAtLeastOneMaterial;

        typedef enum en_MaterialPass
        {
                MATERIALPASS_IMAGES,
                MATERIALPASS_EFFECTS,
                MATERIALPASS_MATERIALS
        } MaterialPass;

        MaterialPass		 materialPass;
        MaterialSet		 materialTagSet;
        MaterialSet		 meshMaterialTagSet;
        std::string		 materialTag;

        LxResult		 BuildImageFilePathList ();
        std::string		 NativePathToURI (const std::string &nativePath);

        LxResult		 AddEffectLibrary (
                                        cio::COLLADAElement &collada);

        LxResult		 AddShaderNodeLibrary (
                                        cio::COLLADAElement &collada);

        LxResult		 AddEffect (cio::EffectElement &effect);

        LxResult		 BuildCommonMaterial (
                                        struct CommonMaterial	&commonMaterial);
        std::string		 UVMapName (CLxUser_Item &imageMap);

        LxResult		 AddPhong (
                                        cio::PhongElement	&phong,
                                        struct CommonMaterial	&commonMaterial);

//	LxResult		 AddAdvancedMaterial (EffectElement &effect);
//	LxResult		 AddConstantEffect (EffectElement &effect);

        ImageMapFileSet		 imageMapFiles;

        LxResult		 AddImageLibrary (
                                        cio::COLLADAElement &collada);

        LxResult		 AddMaterialLibrary (
                                        cio::COLLADAElement &collada);

        LxResult		 BuildMaterialSet ();

        /*
         * Mesh traversal and output.
         */

        bool			 haveAtLeastOneMesh;
        bool			 haveAtLeastOneMeshAnimation;

        LxResult		 AddGeometryLibrary (
                                        cio::COLLADAElement &collada);

        LxResult		 AddMeshGeometry (cio::MeshElement &mesh);
        LxResult		 AddMeshTechniqueProfileModo401 (
                                        cio::MeshElement &mesh);

        bool				 saveVertexNormals;
        bool				 saveUVTextureCoordinates;
        bool				 saveColors;
        bool				 saveWeights;

        /*
         * Geometry vertex positions.
         */
        unsigned			 pointIndex;
        PointMap			 pointMap;
        cio::Element::FloatArray	 points;

        /*
         * Normal maps.
         */
        unsigned			 normalIndex;
        NormalMap			 normalMap;
        cio::Element::FloatArray	 normals;

        /*
         * Texture coordinate maps. (UV Maps)
         */
        unsigned				 texcoordIndex;
        unsigned				 texcoordSet;

        typedef TexcoordMap *TexcoordMapID;
        typedef std::vector<TexcoordMapID>	 TexcoordMapIDArray;
        TexcoordMapIDArray			 texcoordMaps;

        typedef cio::Element::FloatArray	*FloatArrayID;
        typedef std::vector<FloatArrayID>	 FloatArrayIDArray;
        FloatArrayIDArray			 texcoordArrays;

        /*
         * Vertex color maps.
         */
        unsigned				 colorRGBIndex;
        unsigned				 colorRGBAIndex;

        unsigned				 colorRGBSet;
        unsigned				 colorRGBASet;

        typedef ColorRGBMap			*ColorRGBMapID;
        typedef ColorRGBAMap			*ColorRGBAMapID;
        typedef std::vector<ColorRGBMapID>	 ColorRGBMapIDArray;
        typedef std::vector<ColorRGBAMapID>	 ColorRGBAMapIDArray;
        ColorRGBMapIDArray			 colorRGBMaps;
        ColorRGBAMapIDArray			 colorRGBAMaps;

        FloatArrayIDArray			 colorRGBArrays;
        FloatArrayIDArray			 colorRGBAArrays;

        /*
         * Weight maps.
         */
        unsigned			 weightIndex;
        unsigned			 weightSet;

        typedef WeightMap *WeightMapID;
        typedef std::vector<WeightMapID> WeightMapIDArray;
        WeightMapIDArray		 weightMaps;

        FloatArrayIDArray		 weightArrays;

        /*
         * Mesh map names.
         */
        cio::StringArray	 normalMapNames;
        cio::StringArray	 uvMapNames;
        cio::StringArray	 colorRGBMapNames;
        cio::StringArray	 colorRGBAMapNames;
        cio::StringArray	 weightMapNames;
        PolyTagTexCoord		 polyTagTexCoords;

        unsigned		 polyCount;
        std::vector<unsigned>	 polyCounts;
        std::vector<unsigned>	 polyIndices;

        typedef enum en_PolyPass
        {
                POLYPASS_BUILDMATERIALSET,
                POLYPASS_NORMALS,
                POLYPASS_UVS,
                POLYPASS_RGB_COLORS,
                POLYPASS_RGBA_COLORS,
                POLYPASS_WEIGHTS,
                POLYPASS_POLYGONS,
                POLYPASS_INSTANCEMATERIAL
        } PolyPass;

        PolyPass		 polyPass;
        cio::MeshElement	*activeMesh;

        cio::SourceElement		*sourceNormals;
        typedef cio::SourceElement	*SourceElementID;
        typedef std::vector<SourceElementID> SourceElementIDArray;
        SourceElementIDArray	 sourceTexcoords;
        SourceElementIDArray	 sourceColors;
        SourceElementIDArray	 sourceWeights;

        ElementXML		*instance_geometry;
        ElementXML		*instance_controller;
        ElementXML		*bind_material;
        ElementXML		*material_technique_common;

        LxResult		 VisitPolygons (PolyPass inPolyPass);

        void			 AddVertexNormal(unsigned polyVertexIndex);
        unsigned		 FindVertexNormal(unsigned polyVertexIndex);

        void			 AddVertexTexture(unsigned polyVertexIndex);
        unsigned		 FindVertexTexture(unsigned polyVertexIndex);

        void			 AddVertexColor(unsigned polyVertexIndex, bool useAlpha);
        unsigned		 FindVertexRGBColor(unsigned polyVertexIndex);
        unsigned		 FindVertexRGBAColor(unsigned polyVertexIndex);

        void			 AddVertexWeight(unsigned polyVertexIndex);
        unsigned		 FindVertexWeight(unsigned polyVertexIndex);

        bool			 AllTriangles () const;
        void			 AddTriangles (const std::string &materialName);
        void			 AddPolyList (const std::string &materialName);
        void			 AddPolygon ();


        void		AddRotationElement(
                                        TiXmlElement *node,
                                        const std::string & transformID,
                                        int order,
                                        const LXtVector & rotate);

        /*
         * Controller Library.
         */
        bool			 haveAtLeastOneController;
        std::set<std::string>	 jointNodeIDs;

        LxResult		 AddControllerLibrary (
                                        cio::COLLADAElement &collada);

        LxResult		 AddSkinController (
                                        cio::SkinElement	&skin,
                                        CLxUser_Item		&meshItem,
                                        CLxUser_GroupDeformer	&groupDeformer,
                                        unsigned		 groupDeformerMeshIndex);

        /*
         * Visual Scene Library and Scene element.
         */

        bool			 haveAtLeastOneItem;
        bool			 haveAtLeastOneTransformAnimation;
        CLxUser_ItemGraph	 itemGraph;

        LxResult		 AddVisualSceneLibrary (
                                        cio::COLLADAElement	&collada);

        LxResult		 AddVisualSceneAsset (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddVisualSceneItem (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddVisualScene_modo401 (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddVisualScene_Maya (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddVisualScene_Max3D (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddVisualScene_Okino (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddVisualScene_XSI (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddAmbientLightItemNode (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddItemNode (
                                        cio::VisualSceneElement	&visualScene);

        LxResult		 AddItemNode (
                                        cio::NodeElement	&parentNode);

        std::string		 GetItemNodeID () const;

        LxResult		 AddItemNode (ElementXML	*parentNode);

        ElementXML*		 AddExtraTechnique (ElementXML *node);

        LxResult		 AddItemNodeTransforms (
                                        CLxUser_Item		&selectedItem,
                                        ElementXML		*node);

        LxResult		 AddItemNodeTranslationChannels (
                                        ElementXML		*node,
                                        CLxUser_Item		&transformItem);

        LxResult		 AddItemNodeRotationChannels (
                                        ElementXML		*node,
                                        CLxUser_Item		&transformItem);

        LxResult		 AddItemNodeScaleChannels (
                                        ElementXML		*node,
                                        CLxUser_Item		&transformItem);

        LxResult		 AddItemNodeInverseChannel (
                                        ElementXML		*node,
                                        CLxUser_Item		&transformItem);

        void			 LogItemChannels (
                                        CLxUser_Item		&item);

        LxResult		 AddScene (cio::COLLADAElement &collada);

        void			 ClearContainers ();

    public:
                                 COLLADASceneSaver();
                                ~COLLADASceneSaver() {}

        //----------------------------------------------------------------
        //	Standard exporter overrides.

        virtual CLxFileFormat	*ss_Format ()	{ return this; }

        virtual void		 ss_Verify    ();
        virtual LxResult	 ss_Save ();
        virtual void		 ss_Point ();
        virtual void		 ss_Polygon ();

 	virtual void		 ff_Cleanup    ();

        static LXtTagInfoDesc	 descInfo[];
};

#endif // COLLADASAVER_H

