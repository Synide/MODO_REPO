#ifndef LX_VERSION_H
#define LX_VERSION_H

#define LXx_INT_STR(i)		#i		// turn an integer into a string
#define LXx_MACRO_STR(a)	LXx_INT_STR(a)	// extra nesting required for turning macro into string

#define LXi_VERSION_BUILD 100154
#define LXs_VERSION_BRANCH "modo901"
#define LXi_VERSION_BASE 9
#define LXi_VERSION_MINOR 02
#define LXi_VERSION_LIB1 900
#define LXi_VERSION_LIB2 0
#define LXi_VERSION_LIB3 10
#define LXi_VERSION_LIB4 154
#define LXs_VERSION_LIB "902.0.10.154"
#define LXs_VERSION_NAME "nexus 9"
#define LXs_VERSION_DESC "nexus 9 by The Foundry"
#define LXs_VERSION_MAKER "The Foundry Group LLC"
#define LXs_VERSION_FNBUILD "9.02v100154"
#define LXi_VERSION_YEAR 2015
#define LXs_VERSION_YEAR "2015"
#define LXi_VERSION_MONTH 12
#define LXs_VERSION_MONTH "12"
#define LXi_VERSION_DAY 1
#define LXs_VERSION_DAY "1"
#define LXs_VERSION_TIME "11:22:43"

#endif


