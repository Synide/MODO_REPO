/*
 * Plug-in SDK Header: C++ Services
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Helper class for doing math with modo matrices.
 */

#ifndef LX_MATRIX_HPP
#define LX_MATRIX_HPP

#include <lxvmath.h>
#include <lxu_math.hpp>
#include <lxu_vector.hpp>


class CLxMatrix4
{
public:
        LXtMatrix4 	m;
        
        
        CLxMatrix4()
        {
                lx::Matrix4Ident(m);
        }
        
        CLxMatrix4(const CLxMatrix4 &other)
        {
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                m[i][j] = other.m[i][j];
        }
        
        
        CLxMatrix4(const CLxMatrix4 &otherM, const CLxVector &otherV )
        {
                *this = otherM;
                setTranslation( otherV );
        }
        
        inline CLxMatrix4& operator= (const CLxMatrix4 &other)
        {
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                m[i][j] = other.m[i][j];
                
                return *this;
        }

        CLxMatrix4(const LXtMatrix4 mat)
        {
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                m[i][j] = mat[i][j];
        }
        
        inline CLxMatrix4& operator= (const LXtMatrix4 mat)
        {
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                m[i][j] = mat[i][j];
                
                return *this;
        }
        
        

        inline CLxMatrix4 transpose() const
        {
                CLxMatrix4 retM(*this);
                lx::MatrixTranspose( retM.m );
                return retM;
        }
        
        // faster inverse for pure rotations with isotropic scaling (orthogonal transforms)
        inline CLxMatrix4 inverseRotation() const
        {
                const CLxMatrix4 inv( getMatrix3x3().transpose() );
                return CLxMatrix4(inv, -getTranslation() * inv);
        }
        
        inline CLxMatrix4 inverse() const
        {
                LXtMatrix4			temp, input;//, output;
                double				inv_det = 0.0, det = 0.0;
                double				a0, a1, a2, a3, a4, a5, b0, b1, b2, b3, b4, b5;
                
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                input[i][j] = m[i][j];
                                
                a0 = input[0][0] * input[1][1] - input[0][1] * input[1][0];
                a1 = input[0][0] * input[1][2] - input[0][2] * input[1][0];
                a2 = input[0][0] * input[1][3] - input[0][3] * input[1][0];
                a3 = input[0][1] * input[1][2] - input[0][2] * input[1][1];
                a4 = input[0][1] * input[1][3] - input[0][3] * input[1][1];
                a5 = input[0][2] * input[1][3] - input[0][3] * input[1][2];
                b0 = input[2][0] * input[3][1] - input[2][1] * input[3][0];
                b1 = input[2][0] * input[3][2] - input[2][2] * input[3][0];
                b2 = input[2][0] * input[3][3] - input[2][3] * input[3][0];
                b3 = input[2][1] * input[3][2] - input[2][2] * input[3][1];
                b4 = input[2][1] * input[3][3] - input[2][3] * input[3][1];
                b5 = input[2][2] * input[3][3] - input[2][3] * input[3][2];
                
                det = a0 * b5 - a1 * b4 + a2 * b3 + a3 * b2 - a4 * b1 + a5 * b0;
                
                if (det == 0.0)
                        return CLxMatrix4 ();
                
                temp[0][0] = + input[1][1] * b5 - input[1][2] * b4 + input[1][3] * b3;
                temp[1][0] = - input[1][0] * b5 + input[1][2] * b2 - input[1][3] * b1;
                temp[2][0] = + input[1][0] * b4 - input[1][1] * b2 + input[1][3] * b0;
                temp[3][0] = - input[1][0] * b3 + input[1][1] * b1 - input[1][2] * b0;
                temp[0][1] = - input[0][1] * b5 + input[0][2] * b4 - input[0][3] * b3;
                temp[1][1] = + input[0][0] * b5 - input[0][2] * b2 + input[0][3] * b1;
                temp[2][1] = - input[0][0] * b4 + input[0][1] * b2 - input[0][3] * b0;
                temp[3][1] = + input[0][0] * b3 - input[0][1] * b1 + input[0][2] * b0;
                temp[0][2] = + input[3][1] * a5 - input[3][2] * a4 + input[3][3] * a3;
                temp[1][2] = - input[3][0] * a5 + input[3][2] * a2 - input[3][3] * a1;
                temp[2][2] = + input[3][0] * a4 - input[3][1] * a2 + input[3][3] * a0;
                temp[3][2] = - input[3][0] * a3 + input[3][1] * a1 - input[3][2] * a0;
                temp[0][3] = - input[2][1] * a5 + input[2][2] * a4 - input[2][3] * a3;
                temp[1][3] = + input[2][0] * a5 - input[2][2] * a2 + input[2][3] * a1;
                temp[2][3] = - input[2][0] * a4 + input[2][1] * a2 - input[2][3] * a0;
                temp[3][3] = + input[2][0] * a3 - input[2][1] * a1 + input[2][2] * a0;
                
                inv_det = 1.0 / det;
                
                for (unsigned i=0; i<4; i++)
                {
                        for (unsigned j=0; j<4; j++)
                        {
                                temp[i][j] *= inv_det;
                        }
                }
                
                return CLxMatrix4 ( temp );
        }
        
        inline CLxMatrix4& operator*=( const CLxMatrix4 &mat )
        {
                LXtMatrix4		 tmp;
                
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                tmp[i][j] = 0.0;
                
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                for (int k = 0; k < 4; k++)
                                        tmp[i][j] += m[i][k] * mat.m[k][j];
                
                for (int i = 0; i < 4; i++)
                        for (int j = 0; j < 4; j++)
                                m[i][j] = tmp[i][j];

                return *this;
        }
        
        inline CLxMatrix4	operator*( const CLxMatrix4 &mat ) const
        {
                CLxMatrix4 retM(*this);
                retM *= mat;
                return retM;
        }
        
        
        inline void	getScale( CLxVector &scale ) const
        {
                for (int i = 0; i < 3; i++)
                        scale[i] = LXx_VLEN( m[i] );
        }
        
        
        inline CLxMatrix4	getMatrix3x3( ) const
        {
                CLxMatrix4 retM;
                
                for (int i = 0; i < 3; i++)
                        for (int j = 0; j < 3; j++)
                                retM[i][j] = m[i][j];
                
                return retM;
        }
        
        
        inline CLxMatrix4	getRotateMatrix( ) const
        {
                CLxVector s(1.,1.,1.);
                getScale( s );
                
                CLxMatrix4 retM( getMatrix3x3() ) ;
                
                for (int i = 0; i < 3; i++)
                        LXx_VSCL( retM[i], s[i]);
                
                return retM;
        }
        
        inline void setTranslation( const CLxVector &vec  )
        {
                LXx_VCPY( m[3], vec );
        }
        
        inline void setTranslation( const LXtVector vec  )
        {
                LXx_VCPY( m[3], vec );
        }
        
        inline CLxVector getTranslation(  ) const
        {
                return CLxVector( m[3] );
        }
        
        
        inline void getTranslation( LXtVector vec ) const
        {
                LXx_VCPY ( vec, m[3] );
        }
        
        operator LXtMatrix4&()
        {
                return(m);
        }
        
        
        inline double* 	operator[] (unsigned int i)
        {
                if( i > 4 )
                        throw LXe_OUTOFBOUNDS;
                else
                        return m[i];
        }
        
        inline const double* 	operator[] (unsigned int i) const
        {
                if( i > 4 )
                        throw LXe_OUTOFBOUNDS;
                else
                        return m[i];
        }
        
};






#endif	/* LX_MATRIX_HPP */

