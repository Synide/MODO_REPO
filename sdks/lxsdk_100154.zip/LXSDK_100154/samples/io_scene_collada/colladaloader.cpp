/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

/*
 * Suppress warnings for deprecated functions.
 */
#ifdef _MSC_VER
        #define _CRT_SECURE_NO_WARNINGS 1
        #define _CRT_SECURE_NO_DEPRECATE 1
        #pragma warning(disable: 4996)
#endif

#pragma warning(disable: 4786)

#include "colladaloader.h"
#include "colladacontainers.h"

#include "../libcolladaio/cio_animation.h"
#include "../libcolladaio/cio_asset.h"
#include "../libcolladaio/cio_camera.h"
#include "../libcolladaio/cio_controller.h"
#include "../libcolladaio/cio_collada.h"
#include "../libcolladaio/cio_image.h"
#include "../libcolladaio/cio_light.h"
#include "../libcolladaio/cio_material.h"
#include "../libcolladaio/cio_profiles.h"
#include "../libcolladaio/cio_source.h"
#include "../libcolladaio/cio_visualscene.h"
#include "../libcolladaio/cio_scene.h"

#include <lxidef.h>
#include <lxitem.h>
#include <lxlog.h>
#include <lx_util.hpp>

#include <string>
#include <algorithm>

using namespace std;
using namespace cio;
using namespace cio::math;

/*
 * Define COLLADALOADER_VERBOSE_LOGGING for heavy-duty
 * logging message info.
 */
// #define COLLADALOADER_VERBOSE_LOGGING		1

static const unsigned NO_ITEM = static_cast<unsigned>(-1);

static Element::ColorRGBA OPAQUE_BLACK = {0, 0, 0, 1.0};

LXtTagInfoDesc	 COLLADASceneLoader::descInfo[] = {
        { LXsLOD_CLASSLIST,	LXa_SCENE			},
        { LXsLOD_DOSPATTERN,	VALUE_COLLADA_DOS_PATTERN	},
        { LXsSRV_USERNAME,	VALUE_SCENE_IO_USER_NAME	},
        { LXsSRV_LOGSUBSYSTEM,	"io-status"			},
        { 0 }
};

        LxResult
COLLADASceneLoader::LogError (
        LxResult		result,
        const string		&msg)
{
        LxResult logResult(result);
        if (LXx_OK (logResult)) {
                logResult = scene_build.ErrorCode ();
        }

        if (LXx_FAIL(logResult)) {
                log.Info (string("Error in ") + msg + string(": "), result);
        }

        return logResult;
}

#define LOG_ERR(result) LogError (result, __FUNCTION__)

COLLADASceneLoader::COLLADASceneLoader ()
        :
        file(IO_MODE_LOAD),
        error (LXe_FALSE)
{
}

COLLADASceneLoader::~COLLADASceneLoader ()
{
}

/*
 * ---------------------------------------------------------------------------
 * CLxSceneLoader overrides.
 */

        bool
COLLADASceneLoader::sl_Recognize ()
{
        /*
         * Verify that the file extension indicates COLLADA.
         */
        return (FileExtension (filename) == string(VALUE_COLLADA_FILE_EXTENSION));
}

        bool
COLLADASceneLoader::sl_ParseInit ()
{
        return true;
}

        bool
COLLADASceneLoader::sl_ParseDone ()
{
        return true;
}

        bool
COLLADASceneLoader::sl_Parse     (LxResult *loadResult)
{
        LxResult	result(LXe_FAILED);

        typedef enum en_COLLADA_LOAD_EXCEPTION
        {
                COLLADA_TALLY_FAILED,
                COLLADA_LOAD_ASSET_FAILED,
                COLLADA_LOAD_ANIMATION_LIBRARY_FAILED,
                COLLADA_LOAD_IMAGE_LIBRARY_FAILED,
                COLLADA_LOAD_VISUAL_SCENE_LIBRARY_FAILED,
                COLLADA_LOAD_SCENE_FAILED
        } COLLADA_LOAD_EXCEPTION;

        try {
                /*
                 * Setup the message logging system.
                 */
                log.Setup ();

                /*
                 * COLLADAElement lives and dies during sl_Parse, so we
                 * can use simple reference lifetime management for the
                 * entire COLLADA tree.
                 */
                COLLADAElement	collada(IO_MODE_LOAD);
                if (file.LoadDocument (filename, collada)) {
                        Asset		asset;
                        if (LXx_FAIL (LoadAsset (collada, asset))) {
                                throw COLLADA_LOAD_ASSET_FAILED;
                        }

                        if (LXx_FAIL (LoadAnimationLibrary (collada))) {
                                throw COLLADA_LOAD_ANIMATION_LIBRARY_FAILED;
                        }

                        if (LXx_FAIL (LoadImageLibrary (collada))) {
                                throw COLLADA_LOAD_IMAGE_LIBRARY_FAILED;
                        }

                        string visualSceneURI;
                        if (LXx_FAIL (LoadScene (collada, visualSceneURI))) {
                                throw COLLADA_LOAD_SCENE_FAILED;
                        }

                        if (LXx_FAIL (TallyVisualSceneLibrary (collada, visualSceneURI))) {
                                throw COLLADA_TALLY_FAILED;
                        }

                        if (LXx_FAIL(LoadVisualSceneLibrary (
                                collada, visualSceneURI, asset))) {
                                throw COLLADA_LOAD_VISUAL_SCENE_LIBRARY_FAILED;
                        }

                        result = LXe_OK;
                }
        }
        catch (COLLADA_LOAD_EXCEPTION loadException) {
                string	errorMsg("Unknown.");

                switch (loadException) {
                        case COLLADA_LOAD_ASSET_FAILED:
                                errorMsg = string("Asset load failure.");
                                break;

                        case COLLADA_LOAD_ANIMATION_LIBRARY_FAILED:
                                errorMsg = string("Animation library load failure.");
                                break;

                        case COLLADA_LOAD_IMAGE_LIBRARY_FAILED:
                                errorMsg = string("Image library load failure.");
                                break;

                        case COLLADA_LOAD_VISUAL_SCENE_LIBRARY_FAILED:
                                errorMsg = string("Visual Scene Library load failure.");
                                break;

                        case COLLADA_LOAD_SCENE_FAILED:
                                errorMsg = string("Scene load failure.");
                                break;
                }
                log.Error (errorMsg);

                /*
                 * Force a failure result code, in case no one set it.
                 */
                if (LXx_OK (result)) {
                        result = LXe_FAILED;
                }
        }
        catch (LxResult rc) {
                string errMsg("Loader failed with error: ");
                log.Error (errMsg, rc);
        }
        catch (...) {
                /*
                 * Make sure error doesn't take down the host.
                 */
                log.Error (
                        "Loader failed with unknown error.");

                /*
                 * Force a failure result code, in case no one set it.
                 */
                if (LXx_OK (result)) {
                        result = LXe_FAILED;
                }
        }

        if (LXx_OK (result)) {
                log.Info ("Scene loaded successfully.");
        }

        *loadResult = result;

        fp_Cleanup ();

        /*
         * Return false to indicate that no further processing is required.
         */
        return false;
}

/*
 * ---------------------------------------------------------------------------
 * CLxFileParser overrides.
 */

        bool
COLLADASceneLoader::fp_Open       (const char *name)
{
        fp_Cleanup ();

        filename = name;
        file_name = filename.c_str ();
        error = LXe_OK;

        return !filename.empty ();
}

        void
COLLADASceneLoader::fp_SetMonitor (LXtObjectID monObj)
{
        mon.set (monObj);
}

        bool
COLLADASceneLoader::fp_HasError   ()
{
        return LXx_FAIL (error);
}

        LxResult
COLLADASceneLoader::fp_ErrorCode  ()
{
        return error;
}

        void
COLLADASceneLoader::fp_Cleanup    ()
{
        filename.clear ();
        mon.clear ();

        nodeIDIndexMap.clear ();
        transformIDIndexMap.clear ();
        instances.clear ();
        cameraTargets.clear ();

        /*
         * Release our copies of what was loaded.
         */
        points.clear ();
        normals.clear ();

        texcoordOffsets.clear ();
        texcoords.clear ();
        texcoordUVMapIDs.clear ();
        texcoordUVMaps.clear ();

        colorOffsets.clear ();
        colors.clear ();
        colorMapIDs.clear ();
        colorMaps.clear ();
        colorMapStrides.clear ();

        weightOffsets.clear ();
        weights.clear ();
        weightMapIDs.clear ();
        weightMaps.clear ();

        polyVertexCounts.clear ();
        polyVertexIndices.clear ();

        materialTag = "";
        materialName = "";
        materialTagSet.clear ();
        materialMap.clear ();
        materialTargetNameMap.clear ();
        materialBindKey = make_pair ("", "");

        /*
         * The animation pointers are not allocated.
         */
        animationMap.clear ();
}

/*
 * ---------------------------------------------------------------------------
 * Element loaders.
 */

/*
 * Tally a number of steps required to load the scene.
 * (For the progress bar.)
 */
        LxResult
COLLADASceneLoader::TallyVisualSceneLibrary (
        COLLADAElement		&collada,
        const string		&visualSceneID)
{
        LxResult	result(LXe_OK);

        if (mon.test ()) {
                steps = 0;

                if (collada.HasVisualSceneLibrary ()) {
                        VisualSceneLibraryElement visualSceneLibrary(collada);

                        /*
                         * If the visual scene library is present, it must have
                         * at least one visual scene node, or the document is invalid.
                         * Set the result code to "not found" until we obtain a
                         * different result from loading a visual scene.
                         */
                        result = LXe_NOTFOUND;
                        if (visualSceneLibrary.HasVisualScene ()) {
                                VisualSceneElement visualScene(visualSceneLibrary);
                                if (visualSceneLibrary.LinkVisualScene (
                                        visualSceneID, visualScene)) {
                                        result = TallyVisualScene (collada, visualScene);
                                }
                        }
                }

                /*
                 * At least one step.
                 */
                if (!steps) {
                        steps = 1;
                }

                mon.Initialize (steps);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::TallyVisualScene (
        COLLADAElement		&collada,
        VisualSceneElement	&visualScene)
{
        LxResult	result(LXe_OK);

        /*
         * If the scene has at least one node.
         */
        if (visualScene.HasNode ()) {
                /*
                 * Link to the first node and start tallying the scene.
                 */
                NodeElement node(visualScene);
                if (visualScene.LinkFirstNode (node)) {
                        bool foundNextNode;
                        do {
                                /*
                                 * Load a node and its sub-nodes.
                                 */
                                result = TallyNode (collada, node);

                                /*
                                 * Process next sibling node.
                                 */
                                foundNextNode =
                                        visualScene.LinkNextNode (node);
                        } while (foundNextNode && LXx_OK (result));
                }

        }

        return LOG_ERR (result);
}

/*
 * Tally the given node and its sub-nodes.
 */
        LxResult
COLLADASceneLoader::TallyNode (
        COLLADAElement	&collada,
        NodeElement	&node)
{
        LxResult	result(LXe_OK);
        unsigned	pushedNodeItem = parentItem;

        ++steps;

        /*
         * If we're still good to go, load any sub nodes.
         */
        if (node.HasSubNode ()) {
                /*
                 * Link to the first subnode.
                 */
                NodeElement subNode(node);
                if (node.LinkFirstSubNode (subNode)) {

                        bool foundNextNode;
                        do {
                                /*
                                 * Recursively load the subnode.
                                 * The recursion unwinds once it reaches the leaf nodes.
                                 */
                                result = TallyNode (collada, subNode);

                                /*
                                 * Iterate to the next subnode.
                                 */
                                foundNextNode = subNode.LinkNextNode (subNode);
                        } while (foundNextNode && LXx_OK (result));
                }
        }

        LXxUNUSED (pushedNodeItem);

        return LOG_ERR (result);
}

/*
 * Asset element loader.
 */
        LxResult
COLLADASceneLoader::LoadAsset (
        COLLADAElement		&collada,
        Asset			&asset)
{
        LxResult	result(LXe_NOTFOUND);

        /*
         * The asset element is required, so we must fail if it's not found.
         */
        if (collada.HasAsset ()) {
                AssetElement	assetElem(collada);

                if (assetElem.HasContributor ()) {
                        ContributorElement contributor(assetElem);

                        asset.author = contributor.GetAuthor ();
                        asset.copyright = contributor.GetCopyright ();
                }

                asset.keywords = assetElem.GetKeywords ();
                asset.revision = assetElem.GetRevision ();
                asset.subject = assetElem.GetSubject ();
                asset.title = assetElem.GetTitle ();

                /*
                 * Get the up-axis.
                 *
                 * If the visual scene does not have its own asset,
                 * this value becomes the up axis for the scene,
                 * since the asset element is mandatory, and a
                 * default up axis is implied if the up_axis element
                 * is not found.
                 */
                asset.upAxis = assetElem.GetUpAxis ();
                switch (asset.upAxis) {
                        case AssetElement::UP_AXIS_X:
                        case AssetElement::UP_AXIS_Y:
                        case AssetElement::UP_AXIS_Z:
                                result = LXe_OK;
                                break;
                }
        }

        return LOG_ERR (result);
}

LxResult COLLADASceneLoader::LoadAnimationRecursively(
        COLLADAElement & collada,
        AnimationContainerElement & parent)
{
        AnimationElement animation(parent);
        if (!parent.LinkFirstChildAnimation (animation))
        {
                return LXe_FALSE;
        }

        // Iterate over each animation element,
        // sibling to sibling.
        //
        do
        {
                // If this animation element has
                // animation data then assume it is
                // a leaf animation element and store a reference to it.
                if(animation.HasChannel())
                {
                        MapAnimation (animation);
                }
                // If this animation element does not
                // have any animation data (channels)
                // then check if it has any child animation
                // elements. It could be a branch in the tree.
                else
                {
                        LoadAnimationRecursively(collada, animation);
                }
        } while ( animation.LinkNextAnimation (animation) );

        return LXe_OK;
}

/*
 * Create a map of animation targets and their corresponding
 * IDs, such that they can be quickly looked up by potentially
 * animated channels during node loading later on.
 */
        LxResult
COLLADASceneLoader::LoadAnimationLibrary (COLLADAElement &collada)
{
        LxResult	result(LXe_FAILED);

        if (collada.HasAnimationLibrary ()) {
                AnimationLibraryElement library(collada);

                if (library.HasChildAnimation ()) {
                        LoadAnimationRecursively(collada, library);
                }

                result = LXe_OK;
        }
        else {
                /*
                 * The lack of a library is not an error, so return
                 * false, which passes the test for success.
                 */
                result = LXe_FALSE;
        }

        return LOG_ERR (result);
}

/*
 * Cache an association between a target and its animation ID.
 */
        LxResult
COLLADASceneLoader::MapAnimation (
        AnimationElement &animation)
{
        LxResult result(LXe_FALSE);

        if (!animation.HasChannel ()){
                return LOG_ERR (LXe_FALSE);
        }

        AnimationChannelElement	channel(animation);
        if (!animation.LinkFirstChannel (channel)) {
                return LOG_ERR (LXe_FALSE);
        }

        bool foundChannel(false);
        do {
                string target(channel.GetTarget ());
                if (!target.empty ()) {

                        if(animationMap.find(target) == animationMap.end())
                        {
                                // We store an ElementXML pointer rather than a string here
                                // because the animation element may not have a name, as
                                // is the case with collada files from PFTrack.
                                //
                                animationMap[target] = animation.GetElement();
                        }
                        else
                        {
                                std::string error_message;
                                error_message += "The given animation element '";
                                error_message += channel.GetName();
                                error_message += "' is attempting to store a reference to the target channel '";
                                error_message += target;
                                error_message += "'.\nThis channel already has input from another animation channel.";
                                LogError(LXe_FALSE, error_message);
                        }
                        result = LXe_OK;
                }

                foundChannel = channel.LinkNextChannel (channel);
        } while (foundChannel);

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadImageLibrary (COLLADAElement &collada)
{
        LxResult	result(LXe_FAILED);

        if (collada.HasImageLibrary ()) {
                ImageLibraryElement library(collada);

                library.VisitImages (this);

                result = LXe_OK;
        }
        else {
                /*
                 * The lack of a library is not an error, so return
                 * false, which passes the test for success.
                 */
                result = LXe_FALSE;
        }

        return LOG_ERR (result);
}

        bool
COLLADASceneLoader::VisitImage (ImageElement &image)
{
        /*
         * If we have a non-empty file path,
         * add it to the image list.
         */
        string filePath = image.GetNativeFilePath ();
        if (!filePath.empty ()) {
                if (!IsFileAbsolute (filePath)) {
                        MakeFileAbsolute (filePath);
                }

                /*
                 * Load the image using the native file path.
                 */
                scene_build.AddImage (filePath.c_str ());
        }

        /*
         * For now, we always return true to visit every image.
         *
         * [TODO] Check for an error state to discontinue visiting.
         */
        return true;
}

/*
 * @param upAxis The global up axis to use if the visual scene
 *               does not have an asset of its own.
 */
        LxResult
COLLADASceneLoader::LoadVisualSceneLibrary (
        COLLADAElement		&collada,
        const string		&visualSceneID,
        Asset			&asset)
{
        LxResult	result(LXe_FAILED);

        if (collada.HasVisualSceneLibrary ()) {
                VisualSceneLibraryElement visualSceneLibrary(collada);

                /*
                 * If the visual scene library is present, it must have
                 * at least one visual scene node, or the document is invalid.
                 * Set the result code to "not found" until we obtain a
                 * different result from loading a visual scene.
                 */
                result = LXe_NOTFOUND;
                if (visualSceneLibrary.HasVisualScene ()) {
                        VisualSceneElement visualScene(visualSceneLibrary);
                        if (visualSceneLibrary.LinkVisualScene (
                                visualSceneID, visualScene)) {
                                result = LoadVisualScene (
                                        collada, visualScene, asset);
                        }
                }
        }
        else {
                /*
                 * A visual scene library is not required, so we return FALSE,
                 * which is not a fatal error condition. The COLLADA document
                 * may only contain a library of images or some other support
                 * data that is useful on its own.
                 */
                result = LXe_FALSE;
        }

        return LOG_ERR (result);
}

/*
 * @param upAxis The global up axis to use if the visual scene
 *               does not have an asset of its own.
 */
        LxResult
COLLADASceneLoader::LoadVisualScene (
        COLLADAElement		&collada,
        VisualSceneElement	&visualScene,
        Asset			&asset)
{
        LxResult	result(LXe_FAILED);

        /*
         * Select the scene item.
         */
        scene_build.SetItem (scene_build.SceneItem ());

        /*
         * Allow the local visual scene to override the up axis.
         */
        Asset		sceneAsset(asset);
        if (visualScene.HasAsset ()) {
                AssetElement assetElem(visualScene);

                if (assetElem.HasContributor ()) {
                        ContributorElement contributor(assetElem);

                        if (!contributor.GetAuthor ().empty ()) {
                                sceneAsset.author = contributor.GetAuthor ();
                        }
                        if (!contributor.GetCopyright ().empty ()) {
                                sceneAsset.copyright = contributor.GetCopyright ();
                        }
                }

                if (!assetElem.GetKeywords ().empty ()) {
                        sceneAsset.keywords = assetElem.GetKeywords ();
                }

                if (!assetElem.GetRevision ().empty ()) {
                        sceneAsset.revision = assetElem.GetRevision ();
                }

                if (!assetElem.GetSubject ().empty ()) {
                        sceneAsset.subject = assetElem.GetSubject ();
                }

                if (!assetElem.GetTitle ().empty ()) {
                        sceneAsset.keywords = assetElem.GetTitle ();
                }

                sceneAsset.upAxis = assetElem.GetUpAxis ();
        }

        /*
         * Set tags for various pieces of metadata.
         */
        if (!sceneAsset.author.empty ()) {
                scene_build.SetTag (LXi_TAG_AUTHOR, sceneAsset.author.c_str ());
        }

        if (!sceneAsset.copyright.empty ()) {
                scene_build.SetTag (LXi_TAG_COPYRIGHT, sceneAsset.copyright.c_str ());
        }

        if (!sceneAsset.keywords.empty ()) {
                scene_build.SetTag (LXi_TAG_KEYWORDS, sceneAsset.keywords.c_str ());
        }

        if (!sceneAsset.revision.empty ()) {
                scene_build.SetTag (LXi_TAG_REVISION, sceneAsset.revision.c_str ());
        }

        if (!sceneAsset.subject.empty ()) {
                scene_build.SetTag (LXi_TAG_SUBJECT, sceneAsset.subject.c_str ());
        }

        if (!sceneAsset.title.empty ()) {
                scene_build.SetTag (LXi_TAG_TITLE, sceneAsset.title.c_str ());
        }

        /*
         * Convert up axis to the modo channel value.
         */
        int	upAxisVal;
        switch (sceneAsset.upAxis) {
                case AssetElement::UP_AXIS_Y:
                        upAxisVal = LXiICVAL_SCENE_UPAXIS_Y;
                        break;

                case AssetElement::UP_AXIS_Z:
                        upAxisVal = LXiICVAL_SCENE_UPAXIS_Z;
                        break;

                case AssetElement::UP_AXIS_X:
                default:
                        upAxisVal = LXiICVAL_SCENE_UPAXIS_X;
                        break;
        }
        scene_build.SetChannel (LXsICHAN_SCENE_UPAXIS, upAxisVal);

        /*
         * Visual scene animation time system.
         */
        bool	haveFrameRate(false);
        bool	haveTime(false);
        bool	haveSceneStartEnd(false);
        if (visualScene.HasTechniqueProfile_modo401 ()) {
                VisualSceneElement_modo401 modoScene (visualScene);
                if (visualScene.LinkTechniqueProfile_modo401 (modoScene)) {
                        result = LoadVisualScene_modo401 (modoScene);
                        if (LXx_OK(result)) {
                                haveFrameRate = true;
                                haveTime = true;
                                haveSceneStartEnd = true;
                        }
                }
        }
        else {
                if (visualScene.HasTechniqueProfile_3dsMax ()) {
                        VisualSceneElement_3dsMax maxScene (visualScene);
                        if (visualScene.LinkTechniqueProfile_3dsMax (maxScene)) {
                                result = LoadVisualScene_3dsMax (maxScene);
                                if (LXx_OK(result)) {
                                        haveFrameRate = true;
                                }
                        }
                }
                if (visualScene.HasTechniqueProfile_FCOLLADA ()) {
                        VisualSceneElement_FCOLLADA fcScene (visualScene);
                        if (visualScene.LinkTechniqueProfile_FCOLLADA (fcScene)) {
                                result = LoadVisualScene_FCOLLADA (fcScene);
                                if (LXx_OK(result)) {
                                        haveSceneStartEnd = true;
                                }
                        }
                }
                if (visualScene.HasTechniqueProfile_Maya () &&
                    !haveSceneStartEnd) {
                        VisualSceneElement_Maya mayaScene (visualScene);
                        if (visualScene.LinkTechniqueProfile_Maya (mayaScene)) {
                                result = LoadVisualScene_Maya (mayaScene);
                                if (LXx_OK(result)) {
                                        haveSceneStartEnd = true;
                                }
                        }
                }

                if (visualScene.HasTechniqueProfile_XSI () &&
                    (!haveFrameRate || !haveSceneStartEnd)) {
                        VisualSceneElement_XSI xsiScene(visualScene);
                        if (visualScene.LinkTechniqueProfile_XSI (xsiScene)) {
                                result = LoadVisualScene_XSI (xsiScene);
                                if (LXx_OK(result)) {
                                        haveFrameRate = true;
                                        haveSceneStartEnd = true;
                                }
                        }
                }
        }

        if (!haveFrameRate) {
                double fps = prefs.GetFPS ();
                if (fps > 0.0 && fps <= LXdICVAL_SCENE_MAX_FPS)
                        scene_build.SetChannel (LXsICHAN_SCENE_FPS, fps);
                else
                        log.Info ("FPS value of %f not supported by Modo, skipping setting it.", fps);
        }

        if (!haveTime) {
                scene_build.SetChannel (LXsICHAN_SCENE_TIME, 0.0);
        }

        if (!haveSceneStartEnd) {
                double	timeRangeStart = prefs.GetTimeRangeStart ();
                double	timeRangeEnd = prefs.GetTimeRangeEnd ();

                scene_build.SetChannel (LXsICHAN_SCENE_SCENES, timeRangeStart);
                scene_build.SetChannel (LXsICHAN_SCENE_SCENEE, timeRangeEnd);

                scene_build.SetChannel (LXsICHAN_SCENE_CURRENTS, timeRangeStart);
                scene_build.SetChannel (LXsICHAN_SCENE_CURRENTE, timeRangeEnd);
        }

        /*
         * If the scene has at least one node.
         */
        if (visualScene.HasNode ()) {
                /*
                 * Start with root parent item.
                 */
                parentItem = NO_ITEM;
                lastNodeItem = NO_ITEM;

                /*
                 * Link to the first node and start processing the scene.
                 */
                NodeElement node(visualScene);
                if (visualScene.LinkFirstNode (node)) {
                        bool foundNextNode;
                        do {
                                /*
                                 * Load a node and its sub-nodes.
                                 */
                                result = LoadNode (collada, node);

                                /*
                                 * Process next sibling node.
                                 */
                                foundNextNode =
                                        visualScene.LinkNextNode (node);
                        } while (foundNextNode && LXx_OK (result));

                        materialTagSet.clear ();
                        materialTargetNameMap.clear ();
                        materialTag = "";
                        materialName = "";
                }

                if (LXx_OK (result)) {
                        /*
                         * Re-link camera and light targets.
                         */
                        result = LinkTargets ();
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVisualScene_modo401 (
        VisualSceneElement_modo401 &modoTech)
{
        LxResult	result(LXe_OK);

        /*
         * Load the visual scene frame rate and start and end times.
         */
        double	fps;
        if (!modoTech.GetFPS (fps)) {
                fps = prefs.GetFPS ();
        }
        if (fps > 0.0 && fps <= LXdICVAL_SCENE_MAX_FPS)
                scene_build.SetChannel (LXsICHAN_SCENE_FPS, fps);

        double	startTime, endTime;
        if (!modoTech.GetStartEndTime (startTime, endTime)) {
                startTime = prefs.GetTimeRangeStart ();
                endTime = prefs.GetTimeRangeEnd ();
        }
        scene_build.SetChannel (LXsICHAN_SCENE_SCENES, startTime);
        scene_build.SetChannel (LXsICHAN_SCENE_SCENEE, endTime);

        scene_build.SetChannel (LXsICHAN_SCENE_CURRENTS, startTime);
        scene_build.SetChannel (LXsICHAN_SCENE_CURRENTE, endTime);

        TimeSystem timeSystem;
        if (modoTech.GetTimeSystem (timeSystem)) {
                string	timeSysVal;
                switch (timeSystem) {
                        case TIME_SYSTEM_FRAMES:
                                timeSysVal = string(LXsICVAL_SCENE_TIMESYSTEM_FRAMES);
                                break;

                        case TIME_SYSTEM_SMPTE:
                                timeSysVal = string(LXsICVAL_SCENE_TIMESYSTEM_SMPTE);
                                break;

                        case TIME_SYSTEM_FILMCODE:
                                timeSysVal = string(LXsICVAL_SCENE_TIMESYSTEM_FILMCODE);
                                break;

                        case TIME_SYSTEM_SECONDS:
                        default:
                                timeSysVal = string(LXsICVAL_SCENE_TIMESYSTEM_SECONDS);
                                break;
                }
                scene_build.SetChannelEncoded (
                        LXsICHAN_SCENE_TIMESYS, timeSysVal.c_str ());
        }

        double drawSize;
        if (modoTech.GetDefaultDrawSize (drawSize)) {
                scene_build.SetChannel (LXsICHAN_SCENE_DRAWSIZE, drawSize);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVisualScene_3dsMax (
        VisualSceneElement_3dsMax &maxTech)
{
        LxResult	result(LXe_OK);

        double	frameRate;
        if (maxTech.GetFrameRate (frameRate)) {
                if (frameRate > 0.0 && frameRate <= LXdICVAL_SCENE_MAX_FPS)
                        scene_build.SetChannel (LXsICHAN_SCENE_FPS, frameRate);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVisualScene_FCOLLADA (
        VisualSceneElement_FCOLLADA &fTech)
{
        LxResult	result(LXe_OK);

        double	startTime, endTime;
        if (fTech.GetStartEndTime (startTime, endTime)) {
                scene_build.SetChannel (LXsICHAN_SCENE_SCENES, startTime);
                scene_build.SetChannel (LXsICHAN_SCENE_SCENEE, endTime);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVisualScene_Maya (
        VisualSceneElement_Maya &mayaTech)
{
        LxResult	result(LXe_OK);

        double	startTime, endTime;
        if (mayaTech.GetStartEndTime (startTime, endTime)) {
                scene_build.SetChannel (LXsICHAN_SCENE_SCENES, startTime);
                scene_build.SetChannel (LXsICHAN_SCENE_SCENEE, endTime);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVisualScene_XSI (
        VisualSceneElement_XSI &xsiTech)
{
        LxResult	result(LXe_OK);

        double	frameRate;
        if (xsiTech.GetFrameRate (frameRate)) {
                if (frameRate > 0.0 && frameRate <= LXdICVAL_SCENE_MAX_FPS)
                        scene_build.SetChannel (LXsICHAN_SCENE_FPS, frameRate);
        }

        double	startTime, endTime;
        if (xsiTech.GetStartEndTime (startTime, endTime)) {
                scene_build.SetChannel (LXsICHAN_SCENE_SCENES, startTime);
                scene_build.SetChannel (LXsICHAN_SCENE_SCENEE, endTime);
        }

        return LOG_ERR (result);
}

/*
 * Re-link camera and light targets.
 */
        LxResult
COLLADASceneLoader::LinkTargets ()
{
        LxResult	result(LXe_OK);

        /*
         * Re-link camera targets.
         */
        for (CameraTargetMap::const_iterator iter = cameraTargets.begin ();
             iter != cameraTargets.end (); ++iter) {
                /*
                 * Make the camera the current item for SetLink.
                 */
                scene_build.SetItem (iter->first);

                /*
                 * Look up the camera targeting info.
                 */
                NodeIDIndexMap::const_iterator targetedIter =
                        nodeIDIndexMap.find (iter->second.nodeID);
                if (targetedIter != nodeIDIndexMap.end ()) {
                        /*
                         * Add "target" package to the camera item, which
                         * provides the target-related channels.
                         */
                        scene_build.AddPackage (LXsITYPE_TARGET);

                        /*
                         * Relink the target.
                         */
                        scene_build.SetLink (
                                LXsGRAPH_TARGETS,
                                targetedIter->second);

                        /*
                         * Set the camera target-related channel values.
                         */
                        scene_build.SetChannel (
                                LXsICHAN_TARGET_ENABLE,
                                iter->second.enabled);

                        scene_build.SetChannel (
                                LXsICHAN_TARGET_TARGETFOCUS,
                                iter->second.setFocus);

                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_TARGET, iter->second.distance);
                        scene_build.SetChannel (
                                LXsICHAN_TARGET_TARGETROLL,
                                iter->second.roll);
                }
        }

        return LOG_ERR (result);
}

/*
 * Load a node.
 */
        LxResult
COLLADASceneLoader::LoadNode (
        COLLADAElement	&collada,
        NodeElement	&node)
{
        LxResult	result(LXe_FAILED);
        unsigned	pushedNodeItem = parentItem;

        /*
         * Update the progress bar.
         */
        if (mon.test ()) {
                mon.Increment (1);
        }

        /*
         * Remember the node name. If the node name is empty,
         * we fall back to the node ID.
         */
        nodeName = node.GetName ();
        if (nodeName.empty ()) {
                nodeName = node.GetID ();
        }

        unsigned	cameraItemIndex;
        unsigned	lightItemIndex;
        bool		isInstance(false);
        if (node.HasInstanceCamera ()) {
                lastNodeItem = scene_build.AddItem (LXsITYPE_CAMERA);
                cameraItemIndex = lastNodeItem;
                result = LXe_OK;
        }
        else if (node.HasInstanceLight ()) {
                result = InstanceLight (collada, node, lightItemIndex);
                lastNodeItem = lightItemIndex;
        }
        else if (node.HasInstanceController ()) {
                InstanceControllerElement instanceController(node);

                unsigned sourceSkinIndex;
                string controllerID;
                if (node.LinkFirstInstanceController (instanceController)) {
                        controllerID = StripURI_Ref (instanceController.GetURL ());
                        InstanceMap::const_iterator iter = instances.find (controllerID);
                        if (iter != instances.end ()) {
                                sourceSkinIndex = iter->second;
                                isInstance = true;
                        }
                }

                if (isInstance) {
                        lastNodeItem = scene_build.AddItem (LXsITYPE_MESHINST);
                        scene_build.SetItem (sourceSkinIndex);
                        scene_build.SetLink (LXsGRAPH_MESHINST, lastNodeItem);
                        scene_build.SetItem (lastNodeItem);
                        scene_build.SetLink (LXsGRAPH_SOURCE, sourceSkinIndex);
                }
                else {
                        lastNodeItem = scene_build.AddMesh ();
                        instances[controllerID] = lastNodeItem;
                }

                result = LXe_OK;
        }
        else if (node.HasInstanceGeometry ()) {
                InstanceGeometryElement	instanceGeometry(node);

                /*
                 * Although it's technically possible to have more than one
                 * instance geometry under a node, in practice that's unusual,
                 * so for now, we'll just process the first instance geometry
                 * per node.
                 */
                unsigned sourceMeshIndex;
                string	geometryID;
                if (node.LinkFirstInstanceGeometry (instanceGeometry)) {
                        geometryID = StripURI_Ref (instanceGeometry.GetURL ());
                        InstanceMap::const_iterator iter = instances.find (geometryID);
                        if (iter != instances.end ()) {
                                sourceMeshIndex = iter->second;
                                isInstance = true;
                        }
                }

                if (isInstance) {
                        lastNodeItem = scene_build.AddItem (LXsITYPE_MESHINST);
                        scene_build.SetItem (sourceMeshIndex);
                        scene_build.SetLink (LXsGRAPH_MESHINST, lastNodeItem);
                        scene_build.SetItem (lastNodeItem);
                        scene_build.SetLink (LXsGRAPH_SOURCE, sourceMeshIndex);
                }
                else {
                        lastNodeItem = scene_build.AddMesh ();
                        instances[geometryID] = lastNodeItem;
                }

                result = LXe_OK;
        }
        else {
                /*
                 * [TODO] Check the profile to determine if we should add a
                 *        group locator or just a plain locator.
                 */
                lastNodeItem = scene_build.AddItem (LXsITYPE_LOCATOR);
                result = LXe_OK;
        }

        if (result == LXe_OK) {
                /*
                 * Store the node IDs and their associated item indices for a second
                 * pass, to reconnect items to their targets.
                 */
                nodeIDIndexMap[node.GetID ()] = lastNodeItem;

                /*
                 * Set the node's position in the item tree.
                 */
                if (parentItem != NO_ITEM) {
                        scene_build.SetParent (parentItem);
                }

                /*
                 * [TODO] Get the un-filtered item name from the modo profile.
                 */
                if (!nodeName.empty ()) {
                        scene_build.SetName (nodeName.c_str ());
                }

                /*
                 * Check if the node has a transform.
                 */
                if (node.HasTransform ()) {
                        result = LoadTransforms (collada, node);
                }
                else {
                        /*
                         * Transforms are optional, so we indicate that we don't have
                         * any transforms with LXe_FALSE, which isn't an error.
                         */
                        result = LXe_FALSE;
                }

                if (LXx_OK (result)) {
                        /*
                         * Determine what the node is instancing.
                         *
                         * We interpret empty nodes as groups or locators.
                         */
                        if (node.HasInstanceCamera ()) {
                                result = LoadCamera (
                                        collada, node, cameraItemIndex);
                        }
                        else if (node.HasInstanceLight ()) {
                                result = LoadLight (
                                        collada, node, lightItemIndex);
                        }
                        else if (node.HasInstanceGeometry () &&
                                 !isInstance) {
                                result = LoadInstanceGeometry (collada, node);
                        }
                        else if (node.HasInstanceController () &&
                                 !isInstance) {
                                result = LoadInstanceController (collada, node);
                        }
                        else {
                                result = LXe_OK;
                        }

                        parentItem = lastNodeItem;

                        if (LXx_OK(result) && node.HasInstanceNode ()) {
                                result = LoadInstanceNode (collada, node);
                        }
                }

                /*
                 * If we're still good to go, load any sub nodes.
                 */
                if (LXx_OK (result) && node.HasSubNode ()) {
                        /*
                         * Link to the first subnode.
                         */
                        NodeElement subNode(node);
                        if (node.LinkFirstSubNode (subNode)) {

                                bool foundNextNode;
                                do {
                                        /*
                                         * Recursively load the subnode.
                                         * The recursion unwinds once it reaches the leaf nodes.
                                         */
                                        result = LoadNode (collada, subNode);

                                        /*
                                         * Iterate to the next subnode.
                                         */
                                        foundNextNode = subNode.LinkNextNode (subNode);
                                } while (foundNextNode && LXx_OK (result));
                        }
                }
        }

        parentItem = pushedNodeItem;

        return LOG_ERR (result);
}

/*
 * Load a node instance.
 *
 * For now, we only support references into a local node library.
 */
        LxResult
COLLADASceneLoader::LoadInstanceNode (
        COLLADAElement	&collada,
        NodeElement	&node)
{
        LxResult	result(LXe_NOTFOUND);

        InstanceNodeElement	instanceNode(node);

        if (node.LinkFirstInstanceNode (instanceNode)) {
                string nodeID = StripURI_Ref(instanceNode.GetURL ());
                if (collada.HasNodeLibrary ()) {
                        NodeLibraryElement	nodeLibrary(collada);

                        if (nodeLibrary.HasNode ()) {
                                NodeElement	refNode(nodeLibrary);
                                if (nodeLibrary.LinkNode (nodeID, refNode)) {
                                        result = LoadNode (collada, refNode);
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::InstanceLight (
        COLLADAElement		&collada,
        NodeElement		&node,
        unsigned		&lightItemIndex)
{
        LxResult	result(LXe_NOTFOUND);

        InstanceLightElement		instanceLight(node);
        if (node.LinkFirstInstanceLight (instanceLight)) {
                result = LXe_NOTFOUND;
                string	lightID = StripURI_Ref(instanceLight.GetURL ());
                if (collada.HasLightLibrary ()) {
                        LightLibraryElement lightLibrary(collada);

                        if (lightLibrary.HasLight ()) {
                                LightElement light(lightLibrary);
                                if (lightLibrary.LinkLight (
                                        lightID, light)) {

                                        /*
                                         * All lights have a common
                                         * light sub-type param.
                                         */
                                        string lightType;
                                        /*
                                         * Start with NO_ITEM until we find a
                                         * known light sub-type and create it.
                                         */
                                        lightItemIndex = NO_ITEM;
                                        if (light.IsAmbient ()) {
                                                result = LXe_FALSE;
                                        }
                                        else if (light.IsDirectional ()) {
                                                lightItemIndex = scene_build.AddItem (
                                                        LXsITYPE_SUNLIGHT);
                                                result = LXe_OK;
                                        }
                                        else if (light.IsPoint ()) {
                                                PointLightElement point(lightLibrary);
                                                if (light.LinkPointLight (point)) {
                                                        LightElement_modo401	light_modo401(light);
                                                        if (light.LinkTechniqueProfile_modo401 (light_modo401)) {
                                                                if (light_modo401.GetLightType (lightType)) {
                                                                        if (lightType == string(PARAMVALUE_MODO_LIGHT_TYPE_AREA_LIGHT)) {
                                                                                lightItemIndex = scene_build.AddItem (
                                                                                        LXsITYPE_AREALIGHT);
                                                                        }
                                                                        else if (lightType == string(PARAMVALUE_MODO_LIGHT_TYPE_CYLINDER_LIGHT)) {
                                                                                lightItemIndex = scene_build.AddItem (
                                                                                        LXsITYPE_CYLINDERLIGHT);
                                                                        }
                                                                        else if (lightType == string(PARAMVALUE_MODO_LIGHT_TYPE_DOME_LIGHT)) {
                                                                                lightItemIndex = scene_build.AddItem (
                                                                                        LXsITYPE_DOMELIGHT);
                                                                        }
                                                                }
                                                        }
                                                }

                                                /*
                                                 * If we didn't create one of the modo
                                                 * light sub-types, create a common point light.
                                                 */
                                                if (lightItemIndex == NO_ITEM) {
                                                        lightItemIndex = scene_build.AddItem (
                                                                LXsITYPE_POINTLIGHT);
                                                }
                                                result = LXe_OK;
                                        }
                                        else if (light.IsSpot ()) {
                                                SpotlightElement spot(lightLibrary);
                                                if (light.LinkSpotLight (spot)) {
                                                        LightElement_modo401	light_modo401(light);
                                                        if (light.LinkTechniqueProfile_modo401 (light_modo401)) {
                                                                if (light_modo401.GetLightType (lightType)) {
                                                                        if (lightType == string(PARAMVALUE_MODO_LIGHT_TYPE_PHOTO_LIGHT)) {
                                                                                lightItemIndex = scene_build.AddItem (
                                                                                        LXsITYPE_PHOTOMETRYLIGHT);
                                                                        }
                                                                }
                                                        }
                                                }
                                                /*
                                                 * If we didn't create one of the modo
                                                 * light sub-types, create a common spotlight.
                                                 */
                                                if (lightItemIndex == NO_ITEM) {
                                                        lightItemIndex = scene_build.AddItem (
                                                                LXsITYPE_SPOTLIGHT);
                                                }
                                                result = LXe_OK;
                                        }
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadCamera (
        COLLADAElement		&collada,
        NodeElement		&node,
        unsigned		 cameraItemIndex)
{
        LxResult	result(LXe_NOTFOUND);

        InstanceCameraElement		instanceCamera(node);
        if (node.LinkFirstInstanceCamera (instanceCamera)) {
                result = LXe_FALSE;
                string	cameraID = StripURI_Ref(instanceCamera.GetURL ());
                if (collada.HasCameraLibrary ()) {
                        CameraLibraryElement cameraLibrary(collada);
                        if (cameraLibrary.HasCamera ()) {
                                CameraElement camera(cameraLibrary);
                                if (cameraLibrary.LinkCamera (
                                        cameraID, camera)) {
                                        result = LXe_FALSE;
                                        if (camera.HasOptics ()) {
                                                OpticsElement optics(camera);
                                                if (camera.LinkOptics (optics)) {
                                                        result = LoadCameraOptics (
                                                                collada,
                                                                optics,
                                                                cameraItemIndex);
                                                }
                                        }
                                        if (LXx_OK (result) &&
                                            camera.HasImager ()) {
                                                ImagerElement imager(camera);
                                                if (camera.LinkImager (imager)) {
                                                        result = LoadCameraImager (
                                                                collada, imager);
                                                }
                                        }
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadCameraOptics (
        COLLADAElement		&collada,
        OpticsElement		&optics,
        unsigned		 cameraItemIndex)
{
        LxResult	result(LXe_OK);

        /*
         * If we don't have a modo profile, we'll grab the aperture and
         * projection from the common elements.
         */
        bool	hasAperture(false);
        bool	hasProjection(false);
        if (optics.HasTechniqueProfile_modo401 ()) {
                result = LoadCameraOptics_modo401 (collada, optics, cameraItemIndex);
                hasAperture = hasProjection = LXx_OK (result);
        }

        if (optics.HasPerspective ()) {
                PerspectiveElement perspective(optics);
                if (optics.LinkPerspective (perspective)) {
                        if (!hasProjection) {
                                scene_build.SetChannelEncoded (
                                        LXsICHAN_CAMERA_PROJTYPE,
                                        PARAMVALUE_MODO_PROJECTION_TYPE_PERSPECTIVE);				
                        }
                        if (!hasAperture) {
                                /*
                                 * Check for one of the possible combinations
                                 * of FOVs and aspect ratio.
                                 *
                                 * [TODO] Fetch the default aperture sizes
                                 *        and focal length value.
                                 */
                                double xfov, yfov;
                                double aspect = 1.0;
                                if (perspective.GetFOVs (xfov, yfov)) {
                                        if (yfov) {
                                                aspect = xfov / yfov;
                                        }
                                }
                                else if (perspective.GetXFOVandAspectRatio (
                                        xfov, aspect)) {
                                }
                                else if (perspective.GetYFOVandAspectRatio (
                                        yfov, aspect)) {
                                }
                        }
                }
        }
        else if (optics.HasOrthographic ()) {
                OrthographicElement orthographic(optics);
                if (optics.LinkOrthographic (orthographic)) {
                        if (!hasProjection) {
                                scene_build.SetChannelEncoded (
                                        LXsICHAN_CAMERA_PROJTYPE,
                                        PARAMVALUE_MODO_PROJECTION_TYPE_ORTHOGRAPHIC);				
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadCameraOptics_modo401 (
        COLLADAElement	&collada,
        OpticsElement	&optics,
        unsigned	 cameraItemIndex)
{
        LxResult	result(LXe_OK);

        OpticsElement_modo401 modoOptics(optics);
        if (optics.LinkTechniqueProfile_modo401 (modoOptics)) {
                string targetNodeID;
                if (modoOptics.GetTargetNodeID (targetNodeID)) {

                        CameraTarget	cameraTarget;

                        /*
                         * Target node ID is linked during a second pass,
                         * for forward references.
                         */
                        cameraTarget.nodeID = targetNodeID;

                        /*
                         * Set up some reasonable defaults
                         * for missing element values.
                         */
                        cameraTarget.enabled = false;
                        cameraTarget.setFocus = false;
                        cameraTarget.distance = 1.0;
                        cameraTarget.roll = 0.0;

                        /*
                         * Read in the target-related channels.
                         */
                        bool	targetEnabled;
                        if (modoOptics.GetTargetEnable (targetEnabled)) {
                                cameraTarget.enabled = targetEnabled;
                        }

                        bool	targetSetFocus;
                        if (modoOptics.GetTargetSetFocus (targetSetFocus)) {
                                cameraTarget.setFocus = targetSetFocus;
                        }

                        double targetDistance;
                        if (modoOptics.GetTargetDistance (targetDistance)) {
                                cameraTarget.distance = targetDistance;
                        }

                        /*
                         * Convert modo profile roll angle from degrees to radians.
                         */
                        double targetRoll;
                        if (modoOptics.GetTargetRoll (targetRoll)) {
                                cameraTarget.roll = targetRoll * DEG2RAD;
                        }

                        /*
                         * Store the camera target info for the second pass.
                         */
                        cameraTargets[cameraItemIndex] = cameraTarget;
                }


                string projection;
                if (modoOptics.GetProjection (projection)) {
                        scene_build.SetChannelEncoded (
                                LXsICHAN_CAMERA_PROJTYPE,
                                projection.c_str ());
                }

                double focalLength;
                if (modoOptics.GetFocalLength (focalLength)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_FOCALLEN, focalLength);
                }

                double lensDistortion;
                if (modoOptics.GetLensDistortion (lensDistortion)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_DISTORT, lensDistortion);
                }

                double lensSqueeze;
                if (modoOptics.GetLensSqueeze (lensSqueeze)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_SQUEEZE, lensSqueeze);
                }

                double focusDistance;
                if (modoOptics.GetFocusDistance (focusDistance)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_FOCUSDIST, focusDistance);
                }

                double fStop;
                if (modoOptics.GetFStop (fStop)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_FSTOP, fStop);
                }

                double blurLength;
                if (modoOptics.GetMotionBlurLength (blurLength)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_BLURLEN, blurLength);
                }

                double blurOffset;
                if (modoOptics.GetMotionBlurOffset (blurOffset)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_BLUROFF, blurOffset);
                }

                double interDistance;
                if (modoOptics.GetInterocularDistance (interDistance)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_IODIST, interDistance);
                }

                double convergDistance;
                if (modoOptics.GetConvergenceDistance (convergDistance)) {
                        scene_build.SetChannel (
                                LXsICHAN_CAMERA_CONVDIST, convergDistance);
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadCameraImager (
        COLLADAElement		&collada,
        ImagerElement		&imager)
{
        LxResult	result(LXe_OK);

        if (imager.HasTechniqueProfile_modo401 ()) {
                ImagerElement_modo401 modoImager(imager);
                if (imager.LinkTechniqueProfile_modo401 (modoImager)) {
                        double width, height;
                        if (modoImager.GetAperture (width, height)) {
                                scene_build.SetChannel (
                                        LXsICHAN_CAMERA_APERTUREX, width);
                                scene_build.SetChannel (
                                        LXsICHAN_CAMERA_APERTUREY, height);
                        }

                        double offsetX, offsetY;
                        if (modoImager.GetOffset (offsetX, offsetY)) {
                                scene_build.SetChannel (
                                        LXsICHAN_CAMERA_OFFSETX, offsetX);
                                scene_build.SetChannel (
                                        LXsICHAN_CAMERA_OFFSETY, offsetY);
                        }

                        string fit;
                        if (modoImager.GetFilmFit (fit)) {
                                scene_build.SetChannelEncoded (
                                        LXsICHAN_CAMERA_FILMFIT,
                                        fit.c_str ());
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadLight (
        COLLADAElement		&collada,
        NodeElement		&node,
        unsigned		 lightItemIndex)
{
        LxResult	result(LXe_NOTFOUND);

        InstanceLightElement		instanceLight(node);
        if (node.LinkFirstInstanceLight (instanceLight)) {
                result = LXe_FALSE;
                string	lightID = StripURI_Ref(instanceLight.GetURL ());
                if (collada.HasLightLibrary ()) {
                        LightLibraryElement lightLibrary(collada);
                        if (lightLibrary.HasLight ()) {
                                LightElement light(lightLibrary);
                                if (lightLibrary.LinkLight (
                                        lightID, light)) {
                                        result = LXe_FALSE;
                                        if (light.IsDirectional ()) {
                                                DirectionalLightElement directional(lightLibrary);
                                                light.LinkDirectionalLight (directional);
                                                result = LoadDirectionalLight (
                                                        collada, directional,
                                                        lightItemIndex);
                                        }
                                        else if (light.IsPoint ()) {
                                                PointLightElement point(lightLibrary);
                                                light.LinkPointLight (point);
                                                result = LoadPointLight (
                                                        collada, point,
                                                        lightItemIndex);
                                        }
                                        else if (light.IsSpot ()) {
                                                SpotlightElement spot(lightLibrary);
                                                light.LinkSpotLight (spot);
                                                result = LoadSpotLight (
                                                        collada, spot,
                                                        lightItemIndex);
                                        }
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadDirectionalLight (
        COLLADAElement			&collada,
        DirectionalLightElement		&light,
        unsigned			 lightItemIndex)
{
        LxResult	result(LXe_OK);

        Element::ColorRGB color;
        if (light.GetColor (color)) {
                unsigned curItem = scene_build.CurItem ();

                scene_build.AddItem (LXsITYPE_LIGHTMATERIAL);
                scene_build.SetParent (lightItemIndex);
                scene_build.SetChannelColor (
                        LXsICHAN_LIGHTMATERIAL_LIGHTCOL, color);
                scene_build.SetItem (curItem);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadPointLight (
        COLLADAElement		&collada,
        PointLightElement	&light,
        unsigned		 lightItemIndex)
{
        LxResult	result(LXe_OK);

        Element::ColorRGB color;
        if (light.GetColor (color)) {
                unsigned curItem = scene_build.CurItem ();

                scene_build.AddItem (LXsITYPE_LIGHTMATERIAL);
                scene_build.SetParent (lightItemIndex);
                scene_build.SetChannelColor (
                        LXsICHAN_LIGHTMATERIAL_LIGHTCOL, color);
                scene_build.SetItem (curItem);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadSpotLight (
        COLLADAElement		&collada,
        SpotlightElement	&light,
        unsigned		 lightItemIndex)
{
        LxResult	result(LXe_OK);

        Element::ColorRGB color;
        if (light.GetColor (color)) {
                unsigned curItem = scene_build.CurItem ();

                scene_build.AddItem (LXsITYPE_LIGHTMATERIAL);
                scene_build.SetParent (lightItemIndex);
                scene_build.SetChannelColor (
                        LXsICHAN_LIGHTMATERIAL_LIGHTCOL, color);
                scene_build.SetItem (curItem);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadInstanceController (
        COLLADAElement		&collada,
        NodeElement		&node)
{
        LxResult	result(LXe_NOTFOUND);

        InstanceControllerElement	instanceController(node);

        /*
         * Process the instance geometries for the given node.
         */
        if (node.LinkFirstInstanceController (instanceController)) {
                bool foundNextInstanceController(false);
                basePointIndex = 0;

                do {
                        string	controllerID(StripURI_Ref (instanceController.GetURL ()));

                        /*
                         * If we have a controller ID, it must be present or the
                         * document is invalid, so we set the result to "not found"
                         * pending the results of loading the geometry.
                         */
                        result = LXe_NOTFOUND;
                        if (collada.HasControllerLibrary ()) {
                                ControllerLibraryElement controllerLibrary(collada);

                                if (controllerLibrary.HasController ()) {
                                        ControllerElement controller(controllerLibrary);
                                        if (controllerLibrary.LinkController (
                                                controllerID, controller)) {
                                                if (controller.HasSkin ()) {
                                                        SkinElement	skin(controller);
                                                        string	geometryID(StripURI_Ref (skin.GetSourceMeshURI ()));
                                                        if ((!geometryID.empty ()) &&
                                                            collada.HasGeometryLibrary ()) {
                                                                GeometryLibraryElement geometryLibrary(collada);
                                                                if (geometryLibrary.HasGeometry ()) {
                                                                        GeometryElement geometry(geometryLibrary);
                                                                        if (geometryLibrary.LinkGeometry (
                                                                                geometryID, geometry)) {
                                                                                /*
                                                                                 * Material are optional, so we initially indicate
                                                                                 * that we don't have any materials with LXe_FALSE,
                                                                                 * which isn't an error.
                                                                                 */
                                                                                result = LXe_FALSE;
                                                                                if (instanceController.HasInstanceMaterial ()) {
                                                                                        InstanceMaterialElement	instanceMaterial(
                                                                                                instanceController);
                                                                                        if (instanceController.LinkFirstInstanceMaterial (
                                                                                                instanceMaterial)) {
                                                                                                bool	foundNextMaterial(false);
                                                                                                do {
                                                                                                        result = LoadInstanceMaterial (
                                                                                                                collada, geometryID, instanceMaterial);
                                                                                                        if (LXx_OK (result)) {
                                                                                                                foundNextMaterial =
                                                                                                                        instanceMaterial.LinkNextInstanceMaterial (
                                                                                                                                instanceMaterial);
                                                                                                        }
                                                                                                } while (foundNextMaterial && LXx_OK (result));
                                                                                        }
                                                                                }

                                                                                /*
                                                                                 * LXe_FALSE isn't an error, but check if something else went wrong.
                                                                                 */
                                                                                if (LXx_OK (result)) {
                                                                                        result = LoadGeometry (
                                                                                                collada, geometry);
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }
                                        }
                                }
                        }

                        basePointIndex = lastPointIndex + 1;

                        foundNextInstanceController =
                                node.LinkNextInstanceController (instanceController);
                } while (LXx_OK (result) && foundNextInstanceController);

                basePointIndex = 0;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadInstanceGeometry (
        COLLADAElement		&collada,
        NodeElement		&node)
{
        LxResult	result(LXe_NOTFOUND);

        InstanceGeometryElement	instanceGeometry(node);

        /*
         * Process the instance geometries for the given node.
         */
        if (node.LinkFirstInstanceGeometry (instanceGeometry)) {
                bool foundNextInstanceGeometry(false);
                basePointIndex = 0;

                do {
                        string	geometryID(StripURI_Ref (instanceGeometry.GetURL ()));

                        /*
                         * Material are optional, so we initially indicate
                         * that we don't have any materials with LXe_FALSE,
                         * which isn't an error.
                         */
                        result = LXe_FALSE;
                        if (instanceGeometry.HasInstanceMaterial ()) {
                                InstanceMaterialElement	instanceMaterial(
                                        instanceGeometry);
                                if (instanceGeometry.LinkFirstInstanceMaterial (
                                        instanceMaterial)) {
                                        bool	foundNextMaterial(false);
                                        do {
                                                result = LoadInstanceMaterial (
                                                        collada, geometryID, instanceMaterial);
                                                if (LXx_OK (result)) {
                                                        foundNextMaterial =
                                                                instanceMaterial.LinkNextInstanceMaterial (
                                                                        instanceMaterial);
                                                }
                                        } while (foundNextMaterial && LXx_OK (result));
                                }
                        }

                        /*
                         * LXe_FALSE isn't an error, but check if something else went wrong.
                         */
                        if (LXx_OK (result)) {
                                /*
                                 * If we have a geometry ID, it must be present or the
                                 * document is invalid, so we set the result to "not found"
                                 * pending the results of loading the geometry.
                                 */
                                result = LXe_NOTFOUND;
                                if (collada.HasGeometryLibrary ()) {
                                        GeometryLibraryElement geometryLibrary(collada);

                                        if (geometryLibrary.HasGeometry ()) {
                                                GeometryElement geometry(geometryLibrary);
                                                if (geometryLibrary.LinkGeometry (
                                                        geometryID, geometry)) {
                                                        result = LoadGeometry (
                                                                collada, geometry);
                                                }
                                        }
                                }
                        }

                        basePointIndex = lastPointIndex + 1;

                        foundNextInstanceGeometry =
                                node.LinkNextInstanceGeometry (instanceGeometry);
                } while (LXx_OK (result) && foundNextInstanceGeometry);

                basePointIndex = 0;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadTransforms (
        COLLADAElement		&collada,
        NodeElement		&node)
{
        LxResult	result(LXe_NOTFOUND);

        TransformElement		 transform(node);
        TransformTypeArray		 transformTypes;
        RotateAxisArray			 rotateAxes;
        if (node.LinkLastTransform (transform)) {
                bool	foundPrevTransform(false);
                do {
                        result = LoadTransform (
                                collada,
                                node,
                                transform,
                                transformTypes,
                                rotateAxes);
                        if (LXx_OK (result)) {
                                /*
                                 * Transforms can be layered.
                                 */
                                foundPrevTransform =
                                        transform.LinkPreviousTransform (
                                                transform);
                        }
                } while (foundPrevTransform && LXx_OK (result));
        }

        /*
         * Transform sequence links are only valid within a single node.
         */
        transformIDIndexMap.clear ();

        return LOG_ERR (result);
}

        bool
COLLADASceneLoader::HasTransformType (
        TransformType			 transformType,
        const TransformTypeArray	&transformTypes)
{
        return (find (
                transformTypes.begin (),
                transformTypes.end (),
                transformType) != transformTypes.end ());
}

/*
 * @param transform		The transform to be loaded.
 * @param transformTypes	An array of transform types for each transform loaded so far.
 * @param rotateAxes		An array of major axis for each rotation transform.
 */
        LxResult
COLLADASceneLoader::LoadTransform (
        COLLADAElement		&collada,
        NodeElement		&node,
        TransformElement	&transform,
        TransformTypeArray	&transformTypes,
        RotateAxisArray		&rotateAxes)
{
        LxResult	result(LXe_OK);

        /*
         * To insure that the common layered transforms are combined in the
         * correct order, they are processed after the fixed transform.
         */
        if (transform.GetTransformType () == TRANSFORM_TYPE_ROTATE) {
                result = LoadRotateTransform (
                        collada, node, transform, transformTypes, rotateAxes);
        }
        else {
                if (transform.GetTransformType () == TRANSFORM_TYPE_LOOKAT) {
                        result = LoadLookAtTransform (
                                transform, transformTypes);
                }
                else if (transform.GetTransformType () == TRANSFORM_TYPE_MATRIX) {
                        result = LoadMatrixTransform (
                                collada, node, transform, transformTypes);
                }
                else if (transform.GetTransformType () == TRANSFORM_TYPE_SCALE) {
                        if (!node.HasInstanceCamera () &&
                            !node.HasInstanceLight ()) {
                                result = LoadScaleTransform (
                                        collada, node, transform, transformTypes);
                        }
                }
                else if (transform.GetTransformType () == TRANSFORM_TYPE_SKEW) {
                        result = LoadSkewTransform (
                                transform, transformTypes);
                }
                else if (transform.GetTransformType () == TRANSFORM_TYPE_TRANSLATE) {
                        result = LoadTranslateTransform (
                                collada, node, transform, transformTypes);
                }

                /*
                 * Keep the transform type and rotateAxes array synchronized.
                 *
                 * [TODO] This would be unnecessary (and more robust) if the
                 *        transform type and rotateAxes array were both stored
                 *        in a vector of structs that contained both values!
                 */
                rotateAxes.push_back (ROTATE_AXIS_NONE);
        }

        return LOG_ERR (result);
}

/*
 * A lookat element contains a position and orientation
 * transformation suitable for aiming a camera.
 */
        LxResult
COLLADASceneLoader::LoadLookAtTransform (
        TransformElement		&transform,
        TransformTypeArray		&transformTypes)
{
        LxResult			result(LXe_OK);
        Element::DoubleVector3	eyePosition;
        Element::DoubleVector3	interestPosition;
        Element::DoubleVector3	upVector;
        if (transform.GetLookAt (eyePosition, interestPosition, upVector)) {
                /*
                 * [TODO]
                 * If the current item is a camera, simulate a soft
                 * "Set Target" using the lookat transform values.
                 */

                transformTypes.push_back (TRANSFORM_TYPE_LOOKAT);
        }

        return LOG_ERR (result);
}

        static void
ChannelsXYZ (
        const string		&channelBaseName,
        vector<string>		&channelNames,
        bool			 clearChannelNames = true)
{
        if (clearChannelNames) {
                channelNames.clear ();
        }

        string base = channelBaseName + string(ATTRVALUE_DOTSEPARATORSYMBOL);
        channelNames.push_back (base + string(ATTRVALUE_X));
        channelNames.push_back (base + string(ATTRVALUE_Y));
        channelNames.push_back (base + string(ATTRVALUE_Z));
}

        static void
GetAxisNames (
        vector<string>		&axisNames)
{
        axisNames.push_back (string(ATTRVALUE_X));
        axisNames.push_back (string(ATTRVALUE_Y));
        axisNames.push_back (string(ATTRVALUE_Z));
}

        LxResult
COLLADASceneLoader::LoadMatrixTransform (
        COLLADAElement		&collada,
        NodeElement		&node,
        TransformElement	&transform,
        TransformTypeArray	&transformTypes)
{
        LxResult	result(LXe_OK);

        Matrix4		matrix;
        if (transform.GetMatrix (matrix)) {
                double xformValues[math::TransformValue_Count];

                /*
                 * The default rotation order in modo is ZXY.
                 */
                if (Matrix4Decompose (
                        matrix, xformValues,
                        math::ROTATION_ORDER_ZXY)) {
                        /*
                         * Grab the scale, rotation, and translation vectors.
                         */
                        Vector3 vScale;
                        vScale[0] = xformValues[TransformValue_SCALEX];
                        vScale[1] = xformValues[TransformValue_SCALEY];
                        vScale[2] = xformValues[TransformValue_SCALEZ];

                        Vector3 vRot;
                        vRot[0] = xformValues[TransformValue_ROTATEX];
                        vRot[1] = xformValues[TransformValue_ROTATEY];
                        vRot[2] = xformValues[TransformValue_ROTATEZ];

                        Vector3 vTrans;
                        vTrans[0] = xformValues[TransformValue_TRANSX];
                        vTrans[1] = xformValues[TransformValue_TRANSY];
                        vTrans[2] = xformValues[TransformValue_TRANSZ];

                        /*
                         * A matrix contains a full SRT (scale, rotate,
                         * translate) transform, so it can only sit in
                         * the primary transform positions if no other
                         * SRT transforms have been added.
                         */
                        unsigned curItem = scene_build.CurItem ();
                        unsigned scaleItem = NO_ITEM, rotatationItem, translationItem;
                        if (transformTypes.empty ()) {
                                if (!node.HasInstanceCamera ()) {
                                        scene_build.SetXform (LXiXFRM_SCALE, vScale);
                                        scene_build.AddXform (LXiXFRM_SCALE);
                                        scaleItem = scene_build.CurItem ();
                                        scene_build.SetItem (curItem);
                                }

                                /*
                                 * For rotation, set both the angle and order.
                                 */
                                scene_build.SetXform (LXiXFRM_ROTATION, vRot);
                                scene_build.AddXform (LXiXFRM_ROTATION);
                                rotatationItem = scene_build.CurItem ();

                                scene_build.SetChannel (
                                        LXsICHAN_ROTATION_ORDER,
                                        ROTATION_ORDER_ZXY);
                                scene_build.SetItem (curItem);

                                /*
                                 * Leave the last transform as the current item,
                                 * so we can potentially add an envelope.
                                 */
                                scene_build.SetXform (LXiXFRM_POSITION, vTrans);
                                scene_build.AddXform (LXiXFRM_POSITION);
                                translationItem = scene_build.CurItem ();
                                scene_build.SetItem (curItem);
                        }
                        else {
                                scene_build.AppendXform (LXiXFRM_SCALE, vScale);
                                scaleItem = scene_build.CurItem ();
                                scene_build.SetItem (curItem);

                                scene_build.AppendXform (LXiXFRM_ROTATION, vRot);
                                rotatationItem = scene_build.CurItem ();
                                scene_build.SetChannel (
                                        LXsICHAN_ROTATION_ORDER,
                                        ROTATION_ORDER_ZXY);
                                scene_build.SetItem (curItem);

                                scene_build.AppendXform (LXiXFRM_POSITION, vTrans);
                                translationItem = scene_build.CurItem ();
                                scene_build.SetItem (curItem);
                        }
                        /*
                         * Check if we have an animation envelope.
                         */
                        if (LXx_OK (result)) {
                                /*
                                 * Form a node ID and target animation URI fragment.
                                 */
                                string nodeTargetURI =
                                        node.GetID () +
                                        string(ATTRVALUE_PATHSEPARATORSYMBOL) +
                                        transform.GetSID ();
                                if (HasTargetAnimation (collada, nodeTargetURI)) {
                                        /*
                                         * [TODO] Handle subscript indexing into
                                         *        a matrix element from an animation.
                                         */
                                        result = LoadTargetAnimation (
                                                collada, nodeTargetURI,
                                                scaleItem, rotatationItem, translationItem);
                                }
                        }

                        /*
                         * Restore current item back above transform level to layer item level.
                         */
                        scene_build.SetItem (curItem);
                }

                transformTypes.push_back (TRANSFORM_TYPE_MATRIX);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadScaleTransform (
        COLLADAElement		&collada,
        NodeElement		&node,
        TransformElement	&transform,
        TransformTypeArray	&transformTypes)
{
        LxResult	result(LXe_OK);

        Element::DoubleVector3	scale;
        if (transform.GetScale (scale)) {
                unsigned curItem = scene_build.CurItem ();
                if (transformTypes.empty ()) {
                        scene_build.SetXform (LXiXFRM_SCALE, scale);
                        /*
                         * Leave the new transform as the current item,
                         * so we can potentially add an envelope.
                         */
                        scene_build.AddXform (LXiXFRM_SCALE);
                }
                else {
                        scene_build.AppendXform (LXiXFRM_SCALE, scale);
                }

                if (LXx_OK (result)) {
                        /*
                         * Form a node ID and target animation URI fragment.
                         */
                        vector<string> channelNames;
                        ChannelsXYZ (LXsICHAN_SCALE_SCL, channelNames);

                        vector<string> axisNames;
                        GetAxisNames (axisNames);

                        for (unsigned axisIndex = 0; axisIndex < 3; ++axisIndex) {
                                string nodeTargetURI =
                                        node.GetID () +
                                        string(ATTRVALUE_PATHSEPARATORSYMBOL) +
                                        transform.GetSID () +
                                        string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                                        axisNames.at (axisIndex);
                                if (HasTargetAnimation (collada, nodeTargetURI)) {
                                        result = LoadTargetAnimation (
                                                collada, nodeTargetURI,
                                                channelNames.at (axisIndex));
                                }
                        }

                        transformTypes.push_back (TRANSFORM_TYPE_SCALE);
                }

                /*
                 * Restore current item back above transform level to layer item level.
                 */
                scene_build.SetItem (curItem);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadRotateTransform (
        COLLADAElement		&collada,
        NodeElement		&node,
        TransformElement	&transform,
        TransformTypeArray	&transformTypes,
        RotateAxisArray		&rotateAxes)
{
        LxResult			result(LXe_OK);

        Vector3	angles;
        if (transform.GetRotateAngles (angles)) {
                /*
                 * Scan for a rotation, positioned after no more than one
                 * scale element, to determine whether or not to set the
                 * initial rotation vs a post transform.
                 */
                bool	initialRotation(true);

                /*
                 * If we have already processed at least one transform.
                 */
                if (transformTypes.size ()) {
                        if ((transformTypes.size () > 1) ||
                            transformTypes.at (0) != TRANSFORM_TYPE_SCALE) {
                                initialRotation = false;
                        }
                }

                /*
                 * The transform has to be the current item to set the
                 * rotation order channel and to possibly add envelopes
                 * if keyframe data is found.
                 */
                unsigned curItem = scene_build.CurItem ();

                if (initialRotation) {
                        scene_build.SetXform (LXiXFRM_ROTATION, angles);
                        /*
                         * Leave the new transform as the current item,
                         * so we can potentially add an envelope.
                         */
                        scene_build.AddXform (LXiXFRM_ROTATION);
                }
                else {
                        scene_build.AppendXform (LXiXFRM_ROTATION, angles);
                }

                if (LXx_OK (result)) {
                        RotationOrder order =
                                transform.GetRotationOrder ();
                        scene_build.SetChannel (LXsICHAN_ROTATION_ORDER, order);

                        AxisOrder axisOrder;
                        RotationAxisOrder (order, axisOrder);

                        /*
                         * Form a node ID and target animation URI fragment.
                         */
                        vector<string> channelNames;
                        ChannelsXYZ (LXsICHAN_ROTATION_ROT, channelNames);

                        vector<string> sids;
                        transform.GetRotateAxisSIDs (sids);

                        for (unsigned axisIndex = 0; axisIndex < sids.size (); ++axisIndex) {
                                string nodeTargetURI =
                                        node.GetID () +
                                        string(ATTRVALUE_PATHSEPARATORSYMBOL) +
                                        sids.at (axisIndex) +
                                        string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                                        string(ATTRVALUE_ANGLE);
                                if (HasTargetAnimation (collada, nodeTargetURI)) {
                                        result = LoadTargetAnimation (
                                                collada, nodeTargetURI,
                                                channelNames.at (axisOrder[axisIndex]),
                                                DEG2RAD);
                                }
                        }

                        /*
                         * Keep track of the previous transforms.
                         */
                        transformTypes.push_back (TRANSFORM_TYPE_ROTATE);

                        /*
                         * Push back the primary axis of rotation.
                         */
                        rotateAxes.push_back (transform.GetRotateAxis ());
                }

                /*
                 * Restore current item back above transform level to layer item level.
                 */
                scene_build.SetItem (curItem);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadSkewTransform (
        TransformElement		&transform,
        TransformTypeArray		&transformTypes)
{
        LxResult	result(LXe_OK);

        TransformElement::DoubleVectorSkew	skew;
        if (transform.GetSkew (skew)) {
                /*
                 * [TODO] modo 401 doesn't have direct support for
                 *        skew transforms, although skew could be
                 *        simulated by rotating the item and then
                 *        parenting to a group locator with a compen-
                 *        sating rotation combined with a scale and
                 *        translate transform.
                 */

                transformTypes.push_back (TRANSFORM_TYPE_SKEW);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadTranslateTransform (
        COLLADAElement		&collada,
        NodeElement		&node,
        TransformElement	&transform,
        TransformTypeArray	&transformTypes)
{
        LxResult	result(LXe_OK);

        Element::DoubleVector3	translate;
        if (transform.GetTranslate (translate)) {
                /*
                 * Either no initial transforms yet, or an optional initial
                 * scale, followed by an optional initial rotation, with
                 * no earlier translation transforms.
                 */
                bool optionalSRnoT = transformTypes.empty ();
                if (!optionalSRnoT) {
                        unsigned count = static_cast<unsigned>(
                                transformTypes.size ());
                        optionalSRnoT = (count < 3);
                        if (optionalSRnoT) {
                                TransformType firstType = transformTypes.at (0);
                                if (count == 1) {
                                        optionalSRnoT =
                                                (firstType == TRANSFORM_TYPE_SCALE ||
                                                 firstType == TRANSFORM_TYPE_ROTATE);
                                }
                                else if (count == 2) {
                                        TransformType secondType =
                                                transformTypes.at (1);
                                        optionalSRnoT = (firstType == TRANSFORM_TYPE_SCALE &&
                                                         secondType == TRANSFORM_TYPE_ROTATE);
                                }
                        }
                }

                unsigned curItem = scene_build.CurItem ();

                /*
                 * Check for a modo profile technique on the node,
                 * and if present, look for a pivot-to-inverse
                 * entry, and the transform sub-type.
                 */
                string transformSubType;
                string linkedTransformID;
                bool haveTransformSubType(false);
                NodeElement_modo401 node_modo401(node);
                if (node.LinkTechniqueProfile_modo401 (node_modo401)) {
                        haveTransformSubType = node_modo401.GetTransformLink (
                                transform.GetSID (), transformSubType, linkedTransformID);
                }

                /*
                 * Inverses do not have animation envelopes, so add the
                 * transform item, link it, and return.
                 */
                if (haveTransformSubType &&
                    (transformSubType == string(LXsICVAL_TRANSFORM_TYPE_INVERSE))) {
                        unsigned transformIndex =
                                scene_build.AddItem (LXsITYPE_TRANSFORM);
                        scene_build.SetName (transform.GetSID ().c_str ());
                        scene_build.SetChannelEncoded (
                                LXsICHAN_TRANSFORM_TYPE,
                                LXsICVAL_TRANSFORM_TYPE_INVERSE);

                        /*
                         * Link the inverse transform into the core graph.
                         */
                        scene_build.SetLink (LXsGRAPH_XFRMCORE, curItem);

                        /*
                         * Store the transform index so we can link the inverse to
                         * its pivot in the local graph when we reach that pivot
                         * in the local transform sequence.
                         */
                        transformIDIndexMap[transform.GetSID ()] = transformIndex;
                }
                else {
                        if (optionalSRnoT) {
                                scene_build.SetXform (LXiXFRM_POSITION, translate);
                                /*
                                 * Leave the new transform as the current item,
                                 * so we can potentially add an envelope.
                                 */
                                scene_build.AddXform (LXiXFRM_POSITION);
                        }
                        else {
                                scene_build.AppendXform (LXiXFRM_POSITION, translate);
                        }

                        if (LXx_OK (result)) {
                                /*
                                 * Check for a modo profile technique on the node,
                                 * and if present, look for a pivot-to-inverse
                                 * entry, and the transform sub-type.
                                 */
                                NodeElement_modo401 node_modo401(node);
                                if (haveTransformSubType) {
                                        /*
                                         * If the transform is a pivot translation,
                                         * set its transform subtype.
                                         */
                                        scene_build.SetChannelEncoded (
                                                LXsICHAN_TRANSFORM_TYPE,
                                                transformSubType.c_str ());
                                        if (transformSubType == string(LXsICVAL_TRANSFORM_TYPE_PIVOT)) {
                                                NodeIDIndexMap::const_iterator iter =
                                                        transformIDIndexMap.find(linkedTransformID);
                                                if (iter != transformIDIndexMap.end ()) {
                                                        unsigned linkIndex = iter->second;
                                                        scene_build.SetLink (
                                                                LXsGRAPH_XFRMLOCAL, linkIndex);
                                                }
                                        }
                                }

                                /*
                                 * Look for an animation envelope on each axis, forming a
                                 * target animation URI fragment from the node ID and
                                 * the axis names.
                                 */
                                vector<string> channelNames;
                                ChannelsXYZ (LXsICHAN_TRANSLATION_POS, channelNames);

                                vector<string> axisNames;
                                GetAxisNames (axisNames);

                                for (unsigned axisIndex = 0; axisIndex < 3; ++axisIndex) {
                                        string nodeTargetURI =
                                                node.GetID () +
                                                string(ATTRVALUE_PATHSEPARATORSYMBOL) +
                                                transform.GetSID () +
                                                string(ATTRVALUE_DOTSEPARATORSYMBOL) +
                                                axisNames.at (axisIndex);
                                        if (HasTargetAnimation (collada, nodeTargetURI)) {
                                                result = LoadTargetAnimation (
                                                        collada, nodeTargetURI,
                                                        channelNames.at (axisIndex));
                                        }
                                }

                                transformTypes.push_back (TRANSFORM_TYPE_TRANSLATE);
                        }
                }

                /*
                 * Restore current item back above transform level to layer item level.
                 */
                scene_build.SetItem (curItem);
        }

        return LOG_ERR (result);
}

/*
 * Check the animation map for the given target animation SID.
 */
        bool
COLLADASceneLoader::HasTargetAnimation (
        COLLADAElement		&collada,
        const string		&nodeTargetURI) const
{
        return animationMap.find (nodeTargetURI) != animationMap.end ();
}

/*
 * Be sure to first check for the animation with HasTargetAnimation, because
 * this function returns a LXe_NOTFOUND error if the animation isn't found.
 */
        LxResult
COLLADASceneLoader::LoadTargetAnimation (
        COLLADAElement		&collada,
        const string		&nodeTargetURI,
        const string		&channelName,
        double			 valueScale)
{
        LxResult	result(LXe_NOTFOUND);

        /*
         * Lookup the corresponding animation ID by the targeted transform ID.
         */

        AnimationLibraryElement library(collada);
        AnimationElement	animation(library);
        ElementXMLID animationElement = animationMap[nodeTargetURI];

        animation.SetElement(animationElement);

        /*
         * Find the channel that corresponds to our transformSID.
         */
        if (animation.HasChannel ()) {
                AnimationChannelElement	animationChannel(animation);
                if (animation.HasSampler () &&
                    animation.LinkFirstChannel (animationChannel)) {
                        bool	found(false);
                        bool	haveChannel(true);
                        do {
                                if (animationChannel.GetTarget () == nodeTargetURI) {
                                        string	samplerID = StripURI_Ref (
                                                animationChannel.GetSamplerURI ());
                                        AnimationSamplerElement	sampler(animation);
                                        if (animation.LinkSampler (samplerID, sampler)) {
                                                found = true;
                                                result = LoadAnimationSampler (
                                                        animation, sampler,
                                                        channelName,
                                                        valueScale);
                                        }
                                }
                                else {
                                        haveChannel = animationChannel.LinkNextChannel (
                                                animationChannel);
                                }
                        } while (haveChannel && !found);
                }
        }

        return LOG_ERR (result);
}

/*
 * Be sure to first check for the animation with HasTargetAnimation, because
 * this function returns a LXe_NOTFOUND error if the animation isn't found.
 */
        LxResult
COLLADASceneLoader::LoadTargetAnimation (
        COLLADAElement		&collada,
        const string		&nodeTargetURI,
        unsigned		 scaleItem,
        unsigned		 rotateItem,
        unsigned		 translateItem)
{
        LxResult	result(LXe_NOTFOUND);

        /*
         * Lookup the corresponding animation ID by the targeted transform ID.
         */
        AnimationLibraryElement library(collada);
        AnimationElement animation(library);
        ElementXMLID animationElement = animationMap[nodeTargetURI];

        animation.SetElement(animationElement);

        /*
         * Find the channel that corresponds to our transformSID.
         */
        if (animation.HasChannel ()) {
                AnimationChannelElement	animationChannel(animation);
                if (animation.HasSampler () &&
                    animation.LinkFirstChannel (animationChannel)) {
                        bool	found(false);
                        bool	haveChannel(true);
                        do {
                                if (animationChannel.GetTarget () == nodeTargetURI) {
                                        string	samplerID = StripURI_Ref (
                                                animationChannel.GetSamplerURI ());
                                        AnimationSamplerElement	sampler(animation);
                                        if (animation.LinkSampler (samplerID, sampler)) {
                                                found = true;
                                                result = LoadAnimationSampler (
                                                        animation, sampler,
                                                        scaleItem,
                                                        rotateItem,
                                                        translateItem);
                                        }
                                }
                                else {
                                        haveChannel = animationChannel.LinkNextChannel (
                                                animationChannel);
                                }
                        } while (haveChannel && !found);
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadAnimationSampler (
        AnimationElement	&animation,
        AnimationSamplerElement	&sampler,
        const string		&channelName,
        double			 valueScale)
{
        LxResult	result(LXe_NOTFOUND);

        AnimationSamplerInputElement samplerInputInput(sampler);
        AnimationSamplerInputElement samplerInputOutput(sampler);
        AnimationSamplerInputElement samplerInputInterpolation(sampler);
        AnimationSamplerInputElement samplerInputInTangent(sampler);
        AnimationSamplerInputElement samplerInputOutTangent(sampler);

        bool haveInputSemantic = sampler.LinkInput (
                ATTRVALUE_TIME_INPUT_SEMANTIC, samplerInputInput);
        bool haveOutputSemantic = sampler.LinkInput (
                ATTRVALUE_OUTPUT_INPUT_SEMANTIC, samplerInputOutput);

        bool haveInterpSemantic = sampler.LinkInput (
                ATTRVALUE_INTERPOLATION_INPUT_SEMANTIC, samplerInputInterpolation);

        bool haveInTangentSemantic = sampler.LinkInput (
                ATTRVALUE_IN_TANGENT_INPUT_SEMANTIC, samplerInputInTangent);
        bool haveOutTangentSemantic = sampler.LinkInput (
                ATTRVALUE_OUT_TANGENT_INPUT_SEMANTIC, samplerInputOutTangent);

        /*
         * The interpolation semantic is mandatory, but we also require at
         * least an input and output semantic to create an envelope.
         */
        if (haveInputSemantic && haveOutputSemantic && haveInterpSemantic) {
                AnimationSourceElement sourceInput(animation);
                AnimationSourceElement sourceOutput(animation);
                AnimationSourceElement sourceInterpolation(animation);

                bool haveInputSource = animation.LinkSource (
                        StripURI_Ref (samplerInputInput.GetSourceURI ()), sourceInput);
                bool haveOutputSource = animation.LinkSource (
                        StripURI_Ref (samplerInputOutput.GetSourceURI ()), sourceOutput);
                bool haveInterpolationSource = animation.LinkSource (
                        StripURI_Ref (samplerInputInterpolation.GetSourceURI ()), sourceInterpolation);

                if (haveInputSource && haveOutputSource && haveInterpolationSource) {
                        if (haveInTangentSemantic && haveOutTangentSemantic) {
                                AnimationSamplerInputElement samplerInTanSlopeWeights(sampler);
                                AnimationSamplerInputElement samplerOutTanSlopeWeights(sampler);

                                bool haveInTanSlopeWeightSemantic = sampler.LinkInput (
                                        ATTRVALUE_IN_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC,
                                        samplerInTanSlopeWeights);
                                bool haveOutTanSlopeWeightSemantic = sampler.LinkInput (
                                        ATTRVALUE_OUT_TANGENT_SLOPEWEIGHT_INPUT_SEMANTIC,
                                        samplerOutTanSlopeWeights);

                                if (haveInTanSlopeWeightSemantic && haveOutTanSlopeWeightSemantic) {
                                        AnimationSourceElement sourceInTanSlopeWeights(animation);
                                        AnimationSourceElement sourceOutTanSlopeWeights(animation);
                                        bool haveInTanSlopeWeightSource = animation.LinkSource (
                                                StripURI_Ref (samplerInTanSlopeWeights.GetSourceURI ()),
                                                sourceInTanSlopeWeights);
                                        bool haveOutTanSlopeWeightSource = animation.LinkSource (
                                                StripURI_Ref (samplerOutTanSlopeWeights.GetSourceURI ()),
                                                sourceOutTanSlopeWeights);
                                        if (haveInTanSlopeWeightSource && haveOutTanSlopeWeightSource) {
                                                /*
                                                 * Check for broken keyframes.
                                                 */
                                                AnimationSamplerInputElement samplerInputBrokenOutput(sampler);
                                                AnimationSamplerInputElement samplerInputBrokenOutputTimes(sampler);
                                                bool haveBrokenOutput = sampler.LinkInput (
                                                        ATTRVALUE_BROKEN_OUTPUTS_INPUT_SEMANTIC,
                                                        samplerInputBrokenOutput);
                                                bool haveBrokenOutputTimes = sampler.LinkInput (
                                                        ATTRVALUE_BROKEN_OUTPUT_TIMES_INPUT_SEMANTIC,
                                                        samplerInputBrokenOutputTimes);

                                                AnimationSamplerInputElement samplerInputBrokenInTangentOutputs(sampler);
                                                AnimationSamplerInputElement samplerInputBrokenOutTangentOutputs(sampler);
                                                bool haveBrokenInTangentOutputs = sampler.LinkInput (
                                                        ATTRVALUE_IN_TANGENT_OUTPUT_INPUT_SEMANTIC,
                                                        samplerInputBrokenInTangentOutputs);
                                                bool haveBrokenOutTangentOutputs = sampler.LinkInput (
                                                        ATTRVALUE_OUT_TANGENT_OUTPUT_INPUT_SEMANTIC,
                                                        samplerInputBrokenOutTangentOutputs);

                                                AnimationSourceElement sourceBrokenOutput(animation);
                                                AnimationSourceElement sourceBrokenOutputTimes(animation);
                                                AnimationSourceElement sourceBrokenInTangentOutputs(animation);
                                                AnimationSourceElement sourceBrokenOutTangentOutputs(animation);
                                                if (haveBrokenOutput &&
                                                    haveBrokenOutputTimes &&
                                                    haveBrokenInTangentOutputs &&
                                                    haveBrokenOutTangentOutputs) {
                                                        bool haveBrokenOutputSource =
                                                                animation.LinkSource (StripURI_Ref (
                                                                        samplerInputBrokenOutput.GetSourceURI ()),
                                                                        sourceBrokenOutput);
                                                        bool haveBrokenOutputTimesSource =
                                                                animation.LinkSource (StripURI_Ref (
                                                                        samplerInputBrokenOutputTimes.GetSourceURI ()),
                                                                        sourceBrokenOutputTimes);

                                                        bool haveBrokenInTangentOutputsSource =
                                                                animation.LinkSource (StripURI_Ref (
                                                                        samplerInputBrokenInTangentOutputs.GetSourceURI ()),
                                                                        sourceBrokenInTangentOutputs);
                                                        bool haveBrokenOutTangentOutputsSource =
                                                                animation.LinkSource (StripURI_Ref (
                                                                        samplerInputBrokenOutTangentOutputs.GetSourceURI ()),
                                                                        sourceBrokenOutTangentOutputs);
                                                        if (haveBrokenOutputSource &&
                                                            haveBrokenOutputTimesSource &&
                                                            haveBrokenInTangentOutputsSource &&
                                                            haveBrokenOutTangentOutputsSource) {
                                                                result = LoadAnimationEnvelopeTangentsBroken_modo501 (
                                                                        sourceInput, sourceOutput,
                                                                        sourceInterpolation,
                                                                        sourceInTanSlopeWeights,
                                                                        sourceOutTanSlopeWeights,
                                                                        sourceBrokenOutput,
                                                                        sourceBrokenOutputTimes,
                                                                        sourceBrokenInTangentOutputs,
                                                                        sourceBrokenOutTangentOutputs,
                                                                        channelName, valueScale);
                                                        }
                                                }
                                                else {
                                                        result = LoadAnimationEnvelopeTangents_modo501 (
                                                                sourceInput, sourceOutput,
                                                                sourceInterpolation,
                                                                sourceInTanSlopeWeights,
                                                                sourceOutTanSlopeWeights,
                                                                channelName, valueScale);
                                                }
                                        }
                                }
                                else {
                                        AnimationSourceElement sourceInTangent(animation);
                                        AnimationSourceElement sourceOutTangent(animation);

                                        result = LoadAnimationEnvelopeTangents (
                                                sourceInput, sourceOutput,
                                                sourceInterpolation,
                                                &sourceInTangent, &sourceOutTangent,
                                                channelName, valueScale);
                                }
                        }
                        else {
                                result = LoadAnimationEnvelope (
                                        sourceInput, sourceOutput,
                                        sourceInterpolation,
                                        channelName, valueScale);
                        }
                }
        }
        else {
                /*
                 * The sample COLLADA file "Moon Buggy/lunar_vehicle_tris.dae"
                 * is missing the required INTERPOLATION input for one of its
                 * sampler elements, but we'll process it anyways, just to
                 * pass any compliance tests that require the flexibility
                 * to read invalid COLLADA data as best as possible.
                 *
                 * Since "Moon Buggy" fails the coherency test, perhaps it
                 * should be removed from the sample library, or at least
                 * loaded into Maya and saved back out as a valid COLLADA
                 * document, that passes the Coherency Test tool?
                 *
                 * What's the point of the Coherency Test tool if the
                 * consortium's own samples don't even pass without errors?
                 */
                log.Info ("LoadAnimationSampler: Required INTERPOLATION not found!");
                log.Info ("LoadAnimationSampler: Processing invalid document.");

                /*
                 * Continue on, with the non-fatal "FALSE" error.
                 */
                result = LXe_FALSE;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadAnimationSampler (
        AnimationElement	&animation,
        AnimationSamplerElement	&sampler,
        unsigned		 scaleItem,
        unsigned		 rotateItem,
        unsigned		 translateItem)
{
        LxResult	result(LXe_NOTFOUND);

        AnimationSamplerInputElement samplerInputInput(sampler);
        AnimationSamplerInputElement samplerInputOutput(sampler);
        AnimationSamplerInputElement samplerInputInterpolation(sampler);
        AnimationSamplerInputElement samplerInputInTangent(sampler);
        AnimationSamplerInputElement samplerInputOutTangent(sampler);

        bool haveInputSemantic = sampler.LinkInput (
                ATTRVALUE_TIME_INPUT_SEMANTIC, samplerInputInput);
        bool haveOutputSemantic = sampler.LinkInput (
                ATTRVALUE_OUTPUT_INPUT_SEMANTIC, samplerInputOutput);

        bool haveInterpSemantic = sampler.LinkInput (
                ATTRVALUE_INTERPOLATION_INPUT_SEMANTIC, samplerInputInterpolation);

        /*
         * The interpolation semantic is mandatory, but the in and out
         * tangents are optional.
         */
        if (haveInputSemantic && haveOutputSemantic && haveInterpSemantic) {
                AnimationSourceElement sourceInput(animation);
                AnimationSourceElement sourceOutput(animation);
                AnimationSourceElement sourceInterpolation(animation);

                bool haveInputSource = animation.LinkSource (
                        StripURI_Ref (samplerInputInput.GetSourceURI ()), sourceInput);
                bool haveOutputSource = animation.LinkSource (
                        StripURI_Ref (samplerInputOutput.GetSourceURI ()), sourceOutput);

                bool haveInterpolationSource = animation.LinkSource (
                        StripURI_Ref (samplerInputInterpolation.GetSourceURI ()), sourceInterpolation);

                if (haveInputSource && haveOutputSource && haveInterpolationSource) {
                        result = LoadAnimationEnvelope (
                                sourceInput, sourceOutput,
                                sourceInterpolation,
                                scaleItem, rotateItem, translateItem);
                }
        }
        else {
                /*
                 * The sample COLLADA file "Moon Buggy/lunar_vehicle_tris.dae"
                 * is missing the required INTERPOLATION input for one of its
                 * sampler elements, but we'll process the rest of the file
                 * anyways, just to pass any compliance tests that require
                 * the flexibility to read invalid COLLADA data as best as
                 * possible.
                 *
                 * Since "Moon Buggy" fails the coherency test, perhaps it
                 * should be removed from the sample library, or at least
                 * loaded into Maya and saved back out as a valid COLLADA
                 * document, that passes the Coherency Test tool?
                 *
                 * What's the point of the Coherency Test tool if the
                 * consortium's own samples don't even pass without errors?
                 */
                log.Info ("LoadAnimationSampler: Required INTERPOLATION not found!");
                log.Info ("LoadAnimationSampler: Processing invalid document.");

                /*
                 * Continue on, with the non-fatal "FALSE" error.
                 */
                result = LXe_FALSE;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadAnimationEnvelope (
        AnimationSourceElement	&sourceInput,
        AnimationSourceElement	&sourceOutput,
        AnimationSourceElement	&sourceInterpolation,
        const string		&channelName,
        double			 valueScale)
{
        return LoadAnimationEnvelopeTangents (
                sourceInput, sourceOutput,
                sourceInterpolation,
                NULL, NULL,
                channelName,
                valueScale);
}

        LxResult
COLLADASceneLoader::LoadAnimationEnvelopeTangents (
        AnimationSourceElement	&sourceInput,
        AnimationSourceElement	&sourceOutput,
        AnimationSourceElement	&sourceInterpolation,
        AnimationSourceElement	*sourceInTangents,
        AnimationSourceElement	*sourceOutTangents,
        const string		&channelName,
        double			 valueScale)
{
        LxResult	result(LXe_NOTFOUND);

        Element::FloatArray	times;
        Element::FloatArray	values;
        Element::InterpArray	interps;
        if (sourceInput.LinkFloatArray (times) &&
            sourceOutput.LinkFloatArray (values) &&
            sourceInterpolation.LinkInterpArray (interps)) {
                Element::FloatArray	inTanX, inTanY;
                Element::FloatArray	outTanX, outTanY;
                bool			haveInTangents = false, haveOutTangents = false,
                                        haveTangents;

                if (sourceInTangents != NULL) {
                        haveInTangents = sourceInTangents->LinkFloatPairArray (inTanX, inTanY);
                }

                if (sourceOutTangents != NULL) {
                        haveOutTangents = sourceOutTangents->LinkFloatPairArray (outTanX, outTanY);
                }
                haveTangents = haveInTangents && haveOutTangents && (inTanX.size () == outTanX.size ());

                /*
                 * Determine the channel for which we're adding an envelope.
                 */
                CLxUser_Envelope	env;
                scene_build.AddEnvelope (channelName.c_str (), env);

                /*
                 * Minimal envelope has keyframe times and values.
                 */
                Element::FloatArray::const_iterator valueIter = values.begin ();
                Element::InterpArray::const_iterator interpIter = interps.begin ();
                unsigned tanIndex = 0;
                for (Element::FloatArray::const_iterator timeIter = times.begin ();
                        timeIter != times.end () && valueIter != values.end ();
                        ++timeIter, ++valueIter, ++interpIter) {
                        float	time = *timeIter;
                        float	value = static_cast<float>(*valueIter * valueScale);
                        Element::Interpolation	interp = *interpIter;

                        CLxUser_Keyframe	 key;
                        key.fromEnvObject (env);
                        key.AddF (time, value);

                        float weightIn = 1.0f, weightOut = 1.0f;
                        if (haveTangents) {
                                float inTan[2], outTan[2];

                                inTan[0] = inTanX.at (tanIndex);
                                inTan[1] = inTanY.at (tanIndex);
                                outTan[0] = outTanX.at (tanIndex);
                                outTan[1] = outTanY.at (tanIndex);

                                weightIn = sqrt (inTan[0] * inTan[0] + inTan[1] * inTan[1]);
                                weightOut = sqrt (outTan[0] * outTan[0] + outTan[1] * outTan[1]);
                        }
                        if (interp == Element::INTERPOLATION_LINEAR) {
                                key.SetSlopeType (LXiSLOPE_LINEAR_IN, LXiENVSIDE_IN);
                                key.SetSlopeType (LXiSLOPE_LINEAR_OUT, LXiENVSIDE_OUT);
                        }
                        else if ((interp == Element::INTERPOLATION_BEZIER) && haveTangents) {
                                /*
                                 * [TODO] Recreate the slope.
                                 */
                                if (weightIn == weightOut) {
                                        key.SetWeight (
                                                weightIn,
                                                0, LXiENVSIDE_BOTH);
                                }
                                else {
                                        key.SetWeight (
                                                weightIn,
                                                0, LXiENVSIDE_IN); // don't reset to auto
                                        key.SetWeight (
                                                weightOut,
                                                0, LXiENVSIDE_OUT);
                                }
                        }

                        ++tanIndex;
                }

                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadAnimationEnvelopeTangents_modo501 (
        AnimationSourceElement		&sourceInput,
        AnimationSourceElement		&sourceOutput,
        AnimationSourceElement		&sourceInterpolation,
        AnimationSourceElement		&sourceInTanSlopeWeights,
        AnimationSourceElement		&sourceOutTanSlopeWeights,
        const string			&channelName,
        double				 valueScale)
{
        LxResult		result(LXe_NOTFOUND);

        Element::FloatArray	times;
        Element::FloatArray	values;
        Element::InterpArray	interps;
        Element::FloatArray	inTanSlopes, inTanWeights;
        Element::FloatArray	outTanSlopes, outTanWeights;

        if (sourceInput.LinkFloatArray (times) &&
            sourceOutput.LinkFloatArray (values) &&
            sourceInterpolation.LinkInterpArray (interps) &&
            sourceInTanSlopeWeights.LinkFloatPairArray (inTanSlopes, inTanWeights) &&
            sourceOutTanSlopeWeights.LinkFloatPairArray (outTanSlopes, outTanWeights)) {
                /*
                 * Determine the channel for which we're adding an envelope.
                 */
                CLxUser_Envelope	env;
                scene_build.AddEnvelope (channelName.c_str (), env);

                /*
                 * Full envelope has keyframe times, values, and tangents.
                 */
                Element::FloatArray::const_iterator valueIter = values.begin ();
                Element::InterpArray::const_iterator interpIter = interps.begin ();
                Element::FloatArray::const_iterator inTanSlopesIter = inTanSlopes.begin ();
                Element::FloatArray::const_iterator inTanWeightsIter = inTanWeights.begin ();
                Element::FloatArray::const_iterator outTanSlopesIter = outTanSlopes.begin ();
                Element::FloatArray::const_iterator outTanWeightsIter = outTanWeights.begin ();

                for (Element::FloatArray::const_iterator timeIter = times.begin ();
                        timeIter != times.end () && valueIter != values.end () &&
                        interpIter != interps.end () &&
                        inTanSlopesIter != inTanSlopes.end () &&
                        inTanWeightsIter != inTanWeights.end () &&
                        outTanSlopesIter != outTanSlopes.end () &&
                        outTanWeightsIter != outTanWeights.end ();
                        ++timeIter, ++valueIter, ++interpIter,
                        ++inTanSlopesIter, ++inTanWeightsIter,
                        ++outTanSlopesIter, ++outTanWeightsIter) {
                        float	time = *timeIter;
                        float	value = static_cast<float>(*valueIter * valueScale);
                        Element::Interpolation	interp = *interpIter;

                        CLxUser_Keyframe	key;
                        key.fromEnvObject (env);
                        key.AddF (time, value);

                        if (interp == Element::INTERPOLATION_LINEAR) {
                                key.SetSlopeType (LXiSLOPE_LINEAR_IN, LXiENVSIDE_IN);
                                key.SetSlopeType (LXiSLOPE_LINEAR_OUT, LXiENVSIDE_OUT);
                        }
                        else if (interp == Element::INTERPOLATION_BEZIER) {
                                /*
                                 * Set the slopes before the weights,
                                 * since changing the slope type generates
                                 * fresh default weight values.
                                 */
                                key.SetSlopeType (LXiSLOPE_DIRECT, LXiENVSIDE_IN);
                                key.SetSlopeType (LXiSLOPE_DIRECT, LXiENVSIDE_OUT);

                                key.SetSlope (*inTanSlopesIter, LXiENVSIDE_IN);
                                key.SetSlope (*outTanSlopesIter, LXiENVSIDE_OUT);

                                key.SetWeight (
                                        *inTanWeightsIter,
                                        0, LXiENVSIDE_IN); // don't reset to auto
                                key.SetWeight (
                                        *outTanWeightsIter,
                                        0, LXiENVSIDE_OUT);
                        }
                }
                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadAnimationEnvelopeTangentsBroken_modo501 (
        AnimationSourceElement		&sourceInput,
        AnimationSourceElement		&sourceOutput,
        AnimationSourceElement		&sourceInterpolation,
        AnimationSourceElement		&sourceInTanSlopeWeights,
        AnimationSourceElement		&sourceOutTanSlopeWeights,
        AnimationSourceElement		&sourceBrokenOutputs,
        AnimationSourceElement		&sourceBrokenOutputTimes,
        AnimationSourceElement		&sourceBrokenInTangentOutputs,
        AnimationSourceElement		&sourceBrokenOutTangentOutputs,
        const string			&channelName,
        double				 valueScale)
{
        LxResult		result(LXe_NOTFOUND);

        Element::FloatArray	times;
        Element::FloatArray	values;
        Element::InterpArray	interps;
        Element::FloatArray	inTanSlopes, inTanWeights;
        Element::FloatArray	outTanSlopes, outTanWeights;
        Element::BoolArray	brokenOutputs;
        Element::FloatArray	brokenOutputTimes;
        Element::FloatArray	brokenInTangentOutputs;
        Element::FloatArray	brokenOutTangentOutputs;

        if (sourceInput.LinkFloatArray (times) &&
            sourceOutput.LinkFloatArray (values) &&
            sourceInterpolation.LinkInterpArray (interps) &&
            sourceInTanSlopeWeights.LinkFloatPairArray (inTanSlopes, inTanWeights) &&
            sourceOutTanSlopeWeights.LinkFloatPairArray (outTanSlopes, outTanWeights) &&
            sourceBrokenOutputs.LinkBoolArray (brokenOutputs) &&
            sourceBrokenOutputTimes.LinkFloatArray (brokenOutputTimes) &&
            sourceBrokenInTangentOutputs.LinkFloatArray (brokenInTangentOutputs) &&
            sourceBrokenOutTangentOutputs.LinkFloatArray (brokenOutTangentOutputs)) {
                /*
                 * Determine the channel for which we're adding an envelope.
                 */
                CLxUser_Envelope	env;
                scene_build.AddEnvelope (channelName.c_str (), env);

                /*
                 * Full envelope has keyframe times, values, and tangents.
                 */
                Element::FloatArray::const_iterator valueIter = values.begin ();
                Element::InterpArray::const_iterator interpIter = interps.begin ();
                Element::FloatArray::const_iterator inTanSlopesIter = inTanSlopes.begin ();
                Element::FloatArray::const_iterator inTanWeightsIter = inTanWeights.begin ();
                Element::FloatArray::const_iterator outTanSlopesIter = outTanSlopes.begin ();
                Element::FloatArray::const_iterator outTanWeightsIter = outTanWeights.begin ();
                Element::BoolArray::const_iterator brokenOutputsIter = brokenOutputs.begin ();
                Element::FloatArray::const_iterator brokenOutputTimesIter = brokenOutputTimes.begin ();

                Element::FloatArray::const_iterator brokenInTangentOutputsIter = brokenInTangentOutputs.begin ();
                Element::FloatArray::const_iterator brokenOutTangentOutputsIter = brokenOutTangentOutputs.begin ();

                for (Element::FloatArray::const_iterator timeIter = times.begin ();
                        timeIter != times.end () && valueIter != values.end () &&
                        interpIter != interps.end () &&
                        inTanSlopesIter != inTanSlopes.end () &&
                        inTanWeightsIter != inTanWeights.end () &&
                        outTanSlopesIter != outTanSlopes.end () &&
                        outTanWeightsIter != outTanWeights.end () &&
                        brokenOutputsIter != brokenOutputs.end ();
                        ++timeIter, ++valueIter, ++interpIter,
                        ++inTanSlopesIter, ++inTanWeightsIter,
                        ++outTanSlopesIter, ++outTanWeightsIter,
                        ++brokenOutputsIter) {
                        float	time = *timeIter;
                        float	value = static_cast<float>(*valueIter * valueScale);
                        Element::Interpolation	interp = *interpIter;

                        CLxUser_Keyframe	key;
                        key.fromEnvObject (env);
                        key.AddF (time, value);

                        /*
                         * Check if the value, weight, or slope is broken.
                         */
                        if (*brokenOutputsIter && (*brokenOutputTimesIter == time)) {
                                float inTanOutputValue, outTanOutputValue;

                                inTanOutputValue = *brokenInTangentOutputsIter++;
                                outTanOutputValue = *brokenOutTangentOutputsIter++;

                                key.SetValueF (inTanOutputValue * valueScale, LXiENVSIDE_IN);
                                key.SetValueF (outTanOutputValue * valueScale, LXiENVSIDE_OUT);

                                /*
                                 * Advance to the next broken time and output value.
                                 */
                                if (brokenOutputTimesIter != brokenOutputTimes.end ()) {
                                        ++brokenOutputTimesIter;
                                }
                        }

                        if (interp == Element::INTERPOLATION_LINEAR) {
                                key.SetSlopeType (LXiSLOPE_LINEAR_IN, LXiENVSIDE_IN);
                                key.SetSlopeType (LXiSLOPE_LINEAR_OUT, LXiENVSIDE_OUT);
                        }
                        else if (interp == Element::INTERPOLATION_BEZIER) {


                                /*
                                 * Set the slopes before the weights,
                                 * since changing the slope type generates
                                 * fresh default weight values.
                                 */
                                key.SetSlopeType (LXiSLOPE_DIRECT, LXiENVSIDE_IN);
                                key.SetSlopeType (LXiSLOPE_DIRECT, LXiENVSIDE_OUT);

                                key.SetSlope (*inTanSlopesIter, LXiENVSIDE_IN);
                                key.SetSlope (*outTanSlopesIter, LXiENVSIDE_OUT);

                                key.SetWeight (
                                        *inTanWeightsIter,
                                        0, LXiENVSIDE_IN); // don't reset to auto
                                key.SetWeight (
                                        *outTanWeightsIter,
                                        0, LXiENVSIDE_OUT);
                        }
                }
                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadAnimationEnvelope (
        AnimationSourceElement	&sourceInput,
        AnimationSourceElement	&sourceOutput,
        AnimationSourceElement	&sourceInterpolation,
        unsigned		 scaleItem,
        unsigned		 rotateItem,
        unsigned		 translateItem)
{
        LxResult	result(LXe_NOTFOUND);

        Element::FloatArray		times;
        Matrix4Array			matrices;
        Element::InterpArray		interps;
        if (sourceInput.LinkFloatArray (times) &&
            sourceOutput.LinkMatrixArray (matrices) &&
            sourceInterpolation.LinkInterpArray (interps)) {
                /*
                 * Add the scale, rotate, and translate envelopes.
                 */
                CLxUser_Envelope	envScale[3];
                if (scaleItem != NO_ITEM) {
                        AddAnimationEnvelope (LXsICHAN_SCALE_SCL, scaleItem, envScale);
                }
                CLxUser_Envelope	envRotate[3];
                AddAnimationEnvelope (LXsICHAN_ROTATION_ROT, rotateItem, envRotate);
                CLxUser_Envelope	envTranslate[3];
                AddAnimationEnvelope (LXsICHAN_TRANSLATION_POS, translateItem, envTranslate);

                /*
                 * Iterate over each matrix, decomposing each one into
                 * separate scale, rotation, and translation transforms.
                 */
                for (unsigned matrixIndex = 0;
                     matrixIndex < matrices.size (); ++matrixIndex) {
                        double xformValues[TransformValue_Count];

                        /*
                         * The default rotation order in modo is ZXY.
                         */
                        if (Matrix4Decompose (
                                matrices.at (matrixIndex).m, xformValues,
                                ROTATION_ORDER_ZXY)) {
                                Element::Interpolation interp =
                                        interps.at (matrixIndex);

                                LXxUNUSED (interp);

                                /*
                                 * Grab the scale, rotation, and translation vectors.
                                 */
                                Vector3 vScale;
                                vScale[0] = xformValues[TransformValue_SCALEX];
                                vScale[1] = xformValues[TransformValue_SCALEY];
                                vScale[2] = xformValues[TransformValue_SCALEZ];

                                Vector3 vRot;
                                vRot[0] = xformValues[TransformValue_ROTATEX];
                                vRot[1] = xformValues[TransformValue_ROTATEY];
                                vRot[2] = xformValues[TransformValue_ROTATEZ];

                                Vector3 vTrans;
                                vTrans[0] = xformValues[TransformValue_TRANSX];
                                vTrans[1] = xformValues[TransformValue_TRANSY];
                                vTrans[2] = xformValues[TransformValue_TRANSZ];

                                /*
                                 * Minimal envelope has keyframe times and values.
                                 */
                                float	time = times.at (matrixIndex);
                                for (unsigned axisIndex = 0; axisIndex < 3; ++axisIndex) {
                                        if (scaleItem != NO_ITEM) {
                                                float	scaleValue =
                                                        static_cast<float>(vScale[axisIndex]);
                                                CLxUser_Keyframe	 scaleKey;
                                                scaleKey.fromEnvObject (envScale[axisIndex]);
                                                scaleKey.AddF (time, scaleValue);
                                        }

                                        float	rotateValue =
                                                static_cast<float>(vRot[axisIndex]);
                                        CLxUser_Keyframe	 rotateKey;
                                        rotateKey.fromEnvObject (envRotate[axisIndex]);
                                        rotateKey.AddF (time, rotateValue);

                                        float	translateValue =
                                                static_cast<float>(vTrans[axisIndex]);
                                        CLxUser_Keyframe	 translateKey;
                                        translateKey.fromEnvObject (envTranslate[axisIndex]);
                                        translateKey.AddF (time, translateValue);
                                }
                        }
                }

                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        void
COLLADASceneLoader::AddAnimationEnvelope (
        const string			&baseChannelName,
        unsigned			 item,
        CLxUser_Envelope		 envelopes[3])
{
        scene_build.SetItem (item);
        vector<string> channelNames;
        ChannelsXYZ (baseChannelName, channelNames);
        for (unsigned envIndex = 0; envIndex < 3; ++envIndex) {
                scene_build.AddEnvelope (
                        channelNames.at(envIndex).c_str (),
                        envelopes[envIndex]);
        }
}

        LxResult
COLLADASceneLoader::LoadInstanceMaterial (
        COLLADAElement		&collada,
        const string		&geometryID,
        InstanceMaterialElement	&instanceMaterial)
{
        LxResult	result(LXe_OK);

        /*
         * Store all unique mappings of geometry IDs and symbols to materials.
         * There may be multiple mappings to a given material.
         */
        string materialSymbol = instanceMaterial.GetSymbol ();
        string materialTarget = instanceMaterial.GetTarget ();
        materialMap[make_pair(geometryID, materialSymbol)] = materialTarget;

        /*
         * Skip the material if it's already been processed.
         */
        if (!materialSymbol.empty () &&
            !materialTarget.empty () &&
            (materialTarget != materialTag) &&
            (materialTagSet.find (materialTarget) == materialTagSet.end ())) {
                /*
                 * Continue with the material not being found.
                 */
                result = LXe_NOTFOUND;
                materialTag = materialTarget;
                materialTagSet.insert (materialTag);
                if (collada.HasMaterialLibrary ()) {
                        MaterialLibraryElement materialLibrary(collada);
                        if (materialLibrary.HasMaterial ()) {
                                MaterialElement	material(materialLibrary);
                                if (materialLibrary.LinkMaterial (materialTarget, material)) {
                                        /*
                                         * Give preference to the user-friendly
                                         * name (when it's available) over the
                                         * raw material ID.
                                         */
                                        string	materialName = material.GetName ();
                                        if (materialName.empty ()) {
                                                materialName = material.GetID ();
                                        }
                                        /*
                                         * For efficiency, cache the mapping so the
                                         * material name can be quickly retrieved
                                         * later on (while loading geometry).
                                         */
                                        materialTargetNameMap[materialTarget] = materialName;
                                        scene_build.AddMaterial (
                                                materialName.c_str ());

                                        if (material.HasInstanceEffect ()) {
                                                InstanceEffectElement instanceEffect(material);
                                                if (material.LinkInstanceEffect (
                                                        instanceEffect)) {
                                                        string	effectID = StripURI_Ref (
                                                                instanceEffect.GetURL ());
                                                        if (collada.HasEffectLibrary () &&
                                                            !effectID.empty ()) {
                                                                EffectLibraryElement effectLibrary(collada);
                                                                if (effectLibrary.HasEffect ()) {
                                                                        EffectElement	effect(effectLibrary);
                                                                        if (effectLibrary.LinkEffect (effectID, effect)) {
                                                                                /*
                                                                                 * There are two binding methods:
                                                                                 * a bind vertex input, by the
                                                                                 * UV set and input semantic, or
                                                                                 * a simple bind, by the UV set
                                                                                 * and a target pointing directly
                                                                                 * at the source. For simplicity,
                                                                                 * we translate the second method
                                                                                 * into the first by cross-referencing
                                                                                 * the source back to its corresponding
                                                                                 * semantic in the input list.
                                                                                 */
                                                                                string bviSemantic;
                                                                                bool hasBVIInputSet = false;
                                                                                unsigned bviInputSet = 0;
                                                                                if (instanceMaterial.HasBindVertexInput ()) {
                                                                                        bviSemantic = instanceMaterial.GetBVISemantic ();
                                                                                        bviInputSet = instanceMaterial.GetBVIInputSet ();
                                                                                        hasBVIInputSet = true;
                                                                                }
                                                                                else if (instanceMaterial.HasBind ()) {
                                                                                        // [TODO] DAZ uses bind instead of BVI.
                                                                                }

                                                                                result = LoadEffect (
                                                                                        collada,
                                                                                        geometryID,
                                                                                        materialSymbol,
                                                                                        bviSemantic,
                                                                                        hasBVIInputSet,
                                                                                        bviInputSet,
                                                                                        effect);
                                                                        }
                                                                        else {
                                                                                LogError (result,
                                                                                        "LoadInstanceMaterial: missing effect");
                                                                        }
                                                                }
                                                        }
                                                        else {
                                                                LogError (result,
                                                                        "LoadInstanceMaterial: missing effect library");
                                                        }
                                                }
                                                else {
                                                        LogError (result,
                                                                "LoadInstanceMaterial: missing instance effect");
                                                }
                                        }
                                }
                                else {
                                        LogError (result,
                                                "LoadInstanceMaterial: missing material");
                                }
                        }
                }
                else {
                        LogError (result,
                                "LoadInstanceMaterial: missing material library");
                }
        }

        return LOG_ERR (result);
}

        static double
Normalize (
        double			 col[3])
{
        double			 max = 0.0;
        int			 i;

        for (i = 0; i < 3; i++)
                if (col[i] > max)
                        max = col[i];

        if (max == 0.0)
                return 0.0;

        for (i = 0; i < 3; i++)
                col[i] = col[i] / max;

        return max;
}

        LxResult
COLLADASceneLoader::LoadEffect (
        COLLADAElement		&collada,
        const string		&geometryID,
        const string		&materialSymbol,
        const string		&bviSemantic,
        bool			 hasBVIInputSet,
        unsigned		 bviInputSet,
        EffectElement		&effect)
{
        LxResult	result(LXe_FALSE);

        if (effect.HasPhong ()) {
                PhongElement phong(effect);

                result = LoadPhong (
                        collada, geometryID, materialSymbol, bviSemantic, hasBVIInputSet, bviInputSet, effect, phong);
        }
        else if (effect.HasBlinn ()) {
                BlinnElement blinn(effect);

                result = LoadBlinn (
                        collada, geometryID, materialSymbol, bviSemantic, hasBVIInputSet, bviInputSet, effect, blinn);
        }
        else if (effect.HasLambert ()) {
                LambertElement lambert(effect);

                result = LoadLambert (
                        collada, geometryID, materialSymbol, bviSemantic, hasBVIInputSet, bviInputSet, effect, lambert);
        }
        else if (effect.HasConstant ()) {
                ConstantElement constant(effect);

                result = LoadConstant (
                        collada, geometryID, materialSymbol, bviSemantic, hasBVIInputSet, bviInputSet, effect, constant);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadPhong (
        COLLADAElement		&collada,
        const string		&geometryID,
        const string		&materialSymbol,
        const string		&bviSemantic,
        bool			 hasBVIInputSet,
        unsigned		 bviInputSet,
        EffectElement		&effect,
        PhongElement		&phong)
{
        LxResult	result(LXe_FALSE);

        string	textureName;
        string	texcoordSet;
        bool haveEmissionColorMap(false);
        if (phong.GetEmissionColorMap (textureName, texcoordSet)) {
                haveEmissionColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_LUMICOLOR));
        }

        bool haveDiffuseColorMap(false);
        if (phong.GetDiffuseColorMap (textureName, texcoordSet)) {
                haveDiffuseColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_DIFFCOLOR));
        }

        bool haveSpecularColorMap(false);
        if (phong.GetSpecularColorMap (textureName, texcoordSet)) {
                haveSpecularColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_SPECCOLOR));
        }

        bool haveReflectiveColorMap(false);
        if (phong.GetReflectiveColorMap (textureName, texcoordSet)) {
                haveReflectiveColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_REFLCOLOR));
        }

        bool haveTransparentColorMap(false);
        if (phong.GetTransparentColorMap (textureName, texcoordSet)) {
                haveTransparentColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_TRANCOLOR));
        }

        if (LXx_OK(result)) {
                /*
                 * Load any of the supported effect channels that are present.
                 */
                Element::ColorRGBA	color;
                if (!haveEmissionColorMap && phong.GetEmissionColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_RADIANCE,
                                LXsICHAN_ADVANCEDMATERIAL_LUMICOL, color);
                }

                if (!haveDiffuseColorMap && phong.GetDiffuseColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_DIFFAMT,
                                LXsICHAN_ADVANCEDMATERIAL_DIFFCOL, color);
                }

                if (!haveSpecularColorMap && phong.GetSpecularColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_SPECAMT,
                                LXsICHAN_ADVANCEDMATERIAL_SPECCOL, color);
                }

                // Look for either transparent color or transparency.
                FX_Opaque opaqueMode;
                Vector4Copy (color, OPAQUE_BLACK);
                double transparency = 1.0;
                if (!haveTransparentColorMap) {
                        bool hasTransparentColor = phong.GetTransparentColor (
                                color, opaqueMode);
                     	bool hasTransparency = phong.GetTransparency (transparency);
                        if (hasTransparentColor || hasTransparency) {
                                result = InterpretTransparency (
                                        opaqueMode,
                                        hasTransparency, transparency,
                                        hasTransparentColor, color);
                        }
                }

                if (!haveReflectiveColorMap && phong.GetReflectiveColor (color)) {
                        double reflectivity = 0.0;

                        phong.GetReflectivity (reflectivity);
                        scene_build.SetChannel (
                                LXsICHAN_ADVANCEDMATERIAL_REFLAMT, reflectivity);

                        LXtVector color3 = {color[0], color[1], color[2]};
                        scene_build.SetChannelColor (
                                LXsICHAN_ADVANCEDMATERIAL_REFLCOL, color3);
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadBlinn (
        COLLADAElement		&collada,
        const string		&geometryID,
        const string		&materialSymbol,
        const string		&bviSemantic,
        bool			 hasBVIInputSet,
        unsigned		 bviInputSet,
        EffectElement		&effect,
        BlinnElement		&blinn)
{
        LxResult	result(LXe_FALSE);

        string	textureName;
        string	texcoordSet;
        bool haveEmissionColorMap(false);
        if (blinn.GetEmissionColorMap (textureName, texcoordSet)) {
                haveEmissionColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_LUMICOLOR));
        }

        bool haveDiffuseColorMap(false);
        if (blinn.GetDiffuseColorMap (textureName, texcoordSet)) {
                haveDiffuseColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_DIFFCOLOR));
        }

        bool haveSpecularColorMap(false);
        if (blinn.GetSpecularColorMap (textureName, texcoordSet)) {
                haveSpecularColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_SPECCOLOR));
        }

        bool haveReflectiveColorMap(false);
        if (blinn.GetReflectiveColorMap (textureName, texcoordSet)) {
                haveReflectiveColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_REFLCOLOR));
        }

        bool haveTransparentColorMap(false);
        if (blinn.GetTransparentColorMap (textureName, texcoordSet)) {
                haveTransparentColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_TRANCOLOR));
        }

        if (LXx_OK(result)) {
                /*
                 * Load any of the supported effect channels that are present.
                 */
                Element::ColorRGBA	color;
                if (!haveEmissionColorMap && blinn.GetEmissionColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_RADIANCE,
                                LXsICHAN_ADVANCEDMATERIAL_LUMICOL, color);
                }

                if (!haveDiffuseColorMap && blinn.GetDiffuseColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_DIFFAMT,
                                LXsICHAN_ADVANCEDMATERIAL_DIFFCOL, color);
                }

                if (!haveSpecularColorMap && blinn.GetSpecularColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_SPECAMT,
                                LXsICHAN_ADVANCEDMATERIAL_SPECCOL, color);
                }

                if (!haveReflectiveColorMap && blinn.GetReflectiveColor (color)) {
                        double reflectivity = 0.0;

                        blinn.GetReflectivity (reflectivity);
                        scene_build.SetChannel (
                                LXsICHAN_ADVANCEDMATERIAL_REFLAMT, reflectivity);

                        LXtVector color3 = {color[0], color[1], color[2]};
                        scene_build.SetChannelColor (
                                LXsICHAN_ADVANCEDMATERIAL_REFLCOL, color3);
                }

                FX_Opaque opaqueMode;
                Vector4Copy (color, OPAQUE_BLACK);
                double transparency = 1.0;
                if (!haveTransparentColorMap) {
                        bool hasTransparentColor = blinn.GetTransparentColor (
                                color, opaqueMode);
                     	bool hasTransparency = blinn.GetTransparency (transparency);
                        if (hasTransparentColor || hasTransparency) {
                                result = InterpretTransparency (
                                        opaqueMode,
                                        hasTransparency, transparency,
                                        hasTransparentColor, color);
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadLambert (
        COLLADAElement		&collada,
        const string		&geometryID,
        const string		&materialSymbol,
        const string		&bviSemantic,
        bool			 hasBVIInputSet,
        unsigned		 bviInputSet,
        EffectElement		&effect,
        LambertElement		&lambert)
{
        LxResult	result(LXe_FALSE);

        string	textureName;
        string	texcoordSet;
        bool haveEmissionColorMap(false);
        if (lambert.GetEmissionColorMap (textureName, texcoordSet)) {
                haveEmissionColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_LUMICOLOR));
        }

        bool haveDiffuseColorMap(false);
        if (lambert.GetDiffuseColorMap (textureName, texcoordSet)) {
                haveDiffuseColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_DIFFCOLOR));
        }

        bool haveReflectiveColorMap(false);
        if (lambert.GetReflectiveColorMap (textureName, texcoordSet)) {
                haveReflectiveColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_REFLCOLOR));
        }

        bool haveTransparentColorMap(false);
        if (lambert.GetTransparentColorMap (textureName, texcoordSet)) {
                haveTransparentColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_TRANCOLOR));
        }

        if (LXx_OK(result)) {
                /*
                 * Load any of the supported effect channels that are present.
                 */
                Element::ColorRGBA	color;
                if (!haveEmissionColorMap && lambert.GetEmissionColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_RADIANCE,
                                LXsICHAN_ADVANCEDMATERIAL_LUMICOL, color);
                }

                if (!haveDiffuseColorMap && lambert.GetDiffuseColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_DIFFAMT,
                                LXsICHAN_ADVANCEDMATERIAL_DIFFCOL, color);
                }

                FX_Opaque opaqueMode;
                Vector4Copy (color, OPAQUE_BLACK);
                double transparency = 1.0;
                if (!haveTransparentColorMap) {
                        bool hasTransparentColor = lambert.GetTransparentColor (
                                color, opaqueMode);
                     	bool hasTransparency = lambert.GetTransparency (transparency);
                        if (hasTransparentColor || hasTransparency) {
                                result = InterpretTransparency (
                                        opaqueMode,
                                        hasTransparency, transparency,
                                        hasTransparentColor, color);
                        }
                }

                if (!haveReflectiveColorMap && lambert.GetReflectiveColor (color)) {
                        double reflectivity = 0.0;

                        lambert.GetReflectivity (reflectivity);
                        scene_build.SetChannel (
                                LXsICHAN_ADVANCEDMATERIAL_REFLAMT, reflectivity);

                        LXtVector color3 = {color[0], color[1], color[2]};
                        scene_build.SetChannelColor (
                                LXsICHAN_ADVANCEDMATERIAL_REFLCOL, color3);
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::InterpretTransparency (
        FX_Opaque			 opaqueMode,
        bool				 hasTransparency,
        double				 transparency,
        bool				 hasTransparentColor,
        const Element::ColorRGBA	&color)
{
        /*
         * When both transparency and transparent color
         * are present, scale the transparency by the
         * value of the transparent color alpha.
         */
        double luminance = 1.0;
        if (hasTransparency && hasTransparentColor) {
                if (opaqueMode == FX_OPAQUE_ALPHA_ONE) {
                        transparency *= color[3];
                }
                else if (opaqueMode == FX_OPAQUE_RGB_ZERO) {
                        /*
                         * See the section, "Determining Transparency
                         * (Opacity)" in the COLLADA 1.4 specification.
                         */
                        luminance =
                                (color[0] * 0.212671) +
                                (color[1] * 0.715160) +
                                (color[2] * 0.072169);
                        transparency *= luminance;

                        /*
                         * In RGB_ZERO mode the material coefficient
                         * is 1.0 - transparency according to
                         * COLLADA 1.4 specification.
                         * For ALPHA_ONE mode it is not.
                         */
                        transparency = 1.0 - transparency;
                }
        }

        scene_build.SetChannel (
                LXsICHAN_ADVANCEDMATERIAL_TRANAMT, transparency);
        LXtVector color3;
        if (opaqueMode == FX_OPAQUE_ALPHA_ONE) {
                VSET (color3, 1.0);
        }
        else if (opaqueMode == FX_OPAQUE_RGB_ZERO) {
                VCPY (color3, color);
        }
        scene_build.SetChannelColor (
                LXsICHAN_ADVANCEDMATERIAL_TRANCOL, color3);

        return LXe_OK;
}

        LxResult
COLLADASceneLoader::LoadConstant (
        COLLADAElement		&collada,
        const string		&geometryID,
        const string		&materialSymbol,
        const string		&bviSemantic,
        bool			 hasBVIInputSet,
        unsigned		 bviInputSet,
        EffectElement		&effect,
        ConstantElement		&constant)
{
        LxResult	result(LXe_FALSE);

        string	textureName;
        string	texcoordSet;
        bool haveEmissionColorMap(false);
        if (constant.GetEmissionColorMap (textureName, texcoordSet)) {
                haveEmissionColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_LUMICOLOR));
        }

        bool haveReflectiveColorMap(false);
        if (constant.GetReflectiveColorMap (textureName, texcoordSet)) {
                haveReflectiveColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_REFLCOLOR));
        }

        bool haveTransparentColorMap(false);
        if (constant.GetTransparentColorMap (textureName, texcoordSet)) {
                haveTransparentColorMap = LXx_OK(LoadTexture (
                        collada, geometryID, materialSymbol,
                        bviSemantic, hasBVIInputSet, bviInputSet, effect,
                        textureName, texcoordSet, LXs_FX_TRANCOLOR));
        }

        if (LXx_OK(result)) {
                /*
                 * Load any of the supported effect channels that are present.
                 */
                Element::ColorRGBA	color;
                if (!haveEmissionColorMap && constant.GetEmissionColor (color)) {
                        result = SetChannelColorAmount (
                                LXsICHAN_ADVANCEDMATERIAL_RADIANCE,
                                LXsICHAN_ADVANCEDMATERIAL_LUMICOL, color);
                }

                if (!haveReflectiveColorMap && constant.GetReflectiveColor (color)) {
                        double reflectivity = 0.0;

                        constant.GetReflectivity (reflectivity);
                        scene_build.SetChannel (
                                LXsICHAN_ADVANCEDMATERIAL_REFLAMT, reflectivity);

                        LXtVector color3 = {color[0], color[1], color[2]};
                        scene_build.SetChannelColor (
                                LXsICHAN_ADVANCEDMATERIAL_REFLCOL, color3);
                }

                FX_Opaque opaqueMode;
                Vector4Copy (color, OPAQUE_BLACK);
                double transparency = 1.0;
                if (!haveTransparentColorMap) {
                        bool hasTransparentColor = constant.GetTransparentColor (
                                color, opaqueMode);
                     	bool hasTransparency = constant.GetTransparency (transparency);
                        if (hasTransparentColor || hasTransparency) {
                                result = InterpretTransparency (
                                        opaqueMode,
                                        hasTransparency, transparency,
                                        hasTransparentColor, color);
                        }
                }

        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadTexture (
        COLLADAElement		&collada,
        const string		&geometryID,
        const string		&materialSymbol,
        const string		&bviSemantic,
        bool			 hasBVIInputSet,
        unsigned		 bviInputSet,
        EffectElement		&effect,
        const string		&textureName,
        const string		&texcoordSet,
        const string		&effectChannel)
{
        LxResult	result(LXe_FALSE);

        string	samplerID = textureName;
        string	imageID;
        if ((bviSemantic.empty () || (bviSemantic == texcoordSet)) &&
            effect.GetSurfaceSamplerImageID (samplerID, imageID)) {
                if (collada.HasImageLibrary ()) {
                        ImageLibraryElement imageLibrary(collada);
                        ImageElement	image(imageLibrary);
                        if (imageLibrary.LinkImage (imageID, image)) {
                                if (collada.HasGeometryLibrary ()) {
                                        GeometryLibraryElement geometryLibrary(collada);
                                        if (geometryLibrary.HasGeometry ()) {
                                                GeometryElement geometry(geometryLibrary);
                                                if (geometryLibrary.LinkGeometry (
                                                        geometryID, geometry)) {
                                                        if (geometry.HasMesh ()) {
                                                                MeshElement	mesh(geometry);
                                                                result = LoadMeshTexture (
                                                                        mesh, image,
                                                                        materialSymbol,
                                                                        hasBVIInputSet,
                                                                        bviInputSet,
                                                                        texcoordSet,
                                                                        effectChannel);
                                                        }
                                                }
                                        }
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadMeshTexture (
        MeshElement		&mesh,
        ImageElement		&image,
        const string		&materialSymbol,
        bool			 hasBVIInputSet,
        unsigned		 bviInputSet,
        const string		&texcoordSet,
        const string		&effectChannel)
{
        LxResult	result(LXe_FALSE);

        /*
         * [TODO] polylist and triangles
         *        aren't enough - handle
         *        polygons as well! (SketchUp)
         */
        if (mesh.HasPolylist ()) {
                PolylistElement polylist(mesh);
                if (mesh.LinkFirstPolylist (polylist)) {
                        bool foundNextPolylist;
                        do {
                                if ((polylist.GetMaterialName () == materialSymbol) &&
                                        polylist.HasTexcoordInput ()) {
                                        bool foundTexcoordInputSource;
                                        unsigned sourceIndex = 0;
                                        do {
                                                foundTexcoordInputSource = false;
                                                string texcoordSourceID, texcoordSourceName;
                                                unsigned texcoordOffset;
                                                unsigned setIndex;
                                                if (polylist.GetTexcoordInputSourceIDbyIndex (
                                                        sourceIndex++,
                                                        texcoordSourceID,
                                                        texcoordOffset, setIndex)) {
                                                        SourceElement	texcoordsSource(mesh);

                                                        /*
                                                         * If we have a bind vertex input element with an
                                                         * optional input_set attribute that matches the
                                                         * set index in the polylist element, OR
                                                         * a bind vertex input element with no input_set attribute,
                                                         * and we can find the linked UV set source element.
                                                         */
                                                        if (((hasBVIInputSet && (bviInputSet == setIndex)) || !hasBVIInputSet) &&
                                                            mesh.LinkSource (texcoordSourceID, texcoordsSource)) {
                                                                string uvMapName(texcoordsSource.GetName ());
                                                                if (uvMapName.empty ()) {
                                                                        uvMapName = texcoordSourceID;
                                                                }
                                                                result = LoadImageMap (
                                                                        image,
                                                                        uvMapName,
                                                                        effectChannel);
                                                                break;
                                                        }
                                                        foundTexcoordInputSource = true;
                                                }
                                        } while (foundTexcoordInputSource);
                                }
                                foundNextPolylist =
                                        polylist.LinkNextPolylist (polylist);
                        } while (foundNextPolylist && LXx_OK (result));
                }
        }
        /*
         * [TODO] This block should not be an else -
         *        it should simply follow, in case
         *        we have a mixed representation
         *        mesh (SketchUp).
         */
        else if (mesh.HasTriangles ()) {
                TrianglesElement triangles(mesh);
                if (mesh.LinkFirstTriangles (triangles)) {
                        bool foundNextTriangles;
                        do {
                                if ((triangles.GetMaterialName () == materialSymbol) &&
                                        triangles.HasTexcoordInput ()) {
                                        bool foundTexcoordInputSource;
                                        unsigned sourceIndex = 0;
                                        do {
                                                foundTexcoordInputSource = false;
                                                string texcoordSourceID, texcoordSourceName;
                                                unsigned texcoordOffset;
                                                unsigned setIndex;
                                                if (triangles.GetTexcoordInputSourceIDbyIndex (
                                                        sourceIndex++,
                                                        texcoordSourceID,
                                                        texcoordOffset, setIndex)) {
                                                        SourceElement	texcoordsSource(mesh);
                                                        if (mesh.LinkSource (texcoordSourceID, texcoordsSource)) {
                                                                string uvMapName(texcoordsSource.GetName ());
                                                                if (uvMapName.empty ()) {
                                                                        uvMapName = texcoordSourceID;
                                                                }
                                                                result = LoadImageMap (
                                                                        image,
                                                                        uvMapName,
                                                                        effectChannel);
                                                                break;
                                                        }
                                                        foundTexcoordInputSource = true;
                                                }
                                        } while (foundTexcoordInputSource);
                                }
                                foundNextTriangles =
                                        triangles.LinkNextTriangles (triangles);
                        } while (foundNextTriangles && LXx_OK (result));
                }
        }
        /*
         * [TODO] polylist and triangles
         *        aren't enough - handle
         *        polygons as well! (SketchUp)
         */

        return result;
}

        LxResult
COLLADASceneLoader::LoadImageMap (
        ImageElement		&image,
        const string		&texcoordSet,
        const string		&effect)
{
        LxResult	result(LXe_FAILED);

        /*
         * If we have a non-empty file path,
         * add it to the image list.
         */
        string filePath = image.GetNativeFilePath ();
        if (!filePath.empty ()) {

#if defined(COLLADALOADER_VERBOSE_LOGGING)
                log.Info (filePath);
#endif
                if (!IsFileAbsolute (filePath)) {
                        MakeFileAbsolute (filePath);
                }

                /*
                 * Save the active material item.
                 */
                unsigned matItem = scene_build.CurItem ();

                /*
                 * Load the image using the native file path
                 * and the stored texcoord set name.
                 */
                scene_build.AddImageMap (
                        filePath.c_str (), effect.c_str (),
                        texcoordSet.c_str ());

                /*
                 * Restore the active material item.
                 */
                scene_build.SetItem (matItem);

                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::SetChannelColorAmount (
        const string			&amountChannel,
        const string			&colorChannel,
        Element::ColorRGBA		&color)
{
        LxResult	result(LXe_FALSE);

        scene_build.SetChannel (amountChannel.c_str (), Normalize (color));
        LXtVector color3 = {color[0], color[1], color[2]};
        scene_build.SetChannelColor (
                colorChannel.c_str (), color3);

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadGeometry (
        COLLADAElement		&collada,
        GeometryElement		&geometry)
{
        LxResult	result(LXe_FAILED);

        if (geometry.HasMesh ()) {
                MeshElement	mesh(geometry);

                /*
                 * Fall back to geometry name if node was anonymous.
                 */
                if (nodeName.empty ()) {
                        nodeName = geometry.GetName ();
                        scene_build.SetName (
                                nodeName.c_str ());
                }
#if defined(COLLADALOADER_VERBOSE_LOGGING)
                log.Info (nodeName);
#endif

                result = LXe_OK;

                /*
                 * Iterate over mesh elements for multi-material meshes.
                 */
                if (mesh.HasPolygons ()) {
                        result = LoadPolygons (mesh);
                }
                if (LXx_OK (result)) {
                        if (mesh.HasPolylist ()) {
                                result = LoadPolylists (mesh);
                        }
                        if (LXx_OK (result)) {
                                if (mesh.HasTriangles ()) {
                                        result = LoadTriangles (mesh);
                                }
                                if (LXx_OK (result)) {
                                        if (mesh.HasLines ()) {
                                                result = LoadLines (mesh);
                                        }
                                        if (LXx_OK (result) && points.empty ()) {
                                                /*
                                                 * Look for a mesh that only
                                                 * contains points, with no
                                                 * polygons.
                                                 */
                                                result = LoadVertices (mesh);
                                        }
                                }
                        }
                }

                points.clear ();
                normals.clear ();

                texcoordOffsets.clear ();
                texcoords.clear ();
                texcoordUVMapIDs.clear ();
                texcoordUVMaps.clear ();

                colorOffsets.clear ();
                colors.clear ();
                colorMapIDs.clear ();
                colorMaps.clear ();
                colorMapStrides.clear ();

                weightOffsets.clear ();
                weights.clear ();
                weightMapIDs.clear ();
                weightMaps.clear ();
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadPolygons (
        MeshElement		&mesh)
{
        LxResult	result(LXe_FAILED);
        PolygonsElement polygons(mesh);

        if (mesh.LinkFirstPolygons (polygons)) {

                bool foundNextPolygons;
                do {
                        if (points.empty ()) {
                                result = LoadVertices (mesh, polygons);
                        }
                        else {
                                result = LXe_OK;
                        }

                        if (polygons.HasNormalInput ()) {
                                if (normals.empty ()) {
                                        result = LoadNormals (
                                                mesh, polygons);
                                }
                        }

                        if (polygons.HasTexcoordInput ()) {
                                if (texcoords.empty ()) {
                                        result = LoadTexcoords (
                                                mesh, polygons);
                                }
                        }

                        if (polygons.HasColorInput ()) {
                                if (colors.empty ()) {
                                        result = LoadColors (
                                                mesh, polygons);
                                }
                        }

                        if (polygons.HasWeightInput ()) {
                                if (colors.empty ()) {
                                        result = LoadWeights (
                                                mesh, polygons);
                                }
                        }

                        if (LXx_OK (result)) {
                                /*
                                 * Select the material for the polygons.
                                 */
                                if (materialBindKey != make_pair(mesh.GetGeometryID (), polygons.GetMaterialName ())) {
                                        materialBindKey = make_pair(mesh.GetGeometryID (), polygons.GetMaterialName ());
                                        MaterialMap::const_iterator iter =
                                                materialMap.find (materialBindKey);
                                        if (iter != materialMap.end ()) {
                                                materialTag = iter->second;
                                                materialName = materialTargetNameMap[materialTag];
                                        }
                                }
                                /*
                                 * A polygons element can have zero or more
                                 * <p> elements.
                                 */
                                unsigned polyIndex = 0;
                                bool haveAnotherPoly;
                                do {
                                        haveAnotherPoly = polygons.GetInputIndices (
                                                polyIndex++, polyVertexIndices);
                                        if (haveAnotherPoly) {
                                                /*
                                                 * Add the polygon face.
                                                 */
                                                result = BuildPolygons (polygons);
                                        }
                                        polyVertexIndices.clear ();
                                } while (haveAnotherPoly && LXx_OK (result));
                        }
                        foundNextPolygons =
                                polygons.LinkNextPolygons (polygons);
                } while (foundNextPolygons && LXx_OK (result));
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::BuildPolygons (PolygonsElement &polygons)
{
        LxResult	result(LXe_OK);

        /*
         * Iterate over both the vertex counts and the input indices.
         */
        unsigned maxOffset = polygons.GetMaxInputOffset ();

        bool hasNormals = polygons.HasNormalInput () && !normals.empty ();
        bool hasTexcoords = polygons.HasTexcoordInput () && !texcoords.empty ();

        size_t inputIndicesCount = polyVertexIndices.size ();
        unsigned inputIndicesIndex = 0;

        /*
         * Start a new polygon.
         *
         * [TODO] Call StartPoly with LXiPTYP_SUBD if using modo 401
         *        profile and the polygon was stored as subd.
         */
        scene_build.StartPoly (LXiPTYP_FACE);
        unsigned vertexCount = static_cast<unsigned>(
                polyVertexIndices.size () / (maxOffset + 1));
        for (unsigned vertexPolyIndex = 0;
             vertexPolyIndex < vertexCount; ++vertexPolyIndex) {
                /*
                 * Add the vertex position index.
                 */
                unsigned vertexLookup = inputIndicesIndex + pointOffset;
                if (vertexLookup < inputIndicesCount) {
                        unsigned vertexIndex =
                                polyVertexIndices.at (vertexLookup);
                        scene_build.AddVertex (
                                basePointIndex + vertexIndex);
                }
                else {
                        result = LXe_NOTFOUND;
                        break;
                }

                inputIndicesIndex += maxOffset + 1;
        }

        if (LXx_OK (result)) {
                /*
                 * Add the polygon.
                 */
                unsigned polyIndex = scene_build.AddPolygon ();
                scene_build.SetPolyTag (
                        polyIndex, LXi_PTAG_MATR,
                        materialName.c_str ());

                /*
                 * Iterate over the newly created polygon's vertices,
                 * to set its normal and texcoord vertex map values.
                 */
                if (hasNormals || hasTexcoords) {
                        result = SetPolyVertexMaps (
                                hasNormals, hasTexcoords,
                                false /*hasColors*/, false /*hasWeights*/,
                                polyIndex,
                                vertexCount,
                                0,
                                maxOffset);
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVertices (
        MeshElement		&mesh,
        PolygonsElement		&polygons)
{
        LxResult	result(LXe_FAILED);

        /*
         * Load the vertices, after some minimal validity checks.
         */
        if (polygons.HasVertexInput () &&
            mesh.HasVertices () &&
            mesh.HasSource ()) {
                VerticesElement	vertices(mesh);

                string meshVerticesID =
                        polygons.GetVertexInputSourceID (pointOffset);
                if (mesh.LinkVertices (meshVerticesID, vertices)) {
                        if (vertices.HasPositionInput ()) {
                                string positionsSourceID =
                                        vertices.PositionInputSourceID ();
                                SourceElement	positionsSource(mesh);
                                if (mesh.LinkSource (
                                    positionsSourceID, positionsSource)) {
                                        result = LoadPositionsSource (positionsSource);
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadPolylists (
        MeshElement		&mesh)
{
        LxResult	result(LXe_FAILED);
        PolylistElement polylist(mesh);

        if (mesh.LinkFirstPolylist (polylist)) {

                bool foundNextPolylist;
                do {
                        if (points.empty ()) {
                                result = LoadVertices (mesh, polylist);
                        }
                        else {
                                result = LXe_OK;
                        }

                        if (polylist.HasNormalInput ()) {
                                if (normals.empty ()) {
                                        result = LoadNormals (
                                                mesh, polylist);
                                }
                        }

                        if (polylist.HasTexcoordInput ()) {
                                if (texcoords.empty ()) {
                                        result = LoadTexcoords (
                                                mesh, polylist);
                                }
                        }

                        if (polylist.HasColorInput ()) {
                                if (colors.empty ()) {
                                        result = LoadColors (
                                                mesh, polylist);
                                }
                        }

                        if (polylist.HasWeightInput ()) {
                                if (weights.empty ()) {
                                        result = LoadWeights (
                                                mesh, polylist);
                                }
                        }

                        if (LXx_OK (result) &&
                            polylist.GetVertexCounts (polyVertexCounts) &&
                            polylist.GetInputIndices (polyVertexIndices)) {
                                /*
                                 * Add the polygon faces.
                                 */
                                result = BuildPolylist (polylist);
                        }

                        polyVertexCounts.clear ();
                        polyVertexIndices.clear ();
                        foundNextPolylist =
                                polylist.LinkNextPolylist (polylist);
                } while (foundNextPolylist && LXx_OK (result));
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::BuildPolylist (PolylistElement &polylist)
{
        LxResult	result(LXe_OK);

        if (materialBindKey != make_pair(polylist.GetGeometryID (), polylist.GetMaterialName ())) {
                materialBindKey = make_pair(polylist.GetGeometryID (), polylist.GetMaterialName ());
                MaterialMap::const_iterator iter = materialMap.find (materialBindKey);
                if (iter != materialMap.end ()) {
                        materialTag = iter->second;
                        materialName = materialTargetNameMap[materialTag];
                }
        }

        /*
         * Iterate over both the vertex counts and the input indices.
         */
        unsigned maxOffset = polylist.GetMaxInputOffset ();

        bool hasNormals = polylist.HasNormalInput () && !normals.empty ();
        bool hasTexcoords = polylist.HasTexcoordInput () && !texcoords.empty ();
        bool hasColors = polylist.HasColorInput () && !colors.empty ();
        bool hasWeights = polylist.HasWeightInput () && !weights.empty ();

        size_t inputIndicesCount = polyVertexIndices.size ();
        unsigned inputIndicesIndex = 0;
        for (vector<unsigned>::const_iterator iter = polyVertexCounts.begin ();
                iter != polyVertexCounts.end (); ++iter) {
                unsigned vertexPolyCount = *iter;

                /*
                 * Delay advancing the input indices index until after
                 * we have set any vertex map entries for the polygon.
                 */
                unsigned localInputIndicesIndex = inputIndicesIndex;

                /*
                 * Start a new polygon.
                 *
                 * [TODO] Call StartPoly with LXiPTYP_SUBD if using modo 401
                 *        profile and the polygon was stored as subd.
                 */
                scene_build.StartPoly (LXiPTYP_FACE);
                for (unsigned vertexPolyIndex = 0;
                     vertexPolyIndex < vertexPolyCount; ++vertexPolyIndex) {
                        /*
                         * Add the vertex position index.
                         */
                        unsigned vertexLookup = 
                                localInputIndicesIndex + pointOffset;
                        if (vertexLookup < inputIndicesCount) {
                                unsigned vertexIndex =
                                        polyVertexIndices.at (vertexLookup);
                                scene_build.AddVertex (
                                        basePointIndex + vertexIndex);
                        }
                        else {
                                result = LXe_NOTFOUND;
                                break;
                        }

                        localInputIndicesIndex += maxOffset + 1;
                }

                if (LXx_OK (result)) {
                        /*
                         * Add the polygon.
                         */
                        unsigned polyIndex = scene_build.AddPolygon ();

                        scene_build.SetPolyTag (
                                polyIndex, LXi_PTAG_MATR,
                                materialName.c_str ());

                        /*
                         * Iterate over the newly created polygon's vertices,
                         * to set its normal, texcoord, color and weight
                         * vertex map values.
                         */
                        if (hasNormals || hasTexcoords || hasColors || hasWeights) {
                                result = SetPolyVertexMaps (
                                        hasNormals, hasTexcoords, hasColors, hasWeights,
                                        polyIndex, vertexPolyCount,
                                        inputIndicesIndex,
                                        maxOffset);
                        }
                        inputIndicesIndex = localInputIndicesIndex;
                }
                else {
                        break;
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::SetPolyVertexMaps (
        bool		 hasNormals,
        bool		 hasTexcoords,
        bool		 hasColors,
        bool		 hasWeights,
        unsigned	 polyIndex,
        unsigned	 vertexPolyCount,
        unsigned	 inputIndicesIndex,
        unsigned	 maxOffset)
{
        LxResult	result(LXe_OK);

        size_t inputIndicesCount = polyVertexIndices.size ();

        for (unsigned vertexPolyIndex = 0;
             vertexPolyIndex < vertexPolyCount; ++vertexPolyIndex) {
                unsigned vertexLookup = inputIndicesIndex + pointOffset;
                if (vertexLookup < inputIndicesCount) {
                        unsigned vertexIndex =
                                polyVertexIndices.at (vertexLookup);

                        if (hasNormals) {
                                unsigned normalLookup =
                                        inputIndicesIndex + normalOffset;
                                if (normalLookup < inputIndicesCount) {
                                        unsigned normalIndex =
                                                polyVertexIndices.at (normalLookup);
                                        const unsigned NORMAL_STRIDE = 3;
                                        if (normalIndex * NORMAL_STRIDE + 2 < normals.size ()) {
                                                LXtFVector normal;
                                                normal[0] = normals.at (
                                                        normalIndex * NORMAL_STRIDE);
                                                normal[1] = normals.at (
                                                        normalIndex * NORMAL_STRIDE + 1);
                                                normal[2] = normals.at (
                                                        normalIndex * NORMAL_STRIDE + 2);
                                                scene_build.SetCoVertMap (
                                                        normalMap, normal,
                                                        basePointIndex + vertexIndex,
                                                        polyIndex);
                                        }
                                        else {
                                                result = LXe_NOTFOUND;
                                                break;
                                        }
                                }
                        }

                        if (hasTexcoords) {
                                unsigned arrayIndex = 0;
                                for (vector<unsigned>::const_iterator iter = texcoordOffsets.begin ();
                                     iter != texcoordOffsets.end (); ++iter) {
                                        unsigned texcoordOffset = *iter;
                                        unsigned texcoordLookup =
                                                inputIndicesIndex + texcoordOffset;
                                        if (texcoordLookup < inputIndicesCount) {
                                                unsigned texcoordIndex =
                                                        polyVertexIndices.at (texcoordLookup);
                                                const unsigned TEXCOORD_STRIDE = 2;
                                                if (texcoordIndex * TEXCOORD_STRIDE + 1 < texcoords.at (arrayIndex).size ()) {
                                                        LXtFVector2	texcoord;
                                                        texcoord[0] = texcoords.at (arrayIndex).at (
                                                                texcoordIndex * TEXCOORD_STRIDE);
                                                        texcoord[1] = texcoords.at (arrayIndex).at (
                                                                texcoordIndex * TEXCOORD_STRIDE + 1);
                                                        scene_build.SetCoVertMap (
                                                                texcoordUVMaps.at (arrayIndex), texcoord,
                                                                basePointIndex + vertexIndex,
                                                                polyIndex);
                                                }
                                                else {
                                                        /*
                                                         * If UV texcoords are deleted,
                                                         * UV indices may end up pointing
                                                         * past the end of the array.
                                                         * We can ignore this, so it's
                                                         * not a fatal error.
                                                         */
                                                        result = LXe_FALSE;
                                                        break;
                                                }
                                        }
                                        ++arrayIndex;
                                }
                        }

                        if (hasColors) {
                                unsigned arrayIndex = 0;
                                for (vector<unsigned>::const_iterator iter = colorOffsets.begin ();
                                     iter != colorOffsets.end (); ++iter) {
                                        unsigned colorOffset = *iter;
                                        unsigned colorLookup =
                                                inputIndicesIndex + colorOffset;
                                        if (colorLookup < inputIndicesCount) {
                                                unsigned colorIndex =
                                                        polyVertexIndices.at (colorLookup);
                                                unsigned colorStride = colorMapStrides.at (arrayIndex);
                                                if (colorIndex * colorStride + 1 < colors.at (arrayIndex).size ()) {
                                                        float	color[4];
                                                        color[0] = colors.at (arrayIndex).at (
                                                                colorIndex * colorStride);
                                                        color[1] = colors.at (arrayIndex).at (
                                                                colorIndex * colorStride + 1);
                                                        color[2] = colors.at (arrayIndex).at (
                                                                colorIndex * colorStride + 2);
                                                        if (colorStride == 4) {
                                                                color[3] = colors.at (arrayIndex).at (
                                                                        colorIndex * colorStride + 3);
                                                        }
                                                        scene_build.SetCoVertMap (
                                                                colorMaps.at (arrayIndex), color,
                                                                basePointIndex + vertexIndex,
                                                                polyIndex);
                                                }
                                                else {
                                                        /*
                                                         * If colors are deleted,
                                                         * color indices may end up pointing
                                                         * past the end of the array.
                                                         * We can ignore this, so it's
                                                         * not a fatal error.
                                                         */
                                                        result = LXe_FALSE;
                                                        break;
                                                }
                                        }
                                        ++arrayIndex;
                                }
                        }

                        if (hasWeights) {
                                unsigned arrayIndex = 0;
                                for (vector<unsigned>::const_iterator iter = weightOffsets.begin ();
                                     iter != weightOffsets.end (); ++iter) {
                                        unsigned weightOffset = *iter;
                                        unsigned weightLookup =
                                                inputIndicesIndex + weightOffset;
                                        if (weightLookup < inputIndicesCount) {
                                                unsigned weightIndex =
                                                        polyVertexIndices.at (weightLookup);

                                                if (weightIndex < weights.at (arrayIndex).size ()) {
                                                        float	weight;
                                                        weight = weights.at (arrayIndex).at (weightIndex);
                                                        scene_build.SetCoVertMap (
                                                                weightMaps.at (arrayIndex), &weight,
                                                                basePointIndex + vertexIndex,
                                                                polyIndex);
                                                }
                                                else {
                                                        /*
                                                         * If weights are deleted,
                                                         * weight indices may end up pointing
                                                         * past the end of the array.
                                                         * We can ignore this, so it's
                                                         * not a fatal error.
                                                         */
                                                        result = LXe_FALSE;
                                                        break;
                                                }
                                        }
                                        ++arrayIndex;
                                }
                        }

                        inputIndicesIndex += maxOffset + 1;
                }
                else {
                        result = LXe_NOTFOUND;
                        break;
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVertices (
        MeshElement		&mesh,
        PolylistElement		&polylist)
{
        LxResult	result(LXe_FAILED);

        /*
         * Load the vertices, after some minimal validity checks.
         */
        if (polylist.HasVertexInput () &&
            mesh.HasVertices () &&
            mesh.HasSource ()) {
                VerticesElement	vertices(mesh);

                string meshVerticesID =
                        polylist.GetVertexInputSourceID (pointOffset);
                if (mesh.LinkVertices (meshVerticesID, vertices)) {
                        if (vertices.HasPositionInput ()) {
                                string positionsSourceID =
                                        vertices.PositionInputSourceID ();
                                SourceElement	positionsSource(mesh);
                                if (mesh.LinkSource (
                                    positionsSourceID, positionsSource)) {
                                        result = LoadPositionsSource (positionsSource);
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadTriangles (
        MeshElement		&mesh)
{
        LxResult	result(LXe_FAILED);
        TrianglesElement triangles(mesh);

        if (mesh.LinkFirstTriangles (triangles)) {

                bool foundNextTriangles;
                do {
                        if (points.empty ()) {
                                result = LoadVertices (mesh, triangles);
                        }
                        else {
                                result = LXe_OK;
                        }

                        if (triangles.HasNormalInput ()) {
                                if (normals.empty ()) {
                                        result = LoadNormals (
                                                mesh, triangles);
                                }
                        }

                        if (triangles.HasTexcoordInput ()) {
                                if (texcoords.empty ()) {
                                        result = LoadTexcoords (
                                                mesh, triangles);
                                }
                        }

                        if (triangles.HasColorInput ()) {
                                if (colors.empty ()) {
                                        result = LoadColors (
                                                mesh, triangles);
                                }
                        }

                        if (triangles.HasWeightInput ()) {
                                if (colors.empty ()) {
                                        result = LoadWeights (
                                                mesh, triangles);
                                }
                        }

                        if (LXx_OK (result) &&
                            triangles.GetInputIndices (polyVertexIndices)) {
                                /*
                                 * Add the triangles faces.
                                 */
                                result = BuildTriangles (triangles);
                        }
                        polyVertexIndices.clear ();
                        foundNextTriangles =
                                triangles.LinkNextTriangles (triangles);
                } while (foundNextTriangles && LXx_OK (result));
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::BuildTriangles (TrianglesElement &triangles)
{
        LxResult	result(LXe_OK);

        if (materialBindKey != make_pair(triangles.GetGeometryID (), triangles.GetMaterialName ())) {
                materialBindKey = make_pair(triangles.GetGeometryID (), triangles.GetMaterialName ());
                MaterialMap::const_iterator iter = materialMap.find (materialBindKey);
                if (iter != materialMap.end ()) {
                        materialTag = iter->second;
                        materialName = materialTargetNameMap[materialTag];
                }
        }

        /*
         * Iterate over the input indices.
         */
        unsigned maxOffset = triangles.GetMaxInputOffset ();

        bool hasNormals = triangles.HasNormalInput () && !normals.empty ();
        bool hasTexcoords = triangles.HasTexcoordInput () && !texcoords.empty ();
        bool hasColors = triangles.HasColorInput() && !colors.empty ();

        size_t inputIndicesCount = polyVertexIndices.size ();
        size_t trianglesCount = triangles.GetCount ();
        unsigned inputIndicesIndex = 0;
        for (unsigned triangleIndex = 0; triangleIndex < trianglesCount; ++triangleIndex) {
                /*
                 * Delay advancing the input indices index until after
                 * we have set any vertex map entries for the polygon.
                 */
                unsigned localInputIndicesIndex = inputIndicesIndex;

                /*
                 * Start a new polygon.
                 */
                scene_build.StartPoly (LXiPTYP_FACE);

                /*
                 * We're loading triangles, three vertices at a time.
                 */
                for (unsigned vertexPolyIndex = 0;
                     vertexPolyIndex < 3; ++vertexPolyIndex) {
                        /*
                         * Add the vertex position index.
                         */
                        unsigned vertexLookup = 
                                localInputIndicesIndex + pointOffset;
                        if (vertexLookup < inputIndicesCount) {
                                unsigned vertexIndex =
                                        polyVertexIndices.at (vertexLookup);
                                scene_build.AddVertex (
                                        basePointIndex + vertexIndex);
                        }
                        else {
                                result = LXe_NOTFOUND;
                                break;
                        }

                        localInputIndicesIndex += maxOffset + 1;
                }

                if (LXx_OK (result)) {
                        /*
                         * Add the polygon.
                         */
                        unsigned polyIndex = scene_build.AddPolygon ();

                        scene_build.SetPolyTag (
                                polyIndex, LXi_PTAG_MATR,
                                materialName.c_str ());

                        /*
                         * Iterate over the newly created polygon's vertices,
                         * to set its normal and texcoord vertex map values.
                         */
                        if (hasNormals || hasTexcoords || hasColors) {
                                result = SetPolyVertexMaps (
                                        hasNormals, hasTexcoords,
                                        hasColors, false /*hasWeights*/,
                                        polyIndex, 3,
                                        inputIndicesIndex,
                                        maxOffset);
                        }
                        inputIndicesIndex = localInputIndicesIndex;
                }
                else {
                        break;
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVertices (
        MeshElement		&mesh,
        TrianglesElement	&triangles)
{
        LxResult	result(LXe_FAILED);

        /*
         * Load the vertices, after some minimal validity checks.
         */
        if (triangles.HasVertexInput () &&
            mesh.HasVertices () &&
            mesh.HasSource ()) {
                VerticesElement	vertices(mesh);

                string meshVerticesID =
                        triangles.GetVertexInputSourceID (pointOffset);
                if (mesh.LinkVertices (meshVerticesID, vertices)) {
                        if (vertices.HasPositionInput ()) {
                                string positionsSourceID =
                                        vertices.PositionInputSourceID ();
                                SourceElement	positionsSource(mesh);
                                if (mesh.LinkSource (
                                    positionsSourceID, positionsSource)) {
                                        result = LoadPositionsSource (positionsSource);
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadLines (
        MeshElement		&mesh)
{
        LxResult	result(LXe_FAILED);
        LinesElement 	lines(mesh);

        if (mesh.LinkFirstLines (lines)) {

                bool foundNextLines;
                do {
                        if (points.empty ()) {
                                result = LoadVertices (mesh, lines);
                        }
                        else {
                                result = LXe_OK;
                        }

                        if (lines.HasNormalInput ()) {
                                if (normals.empty ()) {
                                        result = LoadNormals (
                                                mesh, lines);
                                }
                        }

                        if (lines.HasTexcoordInput ()) {
                                if (texcoords.empty ()) {
                                        result = LoadTexcoords (
                                                mesh, lines);
                                }
                        }

                        if (lines.HasColorInput ()) {
                                if (colors.empty ()) {
                                        result = LoadColors (
                                                mesh, lines);
                                }
                        }

                        if (lines.HasWeightInput ()) {
                                if (colors.empty ()) {
                                        result = LoadWeights (
                                                mesh, lines);
                                }
                        }

                        if (LXx_OK (result) &&
                            lines.GetInputIndices (polyVertexIndices)) {
                                /*
                                 * Add the triangles faces.
                                 */
                                result = BuildLines (lines);
                        }
                        polyVertexIndices.clear ();
                        foundNextLines =
                                lines.LinkNextLines (lines);
                } while (foundNextLines && LXx_OK (result));
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::BuildLines (LinesElement &lines)
{
        LxResult	result(LXe_OK);

        if (materialBindKey != make_pair(lines.GetGeometryID (), lines.GetMaterialName ())) {
                materialBindKey = make_pair(lines.GetGeometryID (), lines.GetMaterialName ());
                MaterialMap::const_iterator iter = materialMap.find (materialBindKey);
                if (iter != materialMap.end ()) {
                        materialTag = iter->second;
                        materialName = materialTargetNameMap[materialTag];
                }
        }

        /*
         * Iterate over the input indices.
         */
        unsigned maxOffset = lines.GetMaxInputOffset ();

        bool hasNormals = lines.HasNormalInput () && !normals.empty ();
        bool hasTexcoords = lines.HasTexcoordInput () && !texcoords.empty ();

        size_t inputIndicesCount = polyVertexIndices.size ();
        size_t linesCount = lines.GetCount ();
        unsigned inputIndicesIndex = 0;
        for (unsigned linesIndex = 0; linesIndex < linesCount; ++linesIndex) {
                /*
                 * Delay advancing the input indices index until after
                 * we have set any vertex map entries for the line.
                 */
                unsigned localInputIndicesIndex = inputIndicesIndex;

                /*
                 * Start a new polygon.
                 */
                scene_build.StartPoly (LXiPTYP_FACE);

                /*
                 * We're loading lines, two vertices at a time.
                 */
                for (unsigned vertexPolyIndex = 0;
                     vertexPolyIndex < 2; ++vertexPolyIndex) {
                        /*
                         * Add the vertex position index.
                         */
                        unsigned vertexLookup = 
                                localInputIndicesIndex + pointOffset;
                        if (vertexLookup < inputIndicesCount) {
                                unsigned vertexIndex =
                                        polyVertexIndices.at (vertexLookup);
                                scene_build.AddVertex (
                                        basePointIndex + vertexIndex);
                        }
                        else {
                                result = LXe_NOTFOUND;
                                break;
                        }

                        localInputIndicesIndex += maxOffset + 1;
                }

                if (LXx_OK (result)) {
                        /*
                         * Add the line.
                         */
                        unsigned polyIndex = scene_build.AddPolygon ();

                        scene_build.SetPolyTag (
                                polyIndex, LXi_PTAG_MATR,
                                materialName.c_str ());

                        /*
                         * Iterate over the newly created polygon's vertices,
                         * to set its normal and texcoord vertex map values.
                         */
                        if (hasNormals || hasTexcoords) {
                                result = SetPolyVertexMaps (
                                        hasNormals, hasTexcoords,
                                        false /*hasColors*/, false/*hasWeights*/,
                                        polyIndex, 3,
                                        inputIndicesIndex,
                                        maxOffset);
                        }
                        inputIndicesIndex = localInputIndicesIndex;
                }
                else {
                        break;
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVertices (
        MeshElement		&mesh,
        LinesElement		&lines)
{
        LxResult	result(LXe_FAILED);

        /*
         * Load the vertices, after some minimal validity checks.
         */
        if (lines.HasVertexInput () &&
            mesh.HasVertices () &&
            mesh.HasSource ()) {
                VerticesElement	vertices(mesh);

                string meshVerticesID =
                        lines.GetVertexInputSourceID (pointOffset);
                if (mesh.LinkVertices (meshVerticesID, vertices)) {
                        if (vertices.HasPositionInput ()) {
                                string positionsSourceID =
                                        vertices.PositionInputSourceID ();
                                SourceElement	positionsSource(mesh);
                                if (mesh.LinkSource (
                                    positionsSourceID, positionsSource)) {
                                        result = LoadPositionsSource (positionsSource);
                                }
                        }
                }
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadVertices (
        MeshElement	&mesh)
{
        LxResult	result (LXe_NOTFOUND);

        if (mesh.HasVertices () &&
            mesh.HasSource ()) {
                VerticesElement	vertices(mesh);
                if (mesh.LinkFirstVertices (vertices)) {
                        string positionsSourceID =
                                vertices.PositionInputSourceID ();
                        SourceElement	positionsSource(mesh);
                        if (mesh.LinkSource (
                            positionsSourceID, positionsSource)) {
                                result = LoadPositionsSource (positionsSource);
                        }
                }
        }

        return result;
}

        LxResult
COLLADASceneLoader::LoadPositionsSource (
        SourceElement		&source)
{
        LxResult	result(LXe_NOTFOUND);

        if (source.LinkFloatArray (points)) {
                /*
                 * Verify that the array and the accessor are consistent.
                 */
                unsigned componentCount = source.GetCount ();
                unsigned stride = source.GetStride ();
                if ((points.size () == componentCount * stride) &&
                    (stride == 3)) {
                        /*
                         * Pass each point to modo's internal scene builder.
                         */
                        for (vector<float>::const_iterator iter = points.begin (); 
                             iter != points.end ();) {
                                LXtVector	vec;
                                for (unsigned index = 0; index < stride; ++index) {
                                        /*
                                         * Pull the X, Y, and Z coordinates.
                                         */
                                        vec[index] = *iter++;
                                }

                                /*
                                 * Add the point position to the open polygon.
                                 */
                                lastPointIndex = scene_build.AddPoint (vec);
                        }
                }
                result = LXe_OK;
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadNormals (
        MeshElement		&mesh,
        const VertexMapInputHub	&inputHub)
{
        LxResult	result(LXe_FAILED);

        /*
         * Load the normals.
         */
        if (inputHub.HasNormalInput () &&
            mesh.HasSource ()) {
                string normalsSourceID =
                        inputHub.GetNormalInputSourceID (normalOffset);
                SourceElement	normalsSource(mesh);
                if (mesh.LinkSource (normalsSourceID, normalsSource)) {
                        if (normalsSource.LinkFloatArray (normals)) {
#if defined(COLLADALOADER_VERBOSE_LOGGING)
                                log.Info (normalsSourceID);
#endif
                                normalMap = scene_build.AddMap (
                                        LXi_VMAP_NORMAL,
                                        normalsSourceID.c_str ());
                                result = LXe_OK;
                        }
                }
        }

        return LOG_ERR (result);
}

/*
 * Load the texcoords from the given vertex map input hub.
 */
        LxResult
COLLADASceneLoader::LoadTexcoords (
        MeshElement			&mesh,
        const VertexMapInputHub		&inputHub)
{
        LxResult	result(LXe_FAILED);

        if (inputHub.HasTexcoordInput () &&
            mesh.HasSource ()) {
                bool foundTexcoordInputSource;
                unsigned sourceIndex = 0;
                do {
                        foundTexcoordInputSource = false;
                        string texcoordSourceID, texcoordSourceName;
                        unsigned texcoordOffset;
                        unsigned setIndex;
                        set<string> sourceIDs;
                        if (inputHub.GetTexcoordInputSourceIDbyIndex (
                                sourceIndex++,
                                texcoordSourceID,
                                texcoordOffset, setIndex)) {
                                SourceElement	texcoordsSource(mesh);
                                sourceIDs.insert (texcoordSourceID);
                                if (mesh.LinkSource (texcoordSourceID, texcoordsSource)) {
                                        Element::FloatArray	texcoordsArray;
                                        if (texcoordsSource.LinkFloatArray (texcoordsArray)) {
                                                if (texcoordsSource.GetStride () == 2) {
                                                        /*
                                                         * UV or ST can copy straight across.
                                                         */
                                                        texcoords.push_back (texcoordsArray);
                                                }
                                                else if ((texcoordsSource.GetStride () == 3) &&
                                                          texcoordsArray.size () == texcoordsSource.GetCount () * 3) {
                                                        /*
                                                         * Filter out the third "P" parameter for each triplet.
                                                         */
                                                        Element::FloatArray filteredArray;
                                                        for (Element::FloatArray::const_iterator iter = texcoordsArray.begin ();
                                                                iter != texcoordsArray.end ();
                                                                ++iter) {
                                                                filteredArray.push_back (*(iter++));
                                                                filteredArray.push_back (*(iter++));
                                                        }
                                                        texcoords.push_back (filteredArray);
                                                }
                                                else if ((texcoordsSource.GetStride () == 4) &&
                                                          texcoordsArray.size () == texcoordsSource.GetCount () * 4) {
                                                        /*
                                                         * Filter out the third and fourth "P" and "Q" params for each quad.
                                                         */
                                                        Element::FloatArray filteredArray;
                                                        for (Element::FloatArray::const_iterator iter = texcoordsArray.begin ();
                                                                iter != texcoordsArray.end ();
                                                                ++iter) {
                                                                filteredArray.push_back (*(iter++));
                                                                filteredArray.push_back (*(iter++));
                                                                ++iter;
                                                        }
                                                        texcoords.push_back (filteredArray);
                                                }
                                                else {
                                                        result = LXe_NOACCESS;
                                                }
                                                if (result != LXe_NOACCESS) {
                                                        if (texcoordUVMapIDs.find (
                                                                texcoordSourceID) == texcoordUVMapIDs.end ()) {
                                                                /*
                                                                 * [TODO] Store the unfiltered
                                                                 *        UV map name in the
                                                                 *        modo profile.
                                                                 */
                                                                string uvMapName(texcoordsSource.GetName ());
                                                                if (uvMapName.empty ()) {
                                                                        uvMapName = texcoordSourceID;
                                                                }
#if defined(COLLADALOADER_VERBOSE_LOGGING)
                                                                log.Info (uvMapName);
#endif
                                                                unsigned uvMap = scene_build.AddMap (
                                                                        LXi_VMAP_TEXTUREUV,
                                                                        uvMapName.c_str ());
                                                                texcoordOffsets.push_back (texcoordOffset);
                                                                texcoordUVMapIDs.insert (texcoordSourceID);
                                                                texcoordUVMaps.push_back (uvMap);

                                                                foundTexcoordInputSource = true;
                                                        }
                                                        result = LXe_OK;
                                                }
                                        }
                                }
                        }
                } while (foundTexcoordInputSource);
        }

        return LOG_ERR (result);
}

/*
 * Load the vertex map colors from the given vertex map input hub.
 */
        LxResult
COLLADASceneLoader::LoadColors (
        MeshElement		&mesh,
        const VertexMapInputHub	&inputHub)
{
        LxResult	result = LXe_FALSE;

        if (inputHub.HasColorInput () &&
            mesh.HasSource ()) {
                bool foundColorInputSource;
                unsigned sourceIndex = 0;
                do {
                        foundColorInputSource = false;
                        string colorSourceID, colorSourceName;
                        unsigned colorOffset;
                        unsigned setIndex;
                        set<string> sourceIDs;
                        if (inputHub.GetColorInputSourceIDbyIndex (
                                sourceIndex++,
                                colorSourceID,
                                colorOffset, setIndex)) {
                                SourceElement	colorSource(mesh);
                                sourceIDs.insert (colorSourceID);
                                if (mesh.LinkSource (colorSourceID, colorSource)) {
                                        Element::FloatArray	colorsArray;
                                        unsigned colorMapStride = colorSource.GetStride ();
                                        if (colorSource.LinkFloatArray (colorsArray)) {
                                                if (colorMapStride == 3 || // RGB
                                                    colorMapStride == 4) { // RGBA
                                                        /*
                                                         * RGB and RGBA can copy straight across.
                                                         */
                                                        colors.push_back (colorsArray);
                                                        result = LXe_OK;
                                                }
                                                else {
                                                        /*
                                                         * We only load RGB or RGBA.
                                                         */
                                                        result = LXe_NOACCESS;
                                                }
                                                if (result != LXe_NOACCESS) {
                                                        if (colorMapIDs.find (
                                                                colorSourceID) == colorMapIDs.end ()) {
                                                                /*
                                                                 * [TODO] Store the unfiltered
                                                                 *        color map name in the
                                                                 *        modo profile.
                                                                 */
                                                                string colorMapName(colorSource.GetName ());
                                                                if (colorMapName.empty ()) {
                                                                        colorMapName =
                                                                                string(ATTRVALUE_COLORSETPREFIX) +
                                                                                IntegerToString(
                                                                                        static_cast<unsigned>(
                                                                                                sourceIDs.size ()) - 1);
                                                                }
#if defined(COLLADALOADER_VERBOSE_LOGGING)
                                                                log.Info (colorMapName);
#endif
                                                                unsigned colorMap = scene_build.AddMap (
                                                                        ((colorMapStride == 4) ?
                                                                                LXi_VMAP_RGBA :
                                                                                LXi_VMAP_RGB),
                                                                        colorMapName.c_str ());
                                                                colorOffsets.push_back (colorOffset);
                                                                colorMapIDs.insert (colorSourceID);
                                                                colorMaps.push_back (colorMap);
                                                                colorMapStrides.push_back (colorMapStride);

                                                                foundColorInputSource = true;
                                                        }
                                                        result = LXe_OK;
                                                }
                                        }
                                }
                        }
                } while (foundColorInputSource);
        }

        return result;
}

/*
 * Load the vertex map weights from the given vertex map input hub.
 */
        LxResult
COLLADASceneLoader::LoadWeights (
        MeshElement		&mesh,
        const VertexMapInputHub	&inputHub)
{
        LxResult	result(LXe_FAILED);

        if (inputHub.HasWeightInput () &&
            mesh.HasSource ()) {
                bool foundWeightInputSource;
                unsigned sourceIndex = 0;
                do {
                        foundWeightInputSource = false;
                        string weightSourceID, weightSourceName;
                        unsigned weightOffset;
                        unsigned setIndex;
                        set<string> sourceIDs;
                        if (inputHub.GetWeightInputSourceIDbyIndex (
                                sourceIndex++,
                                weightSourceID,
                                weightOffset, setIndex)) {
                                SourceElement	weightSource(mesh);
                                sourceIDs.insert (weightSourceID);
                                if (mesh.LinkSource (weightSourceID, weightSource)) {
                                        Element::FloatArray	weightArray;
                                        if (weightSource.LinkFloatArray (weightArray)) {
                                                /*
                                                 * Single float weights copy straight across.
                                                 */
                                                weights.push_back (weightArray);
                                                if (weightMapIDs.find (
                                                        weightSourceID) == weightMapIDs.end ()) {
                                                        /*
                                                         * [TODO] Store the unfiltered
                                                         *        weight map name in the
                                                         *        modo profile.
                                                         */
                                                        string weightMapName(weightSource.GetName ());
                                                        if (weightMapName.empty ()) {
                                                                weightMapName =
                                                                        string(ATTRVALUE_WEIGHTSETPREFIX) +
                                                                        IntegerToString(
                                                                                static_cast<unsigned>(sourceIDs.size ()) - 1);
                                                        }
#if defined(COLLADALOADER_VERBOSE_LOGGING)
                                                        log.Info (weightMapName);
#endif
                                                        unsigned weightMap = scene_build.AddMap (
                                                                LXi_VMAP_WEIGHT,
                                                                weightMapName.c_str ());
                                                        weightOffsets.push_back (weightOffset);
                                                        weightMapIDs.insert (weightSourceID);
                                                        weightMaps.push_back (weightMap);

                                                        foundWeightInputSource = true;
                                                }
                                                result = LXe_OK;
                                        }
                                }
                        }
                } while (foundWeightInputSource);
        }

        return LOG_ERR (result);
}

        LxResult
COLLADASceneLoader::LoadScene (
        COLLADAElement	&collada,
        string		&visualSceneID)
{
        LxResult	result(LXe_FAILED);

        if (collada.HasScene ()) {
                SceneElement scene(collada);

                /*
                 * If a scene element is present, the
                 * visual scene URI must be present,
                 * or we don't have a valid document.
                 */
                if( scene.GetVisualSceneID(visualSceneID) ) {
                        result = LXe_OK;
                }
                else {
                        result = LXe_NOTFOUND;
                }
        }
        else {
                /*
                 * A scene is not required, so we return FALSE, which is
                 * not a fatal error condition. The COLLADA document may
                 * only contain a library of images or some other support
                 * data that is useful on its own.
                 */
                result = LXe_FALSE;
        }

        return LOG_ERR (result);
}

        const COLLADAprefs&
COLLADASceneLoader::GetPrefs () const
{
        return prefs;
}

