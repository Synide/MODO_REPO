/*
 * COLLADA Plug-in Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef COLLADABIND_H
#define COLLADABIND_H

#include "../libcolladaio/cio_strings.h"
#include "../libcolladaio/cio_bind.h"

/*
 * ---------------------------------------------------------------------------
 * Item type channel.
 */
class ItemTypeChannel
{
    public:
                                 ItemTypeChannel (
                                        const std::string	&itemType,
                                        const std::string	&channel,
                                        const std::string	&paramSID,
                                        const std::string	&paramName,
                                        cio::ParamType		&paramType);

        virtual			~ItemTypeChannel ();

        /*
         * Return the type of the item.
         */
        std::string		 ItemType () const;

        /*
         * Return the channel name.
         */
        std::string		 Channel () const;

        /*
         * Return the scoped ID for the parameter.
         */
        std::string		 GetParamSID () const;

        /*
         * Return the human-readable name for the parameter.
         */
        std::string		 GetParamName () const;

        /*
         * Return the underlying data type used to store the parameter.
         */
        cio::ParamType		 GetParamType () const;

        /*
         * Comparison operator for sorting.
         */
                bool
        operator< (const ItemTypeChannel &other) const
        {
                bool	otherLessThan;
                if (itemTypeName != other.itemTypeName) {
                        otherLessThan = (itemTypeName > other.itemTypeName);
                }
                else if (channelName != other.channelName) {
                        otherLessThan = (channelName > other.channelName);
                }
                else {
                        otherLessThan = false;
                }

                return otherLessThan;
        }

    private:
        std::string		 itemTypeName;
        std::string		 channelName;
        std::string		 paramUniqueSID;
        std::string		 paramFriendlyName;
        cio::ParamType		 paramVarType;
};

/*
 * ---------------------------------------------------------------------------
 * Item type channel bind.
 */

class ItemTypeChannelVisitor;

class ItemTypeChannelBind
{
    public:
                                 ItemTypeChannelBind ();
        virtual			~ItemTypeChannelBind();

        /*
         * Pass back a list of item sub types for a given item type.
         */
        void			 GetItemSubTypes (
                                        const std::string	&itemType,
                                        cio::StringArray	&itemSubTypes);

        /*
         * Add an item sub type for a given item type.
         */
        void			 AddItemSubType (
                                        const std::string	&itemType,
                                        const std::string	&itemSubType);
        
        /*
         * Add an item type channel binding.
         */
        void			 AddItemTypeChannel (
                                        const ItemTypeChannel	&itemTypeChannel);

        /*
         * Visit items and their channels according to the
         * extent of the given visitor.
         */
        void			 VisitItemTypeChannels (
                                        ItemTypeChannelVisitor *visitor);

        /*
         * Visit all channels for all item sub types of the given item type,
         * according to the extent of the given visitor, for which valid
         * extent values are VISIT_EXTENT_FIRST_WANTED_CHANNEL and
         * VISIT_EXTENT_ALL_CHANNELS.
         */
        void			 VisitItemTypeChannels (
                                        const std::string	&itemType,
                                        ItemTypeChannelVisitor	*visitor);

        /*
         * Visit all channels for all of the given item types, in their
         * original tree order, for which valid extent values are
         * VISIT_EXTENT_FIRST_WANTED_CHANNEL and VISIT_EXTENT_ALL_CHANNELS.
         */
        void			 VisitItemTypeChannels (
                                        const cio::StringArray	&itemTypes,
                                        ItemTypeChannelVisitor	*visitor);

    private:
        struct pv_ItemTypeChannelBind	*pv;
};

/*
 * ---------------------------------------------------------------------------
 * Item type channel visitor.
 */

typedef enum en_VisitExtent
{
        VISIT_EXTENT_FIRST_ITEM_OF_EACH_TYPE,
        VISIT_EXTENT_ALL_ITEMS,
        VISIT_EXTENT_FIRST_WANTED_CHANNEL,
        VISIT_EXTENT_ALL_CHANNELS
} VisitExtent;

typedef enum en_VisitTask
{
        VISIT_TASK_FIND_ITEM_TYPES_AND_ACTIVE_CHANNELS,
        VISIT_TASK_BUILD_ANIMATION_LIBRARY,
        VISIT_TASK_BUILD_LIGHT_LIBRARY,
        VISIT_TASK_BUILD_SHADER_NODE_LIBRARY
} VisitTask;

class ItemTypeChannelVisitor
{
        friend class ItemTypeChannelBind;

    public:
                                 ItemTypeChannelVisitor ();
        virtual			~ItemTypeChannelVisitor ();

        /*
         * Return the extent of the current traversal.
         */
        VisitExtent		 GetVisitExtent () const;

        /*
         * Set the extent of the next visit traversal.
         */
        void			 SetVisitExtent (VisitExtent extent);

        /*
         * Get the task being performed during the current traversal.
         */
        VisitTask		 GetVisitTask () const;

        /*
         * Set the task to be performed during the next traversal.
         */
        void			 SetVisitTask (VisitTask task);

        /*
         * Pure virtual. Implementor prepares to scan items of the given type.
         */
        virtual void		 StartItemScan (
                                        const std::string	&itemTypeName) = 0;

        /*
         * Pure virtual. Implementor returns true if the next item was found.
         */
        virtual bool		 NextItem () = 0;

        /*
         * Pure virtual. Implementor returns true if the item should be processed.
         */
        virtual bool		 WantItem () const = 0;

        /*
         * Pure virtual. Implementor returns true if the channel is in use.
         */
        virtual bool		 WantChannel (
                                        const std::string	&itemTypeName,
                                        const std::string	&channel,
                                        cio::ParamType		 paramType) = 0;

        /*
         * Process the first item of a given type. Optional override.
         */
        virtual void		 ProcessFirstItem (
                                        const std::string	&itemTypeName);

        /*
         * Process an item of a given type. Optional override.
         */
        virtual void		 ProcessItem (
                                        const std::string	&itemTypeName);

        /*
         * Process an item channel. Optional override.
         */
        virtual void		 ProcessItemTypeChannel (
                                        const ItemTypeChannel	&itemTypeChannel);

        /*
         * Returns true if at least one item of any type was found.
         */
        bool			 FoundAnyItemType () const;

        /*
         * Returns true if an item of the given item type was found.
         */
        bool			 FoundItemType (
                                        const std::string	&itemType) const;

        /*
         * Returns true if an item of one of the given item types was found.
         */
        bool			 FoundItemType (
                                        const cio::StringArray	&itemTypes) const;

        /*
         * Returns true if any channels were in use.
         */
        bool			 FoundAnyChannel () const;

        /*
         * Returns true if a channel was found for the given item type.
         */
        bool			 FoundChannel (
                                        const std::string	&itemType) const;

        /*
         * Returns true if a channel was found for one of the given item types.
         */
        bool			 FoundChannel (
                                        const cio::StringArray	&itemTypes) const;

        /*
         * Returns true if the given channel was found for the given item type.
         */
        bool			 FoundChannel (
                                        const std::string	&itemType,
                                        const std::string	&channel) const;

    protected:
        /*
         * Visiting the first item type. Initialize for a new traversal.
         */
        void			 VisitFirstItemType ();

        /*
         * Starts a scan for the first item of a given type, and returns
         * true if the initial scan found an item of the given type.
         */
        bool			 VisitFirstItemType (
                                        const std::string	&itemType);

        /*
         * Asks the implementor if the channel is in use via WantChannel,
         * and then in "find" task mode, marks the channel and its item
         * type if it's in use.
         */
        bool			 VisitItemTypeChannel (
                                        const ItemTypeChannel	&itemTypeChannel);

    private:
        struct pv_ItemTypeChannelVisitor	*pv;
};

#endif // COLLADABIND_H

