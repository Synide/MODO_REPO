/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_collada.h"

#include "cio_animation.h"
#include "cio_asset.h"
#include "cio_camera.h"
#include "cio_controller.h"
#include "cio_effect.h"
#include "cio_geometry.h"
#include "cio_image.h"
#include "cio_light.h"
#include "cio_material.h"
#include "cio_node.h"
#include "cio_profiles.h"
#include "cio_schema.h"
#include "cio_scene.h"
#include "cio_shadernode.h"
#include "cio_visualscene.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * The root COLLADA element.
 */

struct pv_COLLADAElement
{
        pv_COLLADAElement ()
        {
        }

        ElementXML*	GetAsset (ElementXML *element) const
        {
                /*
                 * [TODO] Optimize this by adding an "asset" member variable,
                 *        which can be checked against NULL, after which we
                 *        can quickly pass back the previously found element
                 *        pointer without walking the local node subtree.
                 */
                return HandleXML(element).FirstChildElement (
                        ELEMENT_ASSET).Element ();
        }

        ElementXML* GetAnimationLibrary (ElementXML *element) const
        {
                /*
                 * [TODO] Optimize this by adding an "library_animations" member
                 *        variable, which can be checked against NULL, after
                 *        which we can quickly pass back the previously found
                 *        element pointer without walking the local node subtree.
                 */
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_ANIMATIONS).Element ();
        }

        ElementXML* GetCameraLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_CAMERAS).Element ();
        }

        ElementXML* GetControllerLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_CONTROLLERS).Element ();
        }

        ElementXML* GetEffectLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_EFFECTS).Element ();
        }

        ElementXML* GetGeometryLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_GEOMETRIES).Element ();
        }

        ElementXML* GetImageLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_IMAGES).Element ();
        }

        ElementXML* GetLightLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_LIGHTS).Element ();
        }

        ElementXML* GetMaterialLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_MATERIALS).Element ();
        }

        ElementXML* GetNodeLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_NODES).Element ();
        }

        ElementXML* GetVisualSceneLibrary (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_LIBRARY_VISUAL_SCENES).Element ();
        }

        ElementXML* GetScene (ElementXML *element) const
        {
                return HandleXML(element).FirstChildElement (
                        ELEMENT_SCENE).Element ();
        }
};

COLLADAElement::COLLADAElement (
        IO_MODE	 ioMode,
        bool		 formattedArrays)
        :
        Element(ioMode, formattedArrays),
        pv(new pv_COLLADAElement())
{
}

COLLADAElement::~COLLADAElement ()
{
        delete pv;
}

        bool
COLLADAElement::HasAsset () const
{
        return (pv->GetAsset (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasAnimationLibrary () const
{
        return (pv->GetAnimationLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasCameraLibrary () const
{
        return (pv->GetCameraLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasControllerLibrary () const
{
        return (pv->GetControllerLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasEffectLibrary () const
{
        return (pv->GetEffectLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasGeometryLibrary () const
{
        return (pv->GetGeometryLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasImageLibrary () const
{
        return (pv->GetImageLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasLightLibrary () const
{
        return (pv->GetLightLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasMaterialLibrary () const
{
        return (pv->GetMaterialLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasNodeLibrary () const
{
        /*
         * Search for a library of nodes that is not the modo profile shader tree.
         *
         * For example, Google Sketchup outputs a generic node library, while
         * modo outputs a custom profile node library with a "shader_tree" ID.
         */
        ElementXML	*nodeLibElem = pv->GetNodeLibrary (GetElement ());
        bool	found(false);
        if (nodeLibElem) {
                do {
                        found = (GetID (nodeLibElem) != string(SHADER_TREE));
                        if (!found) {
                                nodeLibElem = nodeLibElem->NextSiblingElement (ELEMENT_LIBRARY_NODES);
                        }
                } while (nodeLibElem && !found);
        }

        return found;
}

        bool
COLLADAElement::HasShaderNodeLibraryTechniqueProfile_modo401 () const
{
        /*
         * Search for the shader tree library of nodes.
         */
        ElementXML	*nodeLibElem = pv->GetNodeLibrary (GetElement ());
        bool	found(false);
        do {
                found = (GetID (nodeLibElem) == string(SHADER_TREE));
                if (!found) {
                        nodeLibElem = nodeLibElem->NextSiblingElement (ELEMENT_LIBRARY_NODES);
                }
        } while (nodeLibElem && !found);

        return found;
}

        bool
COLLADAElement::HasVisualSceneLibrary () const
{
        return (pv->GetVisualSceneLibrary (GetElement ()) != NULL);
}

        bool
COLLADAElement::HasScene () const
{
        return (pv->GetScene (GetElement ()) != NULL);
}

        bool
COLLADAElement::LinkAsset (AssetElement &asset)
{
        asset.SetElement (pv->GetAsset (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddAsset (AssetElement &asset)
{
        asset.SetElement (AddElement (ELEMENT_ASSET));
}

        bool
COLLADAElement::LinkAnimationLibrary (
        AnimationLibraryElement &library)
{
        library.SetElement (pv->GetAnimationLibrary (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddAnimationLibrary (
        AnimationLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_ANIMATIONS));
}

        bool
COLLADAElement::LinkCameraLibrary (
        CameraLibraryElement &library)
{
        library.SetElement (pv->GetCameraLibrary (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddCameraLibrary (
        CameraLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_CAMERAS));
}

        bool
COLLADAElement::LinkControllerLibrary (
        ControllerLibraryElement &library)
{
        library.SetElement (pv->GetControllerLibrary (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddControllerLibrary (
        ControllerLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_CONTROLLERS));
}

        bool
COLLADAElement::LinkEffectLibrary (
        EffectLibraryElement &library)
{
        library.SetElement (pv->GetEffectLibrary (GetElement ()));

        return (GetElement () != NULL);
}

 	void
COLLADAElement::AddEffectLibrary (
        EffectLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_EFFECTS));
}

        bool
COLLADAElement::LinkGeometryLibrary (
        GeometryLibraryElement &library)
{
        library.SetElement (pv->GetGeometryLibrary (GetElement ()));

        return (GetElement () != NULL);
}

 	void
COLLADAElement::AddGeometryLibrary (
        GeometryLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_GEOMETRIES));
}

        bool
COLLADAElement::LinkImageLibrary (
        ImageLibraryElement &library)
{
        library.SetElement (pv->GetImageLibrary (GetElement ()));

        return (GetElement () != NULL);
}

 	void
COLLADAElement::AddImageLibrary (
        ImageLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_IMAGES));
}

        bool
COLLADAElement::LinkMaterialLibrary (
        MaterialLibraryElement &library)
{
        library.SetElement (pv->GetMaterialLibrary (GetElement ()));

        return (GetElement () != NULL);
}

 	void
COLLADAElement::AddMaterialLibrary (
        MaterialLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_MATERIALS));
}

        bool
COLLADAElement::LinkLightLibrary (
        LightLibraryElement &library)
{
        library.SetElement (pv->GetLightLibrary (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddLightLibrary (
        LightLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_LIGHTS));
}

        bool
COLLADAElement::LinkShaderNodeLibraryTechniqueProfile_modo401 (
        ShaderNodeLibraryElement_modo401 &library)
{
        library.SetElement (pv->GetNodeLibrary (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddShaderNodeLibraryTechniqueProfile_modo401 (
        ShaderNodeLibraryElement_modo401 &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_NODES));
}

        bool
COLLADAElement::LinkNodeLibrary (
        NodeLibraryElement &library)
{
        library.SetElement (pv->GetNodeLibrary (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddNodeLibrary (
        NodeLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_NODES));
}

        bool
COLLADAElement::LinkVisualSceneLibrary (
        VisualSceneLibraryElement &library)
{
        library.SetElement (pv->GetVisualSceneLibrary (GetElement ()));

        return (GetElement () != NULL);
}

        void
COLLADAElement::AddVisualSceneLibrary (
        VisualSceneLibraryElement &library)
{
        library.SetElement (AddElement (ELEMENT_LIBRARY_VISUAL_SCENES));
}

        bool
COLLADAElement::LinkScene (SceneElement &scene)
{
        scene.SetElement (pv->GetScene (GetElement ()));

        return (GetElement () != NULL);
}

 	void
COLLADAElement::AddScene (
        SceneElement &scene)
{
        scene.SetElement (AddElement (ELEMENT_SCENE));
}

} // namespace cio

