/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_material.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Instance Effect.
 */

InstanceEffectElement::InstanceEffectElement (
        MaterialElement	&material)
        :
        Element(material.PV ())
{
}

InstanceEffectElement::~InstanceEffectElement ()
{
}

        string
InstanceEffectElement::GetURL () const
{
        return GetAttribute (ATTRIBUTE_URL);
}

/*
 * Effect param overrides. These have precedence over their
 * corresponding parameters in the effect.
 */

        bool
InstanceEffectElement::HasSetParamAmbient () const
{
        /*
         * Iterate over the instance effect sub-nodes, looking for the
         * setparam element whose ref attribute is ATTRVALUE_AMBIENT.
         */
        bool	found(false);
        ElementXML *setParamElem = GetElementHandle ().FirstChildElement (
                ELEMENT_SETPARAM).Element ();
        while (setParamElem) {
                const char *text = setParamElem->Attribute (ATTRIBUTE_REF);
                if (text && string(text) == string(ATTRVALUE_AMBIENT)) {
                        found = true;
                        break;
                }
                else {
                        setParamElem = setParamElem->NextSiblingElement (
                                ELEMENT_SETPARAM);
                }
        }

        if (found) {
                found = (HandleXML(setParamElem).FirstChildElement (
                        ELEMENT_FLOAT3).Element () != NULL);
        }

        return found;
}

        void
InstanceEffectElement::GetSetParamAmbientColor (
        ColorRGB		&color)
{
}

        bool
InstanceEffectElement::HasSetParamDiffuse () const
{
        /*
         * Iterate over the instance effect sub-nodes, looking for the
         * setparam element whose ref attribute is ATTRVALUE_DIFFUSE.
         */
        bool	found(false);
        ElementXML *setParamElem = GetElementHandle ().FirstChildElement (
                ELEMENT_SETPARAM).Element ();
        while (setParamElem) {
                const char *text = setParamElem->Attribute (ATTRIBUTE_REF);
                if (text && string(text) == string(ATTRVALUE_DIFFUSE)) {
                        found = true;
                        break;
                }
                else {
                        setParamElem = setParamElem->NextSiblingElement (
                                ELEMENT_SETPARAM);
                }
        }

        if (found) {
                found = (HandleXML(setParamElem).FirstChildElement (
                        ELEMENT_FLOAT3).Element () != NULL);
        }

        return found;
}

        void
InstanceEffectElement::GetSetParamDiffuseColor (
        ColorRGB		&color)
{
}

        bool
InstanceEffectElement::HasSetParamSpecularColor () const
{
        /*
         * Iterate over the instance effect sub-nodes, looking for the
         * setparam element whose ref attribute is ATTRVALUE_SPECULAR.
         */
        bool	found(false);
        ElementXML *setParamElem = GetElementHandle ().FirstChildElement (
                ELEMENT_SETPARAM).Element ();
        while (setParamElem) {
                const char *text = setParamElem->Attribute (ATTRIBUTE_REF);
                if (text && string(text) == string(ATTRVALUE_SPECULAR)) {
                        found = true;
                        break;
                }
                else {
                        setParamElem = setParamElem->NextSiblingElement (
                                ELEMENT_SETPARAM);
                }
        }

        if (found) {
                found = (HandleXML(setParamElem).FirstChildElement (
                        ELEMENT_FLOAT3).Element () != NULL);
        }

        return found;
}


        void
InstanceEffectElement::GetSetParamSpecularColor (
        ColorRGB		&color)
{
        /*
         * Iterate over the instance effect sub-nodes, looking for the
         * setparam element whose ref attribute is ATTRVALUE_SHININESS.
         */
        bool	found(false);
        ElementXML *setParamElem = GetElementHandle ().FirstChildElement (
                ELEMENT_SETPARAM).Element ();
        while (setParamElem) {
                const char *text = setParamElem->Attribute (ATTRIBUTE_REF);
                if (text && string(text) == string(ATTRVALUE_SHININESS)) {
                        found = true;
                        break;
                }
                else {
                        setParamElem = setParamElem->NextSiblingElement (
                                ELEMENT_SETPARAM);
                }
        }

        if (found) {
                found = false;
                ElementXML *float3Elem = HandleXML(setParamElem).FirstChildElement (
                        ELEMENT_FLOAT3).Element ();
                if (float3Elem) {

                        found = true;
                }
        }
}

        bool
InstanceEffectElement::HasSetParamShininess () const
{
        /*
         * Iterate over the instance effect sub-nodes, looking for the
         * setparam element whose ref attribute is "SHININESS".
         */
        bool	found(false);
        ElementXML *setParamElem = GetElementHandle ().FirstChildElement (
                ELEMENT_SETPARAM).Element ();
        while (setParamElem) {
                const char *text = setParamElem->Attribute (ATTRIBUTE_REF);
                if (text && string(text) == string(ATTRVALUE_SHININESS)) {
                        found = true;
                        break;
                }
                else {
                        setParamElem = setParamElem->NextSiblingElement (
                                ELEMENT_SETPARAM);
                }
        }

        if (found) {
                found = (HandleXML(setParamElem).FirstChildElement (
                        ELEMENT_FLOAT).Element () != NULL);
        }

        return found;
}

        float
InstanceEffectElement::GetSetParamShininess () const
{
        float	shininess(0.0f);

        /*
         * Iterate over the instance effect sub-nodes, looking for the
         * setparam element whose ref attribute is "SHININESS".
         */
        bool	found(false);
        ElementXML *setParamElem = GetElementHandle ().FirstChildElement (
                ELEMENT_SETPARAM).Element ();
        while (setParamElem) {
                const char *text = setParamElem->Attribute (ATTRIBUTE_REF);
                if (text && string(text) == string(ATTRVALUE_SHININESS)) {
                        found = true;
                        break;
                }
                else {
                        setParamElem = setParamElem->NextSiblingElement (
                                ELEMENT_SETPARAM);
                }
        }

        if (found) {
                found = false;
                ElementXML *floatElem = HandleXML(setParamElem).FirstChildElement (
                        ELEMENT_FLOAT3).Element ();
                if (floatElem) {
                        shininess = GetElementValueFloat (floatElem);
                        found = true;
                }
        }

        return shininess;
}

/*
 * ---------------------------------------------------------------------------
 * Material.
 */

MaterialElement::MaterialElement (
         MaterialLibraryElement &library,
         const std::string	&name)
        :
        Element(library.PV ())
{
        library.AddMaterial (*this);

        SetID (MaterialID (ItemID (name)));
        SetName (name);

        ElementXML *instance = AddElement (ELEMENT_INSTANCE_EFFECT);
        SetAttribute (instance, ATTRIBUTE_URL, URI_Ref (EffectID (ItemID (name))));
}

MaterialElement::MaterialElement (
        MaterialLibraryElement &library)
        :
        Element(library.PV ())
{
}

MaterialElement::~MaterialElement ()
{
}

        bool
MaterialElement::HasInstanceEffect () const
{
        return HasChildElement (ELEMENT_INSTANCE_EFFECT);
}

        bool
MaterialElement::LinkInstanceEffect (
        InstanceEffectElement	&instanceEffect)
{
        return LinkFirstChildElement (ELEMENT_INSTANCE_EFFECT, instanceEffect);
}

/*
 * ---------------------------------------------------------------------------
 * Material Library.
 */

MaterialLibraryElement::MaterialLibraryElement (COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddMaterialLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkMaterialLibrary (*this);
        }
}

MaterialLibraryElement::~MaterialLibraryElement ()
{
}

        bool
MaterialLibraryElement::HasMaterial () const
{
        return HasChildElement (ELEMENT_MATERIAL);
}

        bool
MaterialLibraryElement::LinkMaterial (
        const std::string	&materialID,
        MaterialElement		&material)
{
        return LinkFirstChildElement (ELEMENT_MATERIAL, materialID, material);
}

        void
MaterialLibraryElement::AddMaterial (MaterialElement &material)
{
        material.SetElement (AddElement (ELEMENT_MATERIAL));
}

} // namespace cio

