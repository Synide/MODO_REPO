/*
 * COLLADAio library for Scene I/O
 *
 * Copyright (c) 2008-2015 The Foundry Group LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.   Except as contained
 * in this notice, the name(s) of the above copyright holders shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#include "cio_effect.h"

#include "cio_collada.h"
#include "cio_schema.h"
#include "cio_profiles.h"
#include "cio_strings.h"

#include <lx_util.hpp>

#include <string>

using namespace std;

namespace cio {

/*
 * ---------------------------------------------------------------------------
 * Shaders.
 */

struct pv_ShaderElement
{
        pv_ShaderElement ()
                :
                shader(NULL),

                emission(NULL),
                emissionColor(NULL),
                emissionTexture(NULL),

                ambient(NULL),
                ambientColor(NULL),
                ambientTexture(NULL),

                diffuse(NULL),
                diffuseColor(NULL),
                diffuseTexture(NULL),

                specular(NULL),
                specularColor(NULL),
                specularTexture(NULL),

                shininess(NULL),
                shininessFloat(NULL),

                reflective(NULL),
                reflectiveColor(NULL),
                reflectiveTexture(NULL),
                reflectivity(NULL),
                reflectivityFloat(NULL),

                transparent(NULL),
                transparentColor(NULL),
                transparentTexture(NULL),

                transparency(NULL),
                transparencyFloat(NULL),

                indexOfRefraction(NULL),
                indexOfRefractionFloat(NULL)
        {
        }

        bool			 GetShaderColor (
                                        ElementXML			*colorElement,
                                        Element::ColorRGBA		&color);
        void			 SetShaderColor (
                                        ElementXML			**colorParent,
                                        ElementXML			**colorElement,
                                        const string			&parentElementName,
                                        const string			&colorSID,
                                        const Element::ColorRGBA	&color);

        bool			 GetShaderTexture (
                                        ElementXML			*textureElement,
                                        string				&textureName,
                                        string				&texcoordSet);
        void			 SetShaderTexture (
                                        ElementXML			**textureParent,
                                        ElementXML			**textureElement,
                                        const string			&parentElementName,
                                        const string			&textureName,
                                        const string			&texcoordSet);

        bool			 GetShaderFloat (
                                        ElementXML			*amountElement,
                                        double				&amount);
        void			 SetShaderFloat (
                                        ElementXML			**valueParent,
                                        ElementXML			**valueElement,
                                        const string			&parentElementName,
                                        const string			&floatSID,
                                        double				 floatValue);

        bool			 LinkChannels (Element *shaderID);

        bool			 LinkAmount (
                                        const string	&channelName,
                                        ElementXML	**channelElem,
                                        ElementXML	**channelAmount);

        bool			 LinkColorOrTexturePair (
                                        const string	&channelName,
                                        ElementXML	**channelElem,
                                        ElementXML	**channelColor,
                                        ElementXML	**channelTexture);

        void			 SetShader (Element *shaderID);

        /*
         * Shader is either phong, blinn, lambert, or constant.
         */
        Element			*shader;

        ElementXML		*emission;
        ElementXML		*emissionColor;
        ElementXML		*emissionTexture;

        ElementXML		*ambient;
        ElementXML		*ambientColor;
        ElementXML		*ambientTexture;

        ElementXML		*diffuse;

        /*
         * Color and Texture are mutually exclusive.
         */
        ElementXML		*diffuseColor;
        ElementXML		*diffuseTexture;

        ElementXML		*specular;
        ElementXML		*specularColor;
        ElementXML		*specularTexture;

        ElementXML		*shininess;
        ElementXML		*shininessFloat;

        ElementXML		*reflective;
        ElementXML		*reflectiveColor;
        ElementXML		*reflectiveTexture;

        ElementXML		*reflectivity;
        ElementXML		*reflectivityFloat;

        ElementXML		*transparent;
        ElementXML		*transparentColor;
        ElementXML		*transparentTexture;

        ElementXML		*transparency;
        ElementXML		*transparencyFloat;

        ElementXML		*indexOfRefraction;
        ElementXML		*indexOfRefractionFloat;
};

        bool
pv_ShaderElement::GetShaderColor (
        ElementXML			*colorElement,
        Element::ColorRGBA		&color)
{
        bool		hasColor(false);

        if (colorElement) {
                Element::FloatArray	values;
                shader->GetElementValue (colorElement, values);
                if (values.size () <= 4) {
                        for (unsigned channel = 0; channel < values.size (); ++channel) {
                                color[channel] = values[channel];
                        }
                        hasColor = true;
                }
        }

        return hasColor;
}

        void
pv_ShaderElement::SetShaderColor (
        ElementXML			**colorParent,
        ElementXML			**colorElement,
        const string			&parentElementName,
        const string			&colorSID,
        const Element::ColorRGBA	&color)
{
        if (*colorElement) {
                shader->ClearElementValue (*colorElement);
        }
        else {
                *colorParent = shader->AddElement (parentElementName);
                *colorElement = shader->AddElement (*colorParent, ELEMENT_COLOR);
                shader->SetSID (*colorElement, colorSID);
        }

        shader->SetElementValue (*colorElement, color);
}

        bool
pv_ShaderElement::GetShaderTexture (
        ElementXML			*textureElement,
        string				&textureName,
        string				&texcoordSet)
{
        bool		hasTexture(false);

        if (textureElement) {
                textureName = shader->GetAttribute (
                        textureElement, ATTRIBUTE_TEXTURE);
                texcoordSet = shader->GetAttribute (
                        textureElement, ATTRIBUTE_TEXCOORD);
                hasTexture = !textureName.empty () && !texcoordSet.empty ();
        }

        return hasTexture;
}

        void
pv_ShaderElement::SetShaderTexture (
        ElementXML			**textureParent,
        ElementXML			**textureElement,
        const string			&parentElementName,
        const string			&textureName,
        const string			&texcoordSet)
{
        *textureParent = shader->AddElement (parentElementName);
        *textureElement = shader->AddElement (*textureParent, ELEMENT_TEXTURE);
        shader->SetAttribute (*textureElement, ATTRIBUTE_TEXTURE,
                EscapeNCName (textureName) + string(ATTRVALUE_SAMPLERSUFFIX));
        shader->SetAttribute (
                *textureElement, ATTRIBUTE_TEXCOORD,
                EscapeNCName (texcoordSet));
}

        bool
pv_ShaderElement::GetShaderFloat (
        ElementXML			*amountElement,
        double				&amount)
{
        bool		hasAmount(false);

        if (amountElement) {
                amount = shader->GetElementValueDouble (amountElement);

                hasAmount = true;
        }

        return hasAmount;
}

        void
pv_ShaderElement::SetShaderFloat (
        ElementXML			**valueParent,
        ElementXML			**valueElement,
        const string			&parentElementName,
        const string			&valueSID,
        double				 floatValue)
{
        if (*valueElement) {
                shader->ClearElementValue (*valueElement);
        }
        else {
                *valueParent = shader->AddElement (parentElementName);
                *valueElement = shader->AddElement (
                        *valueParent, ELEMENT_FLOAT);
                shader->SetSID (*valueElement, valueSID);
        }

        shader->SetElementValue (*valueElement, floatValue);
}

        bool
pv_ShaderElement::LinkChannels (Element *shaderID)
{
        shader = shaderID;

        /*
         * Color or texture pairs.
         */

        LinkColorOrTexturePair (
                ELEMENT_EMISSION,
                &emission, &emissionColor, &emissionTexture);

        LinkColorOrTexturePair (
                ELEMENT_AMBIENT,
                &ambient, &ambientColor, &ambientTexture);

        LinkColorOrTexturePair (
                ELEMENT_DIFFUSE,
                &diffuse, &diffuseColor, &diffuseTexture);

        LinkColorOrTexturePair (
                ELEMENT_SPECULAR,
                &specular, &specularColor, &specularTexture);

        LinkColorOrTexturePair (
                ELEMENT_REFLECTIVE,
                &reflective, &reflectiveColor, &reflectiveTexture);

        LinkColorOrTexturePair (
                ELEMENT_TRANSPARENT,
                &transparent, &transparentColor, &transparentTexture);

        /*
         * Amount-style channels.
         */
        LinkAmount (ELEMENT_SHININESS, &shininess, &shininessFloat);

        LinkAmount (ELEMENT_REFLECTIVITY, &reflectivity, &reflectivityFloat);

        LinkAmount (ELEMENT_TRANSPARENCY, &transparency, &transparencyFloat);

        /*
         * All channels are optional, so we always return true.
         */
        return true;
}

        bool
pv_ShaderElement::LinkAmount (
        const string	&channelName,
        ElementXML	**channelElem,
        ElementXML	**channelAmount)
{
        bool	linked(false);
        *channelElem = shader->GetElementHandle ().FirstChildElement (
                channelName.c_str ()).Element ();
        if (*channelElem) {
                *channelAmount =
                        shader->GetElementHandle (*channelElem).FirstChildElement (
                                ELEMENT_FLOAT).Element ();
                if (*channelAmount) {
                        linked = true;
                }
        }

        return linked;
}

        bool
pv_ShaderElement::LinkColorOrTexturePair (
        const string	&channelName,
        ElementXML	**channelElem,
        ElementXML	**channelColor,
        ElementXML	**channelTexture)
{
        bool	linked(false);
        *channelElem = shader->GetElementHandle ().FirstChildElement (
                channelName.c_str ()).Element ();
        if (*channelElem) {
                *channelColor =
                        shader->GetElementHandle (*channelElem).FirstChildElement (
                                ELEMENT_COLOR).Element ();
                if (*channelColor) {
                        linked = true;
                }
                else {
                        *channelTexture =
                                shader->GetElementHandle (*channelElem).FirstChildElement (
                                        ELEMENT_TEXTURE).Element ();
                        linked = (*channelTexture != NULL);
                }
        }

        return linked;
}

        void
pv_ShaderElement::SetShader (Element *shaderID)
{
        shader = shaderID;
}

/*
 * ---------------------------------------------------------------------------
 * Constant.
 */
ConstantElement::ConstantElement (
        EffectElement		&effect)
        :
        Element(effect.PV ()),
        pv(new pv_ShaderElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                effect.LinkConstant (*this);
        }
        else if (GetIOMode () == IO_MODE_SAVE) {
                effect.AddConstant (*this);
                pv->SetShader (this);
        }
}

ConstantElement::~ConstantElement ()
{
        delete pv;
}

        bool
ConstantElement::GetEmissionColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->emissionColor, color);
}

        void
ConstantElement::SetEmissionColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->emission, &pv->emissionColor, ELEMENT_EMISSION,
                PARAM_EMISSION_EFFECT_COLOR,
                color);
}

        bool
ConstantElement::GetEmissionColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->emissionTexture, textureName, texcoordSet);
}

        void
ConstantElement::SetEmissionColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->emission, &pv->emissionTexture, ELEMENT_EMISSION,
                textureName, texcoordSet);
}

        bool
ConstantElement::GetReflectiveColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->reflectiveColor, color);
}

        void
ConstantElement::SetReflectiveColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->reflective, &pv->reflectiveColor,
                ELEMENT_REFLECTIVE,
                PARAM_REFLECTIVE_EFFECT_COLOR,
                color);
}

        bool
ConstantElement::GetReflectiveColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->reflectiveTexture, textureName, texcoordSet);
}

        void
ConstantElement::SetReflectiveColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->reflective, &pv->reflectiveTexture,
                ELEMENT_REFLECTIVE,
                textureName, texcoordSet);
}

        bool
ConstantElement::GetReflectivity (double &reflection)
{
        return pv->GetShaderFloat (pv->reflectivityFloat, reflection);
}

        void
ConstantElement::SetReflectivity (double reflection)
{
        pv->SetShaderFloat (
                &pv->reflectivity, &pv->reflectivityFloat,
                ELEMENT_REFLECTIVITY,
                PARAM_REFLECTIVITY_EFFECT,
                reflection);
}

        bool
ConstantElement::GetTransparentColor (
        ColorRGBA		&color,
        FX_Opaque		&mode)
{
        mode = FX_OPAQUE_ALPHA_ONE;
        if (pv->transparent) {
                string modeAttr = GetAttribute (
                        pv->transparent, ATTRIBUTE_OPAQUE);
                if (modeAttr == string(ATTRVALUE_RGB_ZERO)) {
                        mode = FX_OPAQUE_RGB_ZERO;
                }
        }

        return pv->GetShaderColor (pv->transparentColor, color);
}

        void
ConstantElement::SetTransparentColor (
        const ColorRGBA		&color,
        FX_Opaque		 mode)
{
        pv->SetShaderColor (
                &pv->transparent,
                &pv->transparentColor,
                ELEMENT_TRANSPARENT,
                PARAM_TRANSPARENT_EFFECT_COLOR,
                color);

        /*
         * The default opaque mode is FX_OPAQUE_ALPHA_ONE, so we only
         * set the attribute value if it's ATTRVALUE_RGB_ZERO.
         */
        if (mode == FX_OPAQUE_RGB_ZERO) {
                SetAttribute (pv->transparent, ATTRIBUTE_OPAQUE, ATTRVALUE_RGB_ZERO);
        }
}

        bool
ConstantElement::GetTransparentColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->transparentTexture, textureName, texcoordSet);
}

        void
ConstantElement::SetTransparentColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->transparent, &pv->transparentTexture,
                ELEMENT_TRANSPARENT,
                textureName, texcoordSet);
}

        bool
ConstantElement::GetTransparency (double &transparency)
{
        return pv->GetShaderFloat (pv->transparencyFloat, transparency);
}

        void
ConstantElement::SetTransparency (double transparency)
{
        pv->SetShaderFloat (
                &pv->transparency,
                &pv->transparencyFloat,
                ELEMENT_TRANSPARENCY,
                PARAM_TRANSPARENCY_EFFECT,
                transparency);
}

        bool
ConstantElement::GetIndexOfRefraction (double &refraction)
{
        return pv->GetShaderFloat (pv->indexOfRefractionFloat, refraction);
}

        void
ConstantElement::SetIndexOfRefraction (double refraction)
{
        pv->SetShaderFloat (
                &pv->indexOfRefraction,
                &pv->indexOfRefractionFloat,
                ELEMENT_INDEX_OF_REFRACTION,
                PARAM_INDEX_OF_REFRACTION,
                refraction);
}

        bool
ConstantElement::LinkChannels ()
{
        return pv->LinkChannels (this);
}

/*
 * ---------------------------------------------------------------------------
 * Lambert.
 */
LambertElement::LambertElement (
        EffectElement		&effect)
        :
        Element(effect.PV ()),
        pv(new pv_ShaderElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                effect.LinkLambert (*this);
        }
        else if (GetIOMode () == IO_MODE_SAVE) {
                effect.AddLambert (*this);
                pv->SetShader (this);
        }
}

LambertElement::~LambertElement ()
{
        delete pv;
}

        bool
LambertElement::GetEmissionColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->emissionColor, color);
}

        void
LambertElement::SetEmissionColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->emission, &pv->emissionColor, ELEMENT_EMISSION,
                PARAM_EMISSION_EFFECT_COLOR,
                color);
}

        bool
LambertElement::GetEmissionColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->emissionTexture, textureName, texcoordSet);
}

        void
LambertElement::SetEmissionColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->emission, &pv->emissionTexture, ELEMENT_EMISSION,
                textureName, texcoordSet);
}

        bool
LambertElement::GetAmbientColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->ambientColor, color);
}

        void
LambertElement::SetAmbientColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->ambient, &pv->ambientColor, ELEMENT_AMBIENT,
                PARAM_AMBIENT_EFFECT_COLOR,
                color);
}

        bool
LambertElement::GetDiffuseColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->diffuseColor, color);
}

        void
LambertElement::SetDiffuseColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->diffuse, &pv->diffuseColor, ELEMENT_DIFFUSE,
                PARAM_DIFFUSE_EFFECT_COLOR,
                color);
}

        bool
LambertElement::GetDiffuseColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->diffuseTexture, textureName, texcoordSet);
}

        bool
LambertElement::GetReflectiveColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->reflectiveColor, color);
}

        void
LambertElement::SetReflectiveColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->reflective, &pv->reflectiveColor,
                ELEMENT_REFLECTIVE,
                PARAM_REFLECTIVE_EFFECT_COLOR,
                color);
}

        bool
LambertElement::GetReflectiveColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->reflectiveTexture, textureName, texcoordSet);
}

        void
LambertElement::SetReflectiveColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->reflective, &pv->reflectiveTexture,
                ELEMENT_REFLECTIVE,
                textureName, texcoordSet);
}

        bool
LambertElement::GetReflectivity (double &reflection)
{
        return pv->GetShaderFloat (pv->reflectivityFloat, reflection);
}

        void
LambertElement::SetReflectivity (double reflection)
{
        pv->SetShaderFloat (
                &pv->reflectivity, &pv->reflectivityFloat,
                ELEMENT_REFLECTIVITY,
                PARAM_REFLECTIVITY_EFFECT,
                reflection);
}

        bool
LambertElement::GetTransparentColor (
        ColorRGBA		&color,
        FX_Opaque		&mode)
{
        mode = FX_OPAQUE_ALPHA_ONE;
        if (pv->transparent) {
                string modeAttr = GetAttribute (
                        pv->transparent, ATTRIBUTE_OPAQUE);
                if (modeAttr == string(ATTRVALUE_RGB_ZERO)) {
                        mode = FX_OPAQUE_RGB_ZERO;
                }
        }

        return pv->GetShaderColor (pv->transparentColor, color);
}

        void
LambertElement::SetTransparentColor (
        const ColorRGBA		&color,
        FX_Opaque		 mode)
{
        pv->SetShaderColor (
                &pv->transparent,
                &pv->transparentColor,
                ELEMENT_TRANSPARENT,
                PARAM_TRANSPARENT_EFFECT_COLOR,
                color);

        if (mode == FX_OPAQUE_RGB_ZERO) {
                SetAttribute (pv->transparent, ATTRIBUTE_OPAQUE, ATTRVALUE_RGB_ZERO);
        }
}

        bool
LambertElement::GetTransparentColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->transparentTexture, textureName, texcoordSet);
}

        void
LambertElement::SetTransparentColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->transparent, &pv->transparentTexture,
                ELEMENT_TRANSPARENT,
                textureName, texcoordSet);
}

        bool
LambertElement::GetTransparency (double &transparency)
{
        return pv->GetShaderFloat (pv->transparencyFloat, transparency);
}

        void
LambertElement::SetTransparency (double transparency)
{
        pv->SetShaderFloat (
                &pv->transparency,
                &pv->transparencyFloat,
                ELEMENT_TRANSPARENCY,
                PARAM_TRANSPARENCY_EFFECT,
                transparency);
}

        bool
LambertElement::GetIndexOfRefraction (double &refraction)
{
        return pv->GetShaderFloat (pv->indexOfRefractionFloat, refraction);
}

        void
LambertElement::SetIndexOfRefraction (double refraction)
{
        pv->SetShaderFloat (
                &pv->indexOfRefraction,
                &pv->indexOfRefractionFloat,
                ELEMENT_INDEX_OF_REFRACTION,
                PARAM_INDEX_OF_REFRACTION,
                refraction);
}

        bool
LambertElement::LinkChannels ()
{
        return pv->LinkChannels (this);
}

/*
 * ---------------------------------------------------------------------------
 * Blinn.
 */
BlinnElement::BlinnElement (
        EffectElement		&effect)
        :
        Element(effect.PV ()),
        pv(new pv_ShaderElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                effect.LinkBlinn (*this);
        }
        else if (GetIOMode () == IO_MODE_SAVE) {
                effect.AddBlinn (*this);
                pv->SetShader (this);
        }
}

BlinnElement::~BlinnElement ()
{
        delete pv;
}

        bool
BlinnElement::GetEmissionColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->emissionColor, color);
}

        void
BlinnElement::SetEmissionColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->emission, &pv->emissionColor,
                ELEMENT_EMISSION,
                PARAM_EMISSION_EFFECT_COLOR,
                color);
}

        bool
BlinnElement::GetEmissionColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->emissionTexture, textureName, texcoordSet);
}

        void
BlinnElement::SetEmissionColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->emission, &pv->emissionTexture, ELEMENT_EMISSION,
                textureName, texcoordSet);
}

        bool
BlinnElement::GetDiffuseColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->diffuseColor, color);
}

        void
BlinnElement::SetDiffuseColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->diffuse, &pv->diffuseColor, ELEMENT_DIFFUSE,
                PARAM_DIFFUSE_EFFECT_COLOR,
                color);
}

        bool
BlinnElement::GetDiffuseColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->diffuseTexture, textureName, texcoordSet);
}

        bool
BlinnElement::GetSpecularColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->specularColor, color);
}

        bool
BlinnElement::GetSpecularColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->specularTexture, textureName, texcoordSet);
}

        bool
BlinnElement::GetShininess (double &specularity)
{
        return pv->GetShaderFloat (pv->shininessFloat, specularity);
}

        void
BlinnElement::SetShininess (double specularity)
{
        pv->SetShaderFloat (
                &pv->shininess, &pv->shininessFloat,
                ELEMENT_SHININESS,
                PARAM_SPECULAR_EFFECT_COLOR,
                specularity);
}

        bool
BlinnElement::GetReflectiveColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->reflectiveColor, color);
}

        void
BlinnElement::SetReflectiveColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->reflective, &pv->reflectiveColor,
                ELEMENT_REFLECTIVE,
                PARAM_REFLECTIVE_EFFECT_COLOR,
                color);
}

        bool
BlinnElement::GetReflectiveColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->reflectiveTexture, textureName, texcoordSet);
}

        void
BlinnElement::SetReflectiveColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->reflective, &pv->reflectiveTexture,
                ELEMENT_REFLECTIVE,
                textureName, texcoordSet);
}

        bool
BlinnElement::GetReflectivity (double &reflection)
{
        return pv->GetShaderFloat (pv->reflectivityFloat, reflection);
}

        void
BlinnElement::SetReflectivity (double reflection)
{
        pv->SetShaderFloat (
                &pv->reflectivity, &pv->reflectivityFloat,
                ELEMENT_REFLECTIVITY,
                PARAM_REFLECTIVITY_EFFECT,
                reflection);
}

        bool
BlinnElement::GetTransparentColor (
        ColorRGBA		&color,
        FX_Opaque		&mode)
{
        mode = FX_OPAQUE_ALPHA_ONE;
        if (pv->transparent) {
                string modeAttr = GetAttribute (
                        pv->transparent, ATTRIBUTE_OPAQUE);
                if (modeAttr == string(ATTRVALUE_RGB_ZERO)) {
                        mode = FX_OPAQUE_RGB_ZERO;
                }
        }

        return pv->GetShaderColor (pv->transparentColor, color);
}

        void
BlinnElement::SetTransparentColor (
        const ColorRGBA		&color,
        FX_Opaque		 mode)
{
        pv->SetShaderColor (
                &pv->transparent,
                &pv->transparentColor,
                ELEMENT_TRANSPARENT,
                PARAM_TRANSPARENT_EFFECT_COLOR,
                color);

        if (mode == FX_OPAQUE_RGB_ZERO) {
                SetAttribute (pv->transparent, ATTRIBUTE_OPAQUE, ATTRVALUE_RGB_ZERO);
        }
}

        bool
BlinnElement::GetTransparentColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->transparentTexture, textureName, texcoordSet);
}

        void
BlinnElement::SetTransparentColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->transparent, &pv->transparentTexture,
                ELEMENT_TRANSPARENT,
                textureName, texcoordSet);
}

        bool
BlinnElement::GetTransparency (double &transparency)
{
        return pv->GetShaderFloat (pv->transparencyFloat, transparency);
}

        void
BlinnElement::SetTransparency (double transparency)
{
        pv->SetShaderFloat (
                &pv->transparency,
                &pv->transparencyFloat,
                ELEMENT_TRANSPARENCY,
                PARAM_TRANSPARENCY_EFFECT,
                transparency);
}

        bool
BlinnElement::GetIndexOfRefraction (double &refraction)
{
        return pv->GetShaderFloat (pv->indexOfRefractionFloat, refraction);
}

        void
BlinnElement::SetIndexOfRefraction (double refraction)
{
        pv->SetShaderFloat (
                &pv->indexOfRefraction,
                &pv->indexOfRefractionFloat,
                ELEMENT_INDEX_OF_REFRACTION,
                PARAM_INDEX_OF_REFRACTION,
                refraction);
}

        bool
BlinnElement::LinkChannels ()
{
        return pv->LinkChannels (this);
}

/*
 * ---------------------------------------------------------------------------
 * Phong.
 */

PhongElement::PhongElement (
        EffectElement	&effect)
        :
        Element(effect.PV ()),
        pv(new pv_ShaderElement())
{
        if (GetIOMode () == IO_MODE_LOAD) {
                effect.LinkPhong (*this);
        }
        else if (GetIOMode () == IO_MODE_SAVE) {
                effect.AddPhong (*this);
                pv->SetShader (this);
        }
}

PhongElement::~PhongElement ()
{
        delete pv;
}

/*
 * Phong values.
 * For values which have both "Color" and "ColorMap" APIs, the calls
 * are mutually exclusive - use extra profile params to store any
 * combined color and color map pairs.
 *
 * Per the spec, the following APIs must be called in the given order.
 *
 * [TODO] Use insertion indices to enforce the order.
 */

        bool
PhongElement::GetEmissionColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->emissionColor, color);
}

        void
PhongElement::SetEmissionColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->emission, &pv->emissionColor,
                ELEMENT_EMISSION,
                PARAM_EMISSION_EFFECT_COLOR,
                color);
}

        bool
PhongElement::GetEmissionColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->emissionTexture, textureName, texcoordSet);
}

        void
PhongElement::SetEmissionColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->emission, &pv->emissionTexture, ELEMENT_EMISSION,
                textureName, texcoordSet);
}

        bool
PhongElement::GetAmbientColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->ambientColor, color);
}

        void
PhongElement::SetAmbientColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->ambient, &pv->ambientColor, ELEMENT_AMBIENT,
                PARAM_AMBIENT_EFFECT_COLOR,
                color);
}

        bool
PhongElement::GetAmbientColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->ambientTexture, textureName, texcoordSet);
}

        void
PhongElement::SetAmbientColorMap (
        const string& textureName, const string& texcoordSet)
{
        pv->SetShaderTexture (
                &pv->ambient, &pv->ambientTexture, ELEMENT_AMBIENT,
                textureName, texcoordSet);
}

        bool
PhongElement::GetDiffuseColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->diffuseColor, color);
}

        void
PhongElement::SetDiffuseColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->diffuse, &pv->diffuseColor, ELEMENT_DIFFUSE,
                PARAM_DIFFUSE_EFFECT_COLOR,
                color);
}

        bool
PhongElement::GetDiffuseColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->diffuseTexture, textureName, texcoordSet);
}

        void
PhongElement::SetDiffuseColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->diffuse, &pv->diffuseTexture, ELEMENT_DIFFUSE,
                textureName, texcoordSet);
}

        bool
PhongElement::GetSpecularColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->specularColor, color);
}

        void
PhongElement::SetSpecularColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->specular, &pv->specularColor, ELEMENT_SPECULAR,
                PARAM_SPECULAR_EFFECT_COLOR,
                color);
}

        bool
PhongElement::GetSpecularColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->specularTexture, textureName, texcoordSet);
}

        void
PhongElement::SetSpecularColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->specular, &pv->specularTexture, ELEMENT_SPECULAR,
                textureName, texcoordSet);
}

        bool
PhongElement::GetShininess (double &specularity)
{
        return pv->GetShaderFloat (pv->shininessFloat, specularity);
}

        void
PhongElement::SetShininess (double specularity)
{
        pv->SetShaderFloat (
                &pv->shininess, &pv->shininessFloat,
                ELEMENT_SHININESS,
                PARAM_SPECULAR_EFFECT_COLOR,
                specularity);
}

        bool
PhongElement::GetReflectiveColor (ColorRGBA &color)
{
        return pv->GetShaderColor (pv->reflectiveColor, color);
}

        void
PhongElement::SetReflectiveColor (const ColorRGBA &color)
{
        pv->SetShaderColor (
                &pv->reflective, &pv->reflectiveColor,
                ELEMENT_REFLECTIVE,
                PARAM_REFLECTIVE_EFFECT_COLOR,
                color);
}

        bool
PhongElement::GetReflectiveColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->reflectiveTexture, textureName, texcoordSet);
}

        void
PhongElement::SetReflectiveColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->reflective, &pv->reflectiveTexture,
                ELEMENT_REFLECTIVE,
                textureName, texcoordSet);
}

        bool
PhongElement::GetReflectivity (double &reflection)
{
        return pv->GetShaderFloat (pv->reflectivityFloat, reflection);
}

        void
PhongElement::SetReflectivity (double reflection)
{
        pv->SetShaderFloat (
                &pv->reflectivity, &pv->reflectivityFloat,
                ELEMENT_REFLECTIVITY,
                PARAM_REFLECTIVITY_EFFECT,
                reflection);
}

        bool
PhongElement::GetTransparentColor (
        ColorRGBA		&color,
        FX_Opaque		&mode)
{
        mode = FX_OPAQUE_ALPHA_ONE;
        if (pv->transparent) {
                string modeAttr = GetAttribute (
                        pv->transparent, ATTRIBUTE_OPAQUE);
                if (modeAttr == string(ATTRVALUE_RGB_ZERO)) {
                        mode = FX_OPAQUE_RGB_ZERO;
                }
        }

        return pv->GetShaderColor (pv->transparentColor, color);
}

        void
PhongElement::SetTransparentColor (
        const ColorRGBA		&color,
        FX_Opaque		 mode)
{
        pv->SetShaderColor (
                &pv->transparent,
                &pv->transparentColor,
                ELEMENT_TRANSPARENT,
                PARAM_TRANSPARENT_EFFECT_COLOR,
                color);

        if (mode == FX_OPAQUE_RGB_ZERO) {
                SetAttribute (pv->transparent, ATTRIBUTE_OPAQUE, ATTRVALUE_RGB_ZERO);
        }
}

        bool
PhongElement::GetTransparentColorMap (
        string	&textureName,
        string	&texcoordSet)
{
        return pv->GetShaderTexture (
                pv->transparentTexture, textureName, texcoordSet);
}

        void
PhongElement::SetTransparentColorMap (
        const string	&textureName,
        const string	&texcoordSet)
{
        pv->SetShaderTexture (
                &pv->transparent,
                &pv->transparentTexture,
                ELEMENT_TRANSPARENT,
                textureName, texcoordSet);
}

        bool
PhongElement::GetTransparency (double &transparency)
{
        return pv->GetShaderFloat (pv->transparencyFloat, transparency);
}

        void
PhongElement::SetTransparency (double transparency)
{
        pv->SetShaderFloat (
                &pv->transparency,
                &pv->transparencyFloat,
                ELEMENT_TRANSPARENCY,
                PARAM_TRANSPARENCY_EFFECT,
                transparency);
}

        bool
PhongElement::GetIndexOfRefraction (double &refraction)
{
        return pv->GetShaderFloat (pv->indexOfRefractionFloat, refraction);
}

        void
PhongElement::SetIndexOfRefraction (double refraction)
{
        pv->SetShaderFloat (
                &pv->indexOfRefraction,
                &pv->indexOfRefractionFloat,
                ELEMENT_INDEX_OF_REFRACTION,
                PARAM_INDEX_OF_REFRACTION,
                refraction);
}

        bool
PhongElement::LinkChannels ()
{
        return pv->LinkChannels (this);
}

/*
 * ---------------------------------------------------------------------------
 * Effect.
 */

struct pv_EffectElement
{
        pv_EffectElement ()
                :
                effect(NULL),

                profileCommon(NULL),
                technique(NULL),
                phong(NULL),
                blinn(NULL),
                lambert(NULL),
                constant(NULL)
        {
        }

        void			 SetEffect (EffectElement *effectItem)
        {
                effect = effectItem;
        }

        bool			 LinkProfileCOMMON ();

        /*
         * Be sure to add all surface samplers before calling
         * SetEffectColor, SetEffectTexture, or SetEffectFloat.
         */
        void			 AddSurfaceSampler (const string& name);

        bool			 HasPhong () const;
        bool			 HasBlinn () const;
        bool			 HasLambert () const;
        bool			 HasConstant () const;

        /*
         * LinkTechnique and AddTechnique ensure that the technique
         * and phong/blinn tree are ready for loading and saving respectively.
         */
        bool			 LinkTechnique ();
        void			 AddTechnique ();

        bool			 LinkPhong ();
        void			 AddPhong ();

        bool			 LinkBlinn ();
        void			 AddBlinn ();

        bool			 LinkLambert ();
        void			 AddLambert ();

        bool			 LinkConstant ();
        void			 AddConstant ();

        bool			 GetSurfaceID (
                                        const string	&samplerID,
                                        string		&surfaceID) const;

        bool			 GetImageID (
                                        const string	&surfaceID,
                                        string		&imageID) const;

        EffectElement		*effect;

        ElementXML		*profileCommon;
        ElementXMLList	 	 newparamSurfaces;
        ElementXMLList		 newparamSamplers;
        ElementXML		*technique;
        ElementXML		*phong;
        ElementXML		*blinn;
        ElementXML		*lambert;
        ElementXML		*constant;
};

        bool
pv_EffectElement::LinkProfileCOMMON ()
{
        bool	linked(false);
        profileCommon = effect->GetElementHandle ().FirstChildElement (
                ELEMENT_PROFILE_COMMON).Element ();
        if (profileCommon) {
                linked = LinkTechnique ();
        }

        return linked;
}

        void
pv_EffectElement::AddSurfaceSampler (const string& imageID)
{
        ElementXML *newparamSurface =
                effect->AddElement (profileCommon, ELEMENT_NEWPARAM);
        newparamSurfaces.push_back(newparamSurface);

        string surfaceName = imageID + string(ATTRVALUE_SURFACESUFFIX);
        effect->SetSID (newparamSurface, surfaceName);
        ElementXML *surface =
                effect->AddElement (newparamSurface, ELEMENT_SURFACE);
        effect->SetType (surface, ATTRVALUE_2D);
        ElementXML *init_from =
                effect->AddElement (surface, ELEMENT_INIT_FROM);
        effect->SetElementValue (init_from, imageID);
        ElementXML *format = effect->AddElement (surface, ELEMENT_FORMAT);

        /*
         * [TODO] Look up the image format and write out 8-, 24-, or 32-bit mask.
         *        (And don't forget to support grayscale.)
         */
        string pixelFormat("A8R8G8B8");
        effect->SetElementValue (format, pixelFormat);

        ElementXML *newparamSampler =
                effect->AddElement (profileCommon, ELEMENT_NEWPARAM);
        newparamSamplers.push_back(newparamSampler);
        string samplerName = imageID + string(ATTRVALUE_SAMPLERSUFFIX);
        effect->SetSID (newparamSampler, samplerName);
        ElementXML *sampler2D =
                effect->AddElement (newparamSampler, ELEMENT_SAMPLER2D);
        ElementXML *source = effect->AddElement (sampler2D, ELEMENT_SOURCE);

        /*
         * Cross-reference the surface name.
         */
        effect->SetElementValue (source, surfaceName);

        /*
         * Boilerplate for the min and mag filter elements.
         */
        ElementXML *minfilter =
                effect->AddElement (sampler2D, ELEMENT_MINFILTER);
        effect->SetElementValue (minfilter, VALUE_LINEARMIPMAPLINEAR);
        ElementXML *magfilter =
                effect->AddElement (sampler2D, ELEMENT_MAGFILTER);
        effect->SetElementValue (magfilter, VALUE_LINEAR);
}

        bool
pv_EffectElement::HasPhong () const
{
        return (technique && technique->FirstChildElement (ELEMENT_PHONG));
}

        bool
pv_EffectElement::HasBlinn () const
{
        return (technique && technique->FirstChildElement (ELEMENT_BLINN));
}

        bool
pv_EffectElement::HasLambert () const
{
        return (technique && technique->FirstChildElement (ELEMENT_LAMBERT));
}

        bool
pv_EffectElement::HasConstant () const
{
        return (technique && technique->FirstChildElement (ELEMENT_CONSTANT));
}

        bool
pv_EffectElement::LinkTechnique ()
{
        bool	linked(false);
        technique = profileCommon->FirstChildElement (ELEMENT_TECHNIQUE);
        if (technique) {
                if (HasPhong ()) {
                        linked = LinkPhong ();
                }
                else if (HasBlinn ()) {
                        linked = LinkBlinn ();
                }
                else if (HasLambert ()) {
                        linked = LinkLambert ();
                }
                else if (HasConstant ()) {
                        linked = LinkConstant ();
                }
        }

        return linked;
}

        void
pv_EffectElement::AddTechnique ()
{
        if (technique == NULL) {
                technique = effect->AddElement (profileCommon, ELEMENT_TECHNIQUE);
                effect->SetSID (technique, ATTRVALUE_COMMON);
        }
}

        bool
pv_EffectElement::LinkPhong ()
{
        phong = technique->FirstChildElement (ELEMENT_PHONG);
        return (phong != NULL);
}

        void
pv_EffectElement::AddPhong ()
{
        AddTechnique ();
        if (phong == NULL) {
                phong = effect->AddElement (technique, ELEMENT_PHONG);
        }
}

        bool
pv_EffectElement::LinkBlinn ()
{
        blinn = technique->FirstChildElement (ELEMENT_BLINN);
        return (blinn != NULL);
}

        void
pv_EffectElement::AddBlinn ()
{
        AddTechnique ();
        if (blinn == NULL) {
                blinn = effect->AddElement (technique, ELEMENT_BLINN);
        }
}

        bool
pv_EffectElement::LinkLambert ()
{
        lambert = technique->FirstChildElement (ELEMENT_LAMBERT);
        return (lambert != NULL);
}

        void
pv_EffectElement::AddLambert ()
{
        AddTechnique ();
        if (lambert == NULL) {
                lambert = effect->AddElement (technique, ELEMENT_LAMBERT);
        }
}

        bool
pv_EffectElement::LinkConstant ()
{
        constant = technique->FirstChildElement (ELEMENT_CONSTANT);
        return (constant != NULL);
}

        void
pv_EffectElement::AddConstant ()
{
        AddTechnique ();
        if (constant == NULL) {
                constant = effect->AddElement (technique, ELEMENT_CONSTANT);
        }
}

        bool
pv_EffectElement::GetSurfaceID (
        const string	&samplerID,
        string		&surfaceID) const
{
        /*
         * Iterate over the this element's child elements, looking for
         * an element with a matching samplerID.
         */
        bool	linked(false);
        ElementXML *newParamElem = effect->GetElementHandle (profileCommon).FirstChildElement (
                ELEMENT_NEWPARAM).Element ();
        while (newParamElem) {
                if (effect->GetSID (newParamElem) == samplerID) {
                        ElementXML *sampler2Delem =
                                effect->GetElementHandle(newParamElem).FirstChildElement (
                                        ELEMENT_SAMPLER2D).Element ();
                        if (sampler2Delem) {
                                ElementXML *sourceElem =
                                        effect->GetElementHandle(sampler2Delem).FirstChildElement (
                                                ELEMENT_SOURCE).Element ();
                                if (sourceElem) {
                                        surfaceID = effect->GetElementValue (sourceElem);
                                        linked = !surfaceID.empty ();
                                }
                        }

                        break;
                }
                newParamElem = newParamElem->NextSiblingElement (ELEMENT_NEWPARAM);
        }

        return linked;
}

        bool
pv_EffectElement::GetImageID (
        const string	&surfaceID,
        string		&imageID) const
{
        /*
         * Iterate over the this element's child elements, looking for
         * an element with a matching samplerID.
         */
        bool	found(false);
        ElementXML *newParamElem = effect->GetElementHandle (profileCommon).FirstChildElement (
                ELEMENT_NEWPARAM).Element ();
        while (newParamElem) {
                if (effect->GetSID (newParamElem) == surfaceID) {
                        ElementXML *surfaceElem =
                                effect->GetElementHandle(newParamElem).FirstChildElement (
                                        ELEMENT_SURFACE).Element ();
                        if (surfaceElem) {
                                ElementXML *initFromElem =
                                        effect->GetElementHandle(surfaceElem).FirstChildElement (
                                                ELEMENT_INIT_FROM).Element ();
                                if (initFromElem) {
                                        imageID = effect->GetElementValue (initFromElem);
                                        found = !imageID.empty ();
                                }
                        }

                        break;
                }
                newParamElem = newParamElem->NextSiblingElement (ELEMENT_NEWPARAM);
        }

        return found;
}

EffectElement::EffectElement (
         EffectLibraryElement &library,
         const std::string	&name)
        :
        Element(library.PV ()),
        pv(new pv_EffectElement())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                pv->SetEffect (this);
                library.AddEffect (*this);

                SetID (EffectID (ItemID (name)));
                SetName (name);

                pv->profileCommon = AddElement (ELEMENT_PROFILE_COMMON);
        }
}

EffectElement::EffectElement (
         EffectLibraryElement &library)
        :
        Element(library.PV ()),
        pv(new pv_EffectElement())
{
        pv->SetEffect (this);

        /*
         * There can be more than one effect, so the client calls
         * LinkEffect for a specific effect ID after construction.
         */
}

EffectElement::~EffectElement ()
{
        delete pv;
}

        bool
EffectElement::LinkProfileCOMMON ()
{
        return pv->LinkProfileCOMMON ();
}


/*
 * Surfaces and samplers.
 * These are cross-referenced by a phong map value.
 */

        bool
EffectElement::GetSurfaceSamplerImageID (
        const string	&samplerID,
        string		&imageID) const
{
        bool	found(false);
        string surfaceID;
        if (pv->GetSurfaceID (samplerID, surfaceID)) {
                found = pv->GetImageID (surfaceID, imageID);
        }

        return found;
}

        void
EffectElement::AddSurfaceSampler (const string& imageID)
{
        pv->AddSurfaceSampler (imageID);
}

        bool
EffectElement::HasConstant () const
{
        return pv->HasConstant ();
}

        bool
EffectElement::HasLambert () const
{
        return pv->HasLambert ();
}

        bool
EffectElement::HasBlinn () const
{
        return pv->HasBlinn ();
}

        bool
EffectElement::HasPhong () const
{
        return pv->HasPhong ();
}

        bool
EffectElement::LinkConstant (
        ConstantElement	&constant)
{
        bool	linked(false);

        if (pv->constant) {
                constant.SetElement (pv->constant);
                linked = constant.LinkChannels ();
        }

        LXxUNUSED (linked);
        return true;
}

        void
EffectElement::AddConstant (
        ConstantElement	&constant)
{
        pv->AddConstant ();
        constant.SetElement (pv->constant);
}

        bool
EffectElement::LinkLambert (
        LambertElement	&lambert)
{
        bool	linked(false);

        if (pv->lambert) {
                lambert.SetElement (pv->lambert);
                linked = lambert.LinkChannels ();
        }

        LXxUNUSED (linked);
        return true;
}

        void
EffectElement::AddLambert (
        LambertElement	&lambert)
{
        pv->AddLambert ();
        lambert.SetElement (pv->lambert);
}

        bool
EffectElement::LinkBlinn (
        BlinnElement		&blinn)
{
        bool	linked(false);

        if (pv->blinn) {
                blinn.SetElement (pv->blinn);
                linked = blinn.LinkChannels ();
        }

        LXxUNUSED (linked);
        return true;
}

        void
EffectElement::AddBlinn (
        BlinnElement		&blinn)
{
        pv->AddBlinn ();
        blinn.SetElement (pv->blinn);
}

        bool
EffectElement::LinkPhong (
        PhongElement		&phong)
{
        bool	linked(false);
        if (pv->phong) {
                phong.SetElement (pv->phong);
                linked = phong.LinkChannels ();
        }

        return linked;
}

        void
EffectElement::AddPhong (
        PhongElement		&phong)
{
        pv->AddPhong ();
        phong.SetElement (pv->phong);
}

/*
 * ---------------------------------------------------------------------------
 * Effect Library.
 */

EffectLibraryElement::EffectLibraryElement (COLLADAElement &collada)
        :
        Element(collada.PV ())
{
        if (GetIOMode () == IO_MODE_SAVE) {
                collada.AddEffectLibrary (*this);
        }
        else if (GetIOMode () == IO_MODE_LOAD) {
                collada.LinkEffectLibrary (*this);
        }
}

EffectLibraryElement::~EffectLibraryElement ()
{
}

        bool
EffectLibraryElement::HasEffect () const
{
        return HasChildElement (ELEMENT_EFFECT);
}

        bool
EffectLibraryElement::LinkEffect (
        const std::string	&effectID,
        EffectElement		&effect)
{
        bool	linked(false);
        if (LinkFirstChildElement (ELEMENT_EFFECT, effectID, effect)) {
                linked = effect.LinkProfileCOMMON ();
        }

        return linked;
}

        void
EffectLibraryElement::AddEffect (EffectElement &effect)
{
        effect.SetElement (AddElement (ELEMENT_EFFECT));
}

} // namespace cio

